﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.Transactions
{
    public class ServiceSearchClass
    {
        string _Name;
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        string _Code;

        public string Code
        {
            get { return _Code; }
            set { _Code = value; }
        }
        int _id;
    }
}
