﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACC.CommonExtensions;
using atACC.HTL.ORM;
namespace atACC.HTL.Transactions
{
    public  class RateCalculationClass
    {
        public static RoomTariffs GetTariffs(atACCHotelEntities dbh, int iRoomTypeId, int iRateTypeId)
        {
            #region Room Rent Calculation With Room Type
            if (iRateTypeId == 0) // Default
            {                
                RoomTypes e_RoomTypes = dbh.RoomTypes.Where(x => x.id == iRoomTypeId).SingleOrDefault();
                if (e_RoomTypes != null)
                {
                    RoomTariffs roomTariffs = new RoomTariffs()
                    {
                        BaseRate = e_RoomTypes.BaseRate.ToDecimal(),
                        AdditionalPersonRate = e_RoomTypes.AdditionalPersonRate.ToDecimal(),
                        ExtraBedRate = e_RoomTypes.ExtraBedRate.ToDecimal()
                    };
                    return roomTariffs;
                }
            }
            #endregion
            #region Room Rent Calculation With Room Tariffs
            else
            {
                return dbh.RoomTariffs.Where(x => x.FK_RateTypeID == iRateTypeId && x.FK_RoomTypeID == iRoomTypeId).SingleOrDefault();                
            }
            #endregion
            return null;
        }
    }
}
