﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACC.Common;
using atACC.CommonExtensions;
using atACC.HTL.ORM;

namespace atACC.HTL.Transactions
{
    public static class SlabCalculationClass
    {
        public static void CalculateSlabAmount(this ITransactionSlabDTL dTL, atACCHotelEntities db, List<Slab> Slabs, bool blnUpdateDeductionAmount = true)
        {
			ENMVMTTransactionType TransactionType = ENMVMTTransactionType.Sales;
			int PurchaseSalesType = (int)ENMVMTSalesType.GSTIntraStateB2C;
			Slab Tax1Slab = null, Tax2Slab = null, Tax3Slab = null, GSTSlab = null, VATSlab = null, AddnlTaxSlab = null, DiscountSlab = null, ExciseDutySlab = null;			
			if (dTL != null)
			{
				if (Slabs != null)
				{
					initSlabPercentageAndID(dTL);

					if (GlobalFunctions.blnTax1) { Tax1Slab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX1).FirstOrDefault(); }
					if (GlobalFunctions.blnTax2) { Tax2Slab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX2).FirstOrDefault(); }
					if (GlobalFunctions.blnTax3) { Tax3Slab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX3).FirstOrDefault(); }
					if (GlobalFunctions.blnGST) { GSTSlab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.GST).FirstOrDefault(); }
					if (GlobalFunctions.blnVAT) { VATSlab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.VAT).FirstOrDefault(); }
					if (GlobalFunctions.blnAddnlTax) { AddnlTaxSlab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.AdditionalTax).FirstOrDefault(); }
					if (GlobalFunctions.blnSlabDiscount) { DiscountSlab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.Discount).FirstOrDefault(); }
					if (GlobalFunctions.blnExiseDuty) { ExciseDutySlab = Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.ExciseDuty).FirstOrDefault(); }
					if (Tax1Slab != null) dTL.FK_TAX1SlabID = Tax1Slab.id;
					if (Tax2Slab != null) dTL.FK_TAX2SlabID = Tax2Slab.id;
					if (Tax3Slab != null) dTL.FK_TAX3SlabID = Tax3Slab.id;
					if (VATSlab != null) dTL.FK_VATSlabID = VATSlab.id;
					if (AddnlTaxSlab != null) dTL.FK_AddnlTaxSlabID = AddnlTaxSlab.id;
					if (DiscountSlab != null) dTL.FK_DiscountSlabID = DiscountSlab.id;
					if (ExciseDutySlab != null) dTL.FK_ExciseSlabID = ExciseDutySlab.id;
					if (GSTSlab != null) dTL.FK_GSTSlabID = GSTSlab.id;
				}
                else
                {
					initSlabPercentage(dTL);
					Slabs = (from slab in db.Slabs
							 select slab).ToList();
					Tax1Slab = Slabs.Where(x => x.id == dTL.FK_TAX1SlabID).SingleOrDefault();
					Tax2Slab = Slabs.Where(x => x.id == dTL.FK_TAX2SlabID).SingleOrDefault();
					Tax3Slab = Slabs.Where(x => x.id == dTL.FK_TAX3SlabID).SingleOrDefault();
					GSTSlab = Slabs.Where(x => x.id == dTL.FK_GSTSlabID).SingleOrDefault();
					VATSlab = Slabs.Where(x => x.id == dTL.FK_VATSlabID).SingleOrDefault();
					AddnlTaxSlab = Slabs.Where(x => x.id == dTL.FK_AddnlTaxSlabID).SingleOrDefault();
					DiscountSlab = Slabs.Where(x => x.id == dTL.FK_DiscountSlabID).SingleOrDefault();
					ExciseDutySlab = Slabs.Where(x => x.id == dTL.FK_ExciseSlabID).SingleOrDefault();
				}
				bool blnApplyGST = IsInterStateGST(TransactionType, PurchaseSalesType) != null;
				bool blnApplyAddnlTax = !(GlobalFunctions.blnKeralaFloodCess && !(PurchaseSalesType == (int)ENMVMTSalesType.GSTInterStateB2C || PurchaseSalesType == (int)ENMVMTSalesType.GSTIntraStateB2C));
				decimal dcTotalInclusiveTaxPerc = getTotalInclusiveTaxPercentage(Tax1Slab, Tax2Slab, Tax3Slab, (blnApplyGST ? GSTSlab : null), VATSlab, (blnApplyAddnlTax ? AddnlTaxSlab : null), DiscountSlab, ExciseDutySlab);
				
				#region Exclusive Rate From Inclusive Rate

				//if (cell == null || (cell.OwningColumn.Name == "col_InclusiveRate" || cell.OwningColumn.Name == "col_Unit" || cell.OwningColumn.Name == "col_Batch" || cell.OwningColumn.Name == "col_MultiRate" || cell.OwningColumn.Name == "col_Product" || cell.OwningColumn.Name == "col_ProductName"))
				//{
				//	if (TransactionType == ENMVMTTransactionType.Purchase && GlobalFunctions.blnInclusiveRateInPurchase || TransactionType == ENMVMTTransactionType.Sales && GlobalFunctions.blnInclusiveRateInSales)
				//	{
				//		dTL.Rate = (dTL.InclusiveRate * 100) / (100 + dcTotalInclusiveTaxPerc);// Exclusive Rate
				//	}
				//}

				#endregion

				#region Applying Slab

				dTL.NetAmount = dTL.Amount;
				dTL.TotalTax = dTL.TotalDiscount = 0;
				ApplySlabDiscount(DiscountSlab, dTL);
				ApplySpecialDiscount(dTL, blnUpdateDeductionAmount);

				dTL.TaxableAmount = dTL.NetAmount;

				if ((PurchaseSalesType == (int)ENMVMTPurchaseType.NonTax && TransactionType == ENMVMTTransactionType.Purchase)
				   || (PurchaseSalesType == (int)ENMVMTSalesType.NonTax && TransactionType == ENMVMTTransactionType.Sales)
				|| (PurchaseSalesType == (int)ENMVMTPurchaseType.Import && TransactionType == ENMVMTTransactionType.Purchase
				&& GlobalFunctions.iCompanyCountryID == (int)ENMVCountryList.SaudiArabia)
				  )
				{
					initSlabPercentage(dTL);
				}
				else
				{
					ApplyExcise(ExciseDutySlab, dTL);
					ApplyTax1(Tax1Slab, dTL);
					ApplyTax2(Tax2Slab, dTL, db);
					ApplyTax3(Tax3Slab, dTL, db);
					ApplyAddnlTax(AddnlTaxSlab, dTL, db, PurchaseSalesType);
					ApplyVAT(VATSlab, dTL, db);
					ApplyGST(GSTSlab, dTL, db, TransactionType, PurchaseSalesType);
				}
				#endregion
				dTL.TotalDiscount = dTL.SlabDiscount + dTL.DeductionAmount;
				dTL.TotalTax = dTL.ExciseAmount + dTL.Tax1Amount + dTL.Tax2Amount + dTL.Tax3Amount
								+ dTL.AddnlTaxAmount + dTL.VATAmount + dTL.CGSTAmount + dTL.SGSTAmount + dTL.IGSTAmount;
				#region Inclusive
				//if (cell != null && cell.OwningColumn.Name == "col_Rate")
				//{
				//	if (TransactionType == ENMVMTTransactionType.Purchase && GlobalFunctions.blnInclusiveRateInPurchase || TransactionType == ENMVMTTransactionType.Sales && GlobalFunctions.blnInclusiveRateInSales)
				//	{
				//		dTL.InclusiveRate = (dTL.Rate * (100 + dcTotalInclusiveTaxPerc)) / 100;// Inclusive  Rate
				//	}
				//}
				#endregion

			}
		}

        #region Private Methods
        private static void ApplySlabDiscount(Slab DiscountSlab, ITransactionSlabDTL dTL)
		{
			if (DiscountSlab == null) { return; }
			if (DiscountSlab.Value == 0) { return; }
			if (DiscountSlab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				if (DiscountSlab.FK_MasterValueBase == (int)ENMVMTBase.Gross)
				{
					dTL.SlabDiscountPerc = DiscountSlab.Value;
					dTL.SlabDiscount = (dTL.Amount * dTL.SlabDiscountPerc / 100);
				}
				dTL.NetAmount = dTL.Amount - dTL.SlabDiscount;
			}
			else if (DiscountSlab.FK_MasterValueValueType == (int)ENMVMTValueType.FLAT)
			{
				if (DiscountSlab.FK_MasterValueBase == (int)ENMVMTBase.Gross)
				{
					if (dTL.Amount != 0)
					{
						dTL.SlabDiscountPerc = (DiscountSlab.Value * 100) / dTL.Amount;
					}
					dTL.SlabDiscount = DiscountSlab.Value;
				}
				dTL.NetAmount = dTL.Amount - dTL.SlabDiscount;
			}			
		}
		private static void ApplySpecialDiscount(ITransactionSlabDTL dTL, bool blnUpdateDeductionAmount)
		{
			if (!blnUpdateDeductionAmount)
			{
				dTL.DeductionPerc = (dTL.DeductionAmount * 100) / dTL.NetAmount;
			}
			else
			{
				dTL.DeductionAmount = (dTL.NetAmount * dTL.DeductionPerc / 100);
			}
			dTL.NetAmount -= dTL.DeductionAmount ?? 0;			
		}
		
		
		private static void ApplyExcise(Slab ExciseSlab, ITransactionSlabDTL dTL)
		{
			if (ExciseSlab == null) { return; }
			if (ExciseSlab.Value == 0) { return; }
			if (ExciseSlab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				dTL.ExcisePerc = ExciseSlab.Value;
				if (ExciseSlab.FK_MasterValueBase == (int)ENMVMTBase.Gross)  // Gross
				{
					dTL.ExciseAmount = (dTL.Amount * dTL.ExcisePerc / 100);
				}
				else if (ExciseSlab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount) // Taxable
				{
					dTL.ExciseAmount = (dTL.TaxableAmount * dTL.ExcisePerc / 100);
				}
				if (ExciseSlab.AddorLess == 1)
				{
					dTL.NetAmount = dTL.NetAmount + dTL.ExciseAmount;
				}
				else
				{
					dTL.NetAmount = dTL.NetAmount - dTL.ExciseAmount;
				}
			}
		}
		private static void ApplyTax1(Slab Tax1Slab, ITransactionSlabDTL dTL)
		{
			if (Tax1Slab == null) { return; }
			if (Tax1Slab.Value == 0) { return; }
			if (Tax1Slab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				dTL.Tax1Perc = Tax1Slab.Value;
				if (Tax1Slab.FK_MasterValueBase == (int)ENMVMTBase.Gross)  // Gross
				{
					dTL.Tax1Amount = (dTL.Amount * dTL.Tax1Perc / 100);
				}
				else if (Tax1Slab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount) // Taxable
				{
					dTL.Tax1Amount = (dTL.TaxableAmount * dTL.Tax1Perc / 100);
				}
				else if (Tax1Slab.FK_MasterValueBase == (int)ENMVMTBase.NetAmount) // NetAmount
				{
					dTL.Tax1Amount = ((dTL.TaxableAmount + dTL.ExciseAmount) * dTL.Tax1Perc / 100);
				}
				if (Tax1Slab.AddorLess == 1)
				{
					dTL.NetAmount = dTL.NetAmount + dTL.Tax1Amount;
				}
				else
				{
					dTL.NetAmount = dTL.NetAmount - dTL.Tax1Amount;
				}
			}

		}
		private static void ApplyTax2(Slab Tax2Slab, ITransactionSlabDTL dTL, atACCHotelEntities db)
		{
			if (Tax2Slab == null) { return; }
			decimal? dcanotherSlabAmount = 0;
			if (Tax2Slab.Value == 0) { return; }
			if (Tax2Slab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				dTL.Tax2Perc = Tax2Slab.Value;
				if (Tax2Slab.FK_MasterValueBase == (int)ENMVMTBase.Gross)  // Gross
				{
					dTL.Tax2Amount = (dTL.Amount * dTL.Tax2Perc / 100);
				}
				else if (Tax2Slab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount) // Taxable
				{
					dTL.Tax2Amount = (dTL.TaxableAmount * dTL.Tax2Perc / 100);
				}
				else if (Tax2Slab.FK_MasterValueBase == (int)ENMVMTBase.NetAmount) // NetAmount
				{
					dTL.Tax2Amount = ((dTL.TaxableAmount + dTL.ExciseAmount + dTL.Tax1Amount) * dTL.Tax2Perc / 100);
				}
				else if (Tax2Slab.FK_MasterValueBase == (int)ENMVMTBase.AnotherSlabValue)
				{
					dcanotherSlabAmount = getAnotherSlabAmount(Tax2Slab.FK_AnotherSlab, dTL, db);
					dTL.Tax2Amount = (dcanotherSlabAmount * dTL.Tax2Perc / 100);
				}
				if (Tax2Slab.AddorLess == 1)
				{
					dTL.NetAmount = dTL.NetAmount + dTL.Tax2Amount;
				}
				else
				{
					dTL.NetAmount = dTL.NetAmount - dTL.Tax2Amount;
				}
			}
		}
		private static void ApplyTax3(Slab Tax3Slab, ITransactionSlabDTL dTL, atACCHotelEntities db)
		{
			if (Tax3Slab == null) { return; }
			decimal? dcanotherSlabAmount = 0;
			if (Tax3Slab.Value == 0) { return; }
			if (Tax3Slab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				dTL.Tax3Perc = Tax3Slab.Value;
				if (Tax3Slab.FK_MasterValueBase == (int)ENMVMTBase.Gross)  // Gross
				{
					dTL.Tax3Amount = (dTL.Amount * dTL.Tax3Perc / 100);
				}
				else if (Tax3Slab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount) // Taxable
				{
					dTL.Tax3Amount = (dTL.TaxableAmount * dTL.Tax3Perc / 100);
				}
				else if (Tax3Slab.FK_MasterValueBase == (int)ENMVMTBase.NetAmount) // NetAmount
				{
					dTL.Tax3Amount = ((dTL.TaxableAmount + dTL.ExciseAmount + dTL.Tax1Amount + dTL.Tax2Amount) * dTL.Tax3Perc / 100);
				}
				else if (Tax3Slab.FK_MasterValueBase == (int)ENMVMTBase.AnotherSlabValue)
				{
					dcanotherSlabAmount = getAnotherSlabAmount(Tax3Slab.FK_AnotherSlab, dTL, db);
					dTL.Tax3Amount = (dcanotherSlabAmount * dTL.Tax3Perc / 100);
				}
				if (Tax3Slab.AddorLess == 1)
				{
					dTL.NetAmount = dTL.NetAmount + dTL.Tax3Amount;
				}
				else
				{
					dTL.NetAmount = dTL.NetAmount - dTL.Tax3Amount;
				}
			}
		}
		private static void ApplyAddnlTax(Slab AddnlTaxSlab, ITransactionSlabDTL dTL , atACCHotelEntities db, int PurchaseSalesType)
		{
			if (AddnlTaxSlab == null) { return; }
			decimal? dcanotherSlabAmount = 0;
			if (AddnlTaxSlab.Value == 0) { return; }
			if (GlobalFunctions.blnKeralaFloodCess && !(PurchaseSalesType == (int)ENMVMTSalesType.GSTInterStateB2C || PurchaseSalesType == (int)ENMVMTSalesType.GSTIntraStateB2C))
			{
				return;
			}
			if (AddnlTaxSlab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				dTL.AddnlTaxPerc = AddnlTaxSlab.Value;
				if (AddnlTaxSlab.FK_MasterValueBase == (int)ENMVMTBase.Gross)  // Gross
				{
					dTL.AddnlTaxAmount = (dTL.Amount * dTL.AddnlTaxPerc / 100);
				}
				else if (AddnlTaxSlab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount) // Taxable
				{
					dTL.AddnlTaxAmount = (dTL.TaxableAmount * dTL.AddnlTaxPerc / 100);
				}
				else if (AddnlTaxSlab.FK_MasterValueBase == (int)ENMVMTBase.NetAmount) // NetAmount
				{
					dTL.AddnlTaxAmount = ((dTL.TaxableAmount + dTL.ExciseAmount + dTL.Tax1Amount + dTL.Tax2Amount + dTL.Tax3Amount) * dTL.AddnlTaxPerc / 100);
				}
				else if (AddnlTaxSlab.FK_MasterValueBase == (int)ENMVMTBase.AnotherSlabValue)
				{
					dcanotherSlabAmount = getAnotherSlabAmount(AddnlTaxSlab.FK_AnotherSlab, dTL, db);
					dTL.AddnlTaxAmount = (dcanotherSlabAmount * dTL.AddnlTaxPerc / 100);
				}
				if (AddnlTaxSlab.AddorLess == 1)
				{
					dTL.NetAmount = dTL.NetAmount + dTL.AddnlTaxAmount;
				}
				else
				{
					dTL.NetAmount = dTL.NetAmount - dTL.AddnlTaxAmount;
				}
			}
		}
		private static void ApplyVAT(Slab VATSlab, ITransactionSlabDTL dTL, atACCHotelEntities db)
		{
			if (VATSlab == null) { return; }
			decimal? dcanotherSlabAmount = 0;
			if (VATSlab.Value == 0) { return; }
			if (VATSlab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				dTL.VATPerc = VATSlab.Value;
				if (VATSlab.FK_MasterValueBase == (int)ENMVMTBase.Gross)  // Gross
				{
					dTL.VATAmount = (dTL.Amount * dTL.VATPerc / 100);
				}
				else if (VATSlab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount) // Taxable
				{
					dTL.VATAmount = (dTL.TaxableAmount * dTL.VATPerc / 100);
				}
				else if (VATSlab.FK_MasterValueBase == (int)ENMVMTBase.NetAmount) // NetAmount
				{
					dTL.VATAmount = ((dTL.TaxableAmount + dTL.ExciseAmount + dTL.Tax1Amount) * dTL.VATPerc / 100);
				}
				else if (VATSlab.FK_MasterValueBase == (int)ENMVMTBase.AnotherSlabValue)
				{
					dcanotherSlabAmount = getAnotherSlabAmount(VATSlab.FK_AnotherSlab, dTL, db);
					dTL.VATAmount = (dcanotherSlabAmount * dTL.VATPerc / 100);
				}
				if (VATSlab.AddorLess == 1)
				{
					dTL.NetAmount = dTL.NetAmount + dTL.VATAmount;
				}
				else
				{
					dTL.NetAmount = dTL.NetAmount - dTL.VATAmount;
				}
			}
		}
		private static void ApplyGST(Slab GSTSlab, ITransactionSlabDTL dTL, atACCHotelEntities db, ENMVMTTransactionType TransactionType, int? PurchaseSalesType)
		{
			if (GSTSlab == null) { return; }
            if (PurchaseSalesType == null) { return; }
            if (GSTSlab.Value == 0) { return; }
			if (GSTSlab.FK_MasterValueValueType == (int)ENMVMTValueType.Percentage)
			{
				bool? blnInterState = IsInterStateGST(TransactionType, PurchaseSalesType.Value);
				if (blnInterState != null)
				{
					if (!blnInterState.Value)
					{
						dTL.CGSTPerc = GSTSlab.Value / 2;
						dTL.SGSTPerc = GSTSlab.Value / 2;
						dTL.IGSTPerc = 0;
					}
					else
					{
						dTL.CGSTPerc = 0;
						dTL.SGSTPerc = 0;
						dTL.IGSTPerc = GSTSlab.Value;
					}

					decimal? dcanotherSlabAmount = 0;

					if (GSTSlab.FK_MasterValueBase == (int)ENMVMTBase.Gross)  // Gross
					{
						dTL.CGSTAmount = (dTL.Amount * dTL.CGSTPerc / 100);
						dTL.SGSTAmount = (dTL.Amount * dTL.SGSTPerc / 100);
						dTL.IGSTAmount = (dTL.Amount * dTL.IGSTPerc / 100);
					}
					else if (GSTSlab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount) // Taxable
					{
						dTL.CGSTAmount = (dTL.TaxableAmount * dTL.CGSTPerc / 100);
						dTL.SGSTAmount = (dTL.TaxableAmount * dTL.SGSTPerc / 100);
						dTL.IGSTAmount = (dTL.TaxableAmount * dTL.IGSTPerc / 100);
					}
					else if (GSTSlab.FK_MasterValueBase == (int)ENMVMTBase.NetAmount) // NetAmount
					{
						dTL.CGSTAmount = ((dTL.TaxableAmount + dTL.ExciseAmount + dTL.Tax1Amount) * dTL.CGSTPerc / 100);
						dTL.SGSTAmount = ((dTL.TaxableAmount + dTL.ExciseAmount + dTL.Tax1Amount) * dTL.SGSTPerc / 100);
						dTL.IGSTAmount = ((dTL.TaxableAmount + dTL.ExciseAmount + dTL.Tax1Amount) * dTL.IGSTPerc / 100);
					}
					else if (GSTSlab.FK_MasterValueBase == (int)ENMVMTBase.AnotherSlabValue)
					{
						dcanotherSlabAmount = getAnotherSlabAmount(GSTSlab.FK_AnotherSlab, dTL, db);
						dTL.CGSTAmount = (dcanotherSlabAmount * dTL.CGSTPerc / 100);
						dTL.SGSTAmount = (dcanotherSlabAmount * dTL.SGSTPerc / 100);
						dTL.IGSTAmount = (dcanotherSlabAmount * dTL.IGSTPerc / 100);
					}
					if (GSTSlab.AddorLess == 1)
					{
						dTL.NetAmount = dTL.NetAmount + (dTL.CGSTAmount + dTL.SGSTAmount + dTL.IGSTAmount);
					}
					else
					{
						dTL.NetAmount = dTL.NetAmount - (dTL.CGSTAmount + dTL.SGSTAmount + dTL.IGSTAmount);
					}
				}
			}
		}

		private static decimal? getAnotherSlabAmount(int? slabTypeId, ITransactionSlabDTL dTL, atACCHotelEntities db)
		{
			decimal? dcAmount = 0;
			switch (slabTypeId)
			{
				case (int)ENMVMTSlabType.TAX1:
					dcAmount = dTL.Tax1Amount;
					break;
				case (int)ENMVMTSlabType.TAX2:
					dcAmount = dTL.Tax2Amount;
					break;
				case (int)ENMVMTSlabType.TAX3:
					dcAmount = dTL.Tax3Amount;
					break;
				case (int)ENMVMTSlabType.VAT:
					dcAmount = dTL.VATAmount;
					break;
			}

			return dcAmount;
		}
		private static void ApplySlabID(int iSlabTypeID, int? iSlabID, ITransactionSlabDTL dTL)
		{
			switch (iSlabTypeID)
			{
				case (int)ENMVMTSlabType.AdditionalTax:
					dTL.FK_AddnlTaxSlabID = iSlabID;
					break;
				case (int)ENMVMTSlabType.Discount:
					dTL.FK_DiscountSlabID = iSlabID;
					break;
				case (int)ENMVMTSlabType.ExciseDuty:
					dTL.FK_ExciseSlabID = iSlabID;
					break;
				case (int)ENMVMTSlabType.GST:
					dTL.FK_GSTSlabID = iSlabID;
					break;
				case (int)ENMVMTSlabType.TAX1:
					dTL.FK_TAX1SlabID = iSlabID;
					break;
				case (int)ENMVMTSlabType.TAX2:
					dTL.FK_TAX2SlabID = iSlabID;
					break;
				case (int)ENMVMTSlabType.TAX3:
					dTL.FK_TAX3SlabID = iSlabID;
					break;
				case (int)ENMVMTSlabType.VAT:
					dTL.FK_VATSlabID = iSlabID;
					break;
			}
		}
		private static bool? IsInterStateGST(ENMVMTTransactionType TransType, int PurchaseSalesType)
		{
			if ((int)TransType == (int)ENMVMTTransactionType.Purchase || (int)TransType == (int)ENMVMTTransactionType.ServicePurchaseInvoice)
			{
				if (PurchaseSalesType == (int)ENMVMTPurchaseType.GSTInterStateB2B || PurchaseSalesType == (int)ENMVMTPurchaseType.GSTInterStateB2BUnreg)
				{
					return true;
				}
				else if (PurchaseSalesType == (int)ENMVMTPurchaseType.GSTIntraStateB2B || PurchaseSalesType == (int)ENMVMTPurchaseType.GSTIntraStateB2BUnreg)
				{
					return false;
				}
				else
				{
					return null;
				}
			}
			else if ((int)TransType == (int)ENMVMTTransactionType.Sales || (int)TransType == (int)ENMVMTTransactionType.ServiceSalesInvoice)
			{
				if (PurchaseSalesType == (int)ENMVMTSalesType.GSTInterStateB2B || PurchaseSalesType == (int)ENMVMTSalesType.GSTInterStateB2C)
				{
					return true;
				}
				else if (PurchaseSalesType == (int)ENMVMTSalesType.GSTIntraStateB2B || PurchaseSalesType == (int)ENMVMTSalesType.GSTIntraStateB2C)
				{
					return false;
				}
				else
				{
					return null;
				}
			}
			else
			{
				return null;
			}
		}
		private static decimal getTotalInclusiveTaxPercentage(params Slab[] slabs)
		{
			decimal totalPerc = 0;
			foreach (Slab slab in slabs)
			{
				if (slab != null && slab.isInclusive.toInt32() == 1 && slab.FK_MasterValueBase == (int)ENMVMTBase.TaxableAmount)
				{
					totalPerc += slab.Value.ToDecimal();
				}
			}
			return totalPerc;
		}
		private static void initSlabPercentageAndID(ITransactionSlabDTL dTL)
		{
			dTL.FK_TAX1SlabID = null;
			dTL.FK_TAX2SlabID = null;
			dTL.FK_TAX3SlabID = null;
			dTL.FK_VATSlabID = null;
			dTL.FK_ExciseSlabID = null;
			dTL.FK_AddnlTaxSlabID = null;
			dTL.FK_DiscountSlabID = null;
			dTL.FK_GSTSlabID = null;
			initSlabPercentage(dTL);
		}
		private static void initSlabPercentage(ITransactionSlabDTL dTL)
		{			
			dTL.SlabDiscount = 0;
			dTL.SlabDiscountPerc = 0;
			dTL.ExciseAmount = 0;
			dTL.ExcisePerc = 0;
			dTL.Tax1Amount = 0;
			dTL.Tax1Perc = 0;
			dTL.Tax2Amount = 0;
			dTL.Tax2Perc = 0;
			dTL.Tax3Amount = 0;
			dTL.Tax3Perc = 0;
			dTL.AddnlTaxAmount = 0;
			dTL.AddnlTaxPerc = 0;
			dTL.VATAmount = 0;
			dTL.VATPerc = 0;
			dTL.CGSTAmount = 0;
			dTL.CGSTPerc = 0;
			dTL.SGSTAmount = 0;
			dTL.SGSTPerc = 0;
			dTL.IGSTAmount = 0;
			dTL.IGSTPerc = 0;
		}
        #endregion
    }
}
