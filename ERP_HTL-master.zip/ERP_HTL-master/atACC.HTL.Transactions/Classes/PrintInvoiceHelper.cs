﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACC.Common;
using atACC.CommonMessages;
using atACCFramework;
using atACC.CommonExtensions;
using LocalORM;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;
using DotmatrixPrint;
using CrystalDecisions.CrystalReports.Engine;
using System.Drawing.Printing;
using atACC.HTL.ORM;
using atACC.HTL.UI;

namespace atACC.HTL.Transactions
{
    public class PrintInvoiceHelper
    {
        atACCHotelEntities db;
        SettingsDbEntities sdb;
        SqlHelper sqlhelper;
        public PrintInvoiceHelper()
        {
            sqlhelper = new SqlHelper();
            sdb = new SettingsDbEntities();
            db = atHotelContext.CreateContext();
        }
        public bool SetPrintFormat(string sTransactionType, int iSaleOrPurchaseType)
        {
            int iFormatID = 0;
            if (GlobalFunctions.blnFormatSelectionInPrint)
            {
                if (HaveMultipleFormat(sTransactionType, iSaleOrPurchaseType) > 1)
                {
                    SelectFormatView frm = new SelectFormatView();
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        iFormatID = frm.iSelectedFormatID;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            InvoiceDesigner invoiceDesigner = GetCurrentFileFormat(sTransactionType, iSaleOrPurchaseType, iFormatID);
            string sPrintFormat = setFormat(invoiceDesigner, sTransactionType, iSaleOrPurchaseType, iFormatID);
            return true;
        }
        public bool PrintOut(string sTransactionType, int iHdrid, int iSaleOrPurchaseType, bool blnPrintPreview, string sExportFileName = "")
        {
            int iFormatID = 0;
            string sPrintFormat;
            string sProcedureName = GetProcedureName(sTransactionType);
            if (GlobalFunctions.blnFormatSelectionInPrint)
            {
                if (HaveMultipleFormat(sTransactionType, iSaleOrPurchaseType) > 1)
                {
                    SelectFormatView frm = new SelectFormatView();
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        iFormatID = frm.iSelectedFormatID;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            InvoiceDesigner invoiceDesigner = GetCurrentFileFormat(sTransactionType, iSaleOrPurchaseType, iFormatID);
            #region Validations
            if (invoiceDesigner == null)
            {
                if (MessageBox.Show("Print Format Not Set do you want to set it Now!", MessageKeys.MsgApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    sPrintFormat = setFormat(invoiceDesigner, sTransactionType, iSaleOrPurchaseType, iFormatID);
                    invoiceDesigner = GetCurrentFileFormat(sTransactionType, iSaleOrPurchaseType, iFormatID);
                }
                else
                {
                    return false;
                }
            }
            sPrintFormat = invoiceDesigner.FormatPath;

            if (sPrintFormat == "")
            {
                if (MessageBox.Show("Print Format Not Set do you want to set it Now!", MessageKeys.MsgApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    sPrintFormat = setFormat(invoiceDesigner, sTransactionType, iSaleOrPurchaseType, iFormatID);
                    return true;
                }
                else
                {
                    return false;
                }

            }

            if (!File.Exists(sPrintFormat))
            {
                MessageBox.Show("Print File Not Found!");
                return false;
            }
            #endregion
            if (invoiceDesigner.ReportType == (int)ENReportType.RDLC)
            {
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("HDRID", iHdrid));
                SqlHelper sqlh = new SqlHelper();
                ds = sqlh.ExecuteProcedure(sProcedureName, sqlParameters);
                System.Drawing.Printing.PrinterSettings printersetting = new System.Drawing.Printing.PrinterSettings();
                if (invoiceDesigner.PrinterName != null && invoiceDesigner.PrinterName.Trim() != "")
                {
                    printersetting.PrinterName = invoiceDesigner.PrinterName;

                }
                List<atReportParameter> entReportParameters = new List<atReportParameter>();
                entReportParameters.Add(new atReportParameter("Address2", GlobalFunctions.sCompanyAddress2));
                entReportParameters.Add(new atReportParameter("Address3", GlobalFunctions.sCompanyAddress3));
                entReportParameters.Add(new atReportParameter("City", GlobalFunctions.sCompanyCity));
                entReportParameters.Add(new atReportParameter("State", GlobalFunctions.sCompanyState));
                entReportParameters.Add(new atReportParameter("Country", GlobalFunctions.sCompanyCountry));
                entReportParameters.Add(new atReportParameter("PostalCode", GlobalFunctions.sCompanyPostalCode));
                entReportParameters.Add(new atReportParameter("Telephone", GlobalFunctions.sCompanyTelephone));
                entReportParameters.Add(new atReportParameter("Mobile", GlobalFunctions.sCompanyMobile));
                entReportParameters.Add(new atReportParameter("Fax", GlobalFunctions.sCompanyFax));
                entReportParameters.Add(new atReportParameter("Email", GlobalFunctions.sCompanyEmail));
                entReportParameters.Add(new atReportParameter("WebSite", GlobalFunctions.sCompanyWebSite));
                entReportParameters.Add(new atReportParameter("GSTNumber", GlobalFunctions.sCompanyGSTNumber));
                entReportParameters.Add(new atReportParameter("VATNumber", GlobalFunctions.sCompanyVATNumber));
                entReportParameters.Add(new atReportParameter("Tax1Number", GlobalFunctions.sCompanyTax1Number));
                entReportParameters.Add(new atReportParameter("Tax2Number", GlobalFunctions.sCompanyTax2Number));
                entReportParameters.Add(new atReportParameter("Tax3Number", GlobalFunctions.sCompanyTax3Number));

                if (blnPrintPreview)
                {
                    atACC.HTL.UI.atReportViewer rptV = new atACC.HTL.UI.atReportViewer();
                    rptV.frmReportBase = null;
                    if (!GlobalFunctions.GetANISettings((int)ENANISettings.ModernDashboard))
                    {
                        rptV.Show();
                    }
                    if (sExportFileName != "")
                    {
                        rptV.Hide();
                    }
                    rptV.Text = invoiceDesigner.TransactionTypeName;
                    rptV.ShowReport(sPrintFormat, ds, entReportParameters);
                    if (sExportFileName != "")
                    {
                        Byte[] mybytes = rptV.rptVwr.LocalReport.Render("PDF");
                        using (FileStream fs = File.Create(sExportFileName))
                        {
                            fs.Write(mybytes, 0, mybytes.Length);
                        }

                        rptV.Close();
                    }
                    if (sExportFileName == "" && GlobalFunctions.GetANISettings((int)ENANISettings.ModernDashboard))
                    {
                        atACC.HTL.UI.NewDash.CreateNewPage(rptV);
                    }

                }
                else
                {
                    if (GlobalFunctions.blnShowPrintDialog)
                    {
                        atReportViewer rptV = new atReportViewer();
                        rptV.blnFromTransactions = true;
                        rptV.frmReportBase = null;
                        rptV.Visible = false;
                        rptV._printersett = printersetting;

                        rptV.ShowReport(sPrintFormat, ds, entReportParameters);


                    }
                    else
                    {
                        if (atLocalSettings.Default.ReverseSkipLines > 0)
                        {
                            LinePrint linePrint = new LinePrint();
                            linePrint.ReversePrint(atLocalSettings.Default.ReverseSkipLines);
                        }
                        DirectReportPrint rdlprint = new DirectReportPrint();
                        rdlprint.PrintReport(sPrintFormat, printersetting, ds, entReportParameters);
                    }
                }
            }
            else if (invoiceDesigner.ReportType == (int)ENReportType.Dotmatrix)
            {

                LinePrint linePrint = new LinePrint();
                if (sTransactionType == MessageKeys.MsgSalesInvoice)
                {
                    linePrint.DotMatrixPrintSales(invoiceDesigner.PrinterName, iHdrid);
                    // linePrint.DotMatrixPrintSales2(invoiceDesigner.PrinterName, iHdrid);

                }
                else if (sTransactionType == MessageKeys.MsgPurchaseInvoice)
                {
                    linePrint.DotMatrixPrintPurchase(invoiceDesigner.PrinterName, iHdrid);
                }

                // Company company = new Company();
                // company = db.Companies.FirstOrDefault();
                // SalesHDR salesHDR = new SalesHDR();
                // salesHDR = db.SalesHDRs.Where(x => x.id ==iHdrid).FirstOrDefault();
                // Customer customer = new Customer();
                // AccountLedger accountLedger = new AccountLedger();
                // Party party = new Party();
                // PartyDTL partyDTL = new PartyDTL();
                // accountLedger = db.AccountLedgers.Where(x => x.id == salesHDR.FK_CashAccountID).FirstOrDefault();
                // party = db.Parties.Where(x => x.FK_Account == accountLedger.id).FirstOrDefault();
                // partyDTL = db.PartyDTLs.Where(x => x.FK_PartyID == party.id).FirstOrDefault();
                // customer.Id = party.id;
                // customer.Name = party.Name;
                // customer.Address1 = partyDTL.Address1;
                // customer.Address2 = partyDTL.Address2;
                // customer.Address3 = partyDTL.Address3;
                // customer.City = partyDTL.City;
                // customer.PostalCode = partyDTL.PostalCode;
                // customer.TelephoneNumber = partyDTL.TelephoneNumber;
                // customer.MobileNumber = partyDTL.MobileNumber;
                // customer.Email = partyDTL.Email;
                // customer.State = partyDTL.State;
                // customer.Country = partyDTL.Country;
                // customer.Tax1No = partyDTL.Tax1No;
                // customer.Tax2No = partyDTL.Tax2No;
                // customer.Tax3No = partyDTL.Tax3No;
                // List<SalesDTL> salesDTLs = new List<SalesDTL>();
                // salesDTLs = db.SalesDTLs.Where(x => x.FK_SalesHDRID == salesHDR.id).ToList();
                // List<SalesAdjustment> salesAdjustments = new List<SalesAdjustment>();
                // salesAdjustments = db.SalesAdjustments.Where(x => x.FK_SalesHDRID == salesHDR.id).ToList();

                //PrintSettings printSettings = new PrintSettings();
                //printSettings.MethodToPrint(invoiceDesigner.FormatPath, company, salesHDR, customer, salesDTLs.Cast<object>().ToList(), salesAdjustments.Cast<object>().ToList());
            }
            else if (invoiceDesigner.ReportType == (int)ENReportType.CrystalReport)
            {
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("HDRID", iHdrid));
                SqlHelper sqlh = new SqlHelper();
                ds = sqlh.ExecuteProcedure(sProcedureName, sqlParameters);
                System.Drawing.Printing.PrinterSettings printersetting = new System.Drawing.Printing.PrinterSettings();
                if (invoiceDesigner.PrinterName != null && invoiceDesigner.PrinterName.Trim() != "")
                {
                    printersetting.PrinterName = invoiceDesigner.PrinterName;

                }
                PrintCrystalReport(ds, printersetting, blnPrintPreview, invoiceDesigner.FormatPath, invoiceDesigner.TransactionTypeName);
            }
            return true;
        }
        public void PrintCrystalReport(DataSet _DataSource, PrinterSettings _printerSettings, bool blnPrintPreview, string sReportPath, string sCaption)
        {
            if (_DataSource == null) { throw new Exception(MessageKeys.MsgDataSourcePropertyCannotBeNull); }
            if (sReportPath == "") { throw new Exception(MessageKeys.MsgInvalidReportPath); }
            if (File.Exists(sReportPath) == false) { throw new Exception(MessageKeys.MsgReportFileNotFound); }
            ReportDocument rptdoc = new ReportDocument();
            //dtTables.WriteXml(Application.StartupPath + @"\Reports\" + sReportName + ".xml", XmlWriteMode.WriteSchema);
            rptdoc.Load(sReportPath);
            int i = 0;
            foreach (DataTable dt in _DataSource.Tables)    
            {
                rptdoc.Database.Tables[dt.TableName].SetDataSource(dt);
                i++;
            }

            rptdoc.VerifyDatabase();
            rptdoc.SetParameterValue("CompanyName", GlobalFunctions.sCompanyName);
            rptdoc.SetParameterValue("Address", GlobalFunctions.sCompanyAddress);
            rptdoc.SetParameterValue("Address2", GlobalFunctions.sCompanyAddress2);
            rptdoc.SetParameterValue("Address3", GlobalFunctions.sCompanyAddress3);
            rptdoc.SetParameterValue("City", GlobalFunctions.sCompanyCity);
            rptdoc.SetParameterValue("State", GlobalFunctions.sCompanyState);
            rptdoc.SetParameterValue("Country", GlobalFunctions.sCompanyCountry);
            rptdoc.SetParameterValue("PostalCode", GlobalFunctions.sCompanyPostalCode);
            rptdoc.SetParameterValue("Telephone", GlobalFunctions.sCompanyTelephone);
            rptdoc.SetParameterValue("Mobile", GlobalFunctions.sCompanyMobile);
            rptdoc.SetParameterValue("Fax", GlobalFunctions.sCompanyFax);
            rptdoc.SetParameterValue("Email", GlobalFunctions.sCompanyEmail);
            rptdoc.SetParameterValue("WebSite", GlobalFunctions.sCompanyWebSite);
            rptdoc.SetParameterValue("GSTNumber", GlobalFunctions.sCompanyGSTNumber);
            rptdoc.SetParameterValue("VATNumber", GlobalFunctions.sCompanyVATNumber);
            rptdoc.SetParameterValue("Tax1Number", GlobalFunctions.sCompanyTax1Number);
            rptdoc.SetParameterValue("Tax2Number", GlobalFunctions.sCompanyTax2Number);
            rptdoc.SetParameterValue("Tax3Number", GlobalFunctions.sCompanyTax3Number);
            if (blnPrintPreview)
            {
                frmreport _frmRpt = new frmreport();
                _frmRpt.Text = sCaption;
                _frmRpt.rptdoc = rptdoc;
                if (GlobalFunctions.GetANISettings((int)ENANISettings.ModernDashboard))
                {
                    atACC.HTL.UI.NewDash.CreateNewPage(_frmRpt);
                }
                else
                {
                    _frmRpt.ShowDialog();
                }
            }
            else
            {
                _printerSettings.DefaultPageSettings.Landscape = false;
                rptdoc.PrintToPrinter(_printerSettings, _printerSettings.DefaultPageSettings, false);


            }
        }
        private string setFormat(InvoiceDesigner invoiceDesigner, string sTransactionType, int iSaleOrPurchaseType, int _iformatid)
        {
            OpenFileDialog openDlg = new OpenFileDialog();
            openDlg.InitialDirectory = @"D:\";
            openDlg.Title = "Browse Report Files";
            openDlg.CheckFileExists = true;
            openDlg.CheckPathExists = true;
            openDlg.DefaultExt = "rdlc";
            openDlg.Filter = "rdlc files (*.rdlc)|*.rdlc";
            openDlg.FilterIndex = 2;
            openDlg.RestoreDirectory = true;
            openDlg.ReadOnlyChecked = true;
            openDlg.ShowReadOnly = true;
            if (openDlg.ShowDialog() == DialogResult.OK)
            {
                UpdatePrintFormat(invoiceDesigner, openDlg.FileName, sTransactionType, iSaleOrPurchaseType, _iformatid);
                return openDlg.FileName;
            }
            else
            {
                return "";
            }
        }
        private void UpdatePrintFormat(InvoiceDesigner _invoiceDesigner, string sFileName, string sTransactionType, int iSaleOrPurchaseType, int _iformatid)
        {
            InvoiceDesigner invoiceDesigner;
            if (_invoiceDesigner == null)  // in case of New Format
            {
                invoiceDesigner = new InvoiceDesigner();
                invoiceDesigner.id = getMax();
            }
            else
            {
                invoiceDesigner = _invoiceDesigner;
            }
            invoiceDesigner.TransactionTypeName = sTransactionType;
            invoiceDesigner.SalesOrPurchaseType = iSaleOrPurchaseType;
            invoiceDesigner.ReportType = 0;
            invoiceDesigner.FormatPath = sFileName;
            invoiceDesigner.FormatID = _iformatid;
            invoiceDesigner.DbName = GlobalFunctions.DatabaseName;
            if (invoiceDesigner.PrinterName == null) // Set Default Printer Name in Case of Printer Name is null
            {
                PrinterSettings printerName = new PrinterSettings();
                invoiceDesigner.PrinterName = printerName.PrinterName;
            }
            if (_invoiceDesigner == null)  // in case of New Format
            {
                sdb.InvoiceDesigners.AddObject(invoiceDesigner);
            }
            else
            {
                sdb.ObjectStateManager.ChangeObjectState(invoiceDesigner, EntityState.Modified);
            }

            sdb.SaveChanges();


        }
        private int getMax()
        {
            int iMax = 0;
            if (sdb.InvoiceDesigners.ToList().Count > 0)
            {
                iMax = sdb.InvoiceDesigners.Max(x => x.id);
            }
            return iMax + 1;
        }
        private string GetProcedureName(string sTransactionTypeName)
        {
            InvoiceDesignForm designForm = db.InvoiceDesignForms.Where(x => x.TransactionName == sTransactionTypeName).SingleOrDefault();
            return designForm.ProcedureName;

        }
        private InvoiceDesigner GetCurrentFileFormat(string sTransactionTypeName, int iSaleOrPurchaseType, int _iFormatID)
        {
            return sdb.InvoiceDesigners.Where(x => (x.TransactionTypeName == sTransactionTypeName && x.SalesOrPurchaseType == iSaleOrPurchaseType
                && x.FormatID == _iFormatID
                && x.DbName == GlobalFunctions.DatabaseName
                )).Select(x => x).FirstOrDefault();
            //return sdb.InvoiceDesigners.Where(x => (x.TransactionTypeName == sTransactionTypeName && x.SalesOrPurchaseType == iSaleOrPurchaseType && x.ReportType == 0)).Select(x => x).SingleOrDefault();
        }
        private int HaveMultipleFormat(string sTransactionTypeName, int iSaleOrPurchaseType)
        {
            return sdb.InvoiceDesigners.Where(x => (x.TransactionTypeName == sTransactionTypeName && x.SalesOrPurchaseType == iSaleOrPurchaseType
               )).Select(x => x.id).Count();

        }

    }
}
