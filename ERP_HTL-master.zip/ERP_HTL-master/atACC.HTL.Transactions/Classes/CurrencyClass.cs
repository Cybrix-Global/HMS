﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.Transactions
{
    public class CurrencyClass
    {
        private int _id;

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _CurrencyName;

        public string CurrencyName
        {
            get { return _CurrencyName; }
            set { _CurrencyName = value; }
        }

    }
}
