﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;

namespace atACC.HTL.Transactions
{
    public static class atExtension
    {
        public static bool IsActiveControl(this SearchFormBase2 searchFormBase, object obj, bool blnCheckParent = false)
        {
            if(blnCheckParent)
                return searchFormBase.ActiveControl != null && searchFormBase.ActiveControl.Name == ((Control)obj).Parent.Name;
            else
                return searchFormBase.ActiveControl != null && searchFormBase.ActiveControl.Name == ((Control)obj).Name;
        }
    }
}
