﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Data;

namespace atACC.HTL.Transactions
{
    public class AccountLabel : LinkLabel
    {
        #region Constructor

        public AccountLabel()
        {
            //this.DisabledLinkColor = System.Drawing.Color.Red;
            //this.VisitedLinkColor = System.Drawing.Color.Blue;
            this.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.LinkColor = System.Drawing.Color.Black;
            this.ForeColor = Color.Black;
        }
        #endregion
        
        #region Public Properties
        public string Format { get; set; }
        public DataTable DataSource { get; set; }
        public decimal TotalAmount
        {
            get
            {
                return DataSource.AsEnumerable().Sum(x => x.Field<decimal>("Amount"));
            }
        }
        #endregion

        #region Overide Method
        protected override void InitLayout()
        {
            base.InitLayout();
        }
        protected override void OnLinkClicked(LinkLabelLinkClickedEventArgs e)
        {
            base.OnLinkClicked(e);
            using (AccountBalanceDetailsView view = new AccountBalanceDetailsView(DataSource, Format))
            {
                view.ShowDialog();
            }
        }
        #endregion       


    }
}
