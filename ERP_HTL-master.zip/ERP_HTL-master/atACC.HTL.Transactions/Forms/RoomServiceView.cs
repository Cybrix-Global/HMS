﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using System.Data.SqlClient;
using atACCFramework.UserControls;
using atACC.HTL.Transactions.Sub_Forms;
using System.Drawing;

namespace atACC.HTL.Transactions
{
    public partial class RoomServiceView : SearchFormBase2
    {
        #region Private Variable
        RoomServiceHDR entRoomServiceHDR;
        List<RoomServiceHDR> entRoomServiceList;
        List<RoomServiceDTL> entOldRoomServiceDTLList;
        List<RoomServiceDTL> entRoomServiceDTLList;
        List<RoomServicePayment> entRoomServicePaymentList;
        List<RoomServicePayment> entOldRoomServicePaymentList;
        RoomServiceDTL entRoomServiceDTL;
        GuestDTLs e_GuestDTLs;
        Guests entGuest;
        List<Guests> entGuestlist;
        atACC.HTL.ORM.AccountLedger Ledger;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        DataTable dt = new DataTable();
        CommonLibClasses objLib;
        ToolTip tooltip;
        List<Employee> entEmployee;
        List<atACC.HTL.ORM.AccountLedger> entGuestAccounts;
        DataGridViewTextBoxEditingControl textbox;
        DataGridViewComboBoxEditingControl cb;
        string sKeyChar = "";
        string NumberFormat, sQtyFormat;
        int iGuestID, _OnLoad, iContentId;
        decimal TotalAmount, Total, AdvanceAmount;
        int _SelectedRoomID;
        VoucherHDR entVoucherHdrPayment;
        VoucherHDR entVoucherHdr;
        decimal previousExRate;
        List<CurrencyClass> entCurrencys;
        bool blnSanctioningRequired = false;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;
        #endregion

        #region Constructor
        public RoomServiceView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            objLib = new CommonLibClasses();
            aniHelper = new ANIHelper();
            ShareButton.Visible = false;
        }
        public RoomServiceView(int selectedRoomID) : this()
        {
            _SelectedRoomID = selectedRoomID;
        }
        #endregion

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(9);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Private Methods
        private bool IsExtraSericeChanged()
        {
            if (dgDetails.CurrentCell != null && dgDetails.CurrentCell.Tag != null && dgDetails.CurrentCell.Value != null)
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name)
                    return dgDetails.CurrentCell.Value.ToString2() != dgDetails.CurrentCell.Tag.ToString2();
            }
            return false;
        }
        private void CalculateSlab(bool blnUpdateDeductionAmount, RoomServiceDTL pdtl)
        {
            try
            {
                if (pdtl != null)
                {
                    List<Slab> slabs = null;
                    if (IsExtraSericeChanged())
                    {
                        int iServiceID = pdtl.FK_ServiceID.ToInt32();
                        slabs = (from rs in dbh.ExtraServiceSlabs
                                 join s in dbh.Slabs on rs.FK_SlabID equals s.id
                                 where rs.FK_ExtraServiceID == iServiceID
                                 select s).ToList();
                    }
                    pdtl.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }        
        private void ApplyExRate()
        {
            decimal dcCurrentExRate = txtExRate.Value;
            decimal dcExRateChange = ((previousExRate == 0 ? 1 : previousExRate) / (dcCurrentExRate == 0 ? 1 : dcCurrentExRate));
            foreach (RoomServiceDTL serviceDtl in entRoomServiceDTLList)
            {
                if (serviceDtl.FK_ServiceID != null)
                {
                    serviceDtl.Rate = dcExRateChange * serviceDtl.Rate;
                    serviceDtl.InclusiveRate = dcExRateChange * serviceDtl.InclusiveRate;
                    serviceDtl.Amount = dcExRateChange * serviceDtl.Amount;                    
                    serviceDtl.TaxableAmount = dcExRateChange * serviceDtl.TaxableAmount;
                    serviceDtl.SlabDiscount = dcExRateChange * serviceDtl.SlabDiscount;
                    serviceDtl.DeductionAmount = dcExRateChange * serviceDtl.DeductionAmount;
                    serviceDtl.ExciseAmount = dcExRateChange * serviceDtl.ExciseAmount;
                    serviceDtl.Tax1Amount = dcExRateChange * serviceDtl.Tax1Amount;
                    serviceDtl.Tax2Amount = dcExRateChange * serviceDtl.Tax2Amount;
                    serviceDtl.Tax3Amount = dcExRateChange * serviceDtl.Tax3Amount;
                    serviceDtl.AddnlTaxAmount = dcExRateChange * serviceDtl.AddnlTaxAmount;
                    serviceDtl.VATAmount = dcExRateChange * serviceDtl.VATAmount;
                    serviceDtl.CGSTAmount = dcExRateChange * serviceDtl.CGSTAmount;
                    serviceDtl.SGSTAmount = dcExRateChange * serviceDtl.SGSTAmount;
                    serviceDtl.IGSTAmount = dcExRateChange * serviceDtl.IGSTAmount;
                    serviceDtl.NetAmount = dcExRateChange * serviceDtl.NetAmount;
                }
            }

            foreach (RoomServicePayment payment in entRoomServicePaymentList)
            {
                payment.Payment = dcExRateChange * payment.Payment;
            }

            CalcNetTotal();
            previousExRate = txtExRate.Value;
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_RoomService, 0, 0, txtVoucherNo.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateSelectedRoom()
        {
            if (_SelectedRoomID > 0)
            {
                Rooms room = dbh.Rooms.Where(x => x.id == _SelectedRoomID).SingleOrDefault();
                if (room != null)
                {
                    cmbRoom.SelectedValue = room.id;
                }
            }
        }
        private void PopulateRoomServiceEnt()
        {
            entRoomServiceList = dbh.RoomServiceHDRs.ToList();
        }
        private void PopulateCombos()
        {
            try
            {
                cmbEmployee.DataSource = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.ServiceMan || x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }

                //cmbVoucherDiscount.DataSource = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterValues.dis).ToList();
                //cmbVoucherDiscount.DisplayMember = "Name";
                //cmbVoucherDiscount.ValueMember = "id";
                //cmbVoucherDiscount.SelectedIndex = -1;

                cmbRoom.DataSource = dbh.Rooms.Where(x => x.IsHall == false).ToList();
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
                cmbRoom.SelectedIndex = -1;

                #region Currency                
                cmbCurrency.DataSource = entCurrencys;
                cmbCurrency.DisplayMember = "CurrencyName";
                cmbCurrency.ValueMember = "id";
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void FnClearAll()
        {
            entRoomServiceHDR = new RoomServiceHDR();
            entRoomServiceDTLList = new List<RoomServiceDTL>();
            entOldRoomServiceDTLList = new List<RoomServiceDTL>();

            entRoomServicePaymentList = new List<RoomServicePayment>();
            entOldRoomServicePaymentList = new List<RoomServicePayment>();

        }
        private void PopulateGuest()
        {
            int iFlagId = 1, iRoomId = 0, iGuest = 0;
            DateTime iDate = dtVoucherDate.Value;

            SqlHelper _sql = new SqlHelper();
            iRoomId = cmbRoom.SelectedValue.ToInt32();
            _sql.SPName = "SPGetGuestInfo";
            SqlParameter paramFlag = new SqlParameter("Flag", iFlagId);
            SqlParameter paramFlag2 = new SqlParameter("RoomId", iRoomId);
            SqlParameter paramFlag3 = new SqlParameter("VoucherDate", iDate);

            _sql.SqlParameters = new List<SqlParameter>();
            _sql.SqlParameters.Add(paramFlag);
            _sql.SqlParameters.Add(paramFlag2);
            _sql.SqlParameters.Add(paramFlag3);

            dt = _sql.ExecuteProcedure().Tables[0];
            
            cmbGuest.DataSource = dt;
            cmbGuest.DisplayMember = "Name";
            cmbGuest.ValueMember = "id";

            cmbGuest.SelectedIndex = -1;
            ClearGuestInfo();
            if (dt.Rows.Count == 1)
            {
                cmbGuest.SelectedIndex = 0;
            }
            if (dt.Rows.Count == 0)
            {
                cmbGuest.SelectedIndex = -1;
                cmbGuest.Text = "";
            }
            LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
        }
        private void SetDefaultComboValues()
        {
            ActiveControl = cmbCurrency;
            cmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;
        }
        private void CalcGrandTotal()
        {
            lblGrandTotal.Value = txtNetTotal.Value;
            txtBalance.Value = lblGrandTotal.Value - txtPayment.Value;
        }
        private bool ValidateRoomRate()
        {
            try
            {
                if (cmbGuest.Text.Trim() == "") { errProvider.SetError(cmbGuest, "Choose Guest"); cmbGuest.Focus(); return false; }
                if (cmbRoom.Text.Trim() == "") { errProvider.SetError(cmbRoom, "Choose Room "); cmbRoom.Focus(); return false; }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void CalcNetTotal()
        {
            txtGross.Value = entRoomServiceDTLList.Sum(x => x.Amount).ToDecimal();
            lblTotQty.Value = entRoomServiceDTLList.Sum(x => x.Qty).ToDecimal();
            txtTotalDiscount.Value = entRoomServiceDTLList.Sum(x => x.TotalDiscount).ToDecimal();
            lblTotalTax.lblTax1 = entRoomServiceDTLList.Sum(x => x.Tax1Amount).ToDecimal();
            lblTotalTax.lblTax2 = entRoomServiceDTLList.Sum(x => x.Tax2Amount).ToDecimal();
            lblTotalTax.lblTax3 = entRoomServiceDTLList.Sum(x => x.Tax3Amount).ToDecimal();
            lblTotalTax.lblAddnlTax = entRoomServiceDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
            lblTotalTax.lblExciseDuty = entRoomServiceDTLList.Sum(x => x.ExciseAmount).ToDecimal();
            lblTotalTax.lblVAT = entRoomServiceDTLList.Sum(x => x.VATAmount).ToDecimal();
            lblTotalTax.lblCGST = entRoomServiceDTLList.Sum(x => x.CGSTAmount).ToDecimal();
            lblTotalTax.lblSGST = entRoomServiceDTLList.Sum(x => x.SGSTAmount).ToDecimal();
            lblTotalTax.lblIGST = entRoomServiceDTLList.Sum(x => x.IGSTAmount).ToDecimal();
            txtTotalTax.Value = entRoomServiceDTLList.Sum(x => x.TotalTax).ToDecimal();
            txtNetTotal.Value = (txtGross.Value + txtTotalTax.Value) - txtTotalDiscount.Value;

            CalcGrandTotal();
        }
        private void ShowToolTip()
        {

            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbGuest, "Select Guest");
                tooltip.SetToolTip(cmbRoom, "Select Room ");
                tooltip.SetToolTip(cmbEmployee, "Select Employee ");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadDefaultSettings()
        {
            dbh = atHotelContext.CreateContext();
            Company company = dbh.Companies.Single();

        }
        private void InitEntities()
        {                        
            entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).ToList();
        }
        private void InitControls()
        {
            dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
            dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();

            dtpArrivalDate.SetCustomFormat();
            dtpDepartureDate.SetCustomFormat();
            dtpArrivalDate.DisbaleShortDateTimeFormat = true;
            dtpDepartureDate.DisbaleShortDateTimeFormat = true;
        }
        private void PostVoucher()
        {
            bool blnNewRecord = true;
            bool blnNewPaymentRecord = true;           
            entVoucherHdrPayment = new VoucherHDR();            
            entVoucherHdr = new VoucherHDR();
            if (!NewRecord)
            {
                if ((entRoomServiceHDR.FK_VoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdr = dbh.VoucherHDRs.Where(x => x.id == entRoomServiceHDR.FK_VoucherHDRID).SingleOrDefault();
                    blnNewRecord = false;
                }
                if ((entRoomServiceHDR.FK_PaymentVoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdrPayment = dbh.VoucherHDRs.Where(x => x.id == entRoomServiceHDR.FK_PaymentVoucherHDRID).SingleOrDefault();
                    blnNewPaymentRecord = false;
                }                
            }
            int iCashorPartyAccountID = cmbGuest.Tag.ToInt32();
            bool blnPartyUnderCashInHand = aniHelper.isUnderCashInHand(iCashorPartyAccountID);
            string sCashorPartyName = aniHelper.getLedNameFromAccountID(iCashorPartyAccountID);
            string sRoomServAccountName = aniHelper.getLedNameFromAccountID(GlobalProperties.ExtraServicesAccountID);

            decimal dcmGrandTotal = txtNetTotal.Value;
            decimal dcExRate = txtExRate.Value;
            decimal dcmOtherPaymentSum = entRoomServicePaymentList.Where(x => x.isCash == false).Sum(x => x.Payment).ToDecimal();
            decimal dcmPartyAmount = blnPartyUnderCashInHand ? dcmGrandTotal - dcmOtherPaymentSum : dcmGrandTotal;

            //Voucher Hdr Entry
            GlobalMethods.DecorateVoucherHdr(entVoucherHdr, iContextID, "", dtVoucherDate.Value
                , cmbCurrency.SelectedValue.ToString().ToInt32(), lblGrandTotal.Value, txtVoucherNo.Text, "H-RSRV");

            //Voucher DTL Entry
            List<VoucherDTL> entVoucherDtls = new List<VoucherDTL>();

            // Debit Bill Amount to Party or Cash Account
            GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, iCashorPartyAccountID, sRoomServAccountName, dcExRate, dcmPartyAmount, "", txtRemarks.Text);
            #region ExtraService Voucher DTL
            if (entRoomServiceDTLList.Count > 0)
            {
                decimal dcGross = entRoomServiceDTLList.Sum(x => x.Amount).ToDecimal();
                decimal dcDiscount = entRoomServiceDTLList.Sum(x => x.DeductionAmount + x.SlabDiscount).ToDecimal();
                decimal dcTax1 = entRoomServiceDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                decimal dcTax2 = entRoomServiceDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                decimal dcTax3 = entRoomServiceDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                decimal dcAddnlTax = entRoomServiceDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                decimal dcExciseDuty = entRoomServiceDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                decimal dcVAT = entRoomServiceDTLList.Sum(x => x.VATAmount).ToDecimal();
                decimal dcCGST = entRoomServiceDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                decimal dcSGST = entRoomServiceDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                decimal dcIGST = entRoomServiceDTLList.Sum(x => x.IGSTAmount).ToDecimal();

                //Credit Gross Amount to ExtraService Account
                if (dcGross != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExtraServicesAccountID, sCashorPartyName, dcExRate, dcGross * (-1), "", txtRemarks.Text);
                //Credit Tax1 
                if (dcTax1 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax1AccountID, sCashorPartyName, dcExRate, dcTax1 * (-1), "", txtRemarks.Text);
                //Credit Tax2
                if (dcTax2 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax2AccountID, sCashorPartyName, dcExRate, dcTax2 * (-1), "", txtRemarks.Text);
                //Credit Tax3
                if (dcTax3 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax3AccountID, sCashorPartyName, dcExRate, dcTax3 * (-1), "", txtRemarks.Text);
                //Credit Excise Duty
                if (dcExciseDuty != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExciseDutyAccountID, sCashorPartyName, dcExRate, dcExciseDuty * (-1), "", txtRemarks.Text);
                //Debit Total Discount 
                if (txtTotalDiscount.Value != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.DiscountAccountID, sCashorPartyName, dcExRate, txtTotalDiscount.Value, "", txtRemarks.Text);
                //Credit Vat
                if (dcVAT != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.VATAccountID, sCashorPartyName, dcExRate, dcVAT * (-1), "", txtRemarks.Text);
                //Credit CGST
                if (dcCGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.CGSTAccountID, sCashorPartyName, dcExRate, dcCGST * (-1), "", txtRemarks.Text);
                //Credit SGST
                if (dcSGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.SGSTAccountID, sCashorPartyName, dcExRate, dcSGST * (-1), "", txtRemarks.Text);
                //Credit IGST
                if (dcIGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.IGSTAccountID, sCashorPartyName, dcExRate, dcIGST * (-1), "", txtRemarks.Text);
                //Credit
                if (dcAddnlTax != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.AdditionalTaxAccountID, sCashorPartyName, dcExRate, dcAddnlTax * (-1), "", txtRemarks.Text);
            }
            #endregion
            List<AnalysisDTL> entAnalysisDTLs = new List<AnalysisDTL>();
            GlobalMethods.PostVoucher(blnNewRecord, entVoucherHdr, entVoucherDtls, ref dbh, entAnalysisDTLs);




            #region Payment Posting

            List<VoucherDTL> entVoucherDtlsPayment = new List<VoucherDTL>();
            if (entRoomServicePaymentList.Count() > 0) // Payment Found
            {
                if (entVoucherHdrPayment.id == 0)
                {
                    entVoucherHdrPayment.id = -1;
                }
                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdrPayment, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-RSRV-PAY");

                foreach (RoomServicePayment payment in entRoomServicePaymentList)
                {
                    #region isCash
                    if (payment.isCash.toBool()) // Cash Payment
                    {
                        if (!blnPartyUnderCashInHand)
                        {
                            int iCashAccountID = payment.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)payment.FK_AccountID;
                            string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                            // Debit to Cash Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashAccountID, sCashorPartyName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            // Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", MessageKeys.MsgPayment);
                        }
                    }
                    #endregion
                    #region Non Cash
                    else
                    {
                        int iSelectedBankAccount = (int)payment.FK_AccountID;
                        string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                        if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                        {
                            string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);

                            // Debit to Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sRoomServAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", MessageKeys.MsgPayment);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                        {
                            string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);

                            //Debit to Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sRoomServAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                            || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                        {
                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCashorPartyName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                    }
                    #endregion
                }
                GlobalMethods.PostVoucher(blnNewPaymentRecord, entVoucherHdrPayment, entVoucherDtlsPayment, ref dbh, entAnalysisDTLs);
            }
            #endregion

           

        }
        private void LoadSettings()
        {
            NumberFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimals;
            sQtyFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimalsQty;
            txtVoucherDiscAmount.Format = NumberFormat;
            txtGross.Format = NumberFormat;
            lblTotQty.Format = sQtyFormat;

            txtNetTotal.Format = NumberFormat;
            txtPayment.Format = NumberFormat;
            txtGross.Format = NumberFormat;

            txtBalance.Format = NumberFormat;
            lblGrandTotal.Format = NumberFormat;
            txtExRate.Format = NumberFormat;
            lblTotalTax.Format = NumberFormat;
            txtDeductionPerc.Format = NumberFormat;


            grpDiscountVoucher.Visible = GlobalFunctions.blnDiscountVoucherInSalesTransactions;

            lblCurrencyCap.Visible = GlobalFunctions.blnMultiCurrency;
            cmbCurrency.Visible = GlobalFunctions.blnMultiCurrency;
            lblExRateCap.Visible = GlobalFunctions.blnMultiCurrency;
            txtExRate.Visible = GlobalFunctions.blnMultiCurrency;
        }
        private void CalcPaymentTotal()
        {
            txtPayment.Value = entRoomServicePaymentList.Sum(x => x.Payment).ToDecimal();
            txtBalance.Value = txtNetTotal.Value - txtPayment.Value;
        }
        private void fillServiceByCodeInCurrentRow()
        {
            int _ServiceID = 0;
            if (dgDetails.CurrentCell.Value == null) { return; }
            string sCode = dgDetails.CurrentCell.Value.ToString();
            if (dbh.ExtraServices.Any(x => x.Code == sCode))
            {
                _ServiceID = dbh.ExtraServices.Where(x => x.Code == textbox.Text).First().id;
                fillService(_ServiceID);

            }
            else
            {
                dgDetails.CurrentCell.Value = "";
                if (dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value == null) { return; }
                _ServiceID = dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value.ToString().ToInt32();
                fillService(_ServiceID);
            }
        }
        private void CalcRowAmount(RoomServiceDTL pdtl)
        {            
            if (pdtl != null)
            {
                pdtl.Amount = pdtl.Rate * pdtl.Qty;
                bool blnUpdateDeductionAmount = dgDetails.CurrentCell.OwningColumn.Name != col_DeductionAmount.Name;
                CalculateSlab(blnUpdateDeductionAmount, pdtl);
                CalcNetTotal();
            }
        }
        private void CalcGrand(bool blnUpdateAddDiscAmount = true)
        {
            if (entRoomServiceDTLList.Count > 0)
            {
                txtGross.Value = entRoomServiceDTLList.Sum(x => x.Amount).ToDecimal();
                lblTotQty.Value = entRoomServiceDTLList.Sum(x => x.Qty).ToDecimal();
                txtNetTotal.Value = txtGross.Value - txtVoucherDiscAmount.Value;
                lblGrandTotal.Value = entRoomServiceDTLList.Sum(x => x.NetAmount).ToDecimal();
                if (GlobalFunctions.strRoundoffPurchases != "")
                {
                    decimal dcBeforeRoundOff = lblGrandTotal.Value;
                    lblGrandTotal.Value = Math2.Round(lblGrandTotal.Value, GlobalFunctions.strRoundoffPurchases.ToInt32());
                }
            }
        }
        private void ClearGuestInfo()
        {

            txtMobile.Text = "";
            txtAdd1.Text = "";
            txtDeductionPerc.Text = "";
            dtpArrivalDate.Value = System.DateTime.Now;
            dtpDepartureDate.Value = System.DateTime.Now;
            entGuest = new Guests();
            e_GuestDTLs = new GuestDTLs();
            cmbGuest.Tag = null;
            DefaultCreditCard = 0;
            DefaultCreditCardNumber = "";
        }
        private void LoadGuestInfo(Int64 Guestid)
        {
            try
            {
                if (dt.Rows.Count > 0)
                {
                    DataView dv = new DataView(dt, "id='" + Guestid + "'", "id", DataViewRowState.OriginalRows);
                    if (dv.ToTable().Rows.Count > 0)
                    {
                        entGuest = dbh.Guests.Where(x => x.id == Guestid).SingleOrDefault();
                        e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == Guestid).SingleOrDefault();
                        txtMobile.Text = dv.ToTable().Rows[0]["Mobile"].ToString();
                        txtAdd1.Text = dv.ToTable().Rows[0]["Address1"].ToString();
                        dtpArrivalDate.Text = dv.ToTable().Rows[0]["ArrivalDate"].ToString();
                        dtpDepartureDate.Text = dv.ToTable().Rows[0]["DepartureDate"].ToString();
                        cmbGuest.Tag = dv.ToTable().Rows[0]["FK_BillingAccountID"].ToInt32();
                        if (entGuest != null && NewRecord)
                        {
                            txtDeductionPerc.Value = dv.ToTable().Rows[0]["DiscountPerc"].ToString().ToDecimal();
                            cmbCurrency.SelectedValue = entGuest.FK_CurrencyHDRID.ToInt32();
                        }
                        if (e_GuestDTLs != null)
                        {
                            DefaultCreditCard = e_GuestDTLs.FK_CreditCardType.ToInt32();
                            DefaultCreditCardNumber = e_GuestDTLs.CreditCardNo;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void SetDefaultDateAndTime()
        {
            try
            {
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Public Methods
        public override void LoadVouchers()
        {
            string sTempVno = txtVoucherNo.Text;
            dbh = atHotelContext.CreateContext();
            List<UpDownData> _Vouchers = dbh.RoomServiceHDRs.OrderByDescending(x => x.id)
                .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
            txtVoucherNo.Items.Clear();
            txtVoucherNo.DataSource = _Vouchers;
            if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
            txtVoucherNo.Text = sTempVno;
        }
        public override void ReLoadData(string VoucherNo)
        {
            RoomServiceHDR roomServiceHDR = dbh.RoomServiceHDRs.Where(x => x.VoucherNo == VoucherNo && 
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (roomServiceHDR != null)
            {
                ReLoadData(roomServiceHDR.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
    
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                #region Room Service Data
                entRoomServiceHDR = dbh.RoomServiceHDRs.Where(x => x.id == ID).SingleOrDefault();
                if (entRoomServiceHDR != null)
                {

                    txtVoucherNo.Text = entRoomServiceHDR.VoucherNo;
                    dtVoucherDate.Text = entRoomServiceHDR.VoucherDate.ToString();
                    cmbRoom.SelectedValue = entRoomServiceHDR.FK_RoomID;

                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = entRoomServiceHDR.FK_GuestID;                    

                    txtPayment.Text = entRoomServiceHDR.Payment.ToString();
                    lblGrandTotal.Value = entRoomServiceHDR.GrandTotal.ToDecimal();
                    if (entRoomServiceHDR.FK_EmployeeID != null)
                    {
                        cmbEmployee.SelectedValue = entRoomServiceHDR.FK_EmployeeID;
                    }
                    txtRemarks.Text = entRoomServiceHDR.Remarks;
                    txtVoucherDiscAmount.Value = entRoomServiceHDR.VoucherDiscountAmount.ToDecimal();
                    cmbVoucherDiscount.SelectedValue = entRoomServiceHDR.FK_VoucherDiscountID;
                    cmbCurrency.SelectedValue = entRoomServiceHDR.FK_CurrencyHdrID;
                    txtExRate.Value = entRoomServiceHDR.ExRate.ToDecimal();
                    #endregion
                    #region Reload Extra Service Details


                    var CurrentDtl = (from pdtl in dbh.RoomServiceDTLs
                                      join prd in dbh.ExtraServices on pdtl.FK_ServiceID equals prd.id
                                      where pdtl.FK_RoomServiceID == ID
                                      select new { pdtl, prd }).ToList();
                    CurrentDtl.ForEach(x =>
                    {
                        x.pdtl.ServiceCode = x.prd.Code;
                        x.pdtl.ServiceName = x.prd.Name;
                    });
                    entRoomServiceDTLList = CurrentDtl.Select(x => x.pdtl).OrderBy(x => x.id).ToList();
                    entOldRoomServiceDTLList = new List<RoomServiceDTL>(entRoomServiceDTLList);
                    #endregion
                    #region Reload Payment Details
                    entRoomServicePaymentList = dbh.RoomServicePayments.Where(x => x.FK_RoomServiceID == entRoomServiceHDR.id).ToList();
                    entOldRoomServicePaymentList = new List<RoomServicePayment>(entRoomServicePaymentList);
                    #endregion
                    BindGrid();
                    LoadFullSerialNo();
                    CalcNetTotal();
                    CalcPaymentTotal();
                    CalcGrandTotal();


                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region GridMethods
        private void LoadCurrentSerialNo()
        {
            if (dgDetails.CurrentRow == null) { return; }
            dgDetails.CurrentRow.Cells[col_slno.Name].Value = dgDetails.CurrentRow.Cells[col_slno.Name].RowIndex + 1;
        }
        private void LoadFullSerialNo()
        {
            int i = 1;
            foreach (DataGridViewRow row in dgDetails.Rows)
            {
                row.Cells[col_slno.Name].Value = i;
                i = i + 1;
            }

        }
        private RoomServiceDTL getCurrent()
        {
            try
            {

                if (dgDetails.CurrentRow != null)
                {
                    RoomServiceDTL RoomServiceDTL = (RoomServiceDTL)dgDetails.CurrentRow.DataBoundItem;
                    return RoomServiceDTL;
                }
                else
                {
                    return null;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void BindGrid()
        {
            try
            {
                dgDetails.AutoGenerateColumns = false;                
                bindRoomServiceDTL.DataSource = null;
                bindRoomServiceDTL.DataSource = entRoomServiceDTLList;
                dgDetails.DataSource = bindRoomServiceDTL;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void initGridColumns()
        {
            try
            {
                entRoomServiceDTLList = dbh.RoomServiceDTLs.Where("1=2").ToList();
             
                col_SlabDiscount.Visible = GlobalFunctions.blnSlabDiscountinService;
                col_SlabDiscountPerc.Visible = GlobalFunctions.blnSlabDiscountinService;
              
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
                col_ExciseAmount.Visible = GlobalFunctions.blnExciseDutyInService;
        
                col_VATAmount.Visible = GlobalFunctions.blnVATinService;
                col_VATPerc.Visible = GlobalFunctions.blnVATinService;
                col_Tax1Amount.Visible = GlobalFunctions.blnTAX1inService;
                col_Tax1Perc.Visible = GlobalFunctions.blnTAX1inService;
              
                col_Tax2Amount.Visible = GlobalFunctions.blnTAX2inService;
                col_Tax2Perc.Visible = GlobalFunctions.blnTAX2inService;
        
                col_Tax3Amount.Visible = GlobalFunctions.blnTAX3inService;
                col_Tax3Perc.Visible = GlobalFunctions.blnTAX3inService;
               
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
             
                col_Tax1Amount.HeaderText = GlobalFunctions.Tax1Caption + " " + MessageKeys.MsgAmount;
                col_Tax2Amount.HeaderText = GlobalFunctions.Tax2Caption + " " + MessageKeys.MsgAmount;
                col_Tax3Amount.HeaderText = GlobalFunctions.Tax3Caption + " " + MessageKeys.MsgAmount;
                col_Tax1Perc.HeaderText = GlobalFunctions.Tax1Caption + " %";
                col_Tax2Perc.HeaderText = GlobalFunctions.Tax2Caption + " %";
                col_Tax3Perc.HeaderText = GlobalFunctions.Tax3Caption + " %";

                col_InclusiveRate.Visible = GlobalFunctions.blnInclusiveRateInPurchase;

                if (GlobalFunctions.blnGSTinService)
                {
                    col_SGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_SGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_IGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_IGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_CGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                    col_CGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                }
                else
                {
                    col_SGSTAmount.Visible = false;
                    col_SGSTPerc.Visible = false;
                    col_IGSTAmount.Visible = false;
                    col_IGSTPerc.Visible = false;
                    col_CGSTAmount.Visible = false;
                    col_CGSTPerc.Visible = false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void ApplyGridStyles()
        {
            try
            {
                col_Qty.DefaultCellStyle.Format = NumberFormat;
                col_Rate.DefaultCellStyle.Format = NumberFormat;
                col_Amount.DefaultCellStyle.Format = NumberFormat;
                col_DeductionPerc.DefaultCellStyle.Format = NumberFormat;
                col_DeductionAmount.DefaultCellStyle.Format = NumberFormat;
                col_TotalTax.DefaultCellStyle.Format = NumberFormat;
                col_NetAmount.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscountPerc.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TotalDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TaxableAmount.DefaultCellStyle.Format = NumberFormat;
                col_CGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_CGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_SGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_SGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_IGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_IGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_VATPerc.DefaultCellStyle.Format = NumberFormat;
                col_VATAmount.DefaultCellStyle.Format = NumberFormat;
                col_ExcisePerc.DefaultCellStyle.Format = NumberFormat;
                col_ExciseAmount.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Amount.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxPerc.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxAmount.DefaultCellStyle.Format = NumberFormat;
                col_InclusiveRate.DefaultCellStyle.Format = NumberFormat;
                lblTotQty.Format = sQtyFormat;
                lblGrandTotal.Format = NumberFormat;
            }
            catch (Exception)
            {

                throw;
            }

        }
        private void fillService(int _ServiceID)
        {
            if (txtExRate.Value == 0) { return; }
            RoomServiceDTL cesd = getCurrent();
            if (cesd != null)
            {
                ExtraServices service = dbh.ExtraServices.Where(x => x.id == _ServiceID).Single();
                dgDetails.CurrentRow.Cells[col_Service.Name].Value = service.Name.ToString();
                dgDetails.CurrentRow.Cells[col_Code.Name].Value = service.Code.ToString();
                cesd.FK_ServiceID = _ServiceID;
                cesd.Rate = service.Rate / txtExRate.Value;
                cesd.InclusiveRate = cesd.Rate;
                cesd.DeductionPerc = txtDeductionPerc.Value;
                dgDetails.CurrentCell = MoveForward(dgDetails.CurrentCell);
            }
        }
        private DataGridViewCell MoveForward(DataGridViewCell _currentCell)
        {
            int row_index = _currentCell.OwningRow.Index;
            int col_index = _currentCell.OwningColumn.Index;
            DataGridViewCell cell = dgDetails.Rows[row_index].Cells[col_index + 1];
            if (cell.Visible && cell.ReadOnly == false)
            {
                return cell;
            }
            else
            {
                return MoveForward(cell);
            }
        }

        #endregion

        #region Grid Events
        private void dgDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            dgDetails.CurrentCell.Tag = dgDetails.CurrentCell.Value ?? string.Empty;
        }
        private void dgDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (e.Control is DataGridViewComboBoxEditingControl)
                {
                    cb = (DataGridViewComboBoxEditingControl)e.Control;
                    if (cb != null)
                    {
                        cb.DropDownStyle = ComboBoxStyle.DropDown;
                        cb.AutoCompleteMode = AutoCompleteMode.Suggest;
                        cb.Validating -= new CancelEventHandler(cb_Validating);
                        cb.Validating += new CancelEventHandler(cb_Validating);
                        cb.KeyDown -= new KeyEventHandler(cb_KeyDown);
                        cb.KeyDown += new KeyEventHandler(cb_KeyDown);
                        cb.Focus();
                    }
                }
                if (e.Control is DataGridViewTextBoxEditingControl)
                {
                    textbox = (DataGridViewTextBoxEditingControl)e.Control;
                    if (textbox != null)
                    {
                        textbox.KeyPress += new KeyPressEventHandler(textbox_KeyPress);
                        textbox.KeyUp -= new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyUp += new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyDown -= new KeyEventHandler(textbox_KeyDown);
                        textbox.KeyDown += new KeyEventHandler(textbox_KeyDown);

                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
            }
        }
        void textbox_KeyDown(object sender, KeyEventArgs e)
        {
            sKeyChar = string.Empty;
            if (e.KeyCode == Keys.Return)
            {
                int index = dgDetails.SelectedCells[0].OwningRow.Index;
                if (textbox.Text.Trim() != "")
                {
                    ExtraServices _service = dbh.ExtraServices.Where(x => x.Name == textbox.Text.Trim()).SingleOrDefault();
                    if (_service != null)
                    {
                        fillService(_service.id);
                    }
                }
                dgDetails.CurrentCell = dgDetails.Rows[index].Cells[col_Code.Index + 1];
            }

        }
        void textbox_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {

                
            }
            catch { }

        }
        void cb_KeyDown(object sender, KeyEventArgs e)
        {


        }
        void cb_Validating(object sender, CancelEventArgs e)
        {
         
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name)
            {
                if (dgDetails.LastKey == Keys.Enter)
                {
                    if (cb.SelectedIndex == -1 && cb.Text != "")
                    {
                        
                    }
                }
            }


        }
        void textbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            sKeyChar = e.KeyChar.ToString();
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (Char.IsDigit(e.KeyChar)) return;
                if (Char.IsControl(e.KeyChar)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).Text.Contains('.') == false)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                e.Handled = true;
            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.NotifyCurrentCellDirty(true);
            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                if (sKeyChar == string.Empty) { return; }
                dgDetails.NotifyCurrentCellDirty(true);
                e.Handled = true;
                int _SelectedService;
                sKeyChar = textbox.GetCharInsertText(e.KeyChar);
                ExtraServiceSearchView frm = new ExtraServiceSearchView(sKeyChar, ENExtraServiceTypes.RoomService);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    _SelectedService = frm.selectedServiceID;
                    fillService(_SelectedService);
                }
                else
                {
                    textbox.Text = "";
                }
            }
        }
        
        private void dgDetails_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }

        private void dgDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {

                fillServiceByCodeInCurrentRow();

            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Amount.Name)
            {
                if (dgDetails.CurrentCell.Value == null) { return; }
                RoomServiceDTL pdtl = getCurrent();
                if (pdtl != null)
                {
                    if (pdtl.Amount == 0) { }
                    if (pdtl.Qty == 0 && pdtl.Rate == 0)
                    {
                        pdtl.Amount = 0;
                    }
                    else if (pdtl.Qty == 0)
                    {
                        pdtl.Qty = pdtl.Amount / pdtl.Rate;
                    }
                    else if (pdtl.Rate == 0)
                    {
                        pdtl.Rate = pdtl.Amount / pdtl.Qty;
                    }
                }

            }

            CalcRowAmount(getCurrent());

            CalcNetTotal();

            CalcGrandTotal();
        }

        private void dgDetails_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.BeginEdit(true);
            }
        }

        private void dgDetails_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (e.FormattedValue == null || e.FormattedValue.ToString2().Trim() == "")
                {
                    //    e.Cancel = true;
                }
            }
        }

        private void dgDetails_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            LoadCurrentSerialNo();
            LoadFullSerialNo();
            CalcGrand();
        }

        private void dgDetails_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            RoomServiceDTL pdtl = (RoomServiceDTL)dgDetails.Rows[e.RowIndex].DataBoundItem;
            if (pdtl != null)
            {
                try
                {
                    int _CurrentProductID = pdtl.FK_ServiceID.toInt32();

                }
                catch (Exception) { }
            }
            LoadCurrentSerialNo();
        }
        #endregion

        #region Form event
        private void txtExtraServices_TextChanged(object sender, EventArgs e)
        {
            CalcNetTotal();
            CalcGrandTotal();
        }
        private void dtVoucherDate_ValueChanged_1(object sender, EventArgs e)
        {
            if (cmbRoom.SelectedValue != null)
                PopulateGuest();
        }
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    dgDetails.Focus();
                }
            }
            catch (Exception)
            {
                throw;
            }
           
        }
        private void txtVoucherDiscountPerc_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtVoucherDiscountAmount_KeyDown(object sender, KeyEventArgs e)
        {
          
        }        
        private void cmbGuest_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsActiveControl(sender)) { return; }

                ClearGuestInfo();
                LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
                CalcNetTotal();

            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void btnPayment_Click(object sender, EventArgs e)
        {
            decimal PayAmt = txtNetTotal.Value;
            RoomServicePaymentView payment = new RoomServicePaymentView(entRoomServicePaymentList, PayAmt, NumberFormat, DefaultCreditCard,DefaultCreditCardNumber);
            if (payment.ShowDialog() == DialogResult.OK)
            {
                CalcPaymentTotal();
                CalcGrandTotal();
            }
        }
        private void cmbRoom_SelectedValueChanged(object sender, EventArgs e)
        {
            if (_OnLoad > 0)
            {
                PopulateGuest();
            }
        }
        private void dtVoucherDate_ValueChanged(object sender, EventArgs e)
        {
            if (cmbRoom.SelectedValue != null)
                PopulateGuest();
        }
        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurrency.ValueMember == "") { return; }
                if (cmbCurrency.SelectedValue == null) { return; }
                int iCurrencyID = cmbCurrency.SelectedValue.ToString2().ToInt32();

                CurrencyClass entCurrency = entCurrencys.Where(x => x.id == iCurrencyID).Single();
                Company company = dbh.Companies.Single();
                int _sourcecurrencyId = company.FK_Currency.toInt32();
                int _destinationCurrencyID = entCurrency.id;
                if (_sourcecurrencyId == _destinationCurrencyID)
                {
                    txtExRate.Enabled = false;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
                txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                ApplyExRate();
            }
            catch (Exception) { }
        }

        private void txtExRate_Enter(object sender, EventArgs e)
        {
            previousExRate = txtExRate.Value;
        }

        private void txtExRate_KeyUp(object sender, KeyEventArgs e)
        {
            ApplyExRate();
        }
        #endregion

        #region Framework events
        private void RoomServiceView_atInitialise()
        {
            try
            {
                InitEntities();
                InitControls();
                LoadSettings();
                initGridColumns();
                ApplyGridStyles();
                ShowToolTip();
                PopulateCombos();
                SettingsButton.Visible = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }             
        private void RoomServiceView_atAfterInitialise()
        {
            try
            {
                _OnLoad = 1;
                SetDefaultDateAndTime();
                RoomServiceView_atNewClick(null);
                PopulateSelectedRoom();
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }      
        private void RoomServiceView_atNewClick(object source)
        {
            try
            {
                PopulateRoomServiceEnt();
                FnClearAll();
                ClearGuestInfo();
                BindGrid();
                SetDefaultComboValues();
                SetDefaultDateAndTime();
                GetSeqNo();
                CalcNetTotal();
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }      
        private bool RoomServiceView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    dbh = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                #region Voucher Posting
                if (!blnSanctioningRequired)
                {
                    PostVoucher();
                }
                //Extra Services
                if (!blnSanctioningRequired && entRoomServiceDTLList.Count() > 0)
                {
                    entRoomServiceHDR.FK_VoucherHDRID = entVoucherHdr.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entRoomServiceHDR.FK_VoucherHDRID, ref dbh);
                    entRoomServiceHDR.FK_VoucherHDRID = null;
                }

                //Payment
                if (!blnSanctioningRequired && entRoomServicePaymentList.Count() > 0)
                {
                    entRoomServiceHDR.FK_PaymentVoucherHDRID = entVoucherHdrPayment.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entRoomServiceHDR.FK_PaymentVoucherHDRID, ref dbh);
                    entRoomServiceHDR.FK_PaymentVoucherHDRID = null;
                }
                
                #endregion
                #region Room Service Details                              
                entRoomServiceHDR.ContextID = iContextID;
                entRoomServiceHDR.LoginUserID = GlobalFunctions.LoginUserID;
                entRoomServiceHDR.LocationID = GlobalFunctions.LoginLocationID;
                entRoomServiceHDR.VoucherNo = txtVoucherNo.Text;
                entRoomServiceHDR.VoucherDate = dtVoucherDate.Value;
                entRoomServiceHDR.FK_GuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                entRoomServiceHDR.FK_RoomID = cmbRoom.SelectedValue.ToString().ToInt32();
                entRoomServiceHDR.GrandTotal = txtNetTotal.Text.ToDecimal();
                entRoomServiceHDR.Payment = txtPayment.Value;
                entRoomServiceHDR.Remarks = txtRemarks.Text;
                entRoomServiceHDR.FK_CurrencyHdrID = cmbCurrency.SelectedValue.ToString2().ToInt32();
                entRoomServiceHDR.ExRate = txtExRate.Value;
                if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
                {
                    entRoomServiceHDR.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
                }
                else { entRoomServiceHDR.FK_EmployeeID = null; }
                entRoomServiceHDR.FK_VoucherDiscountID = null;
                entRoomServiceHDR.VoucherDiscountAmount = txtVoucherDiscAmount.Text.ToDecimal();
                entRoomServiceHDR.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entRoomServiceHDR.Sanctioned = !blnSanctioningRequired;
                entRoomServiceHDR.Cancelled = false;
                if (NewRecord)
                {
                    dbh.RoomServiceHDRs.AddObject(entRoomServiceHDR);
                }
                else
                {
                    entRoomServiceHDR.ModifiedDate = System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(entRoomServiceHDR, EntityState.Modified);
                }
                #endregion
                #region Removing Deleted RoomServiceDTLs
                var d1 = entOldRoomServiceDTLList.Select(x => new { id = x.id });
                var d2 = entRoomServiceDTLList.Select(y => new { id = y.id });
                var deletedESDtls = d1.Except(d2);
                foreach (var deletedItem in deletedESDtls)
                {
                    RoomServiceDTL delItDtl = entOldRoomServiceDTLList.Where(x => x.id == deletedItem.id).First();
                    dbh.RoomServiceDTLs.DeleteObject(delItDtl);
                }
                #endregion
                #region Adding or Updating ExtraSevices
                foreach (RoomServiceDTL RoomService in bindRoomServiceDTL.List)
                {
                    if (entRoomServiceHDR.id != null)
                    {
                        RoomService.FK_RoomServiceID = entRoomServiceHDR.id;


                        if (dbh.RoomServiceDTLs.Where(x => x.id == RoomService.id).ToList().Count == 0)
                        {
                            dbh.RoomServiceDTLs.AddObject(RoomService);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(RoomService, System.Data.EntityState.Modified);
                        }
                    }
                }
                #endregion
                #region Removing Deleted Payments
                var p1 = entOldRoomServicePaymentList.Select(x => new { id = x.id });
                var p2 = entRoomServicePaymentList.Select(y => new { id = y.id });
                var deletedpayments = p1.Except(p2);
                foreach (var deletedItem in deletedpayments)
                {
                    RoomServicePayment delItPay = entOldRoomServicePaymentList.Where(x => x.id == deletedItem.id).First();
                    dbh.RoomServicePayments.DeleteObject(delItPay);
                }
                #endregion
                #region Adding or Updating Payments
                foreach (RoomServicePayment eRoomServicePayment in entRoomServicePaymentList)
                {
                    if (eRoomServicePayment.Payment != 0)
                    {
                        eRoomServicePayment.FK_RoomServiceID = entRoomServiceHDR.id;
                        if (eRoomServicePayment.FK_MVInstrumentTypeID == 0)
                        {
                            eRoomServicePayment.FK_MVInstrumentTypeID = null;
                        }
                        if (dbh.RoomServicePayments.Where(x => x.id == eRoomServicePayment.id).ToList().Count == 0)
                        {
                            dbh.RoomServicePayments.AddObject(eRoomServicePayment);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(eRoomServicePayment, System.Data.EntityState.Modified);
                        }
                    }
                }

                #endregion
                dbh.SaveChanges();
                dbh = atHotelContext.CreateContext();

                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_RoomServiceHDRVoucherNo"))
                    {
                        return RoomServiceView_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Save);
                return false;
            }
        }        
        private bool RoomServiceView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "") { errProvider.SetError(txtVoucherNo, "Voucher No  Must be Entered"); txtVoucherNo.Focus(); return false; }
                if (cmbRoom.Text.Trim() == "") { errProvider.SetError(cmbRoom, "Choose Room "); cmbRoom.Focus(); return false; }
                if (cmbGuest.Text.Trim() == "") { errProvider.SetError(cmbGuest, "Choose Guest"); cmbGuest.Focus(); return false; }
                if (GlobalFunctions.blnMultiCurrency)
                {
                    if (cmbCurrency.SelectedValue == null) { errProvider.SetError(cmbCurrency, MessageKeys.MsgCurrencyMustBeSelected); cmbCurrency.Focus(); return false; }
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }        
        private bool RoomServiceView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInRoomService)
                {
                    PrintClick();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }       
        private void RoomServiceView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vCheckIn = entRoomServiceList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vCheckIn;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }                
        private bool RoomServiceView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {

                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vBookings = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vBookings).id);
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        

        private bool RoomServiceView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }        
        private void RoomServiceView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool RoomServiceView_atPrint(object source)
        {
            try
            {
                if (entRoomServiceHDR.id == 0)
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Room Service", entRoomServiceHDR.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool RoomServiceView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteVoucher(entRoomServiceHDR.FK_VoucherHDRID, ref dbh);
                GlobalMethods.DeleteVoucher(entRoomServiceHDR.FK_PaymentVoucherHDRID, ref dbh);
                foreach (RoomServicePayment Payment in entRoomServicePaymentList) //**Delete Payments **
                {
                    dbh.RoomServicePayments.DeleteObject(Payment);
                }
                dbh.DeleteObject(entRoomServiceHDR);        //**Delete Room Service**
                dbh.SaveChanges();

                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }       
        private void RoomServiceView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
