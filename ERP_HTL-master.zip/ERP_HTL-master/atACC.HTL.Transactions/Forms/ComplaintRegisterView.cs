﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using System.Data.SqlClient;
using atACCFramework.UserControls;
using atACC.HTL.Transactions.Sub_Forms;

namespace atACC.HTL.Transactions
{
    public partial class ComplaintRegisterView : SearchFormBase2
    {
        #region Private Variable
        ComplaintRegister entComplaintRegister;
        List<ComplaintRegister> entComplaintRegisters;
        List<Rooms> entRooms;
        List<Employee> entReceptionist;
        List<Employee> entServiceMans;
        List<MasterValue> entStatus;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        #endregion

        #region Constructor
        public ComplaintRegisterView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_ComplaintRegisterView;
        }
        #endregion        

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(10);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Populate Events
        public override void LoadVouchers()
        {
            string sTempVno = txtVoucherNo.Text;
            dbh = atHotelContext.CreateContext();
            List<UpDownData> _Vouchers = dbh.ComplaintRegisters.OrderByDescending(x => x.id)
                .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
            txtVoucherNo.Items.Clear();
            txtVoucherNo.DataSource = _Vouchers;
            if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
            txtVoucherNo.Text = sTempVno;
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_ComplaintRegister, 0, 0, txtVoucherNo.Text, GlobalFunctions.CurrentFiscalPeriodID);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateComplaintRegister()
        {
            try
            {
                entComplaintRegisters = dbh.ComplaintRegisters.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRooms()
        {
            try
            {
                List<Rooms> entRooms = dbh.Rooms.ToList();
                cmbRoom.DataSource = entRooms;
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateGuest()
        {
            int iFlagId = 1, iRoomId = 0, iGuest = 0;
            DateTime iDate = dtVoucherDate.Value;

            SqlHelper _sql = new SqlHelper();
            iRoomId = Convert.ToInt32(cmbRoom.SelectedValue);
            _sql.SPName = "SPGetGuestInfo";
            SqlParameter paramFlag = new SqlParameter("Flag", iFlagId);
            SqlParameter paramFlag2 = new SqlParameter("RoomId", iRoomId);
            SqlParameter paramFlag3 = new SqlParameter("VoucherDate", iDate);

            _sql.SqlParameters = new List<SqlParameter>();
            _sql.SqlParameters.Add(paramFlag);
            _sql.SqlParameters.Add(paramFlag2);
            _sql.SqlParameters.Add(paramFlag3);
            DataTable dt = new DataTable();
            dt = _sql.ExecuteProcedure().Tables[0];
            cmbGuest.DataSource = dt;
            cmbGuest.DisplayMember = "Name";
            cmbGuest.ValueMember = "id";
            cmbGuest.SelectedIndex = -1;
            if (dt.Rows.Count == 1)
            {
                cmbGuest.SelectedIndex = 0;
                cmbGuest.Enabled = false;
            }
            if (dt.Rows.Count == 0)
            {
                cmbGuest.SelectedIndex = -1;
                cmbGuest.Enabled = true;
            }
        }
        private void PopulateComplaintType()
        {
            try
            {
                var ComplaintType = entComplaintRegisters.Where(x => x.Type != "").Select(x => new { id = -1, x.Type }).Distinct().ToList();
                cmbComplaintType.DataSource = ComplaintType;
                cmbComplaintType.DisplayMember = "Type";
                cmbComplaintType.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateEmployee()
        {
            try
            {
                entReceptionist = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
                entServiceMans = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.ServiceMan || x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
                objLib.fnFillCombo(ref cmbRegisteredEmployee, entReceptionist, "Name", "id");
                objLib.fnFillCombo(ref cmbAssignedTo, entServiceMans, "Name", "id");
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbRegisteredEmployee.SelectedValue = user.FK_EmployeeID;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateStatus()
        {
            try
            {
                entStatus = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.ComplaintRegisterStatus).ToList();
                objLib.fnFillCombo(ref cmbStatus, entStatus, "Description", "id");
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewReceptionist_Click(object sender, EventArgs e)
        {
            atACC.ADM.Masters.EmployeeView frm = new ADM.Masters.EmployeeView(true);
            frm.CurrentEmployeeType = (int)ENMVEmployeeType.Receptionist;
            frm.EditButton.Enabled = false;
            frm.NewButton.Enabled = false;
            frm.DeleteButton.Enabled = false;
            frm.SearchButton.Enabled = false;
            frm.Text = MessageKeys.MsgReceptionist;
            if (frm.ShowDialog() == DialogResult.OK)
            {
                int _id = frm.CurrentEmployeeID;
                if (_id != null && _id != 0)
                {
                    Employee _entReceptionist = dbh.Employees.Where(x => x.id == _id).SingleOrDefault();
                    entReceptionist.Add(_entReceptionist);
                    objLib.fnFillCombo(ref cmbRegisteredEmployee, entReceptionist, "Name", "id");
                    cmbRegisteredEmployee.SelectedValue = _entReceptionist.id;
                }
            }
        }
        private void btnNewServiceMan_Click(object sender, EventArgs e)
        {
            atACC.ADM.Masters.EmployeeView frm = new ADM.Masters.EmployeeView(true);
            frm.CurrentEmployeeType = (int)ENMVEmployeeType.ServiceMan;
            frm.EditButton.Enabled = false;
            frm.NewButton.Enabled = false;
            frm.DeleteButton.Enabled = false;
            frm.SearchButton.Enabled = false;
            frm.Text = MessageKeys.MsgServiceMan;
            if (frm.ShowDialog() == DialogResult.OK)
            {
                int _id = frm.CurrentEmployeeID;
                if (_id != null && _id != 0)
                {
                    Employee _entServiceMan = dbh.Employees.Where(x => x.id == _id).SingleOrDefault();
                    entServiceMans.Add(_entServiceMan);
                    objLib.fnFillCombo(ref cmbAssignedTo, entServiceMans, "Name", "id");
                    cmbAssignedTo.SelectedValue = _entServiceMan.id;
                }
            }
        }
        private void cmbRoom_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateGuest();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void ComplaintRegisterView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                objLib = new CommonLibClasses();
                entComplaintRegister = new ComplaintRegister();
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
                EditButton.Visible = SaveButton.Visible = true;
                SettingsButton.Visible = true;
                if (GlobalFunctions.blnVoucherCancelling)
                {
                    PrintButton.Text = MessageKeys.MsgCancel;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void ComplaintRegisterView_atAfterInitialise()
        {
            try
            {
                PopulateComplaintRegister();
                PopulateRooms();
                PopulateComplaintType();
                PopulateEmployee();
                PopulateStatus();
                GetSeqNo();
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void ComplaintRegisterView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entComplaintRegister = new ComplaintRegister();
                PopulateComplaintRegister();
                PopulateRooms();
                PopulateComplaintType();
                PopulateEmployee();
                PopulateStatus();
                GetSeqNo();
                EditButton.Visible = SaveButton.Visible = true;
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            } 
        }
        private bool ComplaintRegisterView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNumberCannotBeBlank);
                    txtVoucherNo.Focus();
                    return false;
                }
                if (cmbRoom.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbRoom, MessageKeys.MsgRoomOrHallMustBeChosen);
                    cmbRoom.Focus();
                    return false;
                }
                if (cmbGuest.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                    cmbGuest.Focus();
                    return false;
                }
                if (cmbComplaintType.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbComplaintType, MessageKeys.MsgComplaintTypeMustBeEntered);
                    cmbComplaintType.Focus();
                    return false;
                }
                if(txtComplaint.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtComplaint, MessageKeys.MsgComplaintMustBeEntered);
                    txtComplaint.Focus();
                    return false;
                }
                if (cmbRegisteredEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbRegisteredEmployee, MessageKeys.MsgRegisteredByMustBeChosen);
                    cmbRegisteredEmployee.Focus();
                    return false;
                }
                if (cmbStatus.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbStatus, MessageKeys.MsgStatusMustBeChosen);
                    cmbStatus.Focus();
                    return false;
                }
                if (cmbAssignedTo.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbAssignedTo, MessageKeys.MsgAssignedToMustBeChosen);
                    cmbAssignedTo.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool ComplaintRegisterView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    entComplaintRegister = new ComplaintRegister();
                }
                entComplaintRegister.ContextID = iContextID;
                entComplaintRegister.LocationID = GlobalFunctions.LoginLocationID;
                entComplaintRegister.LoginUserID = GlobalFunctions.LoginUserID;
                entComplaintRegister.VoucherNo = txtVoucherNo.Text;
                entComplaintRegister.VoucherDate = dtVoucherDate.Value;
                entComplaintRegister.FK_RoomID = cmbRoom.SelectedValue.ToInt32();
                entComplaintRegister.FK_GuestID = cmbGuest.SelectedValue.ToInt32();
                entComplaintRegister.Type = cmbComplaintType.Text;
                entComplaintRegister.Complaint = txtComplaint.Text;
                entComplaintRegister.Description = txtDescription.Text;
                entComplaintRegister.FK_RegisteredEmployeeID = cmbRegisteredEmployee.SelectedValue.ToInt32();
                entComplaintRegister.ExpectedResolvingDate = dtExpectedResolvingDate.Value;
                entComplaintRegister.FK_StatusID = cmbStatus.SelectedValue.ToInt32();
                entComplaintRegister.FK_AssignedEmployeeID = cmbAssignedTo.SelectedValue.ToInt32();
                entComplaintRegister.ActionTaken = txtActionTaken.Text;
                entComplaintRegister.CompletedDate = dtCompletedDate.Value;
                entComplaintRegister.Remarks = txtRemarks.Text;
                entComplaintRegister.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entComplaintRegister.Sanctioned = true;
                if (NewRecord)
                {
                    dbh.ComplaintRegisters.AddObject(entComplaintRegister);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(entComplaintRegister, EntityState.Modified);
                }
                dbh.SaveChanges();
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_ComplaintRegisterVoucherNo"))
                    {
                        return ComplaintRegisterView_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool ComplaintRegisterView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInComplaintRegister)
                {
                    PrintClick();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void ComplaintRegisterView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vComplaintRegister = entComplaintRegisters.Select(x => new { id = x.id, VoucherNo = x.VoucherNo, VoucherDate = x.VoucherDate.Value.ToShortDateString(), Complaint = x.Complaint }).OrderByDescending(x => x.id);
                e.SearchEntityList = vComplaintRegister;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            ComplaintRegister complaintRegister = dbh.ComplaintRegisters.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (complaintRegister != null)
            {
                ReLoadData(complaintRegister.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entComplaintRegister = dbh.ComplaintRegisters.Where(x => x.id == id).SingleOrDefault();
                if (entComplaintRegister != null)
                {
                    txtVoucherNo.Text = entComplaintRegister.VoucherNo;
                    dtVoucherDate.Value = entComplaintRegister.VoucherDate.Value;
                    cmbRoom.SelectedValue = entComplaintRegister.FK_RoomID;
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = entComplaintRegister.FK_GuestID;
                    cmbComplaintType.Text = entComplaintRegister.Type;
                    txtComplaint.Text = entComplaintRegister.Complaint;
                    txtDescription.Text = entComplaintRegister.Description;
                    cmbRegisteredEmployee.SelectedValue = entComplaintRegister.FK_RegisteredEmployeeID;
                    dtExpectedResolvingDate.Value = entComplaintRegister.ExpectedResolvingDate.Value;
                    cmbStatus.SelectedValue = entComplaintRegister.FK_StatusID;
                    cmbAssignedTo.SelectedValue = entComplaintRegister.FK_AssignedEmployeeID;
                    txtActionTaken.Text = entComplaintRegister.ActionTaken;
                    dtCompletedDate.Value = entComplaintRegister.CompletedDate.Value;
                    txtRemarks.Text = entComplaintRegister.Remarks;
                    if (entComplaintRegister.Cancelled.toBool())
                    {
                        lblCancelStatus.Text = MessageKeys.MsgCancelledVoucher;
                        lblCancelStatus.Visible = true;
                        EditButton.Visible = SaveButton.Visible = false;
                    }
                    else
                    {
                        lblCancelStatus.Text = "--";
                        lblCancelStatus.Visible = false;
                        EditButton.Visible = SaveButton.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool ComplaintRegisterView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
             try
            {

                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vComplaintRegister = new { id = 0, VoucherNo = "", VoucherDate = "", Complaint = ""};
                    ReLoadData(e.GetSelectedEntity().Cast(vComplaintRegister).id);
                }
                else 
                {
                    cmbRoom.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private void ComplaintRegisterView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool ComplaintRegisterView_atPrint(object source)
        {
            try
            {
                if (entComplaintRegister.id == 0)
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Complaint Register", entComplaintRegister.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool ComplaintRegisterView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                if (GlobalFunctions.blnVoucherCancelling)
                {
                    entComplaintRegister.LocationID = GlobalFunctions.LoginLocationID;
                    entComplaintRegister.LoginUserID = GlobalFunctions.LoginUserID;
                    entComplaintRegister.Cancelled = true;
                    dbh.ObjectStateManager.ChangeObjectState(entComplaintRegister, EntityState.Modified);
                }
                else
                {
                    dbh.ComplaintRegisters.DeleteObject(entComplaintRegister);
                }
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void ComplaintRegisterView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
