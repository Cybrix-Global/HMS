﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.Common;
using atACC.CommonExtensions;
using System.Text.RegularExpressions;
using System.Data.Objects;
using atACCFramework;
using atACC.HTL.ORM;

namespace atACC.HTL.Transactions
{
    public partial class CheckInExtraServicesView : FormBase
    {
        #region Private Fields
        atACCHotelEntities dbh;
        List<ExtraServiceDTLs> entCheckInDTLList;
        DataGridViewTextBoxEditingControl textbox;
        DataGridViewComboBoxEditingControl cb;
        string sKeyChar = "";
        string NumberFormat, QtyFormat;
        decimal ExRate;
        #endregion

        #region Public Properties
        public List<ExtraServiceDTLs> ExtraServiceDTLs { get { return entCheckInDTLList; } }
        #endregion

        #region Constructor
        public CheckInExtraServicesView(atACCHotelEntities db, List<ExtraServiceDTLs> checkInExtraServiceDTLs, string sNumberFormat, string sQtyFormat, decimal dcExRate)
        {
            InitializeComponent();

            dbh = db;
            entCheckInDTLList = checkInExtraServiceDTLs;
            NumberFormat = sNumberFormat;
            QtyFormat = sQtyFormat;            
            ExRate = dcExRate;

            lblTotQty.Format = sQtyFormat;
            txtGross.Format = txtTotalDiscount.Format = txtTotalTax.Format = txtNetTotal.Format = sNumberFormat;
            
            initGridColumns();
            ApplyGridStyles();
            BindGrid();
            CalcNetTotal();
        }
        #endregion

        #region Form Events
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }

        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
        private void CheckInExtraServicesView_Shown(object sender, EventArgs e)
        {
            LoadFullSerialNo();
            dgDetails.CurrentCell = dgDetails.Rows[dgDetails.RowCount - 1].Cells[col_Service.Name];
        }
        #endregion

        #region Grid Events
        private void dgDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (e.Control is DataGridViewComboBoxEditingControl)
                {
                    cb = (DataGridViewComboBoxEditingControl)e.Control;
                    if (cb != null)
                    {
                        cb.DropDownStyle = ComboBoxStyle.DropDown;
                        cb.AutoCompleteMode = AutoCompleteMode.Suggest;
                        cb.Validating -= new CancelEventHandler(cb_Validating);
                        cb.Validating += new CancelEventHandler(cb_Validating);
                        cb.KeyDown -= new KeyEventHandler(cb_KeyDown);
                        cb.KeyDown += new KeyEventHandler(cb_KeyDown);
                        cb.Focus();
                    }
                }
                if (e.Control is DataGridViewTextBoxEditingControl)
                {
                    textbox = (DataGridViewTextBoxEditingControl)e.Control;
                    if (textbox != null)
                    {
                        textbox.KeyPress += new KeyPressEventHandler(textbox_KeyPress);
                        textbox.KeyUp -= new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyUp += new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyDown -= new KeyEventHandler(textbox_KeyDown);
                        textbox.KeyDown += new KeyEventHandler(textbox_KeyDown);

                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
            }
        }
        void textbox_KeyDown(object sender, KeyEventArgs e)
        {
            sKeyChar = string.Empty;
            if (e.KeyCode == Keys.Return)
            {
                int index = dgDetails.SelectedCells[0].OwningRow.Index;
                if (textbox.Text.Trim() != "")
                {
                    ExtraServices _service = dbh.ExtraServices.Where(x => x.Name == textbox.Text.Trim()).SingleOrDefault();
                    if (_service != null)
                    {
                        fillService(_service.id);
                    }
                }
                dgDetails.CurrentCell = dgDetails.Rows[index].Cells[col_Code.Index + 1];
            }

        }
        void textbox_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {

                
            }
            catch { }

        }
        void cb_KeyDown(object sender, KeyEventArgs e)
        {


        }
        void cb_Validating(object sender, CancelEventArgs e)
        {
            // Create New Service If Not Exist
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name)
            {
                if (dgDetails.LastKey == Keys.Enter)
                {
                    if (cb.SelectedIndex == -1 && cb.Text != "")
                    {
                        //NewProductView frm = new NewProductView(0, iContextID);
                        //if (frm.ShowDialog() == DialogResult.OK)
                        //{

                        //}
                    }
                }
            }


        }
        void textbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            sKeyChar = e.KeyChar.ToString();
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (Char.IsDigit(e.KeyChar)) return;
                if (Char.IsControl(e.KeyChar)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).Text.Contains('.') == false)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                e.Handled = true;
            }
            
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.NotifyCurrentCellDirty(true);
                if (sKeyChar == string.Empty) { return; }
                sKeyChar = textbox.GetCharInsertText(e.KeyChar);
                e.Handled = true;
                int _SelectedService;

                ExtraServiceSearchView frm = new ExtraServiceSearchView(sKeyChar, ENExtraServiceTypes.Default);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    _SelectedService = frm.selectedServiceID;
                    fillService(_SelectedService);
                }
                else
                {
                    textbox.Text = "";
                }
            }

        }
        
        private void dgDetails_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            //e.Cancel = true;
        }
        private void dgDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {

                FillServiceByCodeInCurrentRow();

            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Amount.Name)
            {
                if (dgDetails.CurrentCell.Value == null) { return; }
                ExtraServiceDTLs pdtl = getCurrent();
                if (pdtl != null)
                {
                    if (pdtl.Amount == 0) { }
                    if (pdtl.Qty == 0 && pdtl.Rate == 0)
                    {
                        pdtl.Amount = 0;
                    }
                    else if (pdtl.Qty == 0)
                    {
                        pdtl.Qty = pdtl.Amount / pdtl.Rate;
                    }
                    else if (pdtl.Rate == 0)
                    {
                        pdtl.Rate = pdtl.Amount / pdtl.Qty;
                    }
                }

            }

            CalcRowAmount(getCurrent());
        }
        private void dgDetails_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.BeginEdit(true);
            }

        }
        private void dgDetails_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (e.FormattedValue == null || e.FormattedValue.ToString2().Trim() == "")
                {
                    //    e.Cancel = true;
                }
            }
            //if (dgDetails.CurrentCell.OwningColumn.Name == col_SpcialDiscount.Name || dgDetails.CurrentCell.OwningColumn.Name == col_SpcialDiscountPerc.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name)
            //{
            //    if (e.FormattedValue.ToString().ToDecimal() < 0)
            //    {
            //        e.Cancel = true;
            //    }

            //}

        }
        private void dgDetails_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            LoadCurrentSerialNo();
            LoadFullSerialNo();
        }
        private void dgDetails_KeyDown(object sender, KeyEventArgs e)
        {


        }
        private void dgDetails_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            
            LoadCurrentSerialNo();
        }
        #endregion

        #region GridMethods
        private void CalculateSlab(bool blnUpdateDeductionAmount, ExtraServiceDTLs extraServiceDTL)
        {
            if (extraServiceDTL != null)
            {
                int iExtraServID = extraServiceDTL.FK_ExtraServiceID.ToInt32();
                List<Slab> slabs = (from rs in dbh.ExtraServiceSlabs
                                    join s in dbh.Slabs on rs.FK_SlabID equals s.id
                                    where rs.FK_ExtraServiceID == iExtraServID
                                    select s).ToList();
                extraServiceDTL.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
            }
        }
        private void CalcRowAmount(ExtraServiceDTLs extraServiceDTL)
        {            
            if (extraServiceDTL != null)
            {
                extraServiceDTL.Amount = (extraServiceDTL.Rate ?? 0)* (extraServiceDTL.Qty ?? 0);
                bool blnUpdateDeductionAmount = dgDetails.CurrentCell.OwningColumn.Name != col_DeductionAmount.Name;
                CalculateSlab(blnUpdateDeductionAmount, extraServiceDTL);
                CalcNetTotal();
            }
        }
        private void CalcNetTotal()
        {
            lblTotQty.Value = entCheckInDTLList.Sum(x => x.Qty).ToDecimal();
            txtGross.Value = entCheckInDTLList.Sum(x => x.Amount).ToDecimal();
            txtTotalDiscount.Value = entCheckInDTLList.Sum(x => x.DeductionAmount + x.SlabDiscount).ToDecimal();
            lblTotalTax.lblTax1 = entCheckInDTLList.Sum(x => x.Tax1Amount).ToDecimal();
            lblTotalTax.lblTax2 = entCheckInDTLList.Sum(x => x.Tax2Amount).ToDecimal();
            lblTotalTax.lblTax3 = entCheckInDTLList.Sum(x => x.Tax3Amount).ToDecimal();
            lblTotalTax.lblAddnlTax = entCheckInDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
            lblTotalTax.lblExciseDuty = entCheckInDTLList.Sum(x => x.ExciseAmount).ToDecimal();
            lblTotalTax.lblVAT = entCheckInDTLList.Sum(x => x.VATAmount).ToDecimal();
            lblTotalTax.lblCGST = entCheckInDTLList.Sum(x => x.CGSTAmount).ToDecimal();
            lblTotalTax.lblSGST = entCheckInDTLList.Sum(x => x.SGSTAmount).ToDecimal();
            lblTotalTax.lblIGST = entCheckInDTLList.Sum(x => x.IGSTAmount).ToDecimal();
            txtTotalTax.Value = lblTotalTax.TotalTax;
            txtNetTotal.Value = (txtGross.Value + txtTotalTax.Value) - txtTotalDiscount.Value;
        }
        private void FillServiceByCodeInCurrentRow()
        {
            int _ServiceID = 0;
            if (dgDetails.CurrentCell.Value == null) { return; }
            string sCode = dgDetails.CurrentCell.Value.ToString();
            if (dbh.ExtraServices.Any(x => x.Code == sCode))
            {
                _ServiceID = dbh.ExtraServices.Where(x => x.Code == textbox.Text).First().id;
                fillService(_ServiceID);

            }
            else
            {
                dgDetails.CurrentCell.Value = "";
                if (dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value == null) { return; }
                _ServiceID = dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value.ToString().ToInt32();
                fillService(_ServiceID);
            }
        }
        private void LoadCurrentSerialNo()
        {
            if (dgDetails.CurrentRow == null) { return; }
            dgDetails.CurrentRow.Cells[col_slno.Name].Value = dgDetails.CurrentRow.Cells[col_slno.Name].RowIndex + 1;


        }
        private void LoadFullSerialNo()
        {
            int i = 1;
            foreach (DataGridViewRow row in dgDetails.Rows)
            {
                row.Cells[col_slno.Name].Value = i;
                i = i + 1;
            }

        }
        private ExtraServiceDTLs getCurrent()
        {
            try
            {

                if (dgDetails.CurrentRow != null)
                {
                    ExtraServiceDTLs ExtraServiceDTL = (ExtraServiceDTLs)dgDetails.CurrentRow.DataBoundItem;
                    return ExtraServiceDTL;
                }
                else
                {
                    return null;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void BindGrid()
        {
            try
            {
                dgDetails.AutoGenerateColumns = false;
                bindCheckInExtraServiceDTL.DataSource = null;
                bindCheckInExtraServiceDTL.DataSource = entCheckInDTLList;
                dgDetails.DataSource = bindCheckInExtraServiceDTL;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void initGridColumns()
        {
            try
            {
                //col_DeductionPerc.Visible=GlobalFunctions.blnDeductionPerc;
                //col_DeductionAmount.Visible=GlobalFunctions.blnDeductionAmount;
                col_SlabDiscount.Visible = GlobalFunctions.blnSlabDiscountinService;
                col_SlabDiscountPerc.Visible = GlobalFunctions.blnSlabDiscountinService;
                //col_TotalTax.Visible=GlobalFunctions.blnTotalTax;
                //col_NetAmount.Visible=GlobalFunctions.blnNetAmount;
                //  col_FK_DiscountSlabID.Visible=GlobalFunctions.blnDiscountSlabID;
                // col_TotalDiscount.Visible = GlobalFunctions.blnTotalDiscount;
                //col_TaxableAmount.Visible = GlobalFunctions.blnTaxableAmount;
                //col_FK_GSTSlabID.Visible = GlobalFunctions.blnGSTSlabID;
                //col_FK_VATSlabID.Visible = GlobalFunctions.blnFK_VATSlabIDe;
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
                col_ExciseAmount.Visible = GlobalFunctions.blnExciseDutyInService;
                // col_FK_ExciseSlabID.Visible = GlobalFunctions.blnExciseSlabID);
                //col_ExciseAmount.Visible=GlobalFunctions.ExcisePerc;
                //col_ExciseAmount.Visible=GlobalFunctions.ExciseAmount;
                // col_FK_TAX1SlabID.Visible=GlobalFunctions.FK_TAX1SlabID;
                col_VATAmount.Visible = GlobalFunctions.blnVATinService;
                col_VATPerc.Visible = GlobalFunctions.blnVATinService;
                col_Tax1Amount.Visible = GlobalFunctions.blnTAX1inService;
                col_Tax1Perc.Visible = GlobalFunctions.blnTAX1inService;
                // col_FK_TAX2SlabID.Visible=GlobalFunctions.blnTAX2SlabID;
                col_Tax2Amount.Visible = GlobalFunctions.blnTAX2inService;
                col_Tax2Perc.Visible = GlobalFunctions.blnTAX2inService;
                //col_FK_TAX3SlabID.Visible=GlobalFunctions.blnTAX3SlabID;
                col_Tax3Amount.Visible = GlobalFunctions.blnTAX3inService;
                col_Tax3Perc.Visible = GlobalFunctions.blnTAX3inService;
                // col_AddnlTaxPerc.Visible = GlobalFunctions.blnAddnlTaxPerc;
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
                //col_FK_AddnlTaxSlabID.Visible=GlobalFunctions.blnAddnlTaxSlabID;
                col_Tax1Amount.HeaderText = GlobalFunctions.Tax1Caption + " " + MessageKeys.MsgAmount;
                col_Tax2Amount.HeaderText = GlobalFunctions.Tax2Caption + " " + MessageKeys.MsgAmount;
                col_Tax3Amount.HeaderText = GlobalFunctions.Tax3Caption + " " + MessageKeys.MsgAmount;
                col_Tax1Perc.HeaderText = GlobalFunctions.Tax1Caption + " %";
                col_Tax2Perc.HeaderText = GlobalFunctions.Tax2Caption + " %";
                col_Tax3Perc.HeaderText = GlobalFunctions.Tax3Caption + " %";

                col_InclusiveRate.Visible = GlobalFunctions.blnInclusiveRateInPurchase;

                if (GlobalFunctions.blnGSTinService)
                {
                    col_SGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_SGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_IGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_IGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_CGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                    col_CGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                }
                else
                {
                    col_SGSTAmount.Visible = false;
                    col_SGSTPerc.Visible = false;
                    col_IGSTAmount.Visible = false;
                    col_IGSTPerc.Visible = false;
                    col_CGSTAmount.Visible = false;
                    col_CGSTPerc.Visible = false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void ApplyGridStyles()
        {
            try
            {
                col_Qty.DefaultCellStyle.Format = QtyFormat;
                col_Rate.DefaultCellStyle.Format = NumberFormat;
                col_Amount.DefaultCellStyle.Format = NumberFormat;
                col_DeductionPerc.DefaultCellStyle.Format = NumberFormat;
                col_DeductionAmount.DefaultCellStyle.Format = NumberFormat;
                col_TotalTax.DefaultCellStyle.Format = NumberFormat;
                col_NetAmount.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscountPerc.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TotalDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TaxableAmount.DefaultCellStyle.Format = NumberFormat;
                col_CGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_CGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_SGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_SGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_IGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_IGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_VATPerc.DefaultCellStyle.Format = NumberFormat;
                col_VATAmount.DefaultCellStyle.Format = NumberFormat;
                col_ExcisePerc.DefaultCellStyle.Format = NumberFormat;
                col_ExciseAmount.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Amount.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxPerc.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxAmount.DefaultCellStyle.Format = NumberFormat;
                col_InclusiveRate.DefaultCellStyle.Format = NumberFormat;

            }
            catch (Exception)
            {

                throw;
            }

        }
        private void fillService(int _ServiceID)
        {
            ExtraServiceDTLs cesd = getCurrent();
            if (cesd != null)
            {
                ExtraServices service = dbh.ExtraServices.Where(x => x.id == _ServiceID).Single();
                dgDetails.CurrentRow.Cells[col_Service.Name].Value = service.Name.ToString();
                dgDetails.CurrentRow.Cells[col_Code.Name].Value = service.Code.ToString();

                cesd.FK_ExtraServiceID = _ServiceID;
                cesd.Rate = service.Rate / ExRate;
                cesd.InclusiveRate = cesd.Rate;
            }
            dgDetails.CurrentCell = MoveForward(dgDetails.CurrentCell);


        }
                

        private DataGridViewCell MoveForward(DataGridViewCell _currentCell)
        {
            int row_index = _currentCell.OwningRow.Index;
            int col_index = _currentCell.OwningColumn.Index;
            DataGridViewCell cell = dgDetails.Rows[row_index].Cells[col_index + 1];
            if (cell.Visible && cell.ReadOnly == false)
            {
                return cell;
            }
            else
            {
                return MoveForward(cell);
            }
        }

        #endregion
    }
}
