﻿namespace atACC.HTL.Transactions
{
    partial class GroupCheckInPaymentView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroupCheckInPaymentView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblBalance = new atACCFramework.UserControls.atNumericLabel();
            this.lblBookingAmountCap = new atACCFramework.UserControls.atLabel();
            this.lblBalanceCap = new atACCFramework.UserControls.atLabel();
            this.lblBillAmount = new atACCFramework.UserControls.atNumericLabel();
            this.btnOK = new atACCFramework.UserControls.atButton();
            this.lblPayments = new atACCFramework.UserControls.atNumericLabel();
            this.pnlBottom = new atACCFramework.UserControls.atPanel();
            this.lblPaymentCap = new atACCFramework.UserControls.atLabel();
            this.dgPayment = new atACCFramework.UserControls.atGridView();
            this.colMode = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colAccount = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colInstrumentStatus = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colInstrumentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCardType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colInstrumentDate = new atACCFramework.UserControls.DataGridViewDateTimeColumn();
            this.colAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColPaymentTerminal = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.pnlCenter = new atACCFramework.UserControls.atPanel();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.bindPayment = new System.Windows.Forms.BindingSource(this.components);
            this.pnlBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPayment)).BeginInit();
            this.pnlCenter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindPayment)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.TabStop = false;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // lblBalance
            // 
            resources.ApplyResources(this.lblBalance, "lblBalance");
            this.lblBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBalance.ForeColor = System.Drawing.Color.Black;
            this.lblBalance.Format = "N2";
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.RequiredField = false;
            this.lblBalance.UseCompatibleTextRendering = true;
            this.lblBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBookingAmountCap
            // 
            resources.ApplyResources(this.lblBookingAmountCap, "lblBookingAmountCap");
            this.lblBookingAmountCap.Name = "lblBookingAmountCap";
            this.lblBookingAmountCap.RequiredField = false;
            // 
            // lblBalanceCap
            // 
            resources.ApplyResources(this.lblBalanceCap, "lblBalanceCap");
            this.lblBalanceCap.Name = "lblBalanceCap";
            this.lblBalanceCap.RequiredField = false;
            // 
            // lblBillAmount
            // 
            resources.ApplyResources(this.lblBillAmount, "lblBillAmount");
            this.lblBillAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBillAmount.ForeColor = System.Drawing.Color.Black;
            this.lblBillAmount.Format = "N2";
            this.lblBillAmount.Name = "lblBillAmount";
            this.lblBillAmount.RequiredField = false;
            this.lblBillAmount.UseCompatibleTextRendering = true;
            this.lblBillAmount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnOK.FlatAppearance.BorderSize = 0;
            this.btnOK.ForeColor = System.Drawing.Color.White;
            this.btnOK.Name = "btnOK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblPayments
            // 
            resources.ApplyResources(this.lblPayments, "lblPayments");
            this.lblPayments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPayments.ForeColor = System.Drawing.Color.Black;
            this.lblPayments.Format = "N2";
            this.lblPayments.Name = "lblPayments";
            this.lblPayments.RequiredField = false;
            this.lblPayments.UseCompatibleTextRendering = true;
            this.lblPayments.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            this.pnlBottom.BackColor = System.Drawing.SystemColors.Window;
            this.pnlBottom.Controls.Add(this.btnOK);
            this.pnlBottom.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlBottom.Name = "pnlBottom";
            // 
            // lblPaymentCap
            // 
            resources.ApplyResources(this.lblPaymentCap, "lblPaymentCap");
            this.lblPaymentCap.Name = "lblPaymentCap";
            this.lblPaymentCap.RequiredField = false;
            // 
            // dgPayment
            // 
            resources.ApplyResources(this.dgPayment, "dgPayment");
            this.dgPayment.AllowUserToOrderColumns = true;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgPayment.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgPayment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPayment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgPayment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMode,
            this.colAccount,
            this.colInstrumentStatus,
            this.colInstrumentNo,
            this.colCardType,
            this.colInstrumentDate,
            this.colAmount,
            this.ColPaymentTerminal});
            this.dgPayment.EnableHeadersVisualStyles = false;
            this.dgPayment.EnterKeyNavigation = false;
            this.dgPayment.LastKey = System.Windows.Forms.Keys.None;
            this.dgPayment.Name = "dgPayment";
            this.dgPayment.sGridID = null;
            this.dgPayment.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgPayment_CellBeginEdit);
            this.dgPayment.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPayment_CellEndEdit);
            this.dgPayment.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgPayment_CellValidating);
            this.dgPayment.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgPayment_DataError);
            this.dgPayment.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgPayment_EditingControlShowing);
            this.dgPayment.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgPayment_RowsRemoved);
            // 
            // colMode
            // 
            this.colMode.DataPropertyName = "FK_MVInstrumentTypeID";
            this.colMode.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.colMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.colMode, "colMode");
            this.colMode.Name = "colMode";
            // 
            // colAccount
            // 
            this.colAccount.DataPropertyName = "FK_AccountID";
            this.colAccount.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.colAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.colAccount, "colAccount");
            this.colAccount.Name = "colAccount";
            this.colAccount.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colAccount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colInstrumentStatus
            // 
            this.colInstrumentStatus.DataPropertyName = "FK_MasterTypeID";
            this.colInstrumentStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.colInstrumentStatus, "colInstrumentStatus");
            this.colInstrumentStatus.Name = "colInstrumentStatus";
            // 
            // colInstrumentNo
            // 
            this.colInstrumentNo.DataPropertyName = "InstrumentNo";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colInstrumentNo.DefaultCellStyle = dataGridViewCellStyle11;
            resources.ApplyResources(this.colInstrumentNo, "colInstrumentNo");
            this.colInstrumentNo.Name = "colInstrumentNo";
            this.colInstrumentNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colInstrumentNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colCardType
            // 
            this.colCardType.DataPropertyName = "FK_MVCardType";
            this.colCardType.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.colCardType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.colCardType, "colCardType");
            this.colCardType.Name = "colCardType";
            // 
            // colInstrumentDate
            // 
            this.colInstrumentDate.DataPropertyName = "InstrumentDate";
            resources.ApplyResources(this.colInstrumentDate, "colInstrumentDate");
            this.colInstrumentDate.Name = "colInstrumentDate";
            this.colInstrumentDate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colInstrumentDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colAmount
            // 
            this.colAmount.DataPropertyName = "Payment";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colAmount.DefaultCellStyle = dataGridViewCellStyle12;
            resources.ApplyResources(this.colAmount, "colAmount");
            this.colAmount.Name = "colAmount";
            // 
            // ColPaymentTerminal
            // 
            this.ColPaymentTerminal.DataPropertyName = "FK_PaymentTerminalID";
            this.ColPaymentTerminal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.ColPaymentTerminal, "ColPaymentTerminal");
            this.ColPaymentTerminal.Name = "ColPaymentTerminal";
            // 
            // pnlCenter
            // 
            resources.ApplyResources(this.pnlCenter, "pnlCenter");
            this.pnlCenter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlCenter.Controls.Add(this.dgPayment);
            this.pnlCenter.Controls.Add(this.lblBalance);
            this.pnlCenter.Controls.Add(this.lblBookingAmountCap);
            this.pnlCenter.Controls.Add(this.lblBalanceCap);
            this.pnlCenter.Controls.Add(this.lblBillAmount);
            this.pnlCenter.Controls.Add(this.lblPayments);
            this.pnlCenter.Controls.Add(this.lblPaymentCap);
            this.pnlCenter.Name = "pnlCenter";
            // 
            // lblHeading
            // 
            resources.ApplyResources(this.lblHeading, "lblHeading");
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            // 
            // GroupCheckInPaymentView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlCenter);
            this.Controls.Add(this.lblHeading);
            this.Name = "GroupCheckInPaymentView";
            this.pnlBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgPayment)).EndInit();
            this.pnlCenter.ResumeLayout(false);
            this.pnlCenter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindPayment)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private atACCFramework.UserControls.atNumericLabel lblBalance;
        private atACCFramework.UserControls.atLabel lblBookingAmountCap;
        private atACCFramework.UserControls.atLabel lblBalanceCap;
        private atACCFramework.UserControls.atNumericLabel lblBillAmount;
        private atACCFramework.UserControls.atButton btnOK;
        private atACCFramework.UserControls.atNumericLabel lblPayments;
        private atACCFramework.UserControls.atPanel pnlBottom;
        private atACCFramework.UserControls.atLabel lblPaymentCap;
        private atACCFramework.UserControls.atGridView dgPayment;
        private atACCFramework.UserControls.atPanel pnlCenter;
        private atACCFramework.UserControls.atLabel lblHeading;
        private System.Windows.Forms.BindingSource bindPayment;
        private System.Windows.Forms.DataGridViewComboBoxColumn colMode;
        private System.Windows.Forms.DataGridViewComboBoxColumn colAccount;
        private System.Windows.Forms.DataGridViewComboBoxColumn colInstrumentStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInstrumentNo;
        private System.Windows.Forms.DataGridViewComboBoxColumn colCardType;
        private atACCFramework.UserControls.DataGridViewDateTimeColumn colInstrumentDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAmount;
        private System.Windows.Forms.DataGridViewComboBoxColumn ColPaymentTerminal;
    }
}