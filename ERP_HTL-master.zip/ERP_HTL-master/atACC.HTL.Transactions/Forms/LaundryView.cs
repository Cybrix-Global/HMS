﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using System.Data.SqlClient;
using atACCFramework.UserControls;
using atACC.HTL.Transactions.Sub_Forms;
using System.Drawing;

namespace atACC.HTL.Transactions
{
    public partial class LaundryView : SearchFormBase2
    {
        #region Private Variable
        LaundryHDR entLaundryHDR;
        List<LaundryHDR> entLaundryHDRList;
        List<LaundryDTL> entOldLaundryDTLList;
        List<LaundryDTL> entLaundryDTLList;
        List<LaundryPayment> entLaundryPaymentList;
        List<LaundryPayment> entOldLaundryPaymentList;
        GuestDTLs e_GuestDTLs;
        Guests entGuest;
        List<Guests> entGuestlist;
        atACC.HTL.ORM.AccountLedger Ledger;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        DataTable dt = new DataTable();
        CommonLibClasses objLib;
        ToolTip tooltip;
        List<Employee> entEmployee;
        List<atACC.HTL.ORM.AccountLedger> entGuestAccounts;
        DataGridViewTextBoxEditingControl textbox;
        DataGridViewComboBoxEditingControl cb;
        string sKeyChar = "";
        string NumberFormat, sQtyFormat;
        int iGuestID, _OnLoad, iContentId;
        decimal TotalAmount, Total, AdvanceAmount;
        VoucherHDR entVoucherHdrPayment;
        VoucherHDR entVoucherHdr;
        decimal previousExRate;
        List<CurrencyClass> entCurrencys;
        bool blnSanctioningRequired = false;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;
        #endregion

        #region Constructor
        public LaundryView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            objLib = new CommonLibClasses();
            aniHelper = new ANIHelper();
            ShareButton.Visible = false;
        }
        #endregion

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(8);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion
                
        #region Private Methods
        private void ApplyExRate()
        {
            decimal dcCurrentExRate = txtExRate.Value;
            decimal dcExRateChange = ((previousExRate == 0 ? 1 : previousExRate) / (dcCurrentExRate == 0 ? 1 : dcCurrentExRate));
            foreach (LaundryDTL serviceDtl in entLaundryDTLList)
            {
                if (serviceDtl.FK_ServiceID != null)
                {
                    serviceDtl.Rate = dcExRateChange * serviceDtl.Rate;
                    serviceDtl.InclusiveRate = dcExRateChange * serviceDtl.InclusiveRate;
                    serviceDtl.Amount = dcExRateChange * serviceDtl.Amount;                    
                    serviceDtl.TaxableAmount = dcExRateChange * serviceDtl.TaxableAmount;
                    serviceDtl.SlabDiscount = dcExRateChange * serviceDtl.SlabDiscount;
                    serviceDtl.DeductionAmount = dcExRateChange * serviceDtl.DeductionAmount;
                    serviceDtl.ExciseAmount = dcExRateChange * serviceDtl.ExciseAmount;
                    serviceDtl.Tax1Amount = dcExRateChange * serviceDtl.Tax1Amount;
                    serviceDtl.Tax2Amount = dcExRateChange * serviceDtl.Tax2Amount;
                    serviceDtl.Tax3Amount = dcExRateChange * serviceDtl.Tax3Amount;
                    serviceDtl.AddnlTaxAmount = dcExRateChange * serviceDtl.AddnlTaxAmount;
                    serviceDtl.VATAmount = dcExRateChange * serviceDtl.VATAmount;
                    serviceDtl.CGSTAmount = dcExRateChange * serviceDtl.CGSTAmount;
                    serviceDtl.SGSTAmount = dcExRateChange * serviceDtl.SGSTAmount;
                    serviceDtl.IGSTAmount = dcExRateChange * serviceDtl.IGSTAmount;
                    serviceDtl.NetAmount = dcExRateChange * serviceDtl.NetAmount;
                }
            }

            foreach (LaundryPayment payment in entLaundryPaymentList)
            {
                payment.Payment = dcExRateChange * payment.Payment;
            }
            
            CalcNetTotal();
            previousExRate = txtExRate.Value;
        }
        private void SetDefaultComboValues()
        {
            ActiveControl = cmbCurrency;
            cmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;
        }
        private void PostVoucher()
        {
            bool blnNewRecord = true;
            bool blnNewPaymentRecord = true;
            entVoucherHdrPayment = new VoucherHDR();            
            entVoucherHdr = new VoucherHDR();
            if (!NewRecord)
            {
                if ((entLaundryHDR.FK_VoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdr = dbh.VoucherHDRs.Where(x => x.id == entLaundryHDR.FK_VoucherHDRID).SingleOrDefault();
                    blnNewRecord = false;
                }
                if ((entLaundryHDR.FK_PaymentVoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdrPayment = dbh.VoucherHDRs.Where(x => x.id == entLaundryHDR.FK_PaymentVoucherHDRID).SingleOrDefault();
                    blnNewPaymentRecord = false;
                }
                
            }

            int iCashorPartyAccountID = cmbGuest.Tag.ToInt32();
            bool blnPartyUnderCashInHand = aniHelper.isUnderCashInHand(iCashorPartyAccountID);
            string sCashorPartyName = aniHelper.getLedNameFromAccountID(iCashorPartyAccountID);
            string sLaundryAccountName = aniHelper.getLedNameFromAccountID(GlobalProperties.LaundryAccountID);

            decimal dcmGrandTotal = txtNetTotal.Value;
            decimal dcExRate = txtExRate.Value;
            decimal dcmOtherPaymentSum = entLaundryPaymentList.Where(x => x.isCash == false).Sum(x => x.Payment).ToDecimal();
            decimal dcmPartyAmount = blnPartyUnderCashInHand ? dcmGrandTotal - dcmOtherPaymentSum : dcmGrandTotal;

            //Voucher Hdr Entry
            GlobalMethods.DecorateVoucherHdr(entVoucherHdr, iContextID, "", dtVoucherDate.Value
                , cmbCurrency.SelectedValue.ToString().ToInt32(), lblGrandTotal.Value, txtVoucherNo.Text, "H-LAU");

            //Voucher DTL Entry
            List<VoucherDTL> entVoucherDtls = new List<VoucherDTL>();

            // Debit Bill Amount to Party or Cash Account
            GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, iCashorPartyAccountID, sLaundryAccountName, dcExRate, dcmPartyAmount, "", txtRemarks.Text);
            #region ExtraService Voucher DTL
            if (entLaundryDTLList.Count > 0)
            {
                decimal dcGross = entLaundryDTLList.Sum(x => x.Amount).ToDecimal();
                decimal dcDiscount = entLaundryDTLList.Sum(x => x.DeductionAmount + x.SlabDiscount).ToDecimal();
                decimal dcTax1 = entLaundryDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                decimal dcTax2 = entLaundryDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                decimal dcTax3 = entLaundryDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                decimal dcAddnlTax = entLaundryDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                decimal dcExciseDuty = entLaundryDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                decimal dcVAT = entLaundryDTLList.Sum(x => x.VATAmount).ToDecimal();
                decimal dcCGST = entLaundryDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                decimal dcSGST = entLaundryDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                decimal dcIGST = entLaundryDTLList.Sum(x => x.IGSTAmount).ToDecimal();

                //Credit Gross Amount to Laundry Account
                if (dcGross != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.LaundryAccountID, sCashorPartyName, dcExRate, dcGross * (-1), "", txtRemarks.Text);
                //Credit Tax1 
                if (dcTax1 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax1AccountID, sCashorPartyName, dcExRate, dcTax1 * (-1), "", txtRemarks.Text);
                //Credit Tax2
                if (dcTax2 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax2AccountID, sCashorPartyName, dcExRate, dcTax2 * (-1), "", txtRemarks.Text);
                //Credit Tax3
                if (dcTax3 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax3AccountID, sCashorPartyName, dcExRate, dcTax3 * (-1), "", txtRemarks.Text);
                //Credit Excise Duty
                if (dcExciseDuty != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExciseDutyAccountID, sCashorPartyName, dcExRate, dcExciseDuty * (-1), "", txtRemarks.Text);
                //Debit Total Discount 
                if (txtTotalDiscount.Value != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.DiscountAccountID, sCashorPartyName, dcExRate, txtTotalDiscount.Value, "", txtRemarks.Text);
                //Credit Vat
                if (dcVAT != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.VATAccountID, sCashorPartyName, dcExRate, dcVAT * (-1), "", txtRemarks.Text);
                //Credit CGST
                if (dcCGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.CGSTAccountID, sCashorPartyName, dcExRate, dcCGST * (-1), "", txtRemarks.Text);
                //Credit SGST
                if (dcSGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.SGSTAccountID, sCashorPartyName, dcExRate, dcSGST * (-1), "", txtRemarks.Text);
                //Credit IGST
                if (dcIGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.IGSTAccountID, sCashorPartyName, dcExRate, dcIGST * (-1), "", txtRemarks.Text);
                //Credit
                if (dcAddnlTax != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.AdditionalTaxAccountID, sCashorPartyName, dcExRate, dcAddnlTax * (-1), "", txtRemarks.Text);
            }
            #endregion
            List<AnalysisDTL> entAnalysisDTLs = new List<AnalysisDTL>();
            GlobalMethods.PostVoucher(blnNewRecord, entVoucherHdr, entVoucherDtls, ref dbh, entAnalysisDTLs);




            #region Payment Posting

            List<VoucherDTL> entVoucherDtlsPayment = new List<VoucherDTL>();
            if (entLaundryPaymentList.Count() > 0) // Payment Found
            {
                if (entVoucherHdrPayment.id == 0)
                {
                    entVoucherHdrPayment.id = -1;
                }
                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdrPayment, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-LAU-PAY");

                foreach (LaundryPayment payment in entLaundryPaymentList)
                {
                    #region isCash
                    if (payment.isCash.toBool()) // Cash Payment
                    {
                        if (!blnPartyUnderCashInHand)
                        {
                            int iCashAccountID = payment.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)payment.FK_AccountID;
                            string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                            // Debit to Cash Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashAccountID, sCashorPartyName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            // Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", MessageKeys.MsgPayment);
                        }
                    }
                    #endregion
                    #region Non Cash
                    else
                    {
                        int iSelectedBankAccount = (int)payment.FK_AccountID;
                        string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                        if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                        {
                            string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);

                            // Debit to Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sLaundryAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", MessageKeys.MsgPayment);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                        {
                            string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);

                            //Debit to Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sLaundryAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                            || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                        {
                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCashorPartyName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                    }
                    #endregion
                }
                GlobalMethods.PostVoucher(blnNewPaymentRecord, entVoucherHdrPayment, entVoucherDtlsPayment, ref dbh, entAnalysisDTLs);
            }
            #endregion
            
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Laundry, 0, 0, txtVoucherNo.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateLaundryEnt()
        {
            entLaundryHDRList = dbh.LaundryHDRs.ToList();
        }
        private void PopulateCombos()
        {
            try
            {
                cmbEmployee.DataSource = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.ServiceMan || x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }

                //cmbVoucherDiscount.DataSource = db.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMVMTVoucherMode.v).ToList();
                //cmbVoucherDiscount.DisplayMember = "Name";
                //cmbVoucherDiscount.ValueMember = "id";
                //cmbVoucherDiscount.SelectedIndex = -1;

                cmbRoom.DataSource = dbh.Rooms.Where(x => x.IsHall ==false).ToList();
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
                cmbRoom.SelectedIndex = -1;

                #region Currency                
                cmbCurrency.DataSource = entCurrencys;
                cmbCurrency.DisplayMember = "CurrencyName";
                cmbCurrency.ValueMember = "id";
                #endregion

            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void FnClearAll()
        {
            entLaundryHDR = new LaundryHDR();
            entLaundryDTLList = new List<LaundryDTL>();
            entOldLaundryDTLList = new List<LaundryDTL>();

            entLaundryPaymentList = new List<LaundryPayment>();
            entOldLaundryPaymentList = new List<LaundryPayment>();
        }
        private void PopulateGuest()
        {
            int iFlagId = 1, iRoomId = 0, iGuest=0;
            DateTime iDate = dtVoucherDate.Value;
           
            SqlHelper _sql = new SqlHelper();
            iRoomId = cmbRoom.SelectedValue.ToInt32();
            _sql.SPName = "SPGetGuestInfo";
            SqlParameter paramFlag = new SqlParameter("Flag", iFlagId);
            SqlParameter paramFlag2 = new SqlParameter("RoomId", iRoomId);
            SqlParameter paramFlag3 = new SqlParameter("VoucherDate", iDate);

            _sql.SqlParameters = new List<SqlParameter>();
            _sql.SqlParameters.Add(paramFlag);
            _sql.SqlParameters.Add(paramFlag2);
            _sql.SqlParameters.Add(paramFlag3);
          
            dt = _sql.ExecuteProcedure().Tables[0];
            cmbGuest.DataSource = dt;
            cmbGuest.DisplayMember = "Name";
            cmbGuest.ValueMember = "id";
            cmbGuest.SelectedIndex = -1;
            ClearGuestInfo();
            if (dt.Rows.Count == 1)
            {
                cmbGuest.SelectedIndex = 0;
            }
            else if (dt.Rows.Count == 0)
            {
                cmbGuest.SelectedIndex = -1;
                cmbGuest.Text = "";
            }
            LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
        }
        private void CalcGrandTotal()
        {
            lblGrandTotal.Value = txtNetTotal.Value;
            txtBalance.Value = lblGrandTotal.Value - txtPayment.Value;
        }
        private bool ValidateRoomRate()
        {
            try
            {
                if (cmbGuest.Text.Trim() == "") { errProvider.SetError(cmbGuest, "Choose Guest"); cmbGuest.Focus(); return false; }
                if (cmbRoom.Text.Trim() == "") { errProvider.SetError(cmbRoom, "Choose Room "); cmbRoom.Focus(); return false; }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void CalcNetTotal()
        {
            txtGross.Value = entLaundryDTLList.Sum(x => x.Amount).ToDecimal();
            lblTotQty.Value = entLaundryDTLList.Sum(x => x.Qty).ToDecimal();
            txtTotalDiscount.Value = entLaundryDTLList.Sum(x => x.TotalDiscount).ToDecimal();
            lblTotalTax.lblTax1 = entLaundryDTLList.Sum(x => x.Tax1Amount).ToDecimal();
            lblTotalTax.lblTax2 = entLaundryDTLList.Sum(x => x.Tax2Amount).ToDecimal();
            lblTotalTax.lblTax3 = entLaundryDTLList.Sum(x => x.Tax3Amount).ToDecimal();
            lblTotalTax.lblAddnlTax = entLaundryDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
            lblTotalTax.lblExciseDuty = entLaundryDTLList.Sum(x => x.ExciseAmount).ToDecimal();
            lblTotalTax.lblVAT = entLaundryDTLList.Sum(x => x.VATAmount).ToDecimal();
            lblTotalTax.lblCGST = entLaundryDTLList.Sum(x => x.CGSTAmount).ToDecimal();
            lblTotalTax.lblSGST = entLaundryDTLList.Sum(x => x.SGSTAmount).ToDecimal();
            lblTotalTax.lblIGST = entLaundryDTLList.Sum(x => x.IGSTAmount).ToDecimal();
            txtTotalTax.Value = entLaundryDTLList.Sum(x => x.TotalTax).ToDecimal();
            txtNetTotal.Value = (txtGross.Value + txtTotalTax.Value) - txtTotalDiscount.Value;

            CalcGrandTotal();
        }
        private void ShowToolTip()
        {

            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbGuest, "Select Guest");
                tooltip.SetToolTip(cmbRoom, "Select Room ");
                tooltip.SetToolTip(cmbEmployee, "Select Employee ");
            }
            catch (Exception)
            {
                throw;
            }
        }        
        private void InitEntities()
        {                        
            entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).ToList();
        }
        private void InitControls()
        {
            dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
            dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();

            dtpArrivalDate.SetCustomFormat();
            dtpDepartureDate.SetCustomFormat();
            dtpArrivalDate.DisbaleShortDateTimeFormat = true;
            dtpDepartureDate.DisbaleShortDateTimeFormat = true;
        }
        private void LoadSettings()
        {
            NumberFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimals;
            sQtyFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimalsQty;
            txtVoucherDiscAmount.Format = NumberFormat;
            txtGross.Format = NumberFormat;
            lblTotQty.Format = sQtyFormat;


            txtNetTotal.Format = NumberFormat;
            txtPayment.Format = NumberFormat;

            txtBalance.Format = NumberFormat;
            lblGrandTotal.Format = NumberFormat;
            txtExRate.Format = NumberFormat;
            lblTotalTax.Format = NumberFormat;
            txtDeductionPerc.Format = NumberFormat;

            grpDiscountVoucher.Visible = GlobalFunctions.blnDiscountVoucherInSalesTransactions;

            lblCurrencyCap.Visible = GlobalFunctions.blnMultiCurrency;
            cmbCurrency.Visible = GlobalFunctions.blnMultiCurrency;
            lblExRateCap.Visible = GlobalFunctions.blnMultiCurrency;
            txtExRate.Visible = GlobalFunctions.blnMultiCurrency;
        }
        private void CalcPaymentTotal()
        {
            txtPayment.Value = entLaundryPaymentList.Sum(x => x.Payment).ToDecimal();
            txtBalance.Value = txtNetTotal.Value - txtPayment.Value;
        }
        private void fillServiceByCodeInCurrentRow()
        {
            int _ServiceID = 0;
            if (dgDetails.CurrentCell.Value == null) { return; }
            string sCode = dgDetails.CurrentCell.Value.ToString();
            if (dbh.ExtraServices.Any(x => x.Code == sCode))
            {
                _ServiceID = dbh.ExtraServices.Where(x => x.Code == textbox.Text).First().id;
                fillService(_ServiceID);

            }
            else
            {
                dgDetails.CurrentCell.Value = "";
                if (dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value == null) { return; }
                _ServiceID = dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value.ToString().ToInt32();
                fillService(_ServiceID);
            }
        }
        private bool IsExtraSericeChanged()
        {
            if (dgDetails.CurrentCell != null && dgDetails.CurrentCell.Tag != null && dgDetails.CurrentCell.Value != null)
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name)
                    return dgDetails.CurrentCell.Value.ToString2() != dgDetails.CurrentCell.Tag.ToString2();
            }
            return false;
        }
        private void CalculateSlab(bool blnUpdateDeductionAmount, LaundryDTL pdtl)
        {
            try
            {
                if (pdtl != null)
                {
                    List<Slab> slabs = null;
                    if (IsExtraSericeChanged())
                    {
                        int iServiceID = pdtl.FK_ServiceID.ToInt32();
                        slabs = (from rs in dbh.ExtraServiceSlabs
                                 join s in dbh.Slabs on rs.FK_SlabID equals s.id
                                 where rs.FK_ExtraServiceID == iServiceID
                                 select s).ToList();
                    }
                    pdtl.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcRowAmount(LaundryDTL pdtl)
        {            
            if (pdtl != null)
            {
                pdtl.Amount = pdtl.Rate * pdtl.Qty;
                bool blnUpdateDeductionAmount = dgDetails.CurrentCell.OwningColumn.Name != col_DeductionAmount.Name;
                CalculateSlab(blnUpdateDeductionAmount, pdtl);
                CalcNetTotal();
            }
        }
        private void CalcGrand(bool blnUpdateAddDiscAmount = true)
        {
            if (entLaundryDTLList.Count > 0)
            {
                txtGross.Value = entLaundryDTLList.Sum(x => x.NetAmount).ToDecimal();
                lblTotQty.Value = entLaundryDTLList.Sum(x => x.Qty).ToDecimal();


                txtNetTotal.Value = txtGross.Value - txtVoucherDiscAmount.Value;
                lblGrandTotal.Value = entLaundryDTLList.Sum(x => x.NetAmount).ToDecimal();
                if (GlobalFunctions.strRoundoffPurchases != "")
                {
                    decimal dcBeforeRoundOff = lblGrandTotal.Value;
                    lblGrandTotal.Value = Math2.Round(lblGrandTotal.Value, GlobalFunctions.strRoundoffPurchases.ToInt32());

                }

            }
        }
        private void ClearGuestInfo()
        {

            txtMobile.Text = "";
            txtAdd1.Text = "";
            txtDeductionPerc.Text = "";
            dtpArrivalDate.Value = System.DateTime.Now;
            dtpDepartureDate.Value = System.DateTime.Now;
            entGuest = new Guests();
            e_GuestDTLs = new GuestDTLs();
            cmbGuest.Tag = null;
            DefaultCreditCard = 0;
        }
        private void LoadGuestInfo(Int64 Guestid)
        {
            try
            {
                if (dt.Rows.Count > 0)
                {
                    DataView dv = new DataView(dt, "id='" + Guestid + "'", "id", DataViewRowState.OriginalRows);
                    if (dv.ToTable().Rows.Count > 0)
                    {
                        entGuest = dbh.Guests.Where(x => x.id == Guestid).SingleOrDefault();
                        e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == Guestid).SingleOrDefault();
                        txtMobile.Text = dv.ToTable().Rows[0]["Mobile"].ToString();
                        txtAdd1.Text = dv.ToTable().Rows[0]["Address1"].ToString();
                        dtpArrivalDate.Text = dv.ToTable().Rows[0]["ArrivalDate"].ToString();
                        dtpDepartureDate.Text = dv.ToTable().Rows[0]["DepartureDate"].ToString();
                        cmbGuest.Tag = dv.ToTable().Rows[0]["FK_BillingAccountID"].ToInt32();
                        if (entGuest != null && NewRecord)
                        {
                            txtDeductionPerc.Value = dv.ToTable().Rows[0]["DiscountPerc"].ToString().ToDecimal();
                            cmbCurrency.SelectedValue = entGuest.FK_CurrencyHDRID.ToInt32();
                        }
                        if (e_GuestDTLs != null)
                        {
                            DefaultCreditCard = e_GuestDTLs.FK_CreditCardType.ToInt32();
                            DefaultCreditCardNumber = e_GuestDTLs.CreditCardNo;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void SetDefaultDateAndTime()
        {
            try
            {
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Public Methods
        public override void LoadVouchers()
        {
            string sTempVno = txtVoucherNo.Text;
            dbh = atHotelContext.CreateContext();
            List<UpDownData> _Vouchers = dbh.LaundryHDRs.OrderByDescending(x => x.id)
                .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
            txtVoucherNo.Items.Clear();
            txtVoucherNo.DataSource = _Vouchers;
            if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
            txtVoucherNo.Text = sTempVno;
        }
        public override void ReLoadData(string VoucherNo)
        {
            LaundryHDR laundryHDR = dbh.LaundryHDRs.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (laundryHDR != null)
            {
                ReLoadData(laundryHDR.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                #region Laundry Data
                entLaundryHDR = dbh.LaundryHDRs.Where(x => x.id == ID).SingleOrDefault();
                if (entLaundryHDR != null)
                {

                    txtVoucherNo.Text = entLaundryHDR.VoucherNo;
                    dtVoucherDate.Text = entLaundryHDR.VoucherDate.ToString();

                    cmbRoom.SelectedValue = entLaundryHDR.FK_RoomID;
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = entLaundryHDR.FK_GuestID;                    
                    txtPayment.Text = entLaundryHDR.Payment.ToString();
                    lblGrandTotal.Value = entLaundryHDR.GrandTotal.ToDecimal();
                    if (entLaundryHDR.FK_EmployeeID != null)
                    {
                        cmbEmployee.SelectedValue = entLaundryHDR.FK_EmployeeID;
                    }
                    txtRemarks.Text = entLaundryHDR.Remarks;
                    txtVoucherDiscAmount.Value = entLaundryHDR.VoucherDiscountAmount.ToDecimal();
                    cmbVoucherDiscount.SelectedValue = entLaundryHDR.FK_VoucherDiscountID;
                    cmbCurrency.SelectedValue = entLaundryHDR.FK_CurrencyHdrID;
                    txtExRate.Value = entLaundryHDR.ExRate.ToDecimal();
                    #endregion
                    #region Reload Extra Service Details


                    var CurrentDtl = (from pdtl in dbh.LaundryDTLs
                                      join prd in dbh.ExtraServices on pdtl.FK_ServiceID equals prd.id
                                      where pdtl.FK_LaundryID == ID
                                      select new { pdtl, prd }).ToList();
                    CurrentDtl.ForEach(x =>
                    {
                        x.pdtl.ServiceCode = x.prd.Code;
                        x.pdtl.ServiceName = x.prd.Name;
                    });
                    entLaundryDTLList = CurrentDtl.Select(x => x.pdtl).OrderBy(x => x.id).ToList();
                    entOldLaundryDTLList = new List<LaundryDTL>(entLaundryDTLList);
                    #endregion
                    #region Reload Payment Details
                    entLaundryPaymentList = dbh.LaundryPayments.Where(x => x.FK_LaundryID == entLaundryHDR.id).ToList();
                    entOldLaundryPaymentList = new List<LaundryPayment>(entLaundryPaymentList);
                    #endregion
                    BindGrid();
                    LoadFullSerialNo();
                    CalcNetTotal();
                    CalcPaymentTotal();
                    CalcGrandTotal();


                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form event
        private void txtExtraServices_TextChanged(object sender, EventArgs e)
        {
            CalcNetTotal();
            CalcGrandTotal();
        }
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    dgDetails.Focus();
                }
                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtVoucherDiscountAmount_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }  
            }
            catch (Exception)
            {
                throw;
            }
        }        
        private void cmbGuest_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsActiveControl(sender)) { return; }

                ClearGuestInfo();
                LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
                CalcNetTotal();

            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void btnPayment_Click(object sender, EventArgs e)
        {
            decimal PayAmt = txtNetTotal.Value;
            LaundryPaymentView payment = new LaundryPaymentView(entLaundryPaymentList, PayAmt, NumberFormat, DefaultCreditCard,DefaultCreditCardNumber);
            if (payment.ShowDialog() == DialogResult.OK)
            {
                CalcPaymentTotal();
                CalcGrandTotal();
            }
        }
        private void cmbRoom_SelectedValueChanged(object sender, EventArgs e)
        {
            if (_OnLoad > 0)
            {
                PopulateGuest();
            }
        }
        private void dtVoucherDate_ValueChanged(object sender, EventArgs e)
        {
            if (cmbRoom.SelectedValue != null)
                PopulateGuest();
        }
        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurrency.ValueMember == "") { return; }
                if (cmbCurrency.SelectedValue == null) { return; }
                int iCurrencyID = cmbCurrency.SelectedValue.ToString2().ToInt32();

                CurrencyClass entCurrency = entCurrencys.Where(x => x.id == iCurrencyID).Single();
                Company company = dbh.Companies.Single();
                int _sourcecurrencyId = company.FK_Currency.toInt32();
                int _destinationCurrencyID = entCurrency.id;
                if (_sourcecurrencyId == _destinationCurrencyID)
                {
                    txtExRate.Enabled = false;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
                txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                ApplyExRate();
            }
            catch (Exception) { }
        }
        private void txtExRate_Enter(object sender, EventArgs e)
        {
            previousExRate = txtExRate.Value;
        }
        private void txtExRate_KeyUp(object sender, KeyEventArgs e)
        {
            ApplyExRate();
        }
        #endregion

        #region Framework events
        private void LaundryView_atInitialise()
        {
            try
            {                               
                InitEntities();
                InitControls();
                LoadSettings();
                initGridColumns();
                ApplyGridStyles();
                ShowToolTip();
                PopulateCombos();
                SettingsButton.Visible = true;               
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }

        }
        private void LaundryView_atAfterInitialise()
        {
            try
            {                
                _OnLoad = 1;
                LaundryView_atNewClick(null);
                SetDefaultDateAndTime();
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void LaundryView_atNewClick(object source)
        {
            try
            {
                PopulateLaundryEnt();                
                FnClearAll();
                ClearGuestInfo();
                BindGrid();
                SetDefaultComboValues();
                SetDefaultDateAndTime();
                GetSeqNo();
                CalcNetTotal();
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool LaundryView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    dbh = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                #region Voucher Posting
                if (!blnSanctioningRequired)
                {
                    PostVoucher();
                }
                //Extra Services
                if (!blnSanctioningRequired && entLaundryDTLList.Count() > 0)
                {
                    entLaundryHDR.FK_VoucherHDRID = entVoucherHdr.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entLaundryHDR.FK_VoucherHDRID, ref dbh);
                    entLaundryHDR.FK_VoucherHDRID = null;
                }

                //Payment
                if (!blnSanctioningRequired && entLaundryPaymentList.Count() > 0)
                {
                    entLaundryHDR.FK_PaymentVoucherHDRID = entVoucherHdrPayment.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entLaundryHDR.FK_PaymentVoucherHDRID, ref dbh);
                    entLaundryHDR.FK_PaymentVoucherHDRID = null;
                }

                #endregion
                #region LaundryHDR Details
                entLaundryHDR.ContextID = iContextID;
                entLaundryHDR.LoginUserID = GlobalFunctions.LoginUserID;
                entLaundryHDR.LocationID = GlobalFunctions.LoginLocationID;
                entLaundryHDR.VoucherNo = txtVoucherNo.Text;
                entLaundryHDR.VoucherDate = dtVoucherDate.Value;
                entLaundryHDR.FK_GuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                entLaundryHDR.FK_RoomID = cmbRoom.SelectedValue.ToString().ToInt32();
                entLaundryHDR.GrandTotal = txtNetTotal.Text.ToDecimal();
                entLaundryHDR.Payment = txtPayment.Value;
                entLaundryHDR.Remarks = txtRemarks.Text;
                entLaundryHDR.FK_CurrencyHdrID = cmbCurrency.SelectedValue.ToString2().ToInt32();
                entLaundryHDR.ExRate = txtExRate.Value;
                if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
                {
                    entLaundryHDR.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
                }
                else { entLaundryHDR.FK_EmployeeID = null; }
                entLaundryHDR.FK_VoucherDiscountID = null;
                entLaundryHDR.VoucherDiscountAmount = txtVoucherDiscAmount.Text.ToDecimal();
                entLaundryHDR.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entLaundryHDR.Sanctioned = !blnSanctioningRequired;
                entLaundryHDR.Cancelled = false;
                if (NewRecord)
                {
                    dbh.LaundryHDRs.AddObject(entLaundryHDR);
                }
                else
                {
                    entLaundryHDR.ModifiedDate = System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(entLaundryHDR, EntityState.Modified);
                }
                #endregion
                #region Removing Deleted LaundryDTLs
                var d1 = entOldLaundryDTLList.Select(x => new { id = x.id });
                var d2 = entLaundryDTLList.Select(y => new { id = y.id });
                var deletedESDtls = d1.Except(d2);
                foreach (var deletedItem in deletedESDtls)
                {
                    LaundryDTL delItDtl = entOldLaundryDTLList.Where(x => x.id == deletedItem.id).First();
                    dbh.LaundryDTLs.DeleteObject(delItDtl);
                }
                #endregion
                #region Adding or Updating ExtraSevices
                foreach (LaundryDTL ExtraService in bindExtraServiceDTL.List)
                {
                    if (entLaundryHDR.id != null)
                    {
                        ExtraService.FK_LaundryID = entLaundryHDR.id;


                        if (dbh.LaundryDTLs.Where(x => x.id == ExtraService.id).ToList().Count == 0)
                        {
                            dbh.LaundryDTLs.AddObject(ExtraService);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(ExtraService, System.Data.EntityState.Modified);
                        }
                    }
                }
                #endregion
                #region Removing Deleted Payments
                var p1 = entOldLaundryPaymentList.Select(x => new { id = x.id });
                var p2 = entLaundryPaymentList.Select(y => new { id = y.id });
                var deletedpayments = p1.Except(p2);
                foreach (var deletedItem in deletedpayments)
                {
                    LaundryPayment delItPay = entOldLaundryPaymentList.Where(x => x.id == deletedItem.id).First();
                    dbh.LaundryPayments.DeleteObject(delItPay);
                }
                #endregion
                #region Adding or Updating Payments
                foreach (LaundryPayment eLaundryPayment in entLaundryPaymentList)
                {
                    if (eLaundryPayment.Payment != 0)
                    {
                        eLaundryPayment.FK_LaundryID = entLaundryHDR.id;
                        if (eLaundryPayment.FK_MVInstrumentTypeID == 0)
                        {
                            eLaundryPayment.FK_MVInstrumentTypeID = null;
                        }
                        if (dbh.LaundryPayments.Where(x => x.id == eLaundryPayment.id).ToList().Count == 0)
                        {
                            dbh.LaundryPayments.AddObject(eLaundryPayment);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(eLaundryPayment, System.Data.EntityState.Modified);
                        }
                    }
                }

                #endregion
                dbh.SaveChanges();
                dbh = atHotelContext.CreateContext();

                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_LaundryHDRVoucherNo"))
                    {
                        return LaundryView_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Save);
                return false;
            }
        }
        private bool LaundryView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "") { errProvider.SetError(txtVoucherNo, "Voucher No  Must be Entered"); txtVoucherNo.Focus(); return false; }
                if (cmbRoom.Text.Trim() == "") { errProvider.SetError(cmbRoom, "Choose Room "); cmbRoom.Focus(); return false; }
                if (cmbGuest.Text.Trim() == "") { errProvider.SetError(cmbGuest, "Choose Guest"); cmbGuest.Focus(); return false; }
                if (GlobalFunctions.blnMultiCurrency)
                {
                    if (cmbCurrency.SelectedValue == null) { errProvider.SetError(cmbCurrency, MessageKeys.MsgCurrencyMustBeSelected); cmbCurrency.Focus(); return false; }
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool LaundryView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInLaundry)
                {
                    PrintClick();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void LaundryView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vCheckIn = entLaundryHDRList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vCheckIn;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }        
        private bool LaundryView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {

                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vBookings = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vBookings).id);
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool LaundryView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void LaundryView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool LaundryView_atPrint(object source)
        {
            try
            {
                if (entLaundryHDR.id == 0) 
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Laundry", entLaundryHDR.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool LaundryView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteVoucher(entLaundryHDR.FK_VoucherHDRID, ref dbh);
                GlobalMethods.DeleteVoucher(entLaundryHDR.FK_PaymentVoucherHDRID, ref dbh);
                foreach (LaundryPayment Payment in entLaundryPaymentList) //**Delete Payments **
                {
                    dbh.LaundryPayments.DeleteObject(Payment);
                }
                dbh.DeleteObject(entLaundryHDR);        //**Delete Laundry**
                dbh.SaveChanges();

                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void LaundryView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion

        #region GridMethods
        private void LoadCurrentSerialNo()
        {
            if (dgDetails.CurrentRow == null) { return; }
            dgDetails.CurrentRow.Cells[col_slno.Name].Value = dgDetails.CurrentRow.Cells[col_slno.Name].RowIndex + 1;
        }
        private void LoadFullSerialNo()
        {
            int i = 1;
            foreach (DataGridViewRow row in dgDetails.Rows)
            {
                row.Cells[col_slno.Name].Value = i;
                i = i + 1;
            }

        }
        private LaundryDTL getCurrent()
        {
            try
            {

                if (dgDetails.CurrentRow != null)
                {
                    LaundryDTL ExtraServiceDTL = (LaundryDTL)dgDetails.CurrentRow.DataBoundItem;
                    return ExtraServiceDTL;
                }
                else
                {
                    return null;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void BindGrid()
        {
            try
            {
                dgDetails.AutoGenerateColumns = false;
                bindExtraServiceDTL.DataSource = null;
                bindExtraServiceDTL.DataSource = entLaundryDTLList;
                dgDetails.DataSource = bindExtraServiceDTL;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void initGridColumns()
        {
            try
            {
                entLaundryDTLList = dbh.LaundryDTLs.Where("1=2").ToList();
                //col_DeductionPerc.Visible=GlobalFunctions.blnDeductionPerc;
                //col_DeductionAmount.Visible=GlobalFunctions.blnDeductionAmount;
                col_SlabDiscount.Visible = GlobalFunctions.blnSlabDiscountinService;
                col_SlabDiscountPerc.Visible = GlobalFunctions.blnSlabDiscountinService;
                //col_TotalTax.Visible=GlobalFunctions.blnTotalTax;
                //col_NetAmount.Visible=GlobalFunctions.blnNetAmount;
                //  col_FK_DiscountSlabID.Visible=GlobalFunctions.blnDiscountSlabID;
                // col_TotalDiscount.Visible = GlobalFunctions.blnTotalDiscount;
                //col_TaxableAmount.Visible = GlobalFunctions.blnTaxableAmount;
                //col_FK_GSTSlabID.Visible = GlobalFunctions.blnGSTSlabID;
                //col_FK_VATSlabID.Visible = GlobalFunctions.blnFK_VATSlabIDe;
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
                col_ExciseAmount.Visible = GlobalFunctions.blnExciseDutyInService;
                // col_FK_ExciseSlabID.Visible = GlobalFunctions.blnExciseSlabID);
                //col_ExciseAmount.Visible=GlobalFunctions.ExcisePerc;
                //col_ExciseAmount.Visible=GlobalFunctions.ExciseAmount;
                // col_FK_TAX1SlabID.Visible=GlobalFunctions.FK_TAX1SlabID;
                col_VATAmount.Visible = GlobalFunctions.blnVATinService;
                col_VATPerc.Visible = GlobalFunctions.blnVATinService;
                col_Tax1Amount.Visible = GlobalFunctions.blnTAX1inService;
                col_Tax1Perc.Visible = GlobalFunctions.blnTAX1inService;
                // col_FK_TAX2SlabID.Visible=GlobalFunctions.blnTAX2SlabID;
                col_Tax2Amount.Visible = GlobalFunctions.blnTAX2inService;
                col_Tax2Perc.Visible = GlobalFunctions.blnTAX2inService;
                //col_FK_TAX3SlabID.Visible=GlobalFunctions.blnTAX3SlabID;
                col_Tax3Amount.Visible = GlobalFunctions.blnTAX3inService;
                col_Tax3Perc.Visible = GlobalFunctions.blnTAX3inService;
                // col_AddnlTaxPerc.Visible = GlobalFunctions.blnAddnlTaxPerc;
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
                //col_FK_AddnlTaxSlabID.Visible=GlobalFunctions.blnAddnlTaxSlabID;
                col_Tax1Amount.HeaderText = GlobalFunctions.Tax1Caption + " " + MessageKeys.MsgAmount;
                col_Tax2Amount.HeaderText = GlobalFunctions.Tax2Caption + " " + MessageKeys.MsgAmount;
                col_Tax3Amount.HeaderText = GlobalFunctions.Tax3Caption + " " + MessageKeys.MsgAmount;
                col_Tax1Perc.HeaderText = GlobalFunctions.Tax1Caption + " %";
                col_Tax2Perc.HeaderText = GlobalFunctions.Tax2Caption + " %";
                col_Tax3Perc.HeaderText = GlobalFunctions.Tax3Caption + " %";

                col_InclusiveRate.Visible = GlobalFunctions.blnInclusiveRateInPurchase;

                if (GlobalFunctions.blnGSTinService)
                {
                    col_SGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_SGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_IGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_IGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_CGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                    col_CGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                }
                else
                {
                    col_SGSTAmount.Visible = false;
                    col_SGSTPerc.Visible = false;
                    col_IGSTAmount.Visible = false;
                    col_IGSTPerc.Visible = false;
                    col_CGSTAmount.Visible = false;
                    col_CGSTPerc.Visible = false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void ApplyGridStyles()
        {
            try
            {
                col_Qty.DefaultCellStyle.Format = NumberFormat;
                col_Rate.DefaultCellStyle.Format = NumberFormat;
                col_Amount.DefaultCellStyle.Format = NumberFormat;
                col_DeductionPerc.DefaultCellStyle.Format = NumberFormat;
                col_DeductionAmount.DefaultCellStyle.Format = NumberFormat;
                col_TotalTax.DefaultCellStyle.Format = NumberFormat;
                col_NetAmount.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscountPerc.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TotalDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TaxableAmount.DefaultCellStyle.Format = NumberFormat;
                col_CGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_CGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_SGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_SGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_IGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_IGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_VATPerc.DefaultCellStyle.Format = NumberFormat;
                col_VATAmount.DefaultCellStyle.Format = NumberFormat;
                col_ExcisePerc.DefaultCellStyle.Format = NumberFormat;
                col_ExciseAmount.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Amount.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxPerc.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxAmount.DefaultCellStyle.Format = NumberFormat;
                col_InclusiveRate.DefaultCellStyle.Format = NumberFormat;
                lblTotQty.Format = sQtyFormat;
                lblGrandTotal.Format = NumberFormat;
            }
            catch (Exception)
            {

                throw;
            }

        }
        private void fillService(int _ServiceID)
        {
            if (txtExRate.Value == 0) { return ; }
            LaundryDTL cesd = getCurrent();
            if (cesd != null)
            {
                ExtraServices service = dbh.ExtraServices.Where(x => x.id == _ServiceID).Single();
                dgDetails.CurrentRow.Cells[col_Service.Name].Value = service.Name.ToString();
                dgDetails.CurrentRow.Cells[col_Code.Name].Value = service.Code.ToString();
                cesd.FK_ServiceID = _ServiceID;
                cesd.Rate = service.Rate / txtExRate.Value;
                cesd.InclusiveRate = cesd.Rate;
                cesd.DeductionPerc = txtDeductionPerc.Value;
                dgDetails.CurrentCell = MoveForward(dgDetails.CurrentCell);
            }
        }
        private DataGridViewCell MoveForward(DataGridViewCell _currentCell)
        {
            int row_index = _currentCell.OwningRow.Index;
            int col_index = _currentCell.OwningColumn.Index;
            DataGridViewCell cell = dgDetails.Rows[row_index].Cells[col_index + 1];
            if (cell.Visible && cell.ReadOnly == false)
            {
                return cell;
            }
            else
            {
                return MoveForward(cell);
            }
        }

        #endregion

        #region Grid Events
        private void dgDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (e.Control is DataGridViewComboBoxEditingControl)
                {
                    cb = (DataGridViewComboBoxEditingControl)e.Control;
                    if (cb != null)
                    {
                        cb.DropDownStyle = ComboBoxStyle.DropDown;
                        cb.AutoCompleteMode = AutoCompleteMode.Suggest;
                        cb.Validating -= new CancelEventHandler(cb_Validating);
                        cb.Validating += new CancelEventHandler(cb_Validating);
                        cb.KeyDown -= new KeyEventHandler(cb_KeyDown);
                        cb.KeyDown += new KeyEventHandler(cb_KeyDown);
                        cb.Focus();
                    }
                }
                if (e.Control is DataGridViewTextBoxEditingControl)
                {
                    textbox = (DataGridViewTextBoxEditingControl)e.Control;
                    if (textbox != null)
                    {
                        textbox.KeyPress += new KeyPressEventHandler(textbox_KeyPress);
                        textbox.KeyUp -= new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyUp += new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyDown -= new KeyEventHandler(textbox_KeyDown);
                        textbox.KeyDown += new KeyEventHandler(textbox_KeyDown);

                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
            }
        }
        void textbox_KeyDown(object sender, KeyEventArgs e)
        {
            sKeyChar = string.Empty;
            if (e.KeyCode == Keys.Return)
            {
                int index = dgDetails.SelectedCells[0].OwningRow.Index;
                if (textbox.Text.Trim() != "")
                {
                    ExtraServices _service = dbh.ExtraServices.Where(x => x.Name == textbox.Text.Trim()).SingleOrDefault();
                    if (_service != null)
                    {
                        fillService(_service.id);
                    }
                }
                dgDetails.CurrentCell = dgDetails.Rows[index].Cells[col_Code.Index + 1];
            }

        }
        void textbox_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {

                
            }
            catch { }

        }
        void cb_KeyDown(object sender, KeyEventArgs e)
        {


        }
        void cb_Validating(object sender, CancelEventArgs e)
        {
            // Create New Service If Not Exist
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name)
            {
                if (dgDetails.LastKey == Keys.Enter)
                {
                    if (cb.SelectedIndex == -1 && cb.Text != "")
                    {
                        //NewProductView frm = new NewProductView(0, iContextID);
                        //if (frm.ShowDialog() == DialogResult.OK)
                        //{

                        //}
                    }
                }
            }


        }
        void textbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            sKeyChar = e.KeyChar.ToString();
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (Char.IsDigit(e.KeyChar)) return;
                if (Char.IsControl(e.KeyChar)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).Text.Contains('.') == false)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                e.Handled = true;
            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.NotifyCurrentCellDirty(true);
            }

            if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                if (sKeyChar == string.Empty) { return; }
                dgDetails.NotifyCurrentCellDirty(true);
                e.Handled = true;
                int _SelectedService;
                sKeyChar = textbox.GetCharInsertText(e.KeyChar);
                ExtraServiceSearchView frm = new ExtraServiceSearchView(sKeyChar, ENExtraServiceTypes.Laundry);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    _SelectedService = frm.selectedServiceID;
                    fillService(_SelectedService);
                }
                else
                {
                    textbox.Text = "";
                }
            }
        }
        
        private void dgDetails_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
        }
        private void dgDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {

                fillServiceByCodeInCurrentRow();

            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Amount.Name)
            {
                if (dgDetails.CurrentCell.Value == null) { return; }
                LaundryDTL pdtl = getCurrent();
                if (pdtl != null)
                {
                    if (pdtl.Amount == 0) { }
                    if (pdtl.Qty == 0 && pdtl.Rate == 0)
                    {
                        pdtl.Amount = 0;
                    }
                    else if (pdtl.Qty == 0)
                    {
                        pdtl.Qty = pdtl.Amount / pdtl.Rate;
                    }
                    else if (pdtl.Rate == 0)
                    {
                        pdtl.Rate = pdtl.Amount / pdtl.Qty;
                    }
                }

            }

            CalcRowAmount(getCurrent());
        }

        private void dgDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            dgDetails.CurrentCell.Tag = dgDetails.CurrentCell.Value ?? string.Empty;
        }

        private void dgDetails_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.BeginEdit(true);
            }

        }
        private void dgDetails_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (e.FormattedValue == null || e.FormattedValue.ToString2().Trim() == "")
                {
                    //    e.Cancel = true;
                }
            }
            //if (dgDetails.CurrentCell.OwningColumn.Name == col_SpcialDiscount.Name || dgDetails.CurrentCell.OwningColumn.Name == col_SpcialDiscountPerc.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name)
            //{
            //    if (e.FormattedValue.ToString().ToDecimal() < 0)
            //    {
            //        e.Cancel = true;
            //    }

            //}

        }
        private void dgDetails_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            LoadCurrentSerialNo();
            LoadFullSerialNo();
            CalcGrand();
        }
        private void dgDetails_KeyDown(object sender, KeyEventArgs e)
        {


        }
        private void dgDetails_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            LaundryDTL pdtl = (LaundryDTL)dgDetails.Rows[e.RowIndex].DataBoundItem;
            if (pdtl != null)
            {
                try
                {
                    int _CurrentProductID = pdtl.FK_ServiceID.toInt32();

                }
                catch (Exception) { }
            }
            LoadCurrentSerialNo();
        }
        #endregion
    }
}
