﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseForms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using System.Data.SqlClient;
using atACC.HTL.Masters;
using System.IO;
using System.Net.Mail;
using atACC.HTL.Transactions.Sub_Forms;
using atACCFramework;

namespace atACC.HTL.Transactions
{
    public partial class CheckInView : SearchFormBase2
    {
        #region Private Variable
        CheckIn entCheckIn;
        List<CheckIn> entCheckInList;
        List<CheckInExtraServiceDTL> entOldCheckInDTLList;
        List<BookingPayment> entBookingPaymentList;
        List<CheckInExtraServiceDTL> entCheckInDTLList;
        List<CheckInPayment> entCheckInPaymentList;
        List<CheckInPayment> entOldCheckInPaymentList;
        RoomTypes e_RoomTypes;
        RoomTariffs e_RoomTariffs;
        GuestDTLs e_GuestDTLs;
        Guests entGuest;
        Booking entBookings;
        List<Guests> entGuestlist;
        atACC.HTL.ORM.AccountLedger Ledger;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        bool _OnLoad;
        CommonLibClasses objLib;
        ToolTip tooltip;
        List<Employee> entEmployees;
        List<Agent> entAgents;
        List<RoomTypeSlabs> entRoomTypesSlabs;
        List<Rooms> entRooms;
        List<RoomTypes> entRoomTypes;
        List<atACC.HTL.ORM.AccountLedger> entGuestAccounts;
        string sKeyChar = "";
        string NumberFormat, sQtyFormat;
        int iRoomType, iGuestID, ExtraAdultCount, iSettingsId, iRateTypeId, iDefaultId, iSlabTypeId, iRoomTypeId, iContentId;
        int AgentLedgerID;
        int _CheckInId;
        int _BookingId;
        decimal AdditionalPersonAmount = 0, RoomRate = 0, GuestDeduction = 0, AdvanceAmount, TotalAmount, Total;
        int _SelectedRoomID;
        DateTime? _arrivalDate;
        DateTime? _departureDate;
        GetAccounts getAccc;
        bool PrintPreview;
        VoucherHDR entVoucherHdrPayment;
        VoucherHDR entVoucherHdr;
        bool blnSanctioningRequired = false;
        decimal previousExRate;
        bool blnPartyUnderCashInHand = false;
        List<CurrencyClass> entCurrencys;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;
        #endregion

        #region Constructor
        public CheckInView(int id)
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            aniHelper = new ANIHelper();
            getAccc = new GetAccounts();
            ShareButton.Visible = false;
            _CheckInId = id;
           _OnLoad = false;

            ToolStripMenuItem mnuSendEmail = new ToolStripMenuItem();
            mnuSendEmail.BackColor = Color.White;
            mnuSendEmail.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendEmail.Text = MessageKeys.MsgSendEmail;
            mnuSendEmail.Image = Properties.Resources.Mail;
            mnuSendEmail.Click += new EventHandler(mnuSendEmail_Click);
            ShareMenu.Items.Add(mnuSendEmail);

            ToolStripMenuItem mnuSendSMS = new ToolStripMenuItem();
            mnuSendSMS.BackColor = Color.White;
            mnuSendSMS.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendSMS.Text = MessageKeys.MsgSendSMS;
            mnuSendSMS.Image = Properties.Resources.SMS;
            mnuSendSMS.Click += new EventHandler(mnuSendSMS_Click);
            ShareMenu.Items.Add(mnuSendSMS);
        }
        public CheckInView() : this(0) { }
        public CheckInView(Int32 icheckIn, int selectedRoomID) : this()
        {
            _SelectedRoomID = selectedRoomID;
        }
        public CheckInView(Int32 icheckIn, int selectedRoomID, int iBookingID) : this()
        {
            _BookingId = iBookingID;
        }
        public CheckInView(Int32 icheckIn, int selectedRoomID, DateTime? arrivalDate, DateTime? departureDate) : this()
        {
            _SelectedRoomID = selectedRoomID;
            _arrivalDate = arrivalDate;
            _departureDate = departureDate;
        }
        #endregion Constructor

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(3);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Share Methods
        void mnuSendEmail_Click(object sender, EventArgs e)
        {
            SendEmail();
        }
        void mnuSendSMS_Click(object sender, EventArgs e)
        {
            SendSMS();
        }
        private void SendEmail()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (cmbGuest.SelectedValue == null)
                {
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                    this.Cursor = Cursors.Arrow;
                    return;
                }
                if (entCheckIn != null && entCheckIn.id != null && entCheckIn.id != 0)
                {
                    string sTo = "";
                    int iGuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                    GuestDTLs _GuDtl = dbh.GuestDTLs.Where(x => x.FK_GuestID == iGuestID).SingleOrDefault();
                    if (_GuDtl != null)
                    {
                        sTo = _GuDtl.Email;
                    }
                    if (sTo.Trim() == "")
                    {
                        MessageBox.Show(MessageKeys.MsgEmailAddressOfGuestMustBeSet);
                        this.Cursor = Cursors.Arrow;
                        return;
                    }
                    string sExportPath = Application.StartupPath + "\\Temp\\Sales_" + txtVoucherNo.Text + ".pdf";
                    string sBody = "";
                    MailHelper _mailHelper = new MailHelper();
                    _mailHelper.sTo = sTo;
                    MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "Email").SingleOrDefault();
                    sBody = _Message.CheckIn;
                    sBody = sBody.Replace("@VoucherNo", txtVoucherNo.Text)
                    .Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString())
                    .Replace("@GuestName@", cmbGuest.Text)
                    .Replace("@RoomType@", cmbRoomType.Text)
                    .Replace("@Room@", cmbRoom.Text)
                    .Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString())
                    .Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString())
                    .Replace("@NoofDays@", txtNoOfDays.Text)
                    .Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat))
                    .Replace("@Payment@", txtPayment.Value.ToString(NumberFormat))
                    .Replace("@Refund@", "")
                    .Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));

                    _mailHelper.sSubject = MessageKeys.MsgCheckInVoucherNo + " : " + txtVoucherNo.Text;
                    _mailHelper.sBody = sBody;
                    if (GlobalFunctions.blnConfirmationForEmail)
                    {
                        EmailConfirmationView emailConfirm = new EmailConfirmationView(_mailHelper.sSubject, _mailHelper.sBody);
                        if (emailConfirm.ShowDialog() == DialogResult.OK)
                        {
                            _mailHelper.sSubject = emailConfirm.sSubject;
                            _mailHelper.sBody = emailConfirm.sBody;
                        }
                        this.Cursor = Cursors.WaitCursor;
                    }
                    if (entCheckIn.id != 0)
                    {
                        if (File.Exists(sExportPath))
                        {
                            File.Delete(sExportPath);
                        }
                        PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                        printInvoice.PrintOut("Hotel Check In", entCheckIn.id, 0, true, sExportPath);
                        if (File.Exists(sExportPath))
                        {
                            _mailHelper.entAttachments.Add(new Attachment(sExportPath));
                        }
                    }
                    _mailHelper.SendEmail();
                    if (File.Exists(sExportPath))
                    {
                        File.Delete(sExportPath);
                    }
                    atMessageBox.Show(MessageKeys.MsgMailSendSuccessfully);
                }
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
                this.Cursor = Cursors.Arrow;
            }
        }
        private bool SendSMS()
        {
            if (cmbGuest.SelectedValue == null)
            {
                errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                return false;
            }
            if (entCheckIn == null || entCheckIn.id == null || entCheckIn.id != 0) 
            {
                atMessageBox.Show(MessageKeys.MsgRecordNotFound);
                return false;
            }
            int iGuestID = cmbGuest.SelectedValue.ToInt32();
            try
            {
                if (cmbGuest.Text.Trim() == "") { return false; }
                if (txtMobile.Text.Trim() == "") { return false; }
                MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "SMS").SingleOrDefault();
                string sMessage = _Message.CheckIn;
                sMessage = sMessage.Replace("@VoucherNo", txtVoucherNo.Text);
                sMessage = sMessage.Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@GuestName@", cmbGuest.Text);
                sMessage = sMessage.Replace("@RoomType@", cmbRoomType.Text);
                sMessage = sMessage.Replace("@Room@", cmbRoom.Text);
                sMessage = sMessage.Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@NoofDays@", txtNoOfDays.Text);
                sMessage = sMessage.Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Payment@", txtPayment.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Refund@", "");
                sMessage = sMessage.Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));
                string sResult = SMSHelper.SendSMSBash(txtMobile.Text.Trim(), sMessage);
                MessageBox.Show("SMS : " + sResult);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion

        #region Private Methods
        private void InitControls()
        {
            dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
            dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();

            dtpArrivalDate.SetCustomFormat();
            dtpDepartureDate.SetCustomFormat();
            dtpArrivalDate.DisbaleShortDateTimeFormat = true;
            dtpDepartureDate.DisbaleShortDateTimeFormat = true;
        }
        private bool IsActiveControl(object ctrl)
        {
            return ActiveControl != null && ActiveControl.Name == ((Control)ctrl).Name;
        }
        private void CalculateSlab(bool blnUpdateDeductionAmount)
        {
            try
            {
                List<Slab> slabs = null;
                int iRoomTypeID = cmbRoomType.SelectedValue.ToInt32();
                int iLastRoomTypeID = (cmbRoomType.Tag ?? 0).ToInt32();
                if (iRoomTypeID != iLastRoomTypeID)
                {
                    slabs = (from rs in dbh.RoomTypeSlabs
                             join s in dbh.Slabs on rs.FK_SlabID equals s.id
                             where rs.FK_RoomTypeID == iRoomTypeID
                             select s).ToList();
                    cmbRoomType.Tag = iRoomTypeID;
                }
                entCheckIn.Amount = txtGross.Value;
                entCheckIn.DeductionPerc = txtDeductionPerc.Value;
                entCheckIn.DeductionAmount = txtDeductionAmount.Value;
                entCheckIn.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ApplyExRate()
        {
            try
            {
                decimal dcCurrentExRate = txtExRate.Value;
                decimal dcExRateChange = ((previousExRate == 0 ? 1 : previousExRate) / (dcCurrentExRate == 0 ? 1 : dcCurrentExRate));
                foreach (CheckInExtraServiceDTL serviceDtl in entCheckInDTLList)
                {
                    if (serviceDtl.FK_ExtraServiceID != null)
                    {
                        serviceDtl.Rate = dcExRateChange * serviceDtl.Rate;
                        serviceDtl.InclusiveRate = dcExRateChange * serviceDtl.InclusiveRate;
                        serviceDtl.Amount = dcExRateChange * serviceDtl.Amount;                        
                        serviceDtl.TaxableAmount = dcExRateChange * serviceDtl.TaxableAmount;
                        serviceDtl.SlabDiscount = dcExRateChange * serviceDtl.SlabDiscount;
                        serviceDtl.DeductionAmount = dcExRateChange * serviceDtl.DeductionAmount;
                        serviceDtl.ExciseAmount = dcExRateChange * serviceDtl.ExciseAmount;
                        serviceDtl.Tax1Amount = dcExRateChange * serviceDtl.Tax1Amount;
                        serviceDtl.Tax2Amount = dcExRateChange * serviceDtl.Tax2Amount;
                        serviceDtl.Tax3Amount = dcExRateChange * serviceDtl.Tax3Amount;
                        serviceDtl.AddnlTaxAmount = dcExRateChange * serviceDtl.AddnlTaxAmount;
                        serviceDtl.VATAmount = dcExRateChange * serviceDtl.VATAmount;
                        serviceDtl.CGSTAmount = dcExRateChange * serviceDtl.CGSTAmount;
                        serviceDtl.SGSTAmount = dcExRateChange * serviceDtl.SGSTAmount;
                        serviceDtl.IGSTAmount = dcExRateChange * serviceDtl.IGSTAmount;
                        serviceDtl.NetAmount = dcExRateChange * serviceDtl.NetAmount;
                    }
                }
                CheckIn dtl = entCheckIn;
                dtl.Rate = dcExRateChange * dtl.Rate;
                dtl.AdditionalBedRate = dcExRateChange * dtl.AdditionalBedRate;
                dtl.AdditionalPersonRate = dcExRateChange * dtl.AdditionalPersonRate;
                dtl.InclusiveRate = dcExRateChange * dtl.InclusiveRate;
                dtl.Amount = dcExRateChange * dtl.Amount;
                dtl.TaxableAmount = dcExRateChange * dtl.TaxableAmount;
                dtl.SlabDiscount = dcExRateChange * dtl.SlabDiscount;
                dtl.DeductionAmount = dcExRateChange * dtl.DeductionAmount;
                dtl.ExciseAmount = dcExRateChange * dtl.ExciseAmount;
                dtl.Tax1Amount = dcExRateChange * dtl.Tax1Amount;
                dtl.Tax2Amount = dcExRateChange * dtl.Tax2Amount;
                dtl.Tax3Amount = dcExRateChange * dtl.Tax3Amount;
                dtl.AddnlTaxAmount = dcExRateChange * dtl.AddnlTaxAmount;
                dtl.VATAmount = dcExRateChange * dtl.VATAmount;
                dtl.CGSTAmount = dcExRateChange * dtl.CGSTAmount;
                dtl.SGSTAmount = dcExRateChange * dtl.SGSTAmount;
                dtl.IGSTAmount = dcExRateChange * dtl.IGSTAmount;
                dtl.NetAmount = dcExRateChange * dtl.NetAmount;
                txtRate.Value *= dcExRateChange;
                txtAddPersonRate.Value *= dcExRateChange;
                txtAddBedRate.Value *= dcExRateChange;
                foreach (CheckInPayment payment in entCheckInPaymentList)
                {
                    payment.Payment = dcExRateChange * payment.Payment;
                }
                CalcNetTotal();
                CalcOpeningAndExternalAmt();
                previousExRate = txtExRate.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PostVoucher()
        {
            try
            {
                bool blnNewRecord = true;
                bool blnNewPaymentRecord = true;
                entVoucherHdr = new VoucherHDR();
                entVoucherHdrPayment = new VoucherHDR();
                if (!NewRecord)
                {
                    if ((entCheckIn.FK_VoucherHDRID ?? 0) != 0)
                    {
                        entVoucherHdr = dbh.VoucherHDRs.Where(x => x.id == entCheckIn.FK_VoucherHDRID).SingleOrDefault();
                        blnNewRecord = false;
                    }

                    if ((entCheckIn.FK_PaymentVoucherHDRID ?? 0) != 0)
                    {
                        entVoucherHdrPayment = dbh.VoucherHDRs.Where(x => x.id == entCheckIn.FK_PaymentVoucherHDRID).SingleOrDefault();
                        blnNewPaymentRecord = false;
                    }
                }

                int iCashorPartyAccountID = cmbBillingAccount.SelectedValue.ToInt32();
                blnPartyUnderCashInHand = aniHelper.isUnderCashInHand(iCashorPartyAccountID);
                AccountLedger entRentAccount = dbh.AccountLedgers.Where(x => x.id == GlobalProperties.RentAccountID).SingleOrDefault();

                decimal dcmGrandTotal = lblGrandTotal.Value;
                decimal dcExRate = txtExRate.Value;
                decimal dcmOtherPaymentSum = entCheckInPaymentList.Where(x => x.isCash == false).Sum(x => x.Payment).ToDecimal();
                decimal dcmPartyAmount = blnPartyUnderCashInHand ? dcmGrandTotal - dcmOtherPaymentSum : dcmGrandTotal;

                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdr, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToString().ToInt32(), lblGrandTotal.Value, txtVoucherNo.Text, "H-CI");

                //Voucher DTL Entry
                List<VoucherDTL> entVoucherDtls = new List<VoucherDTL>();

                // Debit Bill Amount to Party or Cash Account
                GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, iCashorPartyAccountID, entRentAccount.LedgerName, dcExRate, dcmPartyAmount, cmbRoom.Text, txtRemarks.Text);

                #region Rent Voucher DTL
                //Credit Gross Amount to Rent Account
                GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.RentAccountID, cmbBillingAccount.Text, dcExRate, txtGross.Value * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit Tax1 
                if (lblTotalTax.lblTax1 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax1AccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblTax1 * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit Tax2 
                if (lblTotalTax.lblTax2 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax2AccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblTax2 * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit Tax3
                if (lblTotalTax.lblTax3 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax3AccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblTax3 * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit Excise Duty
                if (lblTotalTax.lblExciseDuty != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExciseDutyAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblExciseDuty * (-1), cmbRoom.Text, txtRemarks.Text);
                // Debi Total Discount 
                if (txtTotalDiscount.Value != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.DiscountAccountID, cmbBillingAccount.Text, dcExRate, txtTotalDiscount.Value, cmbRoom.Text, txtRemarks.Text);
                // Round off Posting
                //if (dcTotalRoundoff != 0)
                //    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.RoundoffSalesID, cmbBillingAccount.Text, dcExRate, (dcTotalRoundoff * dcExRate), dcTotalRoundoff, "", txtRemarks.Text);
                //Credit Vat
                if (lblTotalTax.lblVAT != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.VATAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblVAT * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit CGST
                if (lblTotalTax.lblCGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.CGSTAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblCGST * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit SGST
                if (lblTotalTax.lblSGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.SGSTAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblSGST * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit IGST
                if (lblTotalTax.lblIGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.IGSTAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblIGST * (-1), cmbRoom.Text, txtRemarks.Text);
                //Credit AddnlTax
                if (lblTotalTax.lblAddnlTax != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.AdditionalTaxAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblAddnlTax * (-1), cmbRoom.Text, txtRemarks.Text);
                #endregion

                #region ExtraService Voucher DTL
                if (entCheckInDTLList.Count > 0)
                {
                    decimal dcGross = entCheckInDTLList.Sum(x => x.Amount).ToDecimal();
                    decimal dcDiscount = entCheckInDTLList.Sum(x => x.DeductionAmount + x.SlabDiscount).ToDecimal();
                    decimal dcTax1 = entCheckInDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                    decimal dcTax2 = entCheckInDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                    decimal dcTax3 = entCheckInDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                    decimal dcAddnlTax = entCheckInDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                    decimal dcExciseDuty = entCheckInDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                    decimal dcVAT = entCheckInDTLList.Sum(x => x.VATAmount).ToDecimal();
                    decimal dcCGST = entCheckInDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                    decimal dcSGST = entCheckInDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                    decimal dcIGST = entCheckInDTLList.Sum(x => x.IGSTAmount).ToDecimal();

                    //Credit Gross Amount to ExtraService Account
                    if (dcGross != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExtraServicesAccountID, cmbBillingAccount.Text, dcExRate, dcGross * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit Tax1 
                    if (dcTax1 != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax1AccountID, cmbBillingAccount.Text, dcExRate, dcTax1 * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit Tax2
                    if (dcTax2 != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax2AccountID, cmbBillingAccount.Text, dcExRate, dcTax2 * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit Tax3
                    if (dcTax3 != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax3AccountID, cmbBillingAccount.Text, dcExRate, dcTax3 * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit Excise Duty
                    if (dcExciseDuty != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExciseDutyAccountID, cmbBillingAccount.Text, dcExRate, dcExciseDuty * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Debit Total Discount 
                    if (txtTotalDiscount.Value != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.DiscountAccountID, cmbBillingAccount.Text, dcExRate, txtTotalDiscount.Value, cmbRoom.Text, txtRemarks.Text);
                    //Credit Vat
                    if (dcVAT != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.VATAccountID, cmbBillingAccount.Text, dcExRate, dcVAT * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit CGST
                    if (dcCGST != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.CGSTAccountID, cmbBillingAccount.Text, dcExRate, dcCGST * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit SGST
                    if (dcSGST != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.SGSTAccountID, cmbBillingAccount.Text, dcExRate, dcSGST * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit IGST
                    if (dcIGST != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.IGSTAccountID, cmbBillingAccount.Text, dcExRate, dcIGST * (-1), cmbRoom.Text, txtRemarks.Text);
                    //Credit
                    if (dcAddnlTax != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.AdditionalTaxAccountID, cmbBillingAccount.Text, dcExRate, dcAddnlTax * (-1), cmbRoom.Text, txtRemarks.Text);
                }
                #endregion
                List<AnalysisDTL> entAnalysisDTLs = new List<AnalysisDTL>();
                GlobalMethods.PostVoucher(blnNewRecord, entVoucherHdr, entVoucherDtls, ref dbh, entAnalysisDTLs);

                #region Payment Posting
                List<VoucherDTL> entVoucherDtlsPayment = new List<VoucherDTL>();
                if (entCheckInPaymentList.Count() > 0) // Payment Found
                {
                    if (entVoucherHdrPayment.id == 0)
                    {
                        entVoucherHdrPayment.id = -1;
                    }
                    //Voucher Hdr Entry
                    GlobalMethods.DecorateVoucherHdr(entVoucherHdrPayment, iContextID, "", dtVoucherDate.Value
                        , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-CI-PAY");

                    foreach (CheckInPayment payment in entCheckInPaymentList)
                    {
                        #region isCash
                        if (payment.isCash.toBool()) // Cash Payment
                        {
                            if (!blnPartyUnderCashInHand)
                            {
                                int iCashAccountID = payment.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)payment.FK_AccountID;
                                string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                                // Debit to Cash Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashAccountID, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sAccountName, dcExRate, payment.Payment.ToDecimal() * -1, cmbRoom.Text, txtRemarks.Text);
                            }
                        }
                        #endregion

                        #region Non Cash
                        else
                        {
                            int iSelectedBankAccount = (int)payment.FK_AccountID;
                            string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                            string sRentAccountName = aniHelper.getLedNameFromAccountID(GlobalProperties.RentAccountID);
                            if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                            {
                                string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);

                                // Debit to Credit Card Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                                if (!blnPartyUnderCashInHand)
                                {
                                    // Credit From Party Account
                                    GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * -1, cmbRoom.Text, txtRemarks.Text);
                                }

                                //Debit to Bank Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                                //Credit From Credit Card Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                            }
                            else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                            {
                                string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);

                                //Debit to Cheque Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                                if (!blnPartyUnderCashInHand)
                                {
                                    // Credit From Party Account
                                    GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                                }

                                //Debit to Bank Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                                //Credit From Cheque Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                            }
                            else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                                || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                            {
                                //Debit to Bank Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                                //Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                            }
                        }
                        #endregion
                    }

                    GlobalMethods.PostVoucher(blnNewPaymentRecord, entVoucherHdrPayment, entVoucherDtlsPayment, ref dbh, entAnalysisDTLs);
                }
                #endregion
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_CheckIn, 0, 0, txtVoucherNo.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRateType()
        {
            try
            {
                try
                {
                    List<RateTypes> rateTypes = dbh.RateTypes.ToList();
                    rateTypes.Add(new RateTypes()
                    {
                        id = 0,
                        Name = MessageKeys.MsgDefault
                    });
                    cmbRateType.DataSource = rateTypes;
                    cmbRateType.DisplayMember = "Name";
                    cmbRateType.ValueMember = "id";
                    cmbRateType.SelectedIndex = -1;

                }
                catch (Exception ex)
                {
                    ExceptionManager.Publish(ex);
                    atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Guest
                var entGuests = dbh.Guests.Where(x => x.Active == true).Select(x => new { id = x.id, Name = x.Name }).ToList();
                cmbGuest.DataSource = entGuests;
                cmbGuest.DisplayMember = "Name";
                cmbGuest.ValueMember = "id";
                cmbGuest.SelectedIndex = -1;
                #endregion

                #region BillingAccount
                List<AccountLedger> entDebtors = getAccc.GetAccountLedgers(25);
                cmbBillingAccount.DataSource = entDebtors;
                cmbBillingAccount.DisplayMember = "LedgerName";
                cmbBillingAccount.ValueMember = "id";
                cmbBillingAccount.SelectedIndex = -1;
                #endregion

                #region VehicleType
                cmbGuestVehicleType.DataSource = dbh.CheckIns.Where(x => x.GuestVehicleType != "").Select(x => new { id = -1, x.GuestVehicleType}).Distinct().ToList();
                cmbGuestVehicleType.DisplayMember = "GuestVehicleType";
                cmbGuestVehicleType.ValueMember = "id";
                cmbGuestVehicleType.SelectedIndex = -1;
                #endregion

                #region GuestType
                List<GuestType> entGuestTypes = dbh.GuestTypes.ToList();
                GuestType entGuestType = new GuestType();
                entGuestType.id = 0;
                entGuestType.Name = MessageKeys.MsgNone;
                entGuestTypes.Insert(0, entGuestType);
                cmbGuestType.DataSource = entGuestTypes;
                cmbGuestType.DisplayMember = "Name";
                cmbGuestType.ValueMember = "id";
                #endregion

                #region Source
                List<Source> entSources = dbh.Sources.ToList();
                Source entSource = new Source();
                entSource.id = 0;
                entSource.Name = MessageKeys.MsgNone;
                entSources.Insert(0, entSource);
                cmbSource.DataSource = entSources;
                cmbSource.DisplayMember = "Name";
                cmbSource.ValueMember = "id";
                #endregion

                #region Agent
                entAgents = dbh.Agents.Where(x => x.Status == 1).ToList();
                Agent entAgent = new Agent();
                entAgent.id = 0;
                entAgent.Name = MessageKeys.MsgNone;
                entAgents.Insert(0, entAgent);
                cmbAgent.DataSource = entAgents;
                cmbAgent.DisplayMember = "Name";
                cmbAgent.ValueMember = "id";
                #endregion

                #region Employee
                entEmployees = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).Where(x => x.Status == 1).ToList();
                cmbEmployee.DataSource = entEmployees;
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }
                #endregion

                #region Currency
                cmbCurrency.DataSource = entCurrencys;
                cmbCurrency.DisplayMember = "CurrencyName";
                cmbCurrency.ValueMember = "id";
                #endregion

                #region RoomOrHall
                cmbRoomOrHall.Items.Add(MessageKeys.MsgRoom);
                cmbRoomOrHall.Items.Add(MessageKeys.MsgHall);
                #endregion

                PopulateRateType();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void PopulateRoomTypes()
        {
            try
            {
                if (cmbRoomOrHall.Text == MessageKeys.MsgHall)
                {
                    cmbRoomType.DataSource = dbh.RoomTypes.Where(x => x.IsHallType == true).ToList();
                }
                else
                {
                    cmbRoomType.DataSource = dbh.RoomTypes.Where(x => x.IsHallType == false).ToList();
                }
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                if (cmbRoomType.Items.Count == 1)
                {
                    cmbRoomType.SelectedIndex = 0;
                    PopulateRooms();
                }
                else
                {
                    cmbRoomType.SelectedIndex = -1;
                }
                iDefaultId = 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRooms()
        {
            try
            {
                int iRoomTypeID = cmbRoomType.SelectedValue.ToInt32();
                cmbRoom.DataSource = entRooms.Where(x => x.FK_RoomTypeID == iRoomTypeID).ToList();
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
                cmbRoom.SelectedIndex = cmbRoom.Items.Count == 1 ? 0 : -1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateSelectedRoom()
        {
            try
            {
                if (_SelectedRoomID > 0)
                {
                    Rooms room = dbh.Rooms.Where(x => x.id == _SelectedRoomID).SingleOrDefault();
                    if (room != null)
                    {
                        ActiveControl = cmbRoomOrHall;
                        cmbRoomOrHall.Text = room.IsHall.Value ? MessageKeys.MsgHall : MessageKeys.MsgRoom;

                        ActiveControl = cmbRoomType;
                        cmbRoomType.SelectedValue = room.FK_RoomTypeID;

                        cmbRoom.SelectedValue = room.id;
                    }
                }
                if (_arrivalDate != null && _departureDate != null)
                {

                    dtpArrivalDate.Value = new DateTime(_arrivalDate.Value.Year, _arrivalDate.Value.Month, _arrivalDate.Value.Day,
                                                        DateTime.Now.Hour, DateTime.Now.Minute, 0);
                    dtpDepartureDate.Value = new DateTime(_departureDate.Value.Year, _departureDate.Value.Month, _departureDate.Value.Day,
                                                        DateTime.Now.Hour, DateTime.Now.Minute, 0);
                    txtNoOfDays.Text = GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpDepartureDate.Value).ToString();
                    CalcRoomRent();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCheckIn()
        {
            try
            {
                entCheckInList = dbh.CheckIns.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private int DateDiff(DateTime d1, DateTime d2)
        {
            try
            {
                TimeSpan span = d2.Subtract(d1);
                return (int)span.TotalDays;
            }
            catch { return 0; }
        }
        private void ClearGuestInfo()
        {
            try
            {
                txtTelephone.Text = "";
                cmbBillingAccount.SelectedIndex = -1;
                txtMobile.Text = "";
                txtAdd1.Text = "";
                txtAdvance.Value = 0;
                iContentId = 0;
                entGuest = new Guests();
                e_GuestDTLs = new GuestDTLs();
                DefaultCreditCard = 0;
                DefaultCreditCardNumber = string.Empty;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void FnClearAll()
        {
            try
            {
                entCheckIn = new CheckIn();
                entCheckInDTLList = new List<CheckInExtraServiceDTL>();
                entOldCheckInDTLList = new List<CheckInExtraServiceDTL>();

                entCheckInPaymentList = new List<CheckInPayment>();
                entOldCheckInPaymentList = new List<CheckInPayment>();                
                
                cmbRoomType.Tag = null;
                cmbBooking.DataSource = null;
                lblOpBalance.DataSource = new DataTable();
                lblExternal.DataSource = new DataTable();
                errProvider.Clear();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SetDefaultComboValues()
        {
            cmbGuestType.SelectedValue =
                cmbSource.SelectedValue = cmbAgent.SelectedValue = 0;

            ActiveControl = cmbRateType;
            cmbRateType.SelectedValue = 0;

            ActiveControl = cmbCurrency;
            cmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;

            ActiveControl = cmbRoomOrHall;
            cmbRoomOrHall.Text = MessageKeys.MsgRoom;
        }
        private bool ValidateRoomRate()
        {
            try
            {
                if (cmbRoomType.Text.Trim() == "") { return false; }
                if (cmbRateType.Text.Trim() == "") { return false; }
                if (txtExRate.Value == 0) { return false; }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void ShowToolTips()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                tooltip.SetToolTip(cmbRoomOrHall, MessageKeys.MsgRoomOrHallMustBeChosen);
                tooltip.SetToolTip(cmbRoomType, MessageKeys.MsgRoomTypeMustBeChosen);
                tooltip.SetToolTip(cmbRoom, MessageKeys.MsgRoomMustBeChosen);
                tooltip.SetToolTip(cmbRateType, MessageKeys.MsgRateTypeMustBeChosen);
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void InitEntities()
        {
            try
            {                                                               
                entRoomTypes = dbh.RoomTypes.ToList();
                entRooms = dbh.Rooms.ToList();                
                entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                NumberFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimals;
                sQtyFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimalsQty;

                txtAddBedRate.Format = NumberFormat;
                txtAddPersonRate.Format = NumberFormat;
                txtVoucherDiscountAmount.Format = NumberFormat;

                txtRate.Format = NumberFormat;
                txtDeductionPerc.Format = NumberFormat;
                txtDeductionAmount.Format = NumberFormat;

                txtGross.Format = NumberFormat;
                txtTotalTax.Format = NumberFormat;
                txtTotalDiscount.Format = NumberFormat;

                txtNetTotal.Format = NumberFormat;
                txtPayment.Format = NumberFormat;
                txtExtraServices.Format = NumberFormat;
                txtOpBalance.Format = NumberFormat;
                txtAdvance.Format = NumberFormat;
                txtBalance.Format = NumberFormat;
                lblGrandTotal.Format = NumberFormat;
                lblTotalTax.Format = NumberFormat;
                txtExRate.Format = NumberFormat;
                txtExternalAmt.Format = NumberFormat;
                lblOpBalance.Format = NumberFormat;
                lblExternal.Format = NumberFormat;

                lblCurrencyCap.Visible = GlobalFunctions.blnMultiCurrency;
                cmbCurrency.Visible = GlobalFunctions.blnMultiCurrency;
                lblExRateCap.Visible = GlobalFunctions.blnMultiCurrency;
                txtExRate.Visible = GlobalFunctions.blnMultiCurrency;
                lblMandatory11.Visible = GlobalFunctions.blnMultiCurrency;

                grpDiscountVoucher.Visible = GlobalFunctions.blnDiscountVoucherInSalesTransactions;

                List<DefaultUserSettingMapping> usrmap = dbh.DefaultUserSettingMappings.Where(x => x.FK_LoginUserID == GlobalFunctions.LoginUserID).ToList();
                if (usrmap != null && usrmap.Count > 0)
                {
                    PrintPreview = usrmap.Where(x => x.FK_DefaultUserSettingsID == 1).SingleOrDefault().Value == 1 ? true : false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SetDefaultDateAndTime()
        {
            try
            {                                
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
                txtNoOfDays.Value = 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ChangeLabelCaptions()
        {
            try
            {
                if (cmbRoomOrHall.Text == MessageKeys.MsgHall)
                {
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        lblRoomType.Text = MessageKeys.MsgHallType;
                        lblRoom.Text = MessageKeys.MsgHall;
                    }
                    else
                    {
                        lblRoomType.Text = MessageKeys.MsgHallType + " :";
                        lblRoom.Text = MessageKeys.MsgHall + " :";
                    }
                }
                else
                {
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        lblRoomType.Text = MessageKeys.MsgRoomType;
                        lblRoom.Text = MessageKeys.MsgRoom;
                    }
                    else
                    {
                        lblRoomType.Text = MessageKeys.MsgRoomType + " :";
                        lblRoom.Text = MessageKeys.MsgRoom + " :";
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadGuestInfo(Int64 Guestid)
        {
            try
            {
                entGuest = dbh.Guests.Where(x => x.id == Guestid).SingleOrDefault();
                e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == Guestid).SingleOrDefault();
                if (entGuest != null && e_GuestDTLs != null && cmbGuest.Text != "")
                {
                    txtTelephone.Text = Convert.ToString(e_GuestDTLs.Telephone);
                    txtMobile.Text = Convert.ToString(e_GuestDTLs.Mobile);
                    txtAdd1.Text = Convert.ToString(e_GuestDTLs.Address1);
                    DefaultCreditCard = e_GuestDTLs.FK_CreditCardType.ToInt32();
                    DefaultCreditCardNumber = e_GuestDTLs.CreditCardNo.ToString();
                    if (NewRecord)
                    {
                        if (txtDeductionPerc.Value != e_GuestDTLs.DiscountPerc.Value && _OnLoad == false)
                        {
                            if (atMessageBox.Show(MessageKeys.MsgDoYouWantApplyDedcutionPercentage, MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                txtDeductionPerc.Value = e_GuestDTLs.DiscountPerc.Value;                                
                            }
                        }
                    }
                    if (cmbGuest.SelectedValue.ToInt32() != entCheckIn.FK_GuestID)
                    {
                        cmbBillingAccount.SelectedValue = entGuest.FK_AccountID.ToString().ToInt32();
                        cmbCurrency.SelectedValue = entGuest.FK_CurrencyHDRID.ToInt32();
                    }
                    else
                    {
                        cmbBillingAccount.SelectedValue = entCheckIn.FK_BillingAccountID;
                        cmbCurrency.SelectedValue = entCheckIn.FK_CurrencyHdrID;
                        txtExRate.Value = entCheckIn.ExRate.ToDecimal();
                    }
                }
                int GuestId = cmbGuest.SelectedValue.ToInt32();
                List<int> entBookingID =  (from ck in dbh.CheckIns
                                           join bk in dbh.Bookings on ck.FK_BookingID equals bk.id
                                           where ck.FK_GuestID == GuestId
                                           select bk.id ).ToList();
                List<Booking> entBookings = dbh.Bookings.Where(x => !entBookingID.Contains(x.id) && x.FK_GuestID == GuestId).ToList();
                if (entCheckIn.FK_BookingID != null && entCheckIn.FK_BookingID != 0)
                {
                    int BookingID = entCheckIn.FK_BookingID.ToInt32();
                    Booking entBooking = dbh.Bookings.Where(x => x.id == BookingID && x.FK_GuestID == GuestId).SingleOrDefault();
                    entBookings.Add(entBooking);
                }
                cmbBooking.DataSource = entBookings;
                cmbBooking.DisplayMember = "VoucherNo";
                cmbBooking.ValueMember = "id";
                cmbBooking.SelectedIndex = -1;
                iContentId = 1;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        #endregion

        #region Calculation Methods
        private void CalcRoomRent()
        {
            if (!_OnLoad)
            {
                if (!ValidateRoomRate())
                {
                    txtRate.Value = 0;
                    txtAddBedRate.Value = 0;
                    txtAddPersonRate.Value = 0;
                    CalcNetTotal();
                    return;
                }

                int iRateTypeId = cmbRateType.SelectedValue.ToInt32();
                int iRoomTypeId = cmbRoomType.SelectedValue.ToInt32();
                e_RoomTariffs = RateCalculationClass.GetTariffs(dbh, iRoomTypeId, iRateTypeId);
                if (e_RoomTariffs != null)
                {
                    txtRate.Value = e_RoomTariffs.BaseRate.ToDecimal() / txtExRate.Value;
                    txtAddBedRate.Value = e_RoomTariffs.ExtraBedRate.ToDecimal() / txtExRate.Value;
                    txtAddPersonRate.Value = e_RoomTariffs.AdditionalPersonRate.ToDecimal() / txtExRate.Value;
                }
                else
                {
                    txtRate.Value = 0;
                    txtAddBedRate.Value = 0;
                    txtAddPersonRate.Value = 0;
                }
                CalcNetTotal();
            }
        }
        private void CalcGrandTotal()
        {
            try
            {
                lblGrandTotal.Value = txtNetTotal.Value + txtOpBalance.Value + txtExternalAmt.Value;

                txtBalance.Value = lblGrandTotal.Value  - (txtAdvance.Value + txtPayment.Value);                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcNetTotal(bool blnUpdateDeductionAmount = true)
        {
            try
            {
                if (_OnLoad) { return; }
                txtRoomTotal.Value = txtNoOfDays.Value * txtRate.Value;
                txtRoomRent.Value = txtNoOfDays.Value * txtRate.Value;
                txtAddlBedTotal.Value = txtAdditionalBeds.Value * txtAddBedRate.Value;
                txtAddlPsnTotal.Value = txtAddPersons.Value * txtAddPersonRate.Value;
                txtExtraBedAndPer.Value = txtAddlBedTotal.Value + txtAddlPsnTotal.Value;
                txtGross.Value = txtRoomRent.Value + txtAddlBedTotal.Value + txtAddlPsnTotal.Value;

                CalculateSlab(blnUpdateDeductionAmount);
                if (!blnUpdateDeductionAmount)
                {
                    txtDeductionPerc.Value = entCheckIn.DeductionPerc.ToDecimal();
                }
                else
                {
                    txtDeductionAmount.Value = entCheckIn.DeductionAmount.ToDecimal();
                }

                txtTotalDiscount.Value = entCheckIn.SlabDiscount.ToDecimal() + entCheckIn.DeductionAmount.ToDecimal() + txtVoucherDiscountAmount.Value;
                lblTotalTax.lblTax1 = entCheckIn.Tax1Amount.ToDecimal();
                lblTotalTax.lblTax2 = entCheckIn.Tax2Amount.ToDecimal();
                lblTotalTax.lblTax3 = entCheckIn.Tax3Amount.ToDecimal();
                lblTotalTax.lblAddnlTax = entCheckIn.AddnlTaxAmount.ToDecimal();
                lblTotalTax.lblExciseDuty = entCheckIn.ExciseAmount.ToDecimal();
                lblTotalTax.lblVAT = entCheckIn.VATAmount.ToDecimal();
                lblTotalTax.lblCGST = entCheckIn.CGSTAmount.ToDecimal();
                lblTotalTax.lblSGST = entCheckIn.SGSTAmount.ToDecimal();
                lblTotalTax.lblIGST = entCheckIn.IGSTAmount.ToDecimal();
                txtExtraServices.Value = entCheckInDTLList.Sum(x => x.NetAmount).ToDecimal();
                txtTotalTax.Value = lblTotalTax.TotalTax;
                txtNetTotal.Value = (txtGross.Value + txtTotalTax.Value) - txtTotalDiscount.Value + txtExtraServices.Value;
                
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcOpeningAndExternalAmt()
        {
            CalcOpeningBalance();
            CalcExternalAmt();
        }
        private void CalcOpeningBalance()
        {
            try 
            {
                if (txtExRate.Value == 0) { return; }                
                SPGetGuestBillsParam param = new SPGetGuestBillsParam()
                {
                    AccountID = cmbBillingAccount.SelectedValue.ToInt32(),
                    FromDate = GlobalFunctions.dtFinancialFromDate,
                    ToDate = dtpArrivalDate.Value.AddMilliseconds(-1),
                    BookingID = (entBookings == null ? 0 : entBookings.id),
                    CheckInID = (entCheckIn == null ? 0 : entCheckIn.id),
                    CheckOutID = -1,                   
                    ExRate = txtExRate.Value,
                    IsGroupTrans = false
                };                
                lblOpBalance.DataSource = GlobalMethods.GetGuestBills(param);
                txtOpBalance.Value = lblOpBalance.TotalAmount;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcExternalAmt()
        {
            try
            {
                if (txtExRate.Value == 0) { return; }
                SPGetGuestBillsParam param = new SPGetGuestBillsParam()
                {
                    AccountID = cmbBillingAccount.SelectedValue.ToInt32(),
                    FromDate = dtpArrivalDate.Value,
                    ToDate = dtpDepartureDate.Value,
                    BookingID = (entBookings == null ? 0 : entBookings.id),
                    CheckInID = (entCheckIn == null ? 0 : entCheckIn.id),
                    CheckOutID = -1,
                    ExRate = txtExRate.Value,
                    IsGroupTrans = false
                };                
                lblExternal.DataSource = GlobalMethods.GetGuestBills(param);
                txtExternalAmt.Value = lblExternal.TotalAmount;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcPaymentTotal()
        {
            try
            {
                txtPayment.Value = entCheckInPaymentList.Sum(x => x.Payment).ToDecimal();
                txtBalance.Value = txtNetTotal.Value - (txtAdvance.Value + txtPayment.Value);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Public Methods
        public override void LoadVouchers()
        {
            try
            {
                string sTempVno = txtVoucherNo.Text;
                dbh = atHotelContext.CreateContext();
                List<UpDownData> _Vouchers = dbh.CheckIns.OrderByDescending(x => x.id)
                    .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                    .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
                txtVoucherNo.Items.Clear();
                txtVoucherNo.DataSource = _Vouchers;
                if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
                txtVoucherNo.Text = sTempVno;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            CheckIn checkIn = dbh.CheckIns.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (checkIn != null)
            {
                ReLoadData(checkIn.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                ReloadDataFromCheckIn(dbh.CheckIns.Where(x => x.id == ID).SingleOrDefault());
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void ReloadDataFromCheckIn(CheckIn checkIn)
        {
            entCheckIn = checkIn;
            if (entCheckIn != null)
            {
                NewRecord = false;
                _OnLoad = true;
                #region Add Inactive Accounts
                #region Employee
                if (entCheckIn.FK_EmployeeID != null)
                {
                    if (entEmployees.Where(x => x.id == entCheckIn.FK_EmployeeID).ToList().Count == 0)
                    {
                        Employee _Employee = new Employee();
                        _Employee = dbh.Employees.Where(x => x.id == entCheckIn.FK_EmployeeID).SingleOrDefault();
                        entEmployees.Add(_Employee);
                        objLib.fnFillCombo(ref cmbEmployee, entEmployees, "Name", "id");
                    }
                }
                #endregion

                #region Agent
                if (entCheckIn.FK_AgentID != null)
                {
                    if (entAgents.Where(x => x.id == entCheckIn.FK_AgentID).ToList().Count == 0)
                    {
                        Agent _Agent = new Agent();
                        _Agent = dbh.Agents.Where(x => x.id == entCheckIn.FK_AgentID).SingleOrDefault();
                        entAgents.Add(_Agent);
                        objLib.fnFillCombo(ref cmbAgent, entAgents, "Name", "id");
                    }
                }
                #endregion
                #endregion

                #region CheckIn Data
                txtVoucherNo.Text = entCheckIn.VoucherNo;
                dtVoucherDate.Value = entCheckIn.VoucherDate.Value;

                ActiveControl = cmbGuest;
                cmbGuest.SelectedValue = entCheckIn.FK_GuestID;

                cmbBillingAccount.SelectedValue = entCheckIn.FK_BillingAccountID;
                txtGuestVehicleName.Text = entCheckIn.GuestVehicleName;
                txtGuestVehicleNo.Text = entCheckIn.GuestVehicleNo;
                cmbGuestVehicleType.Text = entCheckIn.GuestVehicleType;
                cmbCurrency.SelectedValue = entCheckIn.FK_CurrencyHdrID;
                txtExRate.Value = entCheckIn.ExRate.ToDecimal();
                if (entCheckIn.GuestType != null)
                {
                    cmbGuestType.SelectedText = entCheckIn.GuestType;
                }
                else
                {
                    cmbGuestType.SelectedText = MessageKeys.MsgNone;
                }
                if (entCheckIn.Source != null)
                {
                    cmbSource.Text = entCheckIn.Source;
                }
                else
                {
                    cmbSource.SelectedText = MessageKeys.MsgNone;
                }
                if (entCheckIn.FK_AgentID != null)
                {
                    cmbAgent.SelectedValue = entCheckIn.FK_AgentID;
                }
                else
                {
                    cmbAgent.SelectedValue = 0;
                }
                if (entCheckIn.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = entCheckIn.FK_EmployeeID;
                }
                txtRemarks.Text = entCheckIn.Remarks;

                if (entCheckIn.FK_BookingID != null)
                {
                    cmbBooking.SelectedValue = entCheckIn.FK_BookingID;
                }
                else
                {
                    cmbBooking.SelectedIndex = -1;
                }

                dtpArrivalDate.Text = entCheckIn.ArrivalDate.Value.ToString();
                dtpDepartureDate.Text = entCheckIn.DepartureDate.Value.ToString();
                txtNoOfDays.Text = entCheckIn.NoofDays.ToString();
                txtAdult.Value = entCheckIn.Adult.Value;
                txtChild.Value = entCheckIn.Child.Value;

                ActiveControl = cmbRoomOrHall;
                cmbRoomOrHall.Text = entCheckIn.RoomorHall == 1 ? MessageKeys.MsgHall : MessageKeys.MsgRoom;

                ActiveControl = cmbRoomType;
                cmbRoomType.SelectedValue = entCheckIn.FK_RoomTypeID;

                cmbRoom.SelectedValue = entCheckIn.FK_RoomID;
                if (entCheckIn.FK_RateTypeID == null)
                {
                    cmbRateType.SelectedValue = 0;
                }
                else
                {
                    cmbRateType.SelectedValue = entCheckIn.FK_RateTypeID;
                }
                txtRate.Value = entCheckIn.Rate.Value;
                txtAddBedRate.Value = entCheckIn.AdditionalBedRate.ToDecimal();
                txtAdditionalBeds.Value = entCheckIn.AdditionalBeds.ToInt32();
                txtAddPersonRate.Value = entCheckIn.AdditionalPersonRate.ToDecimal();
                txtAddPersons.Value = entCheckIn.AdditionalPersons.ToInt32();
                txtDeductionPerc.Value = entCheckIn.DeductionPerc ?? 0;
                txtDeductionAmount.Value = entCheckIn.DeductionAmount ?? 0;
                txtGross.Value = entCheckIn.GrandTotal.Value;
                txtTotalTax.Value = entCheckIn.TotalTaxAmount.Value;
                txtExtraServices.Value = entCheckIn.ExtraServices.ToDecimal();
                txtPayment.Value = entCheckIn.Payment.Value;
                txtBalance.Value = entCheckIn.Balance.Value; ;
                txtVoucherDiscountAmount.Value = entCheckIn.VoucherDiscountAmount.Value;
                cmbVoucherDiscount.SelectedValue = entCheckIn.FK_VoucherDiscountID;
                #endregion

                #region Reload Extra Service Details
                var CurrentDtl = (from pdtl in dbh.CheckInExtraServiceDTLs
                                  join prd in dbh.ExtraServices on pdtl.FK_ExtraServiceID equals prd.id
                                  where pdtl.FK_CheckInID == entCheckIn.id
                                  select new { pdtl, prd }).ToList();
                CurrentDtl.ForEach(x =>
                {
                    x.pdtl.ServiceCode = x.prd.Code;
                    x.pdtl.ServiceName = x.prd.Name;
                });
                entCheckInDTLList = CurrentDtl.Select(x => x.pdtl).OrderBy(x => x.id).ToList();
                entOldCheckInDTLList = new List<CheckInExtraServiceDTL>(entCheckInDTLList);
                #endregion

                #region Reload Payment Details
                entCheckInPaymentList = dbh.CheckInPayments.Where(x => x.FK_CheckInID == entCheckIn.id).ToList();
                entOldCheckInPaymentList = new List<CheckInPayment>(entCheckInPaymentList);
                #endregion
                _OnLoad = false;
                CalcNetTotal(false);
                CalcPaymentTotal();
                CalcOpeningAndExternalAmt();
                CalcGrandTotal();
            }
        }
        public void SetDepartureDate(DateTime dateTime)
        {
            ActiveControl = dtpDepartureDate;
            dtpDepartureDate.Value = dateTime;
        }
        public void SetArrivalDate(DateTime dateTime)
        {
            ActiveControl = dtpArrivalDate;
            dtpArrivalDate.Value = dateTime;
        }
        public void SetRoom(int iRommID)
        {
            _SelectedRoomID = iRommID;
            PopulateSelectedRoom();
        }
        public void SetNewRecord()
        {
            NewRecord = true;
            FnClearAll();
            GetSeqNo();
        }
        public void SetDB(atACCHotelEntities db)
        {
            dbh = db;
        }
        public CheckIn SaveData()
        {
            #region Voucher Posting

            if (!blnSanctioningRequired)
            {
                PostVoucher();
            }

            //Rent
            if (!blnSanctioningRequired)
            {
                entCheckIn.FK_VoucherHDRID = entVoucherHdr.id;
            }
            else
            {
                GlobalMethods.DeleteVoucher(entCheckIn.FK_VoucherHDRID, ref dbh);
                entCheckIn.FK_VoucherHDRID = null;
            }

            //Payment
            if (!blnSanctioningRequired && entCheckInPaymentList.Count() > 0)
            {
                entCheckIn.FK_PaymentVoucherHDRID = entVoucherHdrPayment.id;
            }
            else
            {
                GlobalMethods.DeleteVoucher(entCheckIn.FK_PaymentVoucherHDRID, ref dbh);
                entCheckIn.FK_PaymentVoucherHDRID = null;
            }
            #endregion

            #region CheckIn Details
            entCheckIn.ContextID = iContextID;
            entCheckIn.LoginUserID = GlobalFunctions.LoginUserID;
            entCheckIn.LocationID = GlobalFunctions.LoginLocationID;
            entCheckIn.VoucherNo = txtVoucherNo.Text;
            entCheckIn.VoucherDate = dtVoucherDate.Value;
            entCheckIn.FK_GuestID = cmbGuest.SelectedValue.ToString().ToInt32();
            entCheckIn.FK_BillingAccountID = cmbBillingAccount.SelectedValue.ToString().ToInt32();
            entCheckIn.GuestVehicleName = txtGuestVehicleName.Text;
            entCheckIn.GuestVehicleNo = txtGuestVehicleNo.Text;
            entCheckIn.GuestVehicleType = cmbGuestVehicleType.Text;
            entCheckIn.FK_CurrencyHdrID = cmbCurrency.SelectedValue.ToString2().ToInt32();
            entCheckIn.ExRate = txtExRate.Value;
            if (cmbGuestType.Text != MessageKeys.MsgNone)
            {
                entCheckIn.GuestType = cmbGuestType.Text.ToString();
            }
            else
            {
                entCheckIn.GuestType = null;
            }
            if (cmbSource.Text != MessageKeys.MsgNone)
            {
                entCheckIn.Source = cmbSource.Text.ToString();
            }
            else
            {
                entCheckIn.Source = null;
            }
            if (cmbAgent.Text != null && cmbAgent.SelectedValue.ToInt32() != 0)
            {
                entCheckIn.FK_AgentID = cmbAgent.SelectedValue.ToString().ToInt32();
            }
            else
            {
                entCheckIn.FK_AgentID = null;
            }
            if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
            {
                entCheckIn.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
            }
            else
            {
                entCheckIn.FK_EmployeeID = null;
            }
            entCheckIn.Remarks = txtRemarks.Text;
            if (cmbBooking.Text != null && cmbBooking.SelectedValue.ToInt32() != 0)
            {
                entCheckIn.FK_BookingID = cmbBooking.SelectedValue.ToString().ToInt32();
            }
            else
            {
                entCheckIn.FK_BookingID = null;
            }
            entCheckIn.ArrivalDate = dtpArrivalDate.Value;
            entCheckIn.DepartureDate = dtpDepartureDate.Value;
            entCheckIn.NoofDays = txtNoOfDays.Value.ToInt32();
            entCheckIn.Adult = txtAdult.Value.ToInt32();
            entCheckIn.Child = txtChild.Value.ToInt32();
            if (cmbRoomOrHall.Text == MessageKeys.MsgRoom)
            {
                entCheckIn.RoomorHall = 0;
            }
            else
            {
                entCheckIn.RoomorHall = 1;
            }
            entCheckIn.FK_RoomTypeID = cmbRoomType.SelectedValue.ToString().ToInt32();
            entCheckIn.FK_RoomID = cmbRoom.SelectedValue.ToString().ToInt32();
            if (cmbRateType.Text == MessageKeys.MsgDefault && cmbRateType.SelectedValue.ToInt32() == 0)
            {
                entCheckIn.FK_RateTypeID = null;
            }
            else
            {
                entCheckIn.FK_RateTypeID = cmbRateType.SelectedValue.ToString().ToInt32();
            }
            entCheckIn.Rate = txtRate.Value;
            entCheckIn.AdditionalBeds = txtAdditionalBeds.Text.ToInt32();
            entCheckIn.AdditionalBedRate = txtAddBedRate.Value;
            entCheckIn.AdditionalPersons = txtAddPersons.Text.ToInt32();
            entCheckIn.AdditionalPersonRate = txtAddPersonRate.Value;
            entCheckIn.DeductionPerc = txtDeductionPerc.Value;
            entCheckIn.DeductionAmount = txtDeductionAmount.Value;
            entCheckIn.TotalTaxAmount = txtTotalTax.Value;
            entCheckIn.ExtraServices = txtExtraServices.Value;
            entCheckIn.VoucherDiscountAmount = txtVoucherDiscountAmount.Value;
            entCheckIn.TotalTax = txtTotalTax.Value;
            entCheckIn.GrandTotal = txtNetTotal.Value;
            entCheckIn.OpeningBalance = txtOpBalance.Value;
            entCheckIn.Payment = txtPayment.Value;
            entCheckIn.Balance = txtBalance.Value;
            entCheckIn.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
            entCheckIn.Sanctioned = !blnSanctioningRequired;
            entCheckIn.Cancelled = false;
            if (NewRecord)
            {
                dbh.CheckIns.AddObject(entCheckIn);
            }
            else
            {
                dbh.ObjectStateManager.ChangeObjectState(entCheckIn, EntityState.Modified);
            }
            #endregion

            #region Removing Deleted CheckInExtraServices
            var d1 = entOldCheckInDTLList.Select(x => new { id = x.id });
            var d2 = entCheckInDTLList.Select(y => new { id = y.id });
            var deleteddtls = d1.Except(d2);
            foreach (var deletedItem in deleteddtls)
            {
                CheckInExtraServiceDTL delItDtl = entOldCheckInDTLList.Where(x => x.id == deletedItem.id).First();
                dbh.CheckInExtraServiceDTLs.DeleteObject(delItDtl);
            }
            #endregion

            #region Adding or Updating CheckInExtraSevices
            foreach (CheckInExtraServiceDTL ExtraService in entCheckInDTLList)
            {
                if (ExtraService.FK_ExtraServiceID != null)
                {
                    ExtraService.FK_CheckInID = entCheckIn.id;
                    if (dbh.CheckInExtraServiceDTLs.Where(x => x.id == ExtraService.id).ToList().Count == 0)
                    {
                        dbh.CheckInExtraServiceDTLs.AddObject(ExtraService);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(ExtraService, System.Data.EntityState.Modified);
                    }
                }
            }
            #endregion

            #region Removing Deleted Payments
            var p1 = entOldCheckInPaymentList.Select(x => new { id = x.id });
            var p2 = entCheckInPaymentList.Select(y => new { id = y.id });
            var deletedpayments = p1.Except(p2);
            foreach (var deletedItem in deletedpayments)
            {
                CheckInPayment delItPay = entOldCheckInPaymentList.Where(x => x.id == deletedItem.id).First();
                dbh.CheckInPayments.DeleteObject(delItPay);
            }
            #endregion

            #region Adding or Updating Payments
            foreach (CheckInPayment CheckInPayment in entCheckInPaymentList)
            {
                if (CheckInPayment.Payment != 0)
                {
                    CheckInPayment.FK_CheckInID = entCheckIn.id;
                    if (CheckInPayment.FK_MVInstrumentTypeID == 0)
                    {
                        CheckInPayment.FK_MVInstrumentTypeID = null;
                    }
                    if (dbh.CheckInPayments.Where(x => x.id == CheckInPayment.id).ToList().Count == 0)
                    {
                        dbh.CheckInPayments.AddObject(CheckInPayment);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(CheckInPayment, System.Data.EntityState.Modified);
                    }
                }
            }
            #endregion

            #region Save to RoomStatusRegister
            if (cmbBooking.SelectedValue != null)
            {
                entCheckIn.FK_RefTransTypeID = (int)ENMVMTTransactionType.HTL_Booking;
                entCheckIn.FK_RefTransID = cmbBooking.SelectedValue.ToInt32();
            }
            GlobalMethods.SaveRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_CheckIn, entCheckIn);
            #endregion

            return entCheckIn;
        }
        #endregion

        #region Form event
        private void cmbGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    cmbGuest.SelectedValue = frm.SelectedGuestID;
                    cmbGuest.Text = frm.SelectedGuestName;
                    cmbGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewGuest_Click(object sender, EventArgs e)
        {
            try
            {
                GuestView guestView = new GuestView(true);
                guestView.EditButton.Visible = false;
                guestView.SearchButton.Visible = false;
                if (guestView.ShowDialog() == DialogResult.OK)
                {
                    cmbGuest.DataSource = GlobalMethods.GetGuests();
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = guestView.CurrentID;

                    List<AccountLedger> entDebtors = getAccc.GetAccountLedgers(25);
                    cmbBillingAccount.DataSource = entDebtors;
                    cmbBillingAccount.DisplayMember = "LedgerName";
                    cmbBillingAccount.ValueMember = "id";
                    cmbBillingAccount.SelectedIndex = -1;                    
                    cmbBillingAccount.Focus();
                }
                else
                {
                    cmbGuest.Focus();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbGuest_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (!IsActiveControl(sender)) { return; }

                ClearGuestInfo();
                LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
                CalcNetTotal();                
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void btnNewGuestType_Click(object sender, EventArgs e)
        {
            try
            {
                GuestTypeView guestType = new GuestTypeView();
                guestType.ShowDialog();
                cmbGuestType.DataSource = GlobalMethods.GetGuestTypes();
                cmbGuestType.SelectedValue = guestType.CurrentID;
                cmbGuestType.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewSource_Click(object sender, EventArgs e)
        {
            try
            {
                SourceView Source = new SourceView();
                Source.ShowDialog();
                cmbSource.DataSource = GlobalMethods.GetSources();
                cmbSource.SelectedValue = Source.CurrentID;
                cmbSource.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnBooking_Click(object sender, EventArgs e)
        {
            try
            {
                BookingView iBooking = new BookingView();
                iBooking.ShowDialog();
                cmbBooking.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbBooking_SelectedValueChanged(object sender, EventArgs e)
        {
            if (iContentId > 0 && cmbBooking.Text.Trim() != "" && cmbBooking.SelectedValue.ToInt32() != 0)
            {
                int Id = cmbBooking.SelectedValue.ToInt32();
                entBookings = dbh.Bookings.Where(x => x.id == Id).SingleOrDefault();
                entBookingPaymentList = dbh.BookingPayments.Where(x => x.FK_BookingID == Id).ToList();
                txtAdvance.Value = entBookingPaymentList.Sum(x => x.Payment).ToDecimal();
                if (entBookings != null)
                {
                    #region Load Booking Info
                    txtAdult.Value = entBookings.Adult.toInt32();
                    txtChild.Value = entBookings.Child.toInt32();
                    dtpArrivalDate.Text = entBookings.ArrivalDate.Value.ToString();
                    dtpDepartureDate.Text = entBookings.DepartureDate.Value.ToString();
                    txtNoOfDays.Value = entBookings.NoofDays.toInt32();
                    cmbRoomOrHall.Text = entBookings.RoomorHall == 1 ? MessageKeys.MsgHall : MessageKeys.MsgRoom;
                    cmbSource.Text = entBookings.Source;
                    cmbGuestType.Text = entBookings.GuestType;
                    cmbRoomType.SelectedValue = entBookings.FK_RoomTypeID;
                    PopulateRooms();
                    cmbRoom.SelectedValue = entBookings.FK_RoomID;
                    if (entBookings.FK_RateTypeID == null)
                        cmbRateType.SelectedValue = 0;
                    else
                        cmbRateType.SelectedValue = entBookings.FK_RateTypeID;
                    if (entBookings.FK_AgentID != null)
                    {
                        cmbAgent.SelectedValue = entBookings.FK_AgentID;
                    }
                    txtRate.Value = entBookings.Rate.Value;
                    txtDeductionPerc.Value = entBookings.DeductionPerc ?? 0;
                    txtDeductionAmount.Value = entBookings.DeductionAmount ?? 0;                    
                    #endregion
                }
                CalcOpeningAndExternalAmt();
                CalcRoomRent();                
            }
        }
        private void dtpArrivalDate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.IsActiveControl(sender, true))
                {                    
                    txtNoOfDays.Text = GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpDepartureDate.Value).ToString();
                    CalcRoomRent();
                    CalcOpeningAndExternalAmt();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtAdult_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab && cmbRateType.Text.Trim() != null)
                {
                    CalcNetTotal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbHall_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsActiveControl(sender))
                {
                    PopulateRoomTypes();
                    ChangeLabelCaptions();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbRoomOrHall_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsActiveControl(sender))
                {
                    PopulateRoomTypes();
                    ChangeLabelCaptions();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbRoomType_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsActiveControl(sender))
                {
                    PopulateRooms();
                    CalcRoomRent();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbRateType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsActiveControl(sender))
                    CalcRoomRent();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtRate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsActiveControl(sender))
                    CalcNetTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtAdditionalBeds_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtAddlBedTotal.Value = txtAdditionalBeds.Value * txtAddBedRate.Value;
                CalcNetTotal();
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtAddBedRate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtAddlBedTotal.Value = txtAdditionalBeds.Value * txtAddBedRate.Value;
                CalcNetTotal();
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtAddPersons_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtAddlBedTotal.Value = txtAdditionalBeds.Value * txtAddBedRate.Value;
                CalcNetTotal();
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtAddPersonRate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtAddlBedTotal.Value = txtAdditionalBeds.Value * txtAddBedRate.Value;
                CalcNetTotal();
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtDeductionPerc_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab)
                {
                    CalcNetTotal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtDeductionAmount_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab)
                {
                    CalcNetTotal(false);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnExtraServ_Click(object sender, EventArgs e)
        {
            try
            {
                //Copy entCheckInDTLList to ExtraServiceDTLs
                List<ExtraServiceDTLs> extraServiceDTLs = new List<ExtraServiceDTLs>();
                foreach (CheckInExtraServiceDTL item in entCheckInDTLList)
                {
                    ExtraServiceDTLs serviceDTL = new ExtraServiceDTLs();
                    item.CopyTo(serviceDTL, true);
                    extraServiceDTLs.Add(serviceDTL);
                }
                CheckInExtraServicesView checkInExtraServicesView = new CheckInExtraServicesView(dbh, extraServiceDTLs, NumberFormat, sQtyFormat,  txtExRate.Value);
                if (checkInExtraServicesView.ShowDialog() == DialogResult.OK)
                {

                    //Add / Update ExtraServiceDTLs to entCheckInDTLList                     
                    int iIndex = 0;
                    int iCurrentCount = entCheckInDTLList.Count;
                    checkInExtraServicesView.ExtraServiceDTLs.ForEach(x =>
                    {
                        iIndex++;
                        CheckInExtraServiceDTL extraServiceDTL;
                        if (iIndex > iCurrentCount)
                        {
                            extraServiceDTL = new CheckInExtraServiceDTL();
                        }
                        else
                        {
                            extraServiceDTL = entCheckInDTLList[iIndex - 1];
                        }                                                
                        x.CopyTo(extraServiceDTL, true);
                        if (iIndex > iCurrentCount)
                        {
                            entCheckInDTLList.Add(extraServiceDTL);
                        }
                        
                    });
                    //Remove deleted extra service dtls
                    if (iIndex < iCurrentCount)
                    {
                        for (int i = iIndex; i < iCurrentCount; i++)
                        {
                            entCheckInDTLList.RemoveAt(iIndex);
                        }
                    }
                    CalcNetTotal();
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        private void btnPayment_Click(object sender, EventArgs e)
        {
            try
            {
                decimal PayAmt = txtNetTotal.Value - txtAdvance.Value;
                CheckInPaymentView payment = new CheckInPaymentView(entCheckInPaymentList, PayAmt, NumberFormat,DefaultCreditCard,DefaultCreditCardNumber);
                if (payment.ShowDialog() == DialogResult.OK)
                {
                    CalcPaymentTotal();
                    CalcGrandTotal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            try
            {
                CheckOutView checkOUT = new CheckOutView(entCheckIn.id);
                if (checkOUT.ShowDialog() == DialogResult.OK)
                {
                    this.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurrency.ValueMember == "") { return; }
                if (cmbCurrency.SelectedValue == null) { return; }
                int iCurrencyID = cmbCurrency.SelectedValue.ToString2().ToInt32();

                CurrencyClass entCurrency = entCurrencys.Where(x => x.id == iCurrencyID).Single();
                Company company = dbh.Companies.Single();
                int _sourcecurrencyId = company.FK_Currency.toInt32();
                int _destinationCurrencyID = entCurrency.id;
                if (_sourcecurrencyId == _destinationCurrencyID)
                {
                    txtExRate.Enabled = false;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
                txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                ApplyExRate();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtExRate_Enter(object sender, EventArgs e)
        {
            try
            {
                previousExRate = txtExRate.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtExRate_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                ApplyExRate();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void cmbBillingAccount_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!_OnLoad)
            {
                CalcOpeningAndExternalAmt();
            }
        }

        #endregion

        #region Framework events
        public void CheckInView_atInitialise()
        {
            try
            {
                InitEntities();
                InitControls();
                LoadSettings();
                ShowToolTips();
                PopulateCombos();
                SettingsButton.Visible = true; ShareButton.Visible = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }
        private void CheckInView_atBeforeInitialise()
        {
            _OnLoad = true;
        }
        public void CheckInView_atAfterInitialise()
        {
            try
            {

                _OnLoad = false;
                CheckInView_atNewClick(null);
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void CheckInView_atNewClick(object source)
        {
            try
            {
                PopulateCheckIn();
                FnClearAll();
                ClearGuestInfo();
                SetDefaultDateAndTime();
                SetDefaultComboValues();                
                GetSeqNo();                
                CalcNetTotal();
                
                cmbGuest.Focus();          
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool CheckInView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "") 
                {
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNumberCannotBeBlank); 
                    txtVoucherNo.Focus(); 
                    return false; 
                }
                if (cmbGuest.Text.Trim() == "") 
                { 
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen); 
                    cmbGuest.Focus(); 
                    return false; 
                }
                if (cmbBillingAccount.Text.Trim() == "")
                {
                    errProvider.SetError(cmbBillingAccount, MessageKeys.MsgBillingAccountMustBeChosen);
                    cmbBillingAccount.Focus();
                    return false;
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                if (txtNoOfDays.Text.Trim() == "")
                {
                    errProvider.SetError(dtpArrivalDate, MessageKeys.MsgNumberofDaysMustBeEntered);
                    dtpArrivalDate.Focus();
                    return false;
                }
                if (txtNoOfDays.Value == 0)
                {
                    errProvider.SetError(txtNoOfDays, MessageKeys.MsgNumberofDaysMustBeGreaterThanZero);
                    txtNoOfDays.Focus();
                    return false;
                }
                if (txtAdult.Text.Trim() == "")
                {
                    errProvider.SetError(txtAdult, MessageKeys.MsgNumberOfAdultsMustBeEntered);
                    txtAdult.Focus();
                    return false;
                }
                if (txtAdult.Value == 0)
                {
                    errProvider.SetError(txtAdult, MessageKeys.MsgValueMustBeGreaterThanZero);
                    txtAdult.Focus();
                    return false;
                }
                iRoomType = cmbRoomType.SelectedValue.ToInt32();
                e_RoomTypes = dbh.RoomTypes.Where(x => x.id == iRoomType).SingleOrDefault();
                if (txtAdult.Value > e_RoomTypes.AdultOccupancy)
                {
                    errProvider.SetError(txtAdult, MessageKeys.MsgNumberOfAdultsExceededRoomOccupancy + " ( " + e_RoomTypes.AdultOccupancy + " ) ");
                    txtAdult.Focus();
                    return false;
                }
                if (cmbRoomOrHall.Text.Trim() == "")
                {
                    errProvider.SetError(cmbRoomOrHall, MessageKeys.MsgRoomOrHallMustBeChosen);
                    cmbRoomOrHall.Focus();
                    return false;
                }
                if (cmbRoomType.Text.Trim() == "")
                {
                    errProvider.SetError(cmbRoomType, MessageKeys.MsgRoomTypeMustBeChosen);
                    cmbRoomType.Focus();
                    return false;
                }
                if (cmbRoom.Text.Trim() == "")
                {
                    errProvider.SetError(cmbRoom, MessageKeys.MsgRoomMustBeChosen);
                    cmbRoom.Focus();
                    return false;
                }
                if (cmbRateType.Text.Trim() == "")
                {
                    errProvider.SetError(cmbRateType, MessageKeys.MsgRateTypeMustBeChosen);
                    cmbRateType.Focus();
                    return false;
                }
                if (txtRate.Text.Trim() == "")
                {
                    errProvider.SetError(txtRate, MessageKeys.MsgRateMustBeEntered);
                    txtAdult.Focus();
                    return false;
                }
                if (txtRate.Value == 0)
                {
                    errProvider.SetError(txtRate, MessageKeys.MsgRateMustBeGreaterThanZero);
                    txtAdult.Focus();
                    return false;
                }
                int _RoomType = cmbRoomType.SelectedValue.ToInt32();
                RoomTypes roomtype = dbh.RoomTypes.Where(x => x.id == _RoomType).SingleOrDefault();
                int AllowedAddBed = roomtype.MaxExtraBeds.toInt32();
                if (txtAdditionalBeds.Value > AllowedAddBed)
                {
                    errProvider.SetError(txtAdditionalBeds, MessageKeys.MsgAllowedNumberOfAdditionalBedsExceeded);
                    txtAdditionalBeds.Focus();
                    return false;
                }
                if (GlobalFunctions.blnMultiCurrency)
                {
                    if (cmbCurrency.SelectedValue == null) 
                    { 
                        errProvider.SetError(cmbCurrency, MessageKeys.MsgCurrencyMustBeSelected); 
                        cmbCurrency.Focus(); 
                        return false; 
                    }
                    if (txtExRate.Value == 0)
                    {
                        errProvider.SetError(txtExRate, MessageKeys.MsgExchangeRate + " " + MessageKeys.MsgValueMustBeGreaterThanZero);
                        txtExRate.Focus();
                        return false;
                    }
                }
                if (dtpArrivalDate.Value > DateTime.Now)
                {
                    { errProvider.SetError(dtpDepartureDate, "Arrival Date Must be less than Current Date"); dtpDepartureDate.Focus(); return false; }
                }
                int iBookingID = cmbBooking.SelectedValue.ToInt32();
                ENMVMTTransactionType? refTransType = (iBookingID > 0 ? (ENMVMTTransactionType?)ENMVMTTransactionType.HTL_Booking : null);
                int? refTransID = (iBookingID > 0 ? (int?)iBookingID : null);
                List<Rooms> rooms = GlobalMethods.GetAvailableRooms(dtpArrivalDate.Value, dtpDepartureDate.Value,
                                                                    ENMVMTTransactionType.HTL_CheckIn, entCheckIn.id,
                                                                    refTransType, refTransID);
                int iRoomID = cmbRoom.SelectedValue.ToInt32();
                if (!rooms.Where(x => x.id == iRoomID).Any())
                {
                    errProvider.SetError(cmbRoom, "Room is not Available.");
                    cmbRoom.Focus();
                    return false;
                }

                RoomStatusRegister roomStatus = GlobalMethods.GetRoomStatusByDate(dtpArrivalDate.Value)
                                                 .Where(x=> x.FK_RoomID == iRoomID).FirstOrDefault();
                if(roomStatus != null && roomStatus.FK_StatusID == (int)ENRoomStatus.Dirty)
                {
                    errProvider.SetError(cmbRoom, "Room is Dirty.");
                    cmbRoom.Focus();
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool CheckInView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    dbh = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                SaveData();                
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_CheckInVoucherNo"))
                    {
                        return CheckInView_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Save);
                return false;
            }
        }
        private bool CheckInView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInCheckIn)
                {
                    PrintClick();
                }
                if (GlobalProperties.SendEmailWhileSavingInCheckIn)
                {
                    SendEmail();
                }
                if (GlobalProperties.SendSMSWhileSavingInCheckIn)
                {
                    SendSMS();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void CheckInView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vCheckIn = entCheckInList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vCheckIn;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public void CheckInView_Shown(object sender, EventArgs e)
        {
            if (_CheckInId != 0)
            {
                ReLoadData(_CheckInId);
                onPopulate();
            }
            else if(_BookingId != 0)
            {
                Booking booking = dbh.Bookings.Where(x => x.id == _BookingId).SingleOrDefault();
                if(booking != null)
                {
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = booking.FK_GuestID;
                    cmbBooking.SelectedValue = booking.id;
                }
            }
            else
            {
                PopulateSelectedRoom();
            }
        }        
        private bool CheckInView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {

                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vBookings = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vBookings).id);
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool CheckInView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void CheckInView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbGuest.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool CheckInView_atPrint(object source)
        {
            try
            {
                if (entCheckIn.id == 0)
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Check In", entCheckIn.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool CheckInView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteVoucher(entCheckIn.FK_VoucherHDRID, ref dbh);
                GlobalMethods.DeleteVoucher(entCheckIn.FK_PaymentVoucherHDRID, ref dbh);
                GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_CheckIn, entCheckIn);
                foreach (CheckInPayment Payment in entCheckInPaymentList) //**Delete Payments **
                {
                    dbh.CheckInPayments.DeleteObject(Payment);
                }
                dbh.DeleteObject(entCheckIn);        //**Delete CheckIn**
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void CheckInView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
