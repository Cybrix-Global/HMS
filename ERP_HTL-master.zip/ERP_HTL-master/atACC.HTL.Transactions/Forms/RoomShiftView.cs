﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseForms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using atACC.HTL.Masters;
using atACCFramework.UserControls;
using System.Data.SqlClient;
using atACC.HTL.Transactions.Sub_Forms;

namespace atACC.HTL.Transactions
{
    public partial class RoomShiftView : SearchFormBase2
    {
        #region Private Varibales
        RoomShift m_RoomShift;
        List<RoomShift> m_RoomShiftList;
        List<Rooms> entRooms;
        List<RoomTypes> entRoomTypes;
        atACCHotelEntities db;
        ToolTip tooltip;
        bool _OnLoad = true;
        CheckIn _FromCheckIn;
        CheckIn _ToCheckIn;
        #endregion Private Varibales

        #region Constructor
        public RoomShiftView()
        {
            InitializeComponent();
            db = atHotelContext.CreateContext();

        }
        #endregion Constructor

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(11);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Public Methods
        public override void LoadVouchers()
        {
            string sTempVno = txtVoucherNo.Text;
            db = atHotelContext.CreateContext();
            List<UpDownData> _Vouchers = db.RoomShifts.OrderByDescending(x => x.id)
                .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
            txtVoucherNo.Items.Clear();
            txtVoucherNo.DataSource = _Vouchers;
            if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
            txtVoucherNo.Text = sTempVno;
        }
        public override void ReLoadData(string VoucherNo)
        {
            RoomShift roomShift = db.RoomShifts.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (roomShift != null)
            {
                ReLoadData(roomShift.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                db = atHotelContext.CreateContext();
                m_RoomShift = db.RoomShifts.Where(x => x.id == id).SingleOrDefault();
                if (m_RoomShift != null)
                {
                    txtVoucherNo.Text = m_RoomShift.VoucherNo.ToString();
                    dtVoucherDate.Value = m_RoomShift.VoucherDate.ToDateTime();
                    dtpShiftDate.Value = m_RoomShift.ShiftDate.ToDateTime();
                    cmbFromRoom.SelectedValue = m_RoomShift.FK_FromRoomID.ToInt32();
                    cmbToRoom.SelectedValue = m_RoomShift.FK_ToRoomID.ToInt32();
                    txtReason.Text = m_RoomShift.Reason;
                    txtRemarks.Text = m_RoomShift.Remarks;
                    cmbEmployee.SelectedValue = m_RoomShift.FK_EmployeeID.ToInt32();
                    cmbGuest.SelectedValue = m_RoomShift.FK_GuestID;
                    dtpArrivalDate.Value = m_RoomShift.ArrivalDate.Value;
                    dtpDepartureDate.Value = m_RoomShift.DepartureDate.Value;
                    _FromCheckIn = db.CheckIns.Where(x => x.id == (m_RoomShift.FK_FromCheckInID ?? 0)).SingleOrDefault();
                    _ToCheckIn = db.CheckIns.Where(x => x.id == (m_RoomShift.FK_ToCheckInID ?? 0)).SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        #endregion

        #region Private Methods
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_RoomShift, 0, 0, txtVoucherNo.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRoomShift()
        {
            try
            {
                m_RoomShiftList = db.RoomShifts.ToList();
            }
            catch (Exception)
            {
                throw;

            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Employee
                cmbEmployee.DataSource = db.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = db.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }
                #endregion

                #region Guest
                cmbGuest.DataSource = db.Guests.ToList();
                cmbGuest.DisplayMember = "Name";
                cmbGuest.ValueMember = "id";
                cmbGuest.SelectedIndex = -1;
                #endregion

                #region From Room
                cmbFromRoom.DataSource = db.Rooms.Where(x => x.IsHall == false).ToList();
                cmbFromRoom.DisplayMember = "Name";
                cmbFromRoom.ValueMember = "id";
                cmbFromRoom.SelectedIndex = -1;
                #endregion

                #region To Room
                cmbToRoom.DataSource = db.Rooms.Where(x => x.IsHall == false).ToList();
                cmbToRoom.DisplayMember = "Name";
                cmbToRoom.ValueMember = "id";
                cmbToRoom.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }

        }
        private void PopulateGuest()
        {
            if (_OnLoad || !NewRecord) { return; }
            int iRoomID = cmbFromRoom.SelectedValue.ToInt32();
            _FromCheckIn = (from c in db.CheckIns
                            where c.DepartureDate >= dtpShiftDate.Value &&
                                  c.ArrivalDate <= dtpShiftDate.Value &&
                                  c.FK_RoomID == iRoomID
                            select c).SingleOrDefault();
            if (_FromCheckIn != null)
            {
                cmbGuest.SelectedValue = _FromCheckIn.FK_GuestID.ToInt32();
                dtpArrivalDate.Value = _FromCheckIn.ArrivalDate.Value;
                dtpDepartureDate.Value = _FromCheckIn.DepartureDate.Value;
                
            }
            else
            {
                cmbGuest.SelectedIndex = -1;
                dtpArrivalDate.Value = DateTime.Now;
                dtpDepartureDate.Value = DateTime.Now;
            }
            
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            m_RoomShift = new RoomShift();
            m_RoomShiftList = new List<RoomShift>();
            _FromCheckIn = null;
        }
        #endregion 

        #region Form Event
        private void dtpArrivalDate_ValueChanged(object sender, EventArgs e)
        {
            if(NewRecord)
            {
                DateTime date = dtpShiftDate.Value;
                DateTime time = dtpArrivalDate.Value;
                dtpShiftDate.Value = new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, time.Second);
            }
        }
        private void cmbFromRoom_SelectedValueChanged(object sender, EventArgs e)
        {
            PopulateGuest();
        }
        private void txtVoucherNo_Validated(object sender, EventArgs e)
        {
            try
            {

                RoomShift SD = db.RoomShifts.Where(x => x.VoucherNo == txtVoucherNo.Text.Trim())
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .SingleOrDefault();
                if (SD != null)
                {
                    ReLoadData(SD.id);
                    onPopulate();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region Framework events
        private void FrmRoomShift_atInitialise()
        {
            try
            {
                db = atHotelContext.CreateContext();
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
                dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
                dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();
                dtpShiftDate.MaxDate = DateTime.Now.ToEnd();
                dtpShiftDate.SetCustomFormat();
                dtpArrivalDate.SetCustomFormat();
                dtpDepartureDate.SetCustomFormat();
                dtpShiftDate.DisbaleShortDateTimeFormat = true;
                dtpDepartureDate.DisbaleShortDateTimeFormat = true;
                dtpArrivalDate.DisbaleShortDateTimeFormat = true;
                GetSeqNo();
                SettingsButton.Visible = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }
        private void FrmRoomShift_atAfterInitialise()
        {
            try
            {
                ShowToolTip();
                PopulateCombos();
                PopulateRoomShift();
                _OnLoad = false;
                FnClearAll();
                cmbGuest.Enabled = dtpArrivalDate.Enabled = dtpDepartureDate.Enabled = false;
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }

        }
        private void FrmRoomShift_atNewClick(object source)
        {
            try
            {
                m_RoomShift = new RoomShift();
                db = atHotelContext.CreateContext();
                FnClearAll();
                PopulateCombos();
                ShowToolTip();
                PopulateRoomShift();
                GetSeqNo();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool FrmRoomShift_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNo);
                    txtVoucherNo.Focus();
                    return false;
                }
                if(cmbFromRoom.SelectedValue == null)
                {
                    errProvider.SetError(cmbFromRoom, "Choose From Room");
                    cmbFromRoom.Focus();
                    return false;
                }
                if (cmbToRoom.SelectedValue == null)
                {
                    errProvider.SetError(cmbToRoom, "Choose To Room");
                    cmbToRoom.Focus();
                    return false;
                }
                if (cmbFromRoom.SelectedValue.ToInt32() == cmbToRoom.SelectedValue.ToInt32())
                {
                    errProvider.SetError(cmbToRoom, "From Room and To Room cannot be same");
                    cmbToRoom.Focus();
                    return false;
                }
                if (dtpShiftDate.Value.Date < dtpArrivalDate.Value.Date)
                {
                    errProvider.SetError(dtpShiftDate, "Shift date should be greater than arrival date");
                    dtpShiftDate.Focus();
                    return false;
                }
                if (dtpShiftDate.Value.Date > dtpDepartureDate.Value.Date)
                {
                    errProvider.SetError(dtpShiftDate, "Shift date should be less than departure date");
                    dtpShiftDate.Focus();
                    return false;
                }
                if (dtpShiftDate.Value.ToShortTimeString() != dtpArrivalDate.Value.ToShortTimeString())
                {
                    errProvider.SetError(dtpShiftDate, "Shift Time and Arrival Time must be same.");
                    dtpShiftDate.Focus();
                    return false;
                }
                if (GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpShiftDate.Value.AddMinutes(-1)) <= 0)
                {
                    errProvider.SetError(dtpShiftDate, "No of Days in From Room Cannot be Zero.");
                    dtpShiftDate.Focus();
                    return false;
                }
                if (GlobalMethods.GetNoOfDays(dtpShiftDate.Value, dtpDepartureDate.Value) <= 0)
                {
                    errProvider.SetError(dtpShiftDate, "No of Days in To Room Cannot be Zero.");
                    dtpShiftDate.Focus();
                    return false;
                }                
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                if (!NewRecord)
                {
                    CheckIn fromCheckIn = db.CheckIns.Where(x => x.id == m_RoomShift.FK_FromCheckInID).SingleOrDefault();
                    CheckIn toCheckIn = db.CheckIns.Where(x => x.id == m_RoomShift.FK_ToCheckInID).SingleOrDefault();
                    if(fromCheckIn != null && toCheckIn != null)
                    {
                        if(fromCheckIn.FK_GuestID.Value != cmbGuest.SelectedValue.ToInt32())
                        {
                            errProvider.SetError(cmbGuest, "Guest in From Room Changed.");
                            cmbGuest.Focus();
                            return false;
                        }
                        if (toCheckIn.FK_GuestID.Value != cmbGuest.SelectedValue.ToInt32())
                        {
                            errProvider.SetError(cmbGuest, "Guest in To Room Changed.");
                            cmbGuest.Focus();
                            return false;
                        }
                        if (fromCheckIn.ArrivalDate.Value != dtpArrivalDate.Value)
                        {
                            errProvider.SetError(dtpArrivalDate, "Arrival Date of Guest in From Room Changed.");
                            dtpArrivalDate.Focus();
                            return false;
                        }
                        if (toCheckIn.DepartureDate.Value != dtpDepartureDate.Value)
                        {
                            errProvider.SetError(dtpDepartureDate, "Departure Date of Guest in To Room Changed.");
                            dtpDepartureDate.Focus();
                            return false;
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredWhileValidating);
                return false;
            }
        }
        private bool FrmRoomShift_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    db = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                
                #region Updating Check In
                CheckIn fromCheckIn ;
                using (CheckInView fromCheckInView = new CheckInView())
                {
                    fromCheckInView.CheckInView_atInitialise();
                    fromCheckInView.CheckInView_atAfterInitialise();
                    fromCheckInView.SetDB(db);
                    fromCheckIn = db.CheckIns.Where(x => x.id == _FromCheckIn.id).SingleOrDefault();
                    fromCheckInView.ReloadDataFromCheckIn(fromCheckIn);
                    fromCheckInView.SetDepartureDate(dtpShiftDate.Value.AddMinutes(-1));
                    fromCheckIn = fromCheckInView.SaveData();
                }
                CheckIn toCheckIn ;
                using (CheckInView toCheckInView = new CheckInView())
                {
                    toCheckInView.CheckInView_atInitialise();
                    toCheckInView.CheckInView_atAfterInitialise();
                    toCheckInView.SetDB(db);                    
                    if (NewRecord)
                    {
                        toCheckInView.ReloadDataFromCheckIn(_FromCheckIn);
                        toCheckInView.SetNewRecord();
                    }
                    else
                    {
                        toCheckIn = db.CheckIns.Where(x => x.id == _ToCheckIn.id).SingleOrDefault();
                        toCheckInView.ReloadDataFromCheckIn(toCheckIn);
                    }
                    toCheckInView.SetArrivalDate(dtpShiftDate.Value);
                    toCheckInView.SetDepartureDate(dtpDepartureDate.Value);
                    toCheckInView.SetRoom(cmbToRoom.SelectedValue.ToInt32());
                    toCheckIn = toCheckInView.SaveData();
                }
                #endregion
                #region Save / Update Room Shift
                m_RoomShift.ContextID = iContextID;
                m_RoomShift.LocationID = GlobalFunctions.LoginLocationID;
                m_RoomShift.LoginUserID = GlobalFunctions.LoginUserID;
                m_RoomShift.VoucherNo = txtVoucherNo.Text.ToString();
                m_RoomShift.VoucherDate = dtVoucherDate.Value;
                m_RoomShift.ShiftDate = dtpShiftDate.Value;
                m_RoomShift.FK_FromRoomID = cmbFromRoom.SelectedValue.ToInt32();
                m_RoomShift.FK_ToRoomID = cmbToRoom.SelectedValue.ToInt32();
                m_RoomShift.FK_FromCheckInID = fromCheckIn.id;
                m_RoomShift.FK_ToCheckInID = toCheckIn.id;
                m_RoomShift.Reason = txtReason.Text;
                m_RoomShift.FK_EmployeeID = cmbEmployee.SelectedValue.ToInt32();
                m_RoomShift.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                m_RoomShift.Remarks = txtRemarks.Text.ToString();
                m_RoomShift.FK_GuestID = cmbGuest.SelectedValue.ToInt32();
                m_RoomShift.ArrivalDate = dtpArrivalDate.Value;
                m_RoomShift.DepartureDate = dtpDepartureDate.Value;
                m_RoomShift.Sanctioned = true;
                m_RoomShift.Cancelled = false;
                if (NewRecord)
                {
                    db.RoomShifts.AddObject(m_RoomShift);
                }
                else
                {
                    db.ObjectStateManager.ChangeObjectState(m_RoomShift, EntityState.Modified);
                }
                #endregion
                db.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                db.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_RoomShiftVoucherNo"))
                    {
                        return FrmRoomShift_atSaveClick(source, e);
                    }
                    if (updEx.InnerException.Message.Contains("UC_CheckInVoucherNo"))
                    {
                        return FrmRoomShift_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                db.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Save);
                return false;
            }
        }
        private bool FrmRoomShift_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInRoomShift)
                {
                    PrintClick();
                }
                NewClick();
                PopulateRoomShift();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
                return false;
            }
        }
        private void FrmRoomShift_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = m_RoomShiftList.Select(x => new { x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredBeforeSearching);
            }
        }        
        private bool FrmRoomShift_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vLoan = new { id = 0, VoucherNo = string.Empty };
                    ReLoadData(e.GetSelectedEntity().Cast(vLoan).id);
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSearching);
                return false;
            }
        }
        private void FrmRoomShift_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbGuest.Enabled = dtpArrivalDate.Enabled = dtpDepartureDate.Enabled = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool RoomShiftView_atPrint(object source)
        {
            try
            {
                if (m_RoomShift.id == 0) 
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Room Shift", m_RoomShift.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool FrmRoomShift_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                if (atMessageBox.Show("Deleting Room Shift will not affect Check Ins in From/To Rooms, Do you want to continue", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    db.RoomShifts.DeleteObject(m_RoomShift);
                    db.SaveChanges();
                    PopulateCombos();
                    return true;
                }
                else
                {
                    NewClick();
                    return false;
                }
            }
            catch (Exception ex)
            {
                db.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void FrmHallView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
                PopulateRoomShift();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
            }
        }
        #endregion Framework events
    }
}
