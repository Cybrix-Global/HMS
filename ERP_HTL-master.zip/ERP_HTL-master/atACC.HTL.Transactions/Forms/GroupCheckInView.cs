﻿using atACC.Common;
using atACC.CommonExtensions;
using atACC.CommonMessages;
using atACC.HTL.Masters;
using atACC.HTL.ORM;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Net.Mail;
using System.Drawing;
using System.Data.SqlClient;
using atACC.HTL.Transactions.Sub_Forms;
using atACCFramework;

namespace atACC.HTL.Transactions
{
    public partial class GroupCheckInView : SearchFormBase2
    {
        #region Private Variable
        bool _OnLoad;
        DataTable dtDTL;
        GroupCheckIn entGroupCheckIn;
        List<GroupCheckIn> entGroupCheckInList;
        List<GroupCheckInDTL> entGroupCheckInDTLList;
        List<GroupCheckInDTL> entOldGroupCheckInDTLList;
        List<GroupCheckInExtraServiceDTL> entOldGroupCheckInESDTLList;
        List<GroupCheckInExtraServiceDTL> entGroupCheckInESDTLList;
        List<GroupCheckInPayment> entGroupCheckInPaymentList;
        List<GroupCheckInPayment> entOldGroupCheckInPaymentList;
        List<GroupBookingPayment> entGroupBookingPaymentList;
        List<GroupBookingDTL> entGroupBookingDTLsList;
        GroupBookingDTL entGroupBookingDTLs;
        RoomTypes e_RoomTypes;
        RoomTariffs e_RoomTariffs;
        GuestDTLs e_GuestDTLs;
        Guests entGuest;
        GroupBooking entGroupBookings;
        List<Guests> entGuestlist;
        atACC.HTL.ORM.AccountLedger Ledger;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        ToolTip tooltip;
        List<Employee> entEmployees;
        List<Agent> entAgents;
        List<RoomTypeSlabs> entRoomTypesSlabs;
        List<Rooms> entRooms;
        List<RoomTypes> entRoomTypes;
        List<atACC.HTL.ORM.AccountLedger> entGuestAccounts;
        DataGridViewTextBoxEditingControl textbox, textbox1;
        DataGridViewComboBoxEditingControl cb, cb1;
        string sKeyChar = "";
        string NumberFormat, sQtyFormat;
        int Mode, MaxBedCount, ExtraBedCount, AdultCount, iGuestID, iDefaultCash, iDefaultDepo, ExtraAdultCount, iSettingsId, iRateTypeId, iDefaultId, iSlabTypeId, iRoomTypeId, iContentId;
        int _GroupCheckInId;
        int _GroupBookingID;
        decimal AdditionalPersonAmount = 0, RoomRate = 0, GuestDeduction = 0, AdvanceAmount, TotalAmount, Total, ExtraBedRate;
        DataTable dt = new DataTable();
        VoucherHDR entVoucherHdrPayment;
        VoucherHDR entVoucherHdr;
        decimal previousExRate;
        List<CurrencyClass> entCurrencys;
        GetAccounts getAccc;
        bool blnSanctioningRequired = false;
        bool blnPartyUnderCashInHand = false;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;

        #endregion

        #region Constructor
        public GroupCheckInView(int iGroupcheckInId)
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            aniHelper = new ANIHelper();
            getAccc = new GetAccounts();
            objLib = new CommonLibClasses();
            ShareButton.Visible = false;
            _GroupCheckInId = iGroupcheckInId;
            _OnLoad = false;

            ToolStripMenuItem mnuSendEmail = new ToolStripMenuItem();
            mnuSendEmail.BackColor = Color.White;
            mnuSendEmail.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendEmail.Text = MessageKeys.MsgSendEmail;
            mnuSendEmail.Image = Properties.Resources.Mail;
            mnuSendEmail.Click += new EventHandler(mnuSendEmail_Click);
            ShareMenu.Items.Add(mnuSendEmail);

            ToolStripMenuItem mnuSendSMS = new ToolStripMenuItem();
            mnuSendSMS.BackColor = Color.White;
            mnuSendSMS.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendSMS.Text = MessageKeys.MsgSendSMS;
            mnuSendSMS.Image = Properties.Resources.SMS;
            mnuSendSMS.Click += new EventHandler(mnuSendSMS_Click);
            ShareMenu.Items.Add(mnuSendSMS);
        }
        public GroupCheckInView() : this(0) { }
        public GroupCheckInView(int iGroupCheckInID, int iGroupBookingID) : this(0) 
        {
            _GroupBookingID = iGroupBookingID;
        }
        #endregion Constructor

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(4);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Share Methods
        void mnuSendEmail_Click(object sender, EventArgs e)
        {
            SendEmail();
        }
        void mnuSendSMS_Click(object sender, EventArgs e)
        {
            SendSMS();
        }
        private void SendEmail()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (cmbGuest.SelectedValue == null)
                {
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                    this.Cursor = Cursors.Arrow;
                    return;
                }
                if (entGroupCheckIn != null && entGroupCheckIn.id != null && entGroupCheckIn.id != 0) 
                {
                    string sTo = "";
                    int iGuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                    GuestDTLs _GuDtl = dbh.GuestDTLs.Where(x => x.FK_GuestID == iGuestID).SingleOrDefault();
                    if (_GuDtl != null)
                    {
                        sTo = _GuDtl.Email;
                    }
                    if (sTo.Trim() == "")
                    {
                        MessageBox.Show(MessageKeys.MsgEmailAddressOfGuestMustBeSet);
                        this.Cursor = Cursors.Arrow;
                        return;
                    }
                    string sExportPath = Application.StartupPath + "\\Temp\\Sales_" + txtVoucherNo.Text + ".pdf";
                    string sBody = "";
                    MailHelper _mailHelper = new MailHelper();
                    _mailHelper.sTo = sTo;
                    MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "Email").SingleOrDefault();
                    sBody = _Message.GroupCheckIn;
                    sBody = sBody.Replace("@VoucherNo", txtVoucherNo.Text)
                    .Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString())
                    .Replace("@GuestName@", cmbGuest.Text)
                    .Replace("@RoomType@", "")
                    .Replace("@Room@", "")
                    .Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString())
                    .Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString())
                    .Replace("@NoofDays@", txtNoOfDays.Text)
                    .Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat))
                    .Replace("@Payment@", txtPayment.Value.ToString(NumberFormat))
                    .Replace("@Refund@", "")
                    .Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));

                    _mailHelper.sSubject = MessageKeys.MsgGroupCheckInVoucherNo + " : " + txtVoucherNo.Text;
                    _mailHelper.sBody = sBody;
                    if (GlobalFunctions.blnConfirmationForEmail)
                    {
                        EmailConfirmationView emailConfirm = new EmailConfirmationView(_mailHelper.sSubject, _mailHelper.sBody);
                        if (emailConfirm.ShowDialog() == DialogResult.OK)
                        {
                            _mailHelper.sSubject = emailConfirm.sSubject;
                            _mailHelper.sBody = emailConfirm.sBody;
                        }
                        this.Cursor = Cursors.WaitCursor;
                    }
                    if (entGroupCheckIn.id != 0)
                    {
                        if (File.Exists(sExportPath))
                        {
                            File.Delete(sExportPath);
                        }
                        PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                        printInvoice.PrintOut("Hotel Group Check In", entGroupCheckIn.id, 0, true, sExportPath);
                        if (File.Exists(sExportPath))
                        {
                            _mailHelper.entAttachments.Add(new Attachment(sExportPath));
                        }
                    }
                    _mailHelper.SendEmail();
                    if (File.Exists(sExportPath))
                    {
                        File.Delete(sExportPath);
                    }
                    atMessageBox.Show(MessageKeys.MsgMailSendSuccessfully);
                }
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
                this.Cursor = Cursors.Arrow;
            }
        }
        private bool SendSMS()
        {
            if (cmbGuest.SelectedValue == null)
            {
                errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                return false;
            }
            if (entGroupCheckIn == null || entGroupCheckIn.id == null || entGroupCheckIn.id != 0)
            {
                atMessageBox.Show(MessageKeys.MsgRecordNotFound);
                return false;
            }
            int iGuestID = cmbGuest.SelectedValue.ToInt32();
            try
            {
                if (cmbGuest.Text.Trim() == "") { return false; }
                if (txtMobile.Text.Trim() == "") { return false; }
                MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "SMS").SingleOrDefault();
                string sMessage = _Message.GroupCheckIn;
                sMessage = sMessage.Replace("@VoucherNo", txtVoucherNo.Text);
                sMessage = sMessage.Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@GuestName@", cmbGuest.Text);
                sMessage = sMessage.Replace("@RoomType@", "");
                sMessage = sMessage.Replace("@Room@", "");
                sMessage = sMessage.Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@NoofDays@", txtNoOfDays.Text);
                sMessage = sMessage.Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Payment@", txtPayment.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Refund@", "");
                sMessage = sMessage.Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));
                string sResult = SMSHelper.SendSMSBash(txtMobile.Text.Trim(), sMessage);
                MessageBox.Show("SMS : " + sResult);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion

        #region Private Methods
        private void ReloadGridCombos()
        {
            foreach (DataGridViewRow item in dgDetails.Rows)
            {
                GroupCheckInDTL dTL = (GroupCheckInDTL)item.DataBoundItem;
                if (dTL != null)
                {
                    LoadRoomTypeCombosRowWise(item, dTL.RoomorHall.ToInt32());
                    LoadRoomsCombosRowWise(item, dTL.FK_RoomTypeID.ToInt32());
                    LoadRateTypeCombosRowWise(item);
                }
            }
        }
        private void InitControls()
        {
            dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
            dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();

            dtpArrivalDate.SetCustomFormat();
            dtpDepartureDate.SetCustomFormat();
            dtpArrivalDate.DisbaleShortDateTimeFormat = true;
            dtpDepartureDate.DisbaleShortDateTimeFormat = true;
        }
        private bool IsRoomTypeChanged()
        {
            if (dgDetails.CurrentCell != null && dgDetails.CurrentCell.Tag != null && dgDetails.CurrentCell.Value != null)
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_RoomType.Name)
                    return dgDetails.CurrentCell.Value.ToString2() != dgDetails.CurrentCell.Tag.ToString2();
            }
            return false;
        }
        private void CalculateSlab(bool blnUpdateDeductionAmount, GroupCheckInDTL pdtl)
        {
            try
            {                
                if (pdtl != null)
                {
                    List<Slab> slabs = null;
                    if (IsRoomTypeChanged())
                    {
                        int iRoomTypeID = pdtl.FK_RoomTypeID.ToInt32();
                        slabs = (from rs in dbh.RoomTypeSlabs
                                 join s in dbh.Slabs on rs.FK_SlabID equals s.id
                                 where rs.FK_RoomTypeID == iRoomTypeID
                                 select s).ToList();
                        if (dgDetails.CurrentCell != null) dgDetails.CurrentCell.Tag = null;
                    }
                    pdtl.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ApplyExRate()
        {
            try
            {
                decimal dcCurrentExRate = txtExRate.Value;
                decimal dcExRateChange = ((previousExRate == 0 ? 1 : previousExRate) / (dcCurrentExRate == 0 ? 1 : dcCurrentExRate));
                foreach (GroupCheckInExtraServiceDTL serviceDtl in entGroupCheckInESDTLList)
                {
                    if (serviceDtl.FK_ExtraServiceID != null)
                    {
                        serviceDtl.Rate = dcExRateChange * serviceDtl.Rate;
                        serviceDtl.InclusiveRate = dcExRateChange * serviceDtl.InclusiveRate;
                        serviceDtl.Amount = dcExRateChange * serviceDtl.Amount;
                        serviceDtl.TaxableAmount = dcExRateChange * serviceDtl.TaxableAmount;
                        serviceDtl.SlabDiscount = dcExRateChange * serviceDtl.SlabDiscount;
                        serviceDtl.DeductionAmount = dcExRateChange * serviceDtl.DeductionAmount;
                        serviceDtl.ExciseAmount = dcExRateChange * serviceDtl.ExciseAmount;
                        serviceDtl.Tax1Amount = dcExRateChange * serviceDtl.Tax1Amount;
                        serviceDtl.Tax2Amount = dcExRateChange * serviceDtl.Tax2Amount;
                        serviceDtl.Tax3Amount = dcExRateChange * serviceDtl.Tax3Amount;
                        serviceDtl.AddnlTaxAmount = dcExRateChange * serviceDtl.AddnlTaxAmount;
                        serviceDtl.VATAmount = dcExRateChange * serviceDtl.VATAmount;
                        serviceDtl.CGSTAmount = dcExRateChange * serviceDtl.CGSTAmount;
                        serviceDtl.SGSTAmount = dcExRateChange * serviceDtl.SGSTAmount;
                        serviceDtl.IGSTAmount = dcExRateChange * serviceDtl.IGSTAmount;
                        serviceDtl.NetAmount = dcExRateChange * serviceDtl.NetAmount;
                    }
                }
                foreach (GroupCheckInDTL dtl in entGroupCheckInDTLList)
                {
                    dtl.Rate = dcExRateChange * dtl.Rate;
                    dtl.AdditionalBedRate = dcExRateChange * dtl.AdditionalBedRate;
                    dtl.AdditionalPersonRate = dcExRateChange * dtl.AdditionalPersonRate;
                    dtl.InclusiveRate = dcExRateChange * dtl.InclusiveRate;
                    dtl.Amount = dcExRateChange * dtl.Amount;
                    dtl.TaxableAmount = dcExRateChange * dtl.TaxableAmount;
                    dtl.SlabDiscount = dcExRateChange * dtl.SlabDiscount;
                    dtl.DeductionAmount = dcExRateChange * dtl.DeductionAmount;
                    dtl.ExciseAmount = dcExRateChange * dtl.ExciseAmount;
                    dtl.Tax1Amount = dcExRateChange * dtl.Tax1Amount;
                    dtl.Tax2Amount = dcExRateChange * dtl.Tax2Amount;
                    dtl.Tax3Amount = dcExRateChange * dtl.Tax3Amount;
                    dtl.AddnlTaxAmount = dcExRateChange * dtl.AddnlTaxAmount;
                    dtl.VATAmount = dcExRateChange * dtl.VATAmount;
                    dtl.CGSTAmount = dcExRateChange * dtl.CGSTAmount;
                    dtl.SGSTAmount = dcExRateChange * dtl.SGSTAmount;
                    dtl.IGSTAmount = dcExRateChange * dtl.IGSTAmount;
                    dtl.NetAmount = dcExRateChange * dtl.NetAmount;
                }
                foreach (GroupCheckInPayment payment in entGroupCheckInPaymentList)
                {
                    payment.Payment = dcExRateChange * payment.Payment;
                }
                CalcOpeningBalance();
                CalcExternalAmt();
                CalcNetTotal();
                previousExRate = txtExRate.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_GroupCheckIn, 0, 0, txtVoucherNo.Text, GlobalFunctions.CurrentFiscalPeriodID);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateGrpCheckIn()
        {
            try
            {
                entGroupCheckInList = dbh.GroupCheckIns.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Guest
                var entGuests = dbh.Guests.Where(x => x.Active == true).Select(x => new { id = x.id, Name = x.Name }).ToList();
                cmbGuest.DataSource = entGuests;
                cmbGuest.DisplayMember = "Name";
                cmbGuest.ValueMember = "id";
                cmbGuest.SelectedIndex = -1;
                #endregion

                #region BillingAccount
                List<AccountLedger> entDebtors = getAccc.GetAccountLedgers(25);
                cmbBillingAccount.DataSource = entDebtors;
                cmbBillingAccount.DisplayMember = "LedgerName";
                cmbBillingAccount.ValueMember = "id";
                cmbBillingAccount.SelectedIndex = -1;
                #endregion

                #region VehicleType
                cmbGuestVehicleType.DataSource = dbh.GroupCheckIns.Where(x => (x.GuestVehicleType ?? "") != "").Select(x => new { id = -1, x.GuestVehicleType }).Distinct().ToList();
                cmbGuestVehicleType.DisplayMember = "GuestVehicleType";
                cmbGuestVehicleType.ValueMember = "id";
                cmbGuestVehicleType.SelectedIndex = -1;
                #endregion

                #region GuestType
                List<GuestType> entGuestTypes = dbh.GuestTypes.ToList();
                GuestType entGuestType = new GuestType();
                entGuestType.id = 0;
                entGuestType.Name = MessageKeys.MsgNone;
                entGuestTypes.Insert(0, entGuestType);
                cmbGuestType.DataSource = entGuestTypes;
                cmbGuestType.DisplayMember = "Name";
                cmbGuestType.ValueMember = "id";
                #endregion

                #region Source
                List<Source> entSources = dbh.Sources.ToList();
                Source entSource = new Source();
                entSource.id = 0;
                entSource.Name = MessageKeys.MsgNone;
                entSources.Insert(0, entSource);
                cmbSource.DataSource = entSources;
                cmbSource.DisplayMember = "Name";
                cmbSource.ValueMember = "id";
                #endregion

                #region Agent
                entAgents = dbh.Agents.Where(x => x.Status == 1).ToList();
                Agent entAgent = new Agent();
                entAgent.id = 0;
                entAgent.Name = MessageKeys.MsgNone;
                entAgents.Insert(0, entAgent);
                cmbAgent.DataSource = entAgents;
                cmbAgent.DisplayMember = "Name";
                cmbAgent.ValueMember = "id";
                #endregion

                #region Employee
                entEmployees = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).Where(x => x.Status == 1).ToList();
                cmbEmployee.DataSource = entEmployees;
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }
                #endregion

                #region Currency
                cmbCurrency.DataSource = entCurrencys;
                cmbCurrency.DisplayMember = "CurrencyName";
                cmbCurrency.ValueMember = "id";
                #endregion

                LoadRoomOrHall();
                LoadRoomType();
                PopulateRateType();
                LoadRooms(0);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private int DateDiff(DateTime d1, DateTime d2)
        {
            try
            {
                TimeSpan span = d2.Subtract(d1);
                return (int)span.TotalDays;
            }
            catch
            {
                return 0;
            }
        }
        
        private void FnClearAll()
        {
            try
            {
                entGroupCheckIn = new GroupCheckIn();
                entGroupCheckInDTLList = new List<GroupCheckInDTL>();
                entOldGroupCheckInDTLList = new List<GroupCheckInDTL>();

                entGroupCheckInPaymentList = new List<GroupCheckInPayment>();
                entOldGroupCheckInPaymentList = new List<GroupCheckInPayment>();

                entGroupCheckInESDTLList = new List<GroupCheckInExtraServiceDTL>();
                entOldGroupCheckInESDTLList = new List<GroupCheckInExtraServiceDTL>();

                entGroupBookingDTLsList = new List<GroupBookingDTL>();
                entGroupBookingPaymentList = new List<GroupBookingPayment>();

                lblOpBalance.DataSource = new DataTable();
                lblExternal.DataSource = new DataTable();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcGrandTotal()
        {
            try
            {
                lblGrandTotal.Value = txtNetTotal.Value + txtOpBalance.Value + txtExternalAmt.Value;
                txtBalance.Value = lblGrandTotal.Value - (txtAdvance.Value + txtPayment.Value);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcOpeningBalance()
        {
            try
            {
                if (txtExRate.Value == 0) { return; }
                SPGetGuestBillsParam param = new SPGetGuestBillsParam()
                {
                    AccountID = cmbBillingAccount.SelectedValue.ToInt32(),
                    FromDate = GlobalFunctions.dtFinancialFromDate,
                    ToDate = dtpArrivalDate.Value.AddMilliseconds(-1),
                    BookingID = (entGroupBookings == null ? 0 : entGroupBookings.id),
                    CheckInID = (entGroupCheckIn == null ? 0 : entGroupCheckIn.id),
                    CheckOutID = -1,
                    ExRate = txtExRate.Value,
                    IsGroupTrans = true
                };
                lblOpBalance.DataSource = GlobalMethods.GetGuestBills(param);
                txtOpBalance.Value = lblOpBalance.TotalAmount;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcExternalAmt()
        {
            try
            {
                if (txtExRate.Value == 0) { return; }
                SPGetGuestBillsParam param = new SPGetGuestBillsParam()
                {
                    AccountID = cmbBillingAccount.SelectedValue.ToInt32(),
                    FromDate = dtpArrivalDate.Value,
                    ToDate = dtpDepartureDate.Value,
                    BookingID = (entGroupBookings == null ? 0 : entGroupBookings.id),
                    CheckInID = (entGroupCheckIn == null ? 0 : entGroupCheckIn.id),
                    CheckOutID = -1,
                    ExRate = txtExRate.Value,
                    IsGroupTrans = true
                };
                lblExternal.DataSource = GlobalMethods.GetGuestBills(param);
                txtExternalAmt.Value = lblExternal.TotalAmount;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private GroupCheckInDTL getCurrent()
        {
            try
            {
                if (dgDetails.CurrentRow != null)
                {
                    GroupCheckInDTL groopCheckInDTL = (GroupCheckInDTL)dgDetails.CurrentRow.DataBoundItem;
                    return groopCheckInDTL;
                }
                else
                {
                    return null;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void CalcNetTotal(bool blnUpdateDeductionAmount = true)
        {
            try
            {
                txtExtraBedAndPer.Value = entGroupCheckInDTLList.Sum(x => x.AdditionalBeds + x.AdditionalPersons).ToInt32();                
                txtTotalAdults.Value = entGroupCheckInDTLList.Sum(x => x.Adult).ToInt32();
                txtTotalChilds.Value = entGroupCheckInDTLList.Sum(x => x.Child).ToInt32();
                txtGross.Value = entGroupCheckInDTLList.Sum(x => x.Amount).ToDecimal();
                txtTotalDiscount.Value = entGroupCheckInDTLList.Sum(x => x.SlabDiscount).ToDecimal() + entGroupCheckInDTLList.Sum(x => x.DeductionAmount).ToDecimal();
                lblTotalTax.lblTax1 = entGroupCheckInDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                lblTotalTax.lblTax2 = entGroupCheckInDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                lblTotalTax.lblTax3 = entGroupCheckInDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                lblTotalTax.lblAddnlTax = entGroupCheckInDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                lblTotalTax.lblExciseDuty = entGroupCheckInDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                lblTotalTax.lblVAT = entGroupCheckInDTLList.Sum(x => x.VATAmount).ToDecimal();
                lblTotalTax.lblCGST = entGroupCheckInDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                lblTotalTax.lblSGST = entGroupCheckInDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                lblTotalTax.lblIGST = entGroupCheckInDTLList.Sum(x => x.IGSTAmount).ToDecimal();
                txtTotalTax.Value = lblTotalTax.TotalTax;
                txtExtraServicesAmnt.Value = entGroupCheckInESDTLList.Sum(x => x.NetAmount).ToDecimal();
                txtNetTotal.Value = (txtGross.Value + txtTotalTax.Value) - txtTotalDiscount.Value + txtExtraServicesAmnt.Value;
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcTotal()
        {
            try
            {
                decimal RoomTotal = 0, DedAmount = 0, Total = 0;
                RoomTotal = txtGross.Value;
                DedAmount = (RoomTotal * txtDeductionPerc.Value) / 100;
                txtDeductionAmount.Value = DedAmount;
                Total = RoomTotal - DedAmount;
                txtGross.Value = Total;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTips()
        {

            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void InitEntities()
        {
            try
            {
                entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).ToList();
            }
            catch (Exception)
            {
                throw;
            }

        }
        private void LoadSettings()
        {
            NumberFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimals;
            sQtyFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimalsQty;

            txtTotalAdults.Format = NumberFormat;
            txtTotalChilds.Format = NumberFormat;
            txtRoomRent.Format = NumberFormat;
            txtVoucherDiscountAmount.Format = NumberFormat;            
            txtDeductionPerc.Format = NumberFormat;
            txtDeductionAmount.Format = NumberFormat;
            txtGross.Format = NumberFormat;
            txtTotalTax.Format = NumberFormat;
            txtTotalDiscount.Format = NumberFormat;
            txtNetTotal.Format = NumberFormat;
            txtPayment.Format = NumberFormat;
            txtExtraServicesAmnt.Format = NumberFormat;
            txtOpBalance.Format = NumberFormat;
            txtAdvance.Format = NumberFormat;
            txtBalance.Format = NumberFormat;
            lblGrandTotal.Format = NumberFormat;
            txtExRate.Format = NumberFormat;
            txtOpBalance.Format = NumberFormat;
            txtExtraBedAndPer.Format = NumberFormat;
            txtExternalAmt.Format = NumberFormat;
            txtOpBalance.Format = NumberFormat;
            lblOpBalance.Format = NumberFormat;
            lblExternal.Format = NumberFormat;

            grpDiscountVoucher.Visible = GlobalFunctions.blnDiscountVoucherInSalesTransactions;
            lblMandatory3.Visible = lblCurrencyCap.Visible = GlobalFunctions.blnMultiCurrency;
            cmbCurrency.Visible = GlobalFunctions.blnMultiCurrency;
            lblExRateCap.Visible = GlobalFunctions.blnMultiCurrency;
            txtExRate.Visible = GlobalFunctions.blnMultiCurrency;
        }
        private void SetDefaultDateAndTime()
        {
            try
            {
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
                txtNoOfDays.Value = 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SetDefaultComboValues()
        {
            cmbGuestType.SelectedValue =
                cmbSource.SelectedValue = cmbAgent.SelectedValue = 0;

            ActiveControl = cmbCurrency;
            cmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;
        }
        private void CalcPaymentTotal()
        {
            txtPayment.Value = entGroupCheckInPaymentList.Sum(x => x.Payment).ToDecimal();
            txtBalance.Value = txtNetTotal.Value - (txtAdvance.Value + txtPayment.Value);
        }
        private void CalcGrand(bool blnUpdateAddDiscAmount = true)
        {
            if (entGroupCheckInESDTLList.Count > 0)
            {
                txtExtraServicesAmnt.Value = entGroupCheckInESDTLList.Sum(x => x.NetAmount).ToDecimal();
                // lblTotQty.Value = entGrpCheckInESDTLList.Sum(x => x.Qty).ToDecimal();
                //if (blnUpdateAddDiscAmount)
                //{
                //    txtAddDiscAmount.Value = entCheckInDTLList.Sum(X => X.AddnlDiscount).ToDecimal();
                //}
                //lblTotDiscount.Value = (entCheckInDTLList.Sum(x => x.SlabDiscount).ToDecimal() + entCheckInDTLList.Sum(x => x.AddnlDiscount).ToDecimal() + entServicePurchaseDTLs.Sum(x => x.SpcialDiscount).ToDecimal());
                lblTotalTax.lblTax1 = entGroupCheckInESDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                lblTotalTax.lblTax2 = entGroupCheckInESDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                lblTotalTax.lblTax3 = entGroupCheckInESDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                lblTotalTax.lblAddnlTax = entGroupCheckInESDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                lblTotalTax.lblExciseDuty = entGroupCheckInESDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                lblTotalTax.lblVAT = entGroupCheckInESDTLList.Sum(x => x.VATAmount).ToDecimal();
                lblTotalTax.lblCGST = entGroupCheckInESDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                lblTotalTax.lblSGST = entGroupCheckInESDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                lblTotalTax.lblIGST = entGroupCheckInESDTLList.Sum(x => x.IGSTAmount).ToDecimal();
                txtNetTotal.Value = entGroupCheckInESDTLList.Sum(x => x.NetAmount).Value;
                txtTotalTax.Value = lblTotalTax.TotalTax;
                lblGrandTotal.Value = entGroupCheckInESDTLList.Sum(x => x.NetAmount).ToDecimal() + txtAdvance.Value;
                if (GlobalFunctions.strRoundoffPurchases != "")
                {
                    decimal dcBeforeRoundOff = lblGrandTotal.Value;
                    lblGrandTotal.Value = Math2.Round(lblGrandTotal.Value, GlobalFunctions.strRoundoffPurchases.ToInt32());
                }
            }
        }
        private void PopulateRateType()
        {
            try
            {

                List<RateTypes> rateTypes = dbh.RateTypes.ToList();
                rateTypes.Add(new RateTypes()
                {
                    id = 0,
                    Name = MessageKeys.MsgDefault
                });
                Col_RateType.DataSource = rateTypes;
                Col_RateType.DisplayMember = "Name";
                Col_RateType.ValueMember = "id";


            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void PostVoucher()
        {
            try
            {
                bool blnNewRecord = true;
                bool blnNewPaymentRecord = true;
                entVoucherHdr = new VoucherHDR();
                entVoucherHdrPayment = new VoucherHDR();
                if (!NewRecord)
                {
                    if ((entGroupCheckIn.FK_VoucherHDRID ?? 0) != 0)
                    {
                        entVoucherHdr = dbh.VoucherHDRs.Where(x => x.id == entGroupCheckIn.FK_VoucherHDRID).SingleOrDefault();
                        blnNewRecord = false;
                    }

                    if ((entGroupCheckIn.FK_PaymentVoucherHDRID ?? 0) != 0)
                    {
                        entVoucherHdrPayment = dbh.VoucherHDRs.Where(x => x.id == entGroupCheckIn.FK_PaymentVoucherHDRID).SingleOrDefault();
                        blnNewPaymentRecord = false;
                    }
                }

                int iCashorPartyAccountID = cmbBillingAccount.SelectedValue.ToInt32();
                blnPartyUnderCashInHand = aniHelper.isUnderCashInHand(iCashorPartyAccountID);
                AccountLedger entRentAccount = dbh.AccountLedgers.Where(x => x.id == GlobalProperties.RentAccountID).SingleOrDefault();

                decimal dcmGrandTotal = lblGrandTotal.Value;
                decimal dcExRate = txtExRate.Value;
                decimal dcmOtherPaymentSum = entGroupCheckInPaymentList.Where(x => x.isCash == false).Sum(x => x.Payment).ToDecimal();
                decimal dcmPartyAmount = blnPartyUnderCashInHand ? dcmGrandTotal - dcmOtherPaymentSum : dcmGrandTotal;

                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdr, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToString().ToInt32(), lblGrandTotal.Value, txtVoucherNo.Text, "H-GCI");

                //Voucher DTL Entry
                List<VoucherDTL> entVoucherDtls = new List<VoucherDTL>();

                // Debit Bill Amount to Party or Cash Account
                GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, iCashorPartyAccountID, entRentAccount.LedgerName, dcExRate, dcmPartyAmount, "", txtRemarks.Text);

                #region Rent Voucher DTL
                //Credit Gross Amount to Rent Account
                GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.RentAccountID, cmbBillingAccount.Text, dcExRate, txtGross.Value * (-1), "", txtRemarks.Text);
                //Credit Tax1 
                if (lblTotalTax.lblTax1 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax1AccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblTax1 * (-1), "", txtRemarks.Text);
                //Credit Tax2 
                if (lblTotalTax.lblTax2 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax2AccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblTax2 * (-1), "", txtRemarks.Text);
                //Credit Tax3
                if (lblTotalTax.lblTax3 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax3AccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblTax3 * (-1), "", txtRemarks.Text);
                //Credit Excise Duty
                if (lblTotalTax.lblExciseDuty != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExciseDutyAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblExciseDuty * (-1), "", txtRemarks.Text);
                // Debi Total Discount 
                if (txtTotalDiscount.Value != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.DiscountAccountID, cmbBillingAccount.Text, dcExRate, txtTotalDiscount.Value, "", txtRemarks.Text);
                // Round off Posting
                //if (dcTotalRoundoff != 0)
                //    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.RoundoffSalesID, cmbBillingAccount.Text, dcExRate, (dcTotalRoundoff * dcExRate), dcTotalRoundoff, "", txtRemarks.Text);
                //Credit Vat
                if (lblTotalTax.lblVAT != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.VATAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblVAT * (-1), "", txtRemarks.Text);
                //Credit CGST
                if (lblTotalTax.lblCGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.CGSTAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblCGST * (-1), "", txtRemarks.Text);
                //Credit SGST
                if (lblTotalTax.lblSGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.SGSTAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblSGST * (-1), "", txtRemarks.Text);
                //Credit IGST
                if (lblTotalTax.lblIGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.IGSTAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblIGST * (-1), "", txtRemarks.Text);
                //Credit AddnlTax
                if (lblTotalTax.lblAddnlTax != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.AdditionalTaxAccountID, cmbBillingAccount.Text, dcExRate, lblTotalTax.lblAddnlTax * (-1), "", txtRemarks.Text);
                #endregion

                #region ExtraService Voucher DTL
                if (entGroupCheckInESDTLList.Count > 0)
                {
                    decimal dcGross = entGroupCheckInESDTLList.Sum(x => x.Amount).ToDecimal();
                    decimal dcDiscount = entGroupCheckInESDTLList.Sum(x => x.DeductionAmount + x.SlabDiscount).ToDecimal();
                    decimal dcTax1 = entGroupCheckInESDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                    decimal dcTax2 = entGroupCheckInESDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                    decimal dcTax3 = entGroupCheckInESDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                    decimal dcAddnlTax = entGroupCheckInESDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                    decimal dcExciseDuty = entGroupCheckInESDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                    decimal dcVAT = entGroupCheckInESDTLList.Sum(x => x.VATAmount).ToDecimal();
                    decimal dcCGST = entGroupCheckInESDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                    decimal dcSGST = entGroupCheckInESDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                    decimal dcIGST = entGroupCheckInESDTLList.Sum(x => x.IGSTAmount).ToDecimal();

                    //Credit Gross Amount to ExtraService Account
                    if (dcGross != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExtraServicesAccountID, cmbBillingAccount.Text, dcExRate, dcGross * (-1), "", txtRemarks.Text);
                    //Credit Tax1 
                    if (dcTax1 != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax1AccountID, cmbBillingAccount.Text, dcExRate, dcTax1 * (-1), "", txtRemarks.Text);
                    //Credit Tax2
                    if (dcTax2 != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax2AccountID, cmbBillingAccount.Text, dcExRate, dcTax2 * (-1), "", txtRemarks.Text);
                    //Credit Tax3
                    if (dcTax3 != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax3AccountID, cmbBillingAccount.Text, dcExRate, dcTax3 * (-1), "", txtRemarks.Text);
                    //Credit Excise Duty
                    if (dcExciseDuty != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExciseDutyAccountID, cmbBillingAccount.Text, dcExRate, dcExciseDuty * (-1), "", txtRemarks.Text);
                    //Debit Total Discount 
                    if (txtTotalDiscount.Value != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.DiscountAccountID, cmbBillingAccount.Text, dcExRate, txtTotalDiscount.Value, "", txtRemarks.Text);
                    //Credit Vat
                    if (dcVAT != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.VATAccountID, cmbBillingAccount.Text, dcExRate, dcVAT * (-1), "", txtRemarks.Text);
                    //Credit CGST
                    if (dcCGST != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.CGSTAccountID, cmbBillingAccount.Text, dcExRate, dcCGST * (-1), "", txtRemarks.Text);
                    //Credit SGST
                    if (dcSGST != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.SGSTAccountID, cmbBillingAccount.Text, dcExRate, dcSGST * (-1), "", txtRemarks.Text);
                    //Credit IGST
                    if (dcIGST != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.IGSTAccountID, cmbBillingAccount.Text, dcExRate, dcIGST * (-1), "", txtRemarks.Text);
                    //Credit
                    if (dcAddnlTax != 0)
                        GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.AdditionalTaxAccountID, cmbBillingAccount.Text, dcExRate, dcAddnlTax * (-1), "", txtRemarks.Text);
                }
                #endregion
                List<AnalysisDTL> entAnalysisDTLs = new List<AnalysisDTL>();
                GlobalMethods.PostVoucher(blnNewRecord, entVoucherHdr, entVoucherDtls, ref dbh, entAnalysisDTLs);

                #region Payment Posting
                List<VoucherDTL> entVoucherDtlsPayment = new List<VoucherDTL>();
                if (entGroupCheckInPaymentList.Count() > 0) // Payment Found
                {
                    if (entVoucherHdrPayment.id == 0)
                    {
                        entVoucherHdrPayment.id = -1;
                    }
                    //Voucher Hdr Entry
                    GlobalMethods.DecorateVoucherHdr(entVoucherHdrPayment, iContextID, "", dtVoucherDate.Value
                        , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-GCI-PAY");

                    foreach (GroupCheckInPayment payment in entGroupCheckInPaymentList)
                    {
                        #region isCash
                        if (payment.isCash.toBool()) // Cash Payment
                        {
                            if (!blnPartyUnderCashInHand)
                            {
                                int iCashAccountID = payment.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)payment.FK_AccountID;
                                string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                                // Debit to Cash Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashAccountID, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", txtRemarks.Text);
                            }
                        }
                        #endregion

                        #region Non Cash
                        else
                        {
                            int iSelectedBankAccount = (int)payment.FK_AccountID;
                            string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                            string sRentAccountName = aniHelper.getLedNameFromAccountID(GlobalProperties.RentAccountID);
                            if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                            {
                                string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);

                                // Debit to Credit Card Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                                if (!blnPartyUnderCashInHand)
                                {
                                    // Credit From Party Account
                                    GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", txtRemarks.Text);
                                }

                                //Debit to Bank Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                                //Credit From Credit Card Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                            }
                            else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                            {
                                string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);

                                //Debit to Cheque Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                                if (!blnPartyUnderCashInHand)
                                {
                                    // Credit From Party Account
                                    GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                                }

                                //Debit to Bank Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                                //Credit From Cheque Received
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                            }
                            else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                                || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                            {
                                //Debit to Bank Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                                //Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                            }
                        }
                        #endregion
                    }
                    GlobalMethods.PostVoucher(blnNewPaymentRecord, entVoucherHdrPayment, entVoucherDtlsPayment, ref dbh, entAnalysisDTLs);
                }
                #endregion
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ClearGuestInfo()
        {
            try
            {
                txtTelephone.Text = "";
                cmbBillingAccount.SelectedIndex = -1;
                txtMobile.Text = "";
                txtAdd1.Text = "";
                txtAdvance.Value = 0;
                iContentId = 0;
                entGuest = new Guests();
                e_GuestDTLs = new GuestDTLs();
                DefaultCreditCard = 0;
                DefaultCreditCardNumber = string.Empty;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadGuestInfo(Int32 Guestid)
        {
            try
            {
                entGuest = dbh.Guests.Where(x => x.id == Guestid).SingleOrDefault();
                e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == Guestid).SingleOrDefault();
                if (entGuest != null && e_GuestDTLs != null && cmbGuest.Text != "")
                {
                    txtTelephone.Text = Convert.ToString(e_GuestDTLs.Telephone);
                    txtMobile.Text = Convert.ToString(e_GuestDTLs.Mobile);
                    txtAdd1.Text = Convert.ToString(e_GuestDTLs.Address1);
                    DefaultCreditCard = e_GuestDTLs.FK_CreditCardType.ToInt32();
                    DefaultCreditCardNumber = e_GuestDTLs.CreditCardNo.ToString();
                    if (NewRecord)
                    {
                        if (txtDeductionPerc.Value != e_GuestDTLs.DiscountPerc.Value && _OnLoad == false)
                        {
                            if (atMessageBox.Show(MessageKeys.MsgDoYouWantApplyDedcutionPercentage, MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                txtDeductionPerc.Value = e_GuestDTLs.DiscountPerc.Value;
                            }
                        }
                    }
                    if (cmbGuest.SelectedValue.ToInt32() != entGroupCheckIn.FK_GuestID)
                    {
                        cmbBillingAccount.SelectedValue = entGuest.FK_AccountID.ToString().ToInt32();
                        cmbCurrency.SelectedValue = entGuest.FK_CurrencyHDRID.ToInt32();
                    }
                    else
                    {
                        cmbBillingAccount.SelectedValue = entGroupCheckIn.FK_BillingAccountID;
                        cmbCurrency.SelectedValue = entGroupCheckIn.FK_CurrencyHdrID;
                        txtExRate.Value = entGroupCheckIn.ExRate.ToDecimal();
                    }
                    int GuestId = cmbGuest.SelectedValue.ToInt32();
                    List<int> entBookingID = (from ck in dbh.GroupCheckIns
                                              join bk in dbh.GroupBookings on ck.FK_GroupBookingID equals bk.id
                                              where ck.FK_GuestID == GuestId
                                              select bk.id).ToList();
                    List<GroupBooking> entBookings = dbh.GroupBookings.Where(x => !entBookingID.Contains(x.id) && x.FK_GuestID == GuestId).ToList();
                    if (entGroupCheckIn.FK_GroupBookingID != null && entGroupCheckIn.FK_GroupBookingID != 0)
                    {
                        int BookingID = entGroupCheckIn.FK_GroupBookingID.ToInt32();
                        GroupBooking entBooking = dbh.GroupBookings.Where(x => x.id == BookingID && x.FK_GuestID == GuestId).SingleOrDefault();
                        entBookings.Add(entBooking);
                    }
                    cmbGrpBooking.DataSource = entBookings;
                    cmbGrpBooking.DisplayMember = "VoucherNo";
                    cmbGrpBooking.ValueMember = "id";
                    cmbGrpBooking.SelectedIndex = -1;
                    iContentId = 1;
                }
                else
                {
                    cmbGrpBooking.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        #endregion

        #region Public Methods
        public override void LoadVouchers()
        {
            try
            {
                string sTempVno = txtVoucherNo.Text;
                dbh = atHotelContext.CreateContext();
                List<UpDownData> _Vouchers = dbh.GroupCheckIns.OrderByDescending(x => x.id)
                    .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                    .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
                txtVoucherNo.Items.Clear();
                txtVoucherNo.DataSource = _Vouchers;
                if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
                txtVoucherNo.Text = sTempVno;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            GroupCheckIn groupCheckIn = dbh.GroupCheckIns.Where(x => x.VoucherNo == VoucherNo && 
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (groupCheckIn != null)
            {
                ReLoadData(groupCheckIn.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entGroupCheckIn = dbh.GroupCheckIns.Where(x => x.id == ID).SingleOrDefault();
                if (entGroupCheckIn != null)
                {
                    NewRecord = false;
                    _OnLoad = true;
                    #region Add Inactive Accounts
                    #region Employee
                    if (entGroupCheckIn.FK_EmployeeID != null)
                    {
                        if (entEmployees.Where(x => x.id == entGroupCheckIn.FK_EmployeeID).ToList().Count == 0)
                        {
                            Employee _Employee = new Employee();
                            _Employee = dbh.Employees.Where(x => x.id == entGroupCheckIn.FK_EmployeeID).SingleOrDefault();
                            entEmployees.Add(_Employee);
                            objLib.fnFillCombo(ref cmbEmployee, entEmployees, "Name", "id");
                        }
                    }
                    #endregion

                    #region Agent
                    if (entGroupCheckIn.FK_AgentID != null)
                    {
                        if (entAgents.Where(x => x.id == entGroupCheckIn.FK_AgentID).ToList().Count == 0)
                        {
                            Agent _Agent = new Agent();
                            _Agent = dbh.Agents.Where(x => x.id == entGroupCheckIn.FK_AgentID).SingleOrDefault();
                            entAgents.Add(_Agent);
                            objLib.fnFillCombo(ref cmbAgent, entAgents, "Name", "id");
                        }
                    }
                    #endregion
                    #endregion
                    #region CheckIn Data
                    txtVoucherNo.Text = entGroupCheckIn.VoucherNo;
                    dtVoucherDate.Value = entGroupCheckIn.VoucherDate.Value;

                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = entGroupCheckIn.FK_GuestID;

                    cmbGrpBooking.SelectedValue = entGroupCheckIn.FK_GroupBookingID.Value.ToInt32();
                    dtpArrivalDate.Text = entGroupCheckIn.ArrivalDate.Value.ToString();
                    dtpDepartureDate.Text = entGroupCheckIn.DepartureDate.Value.ToString();
                    txtNoOfDays.Value = entGroupCheckIn.NoofDays.toInt32();
                    txtNoOfRooms.Value = entGroupCheckIn.NoofRooms.ToInt32();
                    txtNoOfHalls.Value = entGroupCheckIn.NoofHalls.ToInt32();
                    txtTotalAdults.Value = entGroupCheckIn.TotalAdult.ToInt32();
                    txtTotalChilds.Value = entGroupCheckIn.TotalChild.ToInt32();
                    txtExtraBedAndPer.Value = entGroupCheckIn.TotalAdditionalBeds.ToInt32() + entGroupCheckIn.TotalAdditionalPersons.ToInt32();                    
                    cmbSource.Text = entGroupCheckIn.Source;
                    cmbGuestType.Text = entGroupCheckIn.GuestType;
                    if (entGroupCheckIn.FK_AgentID != null)
                    {
                        // Ledger = dbh.AccountLedgers.ToList().Where(x => x.id == entGrpCheckIn.FK_AgentID).First();
                        cmbAgent.SelectedValue = entGroupCheckIn.FK_AgentID;
                    }
                    txtGross.Value = entGroupCheckIn.Amount.ToDecimal();
                    txtExtraServicesAmnt.Value = entGroupCheckIn.ExtraServices.ToDecimal();
                    txtDeductionPerc.Value = entGroupCheckIn.DeductionPerc.ToDecimal();
                    txtDeductionAmount.Value = entGroupCheckIn.DeductionAmount.ToDecimal();
                    cmbVoucherDiscount.SelectedValue = entGroupCheckIn.FK_VoucherDiscountID;
                    txtVoucherDiscountAmount.Value = entGroupCheckIn.VoucherDiscountAmount.ToDecimal();
                    txtTotalTax.Value = entGroupCheckIn.TotalTaxAmount.ToDecimal();
                    lblGrandTotal.Value = entGroupCheckIn.GrandTotal.ToDecimal();
                    txtOpBalance.Value = entGroupCheckIn.OpeningBalance.ToDecimal();
                    txtAdvance.Value = entGroupCheckIn.Advance.ToDecimal();
                    txtPayment.Value = entGroupCheckIn.Payment.ToDecimal();
                    txtBalance.Value = entGroupCheckIn.Balance.ToDecimal();
                    if (entGroupCheckIn.FK_EmployeeID != null)
                    {


                        cmbEmployee.SelectedValue = entGroupCheckIn.FK_EmployeeID;
                    }
                    txtRemarks.Text = entGroupCheckIn.Remarks;
                    cmbBillingAccount.SelectedValue = entGroupCheckIn.FK_BillingAccountID;
                    txtGuestVehicleName.Text = entGroupCheckIn.GuestVehicleName;
                    txtGuestVehicleNo.Text = entGroupCheckIn.GuestVehicleNo;
                    cmbGuestVehicleType.Text = entGroupCheckIn.GuestVehicleType;
                    txtTotalDiscount.Value = entGroupCheckIn.TotalDiscount.ToDecimal();
                    cmbCurrency.SelectedValue = entGroupCheckIn.FK_CurrencyHdrID;
                    txtExRate.Value = entGroupCheckIn.ExRate.ToDecimal();
                    #endregion
                    #region Reload Room Details
                    var CurrentDt2 = (from pdt2 in dbh.GroupCheckInDTLs
                                      where pdt2.FK_GroupCheckInID == ID
                                      select new { pdt2 }).ToList();
                    CurrentDt2.ForEach(x =>
                    {

                    });
                    entGroupCheckInDTLList = CurrentDt2.Select(x => x.pdt2).OrderBy(x => x.id).ToList();
                    entOldGroupCheckInDTLList = new List<GroupCheckInDTL>(entGroupCheckInDTLList);
                    #endregion
                    #region Reload Extra Service Details
                    var CurrentDtl = (from pdtl in dbh.GroupCheckInExtraServiceDTLs
                                      join prd in dbh.ExtraServices on pdtl.FK_ExtraServiceID equals prd.id
                                      where pdtl.FK_GroupCheckInID == ID
                                      select new { pdtl, prd }).ToList();
                    CurrentDtl.ForEach(x =>
                    {
                        x.pdtl.ServiceCode = x.prd.Code;
                        x.pdtl.ServiceName = x.prd.Name;
                    });
                    entGroupCheckInESDTLList = CurrentDtl.Select(x => x.pdtl).OrderBy(x => x.id).ToList();
                    entOldGroupCheckInESDTLList = new List<GroupCheckInExtraServiceDTL>(entGroupCheckInESDTLList);
                    #endregion
                    #region Reload Payment Details
                    entGroupCheckInPaymentList = dbh.GroupCheckInPayments.Where(x => x.FK_GroupCheckInID == entGroupCheckIn.id).ToList();
                    entOldGroupCheckInPaymentList = new List<GroupCheckInPayment>(entGroupCheckInPaymentList);
                    #endregion
                    BindGrid();
                    ReloadGridCombos();
                    LoadFullSerialNo();
                    _OnLoad = false;
                    CalcOpeningBalance();
                    CalcExternalAmt();
                    CalcPaymentTotal();
                    CalcNetTotal(false);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form event
        
        private void cmbBillingAccount_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!_OnLoad)
            {
                CalcOpeningBalance();
                CalcExternalAmt();
            }
        }
        private void btnAllocate_Click(object sender, EventArgs e)
        {
            entGroupCheckInDTLList.Clear();
            List<Rooms> rooms = GlobalMethods.GetAvailableRooms(dtpArrivalDate.Value, dtpDepartureDate.Value, ENMVMTTransactionType.HTL_GroupCheckIn, entGroupCheckIn.id);
            for (int i = 0; i < txtNoOfRooms.Value; i++)
            {
                Rooms room = rooms.FirstOrDefault(x => x.IsHall == false);
                if (room != null)
                {
                    GroupCheckInDTL groupCheckInDTL = new GroupCheckInDTL()
                    {
                        RoomorHall = 0,
                        FK_RoomTypeID = room.FK_RoomTypeID,
                        FK_RoomID = room.id,
                        FK_RateTypeID = 0,
                        Adult = 1,
                        Child = 0,
                        DeductionPerc = GuestDeduction
                    };
                    CalcRoomRent(groupCheckInDTL);
                    entGroupCheckInDTLList.Add(groupCheckInDTL);
                    rooms.Remove(room);
                }
            }
            for (int i = 0; i < txtNoOfHalls.Value; i++)
            {
                Rooms room = rooms.FirstOrDefault(x => x.IsHall == true);
                if (room != null)
                {
                    GroupCheckInDTL groupCheckInDTL = new GroupCheckInDTL()
                    {
                        RoomorHall = 1,
                        FK_RoomTypeID = room.FK_RoomTypeID,
                        FK_RoomID = room.id,
                        FK_RateTypeID = 0,
                        Adult = 1,
                        Child = 0,
                        DeductionPerc = GuestDeduction
                    };
                    CalcRoomRent(groupCheckInDTL);
                    entGroupCheckInDTLList.Add(groupCheckInDTL);
                    rooms.Remove(room);
                }
            }
            BindGrid();
            ReloadGridCombos();
            LoadFullSerialNo();
            CalcNetTotal(false);
        }
        private void cmbGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    cmbGuest.SelectedValue = frm.SelectedGuestID;
                    cmbGuest.Text = frm.SelectedGuestName;
                    cmbGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewGuest_Click(object sender, EventArgs e)
        {
            try
            {
                GuestView guestView = new GuestView();
                guestView.ShowDialog();
                cmbGuest.DataSource = GlobalMethods.GetGuests();
                ActiveControl = cmbGuest;
                cmbGuest.SelectedValue = guestView.CurrentID;
                cmbGuest.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void txtExtraServices_TextChanged(object sender, EventArgs e)
        {
            try
            {
                CalcNetTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnGrpCheckOut_Click(object sender, EventArgs e)
        {
            try
            {
                GroupCheckOutView checkOUT = new GroupCheckOutView(entGroupCheckIn.id);
                if (checkOUT.ShowDialog() == DialogResult.OK)
                {
                    this.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbEmployee_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbBooking_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_OnLoad)
                {
                    FnClearAll();
                    if (cmbGrpBooking.Text.Trim() != "" && cmbGrpBooking.SelectedValue.ToInt32() != 0)
                    {
                        int Id = cmbGrpBooking.SelectedValue.ToInt32();
                        entGroupBookings = dbh.GroupBookings.Where(x => x.id == Id).SingleOrDefault();
                        entGroupBookingPaymentList = dbh.GroupBookingPayments.Where(x => x.FK_GroupBookingID == Id).ToList();
                        txtAdvance.Value = entGroupBookingPaymentList.Sum(x => x.Payment).ToDecimal();
                        if (entGroupBookings != null)
                        {

                            #region Load Group Booking Info
                            
                            dtpArrivalDate.Text = entGroupBookings.ArrivalDate.Value.ToString();
                            dtpDepartureDate.Text = entGroupBookings.DepartureDate.Value.ToString();

                            txtNoOfDays.Value = entGroupBookings.NoofDays.toInt32();
                            txtNoOfRooms.Value = entGroupBookings.NoofRooms.toInt32();
                            txtNoOfHalls.Value = entGroupBookings.NoofHalls.toInt32();
                            cmbSource.Text = entGroupBookings.Source;
                            cmbGuestType.Text = entGroupBookings.GuestType;
                            if (entGroupBookings.FK_AgentID != null)
                            {
                                //Ledger = dbh.AccountLedgers.ToList().Where(x => x.id == entCheckIn.FK_AgentID).First();
                                cmbAgent.SelectedValue = entGroupBookings.FK_AgentID;
                            }
                            txtDeductionPerc.Value = entGroupBookings.DeductionPerc ?? 0;
                            txtDeductionAmount.Value = entGroupBookings.DeductionAmount ?? 0;

                            #endregion
                            #region Group Booking Room Details Info
                            entGroupBookingDTLsList = dbh.GroupBookingDTLs.Where(x => x.FK_GroupBookingID == Id).ToList();
                            GroupCheckInDTL entGrpCheckInDTLs1 = new GroupCheckInDTL();
                            foreach (GroupBookingDTL entGrpBookingDTLs in entGroupBookingDTLsList)
                            {
                                entGrpCheckInDTLs1.RoomorHall = entGrpBookingDTLs.RoomorHall.ToInt32();
                                entGrpCheckInDTLs1.FK_RoomTypeID = entGrpBookingDTLs.FK_RoomTypeID;
                                entGrpCheckInDTLs1.FK_RoomID = entGrpBookingDTLs.FK_RoomID;
                                entGrpCheckInDTLs1.FK_RateTypeID = entGrpBookingDTLs.FK_RateTypeID;
                                entGrpCheckInDTLs1.Adult = entGrpBookingDTLs.Adult;
                                entGrpCheckInDTLs1.Child = entGrpBookingDTLs.Child;
                                entGrpCheckInDTLs1.Rate = entGrpBookingDTLs.Rate;
                                entGrpCheckInDTLs1.AdditionalBedRate = 0;
                                entGrpCheckInDTLs1.AdditionalBeds = 0;
                                entGrpCheckInDTLs1.AdditionalPersonRate = 0;
                                entGrpCheckInDTLs1.AdditionalPersons = 0;
                                entGrpCheckInDTLs1.SlNo = entGrpBookingDTLs.SlNo;
                                entGrpCheckInDTLs1.FK_GroupBookingDTLID = entGrpBookingDTLs.id;

                                CalcRoomRent(entGrpCheckInDTLs1);
                                entGroupCheckInDTLList.Add(entGrpCheckInDTLs1);
                            }
                            BindGrid();
                            ReloadGridCombos();
                            CalcNetTotal(false);
                            LoadFullSerialNo();

                            #endregion
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    dgDetails.Focus();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbGuest_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsActiveControl(sender)) { return; }

                ClearGuestInfo();
                LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
                CalcNetTotal();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void btnPayment_Click(object sender, EventArgs e)
        {
            try
            {
                decimal PayAmt = txtNetTotal.Value - txtAdvance.Value;
                GroupCheckInPaymentView payment = new GroupCheckInPaymentView(entGroupCheckInPaymentList, PayAmt, NumberFormat, DefaultCreditCard, DefaultCreditCardNumber);
                if (payment.ShowDialog() == DialogResult.OK)
                {
                    CalcPaymentTotal();
                    CalcGrandTotal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dtpArrivalDate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.IsActiveControl(sender, true))
                {
                    txtNoOfDays.Text = GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpDepartureDate.Value).ToString();
                    foreach (var item in entGroupCheckInDTLList)
                    {
                        CalcOpeningBalance();
                        CalcExternalAmt();
                        CalcRowAmount(item);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewGuestType_Click(object sender, EventArgs e)
        {
            try
            {
                GuestTypeView guestType = new GuestTypeView();
                guestType.ShowDialog();
                cmbGuestType.DataSource = GlobalMethods.GetGuestTypes();
                cmbGuestType.SelectedValue = guestType.CurrentID;
                cmbGuestType.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewSource_Click(object sender, EventArgs e)
        {
            try
            {
                SourceView Source = new SourceView();
                Source.ShowDialog();
                cmbSource.DataSource = GlobalMethods.GetSources();
                cmbSource.SelectedValue = Source.CurrentID;
                cmbSource.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtDeductionPerc_TextChanged(object sender, EventArgs e)
        {
            try
            {
                CalcNetTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtDeductionAmount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                CalcNetTotal(false);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnExtraServ_Click(object sender, EventArgs e)
        {
            try
            {
                List<ExtraServiceDTLs> extraServiceDTLs = new List<ExtraServiceDTLs>();

                entGroupCheckInESDTLList.ForEach(x =>
                {
                    ExtraServiceDTLs serviceDTL = new ExtraServiceDTLs();
                    x.CopyTo(serviceDTL, true);
                    extraServiceDTLs.Add(serviceDTL);
                });
                CheckInExtraServicesView checkInExtraServicesView = new CheckInExtraServicesView(dbh, extraServiceDTLs, NumberFormat, sQtyFormat, txtExRate.Value);
                if (checkInExtraServicesView.ShowDialog() == DialogResult.OK)
                {
                    //Add / Update ExtraServiceDTLs to entGrpCheckInESDTLList                     
                    int iIndex = 0;
                    int iCurrentCount = entGroupCheckInESDTLList.Count;
                    checkInExtraServicesView.ExtraServiceDTLs.ForEach(x =>
                    {
                        iIndex++;
                        GroupCheckInExtraServiceDTL extraServiceDTL;
                        if (iIndex > iCurrentCount)
                        {
                            extraServiceDTL = new GroupCheckInExtraServiceDTL();
                        }
                        else
                        {
                            extraServiceDTL = entGroupCheckInESDTLList[iIndex - 1];
                        }
                        x.CopyTo(extraServiceDTL, true);
                        if (iIndex > iCurrentCount)
                        {
                            entGroupCheckInESDTLList.Add(extraServiceDTL);
                        }

                    });
                    //Remove deleted extra service dtls
                    if (iIndex < iCurrentCount)
                    {
                        for (int i = iIndex; i < iCurrentCount; i++)
                        {
                            entGroupCheckInESDTLList.RemoveAt(iIndex);
                        }
                    }
                    CalcNetTotal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurrency.ValueMember == "") { return; }
                if (cmbCurrency.SelectedValue == null) { return; }
                int iCurrencyID = cmbCurrency.SelectedValue.ToString2().ToInt32();

                CurrencyClass entCurrency = entCurrencys.Where(x => x.id == iCurrencyID).Single();
                Company company = dbh.Companies.Single();
                int _sourcecurrencyId = company.FK_Currency.toInt32();
                int _destinationCurrencyID = entCurrency.id;
                if (_sourcecurrencyId == _destinationCurrencyID)
                {
                    txtExRate.Enabled = false;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
                txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                ApplyExRate();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtExRate_Enter(object sender, EventArgs e)
        {
            try
            {
                previousExRate = txtExRate.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtExRate_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                ApplyExRate();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework events
        private void GrpCheckInView_atInitialise()
        {
            try
            {
                InitEntities();
                InitControls();
                LoadSettings();
                ShowToolTips();
                ApplyGridStyles();
                PopulateCombos();
                SettingsButton.Visible = true; ShareButton.Visible = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }
        private void GrpCheckInView_atAfterInitialise()
        {
            try
            {
                _OnLoad = false;
                GrpCheckInView_atNewClick(null);
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void GrpCheckInView_atNewClick(object source)
        {
            try
            {
                PopulateGrpCheckIn();
                FnClearAll();
                ClearGuestInfo();
                BindGrid();
                SetDefaultDateAndTime();
                SetDefaultComboValues();
                GetSeqNo();
                CalcNetTotal();
                cmbGuest.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool GrpCheckInView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    dbh = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                #region Voucher Posting

                if (!blnSanctioningRequired)
                {
                    PostVoucher();
                }

                //Rent
                if (!blnSanctioningRequired)
                {
                    entGroupCheckIn.FK_VoucherHDRID = entVoucherHdr.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entGroupCheckIn.FK_VoucherHDRID, ref dbh);
                    entGroupCheckIn.FK_VoucherHDRID = null;
                }

                //Payment
                if (!blnSanctioningRequired && entGroupCheckInPaymentList.Count() > 0)
                {
                    entGroupCheckIn.FK_PaymentVoucherHDRID = entVoucherHdrPayment.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entGroupCheckIn.FK_PaymentVoucherHDRID, ref dbh);
                    entGroupCheckIn.FK_PaymentVoucherHDRID = null;
                }
                #endregion

                #region CheckIn Details
                entGroupCheckIn.ContextID = iContextID;
                entGroupCheckIn.LoginUserID = GlobalFunctions.LoginUserID;
                entGroupCheckIn.LocationID = GlobalFunctions.LoginLocationID;
                entGroupCheckIn.VoucherNo = txtVoucherNo.Text;
                entGroupCheckIn.VoucherDate = dtVoucherDate.Value;
                entGroupCheckIn.FK_GroupBookingID = cmbGrpBooking.SelectedValue.ToInt32();
                entGroupCheckIn.FK_GuestID = cmbGuest.SelectedValue.ToInt32();
                entGroupCheckIn.ArrivalDate = dtpArrivalDate.Value;
                entGroupCheckIn.DepartureDate = dtpDepartureDate.Value;
                entGroupCheckIn.NoofDays = txtNoOfDays.Value.ToInt32();
                entGroupCheckIn.NoofRooms = txtNoOfRooms.Value.ToInt32();
                entGroupCheckIn.NoofHalls = txtNoOfHalls.Value.ToInt32();
                entGroupCheckIn.TotalAdult = txtTotalAdults.Value.ToInt32();
                entGroupCheckIn.TotalChild = txtTotalChilds.Value.ToInt32();
                entGroupCheckIn.TotalAdditionalBeds = entGroupCheckInDTLList.Sum(x => x.AdditionalBeds).ToInt32(); ;
                entGroupCheckIn.TotalAdditionalPersons = entGroupCheckInDTLList.Sum(x => x.AdditionalPersons).ToInt32(); ;
                entGroupCheckIn.Source = cmbSource.Text.ToString();
                entGroupCheckIn.GuestType = cmbGuestType.Text.ToString();
                entGroupCheckIn.FK_CurrencyHdrID = cmbCurrency.SelectedValue.ToString2().ToInt32();
                entGroupCheckIn.ExRate = txtExRate.Value;
                if (cmbAgent.Text != null && cmbAgent.SelectedValue.ToInt32() != 0)
                {
                    //atACCContextEntities db1 = atContext.CreateContext();
                    //int AgentID = cmbAgent.SelectedValue.ToInt32();

                    //AgentLedgerID = db1.Agents.Where(x => x.id == AgentID).Select(x => x.FK_Account).SingleOrDefault();
                    entGroupCheckIn.FK_AgentID = cmbAgent.SelectedValue.ToString().ToInt32();
                }
                else { entGroupCheckIn.FK_AgentID = null; }

                entGroupCheckIn.Amount = txtGross.Value;
                entGroupCheckIn.ExtraServices = txtExtraServicesAmnt.Value;
                entGroupCheckIn.DeductionPerc = txtDeductionPerc.Value;
                entGroupCheckIn.DeductionAmount = txtDeductionAmount.Value;
                entGroupCheckIn.FK_VoucherDiscountID = null;                
                entGroupCheckIn.VoucherDiscountAmount = txtVoucherDiscountAmount.Value;
                entGroupCheckIn.TotalTaxAmount = txtTotalTax.Value;
                entGroupCheckIn.GrandTotal = txtNetTotal.Value;
                entGroupCheckIn.OpeningBalance = txtOpBalance.Value;
                entGroupCheckIn.Advance = txtAdvance.Value;
                entGroupCheckIn.Payment = txtPayment.Value;
                entGroupCheckIn.Balance = txtBalance.Value;
                if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
                {
                    entGroupCheckIn.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
                }
                else entGroupCheckIn.FK_EmployeeID = null;
                entGroupCheckIn.Remarks = txtRemarks.Text;
                entGroupCheckIn.FK_BillingAccountID = cmbBillingAccount.SelectedValue.ToString().ToInt32();
                entGroupCheckIn.GuestVehicleName = txtGuestVehicleName.Text;
                entGroupCheckIn.GuestVehicleNo = txtGuestVehicleNo.Text;
                entGroupCheckIn.GuestVehicleType = cmbGuestVehicleType.Text;
                entGroupCheckIn.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entGroupCheckIn.Sanctioned = !blnSanctioningRequired;
                entGroupCheckIn.Cancelled = false;
                if (NewRecord)
                {
                    dbh.GroupCheckIns.AddObject(entGroupCheckIn);
                }
                else
                {
                    entGroupCheckIn.ModifiedDate = System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(entGroupCheckIn, EntityState.Modified);
                }
                #endregion

                #region Removing Deleted GrpCheckInExtraServices
                var d1 = entOldGroupCheckInESDTLList.Select(x => new { id = x.id });
                var d2 = entGroupCheckInESDTLList.Select(y => new { id = y.id });
                var deletedESDtls = d1.Except(d2);
                foreach (var deletedItem in deletedESDtls)
                {
                    GroupCheckInExtraServiceDTL delItDtl = entOldGroupCheckInESDTLList.Where(x => x.id == deletedItem.id).First();
                    dbh.GroupCheckInExtraServiceDTLs.DeleteObject(delItDtl);
                }
                #endregion

                #region Adding or Updating CheckInExtraSevices
                foreach (GroupCheckInExtraServiceDTL ExtraService in entGroupCheckInESDTLList)
                {
                    if (ExtraService.FK_ExtraServiceID != null)
                    {
                        ExtraService.FK_GroupCheckInID = entGroupCheckIn.id;


                        if (dbh.GroupCheckInExtraServiceDTLs.Where(x => x.id == ExtraService.id).ToList().Count == 0)
                        {
                            dbh.GroupCheckInExtraServiceDTLs.AddObject(ExtraService);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(ExtraService, System.Data.EntityState.Modified);
                        }
                    }
                }
                #endregion

                #region Removing Deleted GrpCheckInDTls
                var dd1 = entOldGroupCheckInDTLList.Select(x => new { id = x.id });
                var dd2 = entGroupCheckInDTLList.Select(y => new { id = y.id });
                var deletedDtls = dd1.Except(dd2);
                foreach (var deletedItem in deletedDtls)
                {
                    GroupCheckInDTL delItDtl = entOldGroupCheckInDTLList.Where(x => x.id == deletedItem.id).First();
                    GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupCheckIn, delItDtl);
                    dbh.GroupCheckInDTLs.DeleteObject(delItDtl);
                }
                #endregion

                #region Adding or Updating CheckInDTL
                int iSlNo = 0;
                foreach (GroupCheckInDTL groupCheckInDTL in bindCheckInDTL.List)
                {
                    if (groupCheckInDTL.FK_RoomID != null)
                    {
                        iSlNo++;                        
                        groupCheckInDTL.SlNo = iSlNo;
                        groupCheckInDTL.FK_GroupCheckInID = entGroupCheckIn.id;

                        if (dbh.GroupCheckInDTLs.Where(x => x.id == groupCheckInDTL.id).ToList().Count == 0)
                        {
                            groupCheckInDTL.id = int.MinValue + iSlNo;
                            dbh.GroupCheckInDTLs.AddObject(groupCheckInDTL);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(groupCheckInDTL, System.Data.EntityState.Modified);
                        }

                        #region Save to RoomStatusRegister
                        groupCheckInDTL.ArrivalDate = entGroupCheckIn.ArrivalDate;
                        groupCheckInDTL.DepartureDate = entGroupCheckIn.DepartureDate;
                        groupCheckInDTL.FK_GuestID = entGroupCheckIn.FK_GuestID;
                        if (groupCheckInDTL.FK_GroupBookingDTLID != null)
                        {
                            groupCheckInDTL.FK_RefTransTypeID = (int)ENMVMTTransactionType.HTL_GroupBooking;
                            groupCheckInDTL.FK_RefTransID = groupCheckInDTL.FK_GroupBookingDTLID;                            
                        }
                        GlobalMethods.SaveRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupCheckIn, groupCheckInDTL);
                        #endregion
                    }
                }
                #endregion

                #region Removing Deleted Payments
                var p1 = entOldGroupCheckInPaymentList.Select(x => new { id = x.id });
                var p2 = entGroupCheckInPaymentList.Select(y => new { id = y.id });
                var deletedpayments = p1.Except(p2);
                foreach (var deletedItem in deletedpayments)
                {
                    GroupCheckInPayment delItPay = entOldGroupCheckInPaymentList.Where(x => x.id == deletedItem.id).First();
                    dbh.GroupCheckInPayments.DeleteObject(delItPay);
                }
                #endregion

                #region Adding or Updating Payments
                foreach (GroupCheckInPayment GrpCheckInPayment in entGroupCheckInPaymentList)
                {
                    if (GrpCheckInPayment.Payment != 0)
                    {
                        GrpCheckInPayment.FK_GroupCheckInID = entGroupCheckIn.id;
                        if (GrpCheckInPayment.FK_MVInstrumentTypeID == 0)
                        {
                            GrpCheckInPayment.FK_MVInstrumentTypeID = null;
                        }
                        if (dbh.GroupCheckInPayments.Where(x => x.id == GrpCheckInPayment.id).ToList().Count == 0)
                        {
                            dbh.GroupCheckInPayments.AddObject(GrpCheckInPayment);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(GrpCheckInPayment, System.Data.EntityState.Modified);
                        }
                    }
                }

                #endregion                
                dbh.SaveChanges();

                

                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_GroupCheckInVoucherNo"))
                    {
                        return GrpCheckInView_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Save);
                return false;
            }
        }
        private void GroupCheckInView_Shown(object sender, EventArgs e)
        {
            if (_GroupCheckInId != 0)
            {
                ReLoadData(_GroupCheckInId);
                onPopulate();
            }
            else if (_GroupBookingID != 0)
            {
                GroupBooking booking = dbh.GroupBookings.Where(x => x.id == _GroupBookingID).SingleOrDefault();
                if (booking != null)
                {
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = booking.FK_GuestID;
                    cmbGrpBooking.SelectedValue = booking.id;
                }
            }
        }
        private bool GrpCheckInView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "") { errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNumberCannotBeBlank); txtVoucherNo.Focus(); return false; }
                if (cmbGuest.Text.Trim() == "") { errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen); cmbGuest.Focus(); return false; }
                if (cmbBillingAccount.Text.Trim() == "") { errProvider.SetError(cmbBillingAccount, MessageKeys.MsgBillingAccountMustBeChosen); cmbBillingAccount.Focus(); return false; }
                if (txtNoOfDays.Text.Trim() == "") { errProvider.SetError(txtNoOfDays, MessageKeys.MsgNumberofDaysMustBeEntered); txtNoOfDays.Focus(); return false; }
                if (txtNoOfDays.Value < 0) { errProvider.SetError(txtNoOfDays, MessageKeys.MsgNumberofDaysMustBeGreaterThanZero); txtNoOfDays.Focus(); return false; }
                if (entGroupCheckInDTLList.Where(x => x.FK_RoomID != null).ToList().Count <= 0) { errProvider.SetError(txtVoucherNo, MessageKeys.MsgAtleastOneRowMustBeEntered.GetMsg()); dgDetails.Focus(); return false; }
                if (GlobalFunctions.blnMultiCurrency)
                {
                    if (cmbCurrency.SelectedValue == null)
                    {
                        errProvider.SetError(cmbCurrency, MessageKeys.MsgCurrencyMustBeSelected);
                        cmbCurrency.Focus();
                        return false;
                    }
                    if (txtExRate.Value == 0)
                    {
                        errProvider.SetError(txtExRate, MessageKeys.MsgExchangeRate + " " + MessageKeys.MsgValueMustBeGreaterThanZero);
                        txtExRate.Focus();
                        return false;
                    }
                }
                int iSelectedRooms = entGroupCheckInDTLList.Count(x => x.RoomorHall == 0).ToInt32();
                if (txtNoOfRooms.Value != iSelectedRooms)
                {
                    errProvider.SetError(txtNoOfRooms, "No of Rooms must be equal to selected rooms count.");
                    txtExRate.Focus();
                    return false;
                }
                int iSelectedHalls = entGroupCheckInDTLList.Count(x => x.RoomorHall == 1).ToInt32();
                if (txtNoOfHalls.Value != iSelectedHalls)
                {
                    errProvider.SetError(txtNoOfHalls, "No of Rooms must be equal to selected halls count.");
                    txtExRate.Focus();
                    return false;
                }
                if(entGroupCheckInDTLList.GroupBy(x=> x.FK_RoomID).Where(x=> x.Count() > 1).Any())
                {
                    errProvider.SetError(txtVoucherNo, "Dupicate Rooms/Halls selected.");
                    txtExRate.Focus();
                    return false;
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                int iBookingID = cmbGrpBooking.SelectedValue.ToInt32();
                ENMVMTTransactionType? refTransType = (iBookingID > 0 ? (ENMVMTTransactionType?)ENMVMTTransactionType.HTL_Booking : null);
                int? refTransID = (iBookingID > 0 ? (int?)iBookingID : null);
                List<Rooms> rooms = GlobalMethods.GetAvailableRooms(dtpArrivalDate.Value, dtpDepartureDate.Value,
                                                                    ENMVMTTransactionType.HTL_GroupCheckIn, entGroupCheckIn.id,
                                                                    refTransType, refTransID);
                foreach (DataGridViewRow dr in dgDetails.Rows)
                {
                    dr.ErrorText = string.Empty;
                    GroupCheckInDTL dtl = (GroupCheckInDTL)dr.DataBoundItem;
                    if (dtl != null)
                    {
                        if (!rooms.Where(x => x.id == dtl.FK_RoomID).Any())
                        {
                            dr.ErrorText = "Room is not Available.";
                            dgDetails.Focus();
                            return false;
                        }
                    }
                }

                foreach (DataGridViewRow dr in dgDetails.Rows)
                {
                    dr.ErrorText = string.Empty;
                    GroupCheckInDTL dtl = (GroupCheckInDTL)dr.DataBoundItem;
                    if (dtl != null)
                    {
                        RoomStatusRegister roomStatus = GlobalMethods.GetRoomStatusByDate(dtpArrivalDate.Value)
                                                 .Where(x => x.FK_RoomID == dtl.FK_RoomID).FirstOrDefault();
                        if (roomStatus != null && roomStatus.FK_StatusID == (int)ENRoomStatus.Dirty)
                        {
                            dr.ErrorText = "Room is Dirty.";
                            dgDetails.Focus();
                            return false;
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool GrpCheckInView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInGroupCheckIn)
                {
                    PrintClick();
                }
                if (GlobalProperties.SendEmailWhileSavingInGroupCheckIn)
                {
                    SendEmail();
                }
                if (GlobalProperties.SendSMSWhileSavingInGroupCheckIn)
                {
                    SendSMS();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void GroupCheckInView_atBeforeInitialise()
        {
            _OnLoad = true;
        }
        private void GrpCheckInView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vCheckIn = entGroupCheckInList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vCheckIn;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        private bool GrpCheckInView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vBookings = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vBookings).id);
                }
                else
                {
                    cmbGuest.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool GrpCheckInView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {               
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void GrpCheckInView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbGuest.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool GroupCheckInView_atPrint(object source)
        {
            try
            {
                if (entGroupCheckIn.id == 0)
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Group Check In", entGroupCheckIn.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool GrpCheckInView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteVoucher(entGroupCheckIn.FK_VoucherHDRID, ref dbh);
                GlobalMethods.DeleteVoucher(entGroupCheckIn.FK_PaymentVoucherHDRID, ref dbh);
                foreach (GroupCheckInDTL checkInDTL in entGroupCheckInDTLList)
                {
                    dbh.GroupCheckInDTLs.DeleteObject(checkInDTL);
                    GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupCheckIn, checkInDTL);
                }
                foreach (GroupCheckInPayment Payment in entGroupCheckInPaymentList) //**Delete Payments **
                {
                    dbh.GroupCheckInPayments.DeleteObject(Payment);
                }
                dbh.DeleteObject(entGroupCheckIn);        //**Delete CheckIn**
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void GrpCheckInView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion

        #region GridMethods
        private void LoadCurrentSerialNoOfRooms()
        {
            if (dgDetails.CurrentRow == null) { return; }
            dgDetails.CurrentRow.Cells[col_slno.Name].Value = dgDetails.CurrentRow.Cells[col_slno.Name].RowIndex + 1;
        }
        private void LoadFullSerialNo()
        {
            int i = 1;
            foreach (DataGridViewRow row in dgDetails.Rows)
            {
                row.Cells[col_slno.Name].Value = i;
                i = i + 1;
            }
        }
        private GroupCheckInDTL getCurrentOfRooms()
        {
            try
            {
                if (dgDetails.CurrentRow != null)
                {
                    GroupCheckInDTL CheckInDTLs = (GroupCheckInDTL)dgDetails.CurrentRow.DataBoundItem;
                    return CheckInDTLs;
                }
                else
                {
                    return null;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void BindGrid()
        {
            try
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.EndEdit();
                bindCheckInDTL.DataSource = null;
                bindCheckInDTL.DataSource = entGroupCheckInDTLList;
                dgDetails.DataSource = bindCheckInDTL;
            }
            catch (Exception)
            {
                throw;
            }
        }

        

        private void ApplyGridStyles()
        {
            try
            {
                Col_Adult.DefaultCellStyle.Format = sQtyFormat;
                Col_Child.DefaultCellStyle.Format = sQtyFormat;
                col_Rate.DefaultCellStyle.Format = NumberFormat;
                col_AdditionalBeds.DefaultCellStyle.Format = sQtyFormat;
                col_AdditionalPersons.DefaultCellStyle.Format = sQtyFormat;
                col_AdditionalBedRate.DefaultCellStyle.Format = NumberFormat;
                col_AdditionalPersonRate.DefaultCellStyle.Format = NumberFormat;
                col_DeductionPerc.DefaultCellStyle.Format = NumberFormat;
                col_DeductionAmount.DefaultCellStyle.Format = NumberFormat;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private DataGridViewCell MoveForward(DataGridViewCell _currentCell)
        {
            try
            {
                int row_index = _currentCell.OwningRow.Index;
                int col_index = _currentCell.OwningColumn.Index;
                DataGridViewCell cell = dgDetails.Rows[row_index].Cells[col_index + 1];
                if (cell.Visible && cell.ReadOnly == false)
                {
                    return cell;
                }
                else
                {
                    return MoveForward(cell);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadRoomOrHall()
        {
            try
            {
                DataTable dtForRoomOrHall = new DataTable();
                dtForRoomOrHall.Columns.Add("id", typeof(Int32));
                dtForRoomOrHall.Columns.Add("Name", typeof(string));
                DataRow dr = dtForRoomOrHall.NewRow();
                dr["id"] = 0;
                dr["Name"] = MessageKeys.MsgRoom;
                DataRow dr1 = dtForRoomOrHall.NewRow();
                dr1["id"] = 1;
                dr1["Name"] = MessageKeys.MsgHall;
                dtForRoomOrHall.Rows.Add(dr);
                dtForRoomOrHall.Rows.Add(dr1);
                col_RoomOrHall.DataSource = dtForRoomOrHall;
                col_RoomOrHall.DisplayMember = "Name";
                col_RoomOrHall.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadRoomType()
        {
            try
            {
                entRoomTypes = dbh.RoomTypes.ToList();
                col_RoomType.DataSource = entRoomTypes;
                col_RoomType.DisplayMember = "Name";
                col_RoomType.ValueMember = "id";
                col_RoomType.DataSource = entRoomTypes;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadRooms(int _RoomTypeId)
        {
            try
            {
                if (_RoomTypeId == 0)
                {
                    entRooms = dbh.Rooms.ToList();
                    col_Room.DataSource = entRooms;
                }
                else
                {
                    col_Room.DataSource = entRooms.Where(x => x.FK_RoomTypeID == _RoomTypeId).ToList();
                }
                col_Room.DisplayMember = "Name";
                col_Room.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadRateTypes()
        {
            try
            {
                PopulateRateType();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool ValidateRoomRate()
        {
            try
            {
                if (txtExRate.Value == 0) { return false; }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void CalcRoomRent(GroupCheckInDTL pdtl)
        {
            try
            {
                if (!_OnLoad)
                {
                    if (!ValidateRoomRate()) { return; }
                    
                    if (pdtl != null)
                    {
                        int iRateTypeId = pdtl.FK_RateTypeID.ToInt32();
                        int iRoomTypeId = pdtl.FK_RoomTypeID.ToInt32();
                        e_RoomTariffs = RateCalculationClass.GetTariffs(dbh, iRoomTypeId, iRateTypeId);
                        if (e_RoomTariffs != null)
                        {
                            pdtl.Rate = e_RoomTariffs.BaseRate.ToDecimal() / txtExRate.Value;
                            pdtl.AdditionalBedRate = e_RoomTariffs.ExtraBedRate.ToDecimal() / txtExRate.Value;
                            pdtl.AdditionalPersonRate = e_RoomTariffs.AdditionalPersonRate.ToDecimal() / txtExRate.Value;
                        }
                        else
                        {
                            pdtl.Rate = 0;
                            pdtl.AdditionalBedRate = 0;
                            pdtl.AdditionalPersonRate = 0;
                        }
                        CalcRowAmount(pdtl);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcRowAmount(GroupCheckInDTL pdtl)
        {
            
            if (pdtl != null)
            {
                pdtl.Amount = pdtl.Rate * txtNoOfDays.Value + (pdtl.AdditionalPersonRate ?? 0) * (pdtl.AdditionalPersons ?? 0) +
                                                 (pdtl.AdditionalBedRate ?? 0) * (pdtl.AdditionalBeds ?? 0);
                bool blnUpdateDeductionAmount = dgDetails.CurrentCell == null || dgDetails.CurrentCell.OwningColumn.Name != col_DeductionAmount.Name;
                CalculateSlab(blnUpdateDeductionAmount, pdtl);
                CalcNetTotal();
            }
        }
        public void LoadRateTypeCombosRowWise(DataGridViewRow _CurrentRow)
        {
            try
            {
                List<RateTypes> rateTypes = dbh.RateTypes.ToList();
                rateTypes.Add(new RateTypes()
                {
                    id = 0,
                    Name = MessageKeys.MsgDefault
                });

                DataGridViewComboBoxCell _RateType = (_CurrentRow.Cells[Col_RateType.Index] as DataGridViewComboBoxCell);
                _RateType.DataSource = rateTypes;
                _RateType.DisplayMember = "Name";
                _RateType.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void LoadRoomTypeCombosRowWise(DataGridViewRow _CurrentRow, int _RoomOrHallId)
        {
            try
            {
                if (_RoomOrHallId == 1)
                    entRoomTypes = dbh.RoomTypes.Where(x => x.IsHallType == true).ToList();
                else entRoomTypes = dbh.RoomTypes.Where(x => x.IsHallType == false).ToList();
                DataGridViewComboBoxCell _RoomType = (_CurrentRow.Cells[col_RoomType.Index] as DataGridViewComboBoxCell);
                _RoomType.DataSource = entRoomTypes;
                _RoomType.DisplayMember = "Name";
                _RoomType.ValueMember = "id";
                if (_RoomOrHallId == 1) entRooms = dbh.Rooms.Where(x => x.IsHall == true).ToList();
                else entRooms = dbh.Rooms.Where(x => x.IsHall == false).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void LoadRoomsCombosRowWise(DataGridViewRow _CurrentRow, int _RoomTypeId)
        {
            try
            {
                if (_RoomTypeId == 0)
                {
                    entRooms = dbh.Rooms.ToList();
                    DataGridViewComboBoxCell _Rooms = (_CurrentRow.Cells[col_Room.Index] as DataGridViewComboBoxCell);
                    _Rooms.DataSource = entRooms;
                    _Rooms.DisplayMember = "Name";
                    _Rooms.ValueMember = "id";
                }
                else
                {
                    DataGridViewComboBoxCell _Rooms = (_CurrentRow.Cells[col_Room.Index] as DataGridViewComboBoxCell);
                    _Rooms.DataSource = entRooms.Where(x => x.FK_RoomTypeID == _RoomTypeId).ToList(); ;
                    _Rooms.DisplayMember = "Name";
                    _Rooms.ValueMember = "id";
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Grid Events
        private void dgDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            dgDetails.CurrentCell.Tag = dgDetails.CurrentCell.Value ?? string.Empty;
        }
        private void dgDetails_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
        private void dgDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (e.Control is DataGridViewComboBoxEditingControl)
                {
                    dgDetails.NotifyCurrentCellDirty(true);
                    cb = (DataGridViewComboBoxEditingControl)e.Control;
                    if (cb != null)
                    {
                        cb.DropDownStyle = ComboBoxStyle.DropDownList;
                        cb.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        cb.Validating -= new CancelEventHandler(cb_ValidatingOfRooms);
                        cb.Validating += new CancelEventHandler(cb_ValidatingOfRooms);
                        cb.KeyDown -= new KeyEventHandler(cb_KeyDown);
                        cb.KeyDown += new KeyEventHandler(cb_KeyDown);
                        cb.Focus();
                    }
                }
                if (e.Control is DataGridViewTextBoxEditingControl)
                {
                    textbox = (DataGridViewTextBoxEditingControl)e.Control;
                    if (textbox != null)
                    {
                        textbox.KeyPress += new KeyPressEventHandler(textbox_KeyPressOfRooms);
                        textbox.KeyUp -= new KeyEventHandler(textbox_KeyUpOfRooms);
                        textbox.KeyUp += new KeyEventHandler(textbox_KeyUpOfRooms);
                        textbox.KeyDown -= new KeyEventHandler(textbox_KeyDownOfRooms);
                        textbox.KeyDown += new KeyEventHandler(textbox_KeyDownOfRooms);

                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
            }
        }

        void cb_ValidatingOfRooms(object sender, CancelEventArgs e)
        {
            try
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                {
                    if (dgDetails.LastKey == Keys.Enter)
                    {
                        if (cb.SelectedIndex == -1 && cb.Text != "")
                        {

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        void cb_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dgDetails.EndEdit();
                dgDetails.CurrentCell = MoveForward(dgDetails.CurrentCell);
            }
        }
        void textbox_KeyPressOfRooms(object sender, KeyPressEventArgs e)
        {
            try
            {
                sKeyChar = e.KeyChar.ToString();
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_Adult.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Child.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
                {
                    if (Char.IsDigit(e.KeyChar)) return;
                    if (Char.IsControl(e.KeyChar)) return;
                    if ((e.KeyChar == '.') && ((sender as TextBox).Text.Contains('.') == false)) return;
                    if ((e.KeyChar == '.') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                    if ((e.KeyChar == '-') && ((sender as TextBox).Text.Contains('-') == false)) return;
                    if ((e.KeyChar == '-') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                    e.Handled = true;
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                {
                    //   dgDetails.NotifyCurrentCellDirty(true);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        void textbox_KeyUpOfRooms(object sender, KeyEventArgs e)
        {
            try
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                {
                    if (e.KeyCode == Keys.Right) { return; }
                    if (e.KeyCode == Keys.Left) { return; }
                    if (e.KeyCode == Keys.Return) { return; }
                    if (e.KeyCode == Keys.Escape) { return; }
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        void textbox_KeyDownOfRooms(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Return)
                {
                    if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                    {
                        int index = dgDetails.SelectedCells[0].OwningRow.Index;
                        if (textbox.Text.Trim() != "")
                        {

                        }
                        //dgDetails.CurrentCell = dgDetails.Rows[index].Cells[col_Code.Index + 1];
                    }
                    else if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                    {
                        int index = dgDetails.SelectedCells[0].OwningRow.Index;
                        if (textbox.Text.Trim() == "")
                        {
                            // e.Handled = true;
                        }
                        else
                        {

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                GroupCheckInDTL pdtl = (GroupCheckInDTL)dgDetails.Rows[e.RowIndex].DataBoundItem;
                if (pdtl != null)
                {
                    try
                    {
                        int _CurrentProductID = pdtl.FK_GroupCheckInID.toInt32();
                    }
                    catch (Exception) { }
                }
                if (e.RowIndex == -1) { return; }
                LoadCurrentSerialNoOfRooms();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                LoadCurrentSerialNoOfRooms();
                LoadFullSerialNo();
                CalcNetTotal();
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                if (dgDetails.CurrentCell.OwningColumn.Name == col_RoomOrHall.Name)
                {
                    if (dgDetails.CurrentCell is DataGridViewComboBoxCell)
                    {
                        DataGridViewComboBoxCell cb = (DataGridViewComboBoxCell)dgDetails.CurrentCell;
                        if (cb.Value != null)
                        {
                            LoadRoomTypeCombosRowWise(dgDetails.CurrentRow, cb.Value.ToInt32());
                        }
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_RateType.Name)
                {
                    if (dgDetails.CurrentCell.Value == null) { return; }

                    LoadRateTypeCombosRowWise(dgDetails.CurrentRow);
                }

                if (dgDetails.CurrentCell.OwningColumn.Name == col_RoomType.Name)
                {
                    if (dgDetails.CurrentCell.Value == null) { return; }
                    GroupCheckInDTL pdtl = getCurrentOfRooms();
                    if (dgDetails.CurrentCell is DataGridViewComboBoxCell)
                    {
                        LoadRoomsCombosRowWise(dgDetails.CurrentRow, dgDetails.CurrentRow.Cells[col_RoomType.Name].Value.ToInt32());
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_RateType.Name || dgDetails.CurrentCell.OwningColumn.Name == col_RoomType.Name)
                    CalcRoomRent(getCurrent());
                else
                    CalcRowAmount(getCurrent());
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_Adult.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Child.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalBeds.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalBedRate.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalPersons.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalPersonRate.Name)
                {
                    if (e.FormattedValue == null || e.FormattedValue.ToString2().Trim() == "")
                    {
                        dgDetails.CurrentCell.Value = 0;
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Child.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Adult.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalBeds.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalBedRate.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalPersons.Name || dgDetails.CurrentCell.OwningColumn.Name == col_AdditionalPersonRate.Name)
                {
                    if (e.FormattedValue.ToString().ToDecimal() < 0)
                    {
                        e.Cancel = true;
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_RateType.Name)
                {
                    if (txtNoOfDays.Text.Trim() == "")
                    {
                        errProvider.SetError(dtpArrivalDate, "Change Arrival Date"); dtpArrivalDate.Focus(); return;
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                {

                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
