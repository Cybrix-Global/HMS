﻿namespace atACC.HTL.Transactions
{
    partial class CheckInView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckInView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.lblBillingAccountID = new atACCFramework.UserControls.atLabel();
            this.cmbBillingAccount = new atACCFramework.UserControls.ComboBoxExt();
            this.txtVoucherDiscountAmount = new atACCFramework.UserControls.TextBoxExt();
            this.lblVoucherDiscountAmount = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDiscountAccount = new atACCFramework.UserControls.atLabel();
            this.cmbVoucherDiscount = new atACCFramework.UserControls.ComboBoxExt();
            this.txtDeductionAmount = new atACCFramework.UserControls.TextBoxExt();
            this.lblDeductionAmount = new atACCFramework.UserControls.atLabel();
            this.txtDeductionPerc = new atACCFramework.UserControls.TextBoxExt();
            this.lblDeductionPerc = new atACCFramework.UserControls.atLabel();
            this.txtAddPersonRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddPersonRate = new atACCFramework.UserControls.atLabel();
            this.txtAddPersons = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddPersons = new atACCFramework.UserControls.atLabel();
            this.txtAddBedRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblAdditionalBedRate = new atACCFramework.UserControls.atLabel();
            this.txtAdditionalBeds = new atACCFramework.UserControls.TextBoxExt();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.cmbAgent = new atACCFramework.UserControls.ComboBoxExt();
            this.lblAgent = new atACCFramework.UserControls.atLabel();
            this.txtRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblRate = new atACCFramework.UserControls.atLabel();
            this.cmbRateType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRateType = new atACCFramework.UserControls.atLabel();
            this.txtChild = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuestType = new atACCFramework.UserControls.atLabel();
            this.cmbGuestType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblSource = new atACCFramework.UserControls.atLabel();
            this.cmbSource = new atACCFramework.UserControls.ComboBoxExt();
            this.lblChild = new atACCFramework.UserControls.atLabel();
            this.txtAdult = new atACCFramework.UserControls.TextBoxExt();
            this.lblAdult = new atACCFramework.UserControls.atLabel();
            this.cmbRoomOrHall = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomOrHall = new atACCFramework.UserControls.atLabel();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.cmbGuest = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.cmbBooking = new atACCFramework.UserControls.ComboBoxExt();
            this.lblBooking = new atACCFramework.UserControls.atLabel();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.txtNoOfDays = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfDays = new atACCFramework.UserControls.atLabel();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.btnExtraServ = new atACCFramework.UserControls.atButton();
            this.txtExtraBedAndPer = new atACCFramework.UserControls.atNumericLabel();
            this.lblAddlBedAndPerson = new atACCFramework.UserControls.atLabel();
            this.txtRoomRent = new atACCFramework.UserControls.atNumericLabel();
            this.lblRoomRent = new atACCFramework.UserControls.atLabel();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.txtGross = new atACCFramework.UserControls.atNumericLabel();
            this.lblGrossCap = new atACCFramework.UserControls.atLabel();
            this.txtAdvance = new atACCFramework.UserControls.atNumericLabel();
            this.lblAdvance = new atACCFramework.UserControls.atLabel();
            this.txtOpBalance = new atACCFramework.UserControls.atNumericLabel();
            this.lblOpBalance = new atACC.HTL.Transactions.AccountLabel();
            this.txtExtraServices = new atACCFramework.UserControls.atNumericLabel();
            this.txtTotalDiscount = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotalDisc = new atACCFramework.UserControls.atLabel();
            this.lblTotalTax = new atACCFramework.UserControls.TaxLabel();
            this.btnPayment = new atACCFramework.UserControls.atButton();
            this.txtBalance = new atACCFramework.UserControls.TextBoxNormal();
            this.txtPayment = new atACCFramework.UserControls.atNumericLabel();
            this.lblBalance = new atACCFramework.UserControls.atLabel();
            this.grpDiscountVoucher = new atACCFramework.UserControls.atGroupBox();
            this.txtNetTotal = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetTotal = new atACCFramework.UserControls.atLabel();
            this.txtTotalTax = new atACCFramework.UserControls.atNumericLabel();
            this.btnSeperator1 = new System.Windows.Forms.Button();
            this.lblAdditionalBeds = new atACCFramework.UserControls.atLabel();
            this.txtGuestVehicleName = new atACCFramework.UserControls.TextBoxExt();
            this.txtGuestVehicleNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuestVehicleName = new atACCFramework.UserControls.atLabel();
            this.lblGuestVehicleType = new atACCFramework.UserControls.atLabel();
            this.lblGuestVehicleNo = new atACCFramework.UserControls.atLabel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblExternal = new atACC.HTL.Transactions.AccountLabel();
            this.txtExternalAmt = new atACCFramework.UserControls.atNumericLabel();
            this.lblCurrencyCap = new atACCFramework.UserControls.atLabel();
            this.lblExRateCap = new atACCFramework.UserControls.atLabel();
            this.txtRoomTotal = new atACCFramework.UserControls.TextBoxExt();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.lblPayment = new atACCFramework.UserControls.atLabel();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.btnNewSource = new atACCFramework.UserControls.atButton();
            this.txtAddlPsnTotal = new atACCFramework.UserControls.TextBoxExt();
            this.btnNewGuestType = new atACCFramework.UserControls.atButton();
            this.lblMandatory8 = new System.Windows.Forms.Label();
            this.lblMandatory7 = new System.Windows.Forms.Label();
            this.lblMandatory6 = new System.Windows.Forms.Label();
            this.cmbGuestVehicleType = new atACCFramework.UserControls.ComboBoxExt();
            this.btnBooking = new atACCFramework.UserControls.atButton();
            this.txtAddlBedTotal = new atACCFramework.UserControls.TextBoxExt();
            this.btnNewGuest = new atACCFramework.UserControls.atButton();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.lblMandatory9 = new System.Windows.Forms.Label();
            this.lblMandatory10 = new System.Windows.Forms.Label();
            this.lblCancelStatus = new System.Windows.Forms.Label();
            this.lblMandatory11 = new System.Windows.Forms.Label();
            this.cmbCurrency = new atACCFramework.UserControls.ComboBoxExt();
            this.txtExRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblEqualToRateTotal = new atACCFramework.UserControls.atLabel();
            this.lblAddlPsnTotal = new atACCFramework.UserControls.atLabel();
            this.lblAddlBedTotal = new atACCFramework.UserControls.atLabel();
            this.cmbRoom = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGrandTotal = new atACCFramework.UserControls.atNumericLabel();
            this.atlblTot = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlHeader2.SuspendLayout();
            this.grpDiscountVoucher.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnPayment);
            this.panel1.Controls.Add(this.lblGrandTotal);
            this.panel1.Controls.Add(this.atlblTot);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.SetChildIndex(this.atlblTot, 0);
            this.panel1.Controls.SetChildIndex(this.lblGrandTotal, 0);
            this.panel1.Controls.SetChildIndex(this.btnPayment, 0);
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // dtVoucherDate
            // 
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // lblBillingAccountID
            // 
            resources.ApplyResources(this.lblBillingAccountID, "lblBillingAccountID");
            this.lblBillingAccountID.Name = "lblBillingAccountID";
            this.lblBillingAccountID.RequiredField = false;
            // 
            // cmbBillingAccount
            // 
            this.cmbBillingAccount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBillingAccount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBillingAccount.DropDownHeight = 300;
            this.cmbBillingAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbBillingAccount, "cmbBillingAccount");
            this.cmbBillingAccount.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbBillingAccount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbBillingAccount.IconAlignment"))));
            this.cmbBillingAccount.Name = "cmbBillingAccount";
            this.cmbBillingAccount.SelectedValueChanged += new System.EventHandler(this.cmbBillingAccount_SelectedValueChanged);
            // 
            // txtVoucherDiscountAmount
            // 
            this.txtVoucherDiscountAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtVoucherDiscountAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVoucherDiscountAmount.Format = null;
            this.txtVoucherDiscountAmount.isAllowNegative = false;
            this.txtVoucherDiscountAmount.isAllowSpecialChar = false;
            this.txtVoucherDiscountAmount.isNumbersOnly = false;
            this.txtVoucherDiscountAmount.isNumeric = true;
            this.txtVoucherDiscountAmount.isTouchable = true;
            resources.ApplyResources(this.txtVoucherDiscountAmount, "txtVoucherDiscountAmount");
            this.txtVoucherDiscountAmount.Name = "txtVoucherDiscountAmount";
            this.txtVoucherDiscountAmount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblVoucherDiscountAmount
            // 
            resources.ApplyResources(this.lblVoucherDiscountAmount, "lblVoucherDiscountAmount");
            this.lblVoucherDiscountAmount.Name = "lblVoucherDiscountAmount";
            this.lblVoucherDiscountAmount.RequiredField = false;
            // 
            // lblVoucherDiscountAccount
            // 
            resources.ApplyResources(this.lblVoucherDiscountAccount, "lblVoucherDiscountAccount");
            this.lblVoucherDiscountAccount.Name = "lblVoucherDiscountAccount";
            this.lblVoucherDiscountAccount.RequiredField = false;
            // 
            // cmbVoucherDiscount
            // 
            this.cmbVoucherDiscount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbVoucherDiscount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVoucherDiscount.DropDownHeight = 300;
            this.cmbVoucherDiscount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbVoucherDiscount, "cmbVoucherDiscount");
            this.cmbVoucherDiscount.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbVoucherDiscount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbVoucherDiscount.IconAlignment"))));
            this.cmbVoucherDiscount.Name = "cmbVoucherDiscount";
            // 
            // txtDeductionAmount
            // 
            resources.ApplyResources(this.txtDeductionAmount, "txtDeductionAmount");
            this.txtDeductionAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtDeductionAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDeductionAmount.Format = null;
            this.txtDeductionAmount.isAllowNegative = false;
            this.txtDeductionAmount.isAllowSpecialChar = false;
            this.txtDeductionAmount.isNumbersOnly = false;
            this.txtDeductionAmount.isNumeric = true;
            this.txtDeductionAmount.isTouchable = true;
            this.txtDeductionAmount.Name = "txtDeductionAmount";
            this.txtDeductionAmount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtDeductionAmount.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDeductionAmount_KeyUp);
            // 
            // lblDeductionAmount
            // 
            resources.ApplyResources(this.lblDeductionAmount, "lblDeductionAmount");
            this.lblDeductionAmount.Name = "lblDeductionAmount";
            this.lblDeductionAmount.RequiredField = false;
            // 
            // txtDeductionPerc
            // 
            resources.ApplyResources(this.txtDeductionPerc, "txtDeductionPerc");
            this.txtDeductionPerc.BackColor = System.Drawing.SystemColors.Window;
            this.txtDeductionPerc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDeductionPerc.Format = null;
            this.txtDeductionPerc.isAllowNegative = false;
            this.txtDeductionPerc.isAllowSpecialChar = false;
            this.txtDeductionPerc.isNumbersOnly = false;
            this.txtDeductionPerc.isNumeric = true;
            this.txtDeductionPerc.isTouchable = true;
            this.txtDeductionPerc.Name = "txtDeductionPerc";
            this.txtDeductionPerc.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtDeductionPerc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDeductionPerc_KeyUp);
            // 
            // lblDeductionPerc
            // 
            resources.ApplyResources(this.lblDeductionPerc, "lblDeductionPerc");
            this.lblDeductionPerc.Name = "lblDeductionPerc";
            this.lblDeductionPerc.RequiredField = false;
            // 
            // txtAddPersonRate
            // 
            resources.ApplyResources(this.txtAddPersonRate, "txtAddPersonRate");
            this.txtAddPersonRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddPersonRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddPersonRate.Format = null;
            this.txtAddPersonRate.isAllowNegative = false;
            this.txtAddPersonRate.isAllowSpecialChar = false;
            this.txtAddPersonRate.isNumbersOnly = false;
            this.txtAddPersonRate.isNumeric = true;
            this.txtAddPersonRate.isTouchable = true;
            this.txtAddPersonRate.Name = "txtAddPersonRate";
            this.txtAddPersonRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAddPersonRate.TextChanged += new System.EventHandler(this.txtRate_TextChanged);
            // 
            // lblAddPersonRate
            // 
            resources.ApplyResources(this.lblAddPersonRate, "lblAddPersonRate");
            this.lblAddPersonRate.Name = "lblAddPersonRate";
            this.lblAddPersonRate.RequiredField = false;
            // 
            // txtAddPersons
            // 
            resources.ApplyResources(this.txtAddPersons, "txtAddPersons");
            this.txtAddPersons.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddPersons.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddPersons.Format = null;
            this.txtAddPersons.isAllowNegative = false;
            this.txtAddPersons.isAllowSpecialChar = false;
            this.txtAddPersons.isNumbersOnly = false;
            this.txtAddPersons.isNumeric = true;
            this.txtAddPersons.isTouchable = true;
            this.txtAddPersons.Name = "txtAddPersons";
            this.txtAddPersons.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAddPersons.TextChanged += new System.EventHandler(this.txtRate_TextChanged);
            // 
            // lblAddPersons
            // 
            resources.ApplyResources(this.lblAddPersons, "lblAddPersons");
            this.lblAddPersons.Name = "lblAddPersons";
            this.lblAddPersons.RequiredField = false;
            // 
            // txtAddBedRate
            // 
            resources.ApplyResources(this.txtAddBedRate, "txtAddBedRate");
            this.txtAddBedRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddBedRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddBedRate.Format = null;
            this.txtAddBedRate.isAllowNegative = false;
            this.txtAddBedRate.isAllowSpecialChar = false;
            this.txtAddBedRate.isNumbersOnly = false;
            this.txtAddBedRate.isNumeric = true;
            this.txtAddBedRate.isTouchable = true;
            this.txtAddBedRate.Name = "txtAddBedRate";
            this.txtAddBedRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAddBedRate.TextChanged += new System.EventHandler(this.txtRate_TextChanged);
            // 
            // lblAdditionalBedRate
            // 
            resources.ApplyResources(this.lblAdditionalBedRate, "lblAdditionalBedRate");
            this.lblAdditionalBedRate.Name = "lblAdditionalBedRate";
            this.lblAdditionalBedRate.RequiredField = false;
            // 
            // txtAdditionalBeds
            // 
            resources.ApplyResources(this.txtAdditionalBeds, "txtAdditionalBeds");
            this.txtAdditionalBeds.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdditionalBeds.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdditionalBeds.Format = null;
            this.txtAdditionalBeds.isAllowNegative = false;
            this.txtAdditionalBeds.isAllowSpecialChar = false;
            this.txtAdditionalBeds.isNumbersOnly = false;
            this.txtAdditionalBeds.isNumeric = true;
            this.txtAdditionalBeds.isTouchable = true;
            this.txtAdditionalBeds.Name = "txtAdditionalBeds";
            this.txtAdditionalBeds.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAdditionalBeds.TextChanged += new System.EventHandler(this.txtRate_TextChanged);
            // 
            // txtRemarks
            // 
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.errProvider.SetIconAlignment(this.lblRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRemarks.IconAlignment"))));
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // cmbAgent
            // 
            this.cmbAgent.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAgent.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAgent.DropDownHeight = 300;
            this.cmbAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbAgent, "cmbAgent");
            this.cmbAgent.FormattingEnabled = true;
            this.cmbAgent.Name = "cmbAgent";
            // 
            // lblAgent
            // 
            resources.ApplyResources(this.lblAgent, "lblAgent");
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.RequiredField = false;
            // 
            // txtRate
            // 
            resources.ApplyResources(this.txtRate, "txtRate");
            this.txtRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRate.Format = null;
            this.txtRate.isAllowNegative = false;
            this.txtRate.isAllowSpecialChar = false;
            this.txtRate.isNumbersOnly = false;
            this.txtRate.isNumeric = true;
            this.txtRate.isTouchable = false;
            this.txtRate.Name = "txtRate";
            this.txtRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRate.TextChanged += new System.EventHandler(this.txtRate_TextChanged);
            // 
            // lblRate
            // 
            resources.ApplyResources(this.lblRate, "lblRate");
            this.lblRate.Name = "lblRate";
            this.lblRate.RequiredField = false;
            // 
            // cmbRateType
            // 
            resources.ApplyResources(this.cmbRateType, "cmbRateType");
            this.cmbRateType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRateType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRateType.DropDownHeight = 300;
            this.cmbRateType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRateType.FormattingEnabled = true;
            this.cmbRateType.Name = "cmbRateType";
            this.cmbRateType.SelectedIndexChanged += new System.EventHandler(this.cmbRateType_SelectedIndexChanged);
            // 
            // lblRateType
            // 
            resources.ApplyResources(this.lblRateType, "lblRateType");
            this.lblRateType.Name = "lblRateType";
            this.lblRateType.RequiredField = false;
            // 
            // txtChild
            // 
            resources.ApplyResources(this.txtChild, "txtChild");
            this.txtChild.BackColor = System.Drawing.SystemColors.Window;
            this.txtChild.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtChild.Format = null;
            this.errProvider.SetIconAlignment(this.txtChild, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtChild.IconAlignment"))));
            this.txtChild.isAllowNegative = false;
            this.txtChild.isAllowSpecialChar = true;
            this.txtChild.isNumbersOnly = false;
            this.txtChild.isNumeric = true;
            this.txtChild.isTouchable = false;
            this.txtChild.Name = "txtChild";
            this.txtChild.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblGuestType
            // 
            resources.ApplyResources(this.lblGuestType, "lblGuestType");
            this.lblGuestType.Name = "lblGuestType";
            this.lblGuestType.RequiredField = false;
            // 
            // cmbGuestType
            // 
            this.cmbGuestType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuestType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuestType.DropDownHeight = 300;
            this.cmbGuestType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuestType, "cmbGuestType");
            this.cmbGuestType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuestType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuestType.IconAlignment"))));
            this.cmbGuestType.Name = "cmbGuestType";
            // 
            // lblSource
            // 
            resources.ApplyResources(this.lblSource, "lblSource");
            this.lblSource.Name = "lblSource";
            this.lblSource.RequiredField = false;
            // 
            // cmbSource
            // 
            this.cmbSource.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSource.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSource.DropDownHeight = 300;
            this.cmbSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbSource, "cmbSource");
            this.cmbSource.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbSource, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbSource.IconAlignment"))));
            this.cmbSource.Name = "cmbSource";
            // 
            // lblChild
            // 
            resources.ApplyResources(this.lblChild, "lblChild");
            this.errProvider.SetIconAlignment(this.lblChild, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblChild.IconAlignment"))));
            this.lblChild.Name = "lblChild";
            this.lblChild.RequiredField = false;
            // 
            // txtAdult
            // 
            resources.ApplyResources(this.txtAdult, "txtAdult");
            this.txtAdult.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdult.Format = null;
            this.errProvider.SetIconAlignment(this.txtAdult, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAdult.IconAlignment"))));
            this.txtAdult.isAllowNegative = false;
            this.txtAdult.isAllowSpecialChar = true;
            this.txtAdult.isNumbersOnly = false;
            this.txtAdult.isNumeric = true;
            this.txtAdult.isTouchable = false;
            this.txtAdult.Name = "txtAdult";
            this.txtAdult.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAdult.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAdult_KeyUp);
            // 
            // lblAdult
            // 
            resources.ApplyResources(this.lblAdult, "lblAdult");
            this.errProvider.SetIconAlignment(this.lblAdult, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdult.IconAlignment"))));
            this.lblAdult.Name = "lblAdult";
            this.lblAdult.RequiredField = false;
            // 
            // cmbRoomOrHall
            // 
            resources.ApplyResources(this.cmbRoomOrHall, "cmbRoomOrHall");
            this.cmbRoomOrHall.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomOrHall.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomOrHall.DropDownHeight = 300;
            this.cmbRoomOrHall.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoomOrHall.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoomOrHall, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoomOrHall.IconAlignment"))));
            this.cmbRoomOrHall.Name = "cmbRoomOrHall";
            this.cmbRoomOrHall.SelectedIndexChanged += new System.EventHandler(this.cmbHall_SelectedIndexChanged);
            this.cmbRoomOrHall.SelectedValueChanged += new System.EventHandler(this.cmbRoomOrHall_SelectedValueChanged);
            // 
            // lblRoomOrHall
            // 
            resources.ApplyResources(this.lblRoomOrHall, "lblRoomOrHall");
            this.lblRoomOrHall.Name = "lblRoomOrHall";
            this.lblRoomOrHall.RequiredField = false;
            // 
            // cmbRoomType
            // 
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Name = "cmbRoomType";
            this.cmbRoomType.SelectedValueChanged += new System.EventHandler(this.cmbRoomType_SelectedValueChanged);
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // cmbGuest
            // 
            this.cmbGuest.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuest.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuest.DropDownHeight = 300;
            this.cmbGuest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuest, "cmbGuest");
            this.cmbGuest.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuest, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuest.IconAlignment"))));
            this.cmbGuest.Name = "cmbGuest";
            this.cmbGuest.SelectedValueChanged += new System.EventHandler(this.cmbGuest_SelectedValueChanged);
            this.cmbGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbGuest_KeyPress);
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // cmbBooking
            // 
            resources.ApplyResources(this.cmbBooking, "cmbBooking");
            this.cmbBooking.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBooking.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBooking.DropDownHeight = 300;
            this.cmbBooking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBooking.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbBooking, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbBooking.IconAlignment"))));
            this.cmbBooking.Name = "cmbBooking";
            this.cmbBooking.SelectedValueChanged += new System.EventHandler(this.cmbBooking_SelectedValueChanged);
            // 
            // lblBooking
            // 
            resources.ApplyResources(this.lblBooking, "lblBooking");
            this.lblBooking.Name = "lblBooking";
            this.lblBooking.RequiredField = false;
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // txtNoOfDays
            // 
            resources.ApplyResources(this.txtNoOfDays, "txtNoOfDays");
            this.txtNoOfDays.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfDays.Format = null;
            this.txtNoOfDays.isAllowNegative = false;
            this.txtNoOfDays.isAllowSpecialChar = false;
            this.txtNoOfDays.isNumbersOnly = true;
            this.txtNoOfDays.isNumeric = false;
            this.txtNoOfDays.isTouchable = true;
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.ReadOnly = true;
            this.txtNoOfDays.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNoOfDays
            // 
            resources.ApplyResources(this.lblNoOfDays, "lblNoOfDays");
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.RequiredField = false;
            // 
            // dtpDepartureDate
            // 
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpDepartureDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // dtpArrivalDate
            // 
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpArrivalDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // btnExtraServ
            // 
            resources.ApplyResources(this.btnExtraServ, "btnExtraServ");
            this.btnExtraServ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnExtraServ.FlatAppearance.BorderSize = 0;
            this.btnExtraServ.ForeColor = System.Drawing.Color.White;
            this.btnExtraServ.Name = "btnExtraServ";
            this.btnExtraServ.UseVisualStyleBackColor = false;
            this.btnExtraServ.Click += new System.EventHandler(this.btnExtraServ_Click);
            // 
            // txtExtraBedAndPer
            // 
            resources.ApplyResources(this.txtExtraBedAndPer, "txtExtraBedAndPer");
            this.txtExtraBedAndPer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExtraBedAndPer.ForeColor = System.Drawing.Color.Black;
            this.txtExtraBedAndPer.Format = "N2";
            this.txtExtraBedAndPer.Name = "txtExtraBedAndPer";
            this.txtExtraBedAndPer.RequiredField = false;
            this.txtExtraBedAndPer.UseCompatibleTextRendering = true;
            this.txtExtraBedAndPer.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddlBedAndPerson
            // 
            resources.ApplyResources(this.lblAddlBedAndPerson, "lblAddlBedAndPerson");
            this.errProvider.SetIconAlignment(this.lblAddlBedAndPerson, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddlBedAndPerson.IconAlignment"))));
            this.lblAddlBedAndPerson.Name = "lblAddlBedAndPerson";
            this.lblAddlBedAndPerson.RequiredField = false;
            // 
            // txtRoomRent
            // 
            resources.ApplyResources(this.txtRoomRent, "txtRoomRent");
            this.txtRoomRent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRoomRent.ForeColor = System.Drawing.Color.Black;
            this.txtRoomRent.Format = "N2";
            this.txtRoomRent.Name = "txtRoomRent";
            this.txtRoomRent.RequiredField = false;
            this.txtRoomRent.UseCompatibleTextRendering = true;
            this.txtRoomRent.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblRoomRent
            // 
            resources.ApplyResources(this.lblRoomRent, "lblRoomRent");
            this.errProvider.SetIconAlignment(this.lblRoomRent, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoomRent.IconAlignment"))));
            this.lblRoomRent.Name = "lblRoomRent";
            this.lblRoomRent.RequiredField = false;
            // 
            // cmbEmployee
            // 
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // txtGross
            // 
            resources.ApplyResources(this.txtGross, "txtGross");
            this.txtGross.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGross.ForeColor = System.Drawing.Color.Black;
            this.txtGross.Format = "N2";
            this.txtGross.Name = "txtGross";
            this.txtGross.RequiredField = false;
            this.txtGross.UseCompatibleTextRendering = true;
            this.txtGross.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblGrossCap
            // 
            resources.ApplyResources(this.lblGrossCap, "lblGrossCap");
            this.errProvider.SetIconAlignment(this.lblGrossCap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblGrossCap.IconAlignment"))));
            this.lblGrossCap.Name = "lblGrossCap";
            this.lblGrossCap.RequiredField = false;
            // 
            // txtAdvance
            // 
            resources.ApplyResources(this.txtAdvance, "txtAdvance");
            this.txtAdvance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdvance.ForeColor = System.Drawing.Color.Black;
            this.txtAdvance.Format = "N2";
            this.txtAdvance.Name = "txtAdvance";
            this.txtAdvance.RequiredField = false;
            this.txtAdvance.UseCompatibleTextRendering = true;
            this.txtAdvance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAdvance
            // 
            resources.ApplyResources(this.lblAdvance, "lblAdvance");
            this.errProvider.SetIconAlignment(this.lblAdvance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdvance.IconAlignment"))));
            this.lblAdvance.Name = "lblAdvance";
            this.lblAdvance.RequiredField = false;
            // 
            // txtOpBalance
            // 
            resources.ApplyResources(this.txtOpBalance, "txtOpBalance");
            this.txtOpBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOpBalance.ForeColor = System.Drawing.Color.Black;
            this.txtOpBalance.Format = "N2";
            this.txtOpBalance.Name = "txtOpBalance";
            this.txtOpBalance.RequiredField = false;
            this.txtOpBalance.UseCompatibleTextRendering = true;
            this.txtOpBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblOpBalance
            // 
            resources.ApplyResources(this.lblOpBalance, "lblOpBalance");
            this.lblOpBalance.DataSource = null;
            this.lblOpBalance.Format = null;
            this.errProvider.SetIconAlignment(this.lblOpBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblOpBalance.IconAlignment"))));
            this.lblOpBalance.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblOpBalance.LinkColor = System.Drawing.SystemColors.ControlText;
            this.lblOpBalance.Name = "lblOpBalance";
            this.lblOpBalance.TabStop = true;
            // 
            // txtExtraServices
            // 
            resources.ApplyResources(this.txtExtraServices, "txtExtraServices");
            this.txtExtraServices.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExtraServices.ForeColor = System.Drawing.Color.Black;
            this.txtExtraServices.Format = "N2";
            this.txtExtraServices.Name = "txtExtraServices";
            this.txtExtraServices.RequiredField = false;
            this.txtExtraServices.UseCompatibleTextRendering = true;
            this.txtExtraServices.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtTotalDiscount
            // 
            resources.ApplyResources(this.txtTotalDiscount, "txtTotalDiscount");
            this.txtTotalDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalDiscount.Format = "N2";
            this.txtTotalDiscount.Name = "txtTotalDiscount";
            this.txtTotalDiscount.RequiredField = false;
            this.txtTotalDiscount.UseCompatibleTextRendering = true;
            this.txtTotalDiscount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotalDisc
            // 
            resources.ApplyResources(this.lblTotalDisc, "lblTotalDisc");
            this.errProvider.SetIconAlignment(this.lblTotalDisc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalDisc.IconAlignment"))));
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.RequiredField = false;
            // 
            // lblTotalTax
            // 
            resources.ApplyResources(this.lblTotalTax, "lblTotalTax");
            this.lblTotalTax.DisabledLinkColor = System.Drawing.Color.Red;
            this.lblTotalTax.Format = null;
            this.lblTotalTax.lblAddnlTax = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblCGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblExciseDuty = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblIGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblSGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax1 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax2 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax3 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblVAT = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblTotalTax.LinkColor = System.Drawing.Color.Black;
            this.lblTotalTax.Name = "lblTotalTax";
            this.lblTotalTax.TabStop = true;
            this.lblTotalTax.VisitedLinkColor = System.Drawing.Color.Blue;
            // 
            // btnPayment
            // 
            resources.ApplyResources(this.btnPayment, "btnPayment");
            this.btnPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnPayment.FlatAppearance.BorderSize = 0;
            this.btnPayment.ForeColor = System.Drawing.Color.White;
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // txtBalance
            // 
            resources.ApplyResources(this.txtBalance, "txtBalance");
            this.txtBalance.BackColor = System.Drawing.SystemColors.Window;
            this.txtBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBalance.Format = null;
            this.txtBalance.isAllowNegative = true;
            this.txtBalance.isAllowSpecialChar = false;
            this.txtBalance.isNumeric = true;
            this.txtBalance.isTouchable = false;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.TabStop = false;
            this.txtBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            // 
            // txtPayment
            // 
            resources.ApplyResources(this.txtPayment, "txtPayment");
            this.txtPayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Format = "N2";
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.RequiredField = false;
            this.txtPayment.UseCompatibleTextRendering = true;
            this.txtPayment.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBalance
            // 
            resources.ApplyResources(this.lblBalance, "lblBalance");
            this.errProvider.SetIconAlignment(this.lblBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblBalance.IconAlignment"))));
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.RequiredField = false;
            // 
            // grpDiscountVoucher
            // 
            resources.ApplyResources(this.grpDiscountVoucher, "grpDiscountVoucher");
            this.grpDiscountVoucher.BackColor = System.Drawing.Color.Transparent;
            this.grpDiscountVoucher.Controls.Add(this.cmbVoucherDiscount);
            this.grpDiscountVoucher.Controls.Add(this.txtVoucherDiscountAmount);
            this.grpDiscountVoucher.Controls.Add(this.lblVoucherDiscountAccount);
            this.grpDiscountVoucher.Controls.Add(this.lblVoucherDiscountAmount);
            this.grpDiscountVoucher.Name = "grpDiscountVoucher";
            this.grpDiscountVoucher.TabStop = false;
            // 
            // txtNetTotal
            // 
            resources.ApplyResources(this.txtNetTotal, "txtNetTotal");
            this.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNetTotal.ForeColor = System.Drawing.Color.Black;
            this.txtNetTotal.Format = "N2";
            this.txtNetTotal.Name = "txtNetTotal";
            this.txtNetTotal.RequiredField = false;
            this.txtNetTotal.UseCompatibleTextRendering = true;
            this.txtNetTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetTotal
            // 
            resources.ApplyResources(this.lblNetTotal, "lblNetTotal");
            this.errProvider.SetIconAlignment(this.lblNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNetTotal.IconAlignment"))));
            this.lblNetTotal.Name = "lblNetTotal";
            this.lblNetTotal.RequiredField = false;
            // 
            // txtTotalTax
            // 
            resources.ApplyResources(this.txtTotalTax, "txtTotalTax");
            this.txtTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalTax.ForeColor = System.Drawing.Color.Black;
            this.txtTotalTax.Format = "N2";
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.RequiredField = false;
            this.txtTotalTax.UseCompatibleTextRendering = true;
            this.txtTotalTax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator1
            // 
            resources.ApplyResources(this.btnSeperator1, "btnSeperator1");
            this.btnSeperator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator1.Name = "btnSeperator1";
            this.btnSeperator1.UseVisualStyleBackColor = true;
            // 
            // lblAdditionalBeds
            // 
            resources.ApplyResources(this.lblAdditionalBeds, "lblAdditionalBeds");
            this.lblAdditionalBeds.Name = "lblAdditionalBeds";
            this.lblAdditionalBeds.RequiredField = false;
            // 
            // txtGuestVehicleName
            // 
            this.txtGuestVehicleName.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuestVehicleName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtGuestVehicleName, "txtGuestVehicleName");
            this.txtGuestVehicleName.Format = null;
            this.txtGuestVehicleName.isAllowNegative = false;
            this.txtGuestVehicleName.isAllowSpecialChar = false;
            this.txtGuestVehicleName.isNumbersOnly = false;
            this.txtGuestVehicleName.isNumeric = false;
            this.txtGuestVehicleName.isTouchable = false;
            this.txtGuestVehicleName.Name = "txtGuestVehicleName";
            this.txtGuestVehicleName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtGuestVehicleNo
            // 
            this.txtGuestVehicleNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuestVehicleNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtGuestVehicleNo, "txtGuestVehicleNo");
            this.txtGuestVehicleNo.Format = null;
            this.txtGuestVehicleNo.isAllowNegative = false;
            this.txtGuestVehicleNo.isAllowSpecialChar = false;
            this.txtGuestVehicleNo.isNumbersOnly = false;
            this.txtGuestVehicleNo.isNumeric = false;
            this.txtGuestVehicleNo.isTouchable = false;
            this.txtGuestVehicleNo.Name = "txtGuestVehicleNo";
            this.txtGuestVehicleNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblGuestVehicleName
            // 
            resources.ApplyResources(this.lblGuestVehicleName, "lblGuestVehicleName");
            this.lblGuestVehicleName.Name = "lblGuestVehicleName";
            this.lblGuestVehicleName.RequiredField = false;
            // 
            // lblGuestVehicleType
            // 
            resources.ApplyResources(this.lblGuestVehicleType, "lblGuestVehicleType");
            this.lblGuestVehicleType.Name = "lblGuestVehicleType";
            this.lblGuestVehicleType.RequiredField = false;
            // 
            // lblGuestVehicleNo
            // 
            resources.ApplyResources(this.lblGuestVehicleNo, "lblGuestVehicleNo");
            this.lblGuestVehicleNo.Name = "lblGuestVehicleNo";
            this.lblGuestVehicleNo.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblExternal);
            this.pnlMain.Controls.Add(this.txtExternalAmt);
            this.pnlMain.Controls.Add(this.lblCurrencyCap);
            this.pnlMain.Controls.Add(this.lblExRateCap);
            this.pnlMain.Controls.Add(this.txtRoomTotal);
            this.pnlMain.Controls.Add(this.btnCheckOut);
            this.pnlMain.Controls.Add(this.btnSeperator1);
            this.pnlMain.Controls.Add(this.lblOpBalance);
            this.pnlMain.Controls.Add(this.txtOpBalance);
            this.pnlMain.Controls.Add(this.btnExtraServ);
            this.pnlMain.Controls.Add(this.lblPayment);
            this.pnlMain.Controls.Add(this.grpDiscountVoucher);
            this.pnlMain.Controls.Add(this.lblAddlBedAndPerson);
            this.pnlMain.Controls.Add(this.txtExtraBedAndPer);
            this.pnlMain.Controls.Add(this.txtExtraServices);
            this.pnlMain.Controls.Add(this.lblRoomRent);
            this.pnlMain.Controls.Add(this.lblTotalDisc);
            this.pnlMain.Controls.Add(this.txtTotalDiscount);
            this.pnlMain.Controls.Add(this.btnSeperator0);
            this.pnlMain.Controls.Add(this.txtRoomRent);
            this.pnlMain.Controls.Add(this.btnNewSource);
            this.pnlMain.Controls.Add(this.txtAddlPsnTotal);
            this.pnlMain.Controls.Add(this.lblGrossCap);
            this.pnlMain.Controls.Add(this.txtGross);
            this.pnlMain.Controls.Add(this.lblAddPersonRate);
            this.pnlMain.Controls.Add(this.lblTotalTax);
            this.pnlMain.Controls.Add(this.lblAdvance);
            this.pnlMain.Controls.Add(this.txtAdvance);
            this.pnlMain.Controls.Add(this.txtTotalTax);
            this.pnlMain.Controls.Add(this.lblAddPersons);
            this.pnlMain.Controls.Add(this.btnNewGuestType);
            this.pnlMain.Controls.Add(this.txtAddPersonRate);
            this.pnlMain.Controls.Add(this.lblMandatory8);
            this.pnlMain.Controls.Add(this.txtBalance);
            this.pnlMain.Controls.Add(this.txtAddPersons);
            this.pnlMain.Controls.Add(this.lblBalance);
            this.pnlMain.Controls.Add(this.txtPayment);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.txtDeductionPerc);
            this.pnlMain.Controls.Add(this.lblDeductionPerc);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.lblNetTotal);
            this.pnlMain.Controls.Add(this.lblDeductionAmount);
            this.pnlMain.Controls.Add(this.lblEmployee);
            this.pnlMain.Controls.Add(this.txtNetTotal);
            this.pnlMain.Controls.Add(this.cmbEmployee);
            this.pnlMain.Controls.Add(this.lblMandatory7);
            this.pnlMain.Controls.Add(this.lblAdditionalBedRate);
            this.pnlMain.Controls.Add(this.lblMandatory6);
            this.pnlMain.Controls.Add(this.lblGuestType);
            this.pnlMain.Controls.Add(this.cmbAgent);
            this.pnlMain.Controls.Add(this.cmbGuestVehicleType);
            this.pnlMain.Controls.Add(this.lblBooking);
            this.pnlMain.Controls.Add(this.lblAgent);
            this.pnlMain.Controls.Add(this.txtGuestVehicleName);
            this.pnlMain.Controls.Add(this.btnBooking);
            this.pnlMain.Controls.Add(this.cmbSource);
            this.pnlMain.Controls.Add(this.lblSource);
            this.pnlMain.Controls.Add(this.txtAddlBedTotal);
            this.pnlMain.Controls.Add(this.lblBillingAccountID);
            this.pnlMain.Controls.Add(this.lblGuestVehicleName);
            this.pnlMain.Controls.Add(this.lblAdditionalBeds);
            this.pnlMain.Controls.Add(this.btnNewGuest);
            this.pnlMain.Controls.Add(this.txtAddBedRate);
            this.pnlMain.Controls.Add(this.lblGuestVehicleType);
            this.pnlMain.Controls.Add(this.txtGuestVehicleNo);
            this.pnlMain.Controls.Add(this.txtAdditionalBeds);
            this.pnlMain.Controls.Add(this.cmbGuest);
            this.pnlMain.Controls.Add(this.cmbBillingAccount);
            this.pnlMain.Controls.Add(this.lblGuestVehicleNo);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.cmbGuestType);
            this.pnlMain.Controls.Add(this.txtAdult);
            this.pnlMain.Controls.Add(this.txtAdd1);
            this.pnlMain.Controls.Add(this.txtTelephone);
            this.pnlMain.Controls.Add(this.txtChild);
            this.pnlMain.Controls.Add(this.txtRate);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.txtMobile);
            this.pnlMain.Controls.Add(this.lblRate);
            this.pnlMain.Controls.Add(this.lblRateType);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Controls.Add(this.lblAddress1);
            this.pnlMain.Controls.Add(this.lblAdult);
            this.pnlMain.Controls.Add(this.lblTelephone);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblArrivalDate);
            this.pnlMain.Controls.Add(this.lblRoomType);
            this.pnlMain.Controls.Add(this.lblRoomOrHall);
            this.pnlMain.Controls.Add(this.lblDepartureDate);
            this.pnlMain.Controls.Add(this.txtNoOfDays);
            this.pnlMain.Controls.Add(this.lblNoOfDays);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblMandatory5);
            this.pnlMain.Controls.Add(this.lblMandatory9);
            this.pnlMain.Controls.Add(this.lblMandatory10);
            this.pnlMain.Controls.Add(this.lblCancelStatus);
            this.pnlMain.Controls.Add(this.lblMandatory11);
            this.pnlMain.Controls.Add(this.cmbCurrency);
            this.pnlMain.Controls.Add(this.txtExRate);
            this.pnlMain.Controls.Add(this.lblEqualToRateTotal);
            this.pnlMain.Controls.Add(this.lblAddlPsnTotal);
            this.pnlMain.Controls.Add(this.lblAddlBedTotal);
            this.pnlMain.Controls.Add(this.cmbBooking);
            this.pnlMain.Controls.Add(this.lblChild);
            this.pnlMain.Controls.Add(this.cmbRateType);
            this.pnlMain.Controls.Add(this.cmbRoomType);
            this.pnlMain.Controls.Add(this.cmbRoom);
            this.pnlMain.Controls.Add(this.dtpArrivalDate);
            this.pnlMain.Controls.Add(this.cmbRoomOrHall);
            this.pnlMain.Controls.Add(this.dtpDepartureDate);
            this.pnlMain.Controls.Add(this.txtDeductionAmount);
            this.pnlMain.Name = "pnlMain";
            // 
            // lblExternal
            // 
            resources.ApplyResources(this.lblExternal, "lblExternal");
            this.lblExternal.DataSource = null;
            this.lblExternal.Format = null;
            this.errProvider.SetIconAlignment(this.lblExternal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExternal.IconAlignment"))));
            this.lblExternal.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblExternal.LinkColor = System.Drawing.SystemColors.ControlText;
            this.lblExternal.Name = "lblExternal";
            this.lblExternal.TabStop = true;
            // 
            // txtExternalAmt
            // 
            resources.ApplyResources(this.txtExternalAmt, "txtExternalAmt");
            this.txtExternalAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExternalAmt.ForeColor = System.Drawing.Color.Black;
            this.txtExternalAmt.Format = "N2";
            this.txtExternalAmt.Name = "txtExternalAmt";
            this.txtExternalAmt.RequiredField = false;
            this.txtExternalAmt.UseCompatibleTextRendering = true;
            this.txtExternalAmt.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblCurrencyCap
            // 
            resources.ApplyResources(this.lblCurrencyCap, "lblCurrencyCap");
            this.lblCurrencyCap.Name = "lblCurrencyCap";
            this.lblCurrencyCap.RequiredField = false;
            // 
            // lblExRateCap
            // 
            resources.ApplyResources(this.lblExRateCap, "lblExRateCap");
            this.lblExRateCap.Name = "lblExRateCap";
            this.lblExRateCap.RequiredField = false;
            // 
            // txtRoomTotal
            // 
            resources.ApplyResources(this.txtRoomTotal, "txtRoomTotal");
            this.txtRoomTotal.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoomTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoomTotal.Format = null;
            this.txtRoomTotal.isAllowNegative = false;
            this.txtRoomTotal.isAllowSpecialChar = false;
            this.txtRoomTotal.isNumbersOnly = false;
            this.txtRoomTotal.isNumeric = true;
            this.txtRoomTotal.isTouchable = true;
            this.txtRoomTotal.Name = "txtRoomTotal";
            this.txtRoomTotal.ReadOnly = true;
            this.txtRoomTotal.TabStop = false;
            this.txtRoomTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnCheckOut
            // 
            resources.ApplyResources(this.btnCheckOut, "btnCheckOut");
            this.btnCheckOut.FlatAppearance.BorderSize = 0;
            this.btnCheckOut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            this.btnCheckOut.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // lblPayment
            // 
            resources.ApplyResources(this.lblPayment, "lblPayment");
            this.errProvider.SetIconAlignment(this.lblPayment, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblPayment.IconAlignment"))));
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.RequiredField = false;
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 2;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = true;
            // 
            // btnNewSource
            // 
            this.btnNewSource.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewSource.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewSource, "btnNewSource");
            this.btnNewSource.ForeColor = System.Drawing.Color.White;
            this.btnNewSource.Name = "btnNewSource";
            this.btnNewSource.TabStop = false;
            this.btnNewSource.Tag = "";
            this.btnNewSource.UseVisualStyleBackColor = false;
            this.btnNewSource.Click += new System.EventHandler(this.btnNewSource_Click);
            // 
            // txtAddlPsnTotal
            // 
            resources.ApplyResources(this.txtAddlPsnTotal, "txtAddlPsnTotal");
            this.txtAddlPsnTotal.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddlPsnTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddlPsnTotal.Format = null;
            this.txtAddlPsnTotal.isAllowNegative = false;
            this.txtAddlPsnTotal.isAllowSpecialChar = false;
            this.txtAddlPsnTotal.isNumbersOnly = false;
            this.txtAddlPsnTotal.isNumeric = true;
            this.txtAddlPsnTotal.isTouchable = true;
            this.txtAddlPsnTotal.Name = "txtAddlPsnTotal";
            this.txtAddlPsnTotal.ReadOnly = true;
            this.txtAddlPsnTotal.TabStop = false;
            this.txtAddlPsnTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnNewGuestType
            // 
            this.btnNewGuestType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewGuestType.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewGuestType, "btnNewGuestType");
            this.btnNewGuestType.ForeColor = System.Drawing.Color.White;
            this.btnNewGuestType.Name = "btnNewGuestType";
            this.btnNewGuestType.TabStop = false;
            this.btnNewGuestType.Tag = "";
            this.btnNewGuestType.UseVisualStyleBackColor = false;
            this.btnNewGuestType.Click += new System.EventHandler(this.btnNewGuestType_Click);
            // 
            // lblMandatory8
            // 
            resources.ApplyResources(this.lblMandatory8, "lblMandatory8");
            this.lblMandatory8.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory8.Name = "lblMandatory8";
            // 
            // lblMandatory7
            // 
            resources.ApplyResources(this.lblMandatory7, "lblMandatory7");
            this.lblMandatory7.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory7.Name = "lblMandatory7";
            // 
            // lblMandatory6
            // 
            resources.ApplyResources(this.lblMandatory6, "lblMandatory6");
            this.lblMandatory6.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory6.Name = "lblMandatory6";
            // 
            // cmbGuestVehicleType
            // 
            this.cmbGuestVehicleType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuestVehicleType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuestVehicleType.DropDownHeight = 300;
            resources.ApplyResources(this.cmbGuestVehicleType, "cmbGuestVehicleType");
            this.cmbGuestVehicleType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuestVehicleType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuestVehicleType.IconAlignment"))));
            this.cmbGuestVehicleType.Name = "cmbGuestVehicleType";
            // 
            // btnBooking
            // 
            resources.ApplyResources(this.btnBooking, "btnBooking");
            this.btnBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnBooking.FlatAppearance.BorderSize = 0;
            this.btnBooking.ForeColor = System.Drawing.Color.White;
            this.btnBooking.Name = "btnBooking";
            this.btnBooking.TabStop = false;
            this.btnBooking.Tag = "";
            this.btnBooking.UseVisualStyleBackColor = false;
            this.btnBooking.Click += new System.EventHandler(this.btnBooking_Click);
            // 
            // txtAddlBedTotal
            // 
            resources.ApplyResources(this.txtAddlBedTotal, "txtAddlBedTotal");
            this.txtAddlBedTotal.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddlBedTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddlBedTotal.Format = null;
            this.txtAddlBedTotal.isAllowNegative = false;
            this.txtAddlBedTotal.isAllowSpecialChar = false;
            this.txtAddlBedTotal.isNumbersOnly = false;
            this.txtAddlBedTotal.isNumeric = true;
            this.txtAddlBedTotal.isTouchable = true;
            this.txtAddlBedTotal.Name = "txtAddlBedTotal";
            this.txtAddlBedTotal.ReadOnly = true;
            this.txtAddlBedTotal.TabStop = false;
            this.txtAddlBedTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnNewGuest
            // 
            this.btnNewGuest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewGuest.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewGuest, "btnNewGuest");
            this.btnNewGuest.ForeColor = System.Drawing.Color.White;
            this.btnNewGuest.Name = "btnNewGuest";
            this.btnNewGuest.TabStop = false;
            this.btnNewGuest.Tag = "";
            this.btnNewGuest.UseVisualStyleBackColor = false;
            this.btnNewGuest.Click += new System.EventHandler(this.btnNewGuest_Click);
            // 
            // txtAdd1
            // 
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.Format = null;
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.TabStop = false;
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtTelephone
            // 
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.Format = null;
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = false;
            this.txtTelephone.isNumeric = true;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.TabStop = false;
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // txtMobile
            // 
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.Format = null;
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = false;
            this.txtMobile.isNumeric = true;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.TabStop = false;
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // lblTelephone
            // 
            resources.ApplyResources(this.lblTelephone, "lblTelephone");
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblMandatory5
            // 
            resources.ApplyResources(this.lblMandatory5, "lblMandatory5");
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory5.Name = "lblMandatory5";
            // 
            // lblMandatory9
            // 
            resources.ApplyResources(this.lblMandatory9, "lblMandatory9");
            this.lblMandatory9.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory9.Name = "lblMandatory9";
            // 
            // lblMandatory10
            // 
            resources.ApplyResources(this.lblMandatory10, "lblMandatory10");
            this.lblMandatory10.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory10.Name = "lblMandatory10";
            // 
            // lblCancelStatus
            // 
            resources.ApplyResources(this.lblCancelStatus, "lblCancelStatus");
            this.lblCancelStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblCancelStatus.ForeColor = System.Drawing.Color.Crimson;
            this.lblCancelStatus.Name = "lblCancelStatus";
            // 
            // lblMandatory11
            // 
            resources.ApplyResources(this.lblMandatory11, "lblMandatory11");
            this.lblMandatory11.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory11.Name = "lblMandatory11";
            // 
            // cmbCurrency
            // 
            this.cmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCurrency.DropDownHeight = 300;
            this.cmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbCurrency, "cmbCurrency");
            this.cmbCurrency.FormattingEnabled = true;
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency_SelectedIndexChanged);
            // 
            // txtExRate
            // 
            this.txtExRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtExRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtExRate, "txtExRate");
            this.txtExRate.Format = null;
            this.txtExRate.isAllowNegative = false;
            this.txtExRate.isAllowSpecialChar = false;
            this.txtExRate.isNumbersOnly = false;
            this.txtExRate.isNumeric = true;
            this.txtExRate.isTouchable = false;
            this.txtExRate.Name = "txtExRate";
            this.txtExRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtExRate.Enter += new System.EventHandler(this.txtExRate_Enter);
            this.txtExRate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtExRate_KeyUp);
            // 
            // lblEqualToRateTotal
            // 
            resources.ApplyResources(this.lblEqualToRateTotal, "lblEqualToRateTotal");
            this.lblEqualToRateTotal.Name = "lblEqualToRateTotal";
            this.lblEqualToRateTotal.RequiredField = false;
            // 
            // lblAddlPsnTotal
            // 
            resources.ApplyResources(this.lblAddlPsnTotal, "lblAddlPsnTotal");
            this.lblAddlPsnTotal.Name = "lblAddlPsnTotal";
            this.lblAddlPsnTotal.RequiredField = false;
            // 
            // lblAddlBedTotal
            // 
            resources.ApplyResources(this.lblAddlBedTotal, "lblAddlBedTotal");
            this.lblAddlBedTotal.Name = "lblAddlBedTotal";
            this.lblAddlBedTotal.RequiredField = false;
            // 
            // cmbRoom
            // 
            resources.ApplyResources(this.cmbRoom, "cmbRoom");
            this.cmbRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoom.DropDownHeight = 300;
            this.cmbRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoom.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoom.IconAlignment"))));
            this.cmbRoom.Name = "cmbRoom";
            // 
            // lblGrandTotal
            // 
            resources.ApplyResources(this.lblGrandTotal, "lblGrandTotal");
            this.lblGrandTotal.BackColor = System.Drawing.SystemColors.Window;
            this.lblGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGrandTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.lblGrandTotal.Format = "N2";
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.RequiredField = false;
            this.lblGrandTotal.UseCompatibleTextRendering = true;
            this.lblGrandTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atlblTot
            // 
            resources.ApplyResources(this.atlblTot, "atlblTot");
            this.atlblTot.BackColor = System.Drawing.Color.Transparent;
            this.atlblTot.Name = "atlblTot";
            this.atlblTot.RequiredField = false;
            // 
            // CheckInView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "CheckInView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.CheckInView_atSaveClick);
            this.atBeforeInitialise += new atACCFramework.BaseClasses.BeforeInitialiseEventHandler(this.CheckInView_atBeforeInitialise);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.CheckInView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.CheckInView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.CheckInView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.CheckInView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.CheckInView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.CheckInView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.CheckInView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.CheckInView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.CheckInView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.CheckInView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.CheckInView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.CheckInView_atBeforeSearch);
            this.Shown += new System.EventHandler(this.CheckInView_Shown);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.grpDiscountVoucher.ResumeLayout(false);
            this.grpDiscountVoucher.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private System.Windows.Forms.Label lblMandatory3;
        private atACCFramework.UserControls.TextBoxExt txtNoOfDays;
        private atACCFramework.UserControls.atLabel lblNoOfDays;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.ComboBoxExt cmbGuest;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.ComboBoxExt cmbBooking;
        private atACCFramework.UserControls.atLabel lblBooking;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomOrHall;
        private atACCFramework.UserControls.atLabel lblRoomOrHall;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.TextBoxExt txtChild;
        private atACCFramework.UserControls.atLabel lblGuestType;
        private atACCFramework.UserControls.ComboBoxExt cmbGuestType;
        private atACCFramework.UserControls.atLabel lblSource;
        private atACCFramework.UserControls.ComboBoxExt cmbSource;
        private atACCFramework.UserControls.atLabel lblChild;
        private atACCFramework.UserControls.TextBoxExt txtAdult;
        private atACCFramework.UserControls.atLabel lblAdult;
        private atACCFramework.UserControls.TextBoxExt txtRate;
        private atACCFramework.UserControls.atLabel lblRate;
        private atACCFramework.UserControls.ComboBoxExt cmbRateType;
        private atACCFramework.UserControls.atLabel lblRateType;
        private atACCFramework.UserControls.ComboBoxExt cmbAgent;
        private atACCFramework.UserControls.atLabel lblAgent;
        private atACCFramework.UserControls.TextBoxExt txtAddPersonRate;
        private atACCFramework.UserControls.atLabel lblAddPersonRate;
        private atACCFramework.UserControls.TextBoxExt txtAddPersons;
        private atACCFramework.UserControls.atLabel lblAddPersons;
        private atACCFramework.UserControls.TextBoxExt txtAddBedRate;
        private atACCFramework.UserControls.atLabel lblAdditionalBedRate;
        private atACCFramework.UserControls.TextBoxExt txtAdditionalBeds;
        private atACCFramework.UserControls.TextBoxExt txtDeductionAmount;
        private atACCFramework.UserControls.atLabel lblDeductionAmount;
        private atACCFramework.UserControls.TextBoxExt txtDeductionPerc;
        private atACCFramework.UserControls.atLabel lblDeductionPerc;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.atNumericLabel txtTotalDiscount;
        private atACCFramework.UserControls.atLabel lblTotalDisc;
        private atACCFramework.UserControls.TaxLabel lblTotalTax;
        private atACCFramework.UserControls.atButton btnPayment;
        private atACCFramework.UserControls.TextBoxNormal txtBalance;
        private atACCFramework.UserControls.atNumericLabel txtPayment;
        private atACCFramework.UserControls.atLabel lblBalance;
        private atACCFramework.UserControls.atNumericLabel txtNetTotal;
        private atACCFramework.UserControls.atLabel lblNetTotal;
        private atACCFramework.UserControls.atNumericLabel txtTotalTax;
        private System.Windows.Forms.Button btnSeperator1;
        private atACCFramework.UserControls.TextBoxExt txtVoucherDiscountAmount;
        private atACCFramework.UserControls.atLabel lblVoucherDiscountAmount;
        private atACCFramework.UserControls.atLabel lblVoucherDiscountAccount;
        private atACCFramework.UserControls.ComboBoxExt cmbVoucherDiscount;
        private atACCFramework.UserControls.atNumericLabel txtExtraServices;
        private atACCFramework.UserControls.atNumericLabel txtOpBalance;
        private AccountLabel lblOpBalance;
        private atACCFramework.UserControls.atLabel lblBillingAccountID;
        private atACCFramework.UserControls.ComboBoxExt cmbBillingAccount;
        private atACCFramework.UserControls.atLabel lblGuestVehicleNo;
        private atACCFramework.UserControls.atLabel lblGuestVehicleType;
        private atACCFramework.UserControls.atLabel lblGuestVehicleName;
        private atACCFramework.UserControls.TextBoxExt txtGuestVehicleName;
        private atACCFramework.UserControls.TextBoxExt txtGuestVehicleNo;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.ComboBoxExt cmbRoom;
        private atACCFramework.UserControls.atNumericLabel txtAdvance;
        private atACCFramework.UserControls.atLabel lblAdvance;
        private atACCFramework.UserControls.atGroupBox grpDiscountVoucher;
        private atACCFramework.UserControls.atNumericLabel lblGrandTotal;
        private atACCFramework.UserControls.atLabel atlblTot;
        private atACCFramework.UserControls.atNumericLabel txtGross;
        private atACCFramework.UserControls.atLabel lblGrossCap;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.atButton btnNewGuest;
        private atACCFramework.UserControls.ComboBoxExt cmbGuestVehicleType;
        private atACCFramework.UserControls.atLabel lblAdditionalBeds;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.atLabel lblAddlPsnTotal;
        private atACCFramework.UserControls.atLabel lblAddlBedTotal;
        private atACCFramework.UserControls.TextBoxExt txtAddlPsnTotal;
        private atACCFramework.UserControls.TextBoxExt txtAddlBedTotal;
        private atACCFramework.UserControls.atNumericLabel txtExtraBedAndPer;
        private atACCFramework.UserControls.atLabel lblAddlBedAndPerson;
        private atACCFramework.UserControls.atNumericLabel txtRoomRent;
        private atACCFramework.UserControls.atLabel lblRoomRent;
        private System.Windows.Forms.Label lblMandatory8;
        private System.Windows.Forms.Label lblMandatory9;
        private System.Windows.Forms.Label lblMandatory4;
        private System.Windows.Forms.Label lblMandatory6;
        private System.Windows.Forms.Label lblMandatory7;
        private System.Windows.Forms.Label lblMandatory5;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atButton btnBooking;
        private atACCFramework.UserControls.atButton btnNewSource;
        private atACCFramework.UserControls.atButton btnExtraServ;
        private atACCFramework.UserControls.atButton btnNewGuestType;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel lblPayment;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Label lblCancelStatus;
        private atACCFramework.UserControls.atLabel lblEqualToRateTotal;
        private atACCFramework.UserControls.TextBoxExt txtRoomTotal;
        private System.Windows.Forms.Label lblMandatory10;
        private atACCFramework.UserControls.atLabel lblCurrencyCap;
        private atACCFramework.UserControls.TextBoxExt txtExRate;
        private atACCFramework.UserControls.ComboBoxExt cmbCurrency;
        private atACCFramework.UserControls.atLabel lblExRateCap;
        private System.Windows.Forms.Label lblMandatory11;
        private AccountLabel lblExternal;
        private atACCFramework.UserControls.atNumericLabel txtExternalAmt;
    }
}