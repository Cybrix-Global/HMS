﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using atACCFramework.UserControls;
using System.IO;
using System.Net.Mail;
using System.Drawing;
using atACC.HTL.Transactions.Sub_Forms;
using atACCFramework;

namespace atACC.HTL.Transactions
{
    public partial class GroupCheckOutView : SearchFormBase2
    {
        #region Private Variable
        GroupCheckOut entGrpCheckOut;
        List<GroupCheckOut> entGrpCheckOutList;
        List<GroupCheckOutExtraServiceDTL> entOldGrpCheckOutDTLList;
        List<GroupCheckOutExtraServiceDTL> entGrpCheckOutDTLList;
        List<GroupCheckOutPayment> entGrpCheckOutPaymentList;
        List<GroupCheckOutPayment> entOldGrpCheckOutPaymentList;
        List<GroupCheckOutRefund> entGrpCheckOutRefundList;
        List<GroupCheckOutRefund> entOldGrpCheckOutRefundList;
        GroupCheckIn entGrpCheckIn;
        GroupCheckInDTL entGrpCheckInDTL;
        List<GroupCheckInDTL> entGrpCheckInDTLList;
        GroupCheckInPayment entCheckInPayment;
        List<GroupCheckInPayment> entCheckInPaymentlist;
        List<Rooms> entRooms;
        GuestDTLs e_GuestDTLs;
        Guests entGuest;
        List<Employee> entEmployees;
        List<Guests> entGuestlist;
        GroupBooking entBookings;
        List<GroupBooking> entBookingslist;
        GroupBookingPayment entBookingPayments;
        List<GroupBookingPayment> entBookingPaymentlist;
        atACC.HTL.ORM.AccountLedger Ledger;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;

        CommonLibClasses objLib;
        ToolTip tooltip;
        List<Employee> entEmployee;
        List<atACC.HTL.ORM.AccountLedger> entGuestAccounts;
        DataGridViewTextBoxEditingControl textbox;
        DataGridViewComboBoxEditingControl cb;
        string sKeyChar = "";
        string NumberFormat, sQtyFormat;
        int  _OnLoad, iRoomId, Guestid, iBookingId;
        int _GroupCheckInId;
        decimal TotalAmount, AdvanceAmount, dCheckInPayment, dBookingPayment, DeductionPerc;
        VoucherHDR entVoucherHdrPayment;
        VoucherHDR entVoucherHdrRefund;
        VoucherHDR entVoucherHdr;
        decimal previousExRate;
        List<CurrencyClass> entCurrencys;
        bool blnSanctioningRequired = false;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;
        #endregion

        #region Constructor
        public GroupCheckOutView(int iGroupCheckInId)
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            objLib = new CommonLibClasses();
            aniHelper = new ANIHelper();
            this._GroupCheckInId = iGroupCheckInId;
            ShareButton.Visible = false;

            ToolStripMenuItem mnuSendEmail = new ToolStripMenuItem();
            mnuSendEmail.BackColor = Color.White;
            mnuSendEmail.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendEmail.Text = MessageKeys.MsgSendEmail;
            mnuSendEmail.Image = Properties.Resources.Mail;
            mnuSendEmail.Click += new EventHandler(mnuSendEmail_Click);
            ShareMenu.Items.Add(mnuSendEmail);

            ToolStripMenuItem mnuSendSMS = new ToolStripMenuItem();
            mnuSendSMS.BackColor = Color.White;
            mnuSendSMS.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendSMS.Text = MessageKeys.MsgSendSMS;
            mnuSendSMS.Image = Properties.Resources.SMS;
            mnuSendSMS.Click += new EventHandler(mnuSendSMS_Click);
            ShareMenu.Items.Add(mnuSendSMS);
        }
        public GroupCheckOutView() : this(0) { }
        #endregion Constructor

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(6);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Share Methods
        void mnuSendEmail_Click(object sender, EventArgs e)
        {
            SendEmail();
        }
        void mnuSendSMS_Click(object sender, EventArgs e)
        {
            SendSMS();
        }
        private void SendEmail()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (txtGuest.Text == "")
                {
                    errProvider.SetError(txtGuest, MessageKeys.MsgGuestMustBeChosen);
                    this.Cursor = Cursors.Arrow;
                    return;
                }
                if (entGrpCheckOut != null && entGrpCheckOut.id != null && entGrpCheckOut.id != 0) 
                {
                    string sTo = "";
                    int iGuestID = txtGuest.Tag.ToInt32();
                    GuestDTLs _GuDtl = dbh.GuestDTLs.Where(x => x.FK_GuestID == iGuestID).SingleOrDefault();

                    if (_GuDtl != null)
                    {
                        sTo = _GuDtl.Email;
                    }
                    if (sTo.Trim() == "")
                    {
                        MessageBox.Show(MessageKeys.MsgEmailAddressOfGuestMustBeSet);
                        this.Cursor = Cursors.Arrow;
                        return;
                    }
                    string sExportPath = Application.StartupPath + "\\Temp\\Sales_" + txtVoucherNo.Text + ".pdf";
                    string sBody = "";
                    MailHelper _mailHelper = new MailHelper();
                    _mailHelper.sTo = sTo;
                    MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "Email").SingleOrDefault();
                    sBody = _Message.GroupCheckOut;
                    sBody = sBody.Replace("@VoucherNo", txtVoucherNo.Text)
                    .Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString())
                    .Replace("@GuestName@", txtGuest.Text)
                    .Replace("@RoomType@", "")
                    .Replace("@Room@", "")
                    .Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString())
                    .Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString())
                    .Replace("@NoofDays@", txtNoOfDays.Text)
                    .Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat))
                    .Replace("@Payment@", txtPayment.Value.ToString(NumberFormat))
                    .Replace("@Refund@", "")
                    .Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));

                    _mailHelper.sSubject = MessageKeys.MsgGroupCheckOutVoucherNo + " : " + txtVoucherNo.Text;
                    _mailHelper.sBody = sBody;
                    if (GlobalFunctions.blnConfirmationForEmail)
                    {
                        EmailConfirmationView emailConfirm = new EmailConfirmationView(_mailHelper.sSubject, _mailHelper.sBody);
                        if (emailConfirm.ShowDialog() == DialogResult.OK)
                        {
                            _mailHelper.sSubject = emailConfirm.sSubject;
                            _mailHelper.sBody = emailConfirm.sBody;
                        }
                        this.Cursor = Cursors.WaitCursor;
                    }
                    if (entGrpCheckOut.id != 0)
                    {
                        if (File.Exists(sExportPath))
                        {
                            File.Delete(sExportPath);
                        }
                        PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                        printInvoice.PrintOut("Hotel Group Check Out", entGrpCheckOut.id, 0, true, sExportPath);
                        if (File.Exists(sExportPath))
                        {
                            _mailHelper.entAttachments.Add(new Attachment(sExportPath));
                        }
                    }
                    _mailHelper.SendEmail();
                    if (File.Exists(sExportPath))
                    {
                        File.Delete(sExportPath);
                    }
                    atMessageBox.Show(MessageKeys.MsgMailSendSuccessfully);
                }
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
                this.Cursor = Cursors.Arrow;
            }
        }
        private bool SendSMS()
        {
            if (txtGuest.Text == "")
            {
                errProvider.SetError(txtGuest, MessageKeys.MsgGuestMustBeChosen);
                return false;
            }
            if (entGrpCheckOut == null || entGrpCheckOut.id == null || entGrpCheckOut.id != 0)
            {
                atMessageBox.Show(MessageKeys.MsgRecordNotFound);
                return false;
            }
            int iGuestID = txtGuest.Tag.ToInt32();
            try
            {
                if (txtGuest.Text.Trim() == "") { return false; }
                if (txtMobile.Text.Trim() == "") { return false; }
                MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "SMS").SingleOrDefault();
                string sMessage = _Message.GroupCheckOut;
                sMessage = sMessage.Replace("@VoucherNo", txtVoucherNo.Text);
                sMessage = sMessage.Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@GuestName@", txtGuest.Text);
                sMessage = sMessage.Replace("@RoomType@", "");
                sMessage = sMessage.Replace("@Room@", "");
                sMessage = sMessage.Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@NoofDays@", txtNoOfDays.Text);
                sMessage = sMessage.Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Payment@", txtPayment.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Refund@", "");
                sMessage = sMessage.Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));
                string sResult = SMSHelper.SendSMSBash(txtMobile.Text.Trim(), sMessage);
                MessageBox.Show("SMS : " + sResult);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion

        #region Private Methods
        private void InitControls()
        {
            dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
            dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();

            dtpArrivalDate.SetCustomFormat();
            dtpDepartureDate.SetCustomFormat();
            dtpArrivalDate.DisbaleShortDateTimeFormat = true;
            dtpDepartureDate.DisbaleShortDateTimeFormat = true;
        }
        private void SetDefaultComboValues()
        {
            ActiveControl = cmbCurrency;
            cmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;
        }
        private void ApplyExRate()
        {
            decimal dcCurrentExRate = txtExRate.Value;
            decimal dcExRateChange = ((previousExRate == 0 ? 1 : previousExRate) / (dcCurrentExRate == 0 ? 1 : dcCurrentExRate));
            foreach (GroupCheckOutExtraServiceDTL serviceDtl in entGrpCheckOutDTLList)
            {
                if (serviceDtl.FK_ExtraServiceID != null)
                {
                    serviceDtl.Rate = dcExRateChange * serviceDtl.Rate;
                    serviceDtl.InclusiveRate = dcExRateChange * serviceDtl.InclusiveRate;
                    serviceDtl.Amount = dcExRateChange * serviceDtl.Amount;                    
                    serviceDtl.TaxableAmount = dcExRateChange * serviceDtl.TaxableAmount;
                    serviceDtl.SlabDiscount = dcExRateChange * serviceDtl.SlabDiscount;
                    serviceDtl.DeductionAmount = dcExRateChange * serviceDtl.DeductionAmount;
                    serviceDtl.ExciseAmount = dcExRateChange * serviceDtl.ExciseAmount;
                    serviceDtl.Tax1Amount = dcExRateChange * serviceDtl.Tax1Amount;
                    serviceDtl.Tax2Amount = dcExRateChange * serviceDtl.Tax2Amount;
                    serviceDtl.Tax3Amount = dcExRateChange * serviceDtl.Tax3Amount;
                    serviceDtl.AddnlTaxAmount = dcExRateChange * serviceDtl.AddnlTaxAmount;
                    serviceDtl.VATAmount = dcExRateChange * serviceDtl.VATAmount;
                    serviceDtl.CGSTAmount = dcExRateChange * serviceDtl.CGSTAmount;
                    serviceDtl.SGSTAmount = dcExRateChange * serviceDtl.SGSTAmount;
                    serviceDtl.IGSTAmount = dcExRateChange * serviceDtl.IGSTAmount;
                    serviceDtl.NetAmount = dcExRateChange * serviceDtl.NetAmount;
                }
            }

            foreach (GroupCheckOutPayment payment in entGrpCheckOutPaymentList)
            {
                payment.Payment = dcExRateChange * payment.Payment;
            }
            foreach (GroupCheckOutRefund payment in entGrpCheckOutRefundList)
            {
                payment.Refund = dcExRateChange * payment.Refund;
            }
            CalcOpeningAndExternalAmt();
            CalcNetTotal();
            previousExRate = txtExRate.Value;
        }
        private void PostVoucher()
        {
            bool blnNewRecord = true;
            bool blnNewPaymentRecord = true;
            bool blnNewRefundRecord = true;
            entVoucherHdrPayment = new VoucherHDR();
            entVoucherHdrRefund = new VoucherHDR();
            entVoucherHdr = new VoucherHDR();
            if (!NewRecord)
            {
                if ((entGrpCheckOut.FK_VoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdr = dbh.VoucherHDRs.Where(x => x.id == entGrpCheckOut.FK_VoucherHDRID).SingleOrDefault();
                    blnNewRecord = false;
                }
                if ((entGrpCheckOut.FK_PaymentVoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdrPayment = dbh.VoucherHDRs.Where(x => x.id == entGrpCheckOut.FK_PaymentVoucherHDRID).SingleOrDefault();
                    blnNewPaymentRecord = false;
                }
                if ((entGrpCheckOut.FK_RefundVoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdrRefund = dbh.VoucherHDRs.Where(x => x.id == entGrpCheckOut.FK_RefundVoucherHDRID).SingleOrDefault();
                    blnNewRefundRecord = false;
                }
            }

            int iCashorPartyAccountID = entGrpCheckIn.FK_BillingAccountID.ToInt32();
            bool blnPartyUnderCashInHand = aniHelper.isUnderCashInHand(iCashorPartyAccountID);
            string sCashorPartyName = aniHelper.getLedNameFromAccountID(iCashorPartyAccountID);
            string sRentAccountName = aniHelper.getLedNameFromAccountID(GlobalProperties.RentAccountID);

            decimal dcmGrandTotal = txtNetTotal.Value;
            decimal dcExRate = txtExRate.Value;
            decimal dcmOtherPaymentSum = entGrpCheckOutPaymentList.Where(x => x.isCash == false).Sum(x => x.Payment).ToDecimal();
            decimal dcmPartyAmount = blnPartyUnderCashInHand ? dcmGrandTotal - dcmOtherPaymentSum : dcmGrandTotal;

            //Voucher Hdr Entry
            GlobalMethods.DecorateVoucherHdr(entVoucherHdr, iContextID, "", dtVoucherDate.Value
                , cmbCurrency.SelectedValue.ToString().ToInt32(), lblGrandTotal.Value, txtVoucherNo.Text, "H-CO");

            //Voucher DTL Entry
            List<VoucherDTL> entVoucherDtls = new List<VoucherDTL>();

            // Debit Bill Amount to Party or Cash Account
            GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, iCashorPartyAccountID, sRentAccountName, dcExRate, dcmPartyAmount, "", txtRemarks.Text);
            #region ExtraService Voucher DTL
            if (entGrpCheckOutDTLList.Count > 0)
            {
                decimal dcGross = entGrpCheckOutDTLList.Sum(x => x.Amount).ToDecimal();
                decimal dcDiscount = entGrpCheckOutDTLList.Sum(x => x.DeductionAmount + x.SlabDiscount).ToDecimal();
                decimal dcTax1 = entGrpCheckOutDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                decimal dcTax2 = entGrpCheckOutDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                decimal dcTax3 = entGrpCheckOutDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                decimal dcAddnlTax = entGrpCheckOutDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                decimal dcExciseDuty = entGrpCheckOutDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                decimal dcVAT = entGrpCheckOutDTLList.Sum(x => x.VATAmount).ToDecimal();
                decimal dcCGST = entGrpCheckOutDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                decimal dcSGST = entGrpCheckOutDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                decimal dcIGST = entGrpCheckOutDTLList.Sum(x => x.IGSTAmount).ToDecimal();

                //Credit Gross Amount to ExtraService Account
                if (dcGross != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExtraServicesAccountID, sCashorPartyName, dcExRate, dcGross * (-1), "", txtRemarks.Text);
                //Credit Tax1 
                if (dcTax1 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax1AccountID, sCashorPartyName, dcExRate, dcTax1 * (-1), "", txtRemarks.Text);
                //Credit Tax2
                if (dcTax2 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax2AccountID, sCashorPartyName, dcExRate, dcTax2 * (-1), "", txtRemarks.Text);
                //Credit Tax3
                if (dcTax3 != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.Tax3AccountID, sCashorPartyName, dcExRate, dcTax3 * (-1), "", txtRemarks.Text);
                //Credit Excise Duty
                if (dcExciseDuty != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.ExciseDutyAccountID, sCashorPartyName, dcExRate, dcExciseDuty * (-1), "", txtRemarks.Text);
                //Debit Total Discount 
                if (txtTotalDiscount.Value != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.DiscountAccountID, sCashorPartyName, dcExRate, txtTotalDiscount.Value, "", txtRemarks.Text);
                //Credit Vat
                if (dcVAT != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.VATAccountID, sCashorPartyName, dcExRate, dcVAT * (-1), "", txtRemarks.Text);
                //Credit CGST
                if (dcCGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.CGSTAccountID, sCashorPartyName, dcExRate, dcCGST * (-1), "", txtRemarks.Text);
                //Credit SGST
                if (dcSGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.SGSTAccountID, sCashorPartyName, dcExRate, dcSGST * (-1), "", txtRemarks.Text);
                //Credit IGST
                if (dcIGST != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.IGSTAccountID, sCashorPartyName, dcExRate, dcIGST * (-1), "", txtRemarks.Text);
                //Credit
                if (dcAddnlTax != 0)
                    GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.AdditionalTaxAccountID, sCashorPartyName, dcExRate, dcAddnlTax * (-1), "", txtRemarks.Text);
            }
            #endregion

            //RoundOff
            decimal dblRoundOff = txtAddnlRoundoff.Value;
            if (dblRoundOff != 0)
                GlobalMethods.AddVoucherDtl(entVoucherDtls, 0, GlobalProperties.RoundOffAccountID, sCashorPartyName, dcExRate, dblRoundOff, "", txtRemarks.Text);
            List<AnalysisDTL> entAnalysisDTLs = new List<AnalysisDTL>();
            GlobalMethods.PostVoucher(blnNewRecord, entVoucherHdr, entVoucherDtls, ref dbh, entAnalysisDTLs);




            #region Payment Posting

            List<VoucherDTL> entVoucherDtlsPayment = new List<VoucherDTL>();
            if (entGrpCheckOutPaymentList.Count() > 0) // Payment Found
            {
                if (entVoucherHdrPayment.id == 0)
                {
                    entVoucherHdrPayment.id = -1;
                }
                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdrPayment, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-GCO-PAY");

                foreach (GroupCheckOutPayment payment in entGrpCheckOutPaymentList)
                {
                    #region isCash
                    if (payment.isCash.toBool()) // Cash Payment
                    {
                        if (!blnPartyUnderCashInHand)
                        {
                            int iCashAccountID = payment.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)payment.FK_AccountID;
                            string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                            // Debit to Cash Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashAccountID, sCashorPartyName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            // Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", MessageKeys.MsgPayment);
                        }
                    }
                    #endregion
                    #region Non Cash
                    else
                    {
                        int iSelectedBankAccount = (int)payment.FK_AccountID;
                        string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                        if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                        {
                            string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);

                            // Debit to Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * -1, "", MessageKeys.MsgPayment);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                        {
                            string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);

                            //Debit to Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                            || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                        {
                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCashorPartyName, dcExRate, payment.Payment.ToDecimal(), "", MessageKeys.MsgPayment);
                            //Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", MessageKeys.MsgPayment);
                        }
                    }
                    #endregion
                }
                GlobalMethods.PostVoucher(blnNewPaymentRecord, entVoucherHdrPayment, entVoucherDtlsPayment, ref dbh, entAnalysisDTLs);
            }
            #endregion

            #region Refund Posting

            List<VoucherDTL> entVoucherDtlsRefund = new List<VoucherDTL>();
            if (entGrpCheckOutRefundList.Count() > 0) // Refund Found
            {
                if (entVoucherHdrRefund.id == 0)
                {
                    entVoucherHdrRefund.id = -1;
                }
                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdrRefund, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-GCO-REF");

                foreach (GroupCheckOutRefund refund in entGrpCheckOutRefundList)
                {
                    #region isCash
                    if (refund.isCash.toBool()) // Cash Refund
                    {
                        if (!blnPartyUnderCashInHand)
                        {
                            int iCashAccountID = refund.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)refund.FK_AccountID;
                            string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                            // Credit From Cash Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iCashAccountID, sCashorPartyName, dcExRate, refund.Refund.ToDecimal() * -1, "", "");
                            // Debit To Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iCashorPartyAccountID, sAccountName, dcExRate, refund.Refund.ToDecimal(), "", "");
                        }
                    }
                    #endregion
                    #region Non Cash
                    else
                    {
                        int iSelectedBankAccount = (int)refund.FK_AccountID;
                        string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                        if (refund.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                        {
                            string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);

                            // Credit from Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, (int)ENAccountLedgers.CreditCardReceived_16, sRentAccountName, dcExRate, refund.Refund.ToDecimal() * -1, "", "");
                            if (!blnPartyUnderCashInHand)
                            {
                                // Debit to Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, refund.Refund.ToDecimal(), "", "");
                            }

                            //Credit from Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, refund.Refund.ToDecimal() * -1, "", "");
                            //Debit to Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, refund.Refund.ToDecimal(), "", "");
                        }
                        else if (refund.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                        {
                            string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);

                            //Credit from Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, (int)ENAccountLedgers.ChequesReceived_15, sRentAccountName, dcExRate, refund.Refund.ToDecimal() * -1, "", "");
                            if (!blnPartyUnderCashInHand)
                            {
                                // Debit to Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, refund.Refund.ToDecimal(), "", "");
                            }

                            //Credit from Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, refund.Refund.ToDecimal() * -1, "", "");
                            //Debit to Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, refund.Refund.ToDecimal(), "", "");
                        }
                        else if (refund.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                            || refund.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || refund.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                        {
                            //Credit from Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iSelectedBankAccount, sCashorPartyName, dcExRate, refund.Refund.ToDecimal() * -1, "", "");
                            //Debit to Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsRefund, -1, iCashorPartyAccountID, sBankName, dcExRate, refund.Refund.ToDecimal(), "", "");
                        }
                    }
                    #endregion
                }
                GlobalMethods.PostVoucher(blnNewRefundRecord, entVoucherHdrRefund, entVoucherDtlsRefund, ref dbh, entAnalysisDTLs);
            }
            #endregion

        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_GroupCheckOut, 0, 0, txtVoucherNo.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateGroupCheckOut()
        {
            entGrpCheckOutList = dbh.GroupCheckOuts.ToList();
        }
        private void PopulateGroupCombos()
        {
            try
            {
                #region Employee
                entEmployees = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).Where(x => x.Status == 1).ToList();
                cmbEmployee.DataSource = entEmployees;
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }
                #endregion

                cmbGrpCheckIn.DataSource = dbh.GroupCheckIns.ToList();
                cmbGrpCheckIn.DisplayMember = "VoucherNo";
                cmbGrpCheckIn.ValueMember = "id";
                cmbGrpCheckIn.SelectedIndex = -1;

                #region Currency                
                cmbCurrency.DataSource = entCurrencys;
                cmbCurrency.DisplayMember = "CurrencyName";
                cmbCurrency.ValueMember = "id";
                #endregion

                LoadRooms();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void FnClearAll()
        {
            entGrpCheckOut = new GroupCheckOut();
            entGrpCheckOutDTLList = new List<GroupCheckOutExtraServiceDTL>();
            entOldGrpCheckOutDTLList = new List<GroupCheckOutExtraServiceDTL>(entGrpCheckOutDTLList);

            entGrpCheckOutPaymentList = new List<GroupCheckOutPayment>();
            entOldGrpCheckOutPaymentList = new List<GroupCheckOutPayment>();

            entGrpCheckOutRefundList = new List<GroupCheckOutRefund>();
            entOldGrpCheckOutRefundList = new List<GroupCheckOutRefund>();

            lblOpBalance.DataSource = new DataTable();
            lblExternal.DataSource = new DataTable();
        }
        private void CalcGrandTotal()
        {
            lblGrandTotal.Value = txtGrpCheckInTotal.Value + txtNetTotal.Value + txtOpBalance.Value + txtExternalAmt.Value + txtAddnlRoundoff.Value;
            txtBalance.Value = lblGrandTotal.Value - (txtAdvance.Value + txtPayment.Value - txtRefund.Value);
        }
        private void CalcNetTotal()
        {
            txtGross.Value = entGrpCheckOutDTLList.Sum(x => x.Amount).ToDecimal();
            lblTotQty.Value = entGrpCheckOutDTLList.Sum(x => x.Qty).ToDecimal();           
            txtTotalDiscount.Value = entGrpCheckOutDTLList.Sum(x => x.TotalDiscount).ToDecimal();
            lblTotalTax.lblTax1 = entGrpCheckOutDTLList.Sum(x => x.Tax1Amount).ToDecimal();
            lblTotalTax.lblTax2 = entGrpCheckOutDTLList.Sum(x => x.Tax2Amount).ToDecimal();
            lblTotalTax.lblTax3 = entGrpCheckOutDTLList.Sum(x => x.Tax3Amount).ToDecimal();
            lblTotalTax.lblAddnlTax = entGrpCheckOutDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
            lblTotalTax.lblExciseDuty = entGrpCheckOutDTLList.Sum(x => x.ExciseAmount).ToDecimal();
            lblTotalTax.lblVAT = entGrpCheckOutDTLList.Sum(x => x.VATAmount).ToDecimal();
            lblTotalTax.lblCGST = entGrpCheckOutDTLList.Sum(x => x.CGSTAmount).ToDecimal();
            lblTotalTax.lblSGST = entGrpCheckOutDTLList.Sum(x => x.SGSTAmount).ToDecimal();
            lblTotalTax.lblIGST = entGrpCheckOutDTLList.Sum(x => x.IGSTAmount).ToDecimal();
            txtTotalTax.Value = entGrpCheckOutDTLList.Sum(x => x.TotalTax).ToDecimal();
            txtNetTotal.Value = (txtGross.Value + txtTotalTax.Value) - txtTotalDiscount.Value;

            CalcGrandTotal();
        }
        private void CalcOpeningAndExternalAmt()
        {
            CalcOpeningBalance();
            CalcExternalAmt();
        }
        private void CalcOpeningBalance()
        {
            try
            {
                if (txtExRate.Value == 0) { return; }
                SPGetGuestBillsParam param = new SPGetGuestBillsParam()
                {
                    AccountID = entGrpCheckIn.FK_BillingAccountID.ToInt32(),
                    FromDate = GlobalFunctions.dtFinancialFromDate,
                    ToDate = dtpArrivalDate.Value.AddMilliseconds(-1),
                    BookingID = (entBookings == null ? 0 : entBookings.id),
                    CheckInID = (entGrpCheckIn == null ? 0 : entGrpCheckIn.id),
                    CheckOutID = (entGrpCheckOut == null ? 0 : entGrpCheckOut.id),
                    ExRate = txtExRate.Value,
                    IsGroupTrans = true
                };
                lblOpBalance.DataSource = GlobalMethods.GetGuestBills(param);
                txtOpBalance.Value = lblOpBalance.TotalAmount;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcExternalAmt()
        {
            try
            {
                if (txtExRate.Value == 0) { return; }
                SPGetGuestBillsParam param = new SPGetGuestBillsParam()
                {
                    AccountID = entGrpCheckIn.FK_BillingAccountID.ToInt32(),
                    FromDate = dtpArrivalDate.Value,
                    ToDate = dtpDepartureDate.Value,
                    BookingID = (entBookings == null ? 0 : entBookings.id),
                    CheckInID = (entGrpCheckIn == null ? 0 : entGrpCheckIn.id),
                    CheckOutID = entGrpCheckOut.id,
                    ExRate = txtExRate.Value,
                    IsGroupTrans = true
                };
                lblExternal.DataSource = GlobalMethods.GetGuestBills(param);
                txtExternalAmt.Value = lblExternal.TotalAmount;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {

            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbGrpCheckIn, "Select Check In ");
                tooltip.SetToolTip(cmbEmployee, "Select Employee ");
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void InitEntities()
        {            
            entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).ToList();            
        }
        private void LoadRooms()
        {
            entRooms = dbh.Rooms.ToList();
            col_Room.DataSource = entRooms;
            col_Room.DisplayMember = "Name";
            col_Room.ValueMember = "id";
        }
        private void LoadSettings()
        {
            NumberFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimals;
            sQtyFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimalsQty;
            txtGross.Format = NumberFormat;
            lblTotQty.Format = sQtyFormat;            
            txtTotalTax.Format = NumberFormat;
            txtTotalDiscount.Format = NumberFormat;
            txtNetTotal.Format = NumberFormat;
            txtPayment.Format = NumberFormat;
            txtGross.Format = NumberFormat;
            txtAdvance.Format = NumberFormat;
            txtBalance.Format = NumberFormat;
            lblGrandTotal.Format = NumberFormat;
            txtRefund.Format = NumberFormat;
            txtExRate.Format = NumberFormat;
            txtExternalAmt.Format = NumberFormat;
            txtOpBalance.Format = NumberFormat;
            lblOpBalance.Format = NumberFormat;
            lblExternal.Format = NumberFormat;
            txtAddnlRoundoff.Format = NumberFormat;

            lblMandatory2.Visible = lblCurrencyCap.Visible = GlobalFunctions.blnMultiCurrency;
            cmbCurrency.Visible = GlobalFunctions.blnMultiCurrency;
            lblExRateCap.Visible = GlobalFunctions.blnMultiCurrency;
            txtExRate.Visible = GlobalFunctions.blnMultiCurrency;
        }
        private void CalcPaymentTotal()
        {
            txtPayment.Value = entGrpCheckOutPaymentList.Sum(x => x.Payment).ToDecimal();
            txtRefund.Value = entGrpCheckOutRefundList.Sum(x => x.Refund).ToDecimal();
        }
        private void fillServiceByCodeInCurrentRow()
        {
            int _ServiceID = 0;
            if (dgDetails.CurrentCell.Value == null) { return; }
            string sCode = dgDetails.CurrentCell.Value.ToString();
            if (dbh.ExtraServices.Any(x => x.Code == sCode))
            {
                _ServiceID = dbh.ExtraServices.Where(x => x.Code == textbox.Text).First().id;
                fillService(_ServiceID);

            }
            else
            {
                dgDetails.CurrentCell.Value = "";
                if (dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value == null) { return; }
                _ServiceID = dgDetails.CurrentRow.Cells[col_FK_ExtraServiceID.Name].Value.ToString().ToInt32();
                fillService(_ServiceID);
            }
        }
        private bool IsExtraSericeChanged()
        {
            if (dgDetails.CurrentCell != null && dgDetails.CurrentCell.Tag != null && dgDetails.CurrentCell.Value != null)
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name)
                    return dgDetails.CurrentCell.Value.ToString2() != dgDetails.CurrentCell.Tag.ToString2();
            }
            return false;
        }
        private void CalculateSlab(bool blnUpdateDeductionAmount, GroupCheckOutExtraServiceDTL pdtl)
        {
            try
            {
                if (pdtl != null)
                {
                    List<Slab> slabs = null;
                    if (IsExtraSericeChanged())
                    {
                        int iServiceID = pdtl.FK_ExtraServiceID.ToInt32();
                        slabs = (from rs in dbh.ExtraServiceSlabs
                                 join s in dbh.Slabs on rs.FK_SlabID equals s.id
                                 where rs.FK_ExtraServiceID == iServiceID
                                 select s).ToList();
                    }
                    pdtl.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcRowAmount(GroupCheckOutExtraServiceDTL pdtl)
        {            
            if (pdtl != null)
            {
                pdtl.Amount = pdtl.Rate * pdtl.Qty;
                bool blnUpdateDeductionAmount = dgDetails.CurrentCell.OwningColumn.Name != col_DeductionAmount.Name;
                CalculateSlab(blnUpdateDeductionAmount, pdtl);
                CalcNetTotal();
            }
        }
        private void CalcGrand(bool blnUpdateAddDiscAmount = true)
        {
            if (entGrpCheckOutDTLList.Count > 0)
            {
                //if (blnUpdateAddDiscAmount)
                //{
                //    txtAddDiscAmount.Value = entCheckInDTLList.Sum(X => X.AddnlDiscount).ToDecimal();
                //}
                //lblTotDiscount.Value = (entCheckInDTLList.Sum(x => x.SlabDiscount).ToDecimal() + entCheckInDTLList.Sum(x => x.AddnlDiscount).ToDecimal() + entServicePurchaseDTLs.Sum(x => x.SpcialDiscount).ToDecimal());
                lblTotalTax.lblTax1 = entGrpCheckOutDTLList.Sum(x => x.Tax1Amount).ToDecimal();
                lblTotalTax.lblTax2 = entGrpCheckOutDTLList.Sum(x => x.Tax2Amount).ToDecimal();
                lblTotalTax.lblTax3 = entGrpCheckOutDTLList.Sum(x => x.Tax3Amount).ToDecimal();
                lblTotalTax.lblAddnlTax = entGrpCheckOutDTLList.Sum(x => x.AddnlTaxAmount).ToDecimal();
                lblTotalTax.lblExciseDuty = entGrpCheckOutDTLList.Sum(x => x.ExciseAmount).ToDecimal();
                lblTotalTax.lblVAT = entGrpCheckOutDTLList.Sum(x => x.VATAmount).ToDecimal();
                lblTotalTax.lblCGST = entGrpCheckOutDTLList.Sum(x => x.CGSTAmount).ToDecimal();
                lblTotalTax.lblSGST = entGrpCheckOutDTLList.Sum(x => x.SGSTAmount).ToDecimal();
                lblTotalTax.lblIGST = entGrpCheckOutDTLList.Sum(x => x.IGSTAmount).ToDecimal();
                lblGrandTotal.Value = txtGrpCheckInTotal.Value + txtNetTotal.Value;
                if (GlobalFunctions.strRoundoffPurchases != "")
                {
                    decimal dcBeforeRoundOff = lblGrandTotal.Value;
                    lblGrandTotal.Value = Math2.Round(lblGrandTotal.Value, GlobalFunctions.strRoundoffPurchases.ToInt32());
                }
                CalcNetTotal();
            }
        }
        private void ClearGuestInfo()
        {
            Guestid = 0; iRoomId = 0; iBookingId = 0; dCheckInPayment = 0;
            txtMobile.Text = ""; txtGuest.Text = "";
            txtAdd1.Text = ""; txtTelephone.Text = "";
            DeductionPerc = 0; txtAdvance.Value = 0; txtGrpCheckInTotal.Value = 0;
            txtNoOfDays.Value = 0; txtBalance.Value = 0; lblGrandTotal.Value = 0;
            entGrpCheckInDTLList = null;
            entGrpCheckIn = new GroupCheckIn();
            entBookings = new GroupBooking();
            entCheckInPaymentlist = new List<GroupCheckInPayment>();
            entGuest = new Guests();
            e_GuestDTLs = new GuestDTLs();
            entGrpCheckInDTLList = new List<GroupCheckInDTL>();
            entBookings = new GroupBooking();
            entBookingPaymentlist = new List<GroupBookingPayment>();
            DeductionPerc = 0;
            DefaultCreditCard = 0;
            DefaultCreditCardNumber = "";
            BindRoomDetailsGrid();
        }
        private void LoadGuestInfo(int iGroupCheckInId)
        {
            try
            {                
                entGrpCheckIn = dbh.GroupCheckIns.Where(x => x.id == iGroupCheckInId).SingleOrDefault();
                if (entGrpCheckIn != null && cmbGrpCheckIn.Text != "")
                {
                    Guestid = entGrpCheckIn.FK_GuestID.ToInt32();
                    iBookingId = entGrpCheckIn.FK_GroupBookingID.ToInt32();
                    dtpArrivalDate.Value = entGrpCheckIn.ArrivalDate.Value;
                    dtpDepartureDate.Value = entGrpCheckIn.DepartureDate.Value;
                    txtGrpCheckInTotal.Value = entGrpCheckIn.GrandTotal.ToDecimal();
                    txtNoOfDays.Value = entGrpCheckIn.NoofDays.toInt32();
                    cmbCurrency.SelectedValue = entGrpCheckIn.FK_CurrencyHdrID.ToInt32();
                    entBookings = dbh.GroupBookings.Where(x => x.id == iBookingId).SingleOrDefault();
                    entCheckInPaymentlist = dbh.GroupCheckInPayments.Where(x => x.FK_GroupCheckInID == entGrpCheckIn.id).ToList();
                    if (entCheckInPaymentlist != null)
                    {
                        dCheckInPayment = entCheckInPaymentlist.Sum(x => x.Payment).ToDecimal();
                    }
                    #region Guest Details
                    entGuest = dbh.Guests.Where(x => x.id == Guestid).SingleOrDefault();
                    e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == Guestid).SingleOrDefault();
                    if (e_GuestDTLs != null)
                    {
                        txtGuest.Text = Convert.ToString(entGuest.Name); txtGuest.Tag = entGuest.id;
                        txtMobile.Text = Convert.ToString(e_GuestDTLs.Mobile);
                        txtAdd1.Text = Convert.ToString(e_GuestDTLs.Address1);
                        DeductionPerc = e_GuestDTLs.DiscountPerc.ToDecimal();
                        txtTelephone.Text = Convert.ToString(e_GuestDTLs.Telephone);
                        DefaultCreditCard = e_GuestDTLs.FK_CreditCardType.ToInt32();
                        DefaultCreditCardNumber = e_GuestDTLs.CreditCardNo;
                    }
                    #endregion
                    #region Room Details
                    var CurrentDt2 = (from pdt2 in dbh.GroupCheckInDTLs
                                      where pdt2.FK_GroupCheckInID == entGrpCheckIn.id
                                      select new { pdt2 }).ToList();
                    CurrentDt2.ForEach(x =>
                    {

                    });
                    entGrpCheckInDTLList = CurrentDt2.Select(x => x.pdt2).OrderBy(x => x.id).ToList();
                    #endregion
                    #region Booking Details
                    entBookings = dbh.GroupBookings.Where(x => x.id == iBookingId).SingleOrDefault();                    
                    entBookingPaymentlist = dbh.GroupBookingPayments.Where(x => x.FK_GroupBookingID == iBookingId).ToList();
                    if (entBookingPaymentlist != null)
                    {
                        dBookingPayment = entBookingPaymentlist.Sum(x => x.Payment).ToDecimal();

                    }
                    #endregion
                    txtAdvance.Value = dBookingPayment + dCheckInPayment;
                    BindRoomDetailsGrid();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void SetDefaultDateAndTime()
        {
            try
            {
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
                txtNoOfDays.Value = 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Public Methods
        public override void LoadVouchers()
        {
            string sTempVno = txtVoucherNo.Text;
            dbh = atHotelContext.CreateContext();
            List<UpDownData> _Vouchers = dbh.GroupCheckOuts.OrderByDescending(x => x.id)
                .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
            txtVoucherNo.Items.Clear();
            txtVoucherNo.DataSource = _Vouchers;
            if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
            txtVoucherNo.Text = sTempVno;
        }
        public override void ReLoadData(string VoucherNo)
        {
            GroupCheckOut groupCheckOut = dbh.GroupCheckOuts.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (groupCheckOut != null)
            {
                ReLoadData(groupCheckOut.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                #region CheckOut Data
                entGrpCheckOut = dbh.GroupCheckOuts.Where(x => x.id == ID).SingleOrDefault();
                if (entGrpCheckOut != null)
                {

                    txtVoucherNo.Text = entGrpCheckOut.VoucherNo;
                    dtVoucherDate.Value = entGrpCheckOut.VoucherDate.Value;
                    cmbGrpCheckIn.SelectedValue = entGrpCheckOut.FK_GroupCheckInID;
                    
                    txtPayment.Value = entGrpCheckOut.Payment.ToDecimal();
                    txtBalance.Value = entGrpCheckOut.Balance.ToDecimal();
                    dtpDepartureDate.Text = entGrpCheckOut.DepartureDate.Value.ToString();
                    txtNoOfDays.Value = entGrpCheckOut.NoofDays.toInt32();
                    txtNetTotal.Value = entGrpCheckOut.ExtraServices.ToDecimal();
                    txtRefund.Value = entGrpCheckOut.Refund.ToDecimal();
                    if (entGrpCheckOut.FK_EmployeeID != null)
                    {
                        cmbEmployee.SelectedValue = entGrpCheckOut.FK_EmployeeID;
                    }
                    txtRemarks.Text = entGrpCheckOut.Remarks;
                    cmbCurrency.SelectedValue = entGrpCheckOut.FK_CurrencyHdrID;
                    txtExRate.Value = entGrpCheckOut.ExRate.ToDecimal();
                    txtAddnlRoundoff.Value = entGrpCheckOut.AddnlRoundoff ?? 0;
                    #endregion
                    #region Reload Extra Service Details


                    var CurrentDtl = (from pdtl in dbh.GroupCheckOutExtraServiceDTLs
                                      join prd in dbh.ExtraServices on pdtl.FK_ExtraServiceID equals prd.id
                                      where pdtl.FK_GroupCheckOutID == ID
                                      select new { pdtl, prd }).ToList();
                    CurrentDtl.ForEach(x =>
                    {
                        x.pdtl.ServiceCode = x.prd.Code;
                        x.pdtl.ServiceName = x.prd.Name;
                    });
                    entGrpCheckOutDTLList = CurrentDtl.Select(x => x.pdtl).OrderBy(x => x.id).ToList();
                    entOldGrpCheckOutDTLList = new List<GroupCheckOutExtraServiceDTL>(entGrpCheckOutDTLList);
                    #endregion
                    #region Reload Payment Details
                    entGrpCheckOutPaymentList = dbh.GroupCheckOutPayments.Where(x => x.FK_GroupCheckOutID == entGrpCheckOut.id).ToList();
                    entOldGrpCheckOutPaymentList = new List<GroupCheckOutPayment>(entGrpCheckOutPaymentList);
                    #endregion
                    #region Reload Refund Details
                    entGrpCheckOutRefundList = dbh.GroupCheckOutRefunds.Where(x => x.FK_GroupCheckOutID == entGrpCheckOut.id).ToList();
                    entOldGrpCheckOutRefundList = new List<GroupCheckOutRefund>(entGrpCheckOutRefundList);
                    #endregion
                    BindGrid();
                    LoadFullSerialNo();
                    CalcOpeningAndExternalAmt();
                    CalcPaymentTotal();
                    CalcNetTotal();                    
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form event
        private void txtAddnlRoundoff_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter || e.KeyCode != Keys.Tab)
            {
                CalcGrandTotal();
            }
        }
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }        
        private void cmbGrpCheckIn_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (_OnLoad > 0)
                {
                    ClearGuestInfo();
                    LoadGuestInfo(cmbGrpCheckIn.SelectedValue.ToInt32());
                    CalcOpeningAndExternalAmt();
                    CalcNetTotal();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void btnPayment_Click(object sender, EventArgs e)
        {
            decimal PayAmt = lblGrandTotal.Value - (txtAdvance.Value - txtRefund.Value); ;
            GroupCheckOutPaymentView payment = new GroupCheckOutPaymentView(entGrpCheckOutPaymentList, PayAmt, NumberFormat, DefaultCreditCard,DefaultCreditCardNumber);
            if (payment.ShowDialog() == DialogResult.OK)
            {
                CalcPaymentTotal();
                CalcGrandTotal();
            }
        }
        private void btnRefund_Click(object sender, EventArgs e)
        {
            decimal PayAmt = lblGrandTotal.Value - (txtAdvance.Value + txtPayment.Value);
            PayAmt = Math.Abs(PayAmt);
            GroupCheckOutRefundView payment = new GroupCheckOutRefundView(entGrpCheckOutRefundList, PayAmt, NumberFormat, DefaultCreditCard, DefaultCreditCardNumber);
            if (payment.ShowDialog() == DialogResult.OK)
            {
                CalcPaymentTotal();
                CalcGrandTotal();
            }
        }
        private void btnGrpCheckIn_Click(object sender, EventArgs e)
        {
            if (cmbGrpCheckIn.Text.Trim() == "")
            { errProvider.SetError(cmbGrpCheckIn, "Choose Group Check In"); cmbGrpCheckIn.Focus(); }
            else
            {
                GroupCheckInView CheckIn = new GroupCheckInView(cmbGrpCheckIn.SelectedValue.ToInt32());
                if (CheckIn.ShowDialog() == DialogResult.OK)
                {
                    dbh = atHotelContext.CreateContext();
                    entGrpCheckIn = new GroupCheckIn();
                    ClearGuestInfo();
                    LoadGuestInfo(cmbGrpCheckIn.SelectedValue.ToInt32());
                    CalcOpeningAndExternalAmt();
                    CalcNetTotal();

                }
            }
        }
        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurrency.ValueMember == "") { return; }
                if (cmbCurrency.SelectedValue == null) { return; }
                int iCurrencyID = cmbCurrency.SelectedValue.ToString2().ToInt32();

                CurrencyClass entCurrency = entCurrencys.Where(x => x.id == iCurrencyID).Single();
                Company company = dbh.Companies.Single();
                int _sourcecurrencyId = company.FK_Currency.toInt32();
                int _destinationCurrencyID = entCurrency.id;
                if (_sourcecurrencyId == _destinationCurrencyID)
                {
                    txtExRate.Enabled = false;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
                txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                ApplyExRate();
            }
            catch (Exception) { }
        }
        private void txtExRate_Enter(object sender, EventArgs e)
        {
            previousExRate = txtExRate.Value;
        }
        private void txtExRate_KeyUp(object sender, KeyEventArgs e)
        {
            ApplyExRate();
        }
        #endregion

        #region Framework events
        private void GroupCheckOutView_atInitialise()
        {
            try
            {                
                InitEntities();
                InitControls();
                LoadSettings();
                InitGridColumns();
                ApplyGridStyles();
                ShowToolTip();
                PopulateGroupCombos();
                SettingsButton.Visible = true; ShareButton.Visible = true;                            
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }

        }
        private void GroupCheckOutView_atAfterInitialise()
        {
            try
            {                
                _OnLoad = 1;
                SetDefaultDateAndTime();
                GroupCheckOutView_atNewClick(null);
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void GroupCheckOutView_atNewClick(object source)
        {
            try
            {
                PopulateGroupCheckOut();
                FnClearAll();
                ClearGuestInfo();
                BindGrid();
                SetDefaultComboValues();
                BindRoomDetailsGrid();
                SetDefaultDateAndTime();
                GetSeqNo();
                CalcNetTotal();
                cmbGrpCheckIn.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool GroupCheckOutView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    dbh = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                #region Voucher Posting
                entGrpCheckOut.Sanctioned = !blnSanctioningRequired;
                if (!blnSanctioningRequired)
                {
                    PostVoucher();
                }
                //Extra Services
                if (!blnSanctioningRequired && entGrpCheckOutDTLList.Count() > 0)
                {
                    entGrpCheckOut.FK_VoucherHDRID = entVoucherHdr.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entGrpCheckOut.FK_VoucherHDRID, ref dbh);
                    entGrpCheckOut.FK_VoucherHDRID = null;
                }

                //Payment
                if (!blnSanctioningRequired && entGrpCheckOutPaymentList.Count() > 0)
                {
                    entGrpCheckOut.FK_PaymentVoucherHDRID = entVoucherHdrPayment.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entGrpCheckOut.FK_PaymentVoucherHDRID, ref dbh);
                    entGrpCheckOut.FK_PaymentVoucherHDRID = null;
                }

                //Refund
                if (!blnSanctioningRequired && entGrpCheckOutRefundList.Count() > 0)
                {
                    entGrpCheckOut.FK_RefundVoucherHDRID = entVoucherHdrRefund.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entGrpCheckOut.FK_RefundVoucherHDRID, ref dbh);
                    entGrpCheckOut.FK_RefundVoucherHDRID = null;
                }
                #endregion
                #region CheckOut Details                                
                entGrpCheckOut.ContextID = iContextID;
                entGrpCheckOut.LoginUserID = GlobalFunctions.LoginUserID;
                entGrpCheckOut.LocationID = GlobalFunctions.LoginLocationID;
                entGrpCheckOut.VoucherNo = txtVoucherNo.Text;
                entGrpCheckOut.VoucherDate = dtVoucherDate.Value;
                entGrpCheckOut.DepartureDate = dtpDepartureDate.Value;
                entGrpCheckOut.NoofDays = txtNoOfDays.Text.ToInt32();
                entGrpCheckOut.ExtraServices = txtNetTotal.Value;
                entGrpCheckOut.Refund = txtRefund.Value;
                entGrpCheckOut.Balance = txtBalance.Value;
                entGrpCheckOut.FK_GroupCheckInID = cmbGrpCheckIn.SelectedValue.ToString().ToInt32();
                entGrpCheckOut.Payment = txtPayment.Value;
                entGrpCheckOut.Remarks = txtRemarks.Text;
                entGrpCheckOut.FK_CurrencyHdrID = cmbCurrency.SelectedValue.ToString2().ToInt32();
                entGrpCheckOut.ExRate = txtExRate.Value;
                if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
                {
                    entGrpCheckOut.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
                }
                else { entGrpCheckOut.FK_EmployeeID = null; }
                entGrpCheckOut.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entGrpCheckOut.AddnlRoundoff = txtAddnlRoundoff.Value;
                entGrpCheckOut.Sanctioned = true;
                entGrpCheckOut.Cancelled = false;
                if (NewRecord)
                {
                    dbh.GroupCheckOuts.AddObject(entGrpCheckOut);
                }
                else
                {
                    entGrpCheckOut.ModifiedDate = System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(entGrpCheckOut, EntityState.Modified);
                }
                #endregion
                #region Removing Deleted GrpCheckOutExtraServices
                var d1 = entOldGrpCheckOutDTLList.Select(x => new { id = x.id });
                var d2 = entGrpCheckOutDTLList.Select(y => new { id = y.id });
                var deletedESDtls = d1.Except(d2);
                foreach (var deletedItem in deletedESDtls)
                {
                    GroupCheckOutExtraServiceDTL delItDtl = entOldGrpCheckOutDTLList.Where(x => x.id == deletedItem.id).First();
                    dbh.GroupCheckOutExtraServiceDTLs.DeleteObject(delItDtl);
                }
                #endregion
                #region Adding or Updating ExtraSevices
                foreach (GroupCheckOutExtraServiceDTL ExtraService in bindExtraServiceDTL.List)
                {
                    if (entGrpCheckOut.id != null)
                    {
                        ExtraService.FK_GroupCheckOutID = entGrpCheckOut.id;


                        if (dbh.GroupCheckOutExtraServiceDTLs.Where(x => x.id == ExtraService.id).ToList().Count == 0)
                        {
                            dbh.GroupCheckOutExtraServiceDTLs.AddObject(ExtraService);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(ExtraService, System.Data.EntityState.Modified);
                        }
                    }
                }
                #endregion
                #region Removing Deleted Payments
                var p1 = entOldGrpCheckOutPaymentList.Select(x => new { id = x.id });
                var p2 = entGrpCheckOutPaymentList.Select(y => new { id = y.id });
                var deletedpayments = p1.Except(p2);
                foreach (var deletedItem in deletedpayments)
                {
                    GroupCheckOutPayment delItPay = entOldGrpCheckOutPaymentList.Where(x => x.id == deletedItem.id).First();
                    dbh.GroupCheckOutPayments.DeleteObject(delItPay);
                }
                #endregion
                #region Adding or Updating Payments
                foreach (GroupCheckOutPayment eCheckOutPayment in entGrpCheckOutPaymentList)
                {
                    if (eCheckOutPayment.Payment != 0)
                    {
                        eCheckOutPayment.FK_GroupCheckOutID = entGrpCheckOut.id;
                        if (eCheckOutPayment.FK_MVInstrumentTypeID == 0)
                        {
                            eCheckOutPayment.FK_MVInstrumentTypeID = null;
                        }
                        if (dbh.GroupCheckOutPayments.Where(x => x.id == eCheckOutPayment.id).ToList().Count == 0)
                        {
                            dbh.GroupCheckOutPayments.AddObject(eCheckOutPayment);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(eCheckOutPayment, System.Data.EntityState.Modified);
                        }
                    }
                }

                #endregion
                #region Removing Deleted Refunds
                var r1 = entOldGrpCheckOutRefundList.Select(x => new { id = x.id });
                var r2 = entGrpCheckOutRefundList.Select(y => new { id = y.id });
                var deletedRefunds = r1.Except(r2);
                foreach (var deletedItem in deletedRefunds)
                {
                    GroupCheckOutRefund delItPay = entOldGrpCheckOutRefundList.Where(x => x.id == deletedItem.id).First();
                    dbh.GroupCheckOutRefunds.DeleteObject(delItPay);
                }
                #endregion
                #region Adding or Updating Refund
                foreach (GroupCheckOutRefund eCheckOutPayment in entGrpCheckOutRefundList)
                {
                    if (eCheckOutPayment.Refund != 0)
                    {
                        eCheckOutPayment.FK_GroupCheckOutID = entGrpCheckOut.id;
                        if (eCheckOutPayment.FK_MVInstrumentTypeID == 0)
                        {
                            eCheckOutPayment.FK_MVInstrumentTypeID = null;
                        }
                        if (dbh.GroupCheckOutRefunds.Where(x => x.id == eCheckOutPayment.id).ToList().Count == 0)
                        {
                            dbh.GroupCheckOutRefunds.AddObject(eCheckOutPayment);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(eCheckOutPayment, System.Data.EntityState.Modified);
                        }
                    }
                }

                #endregion
                #region Save to RoomStatusRegister
                List<GroupCheckInDTL> groupCheckInDTL = dbh.GroupCheckInDTLs.Where(x => x.FK_GroupCheckInID == entGrpCheckIn.id).ToList();
                foreach (GroupCheckInDTL _Rooms in groupCheckInDTL)
                {
                    _Rooms.ArrivalDate = entGrpCheckIn.ArrivalDate;
                    _Rooms.DepartureDate = entGrpCheckIn.DepartureDate;
                    _Rooms.FK_RefTransTypeID = (int)ENMVMTTransactionType.HTL_GroupCheckIn;
                    _Rooms.FK_RefTransID = _Rooms.id;
                    GlobalMethods.SaveRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupCheckOut, _Rooms);
                }
                #endregion
                dbh.SaveChanges();

                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                // dbh.DetachAllEntities();
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private void GroupCheckOutView_Shown(object sender, EventArgs e)
        {
            if (_GroupCheckInId != 0)
            {
                cmbGrpCheckIn.SelectedValue = _GroupCheckInId;
                ClearGuestInfo();
                LoadGuestInfo(cmbGrpCheckIn.SelectedValue.ToInt32());
                CalcOpeningAndExternalAmt();
                CalcNetTotal();
            }
        }
        private bool GroupCheckOutView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "") { errProvider.SetError(txtVoucherNo, "Voucher No  Must be Entered"); txtVoucherNo.Focus(); return false; }
                if (cmbGrpCheckIn.Text.Trim() == "") { errProvider.SetError(cmbGrpCheckIn, "Choose Check In"); cmbGrpCheckIn.Focus(); return false; }
                // if (cmbEmployee.Text.Trim() == "") { errProvider.SetError(cmbEmployee, MessageKeys.MsgChooseEmployee); cmbEmployee.Focus(); return false; }
                if (GlobalFunctions.blnMultiCurrency)
                {
                    if (cmbCurrency.SelectedValue == null) { errProvider.SetError(cmbCurrency, MessageKeys.MsgCurrencyMustBeSelected); cmbCurrency.Focus(); return false; }
                }
                if (dtpDepartureDate.Value > DateTime.Now)
                {
                    { errProvider.SetError(dtpDepartureDate, "Departure Date Must be less than Current Date"); dtpDepartureDate.Focus(); return false; }
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool GroupCheckOutView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInGroupCheckOut)
                {
                    PrintClick();
                }
                if (GlobalProperties.SendEmailWhileSavingInGroupCheckOut)
                {
                    SendEmail();
                }
                if (GlobalProperties.SendSMSWhileSavingInGroupCheckOut)
                {
                    SendSMS();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void GroupCheckOutView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vCheckIn = entGrpCheckOutList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vCheckIn;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }        
        private bool GroupCheckOutView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vBookings = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vBookings).id);
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool GroupCheckOutView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void GroupCheckOutView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbGrpCheckIn.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool GroupCheckOutView_atPrint(object source)
        {
            try
            {
                if (entGrpCheckOut.id == 0) 
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Group Check Out", entGrpCheckOut.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool GroupCheckOutView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteVoucher(entGrpCheckOut.FK_VoucherHDRID, ref dbh);
                GlobalMethods.DeleteVoucher(entGrpCheckOut.FK_PaymentVoucherHDRID, ref dbh);
                GlobalMethods.DeleteVoucher(entGrpCheckOut.FK_RefundVoucherHDRID, ref dbh);
                List<GroupCheckInDTL> groupCheckInDTL = dbh.GroupCheckInDTLs.Where(x => x.FK_GroupCheckInID == entGrpCheckIn.id).ToList();
                foreach (GroupCheckInDTL _Rooms in groupCheckInDTL)
                {
                    GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupCheckOut, _Rooms);
                }
                foreach (GroupCheckOutPayment Payment in entGrpCheckOutPaymentList) //**Delete Payments **
                {
                    dbh.GroupCheckOutPayments.DeleteObject(Payment);
                }
                foreach (GroupCheckOutRefund Refund in entGrpCheckOutRefundList) //**Delete Refund **
                {
                    dbh.GroupCheckOutRefunds.DeleteObject(Refund);
                }
                dbh.DeleteObject(entGrpCheckOut);        //**Delete GroupCheckOut**
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void GroupCheckOutView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion

        #region GridMethods
        private void LoadCurrentSerialNo()
        {
            if (dgDetails.CurrentRow == null) { return; }
            dgDetails.CurrentRow.Cells[col_slno.Name].Value = dgDetails.CurrentRow.Cells[col_slno.Name].RowIndex + 1;
        }
        private void LoadFullSerialNo()
        {
            int i = 1;
            foreach (DataGridViewRow row in dgDetails.Rows)
            {
                row.Cells[col_slno.Name].Value = i;
                i = i + 1;
            }

        }
        private GroupCheckOutExtraServiceDTL getCurrent()
        {
            try
            {

                if (dgDetails.CurrentRow != null)
                {
                    GroupCheckOutExtraServiceDTL ExtraServiceDTL = (GroupCheckOutExtraServiceDTL)dgDetails.CurrentRow.DataBoundItem;
                    return ExtraServiceDTL;
                }
                else
                {
                    return null;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void BindGrid()
        {
            try
            {
                dgDetails.AutoGenerateColumns = false;
                bindExtraServiceDTL.DataSource = null;
                bindExtraServiceDTL.DataSource = entGrpCheckOutDTLList;
                dgDetails.DataSource = bindExtraServiceDTL;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void InitGridColumns()
        {
            try
            {
                entGrpCheckOutDTLList = dbh.GroupCheckOutExtraServiceDTLs.Where("1=2").ToList();
                //col_DeductionPerc.Visible=GlobalFunctions.blnDeductionPerc;
                //col_DeductionAmount.Visible=GlobalFunctions.blnDeductionAmount;
                col_SlabDiscount.Visible = GlobalFunctions.blnSlabDiscountinService;
                col_SlabDiscountPerc.Visible = GlobalFunctions.blnSlabDiscountinService;
                //col_TotalTax.Visible=GlobalFunctions.blnTotalTax;
                //col_NetAmount.Visible=GlobalFunctions.blnNetAmount;
                //  col_FK_DiscountSlabID.Visible=GlobalFunctions.blnDiscountSlabID;
                // col_TotalDiscount.Visible = GlobalFunctions.blnTotalDiscount;
                //col_TaxableAmount.Visible = GlobalFunctions.blnTaxableAmount;
                //col_FK_GSTSlabID.Visible = GlobalFunctions.blnGSTSlabID;
                //col_FK_VATSlabID.Visible = GlobalFunctions.blnFK_VATSlabIDe;
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
                col_ExciseAmount.Visible = GlobalFunctions.blnExciseDutyInService;
                // col_FK_ExciseSlabID.Visible = GlobalFunctions.blnExciseSlabID);
                //col_ExciseAmount.Visible=GlobalFunctions.ExcisePerc;
                //col_ExciseAmount.Visible=GlobalFunctions.ExciseAmount;
                // col_FK_TAX1SlabID.Visible=GlobalFunctions.FK_TAX1SlabID;
                col_VATAmount.Visible = GlobalFunctions.blnVATinService;
                col_VATPerc.Visible = GlobalFunctions.blnVATinService;
                col_Tax1Amount.Visible = GlobalFunctions.blnTAX1inService;
                col_Tax1Perc.Visible = GlobalFunctions.blnTAX1inService;
                // col_FK_TAX2SlabID.Visible=GlobalFunctions.blnTAX2SlabID;
                col_Tax2Amount.Visible = GlobalFunctions.blnTAX2inService;
                col_Tax2Perc.Visible = GlobalFunctions.blnTAX2inService;
                //col_FK_TAX3SlabID.Visible=GlobalFunctions.blnTAX3SlabID;
                col_Tax3Amount.Visible = GlobalFunctions.blnTAX3inService;
                col_Tax3Perc.Visible = GlobalFunctions.blnTAX3inService;
                // col_AddnlTaxPerc.Visible = GlobalFunctions.blnAddnlTaxPerc;
                col_AddnlTaxAmount.Visible = GlobalFunctions.blnAddnlTaxinService;
                //col_FK_AddnlTaxSlabID.Visible=GlobalFunctions.blnAddnlTaxSlabID;
                col_Tax1Amount.HeaderText = GlobalFunctions.Tax1Caption + " " + MessageKeys.MsgAmount;
                col_Tax2Amount.HeaderText = GlobalFunctions.Tax2Caption + " " + MessageKeys.MsgAmount;
                col_Tax3Amount.HeaderText = GlobalFunctions.Tax3Caption + " " + MessageKeys.MsgAmount;
                col_Tax1Perc.HeaderText = GlobalFunctions.Tax1Caption + " %";
                col_Tax2Perc.HeaderText = GlobalFunctions.Tax2Caption + " %";
                col_Tax3Perc.HeaderText = GlobalFunctions.Tax3Caption + " %";

                col_InclusiveRate.Visible = GlobalFunctions.blnInclusiveRateInPurchase;

                if (GlobalFunctions.blnGSTinService)
                {
                    col_SGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_SGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.SGSTColumnInPurchaseInvoice);
                    col_IGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_IGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.IGSTColumnInPurchaseInvoice);
                    col_CGSTAmount.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                    col_CGSTPerc.Visible = GlobalFunctions.GetANISettings((int)ENANISettings.CGSTColumnInPurchaseInvoice);
                }
                else
                {
                    col_SGSTAmount.Visible = false;
                    col_SGSTPerc.Visible = false;
                    col_IGSTAmount.Visible = false;
                    col_IGSTPerc.Visible = false;
                    col_CGSTAmount.Visible = false;
                    col_CGSTPerc.Visible = false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void ApplyGridStyles()
        {
            try
            {
                col_Qty.DefaultCellStyle.Format = NumberFormat;
                col_Rate.DefaultCellStyle.Format = NumberFormat;
                col_Amount.DefaultCellStyle.Format = NumberFormat;
                col_DeductionPerc.DefaultCellStyle.Format = NumberFormat;
                col_DeductionAmount.DefaultCellStyle.Format = NumberFormat;
                col_TotalTax.DefaultCellStyle.Format = NumberFormat;
                col_NetAmount.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscountPerc.DefaultCellStyle.Format = NumberFormat;
                col_SlabDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TotalDiscount.DefaultCellStyle.Format = NumberFormat;
                col_TaxableAmount.DefaultCellStyle.Format = NumberFormat;
                col_CGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_CGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_SGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_SGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_IGSTPerc.DefaultCellStyle.Format = NumberFormat;
                col_IGSTAmount.DefaultCellStyle.Format = NumberFormat;
                col_VATPerc.DefaultCellStyle.Format = NumberFormat;
                col_VATAmount.DefaultCellStyle.Format = NumberFormat;
                col_ExcisePerc.DefaultCellStyle.Format = NumberFormat;
                col_ExciseAmount.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax1Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax2Amount.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Perc.DefaultCellStyle.Format = NumberFormat;
                col_Tax3Amount.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxPerc.DefaultCellStyle.Format = NumberFormat;
                col_AddnlTaxAmount.DefaultCellStyle.Format = NumberFormat;
                col_InclusiveRate.DefaultCellStyle.Format = NumberFormat;
                lblTotQty.Format = sQtyFormat;
                lblGrandTotal.Format = NumberFormat;
            }
            catch (Exception)
            {

                throw;
            }

        }
        private void fillService(int _ServiceID)
        {
            if (txtExRate.Value == 0) { return; }
            GroupCheckOutExtraServiceDTL cesd = getCurrent();
            if (cesd != null)
            {
                ExtraServices service = dbh.ExtraServices.Where(x => x.id == _ServiceID).Single();
                dgDetails.CurrentRow.Cells[col_Service.Name].Value = service.Name.ToString();
                dgDetails.CurrentRow.Cells[col_Code.Name].Value = service.Code.ToString();
                cesd.FK_ExtraServiceID = _ServiceID;
                cesd.Rate = service.Rate / txtExRate.Value;
                cesd.InclusiveRate = cesd.Rate;
                cesd.DeductionPerc = DeductionPerc;
                dgDetails.CurrentCell = MoveForward(dgDetails.CurrentCell);
            }
        }
        private DataGridViewCell MoveForward(DataGridViewCell _currentCell)
        {
            int row_index = _currentCell.OwningRow.Index;
            int col_index = _currentCell.OwningColumn.Index;
            DataGridViewCell cell = dgDetails.Rows[row_index].Cells[col_index + 1];
            if (cell.Visible && cell.ReadOnly == false)
            {
                return cell;
            }
            else
            {
                return MoveForward(cell);
            }
        }
        private void BindRoomDetailsGrid()
        {
            try
            {
                dgRoom.AutoGenerateColumns = false;
                dgRoom.EndEdit();
                bindRoom.DataSource = null;
                bindRoom.DataSource = entGrpCheckInDTLList;
                dgRoom.DataSource = bindRoom;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region Grid Events
        private void dgDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (e.Control is DataGridViewComboBoxEditingControl)
                {
                    cb = (DataGridViewComboBoxEditingControl)e.Control;
                    if (cb != null)
                    {
                        cb.DropDownStyle = ComboBoxStyle.DropDown;
                        cb.AutoCompleteMode = AutoCompleteMode.Suggest;

                        cb.Validating -= new CancelEventHandler(cb_Validating);
                        cb.Validating += new CancelEventHandler(cb_Validating);
                        cb.KeyDown -= new KeyEventHandler(cb_KeyDown);
                        cb.KeyDown += new KeyEventHandler(cb_KeyDown);
                        cb.Focus();
                    }
                }
                if (e.Control is DataGridViewTextBoxEditingControl)
                {
                    textbox = (DataGridViewTextBoxEditingControl)e.Control;
                    if (textbox != null)
                    {
                        textbox.KeyPress += new KeyPressEventHandler(textbox_KeyPress);
                        textbox.KeyUp -= new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyUp += new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyDown -= new KeyEventHandler(textbox_KeyDown);
                        textbox.KeyDown += new KeyEventHandler(textbox_KeyDown);

                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
            }
        }
        void textbox_KeyDown(object sender, KeyEventArgs e)
        {
            sKeyChar = string.Empty;
            if (e.KeyCode == Keys.Return)
            {
                int index = dgDetails.SelectedCells[0].OwningRow.Index;
                if (textbox.Text.Trim() != "")
                {
                    ExtraServices _service = dbh.ExtraServices.Where(x => x.Name == textbox.Text.Trim()).SingleOrDefault();
                    if (_service != null)
                    {
                        fillService(_service.id);
                    }
                }
                dgDetails.CurrentCell = dgDetails.Rows[index].Cells[col_Code.Index + 1];
            }

        }
        void textbox_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {

                if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
                {
                    if (e.KeyCode == Keys.Return) { return; }
                    if (e.KeyCode == Keys.Escape) { return; }
                    if (e.KeyCode == Keys.Back) { return; }
                    if (sKeyChar == string.Empty) { return; }

                    e.Handled = true;
                    int _SelectedService;

                    ExtraServiceSearchView frm = new ExtraServiceSearchView(sKeyChar, ENExtraServiceTypes.Default);
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        _SelectedService = frm.selectedServiceID;
                        fillService(_SelectedService);
                    }
                    else
                    {
                        textbox.Text = "";
                    }
                }
            }
            catch { }

        }

        private void dgDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            dgDetails.CurrentCell.Tag = dgDetails.CurrentCell.Value ?? string.Empty;
        }
        

        void cb_KeyDown(object sender, KeyEventArgs e)
        {


        }        
        void cb_Validating(object sender, CancelEventArgs e)
        {
            // Create New Service If Not Exist
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Service.Name)
            {
                if (dgDetails.LastKey == Keys.Enter)
                {
                    if (cb.SelectedIndex == -1 && cb.Text != "")
                    {
                        //NewProductView frm = new NewProductView(0, iContextID);
                        //if (frm.ShowDialog() == DialogResult.OK)
                        //{

                        //}
                    }
                }
            }


        }


        void textbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            sKeyChar = e.KeyChar.ToString();
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (Char.IsDigit(e.KeyChar)) return;
                if (Char.IsControl(e.KeyChar)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).Text.Contains('.') == false)) return;
                if ((e.KeyChar == '.') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                e.Handled = true;
            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.NotifyCurrentCellDirty(true);
            }

        }        
        private void dgDetails_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
        }
        private void dgDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {

                fillServiceByCodeInCurrentRow();

            }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Amount.Name)
            {
                if (dgDetails.CurrentCell.Value == null) { return; }
                GroupCheckOutExtraServiceDTL pdtl = getCurrent();
                if (pdtl != null)
                {
                    if (pdtl.Amount == 0) { }
                    if (pdtl.Qty == 0 && pdtl.Rate == 0)
                    {
                        pdtl.Amount = 0;
                    }
                    else if (pdtl.Qty == 0)
                    {
                        pdtl.Qty = pdtl.Amount / pdtl.Rate;
                    }
                    else if (pdtl.Rate == 0)
                    {
                        pdtl.Rate = pdtl.Amount / pdtl.Qty;
                    }
                }

            }

            CalcRowAmount(getCurrent());            
        }
        private void dgDetails_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Code.Name)
            {
                dgDetails.BeginEdit(true);
            }

        }
        private void dgDetails_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            if (dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
            {
                if (e.FormattedValue == null || e.FormattedValue.ToString2().Trim() == "")
                {
                    //    e.Cancel = true;
                }
            }
            //if (dgDetails.CurrentCell.OwningColumn.Name == col_SpcialDiscount.Name || dgDetails.CurrentCell.OwningColumn.Name == col_SpcialDiscountPerc.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Qty.Name)
            //{
            //    if (e.FormattedValue.ToString().ToDecimal() < 0)
            //    {
            //        e.Cancel = true;
            //    }

            //}

        }
        private void dgDetails_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            LoadCurrentSerialNo();
            LoadFullSerialNo();
            CalcGrand();
        }
        private void dgDetails_KeyDown(object sender, KeyEventArgs e)
        {


        }
        private void dgDetails_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            GroupCheckOutExtraServiceDTL pdtl = (GroupCheckOutExtraServiceDTL)dgDetails.Rows[e.RowIndex].DataBoundItem;
            if (pdtl != null)
            {
                try
                {
                    int _CurrentProductID = pdtl.FK_ExtraServiceID.toInt32();

                }
                catch (Exception) { }
            }
            LoadCurrentSerialNo();
        }
        #endregion
    }
}
