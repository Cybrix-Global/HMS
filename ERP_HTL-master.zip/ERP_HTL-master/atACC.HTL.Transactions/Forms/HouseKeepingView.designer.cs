﻿namespace atACC.HTL.Transactions
{
    partial class HouseKeepingView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HouseKeepingView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.cmbRoomStatus = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomSatus = new atACCFramework.UserControls.atLabel();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.cmbRoom = new atACCFramework.UserControls.ComboBoxExt();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.errProvider.SetError(this.panel1, resources.GetString("panel1.Error"));
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.panel1, ((int)(resources.GetObject("panel1.IconPadding"))));
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.errProvider.SetError(this.txtVoucherNo, resources.GetString("txtVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.txtVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtVoucherNo, ((int)(resources.GetObject("txtVoucherNo.IconPadding"))));
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            this.txtVoucherNo.Validating += new System.ComponentModel.CancelEventHandler(this.txtVoucherNo_Validating);
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.errProvider.SetError(this.lblVoucherDate, resources.GetString("lblVoucherDate.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherDate, ((int)(resources.GetObject("lblVoucherDate.IconPadding"))));
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtVoucherDate, resources.GetString("dtVoucherDate.Error"));
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtVoucherDate, ((int)(resources.GetObject("dtVoucherDate.IconPadding"))));
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.errProvider.SetError(this.lblVoucherNo, resources.GetString("lblVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherNo, ((int)(resources.GetObject("lblVoucherNo.IconPadding"))));
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // cmbRoomStatus
            // 
            resources.ApplyResources(this.cmbRoomStatus, "cmbRoomStatus");
            this.cmbRoomStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomStatus.DropDownHeight = 300;
            this.cmbRoomStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbRoomStatus, resources.GetString("cmbRoomStatus.Error"));
            this.cmbRoomStatus.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoomStatus, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoomStatus.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbRoomStatus, ((int)(resources.GetObject("cmbRoomStatus.IconPadding"))));
            this.cmbRoomStatus.Name = "cmbRoomStatus";
            // 
            // lblRoomSatus
            // 
            resources.ApplyResources(this.lblRoomSatus, "lblRoomSatus");
            this.errProvider.SetError(this.lblRoomSatus, resources.GetString("lblRoomSatus.Error"));
            this.errProvider.SetIconAlignment(this.lblRoomSatus, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoomSatus.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRoomSatus, ((int)(resources.GetObject("lblRoomSatus.IconPadding"))));
            this.lblRoomSatus.Name = "lblRoomSatus";
            this.lblRoomSatus.RequiredField = false;
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.errProvider.SetError(this.lblRoom, resources.GetString("lblRoom.Error"));
            this.errProvider.SetIconAlignment(this.lblRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRoom, ((int)(resources.GetObject("lblRoom.IconPadding"))));
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // cmbRoom
            // 
            resources.ApplyResources(this.cmbRoom, "cmbRoom");
            this.cmbRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoom.DropDownHeight = 300;
            this.cmbRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbRoom, resources.GetString("cmbRoom.Error"));
            this.cmbRoom.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbRoom, ((int)(resources.GetObject("cmbRoom.IconPadding"))));
            this.cmbRoom.Name = "cmbRoom";
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtRemarks, resources.GetString("txtRemarks.Error"));
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtRemarks, ((int)(resources.GetObject("txtRemarks.IconPadding"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.errProvider.SetError(this.lblRemarks, resources.GetString("lblRemarks.Error"));
            this.errProvider.SetIconAlignment(this.lblRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRemarks, ((int)(resources.GetObject("lblRemarks.IconPadding"))));
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.errProvider.SetError(this.lblEmployee, resources.GetString("lblEmployee.Error"));
            this.errProvider.SetIconAlignment(this.lblEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblEmployee, ((int)(resources.GetObject("lblEmployee.IconPadding"))));
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // cmbEmployee
            // 
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbEmployee, resources.GetString("cmbEmployee.Error"));
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbEmployee, ((int)(resources.GetObject("cmbEmployee.IconPadding"))));
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.errProvider.SetError(this.lblMandatory1, resources.GetString("lblMandatory1.Error"));
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory1, ((int)(resources.GetObject("lblMandatory1.IconPadding"))));
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.errProvider.SetError(this.lblMandatory3, resources.GetString("lblMandatory3.Error"));
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory3, ((int)(resources.GetObject("lblMandatory3.IconPadding"))));
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.errProvider.SetError(this.lblMandatory2, resources.GetString("lblMandatory2.Error"));
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory2, ((int)(resources.GetObject("lblMandatory2.IconPadding"))));
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // HouseKeepingView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblMandatory3);
            this.Controls.Add(this.lblMandatory1);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.lblRemarks);
            this.Controls.Add(this.lblEmployee);
            this.Controls.Add(this.cmbEmployee);
            this.Controls.Add(this.cmbRoomStatus);
            this.Controls.Add(this.lblRoomSatus);
            this.Controls.Add(this.lblRoom);
            this.Controls.Add(this.cmbRoom);
            this.Controls.Add(this.lblMandatory2);
            this.Name = "HouseKeepingView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.HouseKeepingView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.HouseKeepingView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.HouseKeepingView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.HouseKeepingView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.HouseKeepingView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.HouseKeepingView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.HouseKeepingView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.HouseKeepingView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.HouseKeepingView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.HouseKeepingView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.HouseKeepingView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.HouseKeepingView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.HouseKeepingView_atBeforeSearch);
            this.Controls.SetChildIndex(this.lblMandatory2, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.cmbRoom, 0);
            this.Controls.SetChildIndex(this.lblRoom, 0);
            this.Controls.SetChildIndex(this.lblRoomSatus, 0);
            this.Controls.SetChildIndex(this.cmbRoomStatus, 0);
            this.Controls.SetChildIndex(this.cmbEmployee, 0);
            this.Controls.SetChildIndex(this.lblEmployee, 0);
            this.Controls.SetChildIndex(this.lblRemarks, 0);
            this.Controls.SetChildIndex(this.txtRemarks, 0);
            this.Controls.SetChildIndex(this.lblMandatory1, 0);
            this.Controls.SetChildIndex(this.lblMandatory3, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomStatus;
        private atACCFramework.UserControls.atLabel lblRoomSatus;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.ComboBoxExt cmbRoom;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory2;
    }
}