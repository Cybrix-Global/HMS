﻿namespace atACC.HTL.Transactions
{
    partial class LaundryView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LaundryView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.cmbGuest = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.lblMobileNumber = new atACCFramework.UserControls.atLabel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblCurrencyCap = new atACCFramework.UserControls.atLabel();
            this.txtExRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblExRateCap = new atACCFramework.UserControls.atLabel();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.txtDeductionPerc = new atACCFramework.UserControls.TextBoxExt();
            this.lblDeductionPerc = new atACCFramework.UserControls.atLabel();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.cmbRoom = new atACCFramework.UserControls.ComboBoxExt();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbCurrency = new atACCFramework.UserControls.ComboBoxExt();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.txtGross = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetAmount = new atACCFramework.UserControls.atLabel();
            this.cmbVoucherDiscount = new atACCFramework.UserControls.ComboBoxExt();
            this.lblVoucherDiscountPerc = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDiscountAccount = new atACCFramework.UserControls.atLabel();
            this.lblTotQty = new atACCFramework.UserControls.atNumericLabel();
            this.totqtycap = new atACCFramework.UserControls.atLabel();
            this.btnPayment = new atACCFramework.UserControls.atButton();
            this.txtBalance = new atACCFramework.UserControls.TextBoxNormal();
            this.txtPayment = new atACCFramework.UserControls.atNumericLabel();
            this.lblBalance = new atACCFramework.UserControls.atLabel();
            this.txtNetTotal = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetTotal = new atACCFramework.UserControls.atLabel();
            this.pnlGrid = new atACCFramework.UserControls.atPanel();
            this.dgDetails = new atACCFramework.UserControls.atGridView();
            this.col_slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExtraServiceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_DiscountSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscountPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TaxableAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExcisePerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExciseAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExciseSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX1SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX2SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX3SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_AddnlTaxSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_GSTSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_InclusiveRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_NetAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_VATSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblGrandTotal = new atACCFramework.UserControls.atNumericLabel();
            this.atlblTot = new atACCFramework.UserControls.atLabel();
            this.bindExtraServiceDTL = new System.Windows.Forms.BindingSource(this.components);
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.grpDiscountVoucher = new atACCFramework.UserControls.atGroupBox();
            this.txtVoucherDiscAmount = new atACCFramework.UserControls.TextBoxExt();
            this.txtTotalTax = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotalTax = new atACCFramework.UserControls.TaxLabel();
            this.lblTotalDisc = new atACCFramework.UserControls.atLabel();
            this.lblPayment = new atACCFramework.UserControls.atLabel();
            this.txtTotalDiscount = new atACCFramework.UserControls.atNumericLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindExtraServiceDTL)).BeginInit();
            this.pnlFooter.SuspendLayout();
            this.grpDiscountVoucher.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.btnPayment);
            this.panel1.Controls.Add(this.lblGrandTotal);
            this.panel1.Controls.Add(this.atlblTot);
            this.errProvider.SetError(this.panel1, resources.GetString("panel1.Error"));
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.panel1, ((int)(resources.GetObject("panel1.IconPadding"))));
            this.panel1.Controls.SetChildIndex(this.atlblTot, 0);
            this.panel1.Controls.SetChildIndex(this.lblGrandTotal, 0);
            this.panel1.Controls.SetChildIndex(this.btnPayment, 0);
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.errProvider.SetError(this.txtVoucherNo, resources.GetString("txtVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.txtVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtVoucherNo, ((int)(resources.GetObject("txtVoucherNo.IconPadding"))));
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtVoucherDate, resources.GetString("dtVoucherDate.Error"));
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtVoucherDate, ((int)(resources.GetObject("dtVoucherDate.IconPadding"))));
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            this.dtVoucherDate.ValueChanged += new System.EventHandler(this.dtVoucherDate_ValueChanged);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.errProvider.SetError(this.lblVoucherNo, resources.GetString("lblVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherNo, ((int)(resources.GetObject("lblVoucherNo.IconPadding"))));
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.errProvider.SetError(this.lblVoucherDate, resources.GetString("lblVoucherDate.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherDate, ((int)(resources.GetObject("lblVoucherDate.IconPadding"))));
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // cmbGuest
            // 
            resources.ApplyResources(this.cmbGuest, "cmbGuest");
            this.cmbGuest.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuest.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuest.DropDownHeight = 300;
            this.cmbGuest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbGuest, resources.GetString("cmbGuest.Error"));
            this.cmbGuest.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuest, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuest.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbGuest, ((int)(resources.GetObject("cmbGuest.IconPadding"))));
            this.cmbGuest.Name = "cmbGuest";
            this.cmbGuest.SelectedValueChanged += new System.EventHandler(this.cmbGuest_SelectedValueChanged);
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.errProvider.SetError(this.lblGuest, resources.GetString("lblGuest.Error"));
            this.errProvider.SetIconAlignment(this.lblGuest, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblGuest.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblGuest, ((int)(resources.GetObject("lblGuest.IconPadding"))));
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // txtAdd1
            // 
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtAdd1, resources.GetString("txtAdd1.Error"));
            this.txtAdd1.Format = null;
            this.errProvider.SetIconAlignment(this.txtAdd1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAdd1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtAdd1, ((int)(resources.GetObject("txtAdd1.IconPadding"))));
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.ReadOnly = true;
            this.txtAdd1.TabStop = false;
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.errProvider.SetError(this.lblAddress1, resources.GetString("lblAddress1.Error"));
            this.errProvider.SetIconAlignment(this.lblAddress1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddress1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAddress1, ((int)(resources.GetObject("lblAddress1.IconPadding"))));
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // txtMobile
            // 
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtMobile, resources.GetString("txtMobile.Error"));
            this.txtMobile.Format = null;
            this.errProvider.SetIconAlignment(this.txtMobile, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtMobile.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtMobile, ((int)(resources.GetObject("txtMobile.IconPadding"))));
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = false;
            this.txtMobile.isNumeric = true;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.ReadOnly = true;
            this.txtMobile.TabStop = false;
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMobileNumber
            // 
            resources.ApplyResources(this.lblMobileNumber, "lblMobileNumber");
            this.errProvider.SetError(this.lblMobileNumber, resources.GetString("lblMobileNumber.Error"));
            this.errProvider.SetIconAlignment(this.lblMobileNumber, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMobileNumber.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMobileNumber, ((int)(resources.GetObject("lblMobileNumber.IconPadding"))));
            this.lblMobileNumber.Name = "lblMobileNumber";
            this.lblMobileNumber.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblCurrencyCap);
            this.pnlMain.Controls.Add(this.txtExRate);
            this.pnlMain.Controls.Add(this.lblExRateCap);
            this.pnlMain.Controls.Add(this.txtTelephone);
            this.pnlMain.Controls.Add(this.txtDeductionPerc);
            this.pnlMain.Controls.Add(this.lblDeductionPerc);
            this.pnlMain.Controls.Add(this.cmbEmployee);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.lblEmployee);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.dtpDepartureDate);
            this.pnlMain.Controls.Add(this.lblDepartureDate);
            this.pnlMain.Controls.Add(this.dtpArrivalDate);
            this.pnlMain.Controls.Add(this.lblArrivalDate);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Controls.Add(this.cmbRoom);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.cmbGuest);
            this.pnlMain.Controls.Add(this.lblMobileNumber);
            this.pnlMain.Controls.Add(this.txtAdd1);
            this.pnlMain.Controls.Add(this.txtMobile);
            this.pnlMain.Controls.Add(this.lblAddress1);
            this.pnlMain.Controls.Add(this.label1);
            this.pnlMain.Controls.Add(this.label4);
            this.pnlMain.Controls.Add(this.cmbCurrency);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // lblCurrencyCap
            // 
            resources.ApplyResources(this.lblCurrencyCap, "lblCurrencyCap");
            this.errProvider.SetError(this.lblCurrencyCap, resources.GetString("lblCurrencyCap.Error"));
            this.errProvider.SetIconAlignment(this.lblCurrencyCap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCurrencyCap.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCurrencyCap, ((int)(resources.GetObject("lblCurrencyCap.IconPadding"))));
            this.lblCurrencyCap.Name = "lblCurrencyCap";
            this.lblCurrencyCap.RequiredField = false;
            // 
            // txtExRate
            // 
            resources.ApplyResources(this.txtExRate, "txtExRate");
            this.txtExRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtExRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtExRate, resources.GetString("txtExRate.Error"));
            this.txtExRate.Format = null;
            this.errProvider.SetIconAlignment(this.txtExRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtExRate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtExRate, ((int)(resources.GetObject("txtExRate.IconPadding"))));
            this.txtExRate.isAllowNegative = false;
            this.txtExRate.isAllowSpecialChar = false;
            this.txtExRate.isNumbersOnly = false;
            this.txtExRate.isNumeric = true;
            this.txtExRate.isTouchable = false;
            this.txtExRate.Name = "txtExRate";
            this.txtExRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtExRate.Enter += new System.EventHandler(this.txtExRate_Enter);
            this.txtExRate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtExRate_KeyUp);
            // 
            // lblExRateCap
            // 
            resources.ApplyResources(this.lblExRateCap, "lblExRateCap");
            this.errProvider.SetError(this.lblExRateCap, resources.GetString("lblExRateCap.Error"));
            this.errProvider.SetIconAlignment(this.lblExRateCap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExRateCap.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblExRateCap, ((int)(resources.GetObject("lblExRateCap.IconPadding"))));
            this.lblExRateCap.Name = "lblExRateCap";
            this.lblExRateCap.RequiredField = false;
            // 
            // txtTelephone
            // 
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtTelephone, resources.GetString("txtTelephone.Error"));
            this.txtTelephone.Format = null;
            this.errProvider.SetIconAlignment(this.txtTelephone, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTelephone.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtTelephone, ((int)(resources.GetObject("txtTelephone.IconPadding"))));
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = false;
            this.txtTelephone.isNumeric = true;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.TabStop = false;
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtDeductionPerc
            // 
            resources.ApplyResources(this.txtDeductionPerc, "txtDeductionPerc");
            this.txtDeductionPerc.BackColor = System.Drawing.SystemColors.Window;
            this.txtDeductionPerc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtDeductionPerc, resources.GetString("txtDeductionPerc.Error"));
            this.txtDeductionPerc.Format = null;
            this.errProvider.SetIconAlignment(this.txtDeductionPerc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtDeductionPerc.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtDeductionPerc, ((int)(resources.GetObject("txtDeductionPerc.IconPadding"))));
            this.txtDeductionPerc.isAllowNegative = false;
            this.txtDeductionPerc.isAllowSpecialChar = false;
            this.txtDeductionPerc.isNumbersOnly = false;
            this.txtDeductionPerc.isNumeric = true;
            this.txtDeductionPerc.isTouchable = false;
            this.txtDeductionPerc.Name = "txtDeductionPerc";
            this.txtDeductionPerc.ReadOnly = true;
            this.txtDeductionPerc.TabStop = false;
            this.txtDeductionPerc.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblDeductionPerc
            // 
            resources.ApplyResources(this.lblDeductionPerc, "lblDeductionPerc");
            this.errProvider.SetError(this.lblDeductionPerc, resources.GetString("lblDeductionPerc.Error"));
            this.errProvider.SetIconAlignment(this.lblDeductionPerc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDeductionPerc.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblDeductionPerc, ((int)(resources.GetObject("lblDeductionPerc.IconPadding"))));
            this.lblDeductionPerc.Name = "lblDeductionPerc";
            this.lblDeductionPerc.RequiredField = false;
            // 
            // cmbEmployee
            // 
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbEmployee, resources.GetString("cmbEmployee.Error"));
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbEmployee, ((int)(resources.GetObject("cmbEmployee.IconPadding"))));
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtRemarks, resources.GetString("txtRemarks.Error"));
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtRemarks, ((int)(resources.GetObject("txtRemarks.IconPadding"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.errProvider.SetError(this.lblEmployee, resources.GetString("lblEmployee.Error"));
            this.errProvider.SetIconAlignment(this.lblEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblEmployee, ((int)(resources.GetObject("lblEmployee.IconPadding"))));
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.errProvider.SetError(this.lblRemarks, resources.GetString("lblRemarks.Error"));
            this.errProvider.SetIconAlignment(this.lblRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRemarks, ((int)(resources.GetObject("lblRemarks.IconPadding"))));
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // dtpDepartureDate
            // 
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpDepartureDate, resources.GetString("dtpDepartureDate.Error"));
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpDepartureDate, ((int)(resources.GetObject("dtpDepartureDate.IconPadding"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.TabStop = false;
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.errProvider.SetError(this.lblDepartureDate, resources.GetString("lblDepartureDate.Error"));
            this.errProvider.SetIconAlignment(this.lblDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDepartureDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblDepartureDate, ((int)(resources.GetObject("lblDepartureDate.IconPadding"))));
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // dtpArrivalDate
            // 
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpArrivalDate, resources.GetString("dtpArrivalDate.Error"));
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpArrivalDate, ((int)(resources.GetObject("dtpArrivalDate.IconPadding"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.TabStop = false;
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.errProvider.SetError(this.lblArrivalDate, resources.GetString("lblArrivalDate.Error"));
            this.errProvider.SetIconAlignment(this.lblArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblArrivalDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblArrivalDate, ((int)(resources.GetObject("lblArrivalDate.IconPadding"))));
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.errProvider.SetError(this.lblRoom, resources.GetString("lblRoom.Error"));
            this.errProvider.SetIconAlignment(this.lblRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRoom, ((int)(resources.GetObject("lblRoom.IconPadding"))));
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // cmbRoom
            // 
            resources.ApplyResources(this.cmbRoom, "cmbRoom");
            this.cmbRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoom.DropDownHeight = 300;
            this.cmbRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbRoom, resources.GetString("cmbRoom.Error"));
            this.cmbRoom.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbRoom, ((int)(resources.GetObject("cmbRoom.IconPadding"))));
            this.cmbRoom.Name = "cmbRoom";
            this.cmbRoom.SelectedValueChanged += new System.EventHandler(this.cmbRoom_SelectedValueChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.errProvider.SetError(this.label1, resources.GetString("label1.Error"));
            this.label1.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.label1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("label1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.label1, ((int)(resources.GetObject("label1.IconPadding"))));
            this.label1.Name = "label1";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.errProvider.SetError(this.label4, resources.GetString("label4.Error"));
            this.label4.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.label4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("label4.IconAlignment"))));
            this.errProvider.SetIconPadding(this.label4, ((int)(resources.GetObject("label4.IconPadding"))));
            this.label4.Name = "label4";
            // 
            // cmbCurrency
            // 
            resources.ApplyResources(this.cmbCurrency, "cmbCurrency");
            this.cmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCurrency.DropDownHeight = 300;
            this.cmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbCurrency, resources.GetString("cmbCurrency.Error"));
            this.cmbCurrency.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbCurrency, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbCurrency.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbCurrency, ((int)(resources.GetObject("cmbCurrency.IconPadding"))));
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency_SelectedIndexChanged);
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.errProvider.SetError(this.lblMandatory3, resources.GetString("lblMandatory3.Error"));
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory3, ((int)(resources.GetObject("lblMandatory3.IconPadding"))));
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // txtGross
            // 
            resources.ApplyResources(this.txtGross, "txtGross");
            this.txtGross.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtGross, resources.GetString("txtGross.Error"));
            this.txtGross.ForeColor = System.Drawing.Color.Black;
            this.txtGross.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtGross, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtGross.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtGross, ((int)(resources.GetObject("txtGross.IconPadding"))));
            this.txtGross.Name = "txtGross";
            this.txtGross.RequiredField = false;
            this.txtGross.UseCompatibleTextRendering = true;
            this.txtGross.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetAmount
            // 
            resources.ApplyResources(this.lblNetAmount, "lblNetAmount");
            this.errProvider.SetError(this.lblNetAmount, resources.GetString("lblNetAmount.Error"));
            this.errProvider.SetIconAlignment(this.lblNetAmount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNetAmount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblNetAmount, ((int)(resources.GetObject("lblNetAmount.IconPadding"))));
            this.lblNetAmount.Name = "lblNetAmount";
            this.lblNetAmount.RequiredField = false;
            // 
            // cmbVoucherDiscount
            // 
            resources.ApplyResources(this.cmbVoucherDiscount, "cmbVoucherDiscount");
            this.cmbVoucherDiscount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbVoucherDiscount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVoucherDiscount.DropDownHeight = 300;
            this.errProvider.SetError(this.cmbVoucherDiscount, resources.GetString("cmbVoucherDiscount.Error"));
            this.cmbVoucherDiscount.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbVoucherDiscount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbVoucherDiscount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbVoucherDiscount, ((int)(resources.GetObject("cmbVoucherDiscount.IconPadding"))));
            this.cmbVoucherDiscount.Name = "cmbVoucherDiscount";
            // 
            // lblVoucherDiscountPerc
            // 
            resources.ApplyResources(this.lblVoucherDiscountPerc, "lblVoucherDiscountPerc");
            this.errProvider.SetError(this.lblVoucherDiscountPerc, resources.GetString("lblVoucherDiscountPerc.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherDiscountPerc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherDiscountPerc.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherDiscountPerc, ((int)(resources.GetObject("lblVoucherDiscountPerc.IconPadding"))));
            this.lblVoucherDiscountPerc.Name = "lblVoucherDiscountPerc";
            this.lblVoucherDiscountPerc.RequiredField = false;
            // 
            // lblVoucherDiscountAccount
            // 
            resources.ApplyResources(this.lblVoucherDiscountAccount, "lblVoucherDiscountAccount");
            this.errProvider.SetError(this.lblVoucherDiscountAccount, resources.GetString("lblVoucherDiscountAccount.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherDiscountAccount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherDiscountAccount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherDiscountAccount, ((int)(resources.GetObject("lblVoucherDiscountAccount.IconPadding"))));
            this.lblVoucherDiscountAccount.Name = "lblVoucherDiscountAccount";
            this.lblVoucherDiscountAccount.RequiredField = false;
            // 
            // lblTotQty
            // 
            resources.ApplyResources(this.lblTotQty, "lblTotQty");
            this.lblTotQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.lblTotQty, resources.GetString("lblTotQty.Error"));
            this.lblTotQty.ForeColor = System.Drawing.Color.Black;
            this.lblTotQty.Format = "N2";
            this.errProvider.SetIconAlignment(this.lblTotQty, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotQty.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTotQty, ((int)(resources.GetObject("lblTotQty.IconPadding"))));
            this.lblTotQty.Name = "lblTotQty";
            this.lblTotQty.RequiredField = false;
            this.lblTotQty.UseCompatibleTextRendering = true;
            this.lblTotQty.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // totqtycap
            // 
            resources.ApplyResources(this.totqtycap, "totqtycap");
            this.errProvider.SetError(this.totqtycap, resources.GetString("totqtycap.Error"));
            this.errProvider.SetIconAlignment(this.totqtycap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("totqtycap.IconAlignment"))));
            this.errProvider.SetIconPadding(this.totqtycap, ((int)(resources.GetObject("totqtycap.IconPadding"))));
            this.totqtycap.Name = "totqtycap";
            this.totqtycap.RequiredField = false;
            // 
            // btnPayment
            // 
            resources.ApplyResources(this.btnPayment, "btnPayment");
            this.btnPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnPayment, resources.GetString("btnPayment.Error"));
            this.btnPayment.FlatAppearance.BorderSize = 0;
            this.btnPayment.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnPayment, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnPayment.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnPayment, ((int)(resources.GetObject("btnPayment.IconPadding"))));
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // txtBalance
            // 
            resources.ApplyResources(this.txtBalance, "txtBalance");
            this.txtBalance.BackColor = System.Drawing.SystemColors.Window;
            this.txtBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtBalance, resources.GetString("txtBalance.Error"));
            this.txtBalance.Format = null;
            this.errProvider.SetIconAlignment(this.txtBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtBalance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtBalance, ((int)(resources.GetObject("txtBalance.IconPadding"))));
            this.txtBalance.isAllowNegative = true;
            this.txtBalance.isAllowSpecialChar = false;
            this.txtBalance.isNumeric = true;
            this.txtBalance.isTouchable = false;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.TabStop = false;
            this.txtBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            // 
            // txtPayment
            // 
            resources.ApplyResources(this.txtPayment, "txtPayment");
            this.txtPayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtPayment, resources.GetString("txtPayment.Error"));
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtPayment, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtPayment.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtPayment, ((int)(resources.GetObject("txtPayment.IconPadding"))));
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.RequiredField = false;
            this.txtPayment.UseCompatibleTextRendering = true;
            this.txtPayment.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBalance
            // 
            resources.ApplyResources(this.lblBalance, "lblBalance");
            this.errProvider.SetError(this.lblBalance, resources.GetString("lblBalance.Error"));
            this.errProvider.SetIconAlignment(this.lblBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblBalance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblBalance, ((int)(resources.GetObject("lblBalance.IconPadding"))));
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.RequiredField = false;
            // 
            // txtNetTotal
            // 
            resources.ApplyResources(this.txtNetTotal, "txtNetTotal");
            this.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtNetTotal, resources.GetString("txtNetTotal.Error"));
            this.txtNetTotal.ForeColor = System.Drawing.Color.Black;
            this.txtNetTotal.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNetTotal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtNetTotal, ((int)(resources.GetObject("txtNetTotal.IconPadding"))));
            this.txtNetTotal.Name = "txtNetTotal";
            this.txtNetTotal.RequiredField = false;
            this.txtNetTotal.UseCompatibleTextRendering = true;
            this.txtNetTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetTotal
            // 
            resources.ApplyResources(this.lblNetTotal, "lblNetTotal");
            this.errProvider.SetError(this.lblNetTotal, resources.GetString("lblNetTotal.Error"));
            this.errProvider.SetIconAlignment(this.lblNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNetTotal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblNetTotal, ((int)(resources.GetObject("lblNetTotal.IconPadding"))));
            this.lblNetTotal.Name = "lblNetTotal";
            this.lblNetTotal.RequiredField = false;
            // 
            // pnlGrid
            // 
            resources.ApplyResources(this.pnlGrid, "pnlGrid");
            this.pnlGrid.BackColor = System.Drawing.SystemColors.Window;
            this.pnlGrid.Controls.Add(this.dgDetails);
            this.errProvider.SetError(this.pnlGrid, resources.GetString("pnlGrid.Error"));
            this.errProvider.SetIconAlignment(this.pnlGrid, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlGrid.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlGrid, ((int)(resources.GetObject("pnlGrid.IconPadding"))));
            this.pnlGrid.Name = "pnlGrid";
            // 
            // dgDetails
            // 
            resources.ApplyResources(this.dgDetails, "dgDetails");
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle32;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_slno,
            this.col_Code,
            this.col_Service,
            this.col_FK_ExtraServiceID,
            this.col_Qty,
            this.col_Rate,
            this.col_Amount,
            this.col_DeductionPerc,
            this.col_DeductionAmount,
            this.col_TotalTax,
            this.col_FK_DiscountSlabID,
            this.col_SlabDiscountPerc,
            this.col_SlabDiscount,
            this.col_TotalDiscount,
            this.col_TaxableAmount,
            this.col_ExcisePerc,
            this.col_ExciseAmount,
            this.col_FK_ExciseSlabID,
            this.col_FK_TAX1SlabID,
            this.col_Tax1Perc,
            this.col_Tax1Amount,
            this.col_FK_TAX2SlabID,
            this.col_Tax2Perc,
            this.col_Tax2Amount,
            this.col_FK_TAX3SlabID,
            this.col_Tax3Perc,
            this.col_Tax3Amount,
            this.col_FK_AddnlTaxSlabID,
            this.col_AddnlTaxPerc,
            this.col_AddnlTaxAmount,
            this.col_VATPerc,
            this.col_VATAmount,
            this.col_FK_GSTSlabID,
            this.col_CGSTPerc,
            this.col_CGSTAmount,
            this.col_SGSTPerc,
            this.col_SGSTAmount,
            this.col_IGSTPerc,
            this.col_IGSTAmount,
            this.col_InclusiveRate,
            this.col_NetAmount,
            this.col_FK_VATSlabID});
            this.dgDetails.EnableHeadersVisualStyles = false;
            this.dgDetails.EnterKeyNavigation = false;
            this.errProvider.SetError(this.dgDetails, resources.GetString("dgDetails.Error"));
            this.errProvider.SetIconAlignment(this.dgDetails, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dgDetails.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dgDetails, ((int)(resources.GetObject("dgDetails.IconPadding"))));
            this.dgDetails.LastKey = System.Windows.Forms.Keys.None;
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle62.NullValue = null;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle62;
            this.dgDetails.sGridID = null;
            this.dgDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgDetails_CellBeginEdit);
            this.dgDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEndEdit);
            this.dgDetails.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEnter);
            this.dgDetails.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgDetails_CellValidating);
            this.dgDetails.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgDetails_DataError);
            this.dgDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgDetails_EditingControlShowing);
            this.dgDetails.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgDetails_RowsAdded);
            this.dgDetails.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgDetails_RowsRemoved);
            this.dgDetails.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgDetails_KeyDown);
            // 
            // col_slno
            // 
            this.col_slno.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_slno.DataPropertyName = "SlNo";
            this.col_slno.FillWeight = 111.905F;
            resources.ApplyResources(this.col_slno, "col_slno");
            this.col_slno.Name = "col_slno";
            this.col_slno.ReadOnly = true;
            // 
            // col_Code
            // 
            this.col_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Code.DataPropertyName = "ServiceCode";
            this.col_Code.FillWeight = 95.68391F;
            resources.ApplyResources(this.col_Code, "col_Code");
            this.col_Code.Name = "col_Code";
            this.col_Code.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // col_Service
            // 
            this.col_Service.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Service.DataPropertyName = "ServiceName";
            this.col_Service.FillWeight = 286.4355F;
            resources.ApplyResources(this.col_Service, "col_Service");
            this.col_Service.Name = "col_Service";
            this.col_Service.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Service.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // col_FK_ExtraServiceID
            // 
            this.col_FK_ExtraServiceID.DataPropertyName = "FK_ExtraServiceID";
            resources.ApplyResources(this.col_FK_ExtraServiceID, "col_FK_ExtraServiceID");
            this.col_FK_ExtraServiceID.Name = "col_FK_ExtraServiceID";
            this.col_FK_ExtraServiceID.ReadOnly = true;
            // 
            // col_Qty
            // 
            this.col_Qty.DataPropertyName = "Qty";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_Qty.DefaultCellStyle = dataGridViewCellStyle34;
            this.col_Qty.FillWeight = 91.05099F;
            resources.ApplyResources(this.col_Qty, "col_Qty");
            this.col_Qty.Name = "col_Qty";
            // 
            // col_Rate
            // 
            this.col_Rate.DataPropertyName = "Rate";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Rate.DefaultCellStyle = dataGridViewCellStyle35;
            this.col_Rate.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Rate, "col_Rate");
            this.col_Rate.Name = "col_Rate";
            // 
            // col_Amount
            // 
            this.col_Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Amount.DefaultCellStyle = dataGridViewCellStyle36;
            this.col_Amount.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Amount, "col_Amount");
            this.col_Amount.Name = "col_Amount";
            this.col_Amount.ReadOnly = true;
            // 
            // col_DeductionPerc
            // 
            this.col_DeductionPerc.DataPropertyName = "DeductionPerc";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionPerc.DefaultCellStyle = dataGridViewCellStyle37;
            resources.ApplyResources(this.col_DeductionPerc, "col_DeductionPerc");
            this.col_DeductionPerc.Name = "col_DeductionPerc";
            // 
            // col_DeductionAmount
            // 
            this.col_DeductionAmount.DataPropertyName = "DeductionAmount";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionAmount.DefaultCellStyle = dataGridViewCellStyle38;
            resources.ApplyResources(this.col_DeductionAmount, "col_DeductionAmount");
            this.col_DeductionAmount.Name = "col_DeductionAmount";
            this.col_DeductionAmount.ReadOnly = true;
            // 
            // col_TotalTax
            // 
            this.col_TotalTax.DataPropertyName = "TotalTax";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TotalTax.DefaultCellStyle = dataGridViewCellStyle39;
            resources.ApplyResources(this.col_TotalTax, "col_TotalTax");
            this.col_TotalTax.Name = "col_TotalTax";
            this.col_TotalTax.ReadOnly = true;
            // 
            // col_FK_DiscountSlabID
            // 
            this.col_FK_DiscountSlabID.DataPropertyName = "FK_DiscountSlabID";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_DiscountSlabID.DefaultCellStyle = dataGridViewCellStyle40;
            resources.ApplyResources(this.col_FK_DiscountSlabID, "col_FK_DiscountSlabID");
            this.col_FK_DiscountSlabID.Name = "col_FK_DiscountSlabID";
            // 
            // col_SlabDiscountPerc
            // 
            this.col_SlabDiscountPerc.DataPropertyName = "SlabDiscountPerc";
            resources.ApplyResources(this.col_SlabDiscountPerc, "col_SlabDiscountPerc");
            this.col_SlabDiscountPerc.Name = "col_SlabDiscountPerc";
            // 
            // col_SlabDiscount
            // 
            this.col_SlabDiscount.DataPropertyName = "SlabDiscount";
            resources.ApplyResources(this.col_SlabDiscount, "col_SlabDiscount");
            this.col_SlabDiscount.Name = "col_SlabDiscount";
            // 
            // col_TotalDiscount
            // 
            this.col_TotalDiscount.DataPropertyName = "TotalDiscount";
            resources.ApplyResources(this.col_TotalDiscount, "col_TotalDiscount");
            this.col_TotalDiscount.Name = "col_TotalDiscount";
            // 
            // col_TaxableAmount
            // 
            this.col_TaxableAmount.DataPropertyName = "TaxableAmount";
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TaxableAmount.DefaultCellStyle = dataGridViewCellStyle41;
            resources.ApplyResources(this.col_TaxableAmount, "col_TaxableAmount");
            this.col_TaxableAmount.Name = "col_TaxableAmount";
            this.col_TaxableAmount.ReadOnly = true;
            // 
            // col_ExcisePerc
            // 
            this.col_ExcisePerc.DataPropertyName = "ExcisePerc";
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExcisePerc.DefaultCellStyle = dataGridViewCellStyle42;
            resources.ApplyResources(this.col_ExcisePerc, "col_ExcisePerc");
            this.col_ExcisePerc.Name = "col_ExcisePerc";
            this.col_ExcisePerc.ReadOnly = true;
            // 
            // col_ExciseAmount
            // 
            this.col_ExciseAmount.DataPropertyName = "ExciseAmount";
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExciseAmount.DefaultCellStyle = dataGridViewCellStyle43;
            resources.ApplyResources(this.col_ExciseAmount, "col_ExciseAmount");
            this.col_ExciseAmount.Name = "col_ExciseAmount";
            this.col_ExciseAmount.ReadOnly = true;
            // 
            // col_FK_ExciseSlabID
            // 
            this.col_FK_ExciseSlabID.DataPropertyName = "FK_ExciseSlabID";
            resources.ApplyResources(this.col_FK_ExciseSlabID, "col_FK_ExciseSlabID");
            this.col_FK_ExciseSlabID.Name = "col_FK_ExciseSlabID";
            // 
            // col_FK_TAX1SlabID
            // 
            this.col_FK_TAX1SlabID.DataPropertyName = "FK_TAX1SlabID";
            resources.ApplyResources(this.col_FK_TAX1SlabID, "col_FK_TAX1SlabID");
            this.col_FK_TAX1SlabID.Name = "col_FK_TAX1SlabID";
            // 
            // col_Tax1Perc
            // 
            this.col_Tax1Perc.DataPropertyName = "Tax1Perc";
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Perc.DefaultCellStyle = dataGridViewCellStyle44;
            resources.ApplyResources(this.col_Tax1Perc, "col_Tax1Perc");
            this.col_Tax1Perc.Name = "col_Tax1Perc";
            this.col_Tax1Perc.ReadOnly = true;
            // 
            // col_Tax1Amount
            // 
            this.col_Tax1Amount.DataPropertyName = "Tax1Amount";
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Amount.DefaultCellStyle = dataGridViewCellStyle45;
            resources.ApplyResources(this.col_Tax1Amount, "col_Tax1Amount");
            this.col_Tax1Amount.Name = "col_Tax1Amount";
            this.col_Tax1Amount.ReadOnly = true;
            // 
            // col_FK_TAX2SlabID
            // 
            this.col_FK_TAX2SlabID.DataPropertyName = "FK_TAX2SlabID";
            resources.ApplyResources(this.col_FK_TAX2SlabID, "col_FK_TAX2SlabID");
            this.col_FK_TAX2SlabID.Name = "col_FK_TAX2SlabID";
            // 
            // col_Tax2Perc
            // 
            this.col_Tax2Perc.DataPropertyName = "Tax2Perc";
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Perc.DefaultCellStyle = dataGridViewCellStyle46;
            resources.ApplyResources(this.col_Tax2Perc, "col_Tax2Perc");
            this.col_Tax2Perc.Name = "col_Tax2Perc";
            this.col_Tax2Perc.ReadOnly = true;
            // 
            // col_Tax2Amount
            // 
            this.col_Tax2Amount.DataPropertyName = "Tax2Amount";
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Amount.DefaultCellStyle = dataGridViewCellStyle47;
            resources.ApplyResources(this.col_Tax2Amount, "col_Tax2Amount");
            this.col_Tax2Amount.Name = "col_Tax2Amount";
            this.col_Tax2Amount.ReadOnly = true;
            // 
            // col_FK_TAX3SlabID
            // 
            this.col_FK_TAX3SlabID.DataPropertyName = "FK_TAX3SlabID";
            resources.ApplyResources(this.col_FK_TAX3SlabID, "col_FK_TAX3SlabID");
            this.col_FK_TAX3SlabID.Name = "col_FK_TAX3SlabID";
            // 
            // col_Tax3Perc
            // 
            this.col_Tax3Perc.DataPropertyName = "Tax3Perc";
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Perc.DefaultCellStyle = dataGridViewCellStyle48;
            resources.ApplyResources(this.col_Tax3Perc, "col_Tax3Perc");
            this.col_Tax3Perc.Name = "col_Tax3Perc";
            this.col_Tax3Perc.ReadOnly = true;
            // 
            // col_Tax3Amount
            // 
            this.col_Tax3Amount.DataPropertyName = "Tax3Amount";
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Amount.DefaultCellStyle = dataGridViewCellStyle49;
            resources.ApplyResources(this.col_Tax3Amount, "col_Tax3Amount");
            this.col_Tax3Amount.Name = "col_Tax3Amount";
            this.col_Tax3Amount.ReadOnly = true;
            // 
            // col_FK_AddnlTaxSlabID
            // 
            this.col_FK_AddnlTaxSlabID.DataPropertyName = "FK_AddnlTaxSlabID";
            resources.ApplyResources(this.col_FK_AddnlTaxSlabID, "col_FK_AddnlTaxSlabID");
            this.col_FK_AddnlTaxSlabID.Name = "col_FK_AddnlTaxSlabID";
            // 
            // col_AddnlTaxPerc
            // 
            this.col_AddnlTaxPerc.DataPropertyName = "AddnlTaxPerc";
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxPerc.DefaultCellStyle = dataGridViewCellStyle50;
            resources.ApplyResources(this.col_AddnlTaxPerc, "col_AddnlTaxPerc");
            this.col_AddnlTaxPerc.Name = "col_AddnlTaxPerc";
            this.col_AddnlTaxPerc.ReadOnly = true;
            // 
            // col_AddnlTaxAmount
            // 
            this.col_AddnlTaxAmount.DataPropertyName = "AddnlTaxAmount";
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxAmount.DefaultCellStyle = dataGridViewCellStyle51;
            resources.ApplyResources(this.col_AddnlTaxAmount, "col_AddnlTaxAmount");
            this.col_AddnlTaxAmount.Name = "col_AddnlTaxAmount";
            this.col_AddnlTaxAmount.ReadOnly = true;
            // 
            // col_VATPerc
            // 
            this.col_VATPerc.DataPropertyName = "VATPerc";
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATPerc.DefaultCellStyle = dataGridViewCellStyle52;
            resources.ApplyResources(this.col_VATPerc, "col_VATPerc");
            this.col_VATPerc.Name = "col_VATPerc";
            this.col_VATPerc.ReadOnly = true;
            // 
            // col_VATAmount
            // 
            this.col_VATAmount.DataPropertyName = "VATAmount";
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATAmount.DefaultCellStyle = dataGridViewCellStyle53;
            resources.ApplyResources(this.col_VATAmount, "col_VATAmount");
            this.col_VATAmount.Name = "col_VATAmount";
            this.col_VATAmount.ReadOnly = true;
            // 
            // col_FK_GSTSlabID
            // 
            this.col_FK_GSTSlabID.DataPropertyName = "FK_GSTSlabID";
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_GSTSlabID.DefaultCellStyle = dataGridViewCellStyle54;
            resources.ApplyResources(this.col_FK_GSTSlabID, "col_FK_GSTSlabID");
            this.col_FK_GSTSlabID.Name = "col_FK_GSTSlabID";
            // 
            // col_CGSTPerc
            // 
            this.col_CGSTPerc.DataPropertyName = "CGSTPerc";
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTPerc.DefaultCellStyle = dataGridViewCellStyle55;
            resources.ApplyResources(this.col_CGSTPerc, "col_CGSTPerc");
            this.col_CGSTPerc.Name = "col_CGSTPerc";
            this.col_CGSTPerc.ReadOnly = true;
            // 
            // col_CGSTAmount
            // 
            this.col_CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTAmount.DefaultCellStyle = dataGridViewCellStyle56;
            resources.ApplyResources(this.col_CGSTAmount, "col_CGSTAmount");
            this.col_CGSTAmount.Name = "col_CGSTAmount";
            this.col_CGSTAmount.ReadOnly = true;
            // 
            // col_SGSTPerc
            // 
            this.col_SGSTPerc.DataPropertyName = "SGSTPerc";
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTPerc.DefaultCellStyle = dataGridViewCellStyle57;
            resources.ApplyResources(this.col_SGSTPerc, "col_SGSTPerc");
            this.col_SGSTPerc.Name = "col_SGSTPerc";
            this.col_SGSTPerc.ReadOnly = true;
            // 
            // col_SGSTAmount
            // 
            this.col_SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTAmount.DefaultCellStyle = dataGridViewCellStyle58;
            resources.ApplyResources(this.col_SGSTAmount, "col_SGSTAmount");
            this.col_SGSTAmount.Name = "col_SGSTAmount";
            this.col_SGSTAmount.ReadOnly = true;
            // 
            // col_IGSTPerc
            // 
            this.col_IGSTPerc.DataPropertyName = "IGSTPerc";
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTPerc.DefaultCellStyle = dataGridViewCellStyle59;
            resources.ApplyResources(this.col_IGSTPerc, "col_IGSTPerc");
            this.col_IGSTPerc.Name = "col_IGSTPerc";
            this.col_IGSTPerc.ReadOnly = true;
            // 
            // col_IGSTAmount
            // 
            this.col_IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTAmount.DefaultCellStyle = dataGridViewCellStyle60;
            resources.ApplyResources(this.col_IGSTAmount, "col_IGSTAmount");
            this.col_IGSTAmount.Name = "col_IGSTAmount";
            this.col_IGSTAmount.ReadOnly = true;
            // 
            // col_InclusiveRate
            // 
            this.col_InclusiveRate.DataPropertyName = "InclusiveRate";
            resources.ApplyResources(this.col_InclusiveRate, "col_InclusiveRate");
            this.col_InclusiveRate.Name = "col_InclusiveRate";
            // 
            // col_NetAmount
            // 
            this.col_NetAmount.DataPropertyName = "NetAmount";
            dataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_NetAmount.DefaultCellStyle = dataGridViewCellStyle61;
            resources.ApplyResources(this.col_NetAmount, "col_NetAmount");
            this.col_NetAmount.Name = "col_NetAmount";
            this.col_NetAmount.ReadOnly = true;
            // 
            // col_FK_VATSlabID
            // 
            this.col_FK_VATSlabID.DataPropertyName = "FK_VATSlabID";
            resources.ApplyResources(this.col_FK_VATSlabID, "col_FK_VATSlabID");
            this.col_FK_VATSlabID.Name = "col_FK_VATSlabID";
            // 
            // lblGrandTotal
            // 
            resources.ApplyResources(this.lblGrandTotal, "lblGrandTotal");
            this.lblGrandTotal.BackColor = System.Drawing.SystemColors.Window;
            this.lblGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.lblGrandTotal, resources.GetString("lblGrandTotal.Error"));
            this.lblGrandTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.lblGrandTotal.Format = "N2";
            this.errProvider.SetIconAlignment(this.lblGrandTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblGrandTotal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblGrandTotal, ((int)(resources.GetObject("lblGrandTotal.IconPadding"))));
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.RequiredField = false;
            this.lblGrandTotal.UseCompatibleTextRendering = true;
            this.lblGrandTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atlblTot
            // 
            resources.ApplyResources(this.atlblTot, "atlblTot");
            this.atlblTot.BackColor = System.Drawing.Color.Transparent;
            this.errProvider.SetError(this.atlblTot, resources.GetString("atlblTot.Error"));
            this.errProvider.SetIconAlignment(this.atlblTot, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atlblTot.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atlblTot, ((int)(resources.GetObject("atlblTot.IconPadding"))));
            this.atlblTot.Name = "atlblTot";
            this.atlblTot.RequiredField = false;
            // 
            // pnlFooter
            // 
            resources.ApplyResources(this.pnlFooter, "pnlFooter");
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.grpDiscountVoucher);
            this.pnlFooter.Controls.Add(this.txtTotalTax);
            this.pnlFooter.Controls.Add(this.lblTotalTax);
            this.pnlFooter.Controls.Add(this.lblTotalDisc);
            this.pnlFooter.Controls.Add(this.lblBalance);
            this.pnlFooter.Controls.Add(this.lblPayment);
            this.pnlFooter.Controls.Add(this.txtTotalDiscount);
            this.pnlFooter.Controls.Add(this.lblNetTotal);
            this.pnlFooter.Controls.Add(this.txtNetTotal);
            this.pnlFooter.Controls.Add(this.txtPayment);
            this.pnlFooter.Controls.Add(this.txtGross);
            this.pnlFooter.Controls.Add(this.txtBalance);
            this.pnlFooter.Controls.Add(this.lblNetAmount);
            this.pnlFooter.Controls.Add(this.lblTotQty);
            this.pnlFooter.Controls.Add(this.totqtycap);
            this.errProvider.SetError(this.pnlFooter, resources.GetString("pnlFooter.Error"));
            this.errProvider.SetIconAlignment(this.pnlFooter, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlFooter.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlFooter, ((int)(resources.GetObject("pnlFooter.IconPadding"))));
            this.pnlFooter.Name = "pnlFooter";
            // 
            // grpDiscountVoucher
            // 
            resources.ApplyResources(this.grpDiscountVoucher, "grpDiscountVoucher");
            this.grpDiscountVoucher.BackColor = System.Drawing.Color.Transparent;
            this.grpDiscountVoucher.Controls.Add(this.lblVoucherDiscountAccount);
            this.grpDiscountVoucher.Controls.Add(this.lblVoucherDiscountPerc);
            this.grpDiscountVoucher.Controls.Add(this.cmbVoucherDiscount);
            this.grpDiscountVoucher.Controls.Add(this.txtVoucherDiscAmount);
            this.errProvider.SetError(this.grpDiscountVoucher, resources.GetString("grpDiscountVoucher.Error"));
            this.errProvider.SetIconAlignment(this.grpDiscountVoucher, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("grpDiscountVoucher.IconAlignment"))));
            this.errProvider.SetIconPadding(this.grpDiscountVoucher, ((int)(resources.GetObject("grpDiscountVoucher.IconPadding"))));
            this.grpDiscountVoucher.Name = "grpDiscountVoucher";
            this.grpDiscountVoucher.TabStop = false;
            // 
            // txtVoucherDiscAmount
            // 
            resources.ApplyResources(this.txtVoucherDiscAmount, "txtVoucherDiscAmount");
            this.txtVoucherDiscAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtVoucherDiscAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtVoucherDiscAmount, resources.GetString("txtVoucherDiscAmount.Error"));
            this.txtVoucherDiscAmount.Format = null;
            this.errProvider.SetIconAlignment(this.txtVoucherDiscAmount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtVoucherDiscAmount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtVoucherDiscAmount, ((int)(resources.GetObject("txtVoucherDiscAmount.IconPadding"))));
            this.txtVoucherDiscAmount.isAllowNegative = false;
            this.txtVoucherDiscAmount.isAllowSpecialChar = false;
            this.txtVoucherDiscAmount.isNumbersOnly = false;
            this.txtVoucherDiscAmount.isNumeric = true;
            this.txtVoucherDiscAmount.isTouchable = true;
            this.txtVoucherDiscAmount.Name = "txtVoucherDiscAmount";
            this.txtVoucherDiscAmount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtTotalTax
            // 
            resources.ApplyResources(this.txtTotalTax, "txtTotalTax");
            this.txtTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtTotalTax, resources.GetString("txtTotalTax.Error"));
            this.txtTotalTax.ForeColor = System.Drawing.Color.Black;
            this.txtTotalTax.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtTotalTax, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTotalTax.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtTotalTax, ((int)(resources.GetObject("txtTotalTax.IconPadding"))));
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.RequiredField = false;
            this.txtTotalTax.UseCompatibleTextRendering = true;
            this.txtTotalTax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotalTax
            // 
            resources.ApplyResources(this.lblTotalTax, "lblTotalTax");
            this.lblTotalTax.DisabledLinkColor = System.Drawing.Color.Red;
            this.errProvider.SetError(this.lblTotalTax, resources.GetString("lblTotalTax.Error"));
            this.lblTotalTax.Format = null;
            this.errProvider.SetIconAlignment(this.lblTotalTax, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalTax.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTotalTax, ((int)(resources.GetObject("lblTotalTax.IconPadding"))));
            this.lblTotalTax.lblAddnlTax = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblCGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblExciseDuty = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblIGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblSGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax1 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax2 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax3 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblVAT = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblTotalTax.LinkColor = System.Drawing.Color.Black;
            this.lblTotalTax.Name = "lblTotalTax";
            this.lblTotalTax.TabStop = true;
            this.lblTotalTax.VisitedLinkColor = System.Drawing.Color.Blue;
            // 
            // lblTotalDisc
            // 
            resources.ApplyResources(this.lblTotalDisc, "lblTotalDisc");
            this.errProvider.SetError(this.lblTotalDisc, resources.GetString("lblTotalDisc.Error"));
            this.errProvider.SetIconAlignment(this.lblTotalDisc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalDisc.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTotalDisc, ((int)(resources.GetObject("lblTotalDisc.IconPadding"))));
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.RequiredField = false;
            // 
            // lblPayment
            // 
            resources.ApplyResources(this.lblPayment, "lblPayment");
            this.errProvider.SetError(this.lblPayment, resources.GetString("lblPayment.Error"));
            this.errProvider.SetIconAlignment(this.lblPayment, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblPayment.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblPayment, ((int)(resources.GetObject("lblPayment.IconPadding"))));
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.RequiredField = false;
            // 
            // txtTotalDiscount
            // 
            resources.ApplyResources(this.txtTotalDiscount, "txtTotalDiscount");
            this.txtTotalDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtTotalDiscount, resources.GetString("txtTotalDiscount.Error"));
            this.txtTotalDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalDiscount.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtTotalDiscount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTotalDiscount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtTotalDiscount, ((int)(resources.GetObject("txtTotalDiscount.IconPadding"))));
            this.txtTotalDiscount.Name = "txtTotalDiscount";
            this.txtTotalDiscount.RequiredField = false;
            this.txtTotalDiscount.UseCompatibleTextRendering = true;
            this.txtTotalDiscount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // LaundryView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.pnlGrid);
            this.Controls.Add(this.pnlMain);
            this.Name = "LaundryView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.LaundryView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.LaundryView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.LaundryView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.LaundryView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.LaundryView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.LaundryView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.LaundryView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.LaundryView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.LaundryView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.LaundryView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.LaundryView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.LaundryView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.LaundryView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlGrid, 0);
            this.Controls.SetChildIndex(this.pnlFooter, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindExtraServiceDTL)).EndInit();
            this.pnlFooter.ResumeLayout(false);
            this.pnlFooter.PerformLayout();
            this.grpDiscountVoucher.ResumeLayout(false);
            this.grpDiscountVoucher.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.ComboBoxExt cmbGuest;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atLabel lblMobileNumber;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.ComboBoxExt cmbRoom;
        private atACCFramework.UserControls.atNumericLabel lblTotQty;
        private atACCFramework.UserControls.atLabel totqtycap;
        private atACCFramework.UserControls.atButton btnPayment;
        private atACCFramework.UserControls.TextBoxNormal txtBalance;
        private atACCFramework.UserControls.atNumericLabel txtPayment;
        private atACCFramework.UserControls.atLabel lblBalance;
        private atACCFramework.UserControls.atNumericLabel txtNetTotal;
        private atACCFramework.UserControls.atLabel lblNetTotal;
        private atACCFramework.UserControls.atPanel pnlGrid;
        private atACCFramework.UserControls.atGridView dgDetails;
        private atACCFramework.UserControls.atNumericLabel lblGrandTotal;
        private atACCFramework.UserControls.atLabel atlblTot;
        private System.Windows.Forms.BindingSource bindExtraServiceDTL;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.ComboBoxExt cmbVoucherDiscount;
        private atACCFramework.UserControls.atLabel lblVoucherDiscountPerc;
        private atACCFramework.UserControls.atLabel lblVoucherDiscountAccount;
        private atACCFramework.UserControls.TextBoxExt txtDeductionPerc;
        private atACCFramework.UserControls.atLabel lblDeductionPerc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private atACCFramework.UserControls.atNumericLabel txtGross;
        private atACCFramework.UserControls.atLabel lblNetAmount;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private atACCFramework.UserControls.TextBoxExt txtVoucherDiscAmount;
        private atACCFramework.UserControls.atLabel lblPayment;
        private atACCFramework.UserControls.atLabel lblCurrencyCap;
        private atACCFramework.UserControls.TextBoxExt txtExRate;
        private atACCFramework.UserControls.ComboBoxExt cmbCurrency;
        private atACCFramework.UserControls.atLabel lblExRateCap;
        private atACCFramework.UserControls.atNumericLabel txtTotalTax;
        private atACCFramework.UserControls.TaxLabel lblTotalTax;
        private atACCFramework.UserControls.atLabel lblTotalDisc;
        private atACCFramework.UserControls.atNumericLabel txtTotalDiscount;
        private atACCFramework.UserControls.atGroupBox grpDiscountVoucher;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Service;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExtraServiceID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_DiscountSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscountPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TaxableAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExcisePerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExciseAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExciseSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX1SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX2SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX3SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_AddnlTaxSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_GSTSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_InclusiveRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_NetAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_VATSlabID;
        private System.Windows.Forms.Label lblMandatory3;
    }
}