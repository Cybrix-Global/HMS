﻿namespace atACC.HTL.Transactions
{
    partial class GroupCheckOutView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroupCheckOutView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.pnlDetails = new atACCFramework.UserControls.atPanel();
            this.txtExRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblExRateCap = new atACCFramework.UserControls.atLabel();
            this.btnGrpCheckIn = new System.Windows.Forms.Button();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.txtNoOfDays = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfDays = new atACCFramework.UserControls.atLabel();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.cmbGrpCheckIn = new atACCFramework.UserControls.ComboBoxExt();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.cmbCurrency = new atACCFramework.UserControls.ComboBoxExt();
            this.lblCurrencyCap = new atACCFramework.UserControls.atLabel();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.lblGrpCheckIn = new atACCFramework.UserControls.atLabel();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.dgRoom = new atACCFramework.UserControls.atGridView();
            this.col_Room = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgDetails = new atACCFramework.UserControls.atGridView();
            this.col_slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExtraServiceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_InclusiveRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_DiscountSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscountPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TaxableAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExciseSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExcisePerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExciseAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX1SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX2SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX3SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_AddnlTaxSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_GSTSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_NetAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_VATSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtGrpCheckInTotal = new atACCFramework.UserControls.atNumericLabel();
            this.btnRefund = new atACCFramework.UserControls.atButton();
            this.txtRefund = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotQty = new atACCFramework.UserControls.atNumericLabel();
            this.totqtycap = new atACCFramework.UserControls.atLabel();
            this.txtAdvance = new atACCFramework.UserControls.atNumericLabel();
            this.lblAdvance = new atACCFramework.UserControls.atLabel();
            this.txtGross = new atACCFramework.UserControls.atNumericLabel();
            this.lblExtraServices = new atACCFramework.UserControls.atLabel();
            this.txtTotalDiscount = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotalDisc = new atACCFramework.UserControls.atLabel();
            this.lblTotalTax = new atACCFramework.UserControls.TaxLabel();
            this.btnPayment = new atACCFramework.UserControls.atButton();
            this.txtBalance = new atACCFramework.UserControls.TextBoxNormal();
            this.txtPayment = new atACCFramework.UserControls.atNumericLabel();
            this.lblBalance = new atACCFramework.UserControls.atLabel();
            this.txtNetTotal = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetTotal = new atACCFramework.UserControls.atLabel();
            this.txtTotalTax = new atACCFramework.UserControls.atNumericLabel();
            this.btnSeperator1 = new System.Windows.Forms.Button();
            this.lblGrandTotal = new atACCFramework.UserControls.atNumericLabel();
            this.atlblTot = new atACCFramework.UserControls.atLabel();
            this.bindExtraServiceDTL = new System.Windows.Forms.BindingSource(this.components);
            this.bindRoom = new System.Windows.Forms.BindingSource(this.components);
            this.pnlGridContain = new atACCFramework.UserControls.atPanel();
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.txtAddnlRoundoff = new atACCFramework.UserControls.TextBoxNormal();
            this.lblAdnlRoundoff = new atACCFramework.UserControls.atLabel();
            this.lblExternal = new atACC.HTL.Transactions.AccountLabel();
            this.txtExternalAmt = new atACCFramework.UserControls.atNumericLabel();
            this.lblOpBalance = new atACC.HTL.Transactions.AccountLabel();
            this.txtOpBalance = new atACCFramework.UserControls.atNumericLabel();
            this.lblGroupCheckIn = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlHeader2.SuspendLayout();
            this.pnlDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindExtraServiceDTL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindRoom)).BeginInit();
            this.pnlGridContain.SuspendLayout();
            this.pnlFooter.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblGrandTotal);
            this.panel1.Controls.Add(this.atlblTot);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.SetChildIndex(this.atlblTot, 0);
            this.panel1.Controls.SetChildIndex(this.lblGrandTotal, 0);
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // pnlDetails
            // 
            resources.ApplyResources(this.pnlDetails, "pnlDetails");
            this.pnlDetails.BackColor = System.Drawing.SystemColors.Window;
            this.pnlDetails.Controls.Add(this.txtExRate);
            this.pnlDetails.Controls.Add(this.lblExRateCap);
            this.pnlDetails.Controls.Add(this.btnGrpCheckIn);
            this.pnlDetails.Controls.Add(this.txtTelephone);
            this.pnlDetails.Controls.Add(this.cmbEmployee);
            this.pnlDetails.Controls.Add(this.txtRemarks);
            this.pnlDetails.Controls.Add(this.lblEmployee);
            this.pnlDetails.Controls.Add(this.lblRemarks);
            this.pnlDetails.Controls.Add(this.txtAdd1);
            this.pnlDetails.Controls.Add(this.txtNoOfDays);
            this.pnlDetails.Controls.Add(this.lblNoOfDays);
            this.pnlDetails.Controls.Add(this.lblMandatory3);
            this.pnlDetails.Controls.Add(this.cmbGrpCheckIn);
            this.pnlDetails.Controls.Add(this.dtpArrivalDate);
            this.pnlDetails.Controls.Add(this.dtpDepartureDate);
            this.pnlDetails.Controls.Add(this.lblDepartureDate);
            this.pnlDetails.Controls.Add(this.lblArrivalDate);
            this.pnlDetails.Controls.Add(this.txtGuest);
            this.pnlDetails.Controls.Add(this.txtMobile);
            this.pnlDetails.Controls.Add(this.lblMandatory1);
            this.pnlDetails.Controls.Add(this.lblMandatory2);
            this.pnlDetails.Controls.Add(this.lblMandatory4);
            this.pnlDetails.Controls.Add(this.cmbCurrency);
            this.pnlDetails.Controls.Add(this.lblCurrencyCap);
            this.pnlDetails.Controls.Add(this.lblTelephone);
            this.pnlDetails.Controls.Add(this.lblAddress1);
            this.pnlDetails.Controls.Add(this.lblGrpCheckIn);
            this.pnlDetails.Controls.Add(this.lblGuest);
            this.pnlDetails.Name = "pnlDetails";
            // 
            // txtExRate
            // 
            this.txtExRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtExRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtExRate, "txtExRate");
            this.txtExRate.Format = null;
            this.txtExRate.isAllowNegative = false;
            this.txtExRate.isAllowSpecialChar = false;
            this.txtExRate.isNumbersOnly = false;
            this.txtExRate.isNumeric = true;
            this.txtExRate.isTouchable = false;
            this.txtExRate.Name = "txtExRate";
            this.txtExRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtExRate.Enter += new System.EventHandler(this.txtExRate_Enter);
            this.txtExRate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtExRate_KeyUp);
            // 
            // lblExRateCap
            // 
            resources.ApplyResources(this.lblExRateCap, "lblExRateCap");
            this.lblExRateCap.Name = "lblExRateCap";
            this.lblExRateCap.RequiredField = false;
            // 
            // btnGrpCheckIn
            // 
            resources.ApplyResources(this.btnGrpCheckIn, "btnGrpCheckIn");
            this.btnGrpCheckIn.FlatAppearance.BorderSize = 0;
            this.btnGrpCheckIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            this.btnGrpCheckIn.Name = "btnGrpCheckIn";
            this.btnGrpCheckIn.UseVisualStyleBackColor = true;
            this.btnGrpCheckIn.Click += new System.EventHandler(this.btnGrpCheckIn_Click);
            // 
            // txtTelephone
            // 
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.Format = null;
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = false;
            this.txtTelephone.isNumeric = true;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.TabStop = false;
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // cmbEmployee
            // 
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.errProvider.SetIconAlignment(this.lblRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRemarks.IconAlignment"))));
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // txtAdd1
            // 
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.Format = null;
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.ReadOnly = true;
            this.txtAdd1.TabStop = false;
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtNoOfDays
            // 
            resources.ApplyResources(this.txtNoOfDays, "txtNoOfDays");
            this.txtNoOfDays.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfDays.Format = null;
            this.txtNoOfDays.isAllowNegative = false;
            this.txtNoOfDays.isAllowSpecialChar = false;
            this.txtNoOfDays.isNumbersOnly = false;
            this.txtNoOfDays.isNumeric = true;
            this.txtNoOfDays.isTouchable = true;
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.ReadOnly = true;
            this.txtNoOfDays.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNoOfDays
            // 
            resources.ApplyResources(this.lblNoOfDays, "lblNoOfDays");
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.RequiredField = false;
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // cmbGrpCheckIn
            // 
            this.cmbGrpCheckIn.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGrpCheckIn.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGrpCheckIn.DropDownHeight = 300;
            resources.ApplyResources(this.cmbGrpCheckIn, "cmbGrpCheckIn");
            this.cmbGrpCheckIn.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGrpCheckIn, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGrpCheckIn.IconAlignment"))));
            this.cmbGrpCheckIn.Name = "cmbGrpCheckIn";
            this.cmbGrpCheckIn.SelectedValueChanged += new System.EventHandler(this.cmbGrpCheckIn_SelectedValueChanged);
            // 
            // dtpArrivalDate
            // 
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // dtpDepartureDate
            // 
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // txtGuest
            // 
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.Format = null;
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.ReadOnly = true;
            this.txtGuest.TabStop = false;
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtMobile
            // 
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.Format = null;
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = false;
            this.txtMobile.isNumeric = true;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.ReadOnly = true;
            this.txtMobile.TabStop = false;
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // cmbCurrency
            // 
            this.cmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCurrency.DropDownHeight = 300;
            this.cmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbCurrency, "cmbCurrency");
            this.cmbCurrency.FormattingEnabled = true;
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency_SelectedIndexChanged);
            // 
            // lblCurrencyCap
            // 
            resources.ApplyResources(this.lblCurrencyCap, "lblCurrencyCap");
            this.lblCurrencyCap.Name = "lblCurrencyCap";
            this.lblCurrencyCap.RequiredField = false;
            // 
            // lblTelephone
            // 
            resources.ApplyResources(this.lblTelephone, "lblTelephone");
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // lblGrpCheckIn
            // 
            resources.ApplyResources(this.lblGrpCheckIn, "lblGrpCheckIn");
            this.lblGrpCheckIn.Name = "lblGrpCheckIn";
            this.lblGrpCheckIn.RequiredField = false;
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // dgRoom
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgRoom.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            resources.ApplyResources(this.dgRoom, "dgRoom");
            this.dgRoom.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgRoom.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgRoom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgRoom.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_Room});
            this.dgRoom.EnableHeadersVisualStyles = false;
            this.dgRoom.EnterKeyNavigation = false;
            this.dgRoom.LastKey = System.Windows.Forms.Keys.None;
            this.dgRoom.Name = "dgRoom";
            dataGridViewCellStyle4.NullValue = null;
            this.dgRoom.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgRoom.sGridID = null;
            // 
            // col_Room
            // 
            this.col_Room.DataPropertyName = "FK_RoomID";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.col_Room.DefaultCellStyle = dataGridViewCellStyle3;
            this.col_Room.FillWeight = 286.4355F;
            this.col_Room.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_Room, "col_Room");
            this.col_Room.Name = "col_Room";
            this.col_Room.ReadOnly = true;
            this.col_Room.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Room.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dgDetails
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_slno,
            this.col_Code,
            this.col_Service,
            this.col_FK_ExtraServiceID,
            this.col_Qty,
            this.col_Rate,
            this.col_InclusiveRate,
            this.col_Amount,
            this.col_DeductionPerc,
            this.col_DeductionAmount,
            this.col_TotalTax,
            this.col_FK_DiscountSlabID,
            this.col_SlabDiscountPerc,
            this.col_SlabDiscount,
            this.col_TotalDiscount,
            this.col_TaxableAmount,
            this.col_FK_ExciseSlabID,
            this.col_ExcisePerc,
            this.col_ExciseAmount,
            this.col_FK_TAX1SlabID,
            this.col_Tax1Perc,
            this.col_Tax1Amount,
            this.col_FK_TAX2SlabID,
            this.col_Tax2Perc,
            this.col_Tax2Amount,
            this.col_FK_TAX3SlabID,
            this.col_Tax3Perc,
            this.col_Tax3Amount,
            this.col_FK_AddnlTaxSlabID,
            this.col_AddnlTaxPerc,
            this.col_AddnlTaxAmount,
            this.col_VATPerc,
            this.col_VATAmount,
            this.col_FK_GSTSlabID,
            this.col_CGSTPerc,
            this.col_CGSTAmount,
            this.col_SGSTPerc,
            this.col_SGSTAmount,
            this.col_IGSTPerc,
            this.col_IGSTAmount,
            this.col_NetAmount,
            this.col_FK_VATSlabID});
            this.dgDetails.EnableHeadersVisualStyles = false;
            this.dgDetails.EnterKeyNavigation = false;
            this.dgDetails.LastKey = System.Windows.Forms.Keys.None;
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle36.NullValue = null;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle36;
            this.dgDetails.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.dgDetails.sGridID = null;
            this.dgDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgDetails_CellBeginEdit);
            this.dgDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEndEdit);
            this.dgDetails.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEnter);
            this.dgDetails.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgDetails_CellValidating);
            this.dgDetails.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgDetails_DataError);
            this.dgDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgDetails_EditingControlShowing);
            this.dgDetails.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgDetails_RowsAdded);
            this.dgDetails.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgDetails_RowsRemoved);
            this.dgDetails.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgDetails_KeyDown);
            // 
            // col_slno
            // 
            this.col_slno.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_slno.DataPropertyName = "SlNo";
            this.col_slno.FillWeight = 111.905F;
            resources.ApplyResources(this.col_slno, "col_slno");
            this.col_slno.Name = "col_slno";
            this.col_slno.ReadOnly = true;
            // 
            // col_Code
            // 
            this.col_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Code.DataPropertyName = "ServiceCode";
            this.col_Code.FillWeight = 95.68391F;
            resources.ApplyResources(this.col_Code, "col_Code");
            this.col_Code.Name = "col_Code";
            this.col_Code.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // col_Service
            // 
            this.col_Service.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Service.DataPropertyName = "ServiceName";
            this.col_Service.FillWeight = 286.4355F;
            resources.ApplyResources(this.col_Service, "col_Service");
            this.col_Service.Name = "col_Service";
            this.col_Service.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Service.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // col_FK_ExtraServiceID
            // 
            this.col_FK_ExtraServiceID.DataPropertyName = "FK_ExtraServiceID";
            resources.ApplyResources(this.col_FK_ExtraServiceID, "col_FK_ExtraServiceID");
            this.col_FK_ExtraServiceID.Name = "col_FK_ExtraServiceID";
            this.col_FK_ExtraServiceID.ReadOnly = true;
            // 
            // col_Qty
            // 
            this.col_Qty.DataPropertyName = "Qty";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_Qty.DefaultCellStyle = dataGridViewCellStyle7;
            this.col_Qty.FillWeight = 91.05099F;
            resources.ApplyResources(this.col_Qty, "col_Qty");
            this.col_Qty.Name = "col_Qty";
            // 
            // col_Rate
            // 
            this.col_Rate.DataPropertyName = "Rate";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Rate.DefaultCellStyle = dataGridViewCellStyle8;
            this.col_Rate.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Rate, "col_Rate");
            this.col_Rate.Name = "col_Rate";
            // 
            // col_InclusiveRate
            // 
            this.col_InclusiveRate.DataPropertyName = "InclusiveRate";
            resources.ApplyResources(this.col_InclusiveRate, "col_InclusiveRate");
            this.col_InclusiveRate.Name = "col_InclusiveRate";
            // 
            // col_Amount
            // 
            this.col_Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Amount.DefaultCellStyle = dataGridViewCellStyle9;
            this.col_Amount.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Amount, "col_Amount");
            this.col_Amount.Name = "col_Amount";
            this.col_Amount.ReadOnly = true;
            // 
            // col_DeductionPerc
            // 
            this.col_DeductionPerc.DataPropertyName = "DeductionPerc";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionPerc.DefaultCellStyle = dataGridViewCellStyle10;
            resources.ApplyResources(this.col_DeductionPerc, "col_DeductionPerc");
            this.col_DeductionPerc.Name = "col_DeductionPerc";
            // 
            // col_DeductionAmount
            // 
            this.col_DeductionAmount.DataPropertyName = "DeductionAmount";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionAmount.DefaultCellStyle = dataGridViewCellStyle11;
            resources.ApplyResources(this.col_DeductionAmount, "col_DeductionAmount");
            this.col_DeductionAmount.Name = "col_DeductionAmount";
            this.col_DeductionAmount.ReadOnly = true;
            // 
            // col_TotalTax
            // 
            this.col_TotalTax.DataPropertyName = "TotalTax";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TotalTax.DefaultCellStyle = dataGridViewCellStyle12;
            resources.ApplyResources(this.col_TotalTax, "col_TotalTax");
            this.col_TotalTax.Name = "col_TotalTax";
            this.col_TotalTax.ReadOnly = true;
            // 
            // col_FK_DiscountSlabID
            // 
            this.col_FK_DiscountSlabID.DataPropertyName = "FK_DiscountSlabID";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_DiscountSlabID.DefaultCellStyle = dataGridViewCellStyle13;
            resources.ApplyResources(this.col_FK_DiscountSlabID, "col_FK_DiscountSlabID");
            this.col_FK_DiscountSlabID.Name = "col_FK_DiscountSlabID";
            // 
            // col_SlabDiscountPerc
            // 
            this.col_SlabDiscountPerc.DataPropertyName = "SlabDiscountPerc";
            resources.ApplyResources(this.col_SlabDiscountPerc, "col_SlabDiscountPerc");
            this.col_SlabDiscountPerc.Name = "col_SlabDiscountPerc";
            // 
            // col_SlabDiscount
            // 
            this.col_SlabDiscount.DataPropertyName = "SlabDiscount";
            resources.ApplyResources(this.col_SlabDiscount, "col_SlabDiscount");
            this.col_SlabDiscount.Name = "col_SlabDiscount";
            // 
            // col_TotalDiscount
            // 
            this.col_TotalDiscount.DataPropertyName = "TotalDiscount";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TotalDiscount.DefaultCellStyle = dataGridViewCellStyle14;
            resources.ApplyResources(this.col_TotalDiscount, "col_TotalDiscount");
            this.col_TotalDiscount.Name = "col_TotalDiscount";
            // 
            // col_TaxableAmount
            // 
            this.col_TaxableAmount.DataPropertyName = "TaxableAmount";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TaxableAmount.DefaultCellStyle = dataGridViewCellStyle15;
            resources.ApplyResources(this.col_TaxableAmount, "col_TaxableAmount");
            this.col_TaxableAmount.Name = "col_TaxableAmount";
            this.col_TaxableAmount.ReadOnly = true;
            // 
            // col_FK_ExciseSlabID
            // 
            this.col_FK_ExciseSlabID.DataPropertyName = "FK_ExciseSlabID";
            resources.ApplyResources(this.col_FK_ExciseSlabID, "col_FK_ExciseSlabID");
            this.col_FK_ExciseSlabID.Name = "col_FK_ExciseSlabID";
            // 
            // col_ExcisePerc
            // 
            this.col_ExcisePerc.DataPropertyName = "ExcisePerc";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExcisePerc.DefaultCellStyle = dataGridViewCellStyle16;
            resources.ApplyResources(this.col_ExcisePerc, "col_ExcisePerc");
            this.col_ExcisePerc.Name = "col_ExcisePerc";
            this.col_ExcisePerc.ReadOnly = true;
            // 
            // col_ExciseAmount
            // 
            this.col_ExciseAmount.DataPropertyName = "ExciseAmount";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExciseAmount.DefaultCellStyle = dataGridViewCellStyle17;
            resources.ApplyResources(this.col_ExciseAmount, "col_ExciseAmount");
            this.col_ExciseAmount.Name = "col_ExciseAmount";
            this.col_ExciseAmount.ReadOnly = true;
            // 
            // col_FK_TAX1SlabID
            // 
            this.col_FK_TAX1SlabID.DataPropertyName = "FK_TAX1SlabID";
            resources.ApplyResources(this.col_FK_TAX1SlabID, "col_FK_TAX1SlabID");
            this.col_FK_TAX1SlabID.Name = "col_FK_TAX1SlabID";
            // 
            // col_Tax1Perc
            // 
            this.col_Tax1Perc.DataPropertyName = "Tax1Perc";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Perc.DefaultCellStyle = dataGridViewCellStyle18;
            resources.ApplyResources(this.col_Tax1Perc, "col_Tax1Perc");
            this.col_Tax1Perc.Name = "col_Tax1Perc";
            this.col_Tax1Perc.ReadOnly = true;
            // 
            // col_Tax1Amount
            // 
            this.col_Tax1Amount.DataPropertyName = "Tax1Amount";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Amount.DefaultCellStyle = dataGridViewCellStyle19;
            resources.ApplyResources(this.col_Tax1Amount, "col_Tax1Amount");
            this.col_Tax1Amount.Name = "col_Tax1Amount";
            this.col_Tax1Amount.ReadOnly = true;
            // 
            // col_FK_TAX2SlabID
            // 
            this.col_FK_TAX2SlabID.DataPropertyName = "FK_TAX2SlabID";
            resources.ApplyResources(this.col_FK_TAX2SlabID, "col_FK_TAX2SlabID");
            this.col_FK_TAX2SlabID.Name = "col_FK_TAX2SlabID";
            // 
            // col_Tax2Perc
            // 
            this.col_Tax2Perc.DataPropertyName = "Tax2Perc";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Perc.DefaultCellStyle = dataGridViewCellStyle20;
            resources.ApplyResources(this.col_Tax2Perc, "col_Tax2Perc");
            this.col_Tax2Perc.Name = "col_Tax2Perc";
            this.col_Tax2Perc.ReadOnly = true;
            // 
            // col_Tax2Amount
            // 
            this.col_Tax2Amount.DataPropertyName = "Tax2Amount";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Amount.DefaultCellStyle = dataGridViewCellStyle21;
            resources.ApplyResources(this.col_Tax2Amount, "col_Tax2Amount");
            this.col_Tax2Amount.Name = "col_Tax2Amount";
            this.col_Tax2Amount.ReadOnly = true;
            // 
            // col_FK_TAX3SlabID
            // 
            this.col_FK_TAX3SlabID.DataPropertyName = "FK_TAX3SlabID";
            resources.ApplyResources(this.col_FK_TAX3SlabID, "col_FK_TAX3SlabID");
            this.col_FK_TAX3SlabID.Name = "col_FK_TAX3SlabID";
            // 
            // col_Tax3Perc
            // 
            this.col_Tax3Perc.DataPropertyName = "Tax3Perc";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Perc.DefaultCellStyle = dataGridViewCellStyle22;
            resources.ApplyResources(this.col_Tax3Perc, "col_Tax3Perc");
            this.col_Tax3Perc.Name = "col_Tax3Perc";
            this.col_Tax3Perc.ReadOnly = true;
            // 
            // col_Tax3Amount
            // 
            this.col_Tax3Amount.DataPropertyName = "Tax3Amount";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Amount.DefaultCellStyle = dataGridViewCellStyle23;
            resources.ApplyResources(this.col_Tax3Amount, "col_Tax3Amount");
            this.col_Tax3Amount.Name = "col_Tax3Amount";
            this.col_Tax3Amount.ReadOnly = true;
            // 
            // col_FK_AddnlTaxSlabID
            // 
            this.col_FK_AddnlTaxSlabID.DataPropertyName = "FK_AddnlTaxSlabID";
            resources.ApplyResources(this.col_FK_AddnlTaxSlabID, "col_FK_AddnlTaxSlabID");
            this.col_FK_AddnlTaxSlabID.Name = "col_FK_AddnlTaxSlabID";
            // 
            // col_AddnlTaxPerc
            // 
            this.col_AddnlTaxPerc.DataPropertyName = "AddnlTaxPerc";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxPerc.DefaultCellStyle = dataGridViewCellStyle24;
            resources.ApplyResources(this.col_AddnlTaxPerc, "col_AddnlTaxPerc");
            this.col_AddnlTaxPerc.Name = "col_AddnlTaxPerc";
            this.col_AddnlTaxPerc.ReadOnly = true;
            // 
            // col_AddnlTaxAmount
            // 
            this.col_AddnlTaxAmount.DataPropertyName = "AddnlTaxAmount";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxAmount.DefaultCellStyle = dataGridViewCellStyle25;
            resources.ApplyResources(this.col_AddnlTaxAmount, "col_AddnlTaxAmount");
            this.col_AddnlTaxAmount.Name = "col_AddnlTaxAmount";
            this.col_AddnlTaxAmount.ReadOnly = true;
            // 
            // col_VATPerc
            // 
            this.col_VATPerc.DataPropertyName = "VATPerc";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATPerc.DefaultCellStyle = dataGridViewCellStyle26;
            resources.ApplyResources(this.col_VATPerc, "col_VATPerc");
            this.col_VATPerc.Name = "col_VATPerc";
            this.col_VATPerc.ReadOnly = true;
            // 
            // col_VATAmount
            // 
            this.col_VATAmount.DataPropertyName = "VATAmount";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATAmount.DefaultCellStyle = dataGridViewCellStyle27;
            resources.ApplyResources(this.col_VATAmount, "col_VATAmount");
            this.col_VATAmount.Name = "col_VATAmount";
            this.col_VATAmount.ReadOnly = true;
            // 
            // col_FK_GSTSlabID
            // 
            this.col_FK_GSTSlabID.DataPropertyName = "FK_GSTSlabID";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_GSTSlabID.DefaultCellStyle = dataGridViewCellStyle28;
            resources.ApplyResources(this.col_FK_GSTSlabID, "col_FK_GSTSlabID");
            this.col_FK_GSTSlabID.Name = "col_FK_GSTSlabID";
            // 
            // col_CGSTPerc
            // 
            this.col_CGSTPerc.DataPropertyName = "CGSTPerc";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTPerc.DefaultCellStyle = dataGridViewCellStyle29;
            resources.ApplyResources(this.col_CGSTPerc, "col_CGSTPerc");
            this.col_CGSTPerc.Name = "col_CGSTPerc";
            this.col_CGSTPerc.ReadOnly = true;
            // 
            // col_CGSTAmount
            // 
            this.col_CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTAmount.DefaultCellStyle = dataGridViewCellStyle30;
            resources.ApplyResources(this.col_CGSTAmount, "col_CGSTAmount");
            this.col_CGSTAmount.Name = "col_CGSTAmount";
            this.col_CGSTAmount.ReadOnly = true;
            // 
            // col_SGSTPerc
            // 
            this.col_SGSTPerc.DataPropertyName = "SGSTPerc";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTPerc.DefaultCellStyle = dataGridViewCellStyle31;
            resources.ApplyResources(this.col_SGSTPerc, "col_SGSTPerc");
            this.col_SGSTPerc.Name = "col_SGSTPerc";
            this.col_SGSTPerc.ReadOnly = true;
            // 
            // col_SGSTAmount
            // 
            this.col_SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTAmount.DefaultCellStyle = dataGridViewCellStyle32;
            resources.ApplyResources(this.col_SGSTAmount, "col_SGSTAmount");
            this.col_SGSTAmount.Name = "col_SGSTAmount";
            this.col_SGSTAmount.ReadOnly = true;
            // 
            // col_IGSTPerc
            // 
            this.col_IGSTPerc.DataPropertyName = "IGSTPerc";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTPerc.DefaultCellStyle = dataGridViewCellStyle33;
            resources.ApplyResources(this.col_IGSTPerc, "col_IGSTPerc");
            this.col_IGSTPerc.Name = "col_IGSTPerc";
            this.col_IGSTPerc.ReadOnly = true;
            // 
            // col_IGSTAmount
            // 
            this.col_IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTAmount.DefaultCellStyle = dataGridViewCellStyle34;
            resources.ApplyResources(this.col_IGSTAmount, "col_IGSTAmount");
            this.col_IGSTAmount.Name = "col_IGSTAmount";
            this.col_IGSTAmount.ReadOnly = true;
            // 
            // col_NetAmount
            // 
            this.col_NetAmount.DataPropertyName = "NetAmount";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_NetAmount.DefaultCellStyle = dataGridViewCellStyle35;
            resources.ApplyResources(this.col_NetAmount, "col_NetAmount");
            this.col_NetAmount.Name = "col_NetAmount";
            this.col_NetAmount.ReadOnly = true;
            // 
            // col_FK_VATSlabID
            // 
            this.col_FK_VATSlabID.DataPropertyName = "FK_VATSlabID";
            resources.ApplyResources(this.col_FK_VATSlabID, "col_FK_VATSlabID");
            this.col_FK_VATSlabID.Name = "col_FK_VATSlabID";
            // 
            // txtGrpCheckInTotal
            // 
            resources.ApplyResources(this.txtGrpCheckInTotal, "txtGrpCheckInTotal");
            this.txtGrpCheckInTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGrpCheckInTotal.ForeColor = System.Drawing.Color.Black;
            this.txtGrpCheckInTotal.Format = "N2";
            this.txtGrpCheckInTotal.Name = "txtGrpCheckInTotal";
            this.txtGrpCheckInTotal.RequiredField = false;
            this.txtGrpCheckInTotal.UseCompatibleTextRendering = true;
            this.txtGrpCheckInTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnRefund
            // 
            resources.ApplyResources(this.btnRefund, "btnRefund");
            this.btnRefund.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnRefund.FlatAppearance.BorderSize = 0;
            this.btnRefund.ForeColor = System.Drawing.Color.White;
            this.btnRefund.Name = "btnRefund";
            this.btnRefund.UseVisualStyleBackColor = false;
            this.btnRefund.Click += new System.EventHandler(this.btnRefund_Click);
            // 
            // txtRefund
            // 
            resources.ApplyResources(this.txtRefund, "txtRefund");
            this.txtRefund.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRefund.ForeColor = System.Drawing.Color.Black;
            this.txtRefund.Format = "N2";
            this.txtRefund.Name = "txtRefund";
            this.txtRefund.RequiredField = false;
            this.txtRefund.UseCompatibleTextRendering = true;
            this.txtRefund.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotQty
            // 
            resources.ApplyResources(this.lblTotQty, "lblTotQty");
            this.lblTotQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotQty.ForeColor = System.Drawing.Color.Black;
            this.lblTotQty.Format = "N2";
            this.lblTotQty.Name = "lblTotQty";
            this.lblTotQty.RequiredField = false;
            this.lblTotQty.UseCompatibleTextRendering = true;
            this.lblTotQty.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // totqtycap
            // 
            resources.ApplyResources(this.totqtycap, "totqtycap");
            this.errProvider.SetIconAlignment(this.totqtycap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("totqtycap.IconAlignment"))));
            this.totqtycap.Name = "totqtycap";
            this.totqtycap.RequiredField = false;
            // 
            // txtAdvance
            // 
            resources.ApplyResources(this.txtAdvance, "txtAdvance");
            this.txtAdvance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdvance.ForeColor = System.Drawing.Color.Black;
            this.txtAdvance.Format = "N2";
            this.txtAdvance.Name = "txtAdvance";
            this.txtAdvance.RequiredField = false;
            this.txtAdvance.UseCompatibleTextRendering = true;
            this.txtAdvance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAdvance
            // 
            resources.ApplyResources(this.lblAdvance, "lblAdvance");
            this.errProvider.SetIconAlignment(this.lblAdvance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdvance.IconAlignment"))));
            this.lblAdvance.Name = "lblAdvance";
            this.lblAdvance.RequiredField = false;
            // 
            // txtGross
            // 
            resources.ApplyResources(this.txtGross, "txtGross");
            this.txtGross.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGross.ForeColor = System.Drawing.Color.Black;
            this.txtGross.Format = "N2";
            this.txtGross.Name = "txtGross";
            this.txtGross.RequiredField = false;
            this.txtGross.UseCompatibleTextRendering = true;
            this.txtGross.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblExtraServices
            // 
            resources.ApplyResources(this.lblExtraServices, "lblExtraServices");
            this.errProvider.SetIconAlignment(this.lblExtraServices, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExtraServices.IconAlignment"))));
            this.lblExtraServices.Name = "lblExtraServices";
            this.lblExtraServices.RequiredField = false;
            // 
            // txtTotalDiscount
            // 
            resources.ApplyResources(this.txtTotalDiscount, "txtTotalDiscount");
            this.txtTotalDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalDiscount.Format = "N2";
            this.txtTotalDiscount.Name = "txtTotalDiscount";
            this.txtTotalDiscount.RequiredField = false;
            this.txtTotalDiscount.UseCompatibleTextRendering = true;
            this.txtTotalDiscount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotalDisc
            // 
            resources.ApplyResources(this.lblTotalDisc, "lblTotalDisc");
            this.errProvider.SetIconAlignment(this.lblTotalDisc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalDisc.IconAlignment"))));
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.RequiredField = false;
            // 
            // lblTotalTax
            // 
            resources.ApplyResources(this.lblTotalTax, "lblTotalTax");
            this.lblTotalTax.DisabledLinkColor = System.Drawing.Color.Red;
            this.lblTotalTax.Format = null;
            this.lblTotalTax.lblAddnlTax = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblCGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblExciseDuty = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblIGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblSGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax1 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax2 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax3 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblVAT = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblTotalTax.LinkColor = System.Drawing.Color.Black;
            this.lblTotalTax.Name = "lblTotalTax";
            this.lblTotalTax.TabStop = true;
            this.lblTotalTax.VisitedLinkColor = System.Drawing.Color.Blue;
            // 
            // btnPayment
            // 
            resources.ApplyResources(this.btnPayment, "btnPayment");
            this.btnPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnPayment.FlatAppearance.BorderSize = 0;
            this.btnPayment.ForeColor = System.Drawing.Color.White;
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // txtBalance
            // 
            resources.ApplyResources(this.txtBalance, "txtBalance");
            this.txtBalance.BackColor = System.Drawing.SystemColors.Window;
            this.txtBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBalance.Format = null;
            this.txtBalance.isAllowNegative = true;
            this.txtBalance.isAllowSpecialChar = false;
            this.txtBalance.isNumeric = true;
            this.txtBalance.isTouchable = false;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.TabStop = false;
            this.txtBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            // 
            // txtPayment
            // 
            resources.ApplyResources(this.txtPayment, "txtPayment");
            this.txtPayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Format = "N2";
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.RequiredField = false;
            this.txtPayment.UseCompatibleTextRendering = true;
            this.txtPayment.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBalance
            // 
            resources.ApplyResources(this.lblBalance, "lblBalance");
            this.errProvider.SetIconAlignment(this.lblBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblBalance.IconAlignment"))));
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.RequiredField = false;
            // 
            // txtNetTotal
            // 
            resources.ApplyResources(this.txtNetTotal, "txtNetTotal");
            this.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNetTotal.ForeColor = System.Drawing.Color.Black;
            this.txtNetTotal.Format = "N2";
            this.txtNetTotal.Name = "txtNetTotal";
            this.txtNetTotal.RequiredField = false;
            this.txtNetTotal.UseCompatibleTextRendering = true;
            this.txtNetTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetTotal
            // 
            resources.ApplyResources(this.lblNetTotal, "lblNetTotal");
            this.errProvider.SetIconAlignment(this.lblNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNetTotal.IconAlignment"))));
            this.lblNetTotal.Name = "lblNetTotal";
            this.lblNetTotal.RequiredField = false;
            // 
            // txtTotalTax
            // 
            resources.ApplyResources(this.txtTotalTax, "txtTotalTax");
            this.txtTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalTax.ForeColor = System.Drawing.Color.Black;
            this.txtTotalTax.Format = "N2";
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.RequiredField = false;
            this.txtTotalTax.UseCompatibleTextRendering = true;
            this.txtTotalTax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator1
            // 
            resources.ApplyResources(this.btnSeperator1, "btnSeperator1");
            this.btnSeperator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator1.Name = "btnSeperator1";
            this.btnSeperator1.UseVisualStyleBackColor = true;
            // 
            // lblGrandTotal
            // 
            resources.ApplyResources(this.lblGrandTotal, "lblGrandTotal");
            this.lblGrandTotal.BackColor = System.Drawing.SystemColors.Window;
            this.lblGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGrandTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.lblGrandTotal.Format = "N2";
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.RequiredField = false;
            this.lblGrandTotal.UseCompatibleTextRendering = true;
            this.lblGrandTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atlblTot
            // 
            resources.ApplyResources(this.atlblTot, "atlblTot");
            this.atlblTot.BackColor = System.Drawing.Color.Transparent;
            this.atlblTot.Name = "atlblTot";
            this.atlblTot.RequiredField = false;
            // 
            // pnlGridContain
            // 
            resources.ApplyResources(this.pnlGridContain, "pnlGridContain");
            this.pnlGridContain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlGridContain.Controls.Add(this.dgDetails);
            this.pnlGridContain.Name = "pnlGridContain";
            // 
            // pnlFooter
            // 
            resources.ApplyResources(this.pnlFooter, "pnlFooter");
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.txtAddnlRoundoff);
            this.pnlFooter.Controls.Add(this.lblAdnlRoundoff);
            this.pnlFooter.Controls.Add(this.lblExternal);
            this.pnlFooter.Controls.Add(this.txtExternalAmt);
            this.pnlFooter.Controls.Add(this.lblOpBalance);
            this.pnlFooter.Controls.Add(this.txtOpBalance);
            this.pnlFooter.Controls.Add(this.btnSeperator1);
            this.pnlFooter.Controls.Add(this.lblExtraServices);
            this.pnlFooter.Controls.Add(this.txtGross);
            this.pnlFooter.Controls.Add(this.lblGroupCheckIn);
            this.pnlFooter.Controls.Add(this.txtGrpCheckInTotal);
            this.pnlFooter.Controls.Add(this.totqtycap);
            this.pnlFooter.Controls.Add(this.lblTotQty);
            this.pnlFooter.Controls.Add(this.dgRoom);
            this.pnlFooter.Controls.Add(this.txtRefund);
            this.pnlFooter.Controls.Add(this.btnRefund);
            this.pnlFooter.Controls.Add(this.lblBalance);
            this.pnlFooter.Controls.Add(this.lblTotalDisc);
            this.pnlFooter.Controls.Add(this.txtTotalDiscount);
            this.pnlFooter.Controls.Add(this.txtAdvance);
            this.pnlFooter.Controls.Add(this.txtPayment);
            this.pnlFooter.Controls.Add(this.lblTotalTax);
            this.pnlFooter.Controls.Add(this.lblAdvance);
            this.pnlFooter.Controls.Add(this.txtTotalTax);
            this.pnlFooter.Controls.Add(this.lblNetTotal);
            this.pnlFooter.Controls.Add(this.txtNetTotal);
            this.pnlFooter.Controls.Add(this.txtBalance);
            this.pnlFooter.Controls.Add(this.btnPayment);
            this.pnlFooter.Name = "pnlFooter";
            // 
            // txtAddnlRoundoff
            // 
            resources.ApplyResources(this.txtAddnlRoundoff, "txtAddnlRoundoff");
            this.txtAddnlRoundoff.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddnlRoundoff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddnlRoundoff.Format = null;
            this.txtAddnlRoundoff.isAllowNegative = true;
            this.txtAddnlRoundoff.isAllowSpecialChar = false;
            this.txtAddnlRoundoff.isNumeric = true;
            this.txtAddnlRoundoff.isTouchable = false;
            this.txtAddnlRoundoff.Name = "txtAddnlRoundoff";
            this.txtAddnlRoundoff.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            // 
            // lblAdnlRoundoff
            // 
            resources.ApplyResources(this.lblAdnlRoundoff, "lblAdnlRoundoff");
            this.errProvider.SetIconAlignment(this.lblAdnlRoundoff, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdnlRoundoff.IconAlignment"))));
            this.lblAdnlRoundoff.Name = "lblAdnlRoundoff";
            this.lblAdnlRoundoff.RequiredField = false;
            // 
            // lblExternal
            // 
            resources.ApplyResources(this.lblExternal, "lblExternal");
            this.lblExternal.DataSource = null;
            this.lblExternal.ForeColor = System.Drawing.Color.Black;
            this.lblExternal.Format = null;
            this.errProvider.SetIconAlignment(this.lblExternal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExternal.IconAlignment"))));
            this.lblExternal.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblExternal.LinkColor = System.Drawing.SystemColors.ControlText;
            this.lblExternal.Name = "lblExternal";
            this.lblExternal.TabStop = true;
            // 
            // txtExternalAmt
            // 
            resources.ApplyResources(this.txtExternalAmt, "txtExternalAmt");
            this.txtExternalAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExternalAmt.ForeColor = System.Drawing.Color.Black;
            this.txtExternalAmt.Format = "N2";
            this.txtExternalAmt.Name = "txtExternalAmt";
            this.txtExternalAmt.RequiredField = false;
            this.txtExternalAmt.UseCompatibleTextRendering = true;
            this.txtExternalAmt.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblOpBalance
            // 
            resources.ApplyResources(this.lblOpBalance, "lblOpBalance");
            this.lblOpBalance.DataSource = null;
            this.lblOpBalance.ForeColor = System.Drawing.Color.Black;
            this.lblOpBalance.Format = null;
            this.errProvider.SetIconAlignment(this.lblOpBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblOpBalance.IconAlignment"))));
            this.lblOpBalance.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblOpBalance.LinkColor = System.Drawing.SystemColors.ControlText;
            this.lblOpBalance.Name = "lblOpBalance";
            this.lblOpBalance.TabStop = true;
            // 
            // txtOpBalance
            // 
            resources.ApplyResources(this.txtOpBalance, "txtOpBalance");
            this.txtOpBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOpBalance.ForeColor = System.Drawing.Color.Black;
            this.txtOpBalance.Format = "N2";
            this.txtOpBalance.Name = "txtOpBalance";
            this.txtOpBalance.RequiredField = false;
            this.txtOpBalance.UseCompatibleTextRendering = true;
            this.txtOpBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblGroupCheckIn
            // 
            resources.ApplyResources(this.lblGroupCheckIn, "lblGroupCheckIn");
            this.errProvider.SetIconAlignment(this.lblGroupCheckIn, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblGroupCheckIn.IconAlignment"))));
            this.lblGroupCheckIn.Name = "lblGroupCheckIn";
            this.lblGroupCheckIn.RequiredField = false;
            // 
            // GroupCheckOutView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlDetails);
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.pnlGridContain);
            this.Name = "GroupCheckOutView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.GroupCheckOutView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.GroupCheckOutView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.GroupCheckOutView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.GroupCheckOutView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.GroupCheckOutView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.GroupCheckOutView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.GroupCheckOutView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.GroupCheckOutView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.GroupCheckOutView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.GroupCheckOutView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.GroupCheckOutView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.GroupCheckOutView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.GroupCheckOutView_atBeforeSearch);
            this.Shown += new System.EventHandler(this.GroupCheckOutView_Shown);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlGridContain, 0);
            this.Controls.SetChildIndex(this.pnlFooter, 0);
            this.Controls.SetChildIndex(this.pnlDetails, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlDetails.ResumeLayout(false);
            this.pnlDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindExtraServiceDTL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindRoom)).EndInit();
            this.pnlGridContain.ResumeLayout(false);
            this.pnlFooter.ResumeLayout(false);
            this.pnlFooter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atPanel pnlDetails;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.TextBoxExt txtNoOfDays;
        private atACCFramework.UserControls.atLabel lblNoOfDays;
        private System.Windows.Forms.Label lblMandatory3;
        private atACCFramework.UserControls.ComboBoxExt cmbGrpCheckIn;
        private atACCFramework.UserControls.atLabel lblGrpCheckIn;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atGridView dgDetails;
        private atACCFramework.UserControls.atButton btnRefund;
        private atACCFramework.UserControls.atNumericLabel txtRefund;
        private atACCFramework.UserControls.atNumericLabel lblTotQty;
        private atACCFramework.UserControls.atLabel totqtycap;
        private atACCFramework.UserControls.atNumericLabel txtAdvance;
        private atACCFramework.UserControls.atLabel lblAdvance;
        private atACCFramework.UserControls.atNumericLabel txtGross;
        private atACCFramework.UserControls.atLabel lblExtraServices;
        private atACCFramework.UserControls.atNumericLabel txtTotalDiscount;
        private atACCFramework.UserControls.atLabel lblTotalDisc;
        private atACCFramework.UserControls.TaxLabel lblTotalTax;
        private atACCFramework.UserControls.atButton btnPayment;
        private atACCFramework.UserControls.TextBoxNormal txtBalance;
        private atACCFramework.UserControls.atNumericLabel txtPayment;
        private atACCFramework.UserControls.atLabel lblBalance;
        private atACCFramework.UserControls.atNumericLabel txtNetTotal;
        private atACCFramework.UserControls.atLabel lblNetTotal;
        private atACCFramework.UserControls.atNumericLabel txtTotalTax;
        private System.Windows.Forms.Button btnSeperator1;
        private atACCFramework.UserControls.atNumericLabel lblGrandTotal;
        private atACCFramework.UserControls.atLabel atlblTot;
        private System.Windows.Forms.BindingSource bindExtraServiceDTL;
        private atACCFramework.UserControls.atNumericLabel txtGrpCheckInTotal;
        private System.Windows.Forms.BindingSource bindRoom;
        private atACCFramework.UserControls.atGridView dgRoom;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.atPanel pnlGridContain;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private atACCFramework.UserControls.atLabel lblGroupCheckIn;
        private System.Windows.Forms.Button btnGrpCheckIn;
        private atACCFramework.UserControls.atLabel lblCurrencyCap;
        private atACCFramework.UserControls.TextBoxExt txtExRate;
        private atACCFramework.UserControls.ComboBoxExt cmbCurrency;
        private atACCFramework.UserControls.atLabel lblExRateCap;
        private AccountLabel lblOpBalance;
        private atACCFramework.UserControls.atNumericLabel txtOpBalance;
        private AccountLabel lblExternal;
        private atACCFramework.UserControls.atNumericLabel txtExternalAmt;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory4;
        private atACCFramework.UserControls.TextBoxNormal txtAddnlRoundoff;
        private atACCFramework.UserControls.atLabel lblAdnlRoundoff;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_Room;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Service;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExtraServiceID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_InclusiveRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_DiscountSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscountPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TaxableAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExciseSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExcisePerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExciseAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX1SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX2SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX3SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_AddnlTaxSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_GSTSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_NetAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_VATSlabID;
    }
}