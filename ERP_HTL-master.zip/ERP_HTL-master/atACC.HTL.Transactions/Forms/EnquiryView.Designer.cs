﻿namespace atACC.HTL.Transactions
{
    partial class EnquiryView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EnquiryView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblCancelStatus = new System.Windows.Forms.Label();
            this.btnNewSource = new atACCFramework.UserControls.atButton();
            this.btnNewType = new atACCFramework.UserControls.atButton();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.cmbRoomOrHall = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomOrHall = new atACCFramework.UserControls.atLabel();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.cmbSource = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbType = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbAgent = new atACCFramework.UserControls.ComboBoxExt();
            this.lblAgent = new atACCFramework.UserControls.atLabel();
            this.lblSource = new atACCFramework.UserControls.atLabel();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.txtNoOfDays = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfDays = new atACCFramework.UserControls.atLabel();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.txtEmail = new atACCFramework.UserControls.TextBoxExt();
            this.lblEmail = new atACCFramework.UserControls.atLabel();
            this.txtNoOfRooms = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfRooms = new atACCFramework.UserControls.atLabel();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.lblMobile = new atACCFramework.UserControls.atLabel();
            this.txtPhone = new atACCFramework.UserControls.TextBoxExt();
            this.lblPhoneNo = new atACCFramework.UserControls.atLabel();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.txtCity = new atACCFramework.UserControls.TextBoxExt();
            this.lblCity = new atACCFramework.UserControls.atLabel();
            this.txtContactPerson = new atACCFramework.UserControls.TextBoxExt();
            this.lblContactPerson = new atACCFramework.UserControls.atLabel();
            this.lblType = new atACCFramework.UserControls.atLabel();
            this.lblName = new atACCFramework.UserControls.atLabel();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.lblMandatory6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.errProvider.SetError(this.panel1, resources.GetString("panel1.Error"));
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.panel1, ((int)(resources.GetObject("panel1.IconPadding"))));
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.errProvider.SetError(this.txtVoucherNo, resources.GetString("txtVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.txtVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtVoucherNo, ((int)(resources.GetObject("txtVoucherNo.IconPadding"))));
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            this.txtVoucherNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtVoucherNo_KeyDown);
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtVoucherDate, resources.GetString("dtVoucherDate.Error"));
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtVoucherDate, ((int)(resources.GetObject("dtVoucherDate.IconPadding"))));
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.errProvider.SetError(this.lblVoucherNo, resources.GetString("lblVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherNo, ((int)(resources.GetObject("lblVoucherNo.IconPadding"))));
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.errProvider.SetError(this.lblVoucherDate, resources.GetString("lblVoucherDate.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherDate, ((int)(resources.GetObject("lblVoucherDate.IconPadding"))));
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblCancelStatus);
            this.pnlMain.Controls.Add(this.btnNewSource);
            this.pnlMain.Controls.Add(this.btnNewType);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.cmbRoomOrHall);
            this.pnlMain.Controls.Add(this.lblRoomOrHall);
            this.pnlMain.Controls.Add(this.txtName);
            this.pnlMain.Controls.Add(this.cmbSource);
            this.pnlMain.Controls.Add(this.cmbType);
            this.pnlMain.Controls.Add(this.cmbAgent);
            this.pnlMain.Controls.Add(this.lblAgent);
            this.pnlMain.Controls.Add(this.lblSource);
            this.pnlMain.Controls.Add(this.cmbEmployee);
            this.pnlMain.Controls.Add(this.lblEmployee);
            this.pnlMain.Controls.Add(this.txtNoOfDays);
            this.pnlMain.Controls.Add(this.lblNoOfDays);
            this.pnlMain.Controls.Add(this.dtpDepartureDate);
            this.pnlMain.Controls.Add(this.lblDepartureDate);
            this.pnlMain.Controls.Add(this.dtpArrivalDate);
            this.pnlMain.Controls.Add(this.lblArrivalDate);
            this.pnlMain.Controls.Add(this.txtEmail);
            this.pnlMain.Controls.Add(this.lblEmail);
            this.pnlMain.Controls.Add(this.txtNoOfRooms);
            this.pnlMain.Controls.Add(this.lblNoOfRooms);
            this.pnlMain.Controls.Add(this.txtMobile);
            this.pnlMain.Controls.Add(this.lblMobile);
            this.pnlMain.Controls.Add(this.txtPhone);
            this.pnlMain.Controls.Add(this.lblPhoneNo);
            this.pnlMain.Controls.Add(this.cmbRoomType);
            this.pnlMain.Controls.Add(this.txtCity);
            this.pnlMain.Controls.Add(this.lblCity);
            this.pnlMain.Controls.Add(this.txtContactPerson);
            this.pnlMain.Controls.Add(this.lblContactPerson);
            this.pnlMain.Controls.Add(this.lblType);
            this.pnlMain.Controls.Add(this.lblName);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory5);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblRoomType);
            this.pnlMain.Controls.Add(this.lblMandatory6);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.errProvider.SetError(this.lblMandatory4, resources.GetString("lblMandatory4.Error"));
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory4.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory4, ((int)(resources.GetObject("lblMandatory4.IconPadding"))));
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblCancelStatus
            // 
            resources.ApplyResources(this.lblCancelStatus, "lblCancelStatus");
            this.lblCancelStatus.BackColor = System.Drawing.Color.Transparent;
            this.errProvider.SetError(this.lblCancelStatus, resources.GetString("lblCancelStatus.Error"));
            this.lblCancelStatus.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblCancelStatus, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCancelStatus.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCancelStatus, ((int)(resources.GetObject("lblCancelStatus.IconPadding"))));
            this.lblCancelStatus.Name = "lblCancelStatus";
            // 
            // btnNewSource
            // 
            resources.ApplyResources(this.btnNewSource, "btnNewSource");
            this.btnNewSource.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnNewSource, resources.GetString("btnNewSource.Error"));
            this.btnNewSource.FlatAppearance.BorderSize = 0;
            this.btnNewSource.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnNewSource, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnNewSource.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnNewSource, ((int)(resources.GetObject("btnNewSource.IconPadding"))));
            this.btnNewSource.Name = "btnNewSource";
            this.btnNewSource.TabStop = false;
            this.btnNewSource.Tag = "";
            this.btnNewSource.UseVisualStyleBackColor = false;
            this.btnNewSource.Click += new System.EventHandler(this.btnNewSource_Click);
            // 
            // btnNewType
            // 
            resources.ApplyResources(this.btnNewType, "btnNewType");
            this.btnNewType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnNewType, resources.GetString("btnNewType.Error"));
            this.btnNewType.FlatAppearance.BorderSize = 0;
            this.btnNewType.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnNewType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnNewType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnNewType, ((int)(resources.GetObject("btnNewType.IconPadding"))));
            this.btnNewType.Name = "btnNewType";
            this.btnNewType.TabStop = false;
            this.btnNewType.Tag = "";
            this.btnNewType.UseVisualStyleBackColor = false;
            this.btnNewType.Click += new System.EventHandler(this.btnNewType_Click);
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtRemarks, resources.GetString("txtRemarks.Error"));
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtRemarks, ((int)(resources.GetObject("txtRemarks.IconPadding"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Tag = "11";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.errProvider.SetError(this.lblRemarks, resources.GetString("lblRemarks.Error"));
            this.errProvider.SetIconAlignment(this.lblRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRemarks, ((int)(resources.GetObject("lblRemarks.IconPadding"))));
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // cmbRoomOrHall
            // 
            resources.ApplyResources(this.cmbRoomOrHall, "cmbRoomOrHall");
            this.cmbRoomOrHall.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomOrHall.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomOrHall.DropDownHeight = 300;
            this.cmbRoomOrHall.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbRoomOrHall, resources.GetString("cmbRoomOrHall.Error"));
            this.cmbRoomOrHall.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoomOrHall, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoomOrHall.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbRoomOrHall, ((int)(resources.GetObject("cmbRoomOrHall.IconPadding"))));
            this.cmbRoomOrHall.Name = "cmbRoomOrHall";
            this.cmbRoomOrHall.Tag = "7";
            this.cmbRoomOrHall.SelectedIndexChanged += new System.EventHandler(this.cmbRoomOrHall_SelectedIndexChanged);
            // 
            // lblRoomOrHall
            // 
            resources.ApplyResources(this.lblRoomOrHall, "lblRoomOrHall");
            this.errProvider.SetError(this.lblRoomOrHall, resources.GetString("lblRoomOrHall.Error"));
            this.errProvider.SetIconAlignment(this.lblRoomOrHall, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoomOrHall.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRoomOrHall, ((int)(resources.GetObject("lblRoomOrHall.IconPadding"))));
            this.lblRoomOrHall.Name = "lblRoomOrHall";
            this.lblRoomOrHall.RequiredField = false;
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtName, resources.GetString("txtName.Error"));
            this.txtName.Format = null;
            this.errProvider.SetIconAlignment(this.txtName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtName, ((int)(resources.GetObject("txtName.IconPadding"))));
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = true;
            this.txtName.Name = "txtName";
            this.txtName.Tag = "0";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // cmbSource
            // 
            resources.ApplyResources(this.cmbSource, "cmbSource");
            this.cmbSource.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSource.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSource.DropDownHeight = 300;
            this.cmbSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbSource, resources.GetString("cmbSource.Error"));
            this.cmbSource.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbSource, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbSource.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbSource, ((int)(resources.GetObject("cmbSource.IconPadding"))));
            this.cmbSource.Name = "cmbSource";
            this.cmbSource.Tag = "16";
            // 
            // cmbType
            // 
            resources.ApplyResources(this.cmbType, "cmbType");
            this.cmbType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbType.DropDownHeight = 300;
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbType, resources.GetString("cmbType.Error"));
            this.cmbType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbType, ((int)(resources.GetObject("cmbType.IconPadding"))));
            this.cmbType.Name = "cmbType";
            this.cmbType.Tag = "6";
            // 
            // cmbAgent
            // 
            resources.ApplyResources(this.cmbAgent, "cmbAgent");
            this.cmbAgent.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAgent.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAgent.DropDownHeight = 300;
            this.cmbAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbAgent, resources.GetString("cmbAgent.Error"));
            this.cmbAgent.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbAgent, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbAgent.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbAgent, ((int)(resources.GetObject("cmbAgent.IconPadding"))));
            this.cmbAgent.Name = "cmbAgent";
            this.cmbAgent.Tag = "10";
            // 
            // lblAgent
            // 
            resources.ApplyResources(this.lblAgent, "lblAgent");
            this.errProvider.SetError(this.lblAgent, resources.GetString("lblAgent.Error"));
            this.errProvider.SetIconAlignment(this.lblAgent, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAgent.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAgent, ((int)(resources.GetObject("lblAgent.IconPadding"))));
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.RequiredField = false;
            // 
            // lblSource
            // 
            resources.ApplyResources(this.lblSource, "lblSource");
            this.errProvider.SetError(this.lblSource, resources.GetString("lblSource.Error"));
            this.errProvider.SetIconAlignment(this.lblSource, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblSource.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblSource, ((int)(resources.GetObject("lblSource.IconPadding"))));
            this.lblSource.Name = "lblSource";
            this.lblSource.RequiredField = false;
            // 
            // cmbEmployee
            // 
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbEmployee, resources.GetString("cmbEmployee.Error"));
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbEmployee, ((int)(resources.GetObject("cmbEmployee.IconPadding"))));
            this.cmbEmployee.Name = "cmbEmployee";
            this.cmbEmployee.Tag = "15";
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.errProvider.SetError(this.lblEmployee, resources.GetString("lblEmployee.Error"));
            this.errProvider.SetIconAlignment(this.lblEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblEmployee, ((int)(resources.GetObject("lblEmployee.IconPadding"))));
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // txtNoOfDays
            // 
            resources.ApplyResources(this.txtNoOfDays, "txtNoOfDays");
            this.txtNoOfDays.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtNoOfDays, resources.GetString("txtNoOfDays.Error"));
            this.txtNoOfDays.Format = null;
            this.errProvider.SetIconAlignment(this.txtNoOfDays, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNoOfDays.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtNoOfDays, ((int)(resources.GetObject("txtNoOfDays.IconPadding"))));
            this.txtNoOfDays.isAllowNegative = false;
            this.txtNoOfDays.isAllowSpecialChar = false;
            this.txtNoOfDays.isNumbersOnly = true;
            this.txtNoOfDays.isNumeric = false;
            this.txtNoOfDays.isTouchable = true;
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.ReadOnly = true;
            this.txtNoOfDays.Tag = "14";
            this.txtNoOfDays.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNoOfDays
            // 
            resources.ApplyResources(this.lblNoOfDays, "lblNoOfDays");
            this.errProvider.SetError(this.lblNoOfDays, resources.GetString("lblNoOfDays.Error"));
            this.errProvider.SetIconAlignment(this.lblNoOfDays, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNoOfDays.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblNoOfDays, ((int)(resources.GetObject("lblNoOfDays.IconPadding"))));
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.RequiredField = false;
            // 
            // dtpDepartureDate
            // 
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpDepartureDate, resources.GetString("dtpDepartureDate.Error"));
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpDepartureDate, ((int)(resources.GetObject("dtpDepartureDate.IconPadding"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.Tag = "13";
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpDepartureDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.errProvider.SetError(this.lblDepartureDate, resources.GetString("lblDepartureDate.Error"));
            this.errProvider.SetIconAlignment(this.lblDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDepartureDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblDepartureDate, ((int)(resources.GetObject("lblDepartureDate.IconPadding"))));
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // dtpArrivalDate
            // 
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpArrivalDate, resources.GetString("dtpArrivalDate.Error"));
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpArrivalDate, ((int)(resources.GetObject("dtpArrivalDate.IconPadding"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.Tag = "12";
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpArrivalDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.errProvider.SetError(this.lblArrivalDate, resources.GetString("lblArrivalDate.Error"));
            this.errProvider.SetIconAlignment(this.lblArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblArrivalDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblArrivalDate, ((int)(resources.GetObject("lblArrivalDate.IconPadding"))));
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // txtEmail
            // 
            resources.ApplyResources(this.txtEmail, "txtEmail");
            this.txtEmail.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtEmail, resources.GetString("txtEmail.Error"));
            this.txtEmail.Format = null;
            this.errProvider.SetIconAlignment(this.txtEmail, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtEmail.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtEmail, ((int)(resources.GetObject("txtEmail.IconPadding"))));
            this.txtEmail.isAllowNegative = false;
            this.txtEmail.isAllowSpecialChar = false;
            this.txtEmail.isNumbersOnly = false;
            this.txtEmail.isNumeric = false;
            this.txtEmail.isTouchable = false;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Tag = "5";
            this.txtEmail.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblEmail
            // 
            resources.ApplyResources(this.lblEmail, "lblEmail");
            this.errProvider.SetError(this.lblEmail, resources.GetString("lblEmail.Error"));
            this.errProvider.SetIconAlignment(this.lblEmail, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblEmail.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblEmail, ((int)(resources.GetObject("lblEmail.IconPadding"))));
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.RequiredField = false;
            // 
            // txtNoOfRooms
            // 
            resources.ApplyResources(this.txtNoOfRooms, "txtNoOfRooms");
            this.txtNoOfRooms.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfRooms.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtNoOfRooms, resources.GetString("txtNoOfRooms.Error"));
            this.txtNoOfRooms.Format = null;
            this.errProvider.SetIconAlignment(this.txtNoOfRooms, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNoOfRooms.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtNoOfRooms, ((int)(resources.GetObject("txtNoOfRooms.IconPadding"))));
            this.txtNoOfRooms.isAllowNegative = false;
            this.txtNoOfRooms.isAllowSpecialChar = false;
            this.txtNoOfRooms.isNumbersOnly = true;
            this.txtNoOfRooms.isNumeric = false;
            this.txtNoOfRooms.isTouchable = true;
            this.txtNoOfRooms.Name = "txtNoOfRooms";
            this.txtNoOfRooms.Tag = "9";
            this.txtNoOfRooms.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNoOfRooms
            // 
            resources.ApplyResources(this.lblNoOfRooms, "lblNoOfRooms");
            this.errProvider.SetError(this.lblNoOfRooms, resources.GetString("lblNoOfRooms.Error"));
            this.errProvider.SetIconAlignment(this.lblNoOfRooms, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNoOfRooms.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblNoOfRooms, ((int)(resources.GetObject("lblNoOfRooms.IconPadding"))));
            this.lblNoOfRooms.Name = "lblNoOfRooms";
            this.lblNoOfRooms.RequiredField = false;
            // 
            // txtMobile
            // 
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtMobile, resources.GetString("txtMobile.Error"));
            this.txtMobile.Format = null;
            this.errProvider.SetIconAlignment(this.txtMobile, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtMobile.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtMobile, ((int)(resources.GetObject("txtMobile.IconPadding"))));
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = false;
            this.txtMobile.isNumbersOnly = true;
            this.txtMobile.isNumeric = false;
            this.txtMobile.isTouchable = true;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Tag = "4";
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMobile
            // 
            resources.ApplyResources(this.lblMobile, "lblMobile");
            this.errProvider.SetError(this.lblMobile, resources.GetString("lblMobile.Error"));
            this.errProvider.SetIconAlignment(this.lblMobile, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMobile.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMobile, ((int)(resources.GetObject("lblMobile.IconPadding"))));
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.RequiredField = false;
            // 
            // txtPhone
            // 
            resources.ApplyResources(this.txtPhone, "txtPhone");
            this.txtPhone.BackColor = System.Drawing.SystemColors.Window;
            this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtPhone, resources.GetString("txtPhone.Error"));
            this.txtPhone.Format = null;
            this.errProvider.SetIconAlignment(this.txtPhone, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtPhone.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtPhone, ((int)(resources.GetObject("txtPhone.IconPadding"))));
            this.txtPhone.isAllowNegative = false;
            this.txtPhone.isAllowSpecialChar = false;
            this.txtPhone.isNumbersOnly = true;
            this.txtPhone.isNumeric = false;
            this.txtPhone.isTouchable = true;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Tag = "3";
            this.txtPhone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblPhoneNo
            // 
            resources.ApplyResources(this.lblPhoneNo, "lblPhoneNo");
            this.errProvider.SetError(this.lblPhoneNo, resources.GetString("lblPhoneNo.Error"));
            this.errProvider.SetIconAlignment(this.lblPhoneNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblPhoneNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblPhoneNo, ((int)(resources.GetObject("lblPhoneNo.IconPadding"))));
            this.lblPhoneNo.Name = "lblPhoneNo";
            this.lblPhoneNo.RequiredField = false;
            // 
            // cmbRoomType
            // 
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbRoomType, resources.GetString("cmbRoomType.Error"));
            this.cmbRoomType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoomType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoomType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbRoomType, ((int)(resources.GetObject("cmbRoomType.IconPadding"))));
            this.cmbRoomType.Name = "cmbRoomType";
            this.cmbRoomType.Tag = "8";
            // 
            // txtCity
            // 
            resources.ApplyResources(this.txtCity, "txtCity");
            this.txtCity.BackColor = System.Drawing.SystemColors.Window;
            this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtCity, resources.GetString("txtCity.Error"));
            this.txtCity.Format = null;
            this.errProvider.SetIconAlignment(this.txtCity, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtCity.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtCity, ((int)(resources.GetObject("txtCity.IconPadding"))));
            this.txtCity.isAllowNegative = false;
            this.txtCity.isAllowSpecialChar = false;
            this.txtCity.isNumbersOnly = false;
            this.txtCity.isNumeric = false;
            this.txtCity.isTouchable = true;
            this.txtCity.Name = "txtCity";
            this.txtCity.Tag = "2";
            this.txtCity.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblCity
            // 
            resources.ApplyResources(this.lblCity, "lblCity");
            this.errProvider.SetError(this.lblCity, resources.GetString("lblCity.Error"));
            this.errProvider.SetIconAlignment(this.lblCity, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCity.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCity, ((int)(resources.GetObject("lblCity.IconPadding"))));
            this.lblCity.Name = "lblCity";
            this.lblCity.RequiredField = false;
            // 
            // txtContactPerson
            // 
            resources.ApplyResources(this.txtContactPerson, "txtContactPerson");
            this.txtContactPerson.BackColor = System.Drawing.SystemColors.Window;
            this.txtContactPerson.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtContactPerson, resources.GetString("txtContactPerson.Error"));
            this.txtContactPerson.Format = null;
            this.errProvider.SetIconAlignment(this.txtContactPerson, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtContactPerson.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtContactPerson, ((int)(resources.GetObject("txtContactPerson.IconPadding"))));
            this.txtContactPerson.isAllowNegative = false;
            this.txtContactPerson.isAllowSpecialChar = false;
            this.txtContactPerson.isNumbersOnly = false;
            this.txtContactPerson.isNumeric = false;
            this.txtContactPerson.isTouchable = true;
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Tag = "1";
            this.txtContactPerson.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblContactPerson
            // 
            resources.ApplyResources(this.lblContactPerson, "lblContactPerson");
            this.errProvider.SetError(this.lblContactPerson, resources.GetString("lblContactPerson.Error"));
            this.errProvider.SetIconAlignment(this.lblContactPerson, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblContactPerson.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblContactPerson, ((int)(resources.GetObject("lblContactPerson.IconPadding"))));
            this.lblContactPerson.Name = "lblContactPerson";
            this.lblContactPerson.RequiredField = false;
            // 
            // lblType
            // 
            resources.ApplyResources(this.lblType, "lblType");
            this.errProvider.SetError(this.lblType, resources.GetString("lblType.Error"));
            this.errProvider.SetIconAlignment(this.lblType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblType, ((int)(resources.GetObject("lblType.IconPadding"))));
            this.lblType.Name = "lblType";
            this.lblType.RequiredField = false;
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.errProvider.SetError(this.lblName, resources.GetString("lblName.Error"));
            this.errProvider.SetIconAlignment(this.lblName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblName, ((int)(resources.GetObject("lblName.IconPadding"))));
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.errProvider.SetError(this.lblMandatory1, resources.GetString("lblMandatory1.Error"));
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory1, ((int)(resources.GetObject("lblMandatory1.IconPadding"))));
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory5
            // 
            resources.ApplyResources(this.lblMandatory5, "lblMandatory5");
            this.errProvider.SetError(this.lblMandatory5, resources.GetString("lblMandatory5.Error"));
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory5, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory5.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory5, ((int)(resources.GetObject("lblMandatory5.IconPadding"))));
            this.lblMandatory5.Name = "lblMandatory5";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.errProvider.SetError(this.lblMandatory2, resources.GetString("lblMandatory2.Error"));
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory2, ((int)(resources.GetObject("lblMandatory2.IconPadding"))));
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.errProvider.SetError(this.lblMandatory3, resources.GetString("lblMandatory3.Error"));
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory3, ((int)(resources.GetObject("lblMandatory3.IconPadding"))));
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.errProvider.SetError(this.lblRoomType, resources.GetString("lblRoomType.Error"));
            this.errProvider.SetIconAlignment(this.lblRoomType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoomType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRoomType, ((int)(resources.GetObject("lblRoomType.IconPadding"))));
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // lblMandatory6
            // 
            resources.ApplyResources(this.lblMandatory6, "lblMandatory6");
            this.errProvider.SetError(this.lblMandatory6, resources.GetString("lblMandatory6.Error"));
            this.lblMandatory6.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory6, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory6.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory6, ((int)(resources.GetObject("lblMandatory6.IconPadding"))));
            this.lblMandatory6.Name = "lblMandatory6";
            // 
            // EnquiryView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "EnquiryView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.FrmEnquery_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.FrmEnquery_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.FrmEnquery_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.FrmEnquery_atNewClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.FrmEnquery_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.FrmEnquery_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.FrmEnquery_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.FrmHallView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.FrmEnquery_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.EnquiryView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.FrmEnquery_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.FrmEnquery_atBeforeSearch);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.ComboBoxExt cmbAgent;
        private atACCFramework.UserControls.atLabel lblAgent;
        private atACCFramework.UserControls.atLabel lblSource;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.TextBoxExt txtNoOfDays;
        private atACCFramework.UserControls.atLabel lblNoOfDays;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.TextBoxExt txtEmail;
        private atACCFramework.UserControls.atLabel lblEmail;
        private atACCFramework.UserControls.TextBoxExt txtNoOfRooms;
        private atACCFramework.UserControls.atLabel lblNoOfRooms;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atLabel lblMobile;
        private atACCFramework.UserControls.TextBoxExt txtPhone;
        private atACCFramework.UserControls.atLabel lblPhoneNo;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.TextBoxExt txtCity;
        private atACCFramework.UserControls.atLabel lblCity;
        private atACCFramework.UserControls.TextBoxExt txtContactPerson;
        private atACCFramework.UserControls.atLabel lblContactPerson;
        private atACCFramework.UserControls.atLabel lblType;
        private atACCFramework.UserControls.atLabel lblName;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.ComboBoxExt cmbType;
        private atACCFramework.UserControls.ComboBoxExt cmbSource;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory4;
        private System.Windows.Forms.Label lblMandatory5;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomOrHall;
        private atACCFramework.UserControls.atLabel lblRoomOrHall;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atButton btnNewType;
        private atACCFramework.UserControls.atButton btnNewSource;
        private System.Windows.Forms.Label lblCancelStatus;
        private System.Windows.Forms.Label lblMandatory6;
    }
}