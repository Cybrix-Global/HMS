﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using atACC.CommonExtensions;
using atACCFramework.BaseClasses;
using atACC.HTL.ORM;
namespace atACC.HTL.Transactions
{
    public partial class ExtraServiceSearchView : FormBase
    {
        #region Private Variables
        List<ServiceSearchClass> entCurrent;
        ENExtraServiceTypes _serviceType;
        atACCHotelEntities dbh;
        #endregion

        #region public Properties
        public int selectedServiceID;
        #endregion

        #region Constructor
        public ExtraServiceSearchView(string CurrentService, ENExtraServiceTypes serviceType)
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            _serviceType = serviceType;
            txtItem.Text = CurrentService;            
        }
        #endregion

        #region Private Methods
        private void SelectEnd()
        {
            txtItem.SelectionStart = txtItem.Text.Length;

        }
        private void SearchListView()
        {
            entCurrent = dbh.ExtraServices
                .Where(x => x.Active == true && (x.Type ?? 0) == (int)_serviceType
                    &&
                    (x.Name.ToUpper()
                    .Contains(txtItem.Text.ToUpper())
                    ||
                     x.Code.ToUpper()
                        .Contains(txtItem.Text.ToUpper())))
                    .Take(100).Select(x => new ServiceSearchClass { Name = x.Name, Code = x.Code, Id = x.id }).ToList();

            BindListView();
        }
        private void BindListView()
        {
            lstItemSearch.View = View.Details;
            lstItemSearch.Items.Clear();
            foreach (ServiceSearchClass p in entCurrent)
            {
                var listViewItem = new ListViewItem(ToStringArray(p));
                lstItemSearch.Items.Add(listViewItem);
            }
            lstItemSearch.FullRowSelect = true;
            if (lstItemSearch.Items.Count > 0)
                lstItemSearch.Items[0].Selected = true;

        }
        private string[] ToStringArray(ServiceSearchClass prd)
        {
            string[] sColumns = new string[] { "Id", "Code", "Name" };
            return prd.GetType()
                    .GetProperties()
                    .Where(x => sColumns.Contains(x.Name))
                    .Select(p =>
                    {
                        object value = p.GetValue(prd, null);
                        return value == null ? null : value.ToString();
                    })
                    .ToArray();
        }
        #endregion

        #region private events
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        private void txtItem_TextChanged(object sender, EventArgs e)
        {
            SearchListView();
        }
        private void txtItem_KeyDown(object sender, KeyEventArgs e)
        {
            int index;
            if (lstItemSearch.Items.Count <= 0) { return; }
            if (lstItemSearch.SelectedItems.Count <= 0) { return; }
            switch (e.KeyCode)
            {
                case Keys.Down:
                    e.Handled = true;
                    index = lstItemSearch.SelectedItems[0].Index;
                    if (index < lstItemSearch.Items.Count - 1)
                    {
                        this.lstItemSearch.Items[index].Selected = false;
                        index = index + 1;
                        this.lstItemSearch.Items[index].Selected = true;
                        lstItemSearch.EnsureVisible(index);
                    }
                    break;
                case Keys.Up:
                    e.Handled = true;
                    index = lstItemSearch.SelectedItems[0].Index;
                    if (index > 0)
                    {
                        this.lstItemSearch.Items[index].Selected = false;
                        index = index - 1;
                        this.lstItemSearch.Items[index].Selected = true;
                        lstItemSearch.EnsureVisible(index);
                    }
                    break;
                case Keys.Return:
                    selectedServiceID = lstItemSearch.SelectedItems[0].Text.ToInt32();
                    this.DialogResult = DialogResult.OK;
                    e.Handled = true;
                    break;
            }
        }
        private void lstItemSearch_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            selectedServiceID = lstItemSearch.SelectedItems[0].Text.ToInt32();
            this.DialogResult = DialogResult.OK;
        }
        private void lstItemSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.DialogResult = DialogResult.Cancel;
            }
        }
        private void lstItemSearch_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.Item.Selected)
            {
                int ListViewPosition = lstItemSearch.Location.Y;
                int itemposition = e.Item.Position.Y;
                btnSelectedItem.Location = new Point(btnSelectedItem.Location.X, itemposition + ListViewPosition);
            }
            else if (!e.Item.Selected)
            {

            }
        }
        #endregion

        private void ExtraServiceSearchView_Load(object sender, EventArgs e)
        {
            
        }

        private void ExtraServiceSearchView_Shown(object sender, EventArgs e)
        {
            SelectEnd();
        }
    }
}
