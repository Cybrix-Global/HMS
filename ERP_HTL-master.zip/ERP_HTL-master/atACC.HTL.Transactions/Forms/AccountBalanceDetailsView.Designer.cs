﻿namespace atACC.HTL.Transactions
{
    partial class AccountBalanceDetailsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AccountBalanceDetailsView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgDetails = new atACCFramework.UserControls.atGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.pnlGridContain = new atACCFramework.UserControls.atPanel();
            this.col_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VoucherNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VoucherDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.pnlGridContain.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgDetails
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_Type,
            this.col_VoucherNo,
            this.col_VoucherDate,
            this.col_Amount});
            this.dgDetails.EnableHeadersVisualStyles = false;
            this.dgDetails.EnterKeyNavigation = false;
            this.dgDetails.LastKey = System.Windows.Forms.Keys.None;
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle4.NullValue = null;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgDetails.sGridID = null;
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // lblHeading
            // 
            resources.ApplyResources(this.lblHeading, "lblHeading");
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            // 
            // pnlGridContain
            // 
            this.pnlGridContain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlGridContain.Controls.Add(this.dgDetails);
            resources.ApplyResources(this.pnlGridContain, "pnlGridContain");
            this.pnlGridContain.Name = "pnlGridContain";
            // 
            // col_Type
            // 
            this.col_Type.DataPropertyName = "Type";
            resources.ApplyResources(this.col_Type, "col_Type");
            this.col_Type.Name = "col_Type";
            // 
            // col_VoucherNo
            // 
            this.col_VoucherNo.DataPropertyName = "VoucherNo";
            resources.ApplyResources(this.col_VoucherNo, "col_VoucherNo");
            this.col_VoucherNo.Name = "col_VoucherNo";
            // 
            // col_VoucherDate
            // 
            this.col_VoucherDate.DataPropertyName = "VoucherDate";
            resources.ApplyResources(this.col_VoucherDate, "col_VoucherDate");
            this.col_VoucherDate.Name = "col_VoucherDate";
            // 
            // col_Amount
            // 
            this.col_Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Amount.DefaultCellStyle = dataGridViewCellStyle3;
            resources.ApplyResources(this.col_Amount, "col_Amount");
            this.col_Amount.Name = "col_Amount";
            // 
            // AccountBalanceDetailsView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlGridContain);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.btnClose);
            this.Name = "AccountBalanceDetailsView";
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.pnlGridContain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atACCFramework.UserControls.atGridView dgDetails;
        private System.Windows.Forms.Button btnClose;
        public atACCFramework.UserControls.atLabel lblHeading;
        private atACCFramework.UserControls.atPanel pnlGridContain;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VoucherNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VoucherDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Amount;
    }
}