﻿namespace atACC.HTL.Transactions
{
    partial class RoomShiftView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RoomShiftView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.btnSeperator1 = new System.Windows.Forms.Button();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.txtReason = new atACCFramework.UserControls.TextBoxExt();
            this.cmbGuest = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.atLabel2 = new atACCFramework.UserControls.atLabel();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.cmbToRoom = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.cmbFromRoom = new atACCFramework.UserControls.ComboBoxExt();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.dtpShiftDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblShiftDate = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            this.txtVoucherNo.Validated += new System.EventHandler(this.txtVoucherNo_Validated);
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.dtpArrivalDate);
            this.pnlMain.Controls.Add(this.btnSeperator1);
            this.pnlMain.Controls.Add(this.dtpDepartureDate);
            this.pnlMain.Controls.Add(this.atLabel3);
            this.pnlMain.Controls.Add(this.lblDepartureDate);
            this.pnlMain.Controls.Add(this.lblArrivalDate);
            this.pnlMain.Controls.Add(this.txtReason);
            this.pnlMain.Controls.Add(this.cmbGuest);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.atLabel2);
            this.pnlMain.Controls.Add(this.atLabel1);
            this.pnlMain.Controls.Add(this.cmbToRoom);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Controls.Add(this.cmbFromRoom);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.cmbEmployee);
            this.pnlMain.Controls.Add(this.lblEmployee);
            this.pnlMain.Controls.Add(this.dtpShiftDate);
            this.pnlMain.Controls.Add(this.lblShiftDate);
            this.pnlMain.Name = "pnlMain";
            // 
            // dtpArrivalDate
            // 
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.TabStop = false;
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpArrivalDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // btnSeperator1
            // 
            resources.ApplyResources(this.btnSeperator1, "btnSeperator1");
            this.btnSeperator1.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.btnSeperator1.Name = "btnSeperator1";
            this.btnSeperator1.UseVisualStyleBackColor = true;
            // 
            // dtpDepartureDate
            // 
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.TabStop = false;
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // txtReason
            // 
            this.txtReason.BackColor = System.Drawing.SystemColors.Window;
            this.txtReason.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtReason, "txtReason");
            this.txtReason.Format = null;
            this.txtReason.isAllowNegative = false;
            this.txtReason.isAllowSpecialChar = false;
            this.txtReason.isNumbersOnly = false;
            this.txtReason.isNumeric = false;
            this.txtReason.isTouchable = true;
            this.txtReason.Name = "txtReason";
            this.txtReason.Tag = "11";
            this.txtReason.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // cmbGuest
            // 
            this.cmbGuest.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuest.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuest.DropDownHeight = 300;
            this.cmbGuest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuest, "cmbGuest");
            this.cmbGuest.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuest, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuest.IconAlignment"))));
            this.cmbGuest.Name = "cmbGuest";
            this.cmbGuest.TabStop = false;
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // atLabel2
            // 
            resources.ApplyResources(this.atLabel2, "atLabel2");
            this.atLabel2.Name = "atLabel2";
            this.atLabel2.RequiredField = false;
            // 
            // atLabel1
            // 
            resources.ApplyResources(this.atLabel1, "atLabel1");
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            // 
            // cmbToRoom
            // 
            this.cmbToRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbToRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbToRoom.DropDownHeight = 300;
            this.cmbToRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbToRoom, "cmbToRoom");
            this.cmbToRoom.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbToRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbToRoom.IconAlignment"))));
            this.cmbToRoom.Name = "cmbToRoom";
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // cmbFromRoom
            // 
            this.cmbFromRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbFromRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbFromRoom.DropDownHeight = 300;
            this.cmbFromRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbFromRoom, "cmbFromRoom");
            this.cmbFromRoom.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbFromRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbFromRoom.IconAlignment"))));
            this.cmbFromRoom.Name = "cmbFromRoom";
            this.cmbFromRoom.SelectedValueChanged += new System.EventHandler(this.cmbFromRoom_SelectedValueChanged);
            // 
            // txtRemarks
            // 
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.Format = null;
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Tag = "11";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // cmbEmployee
            // 
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.FormattingEnabled = true;
            this.cmbEmployee.Name = "cmbEmployee";
            this.cmbEmployee.Tag = "15";
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // dtpShiftDate
            // 
            this.dtpShiftDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpShiftDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpShiftDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpShiftDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpShiftDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpShiftDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpShiftDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpShiftDate.Checked = true;
            resources.ApplyResources(this.dtpShiftDate, "dtpShiftDate");
            this.dtpShiftDate.DisbaleDateTimeFormat = false;
            this.dtpShiftDate.DisbaleShortDateTimeFormat = false;
            this.dtpShiftDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpShiftDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpShiftDate.IconAlignment"))));
            this.dtpShiftDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpShiftDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpShiftDate.Name = "dtpShiftDate";
            this.dtpShiftDate.Tag = "12";
            this.dtpShiftDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // lblShiftDate
            // 
            resources.ApplyResources(this.lblShiftDate, "lblShiftDate");
            this.lblShiftDate.Name = "lblShiftDate";
            this.lblShiftDate.RequiredField = false;
            // 
            // RoomShiftView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "RoomShiftView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.FrmRoomShift_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.FrmRoomShift_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.FrmRoomShift_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.FrmRoomShift_atNewClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.FrmRoomShift_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.FrmRoomShift_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.FrmRoomShift_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.FrmHallView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.FrmRoomShift_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.RoomShiftView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.FrmRoomShift_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.FrmRoomShift_atBeforeSearch);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.atDateTimePicker dtpShiftDate;
        private atACCFramework.UserControls.atLabel lblShiftDate;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.atLabel atLabel1;
        private atACCFramework.UserControls.ComboBoxExt cmbToRoom;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.ComboBoxExt cmbFromRoom;
        private atACCFramework.UserControls.TextBoxExt txtReason;
        private atACCFramework.UserControls.atLabel atLabel2;
        private atACCFramework.UserControls.ComboBoxExt cmbGuest;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator1;
    }
}