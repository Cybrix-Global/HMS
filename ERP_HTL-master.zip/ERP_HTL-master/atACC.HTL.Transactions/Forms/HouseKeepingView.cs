﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.BaseForms;
using atACC.Common;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.ORM;
using atACC.HTL.Masters;
using System.Data.SqlClient;
using atACC.HTL.Transactions.Sub_Forms;
namespace atACC.HTL.Transactions
{
    public partial class HouseKeepingView : SearchFormBase2
    {
        #region Private Variable
        HouseKeeping entHouseKeeping;
        List<HouseKeeping> entHouseKeepingList;
        Rooms entRooms;
        RoomStatus entRoomStatus;
        List<Employee> entEmployee;
        List<Rooms> entRoomsList;
        List<RoomStatus> entStatuslist;
        atACCHotelEntities dbh;
        ToolTip tooltip;
         #endregion

        #region Constructor
        public HouseKeepingView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(7);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Private Methods
        public override void LoadVouchers()
        {
            string sTempVno = txtVoucherNo.Text;
            dbh = atHotelContext.CreateContext();
            List<UpDownData> _Vouchers = dbh.HouseKeepings.OrderByDescending(x => x.id)
                .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
            txtVoucherNo.Items.Clear();
            txtVoucherNo.DataSource = _Vouchers;
            if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
            txtVoucherNo.Text = sTempVno;
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_HouseKeeping, 0, 0, txtVoucherNo.Text, GlobalFunctions.CurrentFiscalPeriodID);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateHouseKeeping()
        {
            entHouseKeepingList = dbh.HouseKeepings.ToList();
        }
        public void PopulateCombos()
        {
            try
            {
                cmbEmployee.DataSource = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.ServiceMan || x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }

                cmbRoomStatus.DataSource = dbh.RoomStatus.Where(x => x.id == 1 || x.id == 6 || x.id == 7).ToList();
                cmbRoomStatus.DisplayMember = "Name";
                cmbRoomStatus.ValueMember = "id";
                cmbRoomStatus.SelectedIndex = -1;

                cmbRoom.DataSource = dbh.Rooms.ToList();
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
                cmbRoom.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void FnClearAll()
        {
            txtVoucherNo.Text = "";
            cmbRoom.Focus();
        }
        #endregion

        #region Public Methods
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbRoom, MessageKeys.MsgChooseRoomOrHall);
                tooltip.SetToolTip(cmbEmployee, MessageKeys.MsgChooseEmployee);
                tooltip.SetToolTip(txtRemarks, MessageKeys.MsgEnterRemarks);
                tooltip.SetToolTip(cmbRoomStatus, MessageKeys.MsgChooseStatus);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void initEntities()
        {
            entHouseKeeping = new HouseKeeping();
            entEmployee = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
        }
        #endregion

        #region Form Event
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtVoucherNo_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                HouseKeeping eHouseKeeping = dbh.HouseKeepings.Where(x => x.VoucherNo == txtVoucherNo.Text.Trim())
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .SingleOrDefault();
                if (eHouseKeeping != null)
                {
                    ReLoadData(eHouseKeeping.id);
                    onPopulate();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework events
        private void HouseKeepingView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entHouseKeeping = new HouseKeeping();
                initEntities();
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
                dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
                dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();
                SettingsButton.Visible = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void HouseKeepingView_atAfterInitialise()
        {
            try
            {
                cmbRoom.Focus();
                GetSeqNo();
                ShowToolTip();
                PopulateCombos();
                PopulateHouseKeeping();
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void HouseKeepingView_atNewClick(object source)
        {
            try
            {
                entHouseKeeping = new HouseKeeping();
                dbh = atHotelContext.CreateContext();
                cmbRoom.Focus();
                FnClearAll();
                PopulateCombos();
                ShowToolTip();
                initEntities();
                PopulateHouseKeeping();
                GetSeqNo();
                cmbRoom.Select();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool HouseKeepingView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    entHouseKeeping = new HouseKeeping();
                }
                entHouseKeeping.ContextID = iContextID;
                entHouseKeeping.LocationID = GlobalFunctions.LoginLocationID;
                entHouseKeeping.LoginUserID = GlobalFunctions.LoginUserID;
                entHouseKeeping.VoucherNo = txtVoucherNo.Text;
                entHouseKeeping.VoucherDate = dtVoucherDate.Value;
                entHouseKeeping.FK_RoomID = cmbRoom.SelectedValue.ToString().ToInt32();
                entHouseKeeping.FK_RoomStatus = cmbRoomStatus.SelectedValue.ToString().ToInt32();
                if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
                {
                    entHouseKeeping.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
                }
                else { entHouseKeeping.FK_EmployeeID = null; }
                entHouseKeeping.CreatedDate = System.DateTime.Now;
                entHouseKeeping.Remarks = txtRemarks.Text;
                entHouseKeeping.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entHouseKeeping.Sanctioned = false;
                entHouseKeeping.Cancelled = false;
           
                if (NewRecord)
                {
                    dbh.HouseKeepings.AddObject(entHouseKeeping);
                }
                else
                {
                    entHouseKeeping.ModifiedDate = System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(entHouseKeeping, EntityState.Modified);
                }

                #region Save to RoomStatusRegister

                entHouseKeeping.ArrivalDate = entHouseKeeping.VoucherDate;
                entHouseKeeping.DepartureDate = entHouseKeeping.VoucherDate;
                GlobalMethods.SaveRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_HouseKeeping, entHouseKeeping, cmbRoomStatus.SelectedValue.ToInt32());

                #endregion

                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                //  dbh.DetachAllEntities();
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool HouseKeepingView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "") { errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNumberCannotBeBlank); txtVoucherNo.Focus(); return false; }
                if (cmbRoom.Text.Trim() == "") { errProvider.SetError(cmbRoom, MessageKeys.MsgRoomOrHallMustBeChosen); cmbRoom.Focus(); return false; }
                if (cmbEmployee.Text.Trim() == "") { errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen); cmbEmployee.Focus(); return false; }
                if (cmbRoomStatus.Text.Trim() == "") { errProvider.SetError(cmbRoomStatus, MessageKeys.MsgStatusMustBeChosen); cmbRoomStatus.Focus(); return false; }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool HouseKeepingView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInHouseKeeping)
                {
                    PrintClick();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void HouseKeepingView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vHouseKeeping = entHouseKeepingList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vHouseKeeping;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            HouseKeeping houseKeeping = dbh.HouseKeepings.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (houseKeeping != null)
            {
                ReLoadData(houseKeeping.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entHouseKeeping = dbh.HouseKeepings.Where(x => x.id == ID).SingleOrDefault();
                if (entHouseKeeping != null)
                {

                    txtVoucherNo.Text = entHouseKeeping.VoucherNo;
                    dtVoucherDate.Value = entHouseKeeping.VoucherDate.Value;
                    cmbRoom.SelectedValue = entHouseKeeping.FK_RoomID;
                    cmbRoomStatus.SelectedValue = entHouseKeeping.FK_RoomStatus;
                    if (entHouseKeeping.FK_EmployeeID != null)
                    {
                        cmbEmployee.SelectedValue = entHouseKeeping.FK_EmployeeID;
                    }
                    else
                        cmbEmployee.SelectedIndex = -1;
                        txtRemarks.Text = entHouseKeeping.Remarks;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool HouseKeepingView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var VHouseKeeping = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(VHouseKeeping).id);
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool HouseKeepingView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void HouseKeepingView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool HouseKeepingView_atPrint(object source)
        {
            try
            {
                if (entHouseKeeping.id == 0) 
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel House Keeping", entHouseKeeping.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool HouseKeepingView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_HouseKeeping, entHouseKeeping);
                dbh.DeleteObject(entHouseKeeping);       
                dbh.SaveChanges();

                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void HouseKeepingView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
