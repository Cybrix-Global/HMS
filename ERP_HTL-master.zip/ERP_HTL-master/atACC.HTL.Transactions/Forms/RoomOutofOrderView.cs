﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using System.Data.SqlClient;
using atACCFramework.UserControls;
using atACC.HTL.Transactions.Sub_Forms;

namespace atACC.HTL.Transactions
{
    public partial class RoomOutofOrderView : SearchFormBase2
    {
        #region Private Variable
        RoomOutofOrder entRoomOutOfOrder;
        List<RoomOutofOrder> entRoomOutOfOrders;
        List<Rooms> entRooms;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Constructor
        public RoomOutofOrderView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_RoomOutofOrderView;
        }
        #endregion

        #region Populate Events
        public override void LoadVouchers()
        {
            string sTempVno = txtVoucherNo.Text;
            dbh = atHotelContext.CreateContext();
            List<UpDownData> _Vouchers = dbh.RoomOutofOrders.OrderByDescending(x => x.id)
                .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
            txtVoucherNo.Items.Clear();
            txtVoucherNo.DataSource = _Vouchers;
            if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
            txtVoucherNo.Text = sTempVno;
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_RoomOutofOrder, 0, 0, txtVoucherNo.Text, GlobalFunctions.CurrentFiscalPeriodID);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRoomOutOfOrder()
        {
            try
            {
                entRoomOutOfOrders = dbh.RoomOutofOrders.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRooms()
        {
            try
            {
                entRooms = dbh.Rooms.ToList();
                cmbRoom.DataSource = entRooms;
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateReasons()
        {
            try
            {
                var Reasons = entRoomOutOfOrders.Where(x => x.Reason != "").Select(x => new { id = -1, x.Reason }).Distinct().ToList();
                cmbReason.DataSource = Reasons;
                cmbReason.DisplayMember = "Reason";
                cmbReason.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void RoomOutofOrderView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                entRoomOutOfOrder = new RoomOutofOrder();
                PrintButton.Visible = false;
                ShareButton.Visible = false; 
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
                EditButton.Visible = SaveButton.Visible = true;
                if (GlobalFunctions.blnVoucherCancelling)
                {
                    PrintButton.Text = MessageKeys.MsgCancel;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void RoomOutofOrderView_atAfterInitialise()
        {
            try
            {
                PopulateRoomOutOfOrder();
                PopulateReasons();
                PopulateRooms();
                GetSeqNo();
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void RoomOutofOrderView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entRoomOutOfOrder = new RoomOutofOrder();
                PopulateRoomOutOfOrder();
                PopulateReasons();
                PopulateRooms();
                GetSeqNo();
                EditButton.Visible = SaveButton.Visible = true;
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            } 
        }
        private bool RoomOutofOrderView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "")
                {
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNumberCannotBeBlank);
                    txtVoucherNo.Focus();
                    return false;
                }
                if (cmbRoom.Text.Trim() == "")
                {
                    errProvider.SetError(cmbRoom, MessageKeys.MsgRoomOrHallMustBeChosen);
                    cmbRoom.Focus();
                    return false;
                }
                if (dtFromDate.Value > dtToDate.Value)
                {
                    errProvider.SetError(dtToDate, MessageKeys.MsgToDateShouldBeGreaterThanFromDate);
                    dtToDate.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool RoomOutofOrderView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    entRoomOutOfOrder = new RoomOutofOrder();
                }
                entRoomOutOfOrder.ContextID = iContextID;
                entRoomOutOfOrder.LocationID = GlobalFunctions.LoginLocationID;
                entRoomOutOfOrder.LoginUserID = GlobalFunctions.LoginUserID;
                entRoomOutOfOrder.VoucherNo = txtVoucherNo.Text;
                entRoomOutOfOrder.VoucherDate = dtVoucherDate.Value;
                entRoomOutOfOrder.FK_RoomID = cmbRoom.SelectedValue.ToInt32();
                entRoomOutOfOrder.FromDate = dtFromDate.Value;
                entRoomOutOfOrder.ToDate = dtToDate.Value;
                entRoomOutOfOrder.Reason = cmbReason.Text;
                entRoomOutOfOrder.Remarks = txtRemarks.Text;
                entRoomOutOfOrder.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entRoomOutOfOrder.Sanctioned = true;
                if (NewRecord)
                {
                    dbh.RoomOutofOrders.AddObject(entRoomOutOfOrder);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(entRoomOutOfOrder, EntityState.Modified);
                }

                #region Save to RoomStatusRegister

                entRoomOutOfOrder.ArrivalDate = entRoomOutOfOrder.FromDate;
                entRoomOutOfOrder.DepartureDate = entRoomOutOfOrder.ToDate;
                GlobalMethods.SaveRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_RoomOutofOrder, entRoomOutOfOrder);

                #endregion

                dbh.SaveChanges();

                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_RoomOutofOrderVoucherNo"))
                    {
                        return RoomOutofOrderView_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool RoomOutofOrderView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void RoomOutofOrderView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vRoomOutOfOrder = entRoomOutOfOrders.Select(x => new { id = x.id, VoucherNo = x.VoucherNo ,VoucherDate = x.VoucherDate.Value.ToShortDateString() }).OrderByDescending(x => x.id);
                e.SearchEntityList = vRoomOutOfOrder;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            RoomOutofOrder roomOutofOrder = dbh.RoomOutofOrders.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (roomOutofOrder != null)
            {
                ReLoadData(roomOutofOrder.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entRoomOutOfOrder = dbh.RoomOutofOrders.Where(x => x.id == id).SingleOrDefault();
                if (entRoomOutOfOrder != null)
                {
                    txtVoucherNo.Text = entRoomOutOfOrder.VoucherNo;
                    dtVoucherDate.Value = entRoomOutOfOrder.VoucherDate.Value;
                    cmbRoom.SelectedValue = entRoomOutOfOrder.FK_RoomID;
                    cmbReason.Text = entRoomOutOfOrder.Reason;
                    dtFromDate.Value = entRoomOutOfOrder.FromDate.Value;
                    dtToDate.Value = entRoomOutOfOrder.ToDate.Value;
                    txtRemarks.Text = entRoomOutOfOrder.Remarks;

                    if (entRoomOutOfOrder.Cancelled.toBool())
                    {
                        lblStatus.Text = MessageKeys.MsgCancelledVoucher;
                        lblStatus.Visible = true;
                        EditButton.Visible = SaveButton.Visible = false;
                    }
                    else
                    {
                        lblStatus.Text = "--";
                        lblStatus.Visible = false;
                        EditButton.Visible = SaveButton.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool RoomOutofOrderView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {

                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vRoomOutOfOrder = new { id = 0, VoucherNo = "", VoucherDate = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vRoomOutOfOrder).id);
                }
                else 
                {
                    cmbRoom.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool RoomOutofOrderView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void RoomOutofOrderView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoom.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool RoomOutofOrderView_atPrint(object source)
        {
            if (entRoomOutOfOrder.id == 0)
            {
                atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
            printInvoice.PrintOut("HTL_Room out of Order", entRoomOutOfOrder.id, 0, GlobalFunctions.blnPrintPreview);
            return true;
        }
        private bool RoomOutofOrderView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_RoomOutofOrder, entRoomOutOfOrder);
                if (GlobalFunctions.blnVoucherCancelling)
                {
                    entRoomOutOfOrder.LocationID = GlobalFunctions.LoginLocationID;
                    entRoomOutOfOrder.LoginUserID = GlobalFunctions.LoginUserID;
                    entRoomOutOfOrder.Cancelled = true;
                    dbh.ObjectStateManager.ChangeObjectState(entRoomOutOfOrder, EntityState.Modified);
                }
                else
                {
                    dbh.RoomOutofOrders.DeleteObject(entRoomOutOfOrder);
                }
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void RoomOutofOrderView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
