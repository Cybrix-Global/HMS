﻿namespace atACC.HTL.Transactions
{
    partial class CheckInExtraServicesView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckInExtraServicesView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlBottom = new atACCFramework.UserControls.atPanel();
            this.btnOK = new atACCFramework.UserControls.atButton();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblCaption = new atACCFramework.UserControls.atLabel();
            this.pnldgDetails = new atACCFramework.UserControls.atPanel();
            this.dgDetails = new atACCFramework.UserControls.atGridView();
            this.col_slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExtraServiceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_DiscountSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscountPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TaxableAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_GSTSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExciseSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExcisePerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExciseAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX1SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX2SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX3SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_AddnlTaxSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_InclusiveRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_NetAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_VATSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindCheckInExtraServiceDTL = new System.Windows.Forms.BindingSource(this.components);
            this.txtGross = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotal = new atACCFramework.UserControls.atLabel();
            this.txtTotalDiscount = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotalDisc = new atACCFramework.UserControls.atLabel();
            this.lblTotalTax = new atACCFramework.UserControls.TaxLabel();
            this.txtNetTotal = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetTotal = new atACCFramework.UserControls.atLabel();
            this.txtTotalTax = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotQty = new atACCFramework.UserControls.atNumericLabel();
            this.totqtycap = new atACCFramework.UserControls.atLabel();
            this.pnlBottom.SuspendLayout();
            this.pnldgDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindCheckInExtraServiceDTL)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            this.pnlBottom.BackColor = System.Drawing.SystemColors.Window;
            this.pnlBottom.Controls.Add(this.btnOK);
            this.pnlBottom.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlBottom.Name = "pnlBottom";
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnOK.FlatAppearance.BorderSize = 0;
            this.btnOK.ForeColor = System.Drawing.Color.White;
            this.btnOK.Name = "btnOK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // lblCaption
            // 
            resources.ApplyResources(this.lblCaption, "lblCaption");
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.RequiredField = false;
            // 
            // pnldgDetails
            // 
            resources.ApplyResources(this.pnldgDetails, "pnldgDetails");
            this.pnldgDetails.BackColor = System.Drawing.SystemColors.Window;
            this.pnldgDetails.Controls.Add(this.dgDetails);
            this.pnldgDetails.Name = "pnldgDetails";
            // 
            // dgDetails
            // 
            resources.ApplyResources(this.dgDetails, "dgDetails");
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_slno,
            this.col_Code,
            this.col_Service,
            this.col_FK_ExtraServiceID,
            this.col_Qty,
            this.col_Rate,
            this.col_Amount,
            this.col_DeductionPerc,
            this.col_DeductionAmount,
            this.col_TotalTax,
            this.col_FK_DiscountSlabID,
            this.col_SlabDiscountPerc,
            this.col_SlabDiscount,
            this.col_TotalDiscount,
            this.col_TaxableAmount,
            this.col_FK_GSTSlabID,
            this.col_CGSTPerc,
            this.col_CGSTAmount,
            this.col_SGSTPerc,
            this.col_SGSTAmount,
            this.col_IGSTPerc,
            this.col_IGSTAmount,
            this.col_VATPerc,
            this.col_VATAmount,
            this.col_FK_ExciseSlabID,
            this.col_ExcisePerc,
            this.col_ExciseAmount,
            this.col_FK_TAX1SlabID,
            this.col_Tax1Perc,
            this.col_Tax1Amount,
            this.col_FK_TAX2SlabID,
            this.col_Tax2Perc,
            this.col_Tax2Amount,
            this.col_FK_TAX3SlabID,
            this.col_Tax3Perc,
            this.col_Tax3Amount,
            this.col_FK_AddnlTaxSlabID,
            this.col_AddnlTaxPerc,
            this.col_AddnlTaxAmount,
            this.col_InclusiveRate,
            this.col_NetAmount,
            this.col_FK_VATSlabID});
            this.dgDetails.EnableHeadersVisualStyles = false;
            this.dgDetails.EnterKeyNavigation = false;
            this.dgDetails.LastKey = System.Windows.Forms.Keys.None;
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle31.NullValue = null;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle31;
            this.dgDetails.sGridID = null;
            this.dgDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEndEdit);
            this.dgDetails.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEnter);
            this.dgDetails.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgDetails_CellValidating);
            this.dgDetails.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgDetails_DataError);
            this.dgDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgDetails_EditingControlShowing);
            this.dgDetails.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgDetails_RowsAdded);
            this.dgDetails.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgDetails_RowsRemoved);
            // 
            // col_slno
            // 
            this.col_slno.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_slno.FillWeight = 111.905F;
            resources.ApplyResources(this.col_slno, "col_slno");
            this.col_slno.Name = "col_slno";
            this.col_slno.ReadOnly = true;
            // 
            // col_Code
            // 
            this.col_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Code.DataPropertyName = "ServiceCode";
            this.col_Code.FillWeight = 95.68391F;
            resources.ApplyResources(this.col_Code, "col_Code");
            this.col_Code.Name = "col_Code";
            this.col_Code.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // col_Service
            // 
            this.col_Service.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Service.DataPropertyName = "ServiceName";
            this.col_Service.FillWeight = 286.4355F;
            resources.ApplyResources(this.col_Service, "col_Service");
            this.col_Service.Name = "col_Service";
            this.col_Service.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Service.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // col_FK_ExtraServiceID
            // 
            this.col_FK_ExtraServiceID.DataPropertyName = "FK_ExtraServiceID";
            resources.ApplyResources(this.col_FK_ExtraServiceID, "col_FK_ExtraServiceID");
            this.col_FK_ExtraServiceID.Name = "col_FK_ExtraServiceID";
            this.col_FK_ExtraServiceID.ReadOnly = true;
            // 
            // col_Qty
            // 
            this.col_Qty.DataPropertyName = "Qty";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_Qty.DefaultCellStyle = dataGridViewCellStyle3;
            this.col_Qty.FillWeight = 91.05099F;
            resources.ApplyResources(this.col_Qty, "col_Qty");
            this.col_Qty.Name = "col_Qty";
            // 
            // col_Rate
            // 
            this.col_Rate.DataPropertyName = "Rate";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Rate.DefaultCellStyle = dataGridViewCellStyle4;
            this.col_Rate.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Rate, "col_Rate");
            this.col_Rate.Name = "col_Rate";
            // 
            // col_Amount
            // 
            this.col_Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Amount.DefaultCellStyle = dataGridViewCellStyle5;
            this.col_Amount.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Amount, "col_Amount");
            this.col_Amount.Name = "col_Amount";
            this.col_Amount.ReadOnly = true;
            // 
            // col_DeductionPerc
            // 
            this.col_DeductionPerc.DataPropertyName = "DeductionPerc";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionPerc.DefaultCellStyle = dataGridViewCellStyle6;
            resources.ApplyResources(this.col_DeductionPerc, "col_DeductionPerc");
            this.col_DeductionPerc.Name = "col_DeductionPerc";
            // 
            // col_DeductionAmount
            // 
            this.col_DeductionAmount.DataPropertyName = "DeductionAmount";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionAmount.DefaultCellStyle = dataGridViewCellStyle7;
            resources.ApplyResources(this.col_DeductionAmount, "col_DeductionAmount");
            this.col_DeductionAmount.Name = "col_DeductionAmount";
            this.col_DeductionAmount.ReadOnly = true;
            // 
            // col_TotalTax
            // 
            this.col_TotalTax.DataPropertyName = "TotalTax";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TotalTax.DefaultCellStyle = dataGridViewCellStyle8;
            resources.ApplyResources(this.col_TotalTax, "col_TotalTax");
            this.col_TotalTax.Name = "col_TotalTax";
            this.col_TotalTax.ReadOnly = true;
            // 
            // col_FK_DiscountSlabID
            // 
            this.col_FK_DiscountSlabID.DataPropertyName = "FK_DiscountSlabID";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_DiscountSlabID.DefaultCellStyle = dataGridViewCellStyle9;
            resources.ApplyResources(this.col_FK_DiscountSlabID, "col_FK_DiscountSlabID");
            this.col_FK_DiscountSlabID.Name = "col_FK_DiscountSlabID";
            // 
            // col_SlabDiscountPerc
            // 
            this.col_SlabDiscountPerc.DataPropertyName = "SlabDiscountPerc";
            resources.ApplyResources(this.col_SlabDiscountPerc, "col_SlabDiscountPerc");
            this.col_SlabDiscountPerc.Name = "col_SlabDiscountPerc";
            // 
            // col_SlabDiscount
            // 
            this.col_SlabDiscount.DataPropertyName = "SlabDiscount";
            resources.ApplyResources(this.col_SlabDiscount, "col_SlabDiscount");
            this.col_SlabDiscount.Name = "col_SlabDiscount";
            // 
            // col_TotalDiscount
            // 
            this.col_TotalDiscount.DataPropertyName = "TotalDiscount";
            resources.ApplyResources(this.col_TotalDiscount, "col_TotalDiscount");
            this.col_TotalDiscount.Name = "col_TotalDiscount";
            // 
            // col_TaxableAmount
            // 
            this.col_TaxableAmount.DataPropertyName = "TaxableAmount";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TaxableAmount.DefaultCellStyle = dataGridViewCellStyle10;
            resources.ApplyResources(this.col_TaxableAmount, "col_TaxableAmount");
            this.col_TaxableAmount.Name = "col_TaxableAmount";
            this.col_TaxableAmount.ReadOnly = true;
            // 
            // col_FK_GSTSlabID
            // 
            this.col_FK_GSTSlabID.DataPropertyName = "FK_GSTSlabID";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_GSTSlabID.DefaultCellStyle = dataGridViewCellStyle11;
            resources.ApplyResources(this.col_FK_GSTSlabID, "col_FK_GSTSlabID");
            this.col_FK_GSTSlabID.Name = "col_FK_GSTSlabID";
            // 
            // col_CGSTPerc
            // 
            this.col_CGSTPerc.DataPropertyName = "CGSTPerc";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTPerc.DefaultCellStyle = dataGridViewCellStyle12;
            resources.ApplyResources(this.col_CGSTPerc, "col_CGSTPerc");
            this.col_CGSTPerc.Name = "col_CGSTPerc";
            this.col_CGSTPerc.ReadOnly = true;
            // 
            // col_CGSTAmount
            // 
            this.col_CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTAmount.DefaultCellStyle = dataGridViewCellStyle13;
            resources.ApplyResources(this.col_CGSTAmount, "col_CGSTAmount");
            this.col_CGSTAmount.Name = "col_CGSTAmount";
            this.col_CGSTAmount.ReadOnly = true;
            // 
            // col_SGSTPerc
            // 
            this.col_SGSTPerc.DataPropertyName = "SGSTPerc";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTPerc.DefaultCellStyle = dataGridViewCellStyle14;
            resources.ApplyResources(this.col_SGSTPerc, "col_SGSTPerc");
            this.col_SGSTPerc.Name = "col_SGSTPerc";
            this.col_SGSTPerc.ReadOnly = true;
            // 
            // col_SGSTAmount
            // 
            this.col_SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTAmount.DefaultCellStyle = dataGridViewCellStyle15;
            resources.ApplyResources(this.col_SGSTAmount, "col_SGSTAmount");
            this.col_SGSTAmount.Name = "col_SGSTAmount";
            this.col_SGSTAmount.ReadOnly = true;
            // 
            // col_IGSTPerc
            // 
            this.col_IGSTPerc.DataPropertyName = "IGSTPerc";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTPerc.DefaultCellStyle = dataGridViewCellStyle16;
            resources.ApplyResources(this.col_IGSTPerc, "col_IGSTPerc");
            this.col_IGSTPerc.Name = "col_IGSTPerc";
            this.col_IGSTPerc.ReadOnly = true;
            // 
            // col_IGSTAmount
            // 
            this.col_IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTAmount.DefaultCellStyle = dataGridViewCellStyle17;
            resources.ApplyResources(this.col_IGSTAmount, "col_IGSTAmount");
            this.col_IGSTAmount.Name = "col_IGSTAmount";
            this.col_IGSTAmount.ReadOnly = true;
            // 
            // col_VATPerc
            // 
            this.col_VATPerc.DataPropertyName = "VATPerc";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATPerc.DefaultCellStyle = dataGridViewCellStyle18;
            resources.ApplyResources(this.col_VATPerc, "col_VATPerc");
            this.col_VATPerc.Name = "col_VATPerc";
            this.col_VATPerc.ReadOnly = true;
            // 
            // col_VATAmount
            // 
            this.col_VATAmount.DataPropertyName = "VATAmount";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATAmount.DefaultCellStyle = dataGridViewCellStyle19;
            resources.ApplyResources(this.col_VATAmount, "col_VATAmount");
            this.col_VATAmount.Name = "col_VATAmount";
            this.col_VATAmount.ReadOnly = true;
            // 
            // col_FK_ExciseSlabID
            // 
            this.col_FK_ExciseSlabID.DataPropertyName = "FK_ExciseSlabID";
            resources.ApplyResources(this.col_FK_ExciseSlabID, "col_FK_ExciseSlabID");
            this.col_FK_ExciseSlabID.Name = "col_FK_ExciseSlabID";
            // 
            // col_ExcisePerc
            // 
            this.col_ExcisePerc.DataPropertyName = "ExcisePerc";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExcisePerc.DefaultCellStyle = dataGridViewCellStyle20;
            resources.ApplyResources(this.col_ExcisePerc, "col_ExcisePerc");
            this.col_ExcisePerc.Name = "col_ExcisePerc";
            this.col_ExcisePerc.ReadOnly = true;
            // 
            // col_ExciseAmount
            // 
            this.col_ExciseAmount.DataPropertyName = "ExciseAmount";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExciseAmount.DefaultCellStyle = dataGridViewCellStyle21;
            resources.ApplyResources(this.col_ExciseAmount, "col_ExciseAmount");
            this.col_ExciseAmount.Name = "col_ExciseAmount";
            this.col_ExciseAmount.ReadOnly = true;
            // 
            // col_FK_TAX1SlabID
            // 
            this.col_FK_TAX1SlabID.DataPropertyName = "FK_TAX1SlabID";
            resources.ApplyResources(this.col_FK_TAX1SlabID, "col_FK_TAX1SlabID");
            this.col_FK_TAX1SlabID.Name = "col_FK_TAX1SlabID";
            // 
            // col_Tax1Perc
            // 
            this.col_Tax1Perc.DataPropertyName = "Tax1Perc";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Perc.DefaultCellStyle = dataGridViewCellStyle22;
            resources.ApplyResources(this.col_Tax1Perc, "col_Tax1Perc");
            this.col_Tax1Perc.Name = "col_Tax1Perc";
            this.col_Tax1Perc.ReadOnly = true;
            // 
            // col_Tax1Amount
            // 
            this.col_Tax1Amount.DataPropertyName = "Tax1Amount";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Amount.DefaultCellStyle = dataGridViewCellStyle23;
            resources.ApplyResources(this.col_Tax1Amount, "col_Tax1Amount");
            this.col_Tax1Amount.Name = "col_Tax1Amount";
            this.col_Tax1Amount.ReadOnly = true;
            // 
            // col_FK_TAX2SlabID
            // 
            this.col_FK_TAX2SlabID.DataPropertyName = "FK_TAX2SlabID";
            resources.ApplyResources(this.col_FK_TAX2SlabID, "col_FK_TAX2SlabID");
            this.col_FK_TAX2SlabID.Name = "col_FK_TAX2SlabID";
            // 
            // col_Tax2Perc
            // 
            this.col_Tax2Perc.DataPropertyName = "Tax2Perc";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Perc.DefaultCellStyle = dataGridViewCellStyle24;
            resources.ApplyResources(this.col_Tax2Perc, "col_Tax2Perc");
            this.col_Tax2Perc.Name = "col_Tax2Perc";
            this.col_Tax2Perc.ReadOnly = true;
            // 
            // col_Tax2Amount
            // 
            this.col_Tax2Amount.DataPropertyName = "Tax2Amount";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Amount.DefaultCellStyle = dataGridViewCellStyle25;
            resources.ApplyResources(this.col_Tax2Amount, "col_Tax2Amount");
            this.col_Tax2Amount.Name = "col_Tax2Amount";
            this.col_Tax2Amount.ReadOnly = true;
            // 
            // col_FK_TAX3SlabID
            // 
            this.col_FK_TAX3SlabID.DataPropertyName = "FK_TAX3SlabID";
            resources.ApplyResources(this.col_FK_TAX3SlabID, "col_FK_TAX3SlabID");
            this.col_FK_TAX3SlabID.Name = "col_FK_TAX3SlabID";
            // 
            // col_Tax3Perc
            // 
            this.col_Tax3Perc.DataPropertyName = "Tax3Perc";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Perc.DefaultCellStyle = dataGridViewCellStyle26;
            resources.ApplyResources(this.col_Tax3Perc, "col_Tax3Perc");
            this.col_Tax3Perc.Name = "col_Tax3Perc";
            this.col_Tax3Perc.ReadOnly = true;
            // 
            // col_Tax3Amount
            // 
            this.col_Tax3Amount.DataPropertyName = "Tax3Amount";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Amount.DefaultCellStyle = dataGridViewCellStyle27;
            resources.ApplyResources(this.col_Tax3Amount, "col_Tax3Amount");
            this.col_Tax3Amount.Name = "col_Tax3Amount";
            this.col_Tax3Amount.ReadOnly = true;
            // 
            // col_FK_AddnlTaxSlabID
            // 
            this.col_FK_AddnlTaxSlabID.DataPropertyName = "FK_AddnlTaxSlabID";
            resources.ApplyResources(this.col_FK_AddnlTaxSlabID, "col_FK_AddnlTaxSlabID");
            this.col_FK_AddnlTaxSlabID.Name = "col_FK_AddnlTaxSlabID";
            // 
            // col_AddnlTaxPerc
            // 
            this.col_AddnlTaxPerc.DataPropertyName = "AddnlTaxPerc";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxPerc.DefaultCellStyle = dataGridViewCellStyle28;
            resources.ApplyResources(this.col_AddnlTaxPerc, "col_AddnlTaxPerc");
            this.col_AddnlTaxPerc.Name = "col_AddnlTaxPerc";
            this.col_AddnlTaxPerc.ReadOnly = true;
            // 
            // col_AddnlTaxAmount
            // 
            this.col_AddnlTaxAmount.DataPropertyName = "AddnlTaxAmount";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxAmount.DefaultCellStyle = dataGridViewCellStyle29;
            resources.ApplyResources(this.col_AddnlTaxAmount, "col_AddnlTaxAmount");
            this.col_AddnlTaxAmount.Name = "col_AddnlTaxAmount";
            this.col_AddnlTaxAmount.ReadOnly = true;
            // 
            // col_InclusiveRate
            // 
            this.col_InclusiveRate.DataPropertyName = "InclusiveRate";
            resources.ApplyResources(this.col_InclusiveRate, "col_InclusiveRate");
            this.col_InclusiveRate.Name = "col_InclusiveRate";
            // 
            // col_NetAmount
            // 
            this.col_NetAmount.DataPropertyName = "NetAmount";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_NetAmount.DefaultCellStyle = dataGridViewCellStyle30;
            resources.ApplyResources(this.col_NetAmount, "col_NetAmount");
            this.col_NetAmount.Name = "col_NetAmount";
            this.col_NetAmount.ReadOnly = true;
            // 
            // col_FK_VATSlabID
            // 
            this.col_FK_VATSlabID.DataPropertyName = "FK_VATSlabID";
            resources.ApplyResources(this.col_FK_VATSlabID, "col_FK_VATSlabID");
            this.col_FK_VATSlabID.Name = "col_FK_VATSlabID";
            // 
            // txtGross
            // 
            resources.ApplyResources(this.txtGross, "txtGross");
            this.txtGross.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGross.ForeColor = System.Drawing.Color.Black;
            this.txtGross.Format = "N2";
            this.txtGross.Name = "txtGross";
            this.txtGross.RequiredField = false;
            this.txtGross.UseCompatibleTextRendering = true;
            this.txtGross.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotal
            // 
            resources.ApplyResources(this.lblTotal, "lblTotal");
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.RequiredField = false;
            // 
            // txtTotalDiscount
            // 
            resources.ApplyResources(this.txtTotalDiscount, "txtTotalDiscount");
            this.txtTotalDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalDiscount.Format = "N2";
            this.txtTotalDiscount.Name = "txtTotalDiscount";
            this.txtTotalDiscount.RequiredField = false;
            this.txtTotalDiscount.UseCompatibleTextRendering = true;
            this.txtTotalDiscount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotalDisc
            // 
            resources.ApplyResources(this.lblTotalDisc, "lblTotalDisc");
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.RequiredField = false;
            // 
            // lblTotalTax
            // 
            resources.ApplyResources(this.lblTotalTax, "lblTotalTax");
            this.lblTotalTax.DisabledLinkColor = System.Drawing.Color.Red;
            this.lblTotalTax.Format = null;
            this.lblTotalTax.lblAddnlTax = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblCGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblExciseDuty = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblIGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblSGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax1 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax2 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax3 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblVAT = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblTotalTax.LinkColor = System.Drawing.Color.Black;
            this.lblTotalTax.Name = "lblTotalTax";
            this.lblTotalTax.TabStop = true;
            this.lblTotalTax.VisitedLinkColor = System.Drawing.Color.Blue;
            // 
            // txtNetTotal
            // 
            resources.ApplyResources(this.txtNetTotal, "txtNetTotal");
            this.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNetTotal.ForeColor = System.Drawing.Color.Black;
            this.txtNetTotal.Format = "N2";
            this.txtNetTotal.Name = "txtNetTotal";
            this.txtNetTotal.RequiredField = false;
            this.txtNetTotal.UseCompatibleTextRendering = true;
            this.txtNetTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetTotal
            // 
            resources.ApplyResources(this.lblNetTotal, "lblNetTotal");
            this.lblNetTotal.Name = "lblNetTotal";
            this.lblNetTotal.RequiredField = false;
            // 
            // txtTotalTax
            // 
            resources.ApplyResources(this.txtTotalTax, "txtTotalTax");
            this.txtTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalTax.ForeColor = System.Drawing.Color.Black;
            this.txtTotalTax.Format = "N2";
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.RequiredField = false;
            this.txtTotalTax.UseCompatibleTextRendering = true;
            this.txtTotalTax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotQty
            // 
            resources.ApplyResources(this.lblTotQty, "lblTotQty");
            this.lblTotQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotQty.ForeColor = System.Drawing.Color.Black;
            this.lblTotQty.Format = "N2";
            this.lblTotQty.Name = "lblTotQty";
            this.lblTotQty.RequiredField = false;
            this.lblTotQty.UseCompatibleTextRendering = true;
            this.lblTotQty.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // totqtycap
            // 
            resources.ApplyResources(this.totqtycap, "totqtycap");
            this.totqtycap.Name = "totqtycap";
            this.totqtycap.RequiredField = false;
            // 
            // CheckInExtraServicesView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblTotQty);
            this.Controls.Add(this.totqtycap);
            this.Controls.Add(this.txtGross);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.txtTotalDiscount);
            this.Controls.Add(this.lblTotalDisc);
            this.Controls.Add(this.lblTotalTax);
            this.Controls.Add(this.txtNetTotal);
            this.Controls.Add(this.lblNetTotal);
            this.Controls.Add(this.txtTotalTax);
            this.Controls.Add(this.pnldgDetails);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblCaption);
            this.Name = "CheckInExtraServicesView";
            this.Shown += new System.EventHandler(this.CheckInExtraServicesView_Shown);
            this.pnlBottom.ResumeLayout(false);
            this.pnldgDetails.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindCheckInExtraServiceDTL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlBottom;
        private atACCFramework.UserControls.atButton btnOK;
        private System.Windows.Forms.Button btnClose;
        private atACCFramework.UserControls.atLabel lblCaption;
        private atACCFramework.UserControls.atPanel pnldgDetails;
        private atACCFramework.UserControls.atGridView dgDetails;
        private System.Windows.Forms.BindingSource bindCheckInExtraServiceDTL;
        private atACCFramework.UserControls.atNumericLabel txtGross;
        private atACCFramework.UserControls.atLabel lblTotal;
        private atACCFramework.UserControls.atNumericLabel txtTotalDiscount;
        private atACCFramework.UserControls.atLabel lblTotalDisc;
        private atACCFramework.UserControls.TaxLabel lblTotalTax;
        private atACCFramework.UserControls.atNumericLabel txtNetTotal;
        private atACCFramework.UserControls.atLabel lblNetTotal;
        private atACCFramework.UserControls.atNumericLabel txtTotalTax;
        private atACCFramework.UserControls.atNumericLabel lblTotQty;
        private atACCFramework.UserControls.atLabel totqtycap;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Service;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExtraServiceID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_DiscountSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscountPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TaxableAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_GSTSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExciseSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExcisePerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExciseAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX1SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX2SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX3SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_AddnlTaxSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_InclusiveRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_NetAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_VATSlabID;
    }
}