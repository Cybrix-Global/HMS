﻿namespace atACC.HTL.Transactions
{
    partial class GroupCheckInView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroupCheckInView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblBooking = new atACCFramework.UserControls.atLabel();
            this.cmbGrpBooking = new atACCFramework.UserControls.ComboBoxExt();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.cmbAgent = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbSource = new atACCFramework.UserControls.ComboBoxExt();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.txtNoOfDays = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfDays = new atACCFramework.UserControls.atLabel();
            this.lblAgent = new atACCFramework.UserControls.atLabel();
            this.lblSource = new atACCFramework.UserControls.atLabel();
            this.cmbVoucherDiscount = new atACCFramework.UserControls.ComboBoxExt();
            this.txtVoucherDiscountAmount = new atACCFramework.UserControls.TextBoxExt();
            this.lblVoucherDiscount = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDiscountAmount = new atACCFramework.UserControls.atLabel();
            this.cmbGuest = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbGuestVehicleType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.txtGuestVehicleName = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuestVehicleName = new atACCFramework.UserControls.atLabel();
            this.cmbBillingAccount = new atACCFramework.UserControls.ComboBoxExt();
            this.lblBillingAccountID = new atACCFramework.UserControls.atLabel();
            this.cmbGuestType = new atACCFramework.UserControls.ComboBoxExt();
            this.txtGuestVehicleNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuestType = new atACCFramework.UserControls.atLabel();
            this.lblGuestVehicleNo = new atACCFramework.UserControls.atLabel();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.btnExtraServ = new atACCFramework.UserControls.atButton();
            this.txtGross = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotal = new atACCFramework.UserControls.atLabel();
            this.txtExtraServicesAmnt = new atACCFramework.UserControls.atNumericLabel();
            this.lblOpBalance = new atACC.HTL.Transactions.AccountLabel();
            this.txtNetTotal = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetTotal = new atACCFramework.UserControls.atLabel();
            this.txtOpBalance = new atACCFramework.UserControls.atNumericLabel();
            this.txtRoomRent = new atACCFramework.UserControls.atNumericLabel();
            this.txtTotalAdults = new atACCFramework.UserControls.atNumericLabel();
            this.txtTotalDiscount = new atACCFramework.UserControls.atNumericLabel();
            this.lblRoomAmount = new atACCFramework.UserControls.atLabel();
            this.lblTotalDisc = new atACCFramework.UserControls.atLabel();
            this.lblTotalTax = new atACCFramework.UserControls.TaxLabel();
            this.txtTotalTax = new atACCFramework.UserControls.atNumericLabel();
            this.txtTotalChilds = new atACCFramework.UserControls.atNumericLabel();
            this.txtAdvance = new atACCFramework.UserControls.atNumericLabel();
            this.lblAdvance = new atACCFramework.UserControls.atLabel();
            this.btnPayment = new atACCFramework.UserControls.atButton();
            this.txtBalance = new atACCFramework.UserControls.TextBoxNormal();
            this.txtPayment = new atACCFramework.UserControls.atNumericLabel();
            this.lblBalance = new atACCFramework.UserControls.atLabel();
            this.lblAdult = new atACCFramework.UserControls.atLabel();
            this.lblChild = new atACCFramework.UserControls.atLabel();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfRooms = new atACCFramework.UserControls.atLabel();
            this.lblNoOfHalls = new atACCFramework.UserControls.atLabel();
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.lblGrandTotal = new atACCFramework.UserControls.atNumericLabel();
            this.atlblTot = new atACCFramework.UserControls.atLabel();
            this.bindCheckInDTL = new System.Windows.Forms.BindingSource(this.components);
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.btnAllocate = new atACCFramework.UserControls.atButton();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.txtExRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblExRateCap = new atACCFramework.UserControls.atLabel();
            this.lblCurrencyCap = new atACCFramework.UserControls.atLabel();
            this.txtDeductionPerc = new atACCFramework.UserControls.TextBoxExt();
            this.lblDeuctionPerc = new atACCFramework.UserControls.atLabel();
            this.cmbCurrency = new atACCFramework.UserControls.ComboBoxExt();
            this.lblDeduction = new atACCFramework.UserControls.atLabel();
            this.btnGrpCheckOut = new System.Windows.Forms.Button();
            this.btnNewGuestType = new atACCFramework.UserControls.atButton();
            this.btnNewGuest = new atACCFramework.UserControls.atButton();
            this.btnNewSource = new atACCFramework.UserControls.atButton();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.txtNoOfHalls = new atACCFramework.UserControls.TextBoxExt();
            this.txtNoOfRooms = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory6 = new System.Windows.Forms.Label();
            this.lblMandatory7 = new System.Windows.Forms.Label();
            this.txtDeductionAmount = new atACCFramework.UserControls.TextBoxExt();
            this.pnlGridContain = new atACCFramework.UserControls.atPanel();
            this.dgDetails = new atACCFramework.UserControls.atGridView();
            this.col_slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_RoomOrHall = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.col_RoomType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.col_Room = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Col_RateType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Col_Adult = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Child = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalBeds = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalBedRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalPersons = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalPersonRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.lblExternal = new atACC.HTL.Transactions.AccountLabel();
            this.txtExternalAmt = new atACCFramework.UserControls.atNumericLabel();
            this.lblAddlBedAndPerson = new atACCFramework.UserControls.atLabel();
            this.txtExtraBedAndPer = new atACCFramework.UserControls.atNumericLabel();
            this.grpDiscountVoucher = new atACCFramework.UserControls.atGroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblPayment = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlHeader2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindCheckInDTL)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.pnlGridContain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.pnlFooter.SuspendLayout();
            this.grpDiscountVoucher.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnPayment);
            this.panel1.Controls.Add(this.lblGrandTotal);
            this.panel1.Controls.Add(this.atlblTot);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.SetChildIndex(this.atlblTot, 0);
            this.panel1.Controls.SetChildIndex(this.lblGrandTotal, 0);
            this.panel1.Controls.SetChildIndex(this.btnPayment, 0);
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            // 
            // lblBooking
            // 
            resources.ApplyResources(this.lblBooking, "lblBooking");
            this.lblBooking.Name = "lblBooking";
            this.lblBooking.RequiredField = false;
            // 
            // cmbGrpBooking
            // 
            resources.ApplyResources(this.cmbGrpBooking, "cmbGrpBooking");
            this.cmbGrpBooking.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGrpBooking.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGrpBooking.DropDownHeight = 300;
            this.cmbGrpBooking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGrpBooking.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGrpBooking, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGrpBooking.IconAlignment"))));
            this.cmbGrpBooking.Name = "cmbGrpBooking";
            this.cmbGrpBooking.SelectedValueChanged += new System.EventHandler(this.cmbBooking_SelectedValueChanged);
            // 
            // dtpArrivalDate
            // 
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpArrivalDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // cmbAgent
            // 
            resources.ApplyResources(this.cmbAgent, "cmbAgent");
            this.cmbAgent.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAgent.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAgent.DropDownHeight = 300;
            this.cmbAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAgent.FormattingEnabled = true;
            this.cmbAgent.Name = "cmbAgent";
            // 
            // cmbSource
            // 
            this.cmbSource.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSource.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSource.DropDownHeight = 300;
            this.cmbSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbSource, "cmbSource");
            this.cmbSource.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbSource, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbSource.IconAlignment"))));
            this.cmbSource.Name = "cmbSource";
            // 
            // dtpDepartureDate
            // 
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpDepartureDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // txtNoOfDays
            // 
            resources.ApplyResources(this.txtNoOfDays, "txtNoOfDays");
            this.txtNoOfDays.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfDays.Format = null;
            this.txtNoOfDays.isAllowNegative = false;
            this.txtNoOfDays.isAllowSpecialChar = false;
            this.txtNoOfDays.isNumbersOnly = true;
            this.txtNoOfDays.isNumeric = false;
            this.txtNoOfDays.isTouchable = true;
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.ReadOnly = true;
            this.txtNoOfDays.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNoOfDays
            // 
            resources.ApplyResources(this.lblNoOfDays, "lblNoOfDays");
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.RequiredField = false;
            // 
            // lblAgent
            // 
            resources.ApplyResources(this.lblAgent, "lblAgent");
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.RequiredField = false;
            // 
            // lblSource
            // 
            resources.ApplyResources(this.lblSource, "lblSource");
            this.lblSource.Name = "lblSource";
            this.lblSource.RequiredField = false;
            // 
            // cmbVoucherDiscount
            // 
            this.cmbVoucherDiscount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbVoucherDiscount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVoucherDiscount.DropDownHeight = 300;
            this.cmbVoucherDiscount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbVoucherDiscount, "cmbVoucherDiscount");
            this.cmbVoucherDiscount.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbVoucherDiscount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbVoucherDiscount.IconAlignment"))));
            this.cmbVoucherDiscount.Name = "cmbVoucherDiscount";
            // 
            // txtVoucherDiscountAmount
            // 
            this.txtVoucherDiscountAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtVoucherDiscountAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVoucherDiscountAmount.Format = null;
            this.txtVoucherDiscountAmount.isAllowNegative = false;
            this.txtVoucherDiscountAmount.isAllowSpecialChar = false;
            this.txtVoucherDiscountAmount.isNumbersOnly = false;
            this.txtVoucherDiscountAmount.isNumeric = true;
            this.txtVoucherDiscountAmount.isTouchable = true;
            resources.ApplyResources(this.txtVoucherDiscountAmount, "txtVoucherDiscountAmount");
            this.txtVoucherDiscountAmount.Name = "txtVoucherDiscountAmount";
            this.txtVoucherDiscountAmount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblVoucherDiscount
            // 
            resources.ApplyResources(this.lblVoucherDiscount, "lblVoucherDiscount");
            this.lblVoucherDiscount.Name = "lblVoucherDiscount";
            this.lblVoucherDiscount.RequiredField = false;
            // 
            // lblVoucherDiscountAmount
            // 
            resources.ApplyResources(this.lblVoucherDiscountAmount, "lblVoucherDiscountAmount");
            this.lblVoucherDiscountAmount.Name = "lblVoucherDiscountAmount";
            this.lblVoucherDiscountAmount.RequiredField = false;
            // 
            // cmbGuest
            // 
            this.cmbGuest.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuest.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuest.DropDownHeight = 300;
            this.cmbGuest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuest, "cmbGuest");
            this.cmbGuest.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuest, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuest.IconAlignment"))));
            this.cmbGuest.Name = "cmbGuest";
            this.cmbGuest.SelectedValueChanged += new System.EventHandler(this.cmbGuest_SelectedValueChanged);
            this.cmbGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbGuest_KeyPress);
            // 
            // cmbGuestVehicleType
            // 
            this.cmbGuestVehicleType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuestVehicleType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuestVehicleType.DropDownHeight = 300;
            resources.ApplyResources(this.cmbGuestVehicleType, "cmbGuestVehicleType");
            this.cmbGuestVehicleType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuestVehicleType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuestVehicleType.IconAlignment"))));
            this.cmbGuestVehicleType.Name = "cmbGuestVehicleType";
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // txtGuestVehicleName
            // 
            this.txtGuestVehicleName.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuestVehicleName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtGuestVehicleName, "txtGuestVehicleName");
            this.txtGuestVehicleName.Format = null;
            this.txtGuestVehicleName.isAllowNegative = false;
            this.txtGuestVehicleName.isAllowSpecialChar = false;
            this.txtGuestVehicleName.isNumbersOnly = false;
            this.txtGuestVehicleName.isNumeric = false;
            this.txtGuestVehicleName.isTouchable = false;
            this.txtGuestVehicleName.Name = "txtGuestVehicleName";
            this.txtGuestVehicleName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblGuestVehicleName
            // 
            resources.ApplyResources(this.lblGuestVehicleName, "lblGuestVehicleName");
            this.lblGuestVehicleName.Name = "lblGuestVehicleName";
            this.lblGuestVehicleName.RequiredField = false;
            // 
            // cmbBillingAccount
            // 
            this.cmbBillingAccount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBillingAccount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBillingAccount.DropDownHeight = 300;
            this.cmbBillingAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbBillingAccount, "cmbBillingAccount");
            this.cmbBillingAccount.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbBillingAccount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbBillingAccount.IconAlignment"))));
            this.cmbBillingAccount.Name = "cmbBillingAccount";
            this.cmbBillingAccount.SelectedValueChanged += new System.EventHandler(this.cmbBillingAccount_SelectedValueChanged);
            // 
            // lblBillingAccountID
            // 
            resources.ApplyResources(this.lblBillingAccountID, "lblBillingAccountID");
            this.lblBillingAccountID.Name = "lblBillingAccountID";
            this.lblBillingAccountID.RequiredField = false;
            // 
            // cmbGuestType
            // 
            this.cmbGuestType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuestType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuestType.DropDownHeight = 300;
            this.cmbGuestType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuestType, "cmbGuestType");
            this.cmbGuestType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuestType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuestType.IconAlignment"))));
            this.cmbGuestType.Name = "cmbGuestType";
            // 
            // txtGuestVehicleNo
            // 
            this.txtGuestVehicleNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuestVehicleNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtGuestVehicleNo, "txtGuestVehicleNo");
            this.txtGuestVehicleNo.Format = null;
            this.txtGuestVehicleNo.isAllowNegative = false;
            this.txtGuestVehicleNo.isAllowSpecialChar = false;
            this.txtGuestVehicleNo.isNumbersOnly = false;
            this.txtGuestVehicleNo.isNumeric = false;
            this.txtGuestVehicleNo.isTouchable = false;
            this.txtGuestVehicleNo.Name = "txtGuestVehicleNo";
            this.txtGuestVehicleNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblGuestType
            // 
            resources.ApplyResources(this.lblGuestType, "lblGuestType");
            this.lblGuestType.Name = "lblGuestType";
            this.lblGuestType.RequiredField = false;
            // 
            // lblGuestVehicleNo
            // 
            resources.ApplyResources(this.lblGuestVehicleNo, "lblGuestVehicleNo");
            this.lblGuestVehicleNo.Name = "lblGuestVehicleNo";
            this.lblGuestVehicleNo.RequiredField = false;
            // 
            // txtAdd1
            // 
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.Format = null;
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.TabStop = false;
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // txtTelephone
            // 
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.Format = null;
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = false;
            this.txtTelephone.isNumeric = true;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.TabStop = false;
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtMobile
            // 
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.Format = null;
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = false;
            this.txtMobile.isNumeric = true;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.TabStop = false;
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTelephone
            // 
            resources.ApplyResources(this.lblTelephone, "lblTelephone");
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            // 
            // btnExtraServ
            // 
            resources.ApplyResources(this.btnExtraServ, "btnExtraServ");
            this.btnExtraServ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnExtraServ.FlatAppearance.BorderSize = 0;
            this.btnExtraServ.ForeColor = System.Drawing.Color.White;
            this.btnExtraServ.Name = "btnExtraServ";
            this.btnExtraServ.UseVisualStyleBackColor = false;
            this.btnExtraServ.Click += new System.EventHandler(this.btnExtraServ_Click);
            // 
            // txtGross
            // 
            resources.ApplyResources(this.txtGross, "txtGross");
            this.txtGross.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGross.ForeColor = System.Drawing.Color.Black;
            this.txtGross.Format = "N2";
            this.txtGross.Name = "txtGross";
            this.txtGross.RequiredField = false;
            this.txtGross.UseCompatibleTextRendering = true;
            this.txtGross.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotal
            // 
            resources.ApplyResources(this.lblTotal, "lblTotal");
            this.errProvider.SetIconAlignment(this.lblTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotal.IconAlignment"))));
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.RequiredField = false;
            // 
            // txtExtraServicesAmnt
            // 
            resources.ApplyResources(this.txtExtraServicesAmnt, "txtExtraServicesAmnt");
            this.txtExtraServicesAmnt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExtraServicesAmnt.ForeColor = System.Drawing.Color.Black;
            this.txtExtraServicesAmnt.Format = "N2";
            this.txtExtraServicesAmnt.Name = "txtExtraServicesAmnt";
            this.txtExtraServicesAmnt.RequiredField = false;
            this.txtExtraServicesAmnt.UseCompatibleTextRendering = true;
            this.txtExtraServicesAmnt.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblOpBalance
            // 
            resources.ApplyResources(this.lblOpBalance, "lblOpBalance");
            this.lblOpBalance.DataSource = null;
            this.lblOpBalance.Format = null;
            this.errProvider.SetIconAlignment(this.lblOpBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblOpBalance.IconAlignment"))));
            this.lblOpBalance.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblOpBalance.Name = "lblOpBalance";
            this.lblOpBalance.TabStop = true;
            // 
            // txtNetTotal
            // 
            resources.ApplyResources(this.txtNetTotal, "txtNetTotal");
            this.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNetTotal.ForeColor = System.Drawing.Color.Black;
            this.txtNetTotal.Format = "N2";
            this.txtNetTotal.Name = "txtNetTotal";
            this.txtNetTotal.RequiredField = false;
            this.txtNetTotal.UseCompatibleTextRendering = true;
            this.txtNetTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetTotal
            // 
            resources.ApplyResources(this.lblNetTotal, "lblNetTotal");
            this.errProvider.SetIconAlignment(this.lblNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNetTotal.IconAlignment"))));
            this.lblNetTotal.Name = "lblNetTotal";
            this.lblNetTotal.RequiredField = false;
            // 
            // txtOpBalance
            // 
            resources.ApplyResources(this.txtOpBalance, "txtOpBalance");
            this.txtOpBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOpBalance.ForeColor = System.Drawing.Color.Black;
            this.txtOpBalance.Format = "N2";
            this.txtOpBalance.Name = "txtOpBalance";
            this.txtOpBalance.RequiredField = false;
            this.txtOpBalance.UseCompatibleTextRendering = true;
            this.txtOpBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtRoomRent
            // 
            resources.ApplyResources(this.txtRoomRent, "txtRoomRent");
            this.txtRoomRent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRoomRent.ForeColor = System.Drawing.Color.Black;
            this.txtRoomRent.Format = "N2";
            this.txtRoomRent.Name = "txtRoomRent";
            this.txtRoomRent.RequiredField = false;
            this.txtRoomRent.UseCompatibleTextRendering = true;
            this.txtRoomRent.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtTotalAdults
            // 
            resources.ApplyResources(this.txtTotalAdults, "txtTotalAdults");
            this.txtTotalAdults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalAdults.ForeColor = System.Drawing.Color.Black;
            this.txtTotalAdults.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtTotalAdults, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTotalAdults.IconAlignment"))));
            this.txtTotalAdults.Name = "txtTotalAdults";
            this.txtTotalAdults.RequiredField = false;
            this.txtTotalAdults.UseCompatibleTextRendering = true;
            this.txtTotalAdults.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtTotalDiscount
            // 
            resources.ApplyResources(this.txtTotalDiscount, "txtTotalDiscount");
            this.txtTotalDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalDiscount.Format = "N2";
            this.txtTotalDiscount.Name = "txtTotalDiscount";
            this.txtTotalDiscount.RequiredField = false;
            this.txtTotalDiscount.UseCompatibleTextRendering = true;
            this.txtTotalDiscount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblRoomAmount
            // 
            resources.ApplyResources(this.lblRoomAmount, "lblRoomAmount");
            this.errProvider.SetIconAlignment(this.lblRoomAmount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoomAmount.IconAlignment"))));
            this.lblRoomAmount.Name = "lblRoomAmount";
            this.lblRoomAmount.RequiredField = false;
            // 
            // lblTotalDisc
            // 
            resources.ApplyResources(this.lblTotalDisc, "lblTotalDisc");
            this.errProvider.SetIconAlignment(this.lblTotalDisc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalDisc.IconAlignment"))));
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.RequiredField = false;
            // 
            // lblTotalTax
            // 
            resources.ApplyResources(this.lblTotalTax, "lblTotalTax");
            this.lblTotalTax.DisabledLinkColor = System.Drawing.Color.Red;
            this.lblTotalTax.Format = null;
            this.lblTotalTax.lblAddnlTax = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblCGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblExciseDuty = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblIGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblSGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax1 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax2 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax3 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblVAT = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblTotalTax.LinkColor = System.Drawing.Color.Black;
            this.lblTotalTax.Name = "lblTotalTax";
            this.lblTotalTax.TabStop = true;
            this.lblTotalTax.VisitedLinkColor = System.Drawing.Color.Blue;
            // 
            // txtTotalTax
            // 
            resources.ApplyResources(this.txtTotalTax, "txtTotalTax");
            this.txtTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalTax.ForeColor = System.Drawing.Color.Black;
            this.txtTotalTax.Format = "N2";
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.RequiredField = false;
            this.txtTotalTax.UseCompatibleTextRendering = true;
            this.txtTotalTax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtTotalChilds
            // 
            resources.ApplyResources(this.txtTotalChilds, "txtTotalChilds");
            this.txtTotalChilds.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalChilds.ForeColor = System.Drawing.Color.Black;
            this.txtTotalChilds.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtTotalChilds, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTotalChilds.IconAlignment"))));
            this.txtTotalChilds.Name = "txtTotalChilds";
            this.txtTotalChilds.RequiredField = false;
            this.txtTotalChilds.UseCompatibleTextRendering = true;
            this.txtTotalChilds.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtAdvance
            // 
            resources.ApplyResources(this.txtAdvance, "txtAdvance");
            this.txtAdvance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdvance.ForeColor = System.Drawing.Color.Black;
            this.txtAdvance.Format = "N2";
            this.txtAdvance.Name = "txtAdvance";
            this.txtAdvance.RequiredField = false;
            this.txtAdvance.UseCompatibleTextRendering = true;
            this.txtAdvance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAdvance
            // 
            resources.ApplyResources(this.lblAdvance, "lblAdvance");
            this.errProvider.SetIconAlignment(this.lblAdvance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdvance.IconAlignment"))));
            this.lblAdvance.Name = "lblAdvance";
            this.lblAdvance.RequiredField = false;
            // 
            // btnPayment
            // 
            resources.ApplyResources(this.btnPayment, "btnPayment");
            this.btnPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnPayment.FlatAppearance.BorderSize = 0;
            this.btnPayment.ForeColor = System.Drawing.Color.White;
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.TabStop = false;
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // txtBalance
            // 
            resources.ApplyResources(this.txtBalance, "txtBalance");
            this.txtBalance.BackColor = System.Drawing.SystemColors.Window;
            this.txtBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBalance.Format = null;
            this.txtBalance.isAllowNegative = true;
            this.txtBalance.isAllowSpecialChar = false;
            this.txtBalance.isNumeric = true;
            this.txtBalance.isTouchable = false;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            // 
            // txtPayment
            // 
            resources.ApplyResources(this.txtPayment, "txtPayment");
            this.txtPayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Format = "N2";
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.RequiredField = false;
            this.txtPayment.UseCompatibleTextRendering = true;
            this.txtPayment.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBalance
            // 
            resources.ApplyResources(this.lblBalance, "lblBalance");
            this.errProvider.SetIconAlignment(this.lblBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblBalance.IconAlignment"))));
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.RequiredField = false;
            // 
            // lblAdult
            // 
            resources.ApplyResources(this.lblAdult, "lblAdult");
            this.errProvider.SetIconAlignment(this.lblAdult, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdult.IconAlignment"))));
            this.lblAdult.Name = "lblAdult";
            this.lblAdult.RequiredField = false;
            // 
            // lblChild
            // 
            resources.ApplyResources(this.lblChild, "lblChild");
            this.errProvider.SetIconAlignment(this.lblChild, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblChild.IconAlignment"))));
            this.lblChild.Name = "lblChild";
            this.lblChild.RequiredField = false;
            // 
            // cmbEmployee
            // 
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // lblNoOfRooms
            // 
            resources.ApplyResources(this.lblNoOfRooms, "lblNoOfRooms");
            this.lblNoOfRooms.Name = "lblNoOfRooms";
            this.lblNoOfRooms.RequiredField = false;
            // 
            // lblNoOfHalls
            // 
            resources.ApplyResources(this.lblNoOfHalls, "lblNoOfHalls");
            this.lblNoOfHalls.Name = "lblNoOfHalls";
            this.lblNoOfHalls.RequiredField = false;
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // lblGrandTotal
            // 
            resources.ApplyResources(this.lblGrandTotal, "lblGrandTotal");
            this.lblGrandTotal.BackColor = System.Drawing.SystemColors.Window;
            this.lblGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGrandTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.lblGrandTotal.Format = "N2";
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.RequiredField = false;
            this.lblGrandTotal.UseCompatibleTextRendering = true;
            this.lblGrandTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atlblTot
            // 
            resources.ApplyResources(this.atlblTot, "atlblTot");
            this.atlblTot.BackColor = System.Drawing.Color.Transparent;
            this.atlblTot.Name = "atlblTot";
            this.atlblTot.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.btnAllocate);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.txtExRate);
            this.pnlMain.Controls.Add(this.lblExRateCap);
            this.pnlMain.Controls.Add(this.lblCurrencyCap);
            this.pnlMain.Controls.Add(this.txtDeductionPerc);
            this.pnlMain.Controls.Add(this.lblDeuctionPerc);
            this.pnlMain.Controls.Add(this.cmbCurrency);
            this.pnlMain.Controls.Add(this.lblDeduction);
            this.pnlMain.Controls.Add(this.btnGrpCheckOut);
            this.pnlMain.Controls.Add(this.btnNewGuestType);
            this.pnlMain.Controls.Add(this.btnNewGuest);
            this.pnlMain.Controls.Add(this.btnNewSource);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.cmbAgent);
            this.pnlMain.Controls.Add(this.txtNoOfHalls);
            this.pnlMain.Controls.Add(this.txtNoOfRooms);
            this.pnlMain.Controls.Add(this.cmbGuest);
            this.pnlMain.Controls.Add(this.lblAgent);
            this.pnlMain.Controls.Add(this.lblBooking);
            this.pnlMain.Controls.Add(this.txtNoOfDays);
            this.pnlMain.Controls.Add(this.lblNoOfDays);
            this.pnlMain.Controls.Add(this.lblBillingAccountID);
            this.pnlMain.Controls.Add(this.cmbSource);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.lblGuestType);
            this.pnlMain.Controls.Add(this.lblSource);
            this.pnlMain.Controls.Add(this.cmbEmployee);
            this.pnlMain.Controls.Add(this.lblEmployee);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.cmbBillingAccount);
            this.pnlMain.Controls.Add(this.dtpDepartureDate);
            this.pnlMain.Controls.Add(this.cmbGuestType);
            this.pnlMain.Controls.Add(this.lblTelephone);
            this.pnlMain.Controls.Add(this.lblDepartureDate);
            this.pnlMain.Controls.Add(this.txtGuestVehicleName);
            this.pnlMain.Controls.Add(this.lblNoOfHalls);
            this.pnlMain.Controls.Add(this.lblAddress1);
            this.pnlMain.Controls.Add(this.txtGuestVehicleNo);
            this.pnlMain.Controls.Add(this.lblGuestVehicleName);
            this.pnlMain.Controls.Add(this.lblGuestVehicleNo);
            this.pnlMain.Controls.Add(this.cmbGuestVehicleType);
            this.pnlMain.Controls.Add(this.txtMobile);
            this.pnlMain.Controls.Add(this.cmbGrpBooking);
            this.pnlMain.Controls.Add(this.dtpArrivalDate);
            this.pnlMain.Controls.Add(this.lblArrivalDate);
            this.pnlMain.Controls.Add(this.txtTelephone);
            this.pnlMain.Controls.Add(this.txtAdd1);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblNoOfRooms);
            this.pnlMain.Controls.Add(this.lblMandatory6);
            this.pnlMain.Controls.Add(this.lblMandatory7);
            this.pnlMain.Controls.Add(this.txtDeductionAmount);
            this.pnlMain.Name = "pnlMain";
            // 
            // btnAllocate
            // 
            resources.ApplyResources(this.btnAllocate, "btnAllocate");
            this.btnAllocate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnAllocate.FlatAppearance.BorderSize = 0;
            this.btnAllocate.ForeColor = System.Drawing.Color.White;
            this.btnAllocate.Name = "btnAllocate";
            this.btnAllocate.TabStop = false;
            this.btnAllocate.Tag = "";
            this.btnAllocate.UseVisualStyleBackColor = false;
            this.btnAllocate.Click += new System.EventHandler(this.btnAllocate_Click);
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // txtExRate
            // 
            resources.ApplyResources(this.txtExRate, "txtExRate");
            this.txtExRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtExRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtExRate.Format = null;
            this.txtExRate.isAllowNegative = false;
            this.txtExRate.isAllowSpecialChar = false;
            this.txtExRate.isNumbersOnly = false;
            this.txtExRate.isNumeric = true;
            this.txtExRate.isTouchable = false;
            this.txtExRate.Name = "txtExRate";
            this.txtExRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtExRate.Enter += new System.EventHandler(this.txtExRate_Enter);
            this.txtExRate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtExRate_KeyUp);
            // 
            // lblExRateCap
            // 
            resources.ApplyResources(this.lblExRateCap, "lblExRateCap");
            this.lblExRateCap.Name = "lblExRateCap";
            this.lblExRateCap.RequiredField = false;
            // 
            // lblCurrencyCap
            // 
            resources.ApplyResources(this.lblCurrencyCap, "lblCurrencyCap");
            this.lblCurrencyCap.Name = "lblCurrencyCap";
            this.lblCurrencyCap.RequiredField = false;
            // 
            // txtDeductionPerc
            // 
            resources.ApplyResources(this.txtDeductionPerc, "txtDeductionPerc");
            this.txtDeductionPerc.BackColor = System.Drawing.SystemColors.Window;
            this.txtDeductionPerc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDeductionPerc.Format = null;
            this.txtDeductionPerc.isAllowNegative = false;
            this.txtDeductionPerc.isAllowSpecialChar = false;
            this.txtDeductionPerc.isNumbersOnly = false;
            this.txtDeductionPerc.isNumeric = true;
            this.txtDeductionPerc.isTouchable = true;
            this.txtDeductionPerc.Name = "txtDeductionPerc";
            this.txtDeductionPerc.ReadOnly = true;
            this.txtDeductionPerc.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblDeuctionPerc
            // 
            resources.ApplyResources(this.lblDeuctionPerc, "lblDeuctionPerc");
            this.lblDeuctionPerc.Name = "lblDeuctionPerc";
            this.lblDeuctionPerc.RequiredField = false;
            // 
            // cmbCurrency
            // 
            resources.ApplyResources(this.cmbCurrency, "cmbCurrency");
            this.cmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCurrency.DropDownHeight = 300;
            this.cmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCurrency.FormattingEnabled = true;
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency_SelectedIndexChanged);
            // 
            // lblDeduction
            // 
            resources.ApplyResources(this.lblDeduction, "lblDeduction");
            this.lblDeduction.Name = "lblDeduction";
            this.lblDeduction.RequiredField = false;
            // 
            // btnGrpCheckOut
            // 
            resources.ApplyResources(this.btnGrpCheckOut, "btnGrpCheckOut");
            this.btnGrpCheckOut.FlatAppearance.BorderSize = 0;
            this.btnGrpCheckOut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            this.btnGrpCheckOut.Name = "btnGrpCheckOut";
            this.btnGrpCheckOut.UseVisualStyleBackColor = true;
            this.btnGrpCheckOut.Click += new System.EventHandler(this.btnGrpCheckOut_Click);
            // 
            // btnNewGuestType
            // 
            this.btnNewGuestType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewGuestType.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewGuestType, "btnNewGuestType");
            this.btnNewGuestType.ForeColor = System.Drawing.Color.White;
            this.btnNewGuestType.Name = "btnNewGuestType";
            this.btnNewGuestType.TabStop = false;
            this.btnNewGuestType.Tag = "";
            this.btnNewGuestType.UseVisualStyleBackColor = false;
            this.btnNewGuestType.Click += new System.EventHandler(this.btnNewGuestType_Click);
            // 
            // btnNewGuest
            // 
            this.btnNewGuest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewGuest.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewGuest, "btnNewGuest");
            this.btnNewGuest.ForeColor = System.Drawing.Color.White;
            this.btnNewGuest.Name = "btnNewGuest";
            this.btnNewGuest.TabStop = false;
            this.btnNewGuest.Tag = "";
            this.btnNewGuest.UseVisualStyleBackColor = false;
            this.btnNewGuest.Click += new System.EventHandler(this.btnNewGuest_Click);
            // 
            // btnNewSource
            // 
            this.btnNewSource.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewSource.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewSource, "btnNewSource");
            this.btnNewSource.ForeColor = System.Drawing.Color.White;
            this.btnNewSource.Name = "btnNewSource";
            this.btnNewSource.TabStop = false;
            this.btnNewSource.Tag = "";
            this.btnNewSource.UseVisualStyleBackColor = false;
            this.btnNewSource.Click += new System.EventHandler(this.btnNewSource_Click);
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // txtNoOfHalls
            // 
            resources.ApplyResources(this.txtNoOfHalls, "txtNoOfHalls");
            this.txtNoOfHalls.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfHalls.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfHalls.Format = null;
            this.txtNoOfHalls.isAllowNegative = false;
            this.txtNoOfHalls.isAllowSpecialChar = false;
            this.txtNoOfHalls.isNumbersOnly = true;
            this.txtNoOfHalls.isNumeric = false;
            this.txtNoOfHalls.isTouchable = true;
            this.txtNoOfHalls.Name = "txtNoOfHalls";
            this.txtNoOfHalls.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtNoOfRooms
            // 
            resources.ApplyResources(this.txtNoOfRooms, "txtNoOfRooms");
            this.txtNoOfRooms.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfRooms.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfRooms.Format = null;
            this.txtNoOfRooms.isAllowNegative = false;
            this.txtNoOfRooms.isAllowSpecialChar = false;
            this.txtNoOfRooms.isNumbersOnly = true;
            this.txtNoOfRooms.isNumeric = false;
            this.txtNoOfRooms.isTouchable = true;
            this.txtNoOfRooms.Name = "txtNoOfRooms";
            this.txtNoOfRooms.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory6
            // 
            resources.ApplyResources(this.lblMandatory6, "lblMandatory6");
            this.lblMandatory6.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory6.Name = "lblMandatory6";
            // 
            // lblMandatory7
            // 
            resources.ApplyResources(this.lblMandatory7, "lblMandatory7");
            this.lblMandatory7.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory7.Name = "lblMandatory7";
            // 
            // txtDeductionAmount
            // 
            resources.ApplyResources(this.txtDeductionAmount, "txtDeductionAmount");
            this.txtDeductionAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtDeductionAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDeductionAmount.Format = null;
            this.txtDeductionAmount.isAllowNegative = false;
            this.txtDeductionAmount.isAllowSpecialChar = false;
            this.txtDeductionAmount.isNumbersOnly = false;
            this.txtDeductionAmount.isNumeric = true;
            this.txtDeductionAmount.isTouchable = true;
            this.txtDeductionAmount.Name = "txtDeductionAmount";
            this.txtDeductionAmount.ReadOnly = true;
            this.txtDeductionAmount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // pnlGridContain
            // 
            resources.ApplyResources(this.pnlGridContain, "pnlGridContain");
            this.pnlGridContain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlGridContain.Controls.Add(this.dgDetails);
            this.pnlGridContain.Name = "pnlGridContain";
            // 
            // dgDetails
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_slno,
            this.col_RoomOrHall,
            this.col_RoomType,
            this.col_Room,
            this.Col_RateType,
            this.Col_Adult,
            this.Col_Child,
            this.col_Rate,
            this.col_AdditionalBeds,
            this.col_AdditionalBedRate,
            this.col_AdditionalPersons,
            this.col_AdditionalPersonRate,
            this.col_DeductionPerc,
            this.col_DeductionAmount});
            this.dgDetails.EnableHeadersVisualStyles = false;
            this.dgDetails.EnterKeyNavigation = false;
            this.dgDetails.LastKey = System.Windows.Forms.Keys.None;
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle13.NullValue = null;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dgDetails.sGridID = null;
            this.dgDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgDetails_CellBeginEdit);
            this.dgDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEndEdit);
            this.dgDetails.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgDetails_CellValidating);
            this.dgDetails.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgDetails_DataError);
            this.dgDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgDetails_EditingControlShowing);
            this.dgDetails.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgDetails_RowsAdded);
            this.dgDetails.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgDetails_RowsRemoved);
            // 
            // col_slno
            // 
            this.col_slno.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_slno.FillWeight = 111.905F;
            resources.ApplyResources(this.col_slno, "col_slno");
            this.col_slno.Name = "col_slno";
            this.col_slno.ReadOnly = true;
            // 
            // col_RoomOrHall
            // 
            this.col_RoomOrHall.DataPropertyName = "RoomOrHall";
            this.col_RoomOrHall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_RoomOrHall, "col_RoomOrHall");
            this.col_RoomOrHall.Items.AddRange(new object[] {
            "Room",
            "Hall"});
            this.col_RoomOrHall.Name = "col_RoomOrHall";
            this.col_RoomOrHall.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_RoomOrHall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // col_RoomType
            // 
            this.col_RoomType.DataPropertyName = "FK_RoomTypeID";
            this.col_RoomType.FillWeight = 120F;
            this.col_RoomType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_RoomType, "col_RoomType");
            this.col_RoomType.Name = "col_RoomType";
            this.col_RoomType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // col_Room
            // 
            this.col_Room.DataPropertyName = "FK_RoomID";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.col_Room.DefaultCellStyle = dataGridViewCellStyle3;
            this.col_Room.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_Room, "col_Room");
            this.col_Room.Name = "col_Room";
            this.col_Room.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Room.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Col_RateType
            // 
            this.Col_RateType.DataPropertyName = "FK_RateTypeID";
            this.Col_RateType.FillWeight = 115F;
            this.Col_RateType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.Col_RateType, "Col_RateType");
            this.Col_RateType.Name = "Col_RateType";
            this.Col_RateType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Col_RateType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Col_Adult
            // 
            this.Col_Adult.DataPropertyName = "Adult";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Col_Adult.DefaultCellStyle = dataGridViewCellStyle4;
            resources.ApplyResources(this.Col_Adult, "Col_Adult");
            this.Col_Adult.Name = "Col_Adult";
            // 
            // Col_Child
            // 
            this.Col_Child.DataPropertyName = "Child";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Col_Child.DefaultCellStyle = dataGridViewCellStyle5;
            resources.ApplyResources(this.Col_Child, "Col_Child");
            this.Col_Child.Name = "Col_Child";
            // 
            // col_Rate
            // 
            this.col_Rate.DataPropertyName = "Rate";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Rate.DefaultCellStyle = dataGridViewCellStyle6;
            this.col_Rate.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Rate, "col_Rate");
            this.col_Rate.Name = "col_Rate";
            // 
            // col_AdditionalBeds
            // 
            this.col_AdditionalBeds.DataPropertyName = "AdditionalBeds";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_AdditionalBeds.DefaultCellStyle = dataGridViewCellStyle7;
            resources.ApplyResources(this.col_AdditionalBeds, "col_AdditionalBeds");
            this.col_AdditionalBeds.Name = "col_AdditionalBeds";
            // 
            // col_AdditionalBedRate
            // 
            this.col_AdditionalBedRate.DataPropertyName = "AdditionalBedRate";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AdditionalBedRate.DefaultCellStyle = dataGridViewCellStyle8;
            resources.ApplyResources(this.col_AdditionalBedRate, "col_AdditionalBedRate");
            this.col_AdditionalBedRate.Name = "col_AdditionalBedRate";
            // 
            // col_AdditionalPersons
            // 
            this.col_AdditionalPersons.DataPropertyName = "AdditionalPersons";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_AdditionalPersons.DefaultCellStyle = dataGridViewCellStyle9;
            resources.ApplyResources(this.col_AdditionalPersons, "col_AdditionalPersons");
            this.col_AdditionalPersons.Name = "col_AdditionalPersons";
            // 
            // col_AdditionalPersonRate
            // 
            this.col_AdditionalPersonRate.DataPropertyName = "AdditionalPersonRate";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AdditionalPersonRate.DefaultCellStyle = dataGridViewCellStyle10;
            resources.ApplyResources(this.col_AdditionalPersonRate, "col_AdditionalPersonRate");
            this.col_AdditionalPersonRate.Name = "col_AdditionalPersonRate";
            // 
            // col_DeductionPerc
            // 
            this.col_DeductionPerc.DataPropertyName = "DeductionPerc";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionPerc.DefaultCellStyle = dataGridViewCellStyle11;
            resources.ApplyResources(this.col_DeductionPerc, "col_DeductionPerc");
            this.col_DeductionPerc.Name = "col_DeductionPerc";
            // 
            // col_DeductionAmount
            // 
            this.col_DeductionAmount.DataPropertyName = "DeductionAmount";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionAmount.DefaultCellStyle = dataGridViewCellStyle12;
            resources.ApplyResources(this.col_DeductionAmount, "col_DeductionAmount");
            this.col_DeductionAmount.Name = "col_DeductionAmount";
            // 
            // pnlFooter
            // 
            resources.ApplyResources(this.pnlFooter, "pnlFooter");
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.lblExternal);
            this.pnlFooter.Controls.Add(this.txtExternalAmt);
            this.pnlFooter.Controls.Add(this.lblAddlBedAndPerson);
            this.pnlFooter.Controls.Add(this.txtExtraBedAndPer);
            this.pnlFooter.Controls.Add(this.grpDiscountVoucher);
            this.pnlFooter.Controls.Add(this.lblOpBalance);
            this.pnlFooter.Controls.Add(this.button1);
            this.pnlFooter.Controls.Add(this.txtRoomRent);
            this.pnlFooter.Controls.Add(this.txtOpBalance);
            this.pnlFooter.Controls.Add(this.txtTotalAdults);
            this.pnlFooter.Controls.Add(this.lblRoomAmount);
            this.pnlFooter.Controls.Add(this.lblTotal);
            this.pnlFooter.Controls.Add(this.btnExtraServ);
            this.pnlFooter.Controls.Add(this.lblPayment);
            this.pnlFooter.Controls.Add(this.txtGross);
            this.pnlFooter.Controls.Add(this.txtBalance);
            this.pnlFooter.Controls.Add(this.txtPayment);
            this.pnlFooter.Controls.Add(this.txtExtraServicesAmnt);
            this.pnlFooter.Controls.Add(this.lblAdvance);
            this.pnlFooter.Controls.Add(this.txtAdvance);
            this.pnlFooter.Controls.Add(this.txtNetTotal);
            this.pnlFooter.Controls.Add(this.lblNetTotal);
            this.pnlFooter.Controls.Add(this.txtTotalChilds);
            this.pnlFooter.Controls.Add(this.lblBalance);
            this.pnlFooter.Controls.Add(this.lblTotalDisc);
            this.pnlFooter.Controls.Add(this.lblChild);
            this.pnlFooter.Controls.Add(this.lblAdult);
            this.pnlFooter.Controls.Add(this.txtTotalTax);
            this.pnlFooter.Controls.Add(this.txtTotalDiscount);
            this.pnlFooter.Controls.Add(this.lblTotalTax);
            this.pnlFooter.Name = "pnlFooter";
            // 
            // lblExternal
            // 
            resources.ApplyResources(this.lblExternal, "lblExternal");
            this.lblExternal.DataSource = null;
            this.lblExternal.Format = null;
            this.errProvider.SetIconAlignment(this.lblExternal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExternal.IconAlignment"))));
            this.lblExternal.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblExternal.Name = "lblExternal";
            this.lblExternal.TabStop = true;
            // 
            // txtExternalAmt
            // 
            resources.ApplyResources(this.txtExternalAmt, "txtExternalAmt");
            this.txtExternalAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExternalAmt.ForeColor = System.Drawing.Color.Black;
            this.txtExternalAmt.Format = "N2";
            this.txtExternalAmt.Name = "txtExternalAmt";
            this.txtExternalAmt.RequiredField = false;
            this.txtExternalAmt.UseCompatibleTextRendering = true;
            this.txtExternalAmt.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddlBedAndPerson
            // 
            resources.ApplyResources(this.lblAddlBedAndPerson, "lblAddlBedAndPerson");
            this.errProvider.SetIconAlignment(this.lblAddlBedAndPerson, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddlBedAndPerson.IconAlignment"))));
            this.lblAddlBedAndPerson.Name = "lblAddlBedAndPerson";
            this.lblAddlBedAndPerson.RequiredField = false;
            // 
            // txtExtraBedAndPer
            // 
            resources.ApplyResources(this.txtExtraBedAndPer, "txtExtraBedAndPer");
            this.txtExtraBedAndPer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExtraBedAndPer.ForeColor = System.Drawing.Color.Black;
            this.txtExtraBedAndPer.Format = "N2";
            this.txtExtraBedAndPer.Name = "txtExtraBedAndPer";
            this.txtExtraBedAndPer.RequiredField = false;
            this.txtExtraBedAndPer.UseCompatibleTextRendering = true;
            this.txtExtraBedAndPer.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // grpDiscountVoucher
            // 
            resources.ApplyResources(this.grpDiscountVoucher, "grpDiscountVoucher");
            this.grpDiscountVoucher.BackColor = System.Drawing.Color.Transparent;
            this.grpDiscountVoucher.Controls.Add(this.lblVoucherDiscount);
            this.grpDiscountVoucher.Controls.Add(this.txtVoucherDiscountAmount);
            this.grpDiscountVoucher.Controls.Add(this.lblVoucherDiscountAmount);
            this.grpDiscountVoucher.Controls.Add(this.cmbVoucherDiscount);
            this.grpDiscountVoucher.Name = "grpDiscountVoucher";
            this.grpDiscountVoucher.TabStop = false;
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lblPayment
            // 
            resources.ApplyResources(this.lblPayment, "lblPayment");
            this.errProvider.SetIconAlignment(this.lblPayment, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblPayment.IconAlignment"))));
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.RequiredField = false;
            // 
            // GroupCheckInView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.pnlGridContain);
            this.Name = "GroupCheckInView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.GrpCheckInView_atSaveClick);
            this.atBeforeInitialise += new atACCFramework.BaseClasses.BeforeInitialiseEventHandler(this.GroupCheckInView_atBeforeInitialise);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.GrpCheckInView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.GrpCheckInView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.GrpCheckInView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.GrpCheckInView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.GrpCheckInView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.GrpCheckInView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.GrpCheckInView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.GrpCheckInView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.GrpCheckInView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.GroupCheckInView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.GrpCheckInView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.GrpCheckInView_atBeforeSearch);
            this.Shown += new System.EventHandler(this.GroupCheckInView_Shown);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlGridContain, 0);
            this.Controls.SetChildIndex(this.pnlFooter, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindCheckInDTL)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlGridContain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.pnlFooter.ResumeLayout(false);
            this.pnlFooter.PerformLayout();
            this.grpDiscountVoucher.ResumeLayout(false);
            this.grpDiscountVoucher.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atLabel lblBooking;
        private atACCFramework.UserControls.ComboBoxExt cmbGrpBooking;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private atACCFramework.UserControls.ComboBoxExt cmbAgent;
        private atACCFramework.UserControls.ComboBoxExt cmbSource;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.TextBoxExt txtNoOfDays;
        private atACCFramework.UserControls.atLabel lblNoOfDays;
        private atACCFramework.UserControls.atLabel lblAgent;
        private atACCFramework.UserControls.atLabel lblSource;
        private atACCFramework.UserControls.ComboBoxExt cmbGuest;
        private atACCFramework.UserControls.ComboBoxExt cmbGuestVehicleType;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtGuestVehicleName;
        private atACCFramework.UserControls.atLabel lblGuestVehicleName;
        private atACCFramework.UserControls.ComboBoxExt cmbBillingAccount;
        private atACCFramework.UserControls.atLabel lblBillingAccountID;
        private atACCFramework.UserControls.ComboBoxExt cmbGuestType;
        private atACCFramework.UserControls.TextBoxExt txtGuestVehicleNo;
        private atACCFramework.UserControls.atLabel lblGuestType;
        private atACCFramework.UserControls.atLabel lblGuestVehicleNo;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atNumericLabel txtTotalChilds;
        private atACCFramework.UserControls.atNumericLabel txtAdvance;
        private atACCFramework.UserControls.atLabel lblAdvance;
        private atACCFramework.UserControls.atNumericLabel txtOpBalance;
        private AccountLabel lblOpBalance;
        private atACCFramework.UserControls.atButton btnPayment;
        private atACCFramework.UserControls.TextBoxNormal txtBalance;
        private atACCFramework.UserControls.atNumericLabel txtPayment;
        private atACCFramework.UserControls.atLabel lblBalance;
        private atACCFramework.UserControls.atLabel lblAdult;
        private atACCFramework.UserControls.atLabel lblChild;
        private atACCFramework.UserControls.atLabel lblNoOfRooms;
        private atACCFramework.UserControls.atLabel lblNoOfHalls;
        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atNumericLabel lblGrandTotal;
        private atACCFramework.UserControls.atLabel atlblTot;
        private atACCFramework.UserControls.ComboBoxExt cmbVoucherDiscount;
        private atACCFramework.UserControls.TextBoxExt txtVoucherDiscountAmount;
        private atACCFramework.UserControls.atLabel lblVoucherDiscount;
        private atACCFramework.UserControls.atLabel lblVoucherDiscountAmount;
        private System.Windows.Forms.BindingSource bindCheckInDTL;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atNumericLabel txtTotalDiscount;
        private atACCFramework.UserControls.atLabel lblTotalDisc;
        private atACCFramework.UserControls.TaxLabel lblTotalTax;
        private atACCFramework.UserControls.atNumericLabel txtTotalTax;
        private atACCFramework.UserControls.atNumericLabel txtExtraServicesAmnt;
        private atACCFramework.UserControls.atNumericLabel txtNetTotal;
        private atACCFramework.UserControls.atLabel lblNetTotal;
        private atACCFramework.UserControls.atNumericLabel txtRoomRent;
        private atACCFramework.UserControls.atNumericLabel txtTotalAdults;
        private atACCFramework.UserControls.atLabel lblRoomAmount;
        private atACCFramework.UserControls.TextBoxExt txtNoOfHalls;
        private atACCFramework.UserControls.TextBoxExt txtNoOfRooms;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.atNumericLabel txtGross;
        private atACCFramework.UserControls.atLabel lblTotal;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory4;
        private atACCFramework.UserControls.atButton btnNewSource;
        private atACCFramework.UserControls.atButton btnNewGuest;
        private atACCFramework.UserControls.atButton btnNewGuestType;
        private atACCFramework.UserControls.atButton btnExtraServ;
        private atACCFramework.UserControls.atPanel pnlGridContain;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private atACCFramework.UserControls.atLabel lblPayment;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnGrpCheckOut;
        private atACCFramework.UserControls.TextBoxExt txtDeductionAmount;
        private atACCFramework.UserControls.TextBoxExt txtDeductionPerc;
        private atACCFramework.UserControls.atLabel lblDeuctionPerc;
        private atACCFramework.UserControls.atLabel lblDeduction;
        private atACCFramework.UserControls.atGroupBox grpDiscountVoucher;
        private atACCFramework.UserControls.atLabel lblCurrencyCap;
        private atACCFramework.UserControls.TextBoxExt txtExRate;
        private atACCFramework.UserControls.ComboBoxExt cmbCurrency;
        private atACCFramework.UserControls.atLabel lblExRateCap;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory6;
        private atACCFramework.UserControls.atGridView dgDetails;
        private System.Windows.Forms.Label lblMandatory7;
        private atACCFramework.UserControls.atButton btnAllocate;
        private AccountLabel lblExternal;
        private atACCFramework.UserControls.atNumericLabel txtExternalAmt;
        private atACCFramework.UserControls.atLabel lblAddlBedAndPerson;
        private atACCFramework.UserControls.atNumericLabel txtExtraBedAndPer;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_slno;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_RoomOrHall;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_RoomType;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_Room;
        private System.Windows.Forms.DataGridViewComboBoxColumn Col_RateType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Adult;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Child;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalBeds;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalBedRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalPersons;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalPersonRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionAmount;
    }
}