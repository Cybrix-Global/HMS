﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.BaseForms;
using atACC.Common;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.ORM;
using atACC.HTL.Masters;
using System.Data.SqlClient;
using System.IO;
using System.Net.Mail;
using atACC.HTL.Transactions.Sub_Forms;
using atACCFramework;

namespace atACC.HTL.Transactions
{
    public partial class GroupBookingView : SearchFormBase2
    {
        #region Private Variables
        string NumberFormat, sQtyFormat;
        CommonLibClasses objLib;
        atACCHotelEntities dbh;
        bool _OnLoad;
        atACC.HTL.ORM.AccountLedger Ledger;
        GroupBooking entGroupBooking;
        GuestDTLs e_GuestDTLs;
        Guests entGuest;
        RoomTypes e_RoomTypes;
        RoomTariffs e_RoomTariffs;
        List<GroupBooking> entGroupBookingList;
        List<GroupBookingDTL> entGroupBookingDTLs;
        List<GroupBookingDTL> entOldGroupBookingDTLs;
        List<GroupBookingPayment> entGroupBookingPaymentList;
        List<GroupBookingPayment> entOldGroupBookingPaymenteList;
        List<CurrencyClass> entCurrencys;
        List<Rooms> entRooms;
        List<Employee> entEmployees;
        List<Agent> entAgents;
        List<Guests> entGuestlist;
        List<RoomTypes> entRoomTypes;
        DataGridViewComboBoxEditingControl cb;
        DataGridViewTextBoxEditingControl textbox;
        int AdultCount = 0, ExtraAdultCount = 0, iSettingsId, iRateTypeId, iDefaultId, iSlabTypeId, iRoomTypeId, AdultOccupancy;
        int AgentLedgerID;
        decimal AdditionalPersonAmount = 0, RoomRate = 0, GuestDeduction = 0, AdvanceAmount, TotalAmount;
        ToolTip tooltip;
        int iDefaultCash, iDefaultDepo;
        string sKeyChar = "";
        ANIHelper aniHelper;
        DataTable dt = new DataTable();
        int _GroupBookingId;
        GetAccounts getAccc;
        VoucherHDR entVoucherHdrPayment;
        bool blnPartyUnderCashInHand = false;
        bool blnSanctioningRequired = false;
        decimal previousExRate;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;
        #endregion

        #region Constructor
        public GroupBookingView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            aniHelper = new ANIHelper();
            getAccc = new GetAccounts();
            ShareButton.Visible = false;
            _OnLoad = false;

            ToolStripMenuItem mnuSendEmail = new ToolStripMenuItem();
            mnuSendEmail.BackColor = Color.White;
            mnuSendEmail.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendEmail.Text = MessageKeys.MsgSendEmail;
            mnuSendEmail.Image = Properties.Resources.Mail;
            mnuSendEmail.Click += new EventHandler(mnuSendEmail_Click);
            ShareMenu.Items.Add(mnuSendEmail);

            ToolStripMenuItem mnuSendSMS = new ToolStripMenuItem();
            mnuSendSMS.BackColor = Color.White;
            mnuSendSMS.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendSMS.Text = MessageKeys.MsgSendSMS;
            mnuSendSMS.Image = Properties.Resources.SMS;
            mnuSendSMS.Click += new EventHandler(mnuSendSMS_Click);
            ShareMenu.Items.Add(mnuSendSMS);
        }
        public GroupBookingView(int id) : this()
        {
            _GroupBookingId = id;
        }
        #endregion

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(2);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Share Methods
        void mnuSendEmail_Click(object sender, EventArgs e)
        {
            SendEmail();
        }
        void mnuSendSMS_Click(object sender, EventArgs e)
        {
            SendSMS();
        }
        private void SendEmail()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (cmbGuest.SelectedValue == null)
                {
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                    this.Cursor = Cursors.Arrow;
                    return;
                }
                if (entGroupBooking != null && entGroupBooking.id != null && entGroupBooking.id != 0) 
                {
                    string sTo = "";
                    int iGuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                    GuestDTLs _GuDtl = dbh.GuestDTLs.Where(x => x.FK_GuestID == iGuestID).SingleOrDefault();
                    if (_GuDtl != null)
                    {
                        sTo = _GuDtl.Email;
                    }
                    if (sTo.Trim() == "")
                    {
                        atMessageBox.Show(MessageKeys.MsgEmailAddressOfGuestMustBeSet);
                        this.Cursor = Cursors.Arrow;
                        return;
                    }
                    string sExportPath = Application.StartupPath + "\\Temp\\Sales_" + txtVoucherNo.Text + ".pdf";
                    string sBody = "";
                    MailHelper _mailHelper = new MailHelper();
                    _mailHelper.sTo = sTo;
                    MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "Email").SingleOrDefault();
                    sBody = _Message.Booking;
                    sBody = sBody.Replace("@VoucherNo", txtVoucherNo.Text)
                    .Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString())
                    .Replace("@GuestName@", cmbGuest.Text)
                    .Replace("@RoomType@", "")
                    .Replace("@Room@", "")
                    .Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString())
                    .Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString())
                    .Replace("@NoofDays@", txtNoOfDays.Text)
                    .Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat))
                    .Replace("@Payment@", "")
                    .Replace("@Refund@", "") 
                    .Replace("@GrandTotal", txtGrandTotal.Value.ToString(NumberFormat));

                    _mailHelper.sSubject = MessageKeys.MsgGroupBookingVoucherNo + " : " + txtVoucherNo.Text;
                    _mailHelper.sBody = sBody;
                    if (GlobalFunctions.blnConfirmationForEmail)
                    {
                        EmailConfirmationView emailConfirm = new EmailConfirmationView(_mailHelper.sSubject, _mailHelper.sBody);
                        if (emailConfirm.ShowDialog() == DialogResult.OK)
                        {
                            _mailHelper.sSubject = emailConfirm.sSubject;
                            _mailHelper.sBody = emailConfirm.sBody;
                        }
                        this.Cursor = Cursors.WaitCursor;
                    }
                    if (entGroupBooking.id != 0)
                    {
                        if (File.Exists(sExportPath))
                        {
                            File.Delete(sExportPath);
                        }
                        PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                        printInvoice.PrintOut("Hotel Group Booking", entGroupBooking.id, 0, true, sExportPath);
                        if (File.Exists(sExportPath))
                        {
                            _mailHelper.entAttachments.Add(new Attachment(sExportPath));
                        }
                    }
                    _mailHelper.SendEmail();
                    if (File.Exists(sExportPath))
                    {
                        File.Delete(sExportPath);
                    }
                    atMessageBox.Show(MessageKeys.MsgMailSendSuccessfully);
                }
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
                this.Cursor = Cursors.Arrow;
            }
        }
        private bool SendSMS()
        {
            if (cmbGuest.SelectedValue == null)
            {
                errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                return false;
            }
            if (entGroupBooking == null || entGroupBooking.id == null || entGroupBooking.id != 0)
            {
                atMessageBox.Show(MessageKeys.MsgRecordNotFound);
                return false;
            }
            int iGuestID = cmbGuest.SelectedValue.ToInt32();
            try
            {
                if (cmbGuest.Text.Trim() == "") { return false; }
                if (txtMobile.Text.Trim() == "") { return false; }
                MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "SMS").SingleOrDefault();
                string sMessage = _Message.Booking;
                sMessage = sMessage.Replace("@VoucherNo", txtVoucherNo.Text);
                sMessage = sMessage.Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@GuestName@", cmbGuest.Text);
                sMessage = sMessage.Replace("@RoomType@", "");
                sMessage = sMessage.Replace("@Room@", "");
                sMessage = sMessage.Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@NoofDays@", txtNoOfDays.Text);
                sMessage = sMessage.Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Payment@", "");
                sMessage = sMessage.Replace("@Refund@", "");
                sMessage = sMessage.Replace("@GrandTotal", txtGrandTotal.Value.ToString(NumberFormat));
                string sResult = SMSHelper.SendSMSBash(txtMobile.Text.Trim(), sMessage);
                MessageBox.Show("SMS : " + sResult);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion

        #region Public Method
        public override void LoadVouchers()
        {
            try
            {
                string sTempVno = txtVoucherNo.Text;
                dbh = atHotelContext.CreateContext();
                List<UpDownData> _Vouchers = dbh.GroupBookings.OrderByDescending(x => x.id)
                    .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                    .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
                txtVoucherNo.Items.Clear();
                txtVoucherNo.DataSource = _Vouchers;
                if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
                txtVoucherNo.Text = sTempVno;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            GroupBooking groupBooking = dbh.GroupBookings.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (groupBooking != null)
            {
                ReLoadData(groupBooking.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entGroupBooking = dbh.GroupBookings.Where(x => x.id == ID).SingleOrDefault();
                if (entGroupBooking != null)
                {
                    #region Group Bookings Data
                    #region Add Inactive Accounts
                    #region Employee
                    if (entGroupBooking.FK_EmployeeID != null)
                    {
                        if (entEmployees.Where(x => x.id == entGroupBooking.FK_EmployeeID).ToList().Count == 0)
                        {
                            Employee _Employee = new Employee();
                            _Employee = dbh.Employees.Where(x => x.id == entGroupBooking.FK_EmployeeID).SingleOrDefault();
                            entEmployees.Add(_Employee);
                            objLib.fnFillCombo(ref cmbEmployee, entEmployees, "Name", "id");
                        }
                    }
                    #endregion

                    #region Agent
                    if (entGroupBooking.FK_AgentID != null)
                    {
                        if (entAgents.Where(x => x.id == entGroupBooking.FK_AgentID).ToList().Count == 0)
                        {
                            Agent _Agent = new Agent();
                            _Agent = dbh.Agents.Where(x => x.id == entGroupBooking.FK_AgentID).SingleOrDefault();
                            entAgents.Add(_Agent);
                            objLib.fnFillCombo(ref cmbAgent, entAgents, "Name", "id");
                        }
                    }
                    #endregion
                    #endregion

                    txtVoucherNo.Text = entGroupBooking.VoucherNo;
                    dtVoucherDate.Value = entGroupBooking.VoucherDate.Value;
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = entGroupBooking.FK_GuestID;
                    cmbBillingAccount.SelectedValue = entGroupBooking.FK_BillingAccountID;
                    cmbCurrency.SelectedValue = entGroupBooking.FK_CurrencyHdrID;
                    txtExRate.Value = entGroupBooking.ExRate.ToDecimal();
                    if (entGroupBooking.Type != null)
                    {
                        cmbType.Text = entGroupBooking.Type;
                    }
                    else
                    {
                        cmbType.Text = MessageKeys.MsgNone;
                    }
                    if (entGroupBooking.GuestType != null)
                    {
                        cmbGuestType.Text = entGroupBooking.GuestType;
                    }
                    else
                    {
                        cmbGuestType.Text = MessageKeys.MsgNone;
                    }
                    if (entGroupBooking.Source != null)
                    {
                        cmbSource.Text = entGroupBooking.Source; ;
                    }
                    else
                    {
                        cmbSource.Text = MessageKeys.MsgNone;
                    }
                    dtpArrivalDate.Text = entGroupBooking.ArrivalDate.ToString();
                    dtpDepartureDate.Text = entGroupBooking.DepartureDate.ToString();
                    txtNoOfDays.Value = entGroupBooking.NoofDays.Value;
                    txtNoOfRooms.Value = entGroupBooking.NoofRooms.Value;
                    txtNoOfHalls.Value = entGroupBooking.NoofHalls.Value;
                    if (entGroupBooking.FK_AgentID != null)
                    {
                        cmbAgent.SelectedValue = entGroupBooking.FK_AgentID;
                    }
                    else
                    {
                        cmbAgent.SelectedValue = 0;
                    }
                    if (entGroupBooking.FK_EmployeeID != null)
                    {
                        cmbEmployee.SelectedValue = entGroupBooking.FK_EmployeeID;
                    }
                    else
                    {
                        cmbEmployee.SelectedValue = 0;
                    }
                    txtTotalTax.Value = entGroupBooking.TotalTaxAmount.Value;
                    txtTotalAmount.Value = entGroupBooking.GrandTotal.Value;
                    txtAdvance.Value = entGroupBooking.Advance.Value;
                    txtBalance.Value = entGroupBooking.Balance.Value;
                    txtRemarks.Text = entGroupBooking.Remarks;
                    #endregion

                    #region Group Booking Details
                    var CurrentDtl = (from pdtl in dbh.GroupBookingDTLs
                                      where pdtl.FK_GroupBookingID == ID
                                      select new { pdtl }).ToList();
                    CurrentDtl.ForEach(x =>
                    {
                        x.pdtl.FK_RateTypeID = (x.pdtl.FK_RateTypeID ?? 0);
                        
                    });
                    entGroupBookingDTLs = CurrentDtl.Select(x => x.pdtl).OrderBy(x => x.id).ToList();
                    entOldGroupBookingDTLs = new List<GroupBookingDTL>(entGroupBookingDTLs);
                    #endregion

                    #region Reload Payment Details
                    entGroupBookingPaymentList = dbh.GroupBookingPayments.Where(x => x.FK_GroupBookingID == entGroupBooking.id).ToList();
                    entOldGroupBookingPaymenteList = new List<GroupBookingPayment>(entGroupBookingPaymentList);
                    #endregion
                    BindGrid();
                    ReloadGridCombos();
                    LoadFullSerialNo();                    
                    CalcNetTotal(false);
                    CalcGrandTotal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Private Method
        private void ReloadGridCombos()
        {
            foreach (DataGridViewRow item in dgDetails.Rows)
            {
                GroupBookingDTL dTL = (GroupBookingDTL)item.DataBoundItem;
                if (dTL != null)
                {
                    LoadRoomTypeCombosRowWise(item, dTL.RoomorHall.ToInt32());
                    LoadRoomsCombosRowWise(item, dTL.FK_RoomTypeID.ToInt32());
                    LoadRateTypeCombosRowWise(item);
                }
            }
        }
        private void SetDefaultComboValues()
        {
            cmbType.SelectedValue = cmbGuestType.SelectedValue =
                cmbSource.SelectedValue = cmbAgent.SelectedValue = 0;

            ActiveControl = cmbCurrency;
            cmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;
        }
        private void InitControls()
        {
            dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
            dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();

            dtpArrivalDate.SetCustomFormat();
            dtpDepartureDate.SetCustomFormat();
            dtpArrivalDate.DisbaleShortDateTimeFormat = true;
            dtpDepartureDate.DisbaleShortDateTimeFormat = true;
        }
        private bool IsRoomTypeChanged()
        {
            if (dgDetails.CurrentCell != null && dgDetails.CurrentCell.Tag != null && dgDetails.CurrentCell.Value != null)
            {
                if(dgDetails.CurrentCell.OwningColumn.Name == col_RoomType.Name)
                    return dgDetails.CurrentCell.Value.ToString2() != dgDetails.CurrentCell.Tag.ToString2();
            }
            return false;
        }
        private void CalculateSlab(bool blnUpdateDeductionAmount, GroupBookingDTL pdtl)
        {
            try
            {
                if (pdtl != null)
                {
                    List<Slab> slabs = null;
                    if (IsRoomTypeChanged())
                    {
                        int iRoomTypeID = pdtl.FK_RoomTypeID.ToInt32();
                        slabs = (from rs in dbh.RoomTypeSlabs
                                 join s in dbh.Slabs on rs.FK_SlabID equals s.id
                                 where rs.FK_RoomTypeID == iRoomTypeID
                                 select s).ToList();
                        if (dgDetails.CurrentCell != null) dgDetails.CurrentCell.Tag = null;
                    }
                    pdtl.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void InitEntities()
        {
            try
            {                
                entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void PopulateRateType()
        {
            try
            {
                List<RateTypes> rateTypes = dbh.RateTypes.ToList();
                rateTypes.Add(new RateTypes()
                {
                    id = 0,
                    Name = MessageKeys.MsgDefault
                });
                Col_RateType.DataSource = rateTypes;
                Col_RateType.DisplayMember = "Name";
                Col_RateType.ValueMember = "id";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void CalcPaymentTotal()
        {
            try
            {
                txtAdvance.Value = entGroupBookingPaymentList.Sum(x => x.Payment).ToDecimal();
                txtBalance.Value = txtGrandTotal.Value - txtAdvance.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private int DateDiff(DateTime d1, DateTime d2)
        {
            try
            {
                TimeSpan span = d2.Subtract(d1);
                return (int)span.TotalDays;
            }
            catch
            {
                return 0;
            }
        }
        private void CalcGrandTotal()
        {
            try
            {
                txtGrandTotal.Value = txtNetTotal.Value;
                txtBalance.Value = txtGrandTotal.Value - txtAdvance.Value;                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadRateTypeCombosRowWise(DataGridViewRow _CurrentRow)
        {
            try
            {
                List<RateTypes> rateTypes = dbh.RateTypes.ToList();
                rateTypes.Add(new RateTypes()
                {
                    id = 0,
                    Name = MessageKeys.MsgDefault
                });
                DataGridViewComboBoxCell _RateType = (_CurrentRow.Cells[Col_RateType.Index] as DataGridViewComboBoxCell);
                _RateType.DataSource = rateTypes;
                _RateType.DisplayMember = "Name";
                _RateType.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcNetTotal(bool blnUpdateDeductionAmount = true)
        {
            try
            {                
                txtAdults.Value = entGroupBookingDTLs.Sum(x => x.Adult).ToInt32();
                txtChilds.Value = entGroupBookingDTLs.Sum(x => x.Child).ToInt32();
                txtTotalAmount.Value = entGroupBookingDTLs.Sum(x => x.Amount).ToDecimal();
                txtTotalDiscount.Value = entGroupBookingDTLs.Sum(x => x.SlabDiscount).ToDecimal() + entGroupBookingDTLs.Sum(x => x.DeductionAmount).ToDecimal();
                lblTotalTax.lblTax1 = entGroupBookingDTLs.Sum(x => x.Tax1Amount).ToDecimal();
                lblTotalTax.lblTax2 = entGroupBookingDTLs.Sum(x => x.Tax2Amount).ToDecimal();
                lblTotalTax.lblTax3 = entGroupBookingDTLs.Sum(x => x.Tax3Amount).ToDecimal();
                lblTotalTax.lblAddnlTax = entGroupBookingDTLs.Sum(x => x.AddnlTaxAmount).ToDecimal();
                lblTotalTax.lblExciseDuty = entGroupBookingDTLs.Sum(x => x.ExciseAmount).ToDecimal();
                lblTotalTax.lblVAT = entGroupBookingDTLs.Sum(x => x.VATAmount).ToDecimal();
                lblTotalTax.lblCGST = entGroupBookingDTLs.Sum(x => x.CGSTAmount).ToDecimal();
                lblTotalTax.lblSGST = entGroupBookingDTLs.Sum(x => x.SGSTAmount).ToDecimal();
                lblTotalTax.lblIGST = entGroupBookingDTLs.Sum(x => x.IGSTAmount).ToDecimal();
                txtTotalTax.Value = lblTotalTax.TotalTax;
                txtNetTotal.Value = (txtTotalAmount.Value + txtTotalTax.Value) - txtTotalDiscount.Value;
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool ValidateRoomRate()
        {
            try
            {
                if (txtExRate.Value == 0) { return false; }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void CalcRoomRent(GroupBookingDTL pdtl)
        {
            try
            {
                if (!_OnLoad)
                {
                    if (!ValidateRoomRate()) { return; }

                    if (pdtl != null)
                    {
                        int iRateTypeId = pdtl.FK_RateTypeID.ToInt32();
                        int iRoomTypeId = pdtl.FK_RoomTypeID.ToInt32();
                        e_RoomTariffs = RateCalculationClass.GetTariffs(dbh, iRoomTypeId, iRateTypeId);
                        if (e_RoomTariffs != null)
                        {
                            pdtl.Rate = e_RoomTariffs.BaseRate.ToDecimal() / txtExRate.Value;
                            pdtl.AdditionalBedRate = e_RoomTariffs.ExtraBedRate.ToDecimal() / txtExRate.Value;
                            pdtl.AdditionalPersonRate = e_RoomTariffs.AdditionalPersonRate.ToDecimal() / txtExRate.Value;
                        }
                        else
                        {
                            pdtl.Rate = 0;
                            pdtl.AdditionalBedRate = 0;
                            pdtl.AdditionalPersonRate = 0;
                        }
                        CalcRowAmount(pdtl);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcRowAmount(GroupBookingDTL pdtl)
        {            
            if (pdtl != null)
            {
                pdtl.Amount = pdtl.Rate * txtNoOfDays.Value + (pdtl.AdditionalPersonRate ?? 0) * (pdtl.AdditionalPersons ?? 0) +
                                                 (pdtl.AdditionalBedRate ?? 0) * (pdtl.AdditionalBeds ?? 0);
                bool blnUpdateDeductionAmount = dgDetails.CurrentCell == null || dgDetails.CurrentCell.OwningColumn.Name != col_DeductionAmount.Name;
                CalculateSlab(blnUpdateDeductionAmount, pdtl);
                CalcNetTotal();
            }
        }
        private void ClearGuestInfo()
        {
            try
            {
                txtTelephone.Text = "";
                cmbBillingAccount.SelectedIndex = -1;
                txtMobile.Text = "";
                txtAdd1.Text = "";
                txtTelephone.Text = "";
                cmbGuest.Focus();
                entGuest = new Guests();
                e_GuestDTLs = new GuestDTLs();
                DefaultCreditCard = 0;
                DefaultCreditCardNumber = string.Empty;
                GuestDeduction = 0;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadGuestInfo(Int64 Guestid)
        {
            try
            {
                entGuest = dbh.Guests.Where(x => x.id == Guestid).SingleOrDefault();
                e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == Guestid).SingleOrDefault();
                if (entGuest != null && e_GuestDTLs != null)
                {
                    txtTelephone.Text = Convert.ToString(e_GuestDTLs.Telephone);
                    txtMobile.Text = Convert.ToString(e_GuestDTLs.Mobile);
                    txtAdd1.Text = Convert.ToString(e_GuestDTLs.Address1);
                    DefaultCreditCard = e_GuestDTLs.FK_CreditCardType.ToInt32();
                    DefaultCreditCardNumber = e_GuestDTLs.CreditCardNo.ToString();
                    GuestDeduction = e_GuestDTLs.DiscountPerc.ToDecimal();
                    if (cmbGuest.SelectedValue.ToInt32() != entGroupBooking.FK_GuestID)
                    {
                        cmbBillingAccount.SelectedValue = entGuest.FK_AccountID.ToString().ToInt32();
                        cmbCurrency.SelectedValue = entGuest.FK_CurrencyHDRID.ToInt32();
                    }
                    else
                    {
                        cmbBillingAccount.SelectedValue = entGroupBooking.FK_BillingAccountID;
                        cmbCurrency.SelectedValue = entGroupBooking.FK_CurrencyHdrID;
                        txtExRate.Value = entGroupBooking.ExRate.ToDecimal();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void ApplyExRate()
        {
            decimal dcCurrentExRate = txtExRate.Value;
            decimal dcExRateChange = ((previousExRate == 0 ? 1 : previousExRate) / (dcCurrentExRate == 0 ? 1 : dcCurrentExRate));
            foreach (GroupBookingDTL dtl in entGroupBookingDTLs)
            {
                if (dtl.FK_RoomID != null)
                {
                    dtl.Rate = dcExRateChange * dtl.Rate;
                    dtl.InclusiveRate = dcExRateChange * dtl.InclusiveRate;
                    dtl.AdditionalBedRate = dcExRateChange * dtl.AdditionalBedRate;
                    dtl.AdditionalPersonRate = dcExRateChange * dtl.AdditionalPersonRate;
                    dtl.Amount = dcExRateChange * dtl.Amount;
                    dtl.TaxableAmount = dcExRateChange * dtl.TaxableAmount;
                    dtl.SlabDiscount = dcExRateChange * dtl.SlabDiscount;
                    dtl.DeductionAmount = dcExRateChange * dtl.DeductionAmount;
                    dtl.ExciseAmount = dcExRateChange * dtl.ExciseAmount;
                    dtl.Tax1Amount = dcExRateChange * dtl.Tax1Amount;
                    dtl.Tax2Amount = dcExRateChange * dtl.Tax2Amount;
                    dtl.Tax3Amount = dcExRateChange * dtl.Tax3Amount;
                    dtl.AddnlTaxAmount = dcExRateChange * dtl.AddnlTaxAmount;
                    dtl.VATAmount = dcExRateChange * dtl.VATAmount;
                    dtl.CGSTAmount = dcExRateChange * dtl.CGSTAmount;
                    dtl.SGSTAmount = dcExRateChange * dtl.SGSTAmount;
                    dtl.IGSTAmount = dcExRateChange * dtl.IGSTAmount;
                    dtl.NetAmount = dcExRateChange * dtl.NetAmount;
                }
            }
            foreach (GroupBookingPayment payment in entGroupBookingPaymentList)
            {
                payment.Payment = dcExRateChange * payment.Payment;
            }
            CalcNetTotal();
            previousExRate = txtExRate.Value;
        }
        private void PostVoucher()
        {
            bool blnNewPaymentRecord = true;
            entVoucherHdrPayment = new VoucherHDR();
            if (!NewRecord)
            {
                if ((entGroupBooking.FK_PaymentVoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdrPayment = dbh.VoucherHDRs.Where(x => x.id == entGroupBooking.FK_PaymentVoucherHDRID).SingleOrDefault();
                    blnNewPaymentRecord = false;
                }
            }

            int iCashorPartyAccountID = cmbBillingAccount.SelectedValue.ToInt32();
            blnPartyUnderCashInHand = aniHelper.isUnderCashInHand(iCashorPartyAccountID);

            #region Payment Posting
            List<VoucherDTL> entVoucherDtlsPayment = new List<VoucherDTL>();
            if (entGroupBookingPaymentList.Count() > 0) // Payment Found
            {
                if (entVoucherHdrPayment.id == 0)
                {
                    entVoucherHdrPayment.id = -1;
                }
                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdrPayment, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-GBK-PAY");


                decimal dcExRate = txtExRate.Value;
                foreach (GroupBookingPayment payment in entGroupBookingPaymentList)
                {
                    #region isCash
                    if (payment.isCash.toBool()) // Cash Payment
                    {
                        if (!blnPartyUnderCashInHand)
                        {
                            int iCashAccountID = payment.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)payment.FK_AccountID;
                            string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                            // Debit to Cash Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashAccountID, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                            // Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                        }
                    }
                    #endregion

                    #region Non Cash
                    else
                    {
                        int iSelectedBankAccount = (int)payment.FK_AccountID;
                        string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                        string sRentAccountName = aniHelper.getLedNameFromAccountID(GlobalProperties.RentAccountID);
                        if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                        {
                            string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);

                            // Debit to Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                            //Credit From Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                        {
                            string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);

                            //Debit to Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                            //Credit From Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                            || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                        {
                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), "", txtRemarks.Text);
                            //Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), "", txtRemarks.Text);
                        }
                    }
                    #endregion
                }
                List<AnalysisDTL> entAnalysisDTLs = new List<AnalysisDTL>();
                GlobalMethods.PostVoucher(blnNewPaymentRecord, entVoucherHdrPayment, entVoucherDtlsPayment, ref dbh, entAnalysisDTLs);
            }
            #endregion
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_GroupBooking, 0, 0, txtVoucherNo.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateGroupBooking()
        {
            try
            {
                entGroupBookingList = dbh.GroupBookings.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTips()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                tooltip.SetToolTip(txtNoOfDays, MessageKeys.MsgNumberOfDays);
                tooltip.SetToolTip(txtNoOfHalls, MessageKeys.MsgEnterNumberOfHalls);
                tooltip.SetToolTip(txtNoOfRooms, MessageKeys.MsgEnterNumberOfRooms);
                tooltip.SetToolTip(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                NumberFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimals;
                sQtyFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimalsQty;

                txtNoOfDays.Format = sQtyFormat;
                txtNoOfHalls.Format = sQtyFormat;
                txtNoOfRooms.Format = sQtyFormat;
                txtTotalTax.Format = NumberFormat;
                txtTotalAmount.Format = NumberFormat;
                txtAdvance.Format = NumberFormat;
                txtTotalDiscount.Format = NumberFormat;
                txtNetTotal.Format = NumberFormat;
                txtGrandTotal.Format = NumberFormat;
                txtBalance.Format = NumberFormat;
                txtBalance.Format = NumberFormat;
                txtExRate.Format = NumberFormat;

                lblCurrencyCap.Visible = GlobalFunctions.blnMultiCurrency;
                cmbCurrency.Visible = GlobalFunctions.blnMultiCurrency;
                lblExRateCap.Visible = GlobalFunctions.blnMultiCurrency;
                txtExRate.Visible = GlobalFunctions.blnMultiCurrency;
                lblMandatory6.Visible = GlobalFunctions.blnMultiCurrency;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Guest
                var entGuests = dbh.Guests.Where(x => x.Active == true).Select(x => new { id = x.id, Name = x.Name }).ToList();
                cmbGuest.DataSource = entGuests;
                cmbGuest.DisplayMember = "Name";
                cmbGuest.ValueMember = "id";
                cmbGuest.SelectedIndex = -1;
                #endregion

                #region BillingAccount
                List<AccountLedger> entDebtors = getAccc.GetAccountLedgers(25);
                cmbBillingAccount.DataSource = entDebtors;
                cmbBillingAccount.DisplayMember = "LedgerName";
                cmbBillingAccount.ValueMember = "id";
                cmbBillingAccount.SelectedIndex = -1;
                #endregion

                #region Type
                List<EnquiryBookingType> entEnquiryBookingTypes = dbh.EnquiryBookingTypes.ToList();
                EnquiryBookingType entEnquiryBookingType = new EnquiryBookingType();
                entEnquiryBookingType.id = 0;
                entEnquiryBookingType.Name = MessageKeys.MsgNone;
                entEnquiryBookingTypes.Insert(0, entEnquiryBookingType);
                cmbType.DataSource = entEnquiryBookingTypes;
                cmbType.DisplayMember = "Name";
                cmbType.ValueMember = "id";
                #endregion

                #region GuestTypes
                List<GuestType> entGuestTypes = dbh.GuestTypes.ToList();
                GuestType entGuestType = new GuestType();
                entGuestType.id = 0;
                entGuestType.Name = MessageKeys.MsgNone;
                entGuestTypes.Insert(0, entGuestType);
                cmbGuestType.DataSource = entGuestTypes;
                cmbGuestType.DisplayMember = "Name";
                cmbGuestType.ValueMember = "id";
                #endregion

                #region Source
                List<Source> entSources = dbh.Sources.ToList();
                Source entSource = new Source();
                entSource.id = 0;
                entSource.Name = MessageKeys.MsgNone;
                entSources.Insert(0, entSource);
                cmbSource.DataSource = entSources;
                cmbSource.DisplayMember = "Name";
                cmbSource.ValueMember = "id";
                #endregion

                #region Agent
                entAgents = dbh.Agents.Where(x => x.Status == 1).ToList();
                Agent entAgent = new Agent();
                entAgent.id = 0;
                entAgent.Name = MessageKeys.MsgNone;
                entAgents.Insert(0, entAgent);
                cmbAgent.DataSource = entAgents;
                cmbAgent.DisplayMember = "Name";
                cmbAgent.ValueMember = "id";
                #endregion

                #region Employee
                entEmployees = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).Where(x => x.Status == 1).ToList();
                cmbEmployee.DataSource = entEmployees;
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }
                #endregion

                #region Currency

                cmbCurrency.DataSource = entCurrencys;
                cmbCurrency.DisplayMember = "CurrencyName";
                cmbCurrency.ValueMember = "id";
                #endregion

                PopulateRateType();
                LoadRoomOrHall();
                LoadRooms(0);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void FnClearAll()
        {
            try
            {
                entGroupBooking = new GroupBooking();
                entGroupBookingDTLs = new List<GroupBookingDTL>();
                entOldGroupBookingDTLs = new List<GroupBookingDTL>();
                entGroupBookingPaymentList = new List<GroupBookingPayment>();
                entOldGroupBookingPaymenteList = new List<GroupBookingPayment>();
                errProvider.Clear();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SetDefaultDateAndTime()
        {
            try
            {
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
                txtNoOfDays.Value = 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadRoomTypeCombosRowWise(DataGridViewRow _CurrentRow, int _RoomOrHallId)
        {
            try
            {
                if (_RoomOrHallId == 1)
                    entRoomTypes = dbh.RoomTypes.Where(x => x.IsHallType == true).ToList();
                else entRoomTypes = dbh.RoomTypes.Where(x => x.IsHallType == false).ToList();
                DataGridViewComboBoxCell _RoomType = (_CurrentRow.Cells[col_RoomType.Index] as DataGridViewComboBoxCell);
                _RoomType.DataSource = entRoomTypes;
                _RoomType.DisplayMember = "Name";
                _RoomType.ValueMember = "id";
                if (_RoomOrHallId == 1) entRooms = dbh.Rooms.Where(x => x.IsHall == true).ToList();
                else entRooms = dbh.Rooms.Where(x => x.IsHall == false).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadRoomsCombosRowWise(DataGridViewRow _CurrentRow, int _RoomTypeId)
        {
            try
            {
                if (_RoomTypeId == 0)
                {
                    entRooms = dbh.Rooms.ToList();
                    DataGridViewComboBoxCell _Rooms = (_CurrentRow.Cells[col_Room.Index] as DataGridViewComboBoxCell);
                    _Rooms.DataSource = entRooms;
                    _Rooms.DisplayMember = "Name";
                    _Rooms.ValueMember = "id";
                }
                else
                {
                    DataGridViewComboBoxCell _Rooms = (_CurrentRow.Cells[col_Room.Index] as DataGridViewComboBoxCell);
                    _Rooms.DataSource = entRooms.Where(x => x.FK_RoomTypeID == _RoomTypeId).ToList(); ;
                    _Rooms.DisplayMember = "Name";
                    _Rooms.ValueMember = "id";
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Grid Method
        private void LoadRoomOrHall()
        {
            try
            {
                DataTable dtForRoomOrHall = new DataTable();
                dtForRoomOrHall.Columns.Add("id", typeof(Int32));
                dtForRoomOrHall.Columns.Add("Name", typeof(string));
                DataRow dr = dtForRoomOrHall.NewRow();
                dr["id"] = 0;
                dr["Name"] = MessageKeys.MsgRoom;
                DataRow dr1 = dtForRoomOrHall.NewRow();
                dr1["id"] = 1;
                dr1["Name"] = MessageKeys.MsgHall;
                dtForRoomOrHall.Rows.Add(dr);
                dtForRoomOrHall.Rows.Add(dr1);
                col_RoomOrHall.DataSource = dtForRoomOrHall;
                col_RoomOrHall.DisplayMember = "Name";
                col_RoomOrHall.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void LoadRooms(int _RoomTypeId)
        {
            try
            {
                if (_RoomTypeId == 0)
                {
                    entRooms = dbh.Rooms.ToList();
                    col_Room.DataSource = entRooms;
                }
                else
                {
                    col_Room.DataSource = entRooms.Where(x => x.FK_RoomTypeID == _RoomTypeId).ToList();
                }
                col_Room.DisplayMember = "Name";
                col_Room.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void LoadCurrentSerialNo()
        {
            try
            {
                if (dgDetails.CurrentRow == null) { return; }
                dgDetails.CurrentRow.Cells[col_slno.Name].Value = dgDetails.CurrentRow.Cells[col_slno.Name].RowIndex + 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadFullSerialNo()
        {
            try
            {
                int i = 1;
                foreach (DataGridViewRow row in dgDetails.Rows)
                {
                    row.Cells[col_slno.Name].Value = i;
                    i = i + 1;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private GroupBookingDTL getCurrent()
        {
            try
            {
                if (dgDetails.CurrentRow != null)
                {
                    GroupBookingDTL GroopBookingDTL = (GroupBookingDTL)dgDetails.CurrentRow.DataBoundItem;
                    return GroopBookingDTL;
                }
                else
                {
                    return null;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void BindGrid()
        {
            try
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.EndEdit();
                bindGroupBookingDTL.DataSource = null;
                bindGroupBookingDTL.DataSource = entGroupBookingDTLs;
                dgDetails.DataSource = bindGroupBookingDTL;

            }
            catch (Exception)
            {

                throw;
            }
        }
        
        private void ApplyGridStyles()
        {
            try
            {
                col_Rate.DefaultCellStyle.Format = NumberFormat;
                Col_Adult.DefaultCellStyle.Format = sQtyFormat;
                Col_Child.DefaultCellStyle.Format = NumberFormat;
                col_AdditionalBeds.DefaultCellStyle.Format = sQtyFormat;
                col_AdditionalBedRate.DefaultCellStyle.Format = NumberFormat;
                col_AdditionalPersons.DefaultCellStyle.Format = sQtyFormat;
                col_AdditionalPersonRate.DefaultCellStyle.Format = NumberFormat;
                col_DeductionPerc.DefaultCellStyle.Format = NumberFormat;
                col_DeductionAmount.DefaultCellStyle.Format = NumberFormat;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool IsNewComboItemAllowed(DataGridViewColumn col)
        {
            try
            {
                return col.Name != col_RoomType.Name && col.Name != col_RoomOrHall.Name && col.Name != col_Room.Name;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private DataGridViewCell MoveForward(DataGridViewCell _currentCell)
        {
            try
            {
                int row_index = _currentCell.OwningRow.Index;
                int col_index = _currentCell.OwningColumn.Index;
                DataGridViewCell cell = dgDetails.Rows[row_index].Cells[col_index + 1];
                if (cell.Visible && cell.ReadOnly == false)
                {
                    return cell;
                }
                else
                {
                    return MoveForward(cell);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private DataGridViewRow GetProductAlreadyExistRow(int _ProductID, DataGridViewRow currentRow)
        {
            try
            {
                DataGridViewRow drowProductExist = null;
                foreach (DataGridViewRow drow in dgDetails.Rows)
                {
                    if (drow != null && drow.DataBoundItem != null && drow != currentRow)
                    {
                        GroupBookingDTL _invDtl = (GroupBookingDTL)drow.DataBoundItem;
                        Rooms punit = null;
                        if (_invDtl != null)
                        {
                            punit = dbh.Rooms.Where(x => x.id == _ProductID).SingleOrDefault();
                        }
                        if (_invDtl.id == _ProductID)
                        {
                            drowProductExist = drow;
                            break;
                        }
                    }
                }
                return drowProductExist;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Grid Events
        private void dgDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            dgDetails.CurrentCell.Tag = dgDetails.CurrentCell.Value ?? string.Empty;
        }
        private void dgDetails_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dgDetails_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
        private void dgDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (e.Control is DataGridViewComboBoxEditingControl)
                {
                    dgDetails.NotifyCurrentCellDirty(true);
                    cb = (DataGridViewComboBoxEditingControl)e.Control;
                    if (cb != null)
                    {
                        cb.DropDownStyle = ComboBoxStyle.DropDownList;
                        cb.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        cb.Validated -= new EventHandler(cb_Validated);
                        cb.Validated += new EventHandler(cb_Validated);
                        cb.Validating -= new CancelEventHandler(cb_Validating);
                        cb.Validating += new CancelEventHandler(cb_Validating);
                        cb.KeyDown -= new KeyEventHandler(cb_KeyDown);
                        cb.KeyDown += new KeyEventHandler(cb_KeyDown);
                        cb.KeyPress += Cb_KeyPress;
                        cb.SelectedIndexChanged += Cb_SelectedIndexChanged;
                        cb.SelectedValueChanged += Cb_SelectedValueChanged;
                        //cb.SelectedIndex = -1;
                        cb.Focus();
                    }
                }
                if (e.Control is DataGridViewTextBoxEditingControl)
                {
                    textbox = (DataGridViewTextBoxEditingControl)e.Control;
                    if (textbox != null)
                    {
                        textbox.KeyPress += new KeyPressEventHandler(textbox_KeyPress);
                        textbox.KeyUp -= new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyUp += new KeyEventHandler(textbox_KeyUp);
                        textbox.KeyDown -= new KeyEventHandler(textbox_KeyDown);
                        textbox.KeyDown += new KeyEventHandler(textbox_KeyDown);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
            }
        }
        private void Cb_SelectedValueChanged(object sender, EventArgs e)
        {

        }
        private void Cb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void Cb_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        void cb_Validated(object sender, EventArgs e)
        {

        }
        void cb_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                {
                    if (dgDetails.LastKey == Keys.Enter)
                    {
                        if (cb.SelectedIndex == -1 && cb.Text != "")
                        {

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        void cb_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                dgDetails.EndEdit();
                dgDetails.CurrentCell = MoveForward(dgDetails.CurrentCell);
            }
        }
        void textbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                sKeyChar = e.KeyChar.ToString();
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_Adult.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Child.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
                {
                    if (Char.IsDigit(e.KeyChar)) return;
                    if (Char.IsControl(e.KeyChar)) return;
                    if ((e.KeyChar == '.') && ((sender as TextBox).Text.Contains('.') == false)) return;
                    if ((e.KeyChar == '.') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                    if ((e.KeyChar == '-') && ((sender as TextBox).Text.Contains('-') == false)) return;
                    if ((e.KeyChar == '-') && ((sender as TextBox).SelectionLength == (sender as TextBox).TextLength)) return;
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        void textbox_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                {
                    if (e.KeyCode == Keys.Right) { return; }
                    if (e.KeyCode == Keys.Left) { return; }
                    if (e.KeyCode == Keys.Return) { return; }
                    if (e.KeyCode == Keys.Escape) { return; }
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        void textbox_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Return)
                {
                    if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                    {
                        int index = dgDetails.SelectedCells[0].OwningRow.Index;
                        if (textbox.Text.Trim() != "")
                        {

                        }
                    }
                    else if (dgDetails.CurrentCell.OwningColumn.Name == col_Room.Name)
                    {
                        int index = dgDetails.SelectedCells[0].OwningRow.Index;
                        if (textbox.Text.Trim() == "")
                        {
                            // e.Handled = true;
                        }
                        else
                        {

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                LoadCurrentSerialNo();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                LoadCurrentSerialNo();
                LoadFullSerialNo();
                CalcNetTotal();
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                if (dgDetails.CurrentCell.OwningColumn.Name == col_RoomOrHall.Name)
                {
                    if (dgDetails.CurrentCell is DataGridViewComboBoxCell)
                    {
                        DataGridViewComboBoxCell cb = (DataGridViewComboBoxCell)dgDetails.CurrentCell;
                        if (cb.Value != null)
                        {
                            LoadRoomTypeCombosRowWise(dgDetails.CurrentRow, cb.Value.ToInt32());
                        }
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_RateType.Name)
                {
                    if (dgDetails.CurrentCell.Value == null) { return; }                    
                    LoadRateTypeCombosRowWise(dgDetails.CurrentRow);
                }
                
                if (dgDetails.CurrentCell.OwningColumn.Name == col_RoomType.Name)
                {
                    if (dgDetails.CurrentCell.Value == null) { return; }                    
                    if (dgDetails.CurrentCell is DataGridViewComboBoxCell)
                    {
                        LoadRoomsCombosRowWise(dgDetails.CurrentRow, dgDetails.CurrentRow.Cells[col_RoomType.Name].Value.ToInt32());
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_RateType.Name || dgDetails.CurrentCell.OwningColumn.Name == col_RoomType.Name)
                    CalcRoomRent(getCurrent());
                else
                    CalcRowAmount(getCurrent());
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgDetails_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            try
            {
                if (e.RowIndex == -1) { return; }
                if (dgDetails.CurrentCell.OwningColumn.Name == Col_Adult.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Child.Name || dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name)
                {
                    if (e.FormattedValue == null || e.FormattedValue.ToString2().Trim() == "")
                    {
                        dgDetails.CurrentCell.Value = 0;
                    }
                }
                if (dgDetails.CurrentCell.OwningColumn.Name == col_Rate.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Child.Name || dgDetails.CurrentCell.OwningColumn.Name == Col_Adult.Name)
                {
                    if (e.FormattedValue.ToString().ToDecimal() < 0)
                    {
                        e.Cancel = true;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region Form Event
        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            GroupCheckInView checkInView = new GroupCheckInView(0, entGroupBooking.id);
            checkInView.Show();
        }
        private void btnAllocate_Click(object sender, EventArgs e)
        {
            entGroupBookingDTLs.Clear();
            List<Rooms> rooms = GlobalMethods.GetAvailableRooms(dtpArrivalDate.Value, dtpDepartureDate.Value, ENMVMTTransactionType.HTL_GroupBooking, entGroupBooking.id);
            for (int i = 0; i < txtNoOfRooms.Value; i++)
            {
                Rooms room = rooms.FirstOrDefault(x => x.IsHall == false);
                if(room != null)
                {
                    GroupBookingDTL groupBookingDTL = new GroupBookingDTL()
                    {
                        RoomorHall = 0,
                        FK_RoomTypeID = room.FK_RoomTypeID,
                        FK_RoomID = room.id,
                        FK_RateTypeID = 0,
                        Adult = 1,
                        Child = 0,
                        DeductionPerc = GuestDeduction
                    };
                    CalcRoomRent(groupBookingDTL);                    
                    entGroupBookingDTLs.Add(groupBookingDTL);
                    rooms.Remove(room);
                }
            }
            for (int i = 0; i < txtNoOfHalls.Value; i++)
            {
                Rooms room = rooms.FirstOrDefault(x => x.IsHall == true);
                if (room != null)
                {
                    GroupBookingDTL groupBookingDTL = new GroupBookingDTL()
                    {
                        RoomorHall = 1,
                        FK_RoomTypeID = room.FK_RoomTypeID,
                        FK_RoomID = room.id,
                        FK_RateTypeID = 0,
                        Adult = 1,
                        Child = 0,
                        DeductionPerc = GuestDeduction
                    };
                    CalcRoomRent(groupBookingDTL);
                    entGroupBookingDTLs.Add(groupBookingDTL);
                    rooms.Remove(room);
                }
            }
            BindGrid();
            ReloadGridCombos();
            LoadFullSerialNo();
            CalcNetTotal(false);
            CalcGrandTotal();
        }
        private void cmbGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    cmbGuest.SelectedValue = frm.SelectedGuestID;
                    cmbGuest.Text = frm.SelectedGuestName;
                    cmbGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtDedPerc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab)
            {
                CalcNetTotal();
            }
        }
        private void txtDedAmount_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab)
            {
                CalcNetTotal(false);
            }
        }
        private void btnNewSource_Click(object sender, EventArgs e)
        {
            try
            {
                SourceView Source = new SourceView();
                Source.ShowDialog();
                cmbSource.DataSource = GlobalMethods.GetSources();
                cmbSource.SelectedValue = Source.CurrentID;
                cmbSource.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewType_Click(object sender, EventArgs e)
        {
            try
            {

                EnquiryBookingTypeView EnquiryBookingType = new EnquiryBookingTypeView();
                EnquiryBookingType.ShowDialog();
                cmbType.DataSource = GlobalMethods.GetEnquiryBookingTypes();
                cmbType.SelectedValue = EnquiryBookingType.CurrentID;
                cmbType.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbGuest_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsActiveControl(sender)) { return; }
                ClearGuestInfo();
                LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
                CalcNetTotal();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }        
        private void dtpArrivalDate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.IsActiveControl(sender, true))
                {
                    txtNoOfDays.Text = GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpDepartureDate.Value).ToString();
                    foreach (var item in entGroupBookingDTLs)
                    {
                        CalcRowAmount(item);
                    }
                };
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnAdvance_Click(object sender, EventArgs e)
        {
            try
            {
                GroupBookingPaymentView payment = new GroupBookingPaymentView(entGroupBookingPaymentList, txtGrandTotal.Value, NumberFormat, DefaultCreditCard,DefaultCreditCardNumber);
                if (payment.ShowDialog() == DialogResult.OK)
                {
                    CalcPaymentTotal();
                    CalcGrandTotal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtAdvance_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnNewGuest_Click(object sender, EventArgs e)
        {
            try
            {
                GuestView guestView = new GuestView(true);
                if (guestView.ShowDialog() == DialogResult.OK)
                {
                    cmbGuest.DataSource = GlobalMethods.GetGuests();
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = guestView.CurrentID;

                    List<AccountLedger> entDebtors = getAccc.GetAccountLedgers(25);
                    cmbBillingAccount.DataSource = entDebtors;
                    cmbBillingAccount.DisplayMember = "LedgerName";
                    cmbBillingAccount.ValueMember = "id";
                    cmbBillingAccount.SelectedIndex = -1;                    
                    cmbType.Focus();
                }
                else
                {
                    cmbGuest.Focus();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewGuestType_Click(object sender, EventArgs e)
        {
            try
            {
                GuestTypeView guestType = new GuestTypeView();
                guestType.ShowDialog();
                cmbGuestType.DataSource = GlobalMethods.GetGuestTypes();
                cmbGuestType.SelectedValue = guestType.CurrentID;
                cmbGuestType.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurrency.ValueMember == "") { return; }
                if (cmbCurrency.SelectedValue == null) { return; }
                int iCurrencyID = cmbCurrency.SelectedValue.ToString2().ToInt32();

                CurrencyClass entCurrency = entCurrencys.Where(x => x.id == iCurrencyID).Single();
                Company company = dbh.Companies.Single();
                int _sourcecurrencyId = company.FK_Currency.toInt32();
                int _destinationCurrencyID = entCurrency.id;
                if (_sourcecurrencyId == _destinationCurrencyID)
                {
                    txtExRate.Enabled = false;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
                txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                ApplyExRate();
            }
            catch (Exception) { }
        }
        private void txtExRate_Enter(object sender, EventArgs e)
        {
            previousExRate = txtExRate.Value;
        }
        private void txtExRate_KeyUp(object sender, KeyEventArgs e)
        {
            ApplyExRate();
        }
        #endregion

        #region Framework Event
        private void GroupBookingView_atInitialise()
        {
            try
            {
                InitEntities();
                InitControls();
                LoadSettings();
                ApplyGridStyles();                
                ShowToolTips();
                PopulateCombos();
                SettingsButton.Visible = true; ShareButton.Visible = true;                
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }
        private void GroupBookingView_Shown(object sender, EventArgs e)
        {
            if (_GroupBookingId != 0)
            {
                ReLoadData(_GroupBookingId);
                onPopulate();
            }
        }

        private void GroupBookingView_atBeforeInitialise()
        {
            _OnLoad = true;
        }
        private void GroupBookingView_atAfterInitialise()
        {
            try
            {
                _OnLoad = false;
                GroupBookingView_atNewClick(null);
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void GroupBookingView_atNewClick(object source)
        {
            try
            {
                PopulateGroupBooking();
                FnClearAll();
                ClearGuestInfo();
                BindGrid();
                SetDefaultDateAndTime();
                SetDefaultComboValues();
                GetSeqNo();
                CalcNetTotal();
                cmbGuest.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex, ENOperation.New);
            }
        }
        private bool GroupBookingView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "")
                {
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNumberCannotBeBlank);
                    txtVoucherNo.Focus();
                    return false;
                }
                if (cmbGuest.Text.Trim() == "")
                {
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                    cmbGuest.Focus();
                    return false;
                }
                if (cmbBillingAccount.Text.Trim() == "")
                {
                    errProvider.SetError(cmbBillingAccount, MessageKeys.MsgBillingAccountMustBeChosen);
                    cmbBillingAccount.Focus();
                    return false;
                }
                if (txtNoOfDays.Text.Trim() == "")
                {
                    errProvider.SetError(txtNoOfDays, MessageKeys.MsgNumberofDaysMustBeEntered);
                    txtNoOfDays.Focus();
                    return false;
                }
                if (txtNoOfDays.Text.ToInt32() < 0)
                {
                    errProvider.SetError(txtNoOfDays, MessageKeys.MsgNumberofDaysMustBeGreaterThanZero);
                    txtNoOfDays.Focus();
                    return false;
                }
                if (txtNoOfRooms.Text.Trim() == "" && txtNoOfHalls.Text.Trim() == "")
                {
                    errProvider.SetError(txtNoOfRooms, MessageKeys.MsgNumberOfRoomsOrHallMustBeEntered);
                    txtNoOfRooms.Focus();
                    return false;
                }
                if (entGroupBookingDTLs.Where(x => x.FK_RoomID != null).ToList().Count <= 0)
                {
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgAtleastOneRowMustBeEntered.GetMsg());
                    dgDetails.Focus();
                    return false;
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                if (GlobalFunctions.blnMultiCurrency)
                {
                    if (cmbCurrency.SelectedValue == null) 
                    { 
                        errProvider.SetError(cmbCurrency, MessageKeys.MsgCurrencyMustBeSelected); 
                        cmbCurrency.Focus(); 
                        return false; 
                    }
                    if (txtExRate.Value == 0)
                    {
                        errProvider.SetError(txtExRate, MessageKeys.MsgExchangeRate + " " + MessageKeys.MsgValueMustBeGreaterThanZero);
                        txtExRate.Focus();
                        return false;
                    }
                }
                int iSelectedRooms = entGroupBookingDTLs.Count(x => x.RoomorHall == 0).ToInt32();                
                if (txtNoOfRooms.Value != iSelectedRooms)
                {
                    errProvider.SetError(txtNoOfRooms, "No of Rooms must be equal to selected rooms count.");
                    txtExRate.Focus();
                    return false;
                }
                int iSelectedHalls = entGroupBookingDTLs.Count(x => x.RoomorHall == 1).ToInt32();
                if (txtNoOfHalls.Value != iSelectedHalls)
                {
                    errProvider.SetError(txtNoOfHalls, "No of Rooms must be equal to selected halls count.");
                    txtExRate.Focus();
                    return false;
                }
                if (entGroupBookingDTLs.GroupBy(x => x.FK_RoomID).Where(x => x.Count() > 1).Any())
                {
                    errProvider.SetError(txtVoucherNo, "Dupicate Rooms/Halls selected.");
                    txtExRate.Focus();
                    return false;
                }

                List<Rooms> rooms = GlobalMethods.GetAvailableRooms(dtpArrivalDate.Value, dtpDepartureDate.Value,
                                                                    ENMVMTTransactionType.HTL_GroupBooking, entGroupBooking.id);                
                foreach (DataGridViewRow dr in dgDetails.Rows)
                {
                    dr.ErrorText = string.Empty;
                    GroupBookingDTL dtl = (GroupBookingDTL)dr.DataBoundItem;
                    if (dtl != null)
                    {
                        if (!rooms.Where(x => x.id == dtl.FK_RoomID).Any())
                        {
                            dr.ErrorText = "Room not available.";
                            dgDetails.Focus();
                            return false;
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool GroupBookingView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    dbh = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                #region Voucher Posting
                if (!blnSanctioningRequired)
                {
                    PostVoucher();
                }

                if (!blnSanctioningRequired && entGroupBookingPaymentList.Count() > 0)
                {
                    entGroupBooking.FK_PaymentVoucherHDRID = entVoucherHdrPayment.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entGroupBooking.FK_PaymentVoucherHDRID, ref dbh);
                    entGroupBooking.FK_PaymentVoucherHDRID = null;
                }
                #endregion

                #region Group Booking Details
                entGroupBooking.ContextID = iContextID;
                entGroupBooking.LocationID = GlobalFunctions.LoginLocationID;
                entGroupBooking.LoginUserID = GlobalFunctions.LoginUserID;
                entGroupBooking.VoucherNo = txtVoucherNo.Text;
                entGroupBooking.VoucherDate = dtVoucherDate.Value;
                entGroupBooking.FK_GuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                entGroupBooking.FK_BillingAccountID = cmbBillingAccount.SelectedValue.ToString().ToInt32();
                entGroupBooking.FK_CurrencyHdrID = cmbCurrency.SelectedValue.ToString2().ToInt32();
                entGroupBooking.ExRate = txtExRate.Value;
                if (cmbType.Text != MessageKeys.MsgNone)
                {
                    entGroupBooking.Type = cmbType.Text;
                }
                else
                {
                    entGroupBooking.Type = null;
                }
                if (cmbGuestType.Text != MessageKeys.MsgNone)
                {
                    entGroupBooking.GuestType = cmbGuestType.Text.ToString();
                }
                else
                {
                    entGroupBooking.GuestType = null;
                }
                if (cmbSource.Text != MessageKeys.MsgNone)
                {
                    entGroupBooking.Source = cmbSource.Text.ToString();
                }
                else
                {
                    entGroupBooking.Source = null;
                }
                entGroupBooking.ArrivalDate = dtpArrivalDate.Value;
                entGroupBooking.DepartureDate = dtpDepartureDate.Value;
                entGroupBooking.NoofDays = txtNoOfDays.Text.ToInt32();
                entGroupBooking.NoofRooms = txtNoOfRooms.Text.ToInt32();
                entGroupBooking.NoofHalls = txtNoOfHalls.Text.ToInt32();
                if (cmbAgent.Text != null && cmbAgent.SelectedValue.ToInt32() != 0)
                {
                    entGroupBooking.FK_AgentID = cmbAgent.SelectedValue.ToString().ToInt32();
                }
                else
                {
                    entGroupBooking.FK_AgentID = null;
                }
                if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
                {
                    entGroupBooking.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
                }
                else
                {
                    entGroupBooking.FK_EmployeeID = null;
                }
                entGroupBooking.Remarks = txtRemarks.Text;
                entGroupBooking.TotalAdult = txtAdults.Text.ToInt32();
                entGroupBooking.TotalChild = txtChilds.Text.ToInt32();
                entGroupBooking.Amount = txtTotalAmount.Value;
                entGroupBooking.TotalTaxAmount = txtTotalTax.Value;
                entGroupBooking.GrandTotal = txtNetTotal.Value;
                entGroupBooking.Advance = txtAdvance.Value;
                entGroupBooking.Balance = txtBalance.Value;
                entGroupBooking.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entGroupBooking.Sanctioned = !blnSanctioningRequired;
                entGroupBooking.Cancelled = false;
                if (NewRecord)
                {
                    dbh.GroupBookings.AddObject(entGroupBooking);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(entGroupBooking, EntityState.Modified);
                }
                #endregion

                #region Removing Deleted GroupBookingDTLs
                var bd1 = entOldGroupBookingDTLs.Select(x => new { id = x.id });
                var bd2 = entGroupBookingDTLs.Select(y => new { id = y.id });
                var deletedbookingdtls = bd1.Except(bd2);
                foreach (var deletedItem in deletedbookingdtls)
                {
                    GroupBookingDTL delItDTL = entOldGroupBookingDTLs.Where(x => x.id == deletedItem.id).First();
                    GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupBooking, delItDTL);
                    dbh.GroupBookingDTLs.DeleteObject(delItDTL);
                }
                #endregion

                #region Adding or Updating Group Booking Details
                int iSlNo = 0;
                foreach (GroupBookingDTL groupBookingDTL in bindGroupBookingDTL.List)
                {
                    if (groupBookingDTL.FK_RoomID != null)
                    {
                        iSlNo++;                        
                        groupBookingDTL.SlNo = iSlNo;
                        groupBookingDTL.FK_GroupBookingID = entGroupBooking.id;
                        if (groupBookingDTL.FK_RateTypeID == 0)
                            groupBookingDTL.FK_RateTypeID = null;
                        if (dbh.GroupBookingDTLs.Where(x => x.id == groupBookingDTL.id).ToList().Count == 0)
                        {
                            groupBookingDTL.id = int.MinValue + iSlNo;
                            dbh.GroupBookingDTLs.AddObject(groupBookingDTL);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(groupBookingDTL, System.Data.EntityState.Modified);
                        }

                        #region Save to RoomStatusRegister
                        groupBookingDTL.ArrivalDate = entGroupBooking.ArrivalDate;
                        groupBookingDTL.DepartureDate = entGroupBooking.DepartureDate;
                        groupBookingDTL.FK_GuestID = entGroupBooking.FK_GuestID;
                        GlobalMethods.SaveRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupBooking, groupBookingDTL);
                        #endregion
                    }
                }
                #endregion

                #region Removing Deleted Payments
                var p1 = entOldGroupBookingPaymenteList.Select(x => new { id = x.id });
                var p2 = entGroupBookingPaymentList.Select(y => new { id = y.id });
                var deletedpayments = p1.Except(p2);
                foreach (var deletedItem in deletedpayments)
                {
                    GroupBookingPayment delItPay = entOldGroupBookingPaymenteList.Where(x => x.id == deletedItem.id).First();
                    dbh.GroupBookingPayments.DeleteObject(delItPay);
                }
                #endregion

                #region Adding or Updating Payments
                foreach (GroupBookingPayment GrpBookingPayment in entGroupBookingPaymentList)
                {
                    if (GrpBookingPayment.Payment != 0)
                    {
                        GrpBookingPayment.FK_GroupBookingID = entGroupBooking.id;//Entity Not Set 
                        if (GrpBookingPayment.FK_MVInstrumentTypeID == 0)
                        {
                            GrpBookingPayment.FK_MVInstrumentTypeID = null;
                        }
                        if (dbh.GroupBookingPayments.Where(x => x.id == GrpBookingPayment.id).ToList().Count == 0)
                        {
                            dbh.GroupBookingPayments.AddObject(GrpBookingPayment);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(GrpBookingPayment, System.Data.EntityState.Modified);
                        }
                    }
                }
                #endregion

                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_GroupBookingVoucherNo"))
                    {
                        return GroupBookingView_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Save);
                return false;
            }
        }
        private bool GroupBookingView_atAfterSave(object source)
        {
            if (GlobalProperties.PrintWhileSavingInGroupBooking)
            {
                PrintClick();
            }
            if (GlobalProperties.SendEmailWhileSavingInGroupBooking)
            {
                SendEmail();
            }
            if (GlobalProperties.SendSMSWhileSavingInGroupBooking)
            {
                SendSMS();
            }
            NewClick();
            return true;
        }
        private void GroupBookingView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vBooking = entGroupBookingList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id);
                e.SearchEntityList = vBooking;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }        
        private bool GroupBookingView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vGrpBookings = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vGrpBookings).id);
                }
                else
                {
                    cmbGuest.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool GroupBookingView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {                
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void GroupBookingView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbGuest.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool GroupBookingView_atPrint(object source)
        {
            try
            {
                if (entGroupBooking.id == 0)
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Group Booking", entGroupBooking.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool GroupBookingView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteVoucher(entGroupBooking.FK_PaymentVoucherHDRID, ref dbh);
                foreach (GroupBookingDTL bookingDTL in entGroupBookingDTLs)
                {
                    dbh.GroupBookingDTLs.DeleteObject(bookingDTL);
                    GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_GroupBooking, bookingDTL);
                }
                foreach (GroupBookingPayment Payment in entGroupBookingPaymentList) //**Delete Payments **
                {
                    dbh.GroupBookingPayments.DeleteObject(Payment);
                }
                dbh.DeleteObject(entGroupBooking);        //**Delete Group Bookings**
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void GroupBookingView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
