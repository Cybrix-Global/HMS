﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseForms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.ORM;
using atACC.CommonExtensions;
using atACC.HTL.Masters;
using atACCFramework.UserControls;
using atACC.HTL.Transactions.Sub_Forms;

namespace atACC.HTL.Transactions
{
    public partial class EnquiryView : SearchFormBase2
    {
        #region Private Varibales
        Enquiry m_Enquiry;
        List<Enquiry> m_EnquerysList;
        List<Rooms> entRooms;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        bool _OnLoad = true;
        #endregion Private Varibales

        #region Constructor
        public EnquiryView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion Constructor

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(0);
            if (settings.ShowDialog() == DialogResult.OK)
            {
                
            }
        }
        #endregion

        #region Populate Events
        public override void LoadVouchers()
        {
            try
            {
                string sTempVno = txtVoucherNo.Text;
                dbh = atHotelContext.CreateContext();
                List<UpDownData> _Vouchers = dbh.Enquiries.OrderByDescending(x => x.id)
                    .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                    .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
                txtVoucherNo.Items.Clear();
                txtVoucherNo.DataSource = _Vouchers;
                if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
                txtVoucherNo.Text = sTempVno;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Enquiry, 0, 0,txtVoucherNo.Text, GlobalFunctions.CurrentFiscalPeriodID);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateEnquery()
        {
            try
            {
                m_EnquerysList = dbh.Enquiries.ToList();
            }
            catch (Exception)
            {
                throw;

            }
        }
        public void PopulateCombos()
        {
            try
            {
                #region Type
                List<EnquiryBookingType> enquiryBookingTypes = dbh.EnquiryBookingTypes.ToList();
                EnquiryBookingType enquiryBookingType = new EnquiryBookingType();
                enquiryBookingType.id = 0;
                enquiryBookingType.Name = MessageKeys.MsgNone;
                enquiryBookingTypes.Insert(0, enquiryBookingType);
                cmbType.DataSource = enquiryBookingTypes;
                cmbType.DisplayMember = "Name";
                cmbType.ValueMember = "id";
                #endregion

                #region Agent
                List<Agent> agents = dbh.Agents.ToList();
                Agent agent = new Agent();
                agent.id = 0;
                agent.Name = MessageKeys.MsgNone;
                agents.Insert(0, agent);
                cmbAgent.DataSource = agents.ToList();
                cmbAgent.DisplayMember = "Name";
                cmbAgent.ValueMember = "id";
                #endregion

                #region Source
                List<Source> entSources = dbh.Sources.ToList();
                Source entSource = new Source();
                entSource.id = 0;
                entSource.Name = MessageKeys.MsgNone;
                entSources.Insert(0, entSource);
                cmbSource.DataSource = entSources;
                cmbSource.DisplayMember = "Name";
                cmbSource.ValueMember = "id";
                #endregion

                #region Employee
                List<Employee> entEmployees = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).ToList();
                cmbEmployee.DataSource = entEmployees;
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void PopulateRoomTypes()
        {
            try
            {
                if (cmbRoomOrHall.Text == MessageKeys.MsgHall)
                {
                    cmbRoomType.DataSource = dbh.RoomTypes.Where(x => x.IsHallType == true).ToList();
                }
                else
                {
                    cmbRoomType.DataSource = dbh.RoomTypes.Where(x => x.IsHallType == false).ToList();
                }
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ChangeLabelCaptions()
        {
            try
            {
                if (cmbRoomOrHall.Text == MessageKeys.MsgHall)
                {
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        lblRoomType.Text = MessageKeys.MsgHallType;
                        lblNoOfRooms.Text = MessageKeys.MsgNoOfHalls;
                    }
                    else
                    {
                        lblRoomType.Text = MessageKeys.MsgHallType + " :";
                        lblNoOfRooms.Text = MessageKeys.MsgNoOfHalls + " :";
                    }
                }
                else
                {
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        lblRoomType.Text = MessageKeys.MsgRoomType;
                        lblNoOfRooms.Text = MessageKeys.MsgNoOfRooms;
                    }
                    else
                    {
                        lblRoomType.Text = MessageKeys.MsgRoomType + " :";
                        lblNoOfRooms.Text = MessageKeys.MsgNoOfRooms + " :";
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(txtContactPerson, MessageKeys.MsgEnterContactPerson);
                tooltip.SetToolTip(txtCity, MessageKeys.MsgEnterCity);
                tooltip.SetToolTip(txtPhone, MessageKeys.MsgEnterTelephoneNumber);
                tooltip.SetToolTip(txtMobile, MessageKeys.MsgEnterMobile);
                tooltip.SetToolTip(txtEmail, MessageKeys.MsgEnterEmailAddress);
                tooltip.SetToolTip(cmbType, MessageKeys.MsgChooseType);
                tooltip.SetToolTip(cmbAgent, MessageKeys.MsgChooseAgent);
                tooltip.SetToolTip(cmbSource, MessageKeys.MsgChooseSource);
                tooltip.SetToolTip(cmbRoomOrHall, MessageKeys.MsgChooseRoomOrHall);
                tooltip.SetToolTip(cmbRoomType,MessageKeys.MsgChooseRoomOrHallType);
                tooltip.SetToolTip(txtNoOfRooms,MessageKeys.MsgEnterNumberOfRooms);
                tooltip.SetToolTip(txtNoOfDays, MessageKeys.MsgEnterNumberOfDays);
                tooltip.SetToolTip(cmbEmployee, MessageKeys.MsgChooseReceptionist);
                tooltip.SetToolTip(txtRemarks, MessageKeys.MsgEnterRemarks);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            m_Enquiry = new Enquiry();
            m_EnquerysList = new List<Enquiry>();
            cmbRoomOrHall.SelectedIndex = 0;
            txtName.Focus();
        }
        int DateDiff(DateTime d1, DateTime d2)
        {
            try
            {
                TimeSpan span = d2.Subtract(d1);
                return (int)span.TotalDays;
            }
            catch { return 0; }
        }
        private void SetDefaultDateAndTime()
        {
            try
            {
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
                txtNoOfDays.Value = 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion Populate Event

        #region Form Event
        private void txtVoucherNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dbh = atHotelContext.CreateContext();
                int _id = dbh.Enquiries
                    .Where(x => x.VoucherNo == txtVoucherNo.Text
                    && x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID
                    ).Select(x => x.id).FirstOrDefault();
                if (_id != 0)
                {
                    ReLoadData(_id);
                    onPopulate();
                    AfterOnPopulate();
                }
                else
                {
                    string sEnteredVNO = txtVoucherNo.Text;
                    NewClick();
                    txtVoucherNo.Text = sEnteredVNO;
                    txtName.Focus();
                    e.Handled = true;
                }
            }
        }
        private void btnNewType_Click(object sender, EventArgs e)
        {
            try
            {
                EnquiryBookingTypeView EnquiryBookingType = new EnquiryBookingTypeView();
                EnquiryBookingType.ShowDialog();
                cmbType.DataSource = GlobalMethods.GetEnquiryBookingTypes();
                cmbType.SelectedValue = EnquiryBookingType.CurrentID;
                cmbType.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewSource_Click(object sender, EventArgs e)
        {
            try
            {
                SourceView Source = new SourceView();
                Source.ShowDialog();
                cmbSource.DataSource = GlobalMethods.GetSources();
                cmbSource.SelectedValue = Source.CurrentID;
                cmbSource.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbType_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbRoomOrHall_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateRoomTypes();
                ChangeLabelCaptions();
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dtpArrivalDate_ValueChanged(object sender, EventArgs e)
        {
            if (this.IsActiveControl(sender, true))
            {
                txtNoOfDays.Text = GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpDepartureDate.Value).ToString();
            }
        }
        #endregion

        #region Framework events
        private void FrmEnquery_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();                
                dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
                dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();                
                dtpArrivalDate.SetCustomFormat();
                dtpDepartureDate.SetCustomFormat();
                dtpArrivalDate.DisbaleShortDateTimeFormat = true;
                dtpDepartureDate.DisbaleShortDateTimeFormat = true;
                ShareButton.Visible = false;
                SettingsButton.Visible = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }
        private void FrmEnquery_atAfterInitialise()
        {
            try
            {
                PopulateEnquery();
                PopulateCombos();
                SetDefaultDateAndTime();
                LoadSettings();
                ShowToolTip();
                GetSeqNo();
                _OnLoad = false;
                cmbRoomOrHall.Items.Add(MessageKeys.MsgRoom);
                cmbRoomOrHall.Items.Add(MessageKeys.MsgHall);
                cmbRoomOrHall.SelectedIndex = 0;
                txtName.Focus();
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void FrmEnquery_atNewClick(object source)
        {
            try
            {
                m_Enquiry = new Enquiry();
                dbh = atHotelContext.CreateContext();
                FnClearAll();
                PopulateEnquery();
                PopulateCombos();
                SetDefaultDateAndTime();
                LoadSettings();
                GetSeqNo();
                txtName.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool FrmEnquery_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNo);
                    txtVoucherNo.Focus();
                    return false;
                }
                if (txtName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtName, MessageKeys.MsgName);
                    txtName.Focus();
                    return false;
                }
                if (!GlobalFunctions.IsValidMobileNo(txtMobile.Text))
                {
                    errProvider.SetError(txtMobile, MessageKeys.MsgInvalidMobileNumber);
                    txtMobile.Focus();
                    return false;
                }
                if (!GlobalFunctions.IsValidEmailId(txtEmail.Text))
                {
                    errProvider.SetError(txtEmail, MessageKeys.MsgInvalidEmailAddress);
                    txtEmail.Focus();
                    return false;
                }
                if (cmbRoomOrHall.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbRoomOrHall, MessageKeys.MsgRoomOrHallMustBeChosen);
                    cmbRoomOrHall.Focus();
                    return false;
                }
                if (cmbRoomType.Text.Trim() == string.Empty && lblRoomType.Text == MessageKeys.MsgRoomType)
                {
                    errProvider.SetError(cmbRoomType, MessageKeys.MsgRoomTypeMustBeChosen);
                    cmbRoomType.Focus();
                    return false;
                }
                if (cmbRoomType.Text.Trim() == string.Empty && lblRoomType.Text == MessageKeys.MsgHallType)
                {
                    errProvider.SetError(cmbRoomType, MessageKeys.MsgHallTypeMustBeChosen);
                    cmbRoomType.Focus();
                    return false;
                }
                if (txtNoOfRooms.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtNoOfRooms, MessageKeys.MsgNumberOfRoomsOrHallMustBeEntered);
                    txtNoOfRooms.Focus();
                    return false;
                }
                if (txtNoOfDays.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtNoOfDays, MessageKeys.MsgNumberofDaysMustBeEntered);
                    txtNoOfDays.Focus();
                    return false;
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredWhileValidating);
                return false;
            }
        }
        private bool FrmEnquery_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if(NewRecord)
                {
                    GetSeqNo();
                    m_Enquiry = new Enquiry();
                }
                m_Enquiry.ContextID = iContextID;
                m_Enquiry.LocationID = GlobalFunctions.LoginLocationID;
                m_Enquiry.LoginUserID = GlobalFunctions.LoginUserID;
                if (NewRecord)
                {
                    m_Enquiry.CreatedDate = System.DateTime.Now;
                }
                m_Enquiry.ModifiedDate = System.DateTime.Now;
                m_Enquiry.VoucherNo = txtVoucherNo.Text.ToString();
                m_Enquiry.VoucherDate = dtVoucherDate.Value;
                m_Enquiry.Name = txtName.Text.ToString();
                m_Enquiry.ContactPerson = txtContactPerson.Text.ToString();
                m_Enquiry.City = txtCity.Text.ToString();
                m_Enquiry.Telephone = txtPhone.Text.ToString();
                m_Enquiry.Mobile = txtMobile.Text.ToString();
                m_Enquiry.Email = txtEmail.Text.ToString();
                if (cmbType.Text != MessageKeys.MsgNone)
                {
                    m_Enquiry.Type = cmbType.Text.ToString();
                }
                else 
                {
                    m_Enquiry.Type = null;
                }
                if (cmbAgent.Text != MessageKeys.MsgNone)
                {
                    m_Enquiry.FK_AgentID = cmbAgent.SelectedValue.ToInt32();
                }
                else 
                {
                    m_Enquiry.FK_AgentID = null;
                }
                if (cmbSource.Text != MessageKeys.MsgNone)
                {
                    m_Enquiry.Source = cmbSource.Text.ToString();
                }
                else
                {
                    m_Enquiry.Source = null;
                }
                if (cmbRoomOrHall.Text ==MessageKeys.MsgRoom)
                {
                    m_Enquiry.RoomorHall = 0;
                }
                else
                {
                    m_Enquiry.RoomorHall = 1;
                }
                m_Enquiry.FK_RoomTypeID = cmbRoomType.SelectedValue.ToInt32();
                m_Enquiry.NoofRooms = txtNoOfRooms.Text.ToInt32();
                m_Enquiry.ArrivalDate = dtpArrivalDate.Value;
                m_Enquiry.DepartureDate = dtpDepartureDate.Value;
                m_Enquiry.NoofDays = txtNoOfDays.Text.ToInt32();
                m_Enquiry.FK_EmployeeID = cmbEmployee.SelectedValue.ToInt32();
                m_Enquiry.Remarks = txtRemarks.Text.ToString();
                m_Enquiry.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                m_Enquiry.Sanctioned = true;
                m_Enquiry.Cancelled = false;
                if (NewRecord)
                {
                    dbh.Enquiries.AddObject(m_Enquiry);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_Enquiry, EntityState.Modified);
                }
                dbh.SaveChanges();
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_EnqueryVoucherNo"))
                    {
                        return FrmEnquery_atSaveClick(source, e);
                    }
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredWhileSaving);
                return false;
            }
        }
        private bool FrmEnquery_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInEnquiry)
                {
                    PrintClick();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
                return false;
            }
        }
        private void FrmEnquery_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = m_EnquerysList.Select(x => new { x.id, Name = x.Name }).OrderByDescending(x => x.id);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredBeforeSearching);
            }
        }
        public override void AfterOnPopulate()
        {
            base.AfterOnPopulate();
            if (m_Enquiry.Cancelled.toBool())
            {
                EditButton.Enabled = false;
                DeleteButton.Enabled = false;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            Enquiry enquiry = dbh.Enquiries.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (enquiry != null)
            {
                ReLoadData(enquiry.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_Enquiry = dbh.Enquiries.Where(x => x.id == id).SingleOrDefault();
                if (m_Enquiry != null)
                {
                    txtVoucherNo.Text = m_Enquiry.VoucherNo.ToString();
                    dtVoucherDate.Value = m_Enquiry.VoucherDate.ToDateTime();
                    txtName.Text = m_Enquiry.Name.ToString();
                    txtContactPerson.Text = m_Enquiry.ContactPerson.ToString();
                    txtCity.Text = m_Enquiry.City.ToString();
                    txtPhone.Text = m_Enquiry.Telephone.ToString();
                    txtMobile.Text = m_Enquiry.Mobile.ToString();
                    txtEmail.Text = m_Enquiry.Email.ToString();
                    if (m_Enquiry.Type != null)
                    {
                        cmbType.Text = m_Enquiry.Type.ToString();
                    }
                    else
                    {
                        cmbType.Text = MessageKeys.MsgNone;
                    }
                    if (m_Enquiry.FK_AgentID != null)
                    {
                        cmbAgent.SelectedValue = m_Enquiry.FK_AgentID.ToInt32();
                    }
                    else
                    {
                        cmbAgent.SelectedValue = 0;
                    }
                    if (m_Enquiry.Source != null)
                    {
                        cmbSource.Text = m_Enquiry.Source.ToString();
                    }
                    else
                    {
                        cmbSource.Text = MessageKeys.MsgNone;
                    }

                    cmbRoomOrHall.Text = m_Enquiry.RoomorHall == 1 ? MessageKeys.MsgHall : MessageKeys.MsgRoom;
                    cmbRoomType.SelectedValue = m_Enquiry.FK_RoomTypeID;
                    txtNoOfRooms.Value = m_Enquiry.NoofRooms.Value;
                    dtpArrivalDate.Value = m_Enquiry.ArrivalDate.ToDateTime();
                    dtpDepartureDate.Value = m_Enquiry.DepartureDate.ToDateTime();
                    txtNoOfDays.Value = m_Enquiry.NoofDays.Value;
                    cmbEmployee.SelectedValue = m_Enquiry.FK_EmployeeID.ToInt32();
                    txtRemarks.Text = m_Enquiry.Remarks;
                }
                else 
                {
                    NewClick();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool FrmEnquery_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vLoan = new { id = 0, Name = string.Empty };
                    ReLoadData(e.GetSelectedEntity().Cast(vLoan).id);
                }
                else 
                {
                    txtName.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSearching);
                return false;
            }
        }
        private void FrmEnquery_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus(); 
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool EnquiryView_atPrint(object source)
        {
            try
            {
                if (m_Enquiry.id == 0)
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Enquiry", m_Enquiry.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool FrmEnquery_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.Enquiries.DeleteObject(m_Enquiry);
                dbh.SaveChanges();
                PopulateCombos();
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void FrmHallView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
                PopulateEnquery();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
            }
        }
        #endregion Framework events
    }
}
