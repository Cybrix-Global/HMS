﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.Common;
using atACC.CommonExtensions;
using System.Text.RegularExpressions;
using System.Data.Objects;
using atACCFramework;
using atACC.HTL.ORM;

namespace atACC.HTL.Transactions
{
    public partial class LaundryPaymentView : FormBase
    {
        #region Private Variable
        atACCHotelEntities dbh;
        List<MasterValue> entPaymentModes;
        List<MasterValue> entCardTypes;
        List<MasterValue> entInstrumentStatus;
        List<PaymentTerminal> entTerminal;
        bool blnPartyUnderCashInHand;
        List<LaundryPayment> entLaundryPayment;
        decimal dcmGrandAmount;
        List<atACC.HTL.ORM.AccountLedger> entCashOrBankAccounts;
        List<atACC.HTL.ORM.AccountLedger> entCashAccounts;
        string NumberFormat;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;
        #endregion

        #region Constructor
        public LaundryPaymentView(List<LaundryPayment> _entLaundryPayment, decimal _dcmGrandAmount, string _NumberFormat, int _DefaultCreditCard, string _DefaultCreditCardNumber)
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            _entLaundryPayment.RemoveAll(x => x.Payment == null);
            entLaundryPayment = _entLaundryPayment;
            NumberFormat = _NumberFormat;
            dcmGrandAmount = _dcmGrandAmount;
            DefaultCreditCard = _DefaultCreditCard;
            DefaultCreditCardNumber = _DefaultCreditCardNumber;
            LoadSettings();
            PopulateEntities();
            PopulateCombos();
            ApplyZeroToInstrumentTypeID();
            BindGrid();
            CalcTotals();
        }
        #endregion

        #region private Methods
        private void ApplyZeroToInstrumentTypeID()
        {
            try
            {
                foreach (LaundryPayment _EntryPay in entLaundryPayment)
                {
                    if (_EntryPay.FK_MVInstrumentTypeID == null)
                    {
                        _EntryPay.FK_MVInstrumentTypeID = 0;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                colAmount.DefaultCellStyle.Format = NumberFormat;
                lblPayments.Format = NumberFormat;
                lblBillAmount.Format = NumberFormat;
                lblBalance.Format = NumberFormat;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateEntities()
        {
            try
            {
                entCashOrBankAccounts = dbh.AccountLedgers.Where(x => x.FK_AccountGroupID == (int)ENAccountGroups.CashinHand || x.FK_AccountGroupID == (int)ENAccountGroups.Banks)
                  .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || x.BuiltIn == true || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                  .OrderBy(x => x.LedgerName).ToList();
                entCashAccounts = dbh.AccountLedgers.Where(x => x.FK_AccountGroupID == 25)
                .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || x.BuiltIn == true || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                .OrderBy(x => x.LedgerName).ToList();

                List<int> excludeModes = new List<int>();
                excludeModes.Add((int)ENMVInstrumentType.DD);
                excludeModes.Add((int)ENMVInstrumentType.OnlineBanking);
                excludeModes.Add((int)ENMVInstrumentType.EWallet);
                entCardTypes = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.CardTypes).OrderBy(x => x.Name).ToList();
                entPaymentModes = new List<MasterValue>();
                entTerminal = dbh.PaymentTerminals.ToList();
                if (blnPartyUnderCashInHand)
                {
                    entPaymentModes = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.InstrumentType
                        && (!excludeModes.Contains(x.id))
                        ).OrderBy(x => x.Name).ToList();
                }
                else
                {
                    entPaymentModes = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.InstrumentType).OrderBy(X => X.Name).ToList();
                    MasterValue mvCash = new MasterValue();
                    mvCash.Name = mvCash.Description = MessageKeys.MsgCash;
                    mvCash.id = 0;
                    entPaymentModes.Add(mvCash);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCombos()
        {
            try
            {
                colCardType.DisplayMember = "Description";
                colCardType.ValueMember = "id";
                colCardType.DataSource = entCardTypes;

                colMode.DisplayMember = "Description";
                colMode.ValueMember = "id";
                colMode.DataSource = entPaymentModes;

                colInstrumentStatus.DataSource = entInstrumentStatus;
                colInstrumentStatus.DisplayMember = "Description";
                colInstrumentStatus.ValueMember = "id";

                colAccount.DisplayMember = "LedgerName";
                colAccount.ValueMember = "id";
                colAccount.DataSource = entCashOrBankAccounts;

                ColPaymentTerminal.DisplayMember = "Name";
                ColPaymentTerminal.ValueMember = "id";
                ColPaymentTerminal.DataSource = entTerminal;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void BindGrid()
        {
            try
            {
                dgPayment.AutoGenerateColumns = false;
                dgPayment.DataSource = null;
                bindPayment.DataSource = null;
                bindPayment.DataSource = entLaundryPayment;
                dgPayment.DataSource = bindPayment;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcTotals()
        {
            try
            {
                if (entLaundryPayment != null)
                    lblBillAmount.Value = dcmGrandAmount;
                lblPayments.Value = entLaundryPayment.Sum(x => x.Payment).ToDecimal();
                lblBalance.Value = lblBillAmount.Value - lblPayments.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool ValidatePayment()
        {
            try
            {
                foreach (DataGridViewRow dgRow in dgPayment.Rows)
                {
                    dgRow.ErrorText = "";
                    LaundryPayment _LaundryPay = (LaundryPayment)dgRow.DataBoundItem;
                    if (_LaundryPay != null && _LaundryPay.FK_MVInstrumentTypeID != null)
                    {
                        if (_LaundryPay.FK_AccountID == null)
                        {
                            dgRow.ErrorText = MessageKeys.MsgAccountMustBeSelected;
                            dgPayment.CurrentCell = dgRow.Cells[colAccount.Name];
                            return false;
                        }
                        if (_LaundryPay.Payment == null || _LaundryPay.Payment == 0)
                        {
                            dgRow.ErrorText = MessageKeys.MsgPaymentAmountCannotBeZero; dgPayment.CurrentCell = dgRow.Cells[colAmount.Name];
                            return false;
                        }
                        if (_LaundryPay.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                        {
                            if (_LaundryPay.InstrumentNo == null || _LaundryPay.InstrumentNo == "")
                            {
                                dgRow.ErrorText = MessageKeys.MsgInstrumentNumberMustBeEntered; dgPayment.CurrentCell = dgRow.Cells[colInstrumentNo.Name];
                                return false;
                            }
                        }
                        else if (_LaundryPay.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                        {
                            if (_LaundryPay.InstrumentNo == null && !GlobalFunctions.GetANISettings((int)ENANISettings.CreditCardnonotmandatory)
                                || _LaundryPay.InstrumentNo == "" && !GlobalFunctions.GetANISettings((int)ENANISettings.CreditCardnonotmandatory))
                            {
                                dgRow.ErrorText = MessageKeys.MsgInstrumentNumberMustBeEntered; dgPayment.CurrentCell = dgRow.Cells[colInstrumentNo.Name];
                                return false;
                            }
                            if (_LaundryPay.FK_MVCardType == null)
                            {
                                dgRow.ErrorText = MessageKeys.MsgCardTypeMustBeSelected; dgPayment.CurrentCell = dgRow.Cells[colCardType.Name];
                                return false;
                            }
                        }
                    }
                }
                var grpResult = (from sp in entLaundryPayment
                                 where (sp.InstrumentNo ?? string.Empty) != string.Empty
                                 group sp by new
                                 {
                                     sp.FK_MVInstrumentTypeID,
                                     sp.InstrumentNo
                                 } into result
                                 select new
                                 {
                                     result.Key.FK_MVInstrumentTypeID,
                                     result.Key.InstrumentNo,
                                     result.ToList().Count
                                 }).ToList();
                var Result2 = grpResult.Where(x => x.Count > 1).FirstOrDefault();
                if (Result2 != null)
                {
                    atMessageBox.Show(MessageKeys.MsgInstrumentNumber + " " + Result2.InstrumentNo + " " + MessageKeys.MsgCannotBeDuplicated);
                    return false;
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Events
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                OKClick();
                if (!ValidatePayment()) { return; }
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void OKClick()
        {
            try
            {
                dgPayment.EndEdit();
                foreach (LaundryPayment LaundryPay in entLaundryPayment)
                {
                    if (LaundryPay.FK_MVInstrumentTypeID == 0)
                    {
                        LaundryPay.isCash = true;
                        LaundryPay.FK_MVInstrumentTypeID = null;
                    }
                    else
                    {
                        LaundryPay.isCash = false;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Event
        private void dgPayment_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgPayment.CurrentCell.Tag.ToString2() == dgPayment.CurrentCell.Value.ToString2()) { return; }
                if (dgPayment.CurrentCell.OwningColumn.Name == colAmount.Name)
                {
                    CalcTotals();
                }
                else if (dgPayment.CurrentCell.OwningColumn.Name == colMode.Name)
                {
                    DataGridViewComboBoxCell cb = (DataGridViewComboBoxCell)dgPayment.Rows[e.RowIndex].Cells[colMode.Name];
                    LaundryPayment pPayment = (LaundryPayment)dgPayment.CurrentRow.DataBoundItem;
                    if (pPayment != null)
                    {
                        if (pPayment.FK_MVInstrumentTypeID != null)
                        {
                            switch (pPayment.FK_MVInstrumentTypeID.ToInt32())
                            {
                                case 0: //Cash
                                    if (GlobalProperties.CashAccountID > 0) pPayment.FK_AccountID = GlobalProperties.CashAccountID;
                                    break;
                                case (int)ENMVInstrumentType.CreditCard:
                                    if (GlobalProperties.CreditCardAccountID > 0)
                                    { pPayment.FK_AccountID = GlobalProperties.CreditCardAccountID; 
                                        if(DefaultCreditCard > 0) pPayment.FK_MVCardType = DefaultCreditCard;
                                        if(DefaultCreditCardNumber != "") pPayment.InstrumentNo = DefaultCreditCardNumber; };
                                    break;
                                case (int)ENMVInstrumentType.Cheque:
                                    if (GlobalProperties.ChequeAccountID > 0) pPayment.FK_AccountID = GlobalProperties.ChequeAccountID;
                                    break;
                                case (int)ENMVInstrumentType.DD:
                                    if (GlobalProperties.DDAccountID > 0) pPayment.FK_AccountID = GlobalProperties.DDAccountID;
                                    break;
                                case (int)ENMVInstrumentType.OnlineBanking:
                                    if (GlobalProperties.OnlineBankingAccountID > 0) pPayment.FK_AccountID = GlobalProperties.OnlineBankingAccountID;
                                    break;
                                case (int)ENMVInstrumentType.EWallet:
                                    if (GlobalProperties.EWalletAccountID > 0) pPayment.FK_AccountID = GlobalProperties.EWalletAccountID;
                                    break;
                            }
                            if (pPayment.FK_MVInstrumentTypeID != (int)ENMVInstrumentType.CreditCard)
                            {
                                pPayment.FK_MVCardType = null;
                            }
                        }
                        if (pPayment.InstrumentDate == null)
                        {
                            pPayment.InstrumentDate = DateTime.Now.Date;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgPayment_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
        private void dgPayment_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            try
            {
                if (dgPayment.CurrentRow.DataBoundItem == null) { return; }
                LaundryPayment _Payment = (LaundryPayment)dgPayment.CurrentRow.DataBoundItem;
                if (dgPayment.CurrentCell.OwningColumn.Name == colCardType.Name)
                {
                    if (_Payment.FK_MVInstrumentTypeID != (int)ENMVInstrumentType.CreditCard)
                    {
                        e.Cancel = true;
                    }
                }
                if (dgPayment.CurrentCell.OwningColumn.Name == colInstrumentDate.Name)
                {
                    if (_Payment.FK_MVInstrumentTypeID != (int)ENMVInstrumentType.Cheque)
                    {
                        e.Cancel = true;
                    }
                }
                if (dgPayment.CurrentCell.OwningColumn.Name == colInstrumentNo.Name)
                {
                    if (_Payment.FK_MVInstrumentTypeID == 0)
                    {
                        e.Cancel = true;
                    }
                }
                dgPayment.CurrentCell.Tag = dgPayment.CurrentCell.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgPayment_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            try
            {
                if (dgPayment.CurrentCell.OwningColumn.Name == colAmount.Name)
                {
                    decimal dcmPayments = 0;
                    foreach (DataGridViewRow dgRow in dgPayment.Rows)
                    {
                        if (dgRow.Cells[colMode.Name].Value != null)
                        {
                            if (dgRow.Index != dgPayment.CurrentRow.Index && dgRow.Cells[colAmount.Name].Value != null)
                            {
                                dcmPayments += dgRow.Cells[colAmount.Name].Value.ToString().ToDecimal();
                            }
                        }
                    }
                    decimal dcmNetPayment = dcmPayments + e.FormattedValue.ToString().ToDecimal();
                    if (dcmNetPayment > dcmGrandAmount)
                    {
                        dgPayment.CurrentRow.ErrorText = MessageKeys.MsgPaymentCannotBeGreaterThanBillAmount;
                        e.Cancel = true;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgPayment_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            try
            {
                CalcTotals();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void dgPayment_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (e.Control is DataGridViewTextBoxEditingControl)
                {
                    DataGridViewTextBoxEditingControl textbox = (DataGridViewTextBoxEditingControl)e.Control;
                    if (textbox != null)
                    {
                        textbox.KeyPress += new KeyPressEventHandler(textbox_KeyPress);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        void textbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (dgPayment.CurrentCell.OwningColumn.Name == colAmount.Name)
                {
                    GlobalFunctions.AllowNumericCharOnly(sender, e);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                OKClick();
                this.Close();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                btnClose.ForeColor = Color.White;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                btnClose.ForeColor = Color.DarkGray;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
