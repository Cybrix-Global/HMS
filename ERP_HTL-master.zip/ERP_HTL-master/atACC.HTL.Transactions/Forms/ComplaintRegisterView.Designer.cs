﻿namespace atACC.HTL.Transactions
{
    partial class ComplaintRegisterView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ComplaintRegisterView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.btnNewServiceMan = new atACCFramework.UserControls.atButton();
            this.btnNewReceptionist = new atACCFramework.UserControls.atButton();
            this.lblCancelStatus = new System.Windows.Forms.Label();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.lblActionTaken = new atACCFramework.UserControls.atLabel();
            this.lblCompleted = new atACCFramework.UserControls.atLabel();
            this.lblAssignedTo = new atACCFramework.UserControls.atLabel();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.lblRegisteredEmployee = new atACCFramework.UserControls.atLabel();
            this.lblDescription = new atACCFramework.UserControls.atLabel();
            this.lblComplaint = new atACCFramework.UserControls.atLabel();
            this.lblType = new atACCFramework.UserControls.atLabel();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.lblExpectedResolvingDate = new atACCFramework.UserControls.atLabel();
            this.dtExpectedResolvingDate = new atACCFramework.UserControls.atDateTimePicker();
            this.cmbRegisteredEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.txtDescription = new atACCFramework.UserControls.TextBoxExt();
            this.txtComplaint = new atACCFramework.UserControls.TextBoxExt();
            this.cmbComplaintType = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbRoom = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbGuest = new atACCFramework.UserControls.ComboBoxExt();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.txtActionTaken = new atACCFramework.UserControls.TextBoxExt();
            this.dtCompletedDate = new atACCFramework.UserControls.atDateTimePicker();
            this.cmbAssignedTo = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbStatus = new atACCFramework.UserControls.ComboBoxExt();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.lblMandatory7 = new System.Windows.Forms.Label();
            this.lblMandatory6 = new System.Windows.Forms.Label();
            this.lblMandatory8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.btnNewServiceMan);
            this.pnlMain.Controls.Add(this.btnNewReceptionist);
            this.pnlMain.Controls.Add(this.lblCancelStatus);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.lblActionTaken);
            this.pnlMain.Controls.Add(this.lblCompleted);
            this.pnlMain.Controls.Add(this.lblAssignedTo);
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.lblRegisteredEmployee);
            this.pnlMain.Controls.Add(this.lblDescription);
            this.pnlMain.Controls.Add(this.lblComplaint);
            this.pnlMain.Controls.Add(this.lblType);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Controls.Add(this.lblExpectedResolvingDate);
            this.pnlMain.Controls.Add(this.dtExpectedResolvingDate);
            this.pnlMain.Controls.Add(this.cmbRegisteredEmployee);
            this.pnlMain.Controls.Add(this.txtDescription);
            this.pnlMain.Controls.Add(this.txtComplaint);
            this.pnlMain.Controls.Add(this.cmbComplaintType);
            this.pnlMain.Controls.Add(this.cmbRoom);
            this.pnlMain.Controls.Add(this.cmbGuest);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.txtActionTaken);
            this.pnlMain.Controls.Add(this.dtCompletedDate);
            this.pnlMain.Controls.Add(this.cmbAssignedTo);
            this.pnlMain.Controls.Add(this.cmbStatus);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblMandatory5);
            this.pnlMain.Controls.Add(this.lblMandatory7);
            this.pnlMain.Controls.Add(this.lblMandatory6);
            this.pnlMain.Controls.Add(this.lblMandatory8);
            this.pnlMain.Name = "pnlMain";
            // 
            // btnNewServiceMan
            // 
            resources.ApplyResources(this.btnNewServiceMan, "btnNewServiceMan");
            this.btnNewServiceMan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewServiceMan.FlatAppearance.BorderSize = 0;
            this.btnNewServiceMan.ForeColor = System.Drawing.Color.White;
            this.btnNewServiceMan.Name = "btnNewServiceMan";
            this.btnNewServiceMan.TabStop = false;
            this.btnNewServiceMan.UseVisualStyleBackColor = false;
            this.btnNewServiceMan.Click += new System.EventHandler(this.btnNewServiceMan_Click);
            // 
            // btnNewReceptionist
            // 
            resources.ApplyResources(this.btnNewReceptionist, "btnNewReceptionist");
            this.btnNewReceptionist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewReceptionist.FlatAppearance.BorderSize = 0;
            this.btnNewReceptionist.ForeColor = System.Drawing.Color.White;
            this.btnNewReceptionist.Name = "btnNewReceptionist";
            this.btnNewReceptionist.TabStop = false;
            this.btnNewReceptionist.UseVisualStyleBackColor = false;
            this.btnNewReceptionist.Click += new System.EventHandler(this.btnNewReceptionist_Click);
            // 
            // lblCancelStatus
            // 
            resources.ApplyResources(this.lblCancelStatus, "lblCancelStatus");
            this.lblCancelStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblCancelStatus.ForeColor = System.Drawing.Color.Crimson;
            this.lblCancelStatus.Name = "lblCancelStatus";
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // lblActionTaken
            // 
            resources.ApplyResources(this.lblActionTaken, "lblActionTaken");
            this.lblActionTaken.Name = "lblActionTaken";
            this.lblActionTaken.RequiredField = false;
            // 
            // lblCompleted
            // 
            resources.ApplyResources(this.lblCompleted, "lblCompleted");
            this.lblCompleted.Name = "lblCompleted";
            this.lblCompleted.RequiredField = false;
            // 
            // lblAssignedTo
            // 
            resources.ApplyResources(this.lblAssignedTo, "lblAssignedTo");
            this.lblAssignedTo.Name = "lblAssignedTo";
            this.lblAssignedTo.RequiredField = false;
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            // 
            // lblRegisteredEmployee
            // 
            resources.ApplyResources(this.lblRegisteredEmployee, "lblRegisteredEmployee");
            this.lblRegisteredEmployee.Name = "lblRegisteredEmployee";
            this.lblRegisteredEmployee.RequiredField = false;
            // 
            // lblDescription
            // 
            resources.ApplyResources(this.lblDescription, "lblDescription");
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.RequiredField = false;
            // 
            // lblComplaint
            // 
            resources.ApplyResources(this.lblComplaint, "lblComplaint");
            this.lblComplaint.Name = "lblComplaint";
            this.lblComplaint.RequiredField = false;
            // 
            // lblType
            // 
            resources.ApplyResources(this.lblType, "lblType");
            this.lblType.Name = "lblType";
            this.lblType.RequiredField = false;
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // lblExpectedResolvingDate
            // 
            resources.ApplyResources(this.lblExpectedResolvingDate, "lblExpectedResolvingDate");
            this.lblExpectedResolvingDate.Name = "lblExpectedResolvingDate";
            this.lblExpectedResolvingDate.RequiredField = false;
            // 
            // dtExpectedResolvingDate
            // 
            this.dtExpectedResolvingDate.BackColor = System.Drawing.Color.Transparent;
            this.dtExpectedResolvingDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtExpectedResolvingDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtExpectedResolvingDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtExpectedResolvingDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtExpectedResolvingDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtExpectedResolvingDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtExpectedResolvingDate.Checked = true;
            resources.ApplyResources(this.dtExpectedResolvingDate, "dtExpectedResolvingDate");
            this.dtExpectedResolvingDate.DisbaleDateTimeFormat = false;
            this.dtExpectedResolvingDate.DisbaleShortDateTimeFormat = false;
            this.dtExpectedResolvingDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtExpectedResolvingDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtExpectedResolvingDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtExpectedResolvingDate.Name = "dtExpectedResolvingDate";
            this.dtExpectedResolvingDate.Value = new System.DateTime(2021, 5, 18, 9, 34, 52, 452);
            // 
            // cmbRegisteredEmployee
            // 
            resources.ApplyResources(this.cmbRegisteredEmployee, "cmbRegisteredEmployee");
            this.cmbRegisteredEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRegisteredEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRegisteredEmployee.DropDownHeight = 300;
            this.cmbRegisteredEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRegisteredEmployee.DropDownWidth = 210;
            this.cmbRegisteredEmployee.FormattingEnabled = true;
            this.cmbRegisteredEmployee.Name = "cmbRegisteredEmployee";
            // 
            // txtDescription
            // 
            this.txtDescription.BackColor = System.Drawing.SystemColors.Window;
            this.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDescription.Format = null;
            this.txtDescription.isAllowNegative = false;
            this.txtDescription.isAllowSpecialChar = false;
            this.txtDescription.isNumbersOnly = false;
            this.txtDescription.isNumeric = false;
            this.txtDescription.isTouchable = false;
            resources.ApplyResources(this.txtDescription, "txtDescription");
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtComplaint
            // 
            this.txtComplaint.BackColor = System.Drawing.SystemColors.Window;
            this.txtComplaint.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtComplaint.Format = null;
            this.txtComplaint.isAllowNegative = false;
            this.txtComplaint.isAllowSpecialChar = false;
            this.txtComplaint.isNumbersOnly = false;
            this.txtComplaint.isNumeric = false;
            this.txtComplaint.isTouchable = false;
            resources.ApplyResources(this.txtComplaint, "txtComplaint");
            this.txtComplaint.Name = "txtComplaint";
            this.txtComplaint.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // cmbComplaintType
            // 
            resources.ApplyResources(this.cmbComplaintType, "cmbComplaintType");
            this.cmbComplaintType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbComplaintType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbComplaintType.DropDownHeight = 300;
            this.cmbComplaintType.DropDownWidth = 210;
            this.cmbComplaintType.FormattingEnabled = true;
            this.cmbComplaintType.Name = "cmbComplaintType";
            // 
            // cmbRoom
            // 
            resources.ApplyResources(this.cmbRoom, "cmbRoom");
            this.cmbRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoom.DropDownHeight = 300;
            this.cmbRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoom.DropDownWidth = 210;
            this.cmbRoom.FormattingEnabled = true;
            this.cmbRoom.Name = "cmbRoom";
            this.cmbRoom.SelectedValueChanged += new System.EventHandler(this.cmbRoom_SelectedValueChanged);
            // 
            // cmbGuest
            // 
            resources.ApplyResources(this.cmbGuest, "cmbGuest");
            this.cmbGuest.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuest.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuest.DropDownHeight = 300;
            this.cmbGuest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGuest.DropDownWidth = 210;
            this.cmbGuest.FormattingEnabled = true;
            this.cmbGuest.Name = "cmbGuest";
            // 
            // txtRemarks
            // 
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRemarks.Format = null;
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // txtActionTaken
            // 
            this.txtActionTaken.BackColor = System.Drawing.SystemColors.Window;
            this.txtActionTaken.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtActionTaken.Format = null;
            this.txtActionTaken.isAllowNegative = false;
            this.txtActionTaken.isAllowSpecialChar = false;
            this.txtActionTaken.isNumbersOnly = false;
            this.txtActionTaken.isNumeric = false;
            this.txtActionTaken.isTouchable = false;
            resources.ApplyResources(this.txtActionTaken, "txtActionTaken");
            this.txtActionTaken.Name = "txtActionTaken";
            this.txtActionTaken.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // dtCompletedDate
            // 
            this.dtCompletedDate.BackColor = System.Drawing.Color.Transparent;
            this.dtCompletedDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtCompletedDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtCompletedDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtCompletedDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtCompletedDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtCompletedDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtCompletedDate.Checked = true;
            resources.ApplyResources(this.dtCompletedDate, "dtCompletedDate");
            this.dtCompletedDate.DisbaleDateTimeFormat = false;
            this.dtCompletedDate.DisbaleShortDateTimeFormat = false;
            this.dtCompletedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtCompletedDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtCompletedDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtCompletedDate.Name = "dtCompletedDate";
            this.dtCompletedDate.Value = new System.DateTime(2021, 5, 18, 9, 34, 52, 452);
            // 
            // cmbAssignedTo
            // 
            resources.ApplyResources(this.cmbAssignedTo, "cmbAssignedTo");
            this.cmbAssignedTo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAssignedTo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAssignedTo.DropDownHeight = 300;
            this.cmbAssignedTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAssignedTo.DropDownWidth = 210;
            this.cmbAssignedTo.FormattingEnabled = true;
            this.cmbAssignedTo.Name = "cmbAssignedTo";
            // 
            // cmbStatus
            // 
            resources.ApplyResources(this.cmbStatus, "cmbStatus");
            this.cmbStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbStatus.DropDownHeight = 300;
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.DropDownWidth = 210;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Name = "cmbStatus";
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblMandatory5
            // 
            resources.ApplyResources(this.lblMandatory5, "lblMandatory5");
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory5.Name = "lblMandatory5";
            // 
            // lblMandatory7
            // 
            resources.ApplyResources(this.lblMandatory7, "lblMandatory7");
            this.lblMandatory7.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory7.Name = "lblMandatory7";
            // 
            // lblMandatory6
            // 
            resources.ApplyResources(this.lblMandatory6, "lblMandatory6");
            this.lblMandatory6.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory6.Name = "lblMandatory6";
            // 
            // lblMandatory8
            // 
            resources.ApplyResources(this.lblMandatory8, "lblMandatory8");
            this.lblMandatory8.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory8.Name = "lblMandatory8";
            // 
            // ComplaintRegisterView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "ComplaintRegisterView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.ComplaintRegisterView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.ComplaintRegisterView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.ComplaintRegisterView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.ComplaintRegisterView_atNewClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.ComplaintRegisterView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.ComplaintRegisterView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.ComplaintRegisterView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.ComplaintRegisterView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.ComplaintRegisterView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.ComplaintRegisterView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.ComplaintRegisterView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.ComplaintRegisterView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atPanel pnlMain;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.ComboBoxExt cmbRoom;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.atLabel lblType;
        private atACCFramework.UserControls.ComboBoxExt cmbComplaintType;
        private atACCFramework.UserControls.ComboBoxExt cmbRegisteredEmployee;
        private atACCFramework.UserControls.TextBoxExt txtDescription;
        private atACCFramework.UserControls.TextBoxExt txtComplaint;
        private atACCFramework.UserControls.atLabel lblDescription;
        private atACCFramework.UserControls.atLabel lblComplaint;
        private atACCFramework.UserControls.atLabel lblRegisteredEmployee;
        private atACCFramework.UserControls.atLabel lblExpectedResolvingDate;
        private atACCFramework.UserControls.atDateTimePicker dtExpectedResolvingDate;
        private atACCFramework.UserControls.atLabel lblStatus;
        private atACCFramework.UserControls.ComboBoxExt cmbStatus;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblActionTaken;
        private atACCFramework.UserControls.TextBoxExt txtActionTaken;
        private atACCFramework.UserControls.atLabel lblCompleted;
        private atACCFramework.UserControls.atDateTimePicker dtCompletedDate;
        private atACCFramework.UserControls.atLabel lblAssignedTo;
        private atACCFramework.UserControls.ComboBoxExt cmbAssignedTo;
        private System.Windows.Forms.Label lblCancelStatus;
        private atACCFramework.UserControls.ComboBoxExt cmbGuest;
        private atACCFramework.UserControls.atButton btnNewServiceMan;
        private atACCFramework.UserControls.atButton btnNewReceptionist;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory4;
        private System.Windows.Forms.Label lblMandatory5;
        private System.Windows.Forms.Label lblMandatory6;
        private System.Windows.Forms.Label lblMandatory7;
        private System.Windows.Forms.Label lblMandatory8;
    }
}