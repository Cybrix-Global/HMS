﻿namespace atACC.HTL.Transactions
{
    partial class RoomOutofOrderView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RoomOutofOrderView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblTo = new atACCFramework.UserControls.atLabel();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblReason = new atACCFramework.UserControls.atLabel();
            this.cmbReason = new atACCFramework.UserControls.ComboBoxExt();
            this.lblFrom = new atACCFramework.UserControls.atLabel();
            this.dtToDate = new atACCFramework.UserControls.atDateTimePicker();
            this.dtFromDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.cmbRoom = new atACCFramework.UserControls.ComboBoxExt();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.lblTo);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.lblReason);
            this.pnlMain.Controls.Add(this.cmbReason);
            this.pnlMain.Controls.Add(this.lblFrom);
            this.pnlMain.Controls.Add(this.dtToDate);
            this.pnlMain.Controls.Add(this.dtFromDate);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Controls.Add(this.cmbRoom);
            this.pnlMain.Name = "pnlMain";
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.ForeColor = System.Drawing.Color.Crimson;
            this.lblStatus.Name = "lblStatus";
            // 
            // lblTo
            // 
            resources.ApplyResources(this.lblTo, "lblTo");
            this.lblTo.Name = "lblTo";
            this.lblTo.RequiredField = false;
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // txtRemarks
            // 
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRemarks.Format = null;
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // lblReason
            // 
            resources.ApplyResources(this.lblReason, "lblReason");
            this.lblReason.Name = "lblReason";
            this.lblReason.RequiredField = false;
            // 
            // cmbReason
            // 
            resources.ApplyResources(this.cmbReason, "cmbReason");
            this.cmbReason.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbReason.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbReason.DropDownHeight = 300;
            this.cmbReason.DropDownWidth = 210;
            this.cmbReason.FormattingEnabled = true;
            this.cmbReason.Name = "cmbReason";
            // 
            // lblFrom
            // 
            resources.ApplyResources(this.lblFrom, "lblFrom");
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.RequiredField = false;
            // 
            // dtToDate
            // 
            resources.ApplyResources(this.dtToDate, "dtToDate");
            this.dtToDate.BackColor = System.Drawing.Color.Transparent;
            this.dtToDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtToDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtToDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtToDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtToDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtToDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtToDate.Checked = true;
            this.dtToDate.DisbaleDateTimeFormat = false;
            this.dtToDate.DisbaleShortDateTimeFormat = false;
            this.dtToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtToDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtToDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtToDate.Name = "dtToDate";
            this.dtToDate.TabStop = false;
            this.dtToDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // dtFromDate
            // 
            resources.ApplyResources(this.dtFromDate, "dtFromDate");
            this.dtFromDate.BackColor = System.Drawing.Color.Transparent;
            this.dtFromDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFromDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtFromDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtFromDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtFromDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtFromDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtFromDate.Checked = true;
            this.dtFromDate.DisbaleDateTimeFormat = false;
            this.dtFromDate.DisbaleShortDateTimeFormat = false;
            this.dtFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtFromDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtFromDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtFromDate.Name = "dtFromDate";
            this.dtFromDate.TabStop = false;
            this.dtFromDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // cmbRoom
            // 
            resources.ApplyResources(this.cmbRoom, "cmbRoom");
            this.cmbRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoom.DropDownHeight = 300;
            this.cmbRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoom.DropDownWidth = 210;
            this.cmbRoom.FormattingEnabled = true;
            this.cmbRoom.Name = "cmbRoom";
            // 
            // RoomOutofOrderView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "RoomOutofOrderView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.RoomOutofOrderView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.RoomOutofOrderView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.RoomOutofOrderView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.RoomOutofOrderView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.RoomOutofOrderView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.RoomOutofOrderView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.RoomOutofOrderView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.RoomOutofOrderView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.RoomOutofOrderView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.RoomOutofOrderView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.RoomOutofOrderView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.RoomOutofOrderView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.RoomOutofOrderView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.ComboBoxExt cmbRoom;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.atDateTimePicker dtToDate;
        private atACCFramework.UserControls.atDateTimePicker dtFromDate;
        private atACCFramework.UserControls.atLabel lblTo;
        private atACCFramework.UserControls.atLabel lblFrom;
        private atACCFramework.UserControls.atLabel lblReason;
        private atACCFramework.UserControls.ComboBoxExt cmbReason;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblStatus;
    }
}