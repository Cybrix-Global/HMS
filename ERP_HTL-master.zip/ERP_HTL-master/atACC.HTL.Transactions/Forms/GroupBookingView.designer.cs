﻿namespace atACC.HTL.Transactions
{
    partial class GroupBookingView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroupBookingView));
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblBillingAccount = new atACCFramework.UserControls.atLabel();
            this.cmbBillingAccount = new atACCFramework.UserControls.ComboBoxExt();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.cmbGuest = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.pnlGridContain = new atACCFramework.UserControls.atPanel();
            this.dgDetails = new atACCFramework.UserControls.atGridView();
            this.col_slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_RoomOrHall = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.col_RoomType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.col_Room = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Col_RateType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Col_Adult = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Child = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalBeds = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalBedRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalPersons = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AdditionalPersonRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTotalAmount = new atACCFramework.UserControls.atNumericLabel();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.txtChilds = new atACCFramework.UserControls.atNumericLabel();
            this.atLabel5 = new atACCFramework.UserControls.atLabel();
            this.txtAdults = new atACCFramework.UserControls.atNumericLabel();
            this.atLabel4 = new atACCFramework.UserControls.atLabel();
            this.txtNetTotal = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetTotal = new atACCFramework.UserControls.atLabel();
            this.txtTotalDiscount = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotalDisc = new atACCFramework.UserControls.atLabel();
            this.lblTotalTax = new atACCFramework.UserControls.TaxLabel();
            this.btnAdvance = new atACCFramework.UserControls.atButton();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.lblComments = new atACCFramework.UserControls.atLabel();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.txtBalance = new atACCFramework.UserControls.TextBoxNormal();
            this.txtAdvance = new atACCFramework.UserControls.atNumericLabel();
            this.lblBalance = new atACCFramework.UserControls.atLabel();
            this.txtTotalTax = new atACCFramework.UserControls.atNumericLabel();
            this.btnSeperator1 = new System.Windows.Forms.Button();
            this.bindGroupBookingDTL = new System.Windows.Forms.BindingSource(this.components);
            this.txtGrandTotal = new atACCFramework.UserControls.atNumericLabel();
            this.atlblTot = new atACCFramework.UserControls.atLabel();
            this.btnNewGuest = new atACCFramework.UserControls.atButton();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.btnNewGuestType = new atACCFramework.UserControls.atButton();
            this.btnNewSource = new atACCFramework.UserControls.atButton();
            this.btnNewType = new atACCFramework.UserControls.atButton();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblSource = new atACCFramework.UserControls.atLabel();
            this.cmbSource = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbAgent = new atACCFramework.UserControls.ComboBoxExt();
            this.lblAgent = new atACCFramework.UserControls.atLabel();
            this.lblGuestType = new atACCFramework.UserControls.atLabel();
            this.cmbGuestType = new atACCFramework.UserControls.ComboBoxExt();
            this.txtNoOfHalls = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel2 = new atACCFramework.UserControls.atLabel();
            this.txtNoOfRooms = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.txtNoOfDays = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfDays = new atACCFramework.UserControls.atLabel();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.lblType = new atACCFramework.UserControls.atLabel();
            this.cmbType = new atACCFramework.UserControls.ComboBoxExt();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.btnAllocate = new atACCFramework.UserControls.atButton();
            this.lblCurrencyCap = new atACCFramework.UserControls.atLabel();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.txtExRate = new atACCFramework.UserControls.TextBoxExt();
            this.cmbCurrency = new atACCFramework.UserControls.ComboBoxExt();
            this.lblExRateCap = new atACCFramework.UserControls.atLabel();
            this.lblMandatory6 = new System.Windows.Forms.Label();
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.lblAdvance = new atACCFramework.UserControls.atLabel();
            this.lblCancelStatus = new System.Windows.Forms.Label();
            this.btnCheckIn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlHeader2.SuspendLayout();
            this.pnlGridContain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindGroupBookingDTL)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.pnlFooter.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnAdvance);
            this.panel1.Controls.Add(this.txtGrandTotal);
            this.panel1.Controls.Add(this.atlblTot);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.SetChildIndex(this.atlblTot, 0);
            this.panel1.Controls.SetChildIndex(this.txtGrandTotal, 0);
            this.panel1.Controls.SetChildIndex(this.btnAdvance, 0);
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblBillingAccount
            // 
            resources.ApplyResources(this.lblBillingAccount, "lblBillingAccount");
            this.lblBillingAccount.Name = "lblBillingAccount";
            this.lblBillingAccount.RequiredField = false;
            // 
            // cmbBillingAccount
            // 
            this.cmbBillingAccount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBillingAccount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBillingAccount.DropDownHeight = 300;
            this.cmbBillingAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbBillingAccount, "cmbBillingAccount");
            this.cmbBillingAccount.FormattingEnabled = true;
            this.cmbBillingAccount.Name = "cmbBillingAccount";
            // 
            // txtTelephone
            // 
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.Format = null;
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = true;
            this.txtTelephone.isNumeric = false;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.TabStop = false;
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTelephone
            // 
            resources.ApplyResources(this.lblTelephone, "lblTelephone");
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            // 
            // cmbGuest
            // 
            this.cmbGuest.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuest.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuest.DropDownHeight = 300;
            this.cmbGuest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuest, "cmbGuest");
            this.cmbGuest.FormattingEnabled = true;
            this.cmbGuest.Name = "cmbGuest";
            this.cmbGuest.SelectedValueChanged += new System.EventHandler(this.cmbGuest_SelectedValueChanged);
            this.cmbGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbGuest_KeyPress);
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // pnlGridContain
            // 
            resources.ApplyResources(this.pnlGridContain, "pnlGridContain");
            this.pnlGridContain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlGridContain.Controls.Add(this.dgDetails);
            this.pnlGridContain.Name = "pnlGridContain";
            // 
            // dgDetails
            // 
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle27;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_slno,
            this.col_RoomOrHall,
            this.col_RoomType,
            this.col_Room,
            this.Col_RateType,
            this.Col_Adult,
            this.Col_Child,
            this.col_Rate,
            this.col_AdditionalBeds,
            this.col_AdditionalBedRate,
            this.col_AdditionalPersons,
            this.col_AdditionalPersonRate,
            this.col_DeductionPerc,
            this.col_DeductionAmount});
            this.dgDetails.EnableHeadersVisualStyles = false;
            this.dgDetails.EnterKeyNavigation = false;
            this.dgDetails.LastKey = System.Windows.Forms.Keys.None;
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle39.NullValue = null;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle39;
            this.dgDetails.sGridID = null;
            this.dgDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgDetails_CellBeginEdit);
            this.dgDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEndEdit);
            this.dgDetails.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgDetails_CellValidating);
            this.dgDetails.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellValueChanged);
            this.dgDetails.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgDetails_DataError);
            this.dgDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgDetails_EditingControlShowing);
            this.dgDetails.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgDetails_RowsAdded);
            this.dgDetails.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgDetails_RowsRemoved);
            // 
            // col_slno
            // 
            this.col_slno.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_slno.FillWeight = 111.905F;
            resources.ApplyResources(this.col_slno, "col_slno");
            this.col_slno.Name = "col_slno";
            this.col_slno.ReadOnly = true;
            // 
            // col_RoomOrHall
            // 
            this.col_RoomOrHall.DataPropertyName = "RoomOrHall";
            this.col_RoomOrHall.FillWeight = 80F;
            this.col_RoomOrHall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_RoomOrHall, "col_RoomOrHall");
            this.col_RoomOrHall.Items.AddRange(new object[] {
            "Room",
            "Hall"});
            this.col_RoomOrHall.Name = "col_RoomOrHall";
            this.col_RoomOrHall.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_RoomOrHall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // col_RoomType
            // 
            this.col_RoomType.DataPropertyName = "FK_RoomTypeID";
            this.col_RoomType.FillWeight = 120F;
            this.col_RoomType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_RoomType, "col_RoomType");
            this.col_RoomType.Name = "col_RoomType";
            this.col_RoomType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // col_Room
            // 
            this.col_Room.DataPropertyName = "FK_RoomID";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.col_Room.DefaultCellStyle = dataGridViewCellStyle29;
            this.col_Room.FillWeight = 125F;
            this.col_Room.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_Room, "col_Room");
            this.col_Room.Name = "col_Room";
            this.col_Room.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Room.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Col_RateType
            // 
            this.Col_RateType.DataPropertyName = "FK_RateTypeID";
            this.Col_RateType.FillWeight = 115F;
            this.Col_RateType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.Col_RateType, "Col_RateType");
            this.Col_RateType.Name = "Col_RateType";
            this.Col_RateType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Col_RateType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Col_Adult
            // 
            this.Col_Adult.DataPropertyName = "Adult";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Col_Adult.DefaultCellStyle = dataGridViewCellStyle30;
            this.Col_Adult.FillWeight = 75F;
            resources.ApplyResources(this.Col_Adult, "Col_Adult");
            this.Col_Adult.Name = "Col_Adult";
            // 
            // Col_Child
            // 
            this.Col_Child.DataPropertyName = "Child";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Col_Child.DefaultCellStyle = dataGridViewCellStyle31;
            this.Col_Child.FillWeight = 75F;
            resources.ApplyResources(this.Col_Child, "Col_Child");
            this.Col_Child.Name = "Col_Child";
            // 
            // col_Rate
            // 
            this.col_Rate.DataPropertyName = "Rate";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Rate.DefaultCellStyle = dataGridViewCellStyle32;
            this.col_Rate.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Rate, "col_Rate");
            this.col_Rate.Name = "col_Rate";
            // 
            // col_AdditionalBeds
            // 
            this.col_AdditionalBeds.DataPropertyName = "AdditionalBeds";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_AdditionalBeds.DefaultCellStyle = dataGridViewCellStyle33;
            this.col_AdditionalBeds.FillWeight = 75F;
            resources.ApplyResources(this.col_AdditionalBeds, "col_AdditionalBeds");
            this.col_AdditionalBeds.Name = "col_AdditionalBeds";
            // 
            // col_AdditionalBedRate
            // 
            this.col_AdditionalBedRate.DataPropertyName = "AdditionalBedRate";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AdditionalBedRate.DefaultCellStyle = dataGridViewCellStyle34;
            resources.ApplyResources(this.col_AdditionalBedRate, "col_AdditionalBedRate");
            this.col_AdditionalBedRate.Name = "col_AdditionalBedRate";
            // 
            // col_AdditionalPersons
            // 
            this.col_AdditionalPersons.DataPropertyName = "AdditionalPersons";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_AdditionalPersons.DefaultCellStyle = dataGridViewCellStyle35;
            this.col_AdditionalPersons.FillWeight = 75F;
            resources.ApplyResources(this.col_AdditionalPersons, "col_AdditionalPersons");
            this.col_AdditionalPersons.Name = "col_AdditionalPersons";
            // 
            // col_AdditionalPersonRate
            // 
            this.col_AdditionalPersonRate.DataPropertyName = "AdditionalPersonRate";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AdditionalPersonRate.DefaultCellStyle = dataGridViewCellStyle36;
            resources.ApplyResources(this.col_AdditionalPersonRate, "col_AdditionalPersonRate");
            this.col_AdditionalPersonRate.Name = "col_AdditionalPersonRate";
            // 
            // col_DeductionPerc
            // 
            this.col_DeductionPerc.DataPropertyName = "DeductionPerc";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionPerc.DefaultCellStyle = dataGridViewCellStyle37;
            resources.ApplyResources(this.col_DeductionPerc, "col_DeductionPerc");
            this.col_DeductionPerc.Name = "col_DeductionPerc";
            // 
            // col_DeductionAmount
            // 
            this.col_DeductionAmount.DataPropertyName = "DeductionAmount";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionAmount.DefaultCellStyle = dataGridViewCellStyle38;
            resources.ApplyResources(this.col_DeductionAmount, "col_DeductionAmount");
            this.col_DeductionAmount.Name = "col_DeductionAmount";
            // 
            // txtTotalAmount
            // 
            resources.ApplyResources(this.txtTotalAmount, "txtTotalAmount");
            this.txtTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalAmount.Format = "N2";
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.RequiredField = false;
            this.txtTotalAmount.UseCompatibleTextRendering = true;
            this.txtTotalAmount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.errProvider.SetIconAlignment(this.atLabel3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel3.IconAlignment"))));
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // txtChilds
            // 
            resources.ApplyResources(this.txtChilds, "txtChilds");
            this.txtChilds.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtChilds.ForeColor = System.Drawing.Color.Black;
            this.txtChilds.Format = "N2";
            this.txtChilds.Name = "txtChilds";
            this.txtChilds.RequiredField = false;
            this.txtChilds.UseCompatibleTextRendering = true;
            this.txtChilds.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atLabel5
            // 
            resources.ApplyResources(this.atLabel5, "atLabel5");
            this.errProvider.SetIconAlignment(this.atLabel5, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel5.IconAlignment"))));
            this.atLabel5.Name = "atLabel5";
            this.atLabel5.RequiredField = false;
            // 
            // txtAdults
            // 
            resources.ApplyResources(this.txtAdults, "txtAdults");
            this.txtAdults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdults.ForeColor = System.Drawing.Color.Black;
            this.txtAdults.Format = "N2";
            this.txtAdults.Name = "txtAdults";
            this.txtAdults.RequiredField = false;
            this.txtAdults.UseCompatibleTextRendering = true;
            this.txtAdults.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atLabel4
            // 
            resources.ApplyResources(this.atLabel4, "atLabel4");
            this.errProvider.SetIconAlignment(this.atLabel4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel4.IconAlignment"))));
            this.atLabel4.Name = "atLabel4";
            this.atLabel4.RequiredField = false;
            // 
            // txtNetTotal
            // 
            resources.ApplyResources(this.txtNetTotal, "txtNetTotal");
            this.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNetTotal.ForeColor = System.Drawing.Color.Black;
            this.txtNetTotal.Format = "N2";
            this.txtNetTotal.Name = "txtNetTotal";
            this.txtNetTotal.RequiredField = false;
            this.txtNetTotal.UseCompatibleTextRendering = true;
            this.txtNetTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetTotal
            // 
            resources.ApplyResources(this.lblNetTotal, "lblNetTotal");
            this.errProvider.SetIconAlignment(this.lblNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNetTotal.IconAlignment"))));
            this.lblNetTotal.Name = "lblNetTotal";
            this.lblNetTotal.RequiredField = false;
            // 
            // txtTotalDiscount
            // 
            resources.ApplyResources(this.txtTotalDiscount, "txtTotalDiscount");
            this.txtTotalDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalDiscount.Format = "N2";
            this.txtTotalDiscount.Name = "txtTotalDiscount";
            this.txtTotalDiscount.RequiredField = false;
            this.txtTotalDiscount.UseCompatibleTextRendering = true;
            this.txtTotalDiscount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotalDisc
            // 
            resources.ApplyResources(this.lblTotalDisc, "lblTotalDisc");
            this.errProvider.SetIconAlignment(this.lblTotalDisc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalDisc.IconAlignment"))));
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.RequiredField = false;
            // 
            // lblTotalTax
            // 
            resources.ApplyResources(this.lblTotalTax, "lblTotalTax");
            this.lblTotalTax.DisabledLinkColor = System.Drawing.Color.Red;
            this.lblTotalTax.Format = null;
            this.lblTotalTax.lblAddnlTax = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblCGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblExciseDuty = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblIGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblSGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax1 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax2 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax3 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblVAT = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblTotalTax.LinkColor = System.Drawing.Color.Black;
            this.lblTotalTax.Name = "lblTotalTax";
            this.lblTotalTax.TabStop = true;
            this.lblTotalTax.VisitedLinkColor = System.Drawing.Color.Blue;
            // 
            // btnAdvance
            // 
            resources.ApplyResources(this.btnAdvance, "btnAdvance");
            this.btnAdvance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnAdvance.FlatAppearance.BorderSize = 0;
            this.btnAdvance.ForeColor = System.Drawing.Color.White;
            this.btnAdvance.Name = "btnAdvance";
            this.btnAdvance.TabStop = false;
            this.btnAdvance.UseVisualStyleBackColor = false;
            this.btnAdvance.Click += new System.EventHandler(this.btnAdvance_Click);
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblComments
            // 
            resources.ApplyResources(this.lblComments, "lblComments");
            this.errProvider.SetIconAlignment(this.lblComments, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblComments.IconAlignment"))));
            this.lblComments.Name = "lblComments";
            this.lblComments.RequiredField = false;
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // cmbEmployee
            // 
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // txtBalance
            // 
            resources.ApplyResources(this.txtBalance, "txtBalance");
            this.txtBalance.BackColor = System.Drawing.SystemColors.Window;
            this.txtBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBalance.Format = null;
            this.txtBalance.isAllowNegative = true;
            this.txtBalance.isAllowSpecialChar = false;
            this.txtBalance.isNumeric = true;
            this.txtBalance.isTouchable = false;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            // 
            // txtAdvance
            // 
            resources.ApplyResources(this.txtAdvance, "txtAdvance");
            this.txtAdvance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdvance.ForeColor = System.Drawing.Color.Black;
            this.txtAdvance.Format = "N2";
            this.txtAdvance.Name = "txtAdvance";
            this.txtAdvance.RequiredField = false;
            this.txtAdvance.UseCompatibleTextRendering = true;
            this.txtAdvance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBalance
            // 
            resources.ApplyResources(this.lblBalance, "lblBalance");
            this.errProvider.SetIconAlignment(this.lblBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblBalance.IconAlignment"))));
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.RequiredField = false;
            // 
            // txtTotalTax
            // 
            resources.ApplyResources(this.txtTotalTax, "txtTotalTax");
            this.txtTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalTax.ForeColor = System.Drawing.Color.Black;
            this.txtTotalTax.Format = "N2";
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.RequiredField = false;
            this.txtTotalTax.UseCompatibleTextRendering = true;
            this.txtTotalTax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator1
            // 
            resources.ApplyResources(this.btnSeperator1, "btnSeperator1");
            this.btnSeperator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator1.Name = "btnSeperator1";
            this.btnSeperator1.UseVisualStyleBackColor = true;
            // 
            // txtGrandTotal
            // 
            resources.ApplyResources(this.txtGrandTotal, "txtGrandTotal");
            this.txtGrandTotal.BackColor = System.Drawing.SystemColors.Window;
            this.txtGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGrandTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.txtGrandTotal.Format = "N2";
            this.txtGrandTotal.Name = "txtGrandTotal";
            this.txtGrandTotal.RequiredField = false;
            this.txtGrandTotal.UseCompatibleTextRendering = true;
            this.txtGrandTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atlblTot
            // 
            resources.ApplyResources(this.atlblTot, "atlblTot");
            this.atlblTot.BackColor = System.Drawing.Color.Transparent;
            this.atlblTot.Name = "atlblTot";
            this.atlblTot.RequiredField = false;
            // 
            // btnNewGuest
            // 
            this.btnNewGuest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewGuest.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewGuest, "btnNewGuest");
            this.btnNewGuest.ForeColor = System.Drawing.Color.White;
            this.btnNewGuest.Name = "btnNewGuest";
            this.btnNewGuest.TabStop = false;
            this.btnNewGuest.Tag = "";
            this.btnNewGuest.UseVisualStyleBackColor = false;
            this.btnNewGuest.Click += new System.EventHandler(this.btnNewGuest_Click);
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // txtAdd1
            // 
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.Format = null;
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.TabStop = false;
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtMobile
            // 
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.Format = null;
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = true;
            this.txtMobile.isNumeric = false;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.TabStop = false;
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // btnNewGuestType
            // 
            this.btnNewGuestType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewGuestType.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewGuestType, "btnNewGuestType");
            this.btnNewGuestType.ForeColor = System.Drawing.Color.White;
            this.btnNewGuestType.Name = "btnNewGuestType";
            this.btnNewGuestType.TabStop = false;
            this.btnNewGuestType.Tag = "";
            this.btnNewGuestType.UseVisualStyleBackColor = false;
            this.btnNewGuestType.Click += new System.EventHandler(this.btnNewGuestType_Click);
            // 
            // btnNewSource
            // 
            this.btnNewSource.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewSource.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewSource, "btnNewSource");
            this.btnNewSource.ForeColor = System.Drawing.Color.White;
            this.btnNewSource.Name = "btnNewSource";
            this.btnNewSource.TabStop = false;
            this.btnNewSource.Tag = "";
            this.btnNewSource.UseVisualStyleBackColor = false;
            this.btnNewSource.Click += new System.EventHandler(this.btnNewSource_Click);
            // 
            // btnNewType
            // 
            this.btnNewType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewType.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewType, "btnNewType");
            this.btnNewType.ForeColor = System.Drawing.Color.White;
            this.btnNewType.Name = "btnNewType";
            this.btnNewType.TabStop = false;
            this.btnNewType.Tag = "";
            this.btnNewType.UseVisualStyleBackColor = false;
            this.btnNewType.Click += new System.EventHandler(this.btnNewType_Click);
            // 
            // dtpDepartureDate
            // 
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpDepartureDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // dtpArrivalDate
            // 
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            this.dtpArrivalDate.ValueChanged += new System.EventHandler(this.dtpArrivalDate_ValueChanged);
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblSource
            // 
            resources.ApplyResources(this.lblSource, "lblSource");
            this.lblSource.Name = "lblSource";
            this.lblSource.RequiredField = false;
            // 
            // cmbSource
            // 
            this.cmbSource.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSource.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSource.DropDownHeight = 300;
            this.cmbSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbSource, "cmbSource");
            this.cmbSource.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbSource, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbSource.IconAlignment"))));
            this.cmbSource.Name = "cmbSource";
            // 
            // cmbAgent
            // 
            resources.ApplyResources(this.cmbAgent, "cmbAgent");
            this.cmbAgent.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAgent.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAgent.DropDownHeight = 300;
            this.cmbAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAgent.FormattingEnabled = true;
            this.cmbAgent.Name = "cmbAgent";
            // 
            // lblAgent
            // 
            resources.ApplyResources(this.lblAgent, "lblAgent");
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.RequiredField = false;
            // 
            // lblGuestType
            // 
            resources.ApplyResources(this.lblGuestType, "lblGuestType");
            this.lblGuestType.Name = "lblGuestType";
            this.lblGuestType.RequiredField = false;
            // 
            // cmbGuestType
            // 
            this.cmbGuestType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuestType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuestType.DropDownHeight = 300;
            this.cmbGuestType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuestType, "cmbGuestType");
            this.cmbGuestType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGuestType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGuestType.IconAlignment"))));
            this.cmbGuestType.Name = "cmbGuestType";
            // 
            // txtNoOfHalls
            // 
            resources.ApplyResources(this.txtNoOfHalls, "txtNoOfHalls");
            this.txtNoOfHalls.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfHalls.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfHalls.Format = null;
            this.errProvider.SetIconAlignment(this.txtNoOfHalls, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNoOfHalls.IconAlignment"))));
            this.txtNoOfHalls.isAllowNegative = false;
            this.txtNoOfHalls.isAllowSpecialChar = false;
            this.txtNoOfHalls.isNumbersOnly = true;
            this.txtNoOfHalls.isNumeric = false;
            this.txtNoOfHalls.isTouchable = false;
            this.txtNoOfHalls.Name = "txtNoOfHalls";
            this.txtNoOfHalls.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atLabel2
            // 
            resources.ApplyResources(this.atLabel2, "atLabel2");
            this.errProvider.SetIconAlignment(this.atLabel2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel2.IconAlignment"))));
            this.atLabel2.Name = "atLabel2";
            this.atLabel2.RequiredField = false;
            // 
            // txtNoOfRooms
            // 
            resources.ApplyResources(this.txtNoOfRooms, "txtNoOfRooms");
            this.txtNoOfRooms.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfRooms.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfRooms.Format = null;
            this.errProvider.SetIconAlignment(this.txtNoOfRooms, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNoOfRooms.IconAlignment"))));
            this.txtNoOfRooms.isAllowNegative = false;
            this.txtNoOfRooms.isAllowSpecialChar = false;
            this.txtNoOfRooms.isNumbersOnly = true;
            this.txtNoOfRooms.isNumeric = false;
            this.txtNoOfRooms.isTouchable = false;
            this.txtNoOfRooms.Name = "txtNoOfRooms";
            this.txtNoOfRooms.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atLabel1
            // 
            resources.ApplyResources(this.atLabel1, "atLabel1");
            this.errProvider.SetIconAlignment(this.atLabel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel1.IconAlignment"))));
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            // 
            // txtNoOfDays
            // 
            resources.ApplyResources(this.txtNoOfDays, "txtNoOfDays");
            this.txtNoOfDays.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoOfDays.Format = null;
            this.errProvider.SetIconAlignment(this.txtNoOfDays, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNoOfDays.IconAlignment"))));
            this.txtNoOfDays.isAllowNegative = false;
            this.txtNoOfDays.isAllowSpecialChar = false;
            this.txtNoOfDays.isNumbersOnly = true;
            this.txtNoOfDays.isNumeric = false;
            this.txtNoOfDays.isTouchable = false;
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.ReadOnly = true;
            this.txtNoOfDays.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNoOfDays
            // 
            resources.ApplyResources(this.lblNoOfDays, "lblNoOfDays");
            this.errProvider.SetIconAlignment(this.lblNoOfDays, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNoOfDays.IconAlignment"))));
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.RequiredField = false;
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // lblType
            // 
            resources.ApplyResources(this.lblType, "lblType");
            this.lblType.Name = "lblType";
            this.lblType.RequiredField = false;
            // 
            // cmbType
            // 
            this.cmbType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbType.DropDownHeight = 300;
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbType, "cmbType");
            this.cmbType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbType.IconAlignment"))));
            this.cmbType.Name = "cmbType";
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.btnCheckIn);
            this.pnlMain.Controls.Add(this.btnAllocate);
            this.pnlMain.Controls.Add(this.lblCurrencyCap);
            this.pnlMain.Controls.Add(this.lblMandatory5);
            this.pnlMain.Controls.Add(this.txtExRate);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.cmbCurrency);
            this.pnlMain.Controls.Add(this.btnNewGuestType);
            this.pnlMain.Controls.Add(this.lblExRateCap);
            this.pnlMain.Controls.Add(this.lblComments);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblEmployee);
            this.pnlMain.Controls.Add(this.btnNewSource);
            this.pnlMain.Controls.Add(this.cmbEmployee);
            this.pnlMain.Controls.Add(this.lblTelephone);
            this.pnlMain.Controls.Add(this.lblSource);
            this.pnlMain.Controls.Add(this.cmbSource);
            this.pnlMain.Controls.Add(this.cmbAgent);
            this.pnlMain.Controls.Add(this.dtpDepartureDate);
            this.pnlMain.Controls.Add(this.lblAgent);
            this.pnlMain.Controls.Add(this.lblGuestType);
            this.pnlMain.Controls.Add(this.btnNewType);
            this.pnlMain.Controls.Add(this.cmbGuestType);
            this.pnlMain.Controls.Add(this.dtpArrivalDate);
            this.pnlMain.Controls.Add(this.txtMobile);
            this.pnlMain.Controls.Add(this.atLabel2);
            this.pnlMain.Controls.Add(this.txtNoOfHalls);
            this.pnlMain.Controls.Add(this.atLabel1);
            this.pnlMain.Controls.Add(this.txtTelephone);
            this.pnlMain.Controls.Add(this.txtNoOfRooms);
            this.pnlMain.Controls.Add(this.btnNewGuest);
            this.pnlMain.Controls.Add(this.lblAddress1);
            this.pnlMain.Controls.Add(this.cmbGuest);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.lblNoOfDays);
            this.pnlMain.Controls.Add(this.txtNoOfDays);
            this.pnlMain.Controls.Add(this.txtAdd1);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblDepartureDate);
            this.pnlMain.Controls.Add(this.cmbBillingAccount);
            this.pnlMain.Controls.Add(this.lblArrivalDate);
            this.pnlMain.Controls.Add(this.lblBillingAccount);
            this.pnlMain.Controls.Add(this.cmbType);
            this.pnlMain.Controls.Add(this.lblType);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblMandatory6);
            this.pnlMain.Name = "pnlMain";
            // 
            // btnAllocate
            // 
            resources.ApplyResources(this.btnAllocate, "btnAllocate");
            this.btnAllocate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnAllocate.FlatAppearance.BorderSize = 0;
            this.btnAllocate.ForeColor = System.Drawing.Color.White;
            this.btnAllocate.Name = "btnAllocate";
            this.btnAllocate.TabStop = false;
            this.btnAllocate.Tag = "";
            this.btnAllocate.UseVisualStyleBackColor = false;
            this.btnAllocate.Click += new System.EventHandler(this.btnAllocate_Click);
            // 
            // lblCurrencyCap
            // 
            resources.ApplyResources(this.lblCurrencyCap, "lblCurrencyCap");
            this.lblCurrencyCap.Name = "lblCurrencyCap";
            this.lblCurrencyCap.RequiredField = false;
            // 
            // lblMandatory5
            // 
            resources.ApplyResources(this.lblMandatory5, "lblMandatory5");
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory5.Name = "lblMandatory5";
            // 
            // txtExRate
            // 
            this.txtExRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtExRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtExRate, "txtExRate");
            this.txtExRate.Format = null;
            this.txtExRate.isAllowNegative = false;
            this.txtExRate.isAllowSpecialChar = false;
            this.txtExRate.isNumbersOnly = false;
            this.txtExRate.isNumeric = true;
            this.txtExRate.isTouchable = false;
            this.txtExRate.Name = "txtExRate";
            this.txtExRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtExRate.Enter += new System.EventHandler(this.txtExRate_Enter);
            this.txtExRate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtExRate_KeyUp);
            // 
            // cmbCurrency
            // 
            this.cmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCurrency.DropDownHeight = 300;
            this.cmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbCurrency, "cmbCurrency");
            this.cmbCurrency.FormattingEnabled = true;
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency_SelectedIndexChanged);
            // 
            // lblExRateCap
            // 
            resources.ApplyResources(this.lblExRateCap, "lblExRateCap");
            this.lblExRateCap.Name = "lblExRateCap";
            this.lblExRateCap.RequiredField = false;
            // 
            // lblMandatory6
            // 
            resources.ApplyResources(this.lblMandatory6, "lblMandatory6");
            this.lblMandatory6.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory6.Name = "lblMandatory6";
            // 
            // pnlFooter
            // 
            resources.ApplyResources(this.pnlFooter, "pnlFooter");
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.lblAdvance);
            this.pnlFooter.Controls.Add(this.lblCancelStatus);
            this.pnlFooter.Controls.Add(this.txtChilds);
            this.pnlFooter.Controls.Add(this.txtTotalAmount);
            this.pnlFooter.Controls.Add(this.atLabel5);
            this.pnlFooter.Controls.Add(this.txtNetTotal);
            this.pnlFooter.Controls.Add(this.btnSeperator1);
            this.pnlFooter.Controls.Add(this.txtAdults);
            this.pnlFooter.Controls.Add(this.atLabel4);
            this.pnlFooter.Controls.Add(this.atLabel3);
            this.pnlFooter.Controls.Add(this.lblBalance);
            this.pnlFooter.Controls.Add(this.lblTotalDisc);
            this.pnlFooter.Controls.Add(this.txtTotalDiscount);
            this.pnlFooter.Controls.Add(this.txtAdvance);
            this.pnlFooter.Controls.Add(this.txtBalance);
            this.pnlFooter.Controls.Add(this.lblNetTotal);
            this.pnlFooter.Controls.Add(this.txtTotalTax);
            this.pnlFooter.Controls.Add(this.lblTotalTax);
            this.pnlFooter.Name = "pnlFooter";
            // 
            // lblAdvance
            // 
            resources.ApplyResources(this.lblAdvance, "lblAdvance");
            this.errProvider.SetIconAlignment(this.lblAdvance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdvance.IconAlignment"))));
            this.lblAdvance.Name = "lblAdvance";
            this.lblAdvance.RequiredField = false;
            // 
            // lblCancelStatus
            // 
            resources.ApplyResources(this.lblCancelStatus, "lblCancelStatus");
            this.lblCancelStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblCancelStatus.ForeColor = System.Drawing.Color.Crimson;
            this.lblCancelStatus.Name = "lblCancelStatus";
            // 
            // btnCheckIn
            // 
            resources.ApplyResources(this.btnCheckIn, "btnCheckIn");
            this.btnCheckIn.FlatAppearance.BorderSize = 0;
            this.btnCheckIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            this.btnCheckIn.Name = "btnCheckIn";
            this.btnCheckIn.UseVisualStyleBackColor = true;
            this.btnCheckIn.Click += new System.EventHandler(this.btnCheckIn_Click);
            // 
            // GroupBookingView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlGridContain);
            this.Name = "GroupBookingView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.GroupBookingView_atSaveClick);
            this.atBeforeInitialise += new atACCFramework.BaseClasses.BeforeInitialiseEventHandler(this.GroupBookingView_atBeforeInitialise);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.GroupBookingView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.GroupBookingView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.GroupBookingView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.GroupBookingView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.GroupBookingView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.GroupBookingView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.GroupBookingView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.GroupBookingView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.GroupBookingView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.GroupBookingView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.GroupBookingView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.GroupBookingView_atBeforeSearch);
            this.Shown += new System.EventHandler(this.GroupBookingView_Shown);
            this.Controls.SetChildIndex(this.pnlGridContain, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlFooter, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlGridContain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindGroupBookingDTL)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlFooter.ResumeLayout(false);
            this.pnlFooter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblBillingAccount;
        private atACCFramework.UserControls.ComboBoxExt cmbBillingAccount;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.ComboBoxExt cmbGuest;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.atPanel pnlGridContain;
        private atACCFramework.UserControls.atNumericLabel txtChilds;
        private atACCFramework.UserControls.atLabel atLabel5;
        private atACCFramework.UserControls.atNumericLabel txtAdults;
        private atACCFramework.UserControls.atLabel atLabel4;
        private atACCFramework.UserControls.atNumericLabel txtNetTotal;
        private atACCFramework.UserControls.atLabel lblNetTotal;
        private atACCFramework.UserControls.atNumericLabel txtTotalDiscount;
        private atACCFramework.UserControls.atLabel lblTotalDisc;
        private atACCFramework.UserControls.TaxLabel lblTotalTax;
        private atACCFramework.UserControls.atButton btnAdvance;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atLabel lblComments;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.TextBoxNormal txtBalance;
        private atACCFramework.UserControls.atNumericLabel txtAdvance;
        private atACCFramework.UserControls.atLabel lblBalance;
        private atACCFramework.UserControls.atNumericLabel txtTotalTax;
        private System.Windows.Forms.Button btnSeperator1;
        private atACCFramework.UserControls.atNumericLabel txtTotalAmount;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.BindingSource bindGroupBookingDTL;
        private atACCFramework.UserControls.atNumericLabel txtGrandTotal;
        private atACCFramework.UserControls.atLabel atlblTot;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.atGridView dgDetails;
        private atACCFramework.UserControls.atLabel lblSource;
        private atACCFramework.UserControls.ComboBoxExt cmbSource;
        private atACCFramework.UserControls.ComboBoxExt cmbAgent;
        private atACCFramework.UserControls.atLabel lblAgent;
        private atACCFramework.UserControls.atLabel lblGuestType;
        private atACCFramework.UserControls.ComboBoxExt cmbGuestType;
        private atACCFramework.UserControls.TextBoxExt txtNoOfHalls;
        private atACCFramework.UserControls.atLabel atLabel2;
        private atACCFramework.UserControls.TextBoxExt txtNoOfRooms;
        private atACCFramework.UserControls.atLabel atLabel1;
        private atACCFramework.UserControls.TextBoxExt txtNoOfDays;
        private atACCFramework.UserControls.atLabel lblNoOfDays;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.atLabel lblType;
        private atACCFramework.UserControls.ComboBoxExt cmbType;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory4;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atButton btnNewType;
        private atACCFramework.UserControls.atButton btnNewSource;
        private atACCFramework.UserControls.atButton btnNewGuest;
        private atACCFramework.UserControls.atButton btnNewGuestType;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private System.Windows.Forms.Label lblCancelStatus;
        private atACCFramework.UserControls.atLabel lblAdvance;
        private System.Windows.Forms.Label lblMandatory5;
        private atACCFramework.UserControls.atLabel lblCurrencyCap;
        private atACCFramework.UserControls.TextBoxExt txtExRate;
        private atACCFramework.UserControls.ComboBoxExt cmbCurrency;
        private atACCFramework.UserControls.atLabel lblExRateCap;
        private System.Windows.Forms.Label lblMandatory6;
        private atACCFramework.UserControls.atButton btnAllocate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_slno;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_RoomOrHall;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_RoomType;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_Room;
        private System.Windows.Forms.DataGridViewComboBoxColumn Col_RateType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Adult;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Child;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalBeds;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalBedRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalPersons;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AdditionalPersonRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionAmount;
        private System.Windows.Forms.Button btnCheckIn;
    }
}