﻿namespace atACC.HTL.Transactions
{
    partial class CheckOutView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckOutView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle64 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtVoucherNo = new atACCFramework.UserControls.atUpDown();
            this.dtVoucherDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblVoucherNo = new atACCFramework.UserControls.atLabel();
            this.lblVoucherDate = new atACCFramework.UserControls.atLabel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblCurrencyCap = new atACCFramework.UserControls.atLabel();
            this.txtExRate = new atACCFramework.UserControls.TextBoxExt();
            this.cmbCurrency = new atACCFramework.UserControls.ComboBoxExt();
            this.lblExRateCap = new atACCFramework.UserControls.atLabel();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.btnCheckIn = new System.Windows.Forms.Button();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.txtNoOfDays = new atACCFramework.UserControls.TextBoxExt();
            this.lblNoOfDays = new atACCFramework.UserControls.atLabel();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.cmbCheckIn = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.dtpDepartureDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.lblArrivalDate = new atACCFramework.UserControls.atLabel();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.txtRoom = new atACCFramework.UserControls.TextBoxExt();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblCheckIn = new atACCFramework.UserControls.atLabel();
            this.dtpArrivalDate = new atACCFramework.UserControls.atDateTimePicker();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.pnlGrid = new atACCFramework.UserControls.atPanel();
            this.dgDetails = new atACCFramework.UserControls.atGridView();
            this.col_slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExtraServiceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_InclusiveRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DeductionAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_DiscountSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscountPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SlabDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TotalDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TaxableAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExcisePerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ExciseAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_ExciseSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax1Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX1SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax2Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX2SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Tax3Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_TAX3SlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AddnlTaxAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_AddnlTaxSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_VATAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_VATSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_FK_GSTSlabID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_NetAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCheckInTotal = new atACCFramework.UserControls.atNumericLabel();
            this.btnRefund = new atACCFramework.UserControls.atButton();
            this.txtRefund = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotQty = new atACCFramework.UserControls.atNumericLabel();
            this.totqtycap = new atACCFramework.UserControls.atLabel();
            this.txtAdvance = new atACCFramework.UserControls.atNumericLabel();
            this.lblAdvance = new atACCFramework.UserControls.atLabel();
            this.txtGross = new atACCFramework.UserControls.atNumericLabel();
            this.lblExtraServices = new atACCFramework.UserControls.atLabel();
            this.txtTotalDiscount = new atACCFramework.UserControls.atNumericLabel();
            this.lblTotalDisc = new atACCFramework.UserControls.atLabel();
            this.lblTotalTax = new atACCFramework.UserControls.TaxLabel();
            this.btnPayment = new atACCFramework.UserControls.atButton();
            this.txtBalance = new atACCFramework.UserControls.TextBoxNormal();
            this.txtPayment = new atACCFramework.UserControls.atNumericLabel();
            this.lblBalance = new atACCFramework.UserControls.atLabel();
            this.txtNetTotal = new atACCFramework.UserControls.atNumericLabel();
            this.lblNetTotal = new atACCFramework.UserControls.atLabel();
            this.txtTotalTax = new atACCFramework.UserControls.atNumericLabel();
            this.btnSeperator1 = new System.Windows.Forms.Button();
            this.lblGrandTotal = new atACCFramework.UserControls.atNumericLabel();
            this.atlblTot = new atACCFramework.UserControls.atLabel();
            this.bindExtraServiceDTL = new System.Windows.Forms.BindingSource(this.components);
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.txtAddnlRoundoff = new atACCFramework.UserControls.TextBoxNormal();
            this.lblAdnlRoundoff = new atACCFramework.UserControls.atLabel();
            this.lblExternal = new atACC.HTL.Transactions.AccountLabel();
            this.txtExternalAmt = new atACCFramework.UserControls.atNumericLabel();
            this.lblOpBalance = new atACC.HTL.Transactions.AccountLabel();
            this.txtOpBalance = new atACCFramework.UserControls.atNumericLabel();
            this.lblCancelStatus = new System.Windows.Forms.Label();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindExtraServiceDTL)).BeginInit();
            this.pnlFooter.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.lblGrandTotal);
            this.panel1.Controls.Add(this.atlblTot);
            this.errProvider.SetError(this.panel1, resources.GetString("panel1.Error"));
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.panel1, ((int)(resources.GetObject("panel1.IconPadding"))));
            this.panel1.Controls.SetChildIndex(this.atlblTot, 0);
            this.panel1.Controls.SetChildIndex(this.lblGrandTotal, 0);
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.txtVoucherNo);
            this.pnlHeader2.Controls.Add(this.dtVoucherDate);
            this.pnlHeader2.Controls.Add(this.lblVoucherNo);
            this.pnlHeader2.Controls.Add(this.lblVoucherDate);
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // txtVoucherNo
            // 
            resources.ApplyResources(this.txtVoucherNo, "txtVoucherNo");
            this.txtVoucherNo.BackColor = System.Drawing.Color.Transparent;
            this.txtVoucherNo.DataSource = null;
            this.errProvider.SetError(this.txtVoucherNo, resources.GetString("txtVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.txtVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtVoucherNo, ((int)(resources.GetObject("txtVoucherNo.IconPadding"))));
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.SelectedIndex = -1;
            this.txtVoucherNo.SelectedItem = null;
            this.txtVoucherNo.TabStop = false;
            // 
            // dtVoucherDate
            // 
            resources.ApplyResources(this.dtVoucherDate, "dtVoucherDate");
            this.dtVoucherDate.BackColor = System.Drawing.Color.Transparent;
            this.dtVoucherDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtVoucherDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtVoucherDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtVoucherDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtVoucherDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtVoucherDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtVoucherDate.Checked = true;
            this.dtVoucherDate.DisbaleDateTimeFormat = false;
            this.dtVoucherDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtVoucherDate, resources.GetString("dtVoucherDate.Error"));
            this.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtVoucherDate, ((int)(resources.GetObject("dtVoucherDate.IconPadding"))));
            this.dtVoucherDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtVoucherDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtVoucherDate.Name = "dtVoucherDate";
            this.dtVoucherDate.TabStop = false;
            this.dtVoucherDate.Value = new System.DateTime(2019, 5, 25, 14, 30, 12, 430);
            // 
            // lblVoucherNo
            // 
            resources.ApplyResources(this.lblVoucherNo, "lblVoucherNo");
            this.errProvider.SetError(this.lblVoucherNo, resources.GetString("lblVoucherNo.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherNo, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherNo.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherNo, ((int)(resources.GetObject("lblVoucherNo.IconPadding"))));
            this.lblVoucherNo.Name = "lblVoucherNo";
            this.lblVoucherNo.RequiredField = false;
            // 
            // lblVoucherDate
            // 
            resources.ApplyResources(this.lblVoucherDate, "lblVoucherDate");
            this.errProvider.SetError(this.lblVoucherDate, resources.GetString("lblVoucherDate.Error"));
            this.errProvider.SetIconAlignment(this.lblVoucherDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVoucherDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVoucherDate, ((int)(resources.GetObject("lblVoucherDate.IconPadding"))));
            this.lblVoucherDate.Name = "lblVoucherDate";
            this.lblVoucherDate.RequiredField = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblCurrencyCap);
            this.pnlMain.Controls.Add(this.txtExRate);
            this.pnlMain.Controls.Add(this.cmbCurrency);
            this.pnlMain.Controls.Add(this.lblExRateCap);
            this.pnlMain.Controls.Add(this.txtTelephone);
            this.pnlMain.Controls.Add(this.lblTelephone);
            this.pnlMain.Controls.Add(this.btnCheckIn);
            this.pnlMain.Controls.Add(this.lblAddress1);
            this.pnlMain.Controls.Add(this.txtNoOfDays);
            this.pnlMain.Controls.Add(this.lblNoOfDays);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.cmbCheckIn);
            this.pnlMain.Controls.Add(this.cmbEmployee);
            this.pnlMain.Controls.Add(this.txtRemarks);
            this.pnlMain.Controls.Add(this.dtpDepartureDate);
            this.pnlMain.Controls.Add(this.lblRemarks);
            this.pnlMain.Controls.Add(this.lblDepartureDate);
            this.pnlMain.Controls.Add(this.lblEmployee);
            this.pnlMain.Controls.Add(this.lblArrivalDate);
            this.pnlMain.Controls.Add(this.txtGuest);
            this.pnlMain.Controls.Add(this.txtRoom);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.txtMobile);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblCheckIn);
            this.pnlMain.Controls.Add(this.dtpArrivalDate);
            this.pnlMain.Controls.Add(this.txtAdd1);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.errProvider.SetError(this.lblMandatory4, resources.GetString("lblMandatory4.Error"));
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory4.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory4, ((int)(resources.GetObject("lblMandatory4.IconPadding"))));
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.errProvider.SetError(this.lblMandatory2, resources.GetString("lblMandatory2.Error"));
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory2, ((int)(resources.GetObject("lblMandatory2.IconPadding"))));
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblCurrencyCap
            // 
            resources.ApplyResources(this.lblCurrencyCap, "lblCurrencyCap");
            this.errProvider.SetError(this.lblCurrencyCap, resources.GetString("lblCurrencyCap.Error"));
            this.errProvider.SetIconAlignment(this.lblCurrencyCap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCurrencyCap.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCurrencyCap, ((int)(resources.GetObject("lblCurrencyCap.IconPadding"))));
            this.lblCurrencyCap.Name = "lblCurrencyCap";
            this.lblCurrencyCap.RequiredField = false;
            // 
            // txtExRate
            // 
            resources.ApplyResources(this.txtExRate, "txtExRate");
            this.txtExRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtExRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtExRate, resources.GetString("txtExRate.Error"));
            this.txtExRate.Format = null;
            this.errProvider.SetIconAlignment(this.txtExRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtExRate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtExRate, ((int)(resources.GetObject("txtExRate.IconPadding"))));
            this.txtExRate.isAllowNegative = false;
            this.txtExRate.isAllowSpecialChar = false;
            this.txtExRate.isNumbersOnly = false;
            this.txtExRate.isNumeric = true;
            this.txtExRate.isTouchable = false;
            this.txtExRate.Name = "txtExRate";
            this.txtExRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtExRate.Enter += new System.EventHandler(this.txtExRate_Enter);
            this.txtExRate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtExRate_KeyUp);
            // 
            // cmbCurrency
            // 
            resources.ApplyResources(this.cmbCurrency, "cmbCurrency");
            this.cmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCurrency.DropDownHeight = 300;
            this.cmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbCurrency, resources.GetString("cmbCurrency.Error"));
            this.cmbCurrency.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbCurrency, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbCurrency.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbCurrency, ((int)(resources.GetObject("cmbCurrency.IconPadding"))));
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.SelectedIndexChanged += new System.EventHandler(this.cmbCurrency_SelectedIndexChanged);
            // 
            // lblExRateCap
            // 
            resources.ApplyResources(this.lblExRateCap, "lblExRateCap");
            this.errProvider.SetError(this.lblExRateCap, resources.GetString("lblExRateCap.Error"));
            this.errProvider.SetIconAlignment(this.lblExRateCap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExRateCap.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblExRateCap, ((int)(resources.GetObject("lblExRateCap.IconPadding"))));
            this.lblExRateCap.Name = "lblExRateCap";
            this.lblExRateCap.RequiredField = false;
            // 
            // txtTelephone
            // 
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtTelephone, resources.GetString("txtTelephone.Error"));
            this.txtTelephone.Format = null;
            this.errProvider.SetIconAlignment(this.txtTelephone, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTelephone.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtTelephone, ((int)(resources.GetObject("txtTelephone.IconPadding"))));
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = true;
            this.txtTelephone.isNumeric = false;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.TabStop = false;
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTelephone
            // 
            resources.ApplyResources(this.lblTelephone, "lblTelephone");
            this.errProvider.SetError(this.lblTelephone, resources.GetString("lblTelephone.Error"));
            this.errProvider.SetIconAlignment(this.lblTelephone, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTelephone.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTelephone, ((int)(resources.GetObject("lblTelephone.IconPadding"))));
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            // 
            // btnCheckIn
            // 
            resources.ApplyResources(this.btnCheckIn, "btnCheckIn");
            this.errProvider.SetError(this.btnCheckIn, resources.GetString("btnCheckIn.Error"));
            this.btnCheckIn.FlatAppearance.BorderSize = 0;
            this.btnCheckIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            this.errProvider.SetIconAlignment(this.btnCheckIn, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnCheckIn.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnCheckIn, ((int)(resources.GetObject("btnCheckIn.IconPadding"))));
            this.btnCheckIn.Name = "btnCheckIn";
            this.btnCheckIn.UseVisualStyleBackColor = true;
            this.btnCheckIn.Click += new System.EventHandler(this.btnCheckIn_Click);
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.errProvider.SetError(this.lblAddress1, resources.GetString("lblAddress1.Error"));
            this.errProvider.SetIconAlignment(this.lblAddress1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddress1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAddress1, ((int)(resources.GetObject("lblAddress1.IconPadding"))));
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // txtNoOfDays
            // 
            resources.ApplyResources(this.txtNoOfDays, "txtNoOfDays");
            this.txtNoOfDays.BackColor = System.Drawing.SystemColors.Window;
            this.txtNoOfDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtNoOfDays, resources.GetString("txtNoOfDays.Error"));
            this.txtNoOfDays.Format = "";
            this.errProvider.SetIconAlignment(this.txtNoOfDays, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNoOfDays.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtNoOfDays, ((int)(resources.GetObject("txtNoOfDays.IconPadding"))));
            this.txtNoOfDays.isAllowNegative = false;
            this.txtNoOfDays.isAllowSpecialChar = false;
            this.txtNoOfDays.isNumbersOnly = true;
            this.txtNoOfDays.isNumeric = false;
            this.txtNoOfDays.isTouchable = true;
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.ReadOnly = true;
            this.txtNoOfDays.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNoOfDays
            // 
            resources.ApplyResources(this.lblNoOfDays, "lblNoOfDays");
            this.errProvider.SetError(this.lblNoOfDays, resources.GetString("lblNoOfDays.Error"));
            this.errProvider.SetIconAlignment(this.lblNoOfDays, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNoOfDays.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblNoOfDays, ((int)(resources.GetObject("lblNoOfDays.IconPadding"))));
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.RequiredField = false;
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.errProvider.SetError(this.lblMandatory3, resources.GetString("lblMandatory3.Error"));
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory3, ((int)(resources.GetObject("lblMandatory3.IconPadding"))));
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // cmbCheckIn
            // 
            resources.ApplyResources(this.cmbCheckIn, "cmbCheckIn");
            this.cmbCheckIn.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCheckIn.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCheckIn.DropDownHeight = 300;
            this.cmbCheckIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbCheckIn, resources.GetString("cmbCheckIn.Error"));
            this.cmbCheckIn.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbCheckIn, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbCheckIn.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbCheckIn, ((int)(resources.GetObject("cmbCheckIn.IconPadding"))));
            this.cmbCheckIn.Name = "cmbCheckIn";
            this.cmbCheckIn.SelectedValueChanged += new System.EventHandler(this.cmbCheckIn_SelectedValueChanged);
            this.cmbCheckIn.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbCheckIn_KeyDown);
            // 
            // cmbEmployee
            // 
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbEmployee, resources.GetString("cmbEmployee.Error"));
            this.cmbEmployee.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbEmployee, ((int)(resources.GetObject("cmbEmployee.IconPadding"))));
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtRemarks, resources.GetString("txtRemarks.Error"));
            this.txtRemarks.Format = null;
            this.errProvider.SetIconAlignment(this.txtRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtRemarks, ((int)(resources.GetObject("txtRemarks.IconPadding"))));
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRemarks_KeyDown);
            // 
            // dtpDepartureDate
            // 
            resources.ApplyResources(this.dtpDepartureDate, "dtpDepartureDate");
            this.dtpDepartureDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpDepartureDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDepartureDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpDepartureDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpDepartureDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpDepartureDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpDepartureDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpDepartureDate.Checked = true;
            this.dtpDepartureDate.DisbaleDateTimeFormat = false;
            this.dtpDepartureDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpDepartureDate, resources.GetString("dtpDepartureDate.Error"));
            this.dtpDepartureDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpDepartureDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpDepartureDate, ((int)(resources.GetObject("dtpDepartureDate.IconPadding"))));
            this.dtpDepartureDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpDepartureDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.errProvider.SetError(this.lblRemarks, resources.GetString("lblRemarks.Error"));
            this.errProvider.SetIconAlignment(this.lblRemarks, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRemarks.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRemarks, ((int)(resources.GetObject("lblRemarks.IconPadding"))));
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // lblDepartureDate
            // 
            resources.ApplyResources(this.lblDepartureDate, "lblDepartureDate");
            this.errProvider.SetError(this.lblDepartureDate, resources.GetString("lblDepartureDate.Error"));
            this.errProvider.SetIconAlignment(this.lblDepartureDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDepartureDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblDepartureDate, ((int)(resources.GetObject("lblDepartureDate.IconPadding"))));
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.errProvider.SetError(this.lblEmployee, resources.GetString("lblEmployee.Error"));
            this.errProvider.SetIconAlignment(this.lblEmployee, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblEmployee.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblEmployee, ((int)(resources.GetObject("lblEmployee.IconPadding"))));
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // lblArrivalDate
            // 
            resources.ApplyResources(this.lblArrivalDate, "lblArrivalDate");
            this.errProvider.SetError(this.lblArrivalDate, resources.GetString("lblArrivalDate.Error"));
            this.errProvider.SetIconAlignment(this.lblArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblArrivalDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblArrivalDate, ((int)(resources.GetObject("lblArrivalDate.IconPadding"))));
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.RequiredField = false;
            // 
            // txtGuest
            // 
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtGuest, resources.GetString("txtGuest.Error"));
            this.txtGuest.Format = null;
            this.errProvider.SetIconAlignment(this.txtGuest, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtGuest.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtGuest, ((int)(resources.GetObject("txtGuest.IconPadding"))));
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.ReadOnly = true;
            this.txtGuest.TabStop = false;
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtRoom
            // 
            resources.ApplyResources(this.txtRoom, "txtRoom");
            this.txtRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtRoom, resources.GetString("txtRoom.Error"));
            this.txtRoom.Format = null;
            this.errProvider.SetIconAlignment(this.txtRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRoom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtRoom, ((int)(resources.GetObject("txtRoom.IconPadding"))));
            this.txtRoom.isAllowNegative = false;
            this.txtRoom.isAllowSpecialChar = false;
            this.txtRoom.isNumbersOnly = false;
            this.txtRoom.isNumeric = false;
            this.txtRoom.isTouchable = false;
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.ReadOnly = true;
            this.txtRoom.TabStop = false;
            this.txtRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.errProvider.SetError(this.lblRoom, resources.GetString("lblRoom.Error"));
            this.errProvider.SetIconAlignment(this.lblRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRoom, ((int)(resources.GetObject("lblRoom.IconPadding"))));
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.errProvider.SetError(this.lblGuest, resources.GetString("lblGuest.Error"));
            this.errProvider.SetIconAlignment(this.lblGuest, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblGuest.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblGuest, ((int)(resources.GetObject("lblGuest.IconPadding"))));
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // txtMobile
            // 
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtMobile, resources.GetString("txtMobile.Error"));
            this.txtMobile.Format = null;
            this.errProvider.SetIconAlignment(this.txtMobile, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtMobile.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtMobile, ((int)(resources.GetObject("txtMobile.IconPadding"))));
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = true;
            this.txtMobile.isNumeric = false;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.ReadOnly = true;
            this.txtMobile.TabStop = false;
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.errProvider.SetError(this.lblMandatory1, resources.GetString("lblMandatory1.Error"));
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory1, ((int)(resources.GetObject("lblMandatory1.IconPadding"))));
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblCheckIn
            // 
            resources.ApplyResources(this.lblCheckIn, "lblCheckIn");
            this.errProvider.SetError(this.lblCheckIn, resources.GetString("lblCheckIn.Error"));
            this.errProvider.SetIconAlignment(this.lblCheckIn, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCheckIn.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCheckIn, ((int)(resources.GetObject("lblCheckIn.IconPadding"))));
            this.lblCheckIn.Name = "lblCheckIn";
            this.lblCheckIn.RequiredField = false;
            // 
            // dtpArrivalDate
            // 
            resources.ApplyResources(this.dtpArrivalDate, "dtpArrivalDate");
            this.dtpArrivalDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpArrivalDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpArrivalDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpArrivalDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpArrivalDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpArrivalDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpArrivalDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpArrivalDate.Checked = true;
            this.dtpArrivalDate.DisbaleDateTimeFormat = false;
            this.dtpArrivalDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpArrivalDate, resources.GetString("dtpArrivalDate.Error"));
            this.dtpArrivalDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpArrivalDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpArrivalDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpArrivalDate, ((int)(resources.GetObject("dtpArrivalDate.IconPadding"))));
            this.dtpArrivalDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpArrivalDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.Value = new System.DateTime(2019, 8, 21, 10, 25, 26, 853);
            // 
            // txtAdd1
            // 
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtAdd1, resources.GetString("txtAdd1.Error"));
            this.txtAdd1.Format = null;
            this.errProvider.SetIconAlignment(this.txtAdd1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAdd1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtAdd1, ((int)(resources.GetObject("txtAdd1.IconPadding"))));
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.ReadOnly = true;
            this.txtAdd1.TabStop = false;
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // pnlGrid
            // 
            resources.ApplyResources(this.pnlGrid, "pnlGrid");
            this.pnlGrid.BackColor = System.Drawing.SystemColors.Window;
            this.pnlGrid.Controls.Add(this.dgDetails);
            this.errProvider.SetError(this.pnlGrid, resources.GetString("pnlGrid.Error"));
            this.errProvider.SetIconAlignment(this.pnlGrid, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlGrid.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlGrid, ((int)(resources.GetObject("pnlGrid.IconPadding"))));
            this.pnlGrid.Name = "pnlGrid";
            // 
            // dgDetails
            // 
            resources.ApplyResources(this.dgDetails, "dgDetails");
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_slno,
            this.col_Code,
            this.col_Service,
            this.col_FK_ExtraServiceID,
            this.col_Qty,
            this.col_Rate,
            this.col_InclusiveRate,
            this.col_Amount,
            this.col_DeductionPerc,
            this.col_DeductionAmount,
            this.col_TotalTax,
            this.col_FK_DiscountSlabID,
            this.col_SlabDiscountPerc,
            this.col_SlabDiscount,
            this.col_TotalDiscount,
            this.col_TaxableAmount,
            this.col_ExcisePerc,
            this.col_ExciseAmount,
            this.col_FK_ExciseSlabID,
            this.col_Tax1Perc,
            this.col_Tax1Amount,
            this.col_FK_TAX1SlabID,
            this.col_Tax2Perc,
            this.col_Tax2Amount,
            this.col_FK_TAX2SlabID,
            this.col_Tax3Perc,
            this.col_Tax3Amount,
            this.col_FK_TAX3SlabID,
            this.col_AddnlTaxPerc,
            this.col_AddnlTaxAmount,
            this.col_FK_AddnlTaxSlabID,
            this.col_VATPerc,
            this.col_VATAmount,
            this.col_FK_VATSlabID,
            this.col_CGSTPerc,
            this.col_CGSTAmount,
            this.col_SGSTPerc,
            this.col_SGSTAmount,
            this.col_IGSTPerc,
            this.col_IGSTAmount,
            this.col_FK_GSTSlabID,
            this.col_NetAmount});
            this.dgDetails.EnableHeadersVisualStyles = false;
            this.dgDetails.EnterKeyNavigation = false;
            this.errProvider.SetError(this.dgDetails, resources.GetString("dgDetails.Error"));
            this.errProvider.SetIconAlignment(this.dgDetails, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dgDetails.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dgDetails, ((int)(resources.GetObject("dgDetails.IconPadding"))));
            this.dgDetails.LastKey = System.Windows.Forms.Keys.None;
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle64.NullValue = null;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle64;
            this.dgDetails.sGridID = null;
            this.dgDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgDetails_CellBeginEdit);
            this.dgDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEndEdit);
            this.dgDetails.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellEnter);
            this.dgDetails.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgDetails_CellValidating);
            this.dgDetails.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgDetails_DataError);
            this.dgDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgDetails_EditingControlShowing);
            this.dgDetails.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgDetails_RowsAdded);
            this.dgDetails.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgDetails_RowsRemoved);
            this.dgDetails.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgDetails_KeyDown);
            // 
            // col_slno
            // 
            this.col_slno.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_slno.DataPropertyName = "SlNo";
            this.col_slno.FillWeight = 111.905F;
            resources.ApplyResources(this.col_slno, "col_slno");
            this.col_slno.Name = "col_slno";
            this.col_slno.ReadOnly = true;
            // 
            // col_Code
            // 
            this.col_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Code.DataPropertyName = "ServiceCode";
            this.col_Code.FillWeight = 95.68391F;
            resources.ApplyResources(this.col_Code, "col_Code");
            this.col_Code.Name = "col_Code";
            this.col_Code.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // col_Service
            // 
            this.col_Service.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.col_Service.DataPropertyName = "ServiceName";
            this.col_Service.FillWeight = 286.4355F;
            resources.ApplyResources(this.col_Service, "col_Service");
            this.col_Service.Name = "col_Service";
            this.col_Service.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Service.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // col_FK_ExtraServiceID
            // 
            this.col_FK_ExtraServiceID.DataPropertyName = "FK_ExtraServiceID";
            resources.ApplyResources(this.col_FK_ExtraServiceID, "col_FK_ExtraServiceID");
            this.col_FK_ExtraServiceID.Name = "col_FK_ExtraServiceID";
            this.col_FK_ExtraServiceID.ReadOnly = true;
            // 
            // col_Qty
            // 
            this.col_Qty.DataPropertyName = "Qty";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_Qty.DefaultCellStyle = dataGridViewCellStyle35;
            this.col_Qty.FillWeight = 91.05099F;
            resources.ApplyResources(this.col_Qty, "col_Qty");
            this.col_Qty.Name = "col_Qty";
            // 
            // col_Rate
            // 
            this.col_Rate.DataPropertyName = "Rate";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Rate.DefaultCellStyle = dataGridViewCellStyle36;
            this.col_Rate.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Rate, "col_Rate");
            this.col_Rate.Name = "col_Rate";
            // 
            // col_InclusiveRate
            // 
            this.col_InclusiveRate.DataPropertyName = "InclusiveRate";
            resources.ApplyResources(this.col_InclusiveRate, "col_InclusiveRate");
            this.col_InclusiveRate.Name = "col_InclusiveRate";
            // 
            // col_Amount
            // 
            this.col_Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Amount.DefaultCellStyle = dataGridViewCellStyle37;
            this.col_Amount.FillWeight = 109.2612F;
            resources.ApplyResources(this.col_Amount, "col_Amount");
            this.col_Amount.Name = "col_Amount";
            this.col_Amount.ReadOnly = true;
            // 
            // col_DeductionPerc
            // 
            this.col_DeductionPerc.DataPropertyName = "DeductionPerc";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionPerc.DefaultCellStyle = dataGridViewCellStyle38;
            resources.ApplyResources(this.col_DeductionPerc, "col_DeductionPerc");
            this.col_DeductionPerc.Name = "col_DeductionPerc";
            // 
            // col_DeductionAmount
            // 
            this.col_DeductionAmount.DataPropertyName = "DeductionAmount";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DeductionAmount.DefaultCellStyle = dataGridViewCellStyle39;
            resources.ApplyResources(this.col_DeductionAmount, "col_DeductionAmount");
            this.col_DeductionAmount.Name = "col_DeductionAmount";
            this.col_DeductionAmount.ReadOnly = true;
            // 
            // col_TotalTax
            // 
            this.col_TotalTax.DataPropertyName = "TotalTax";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TotalTax.DefaultCellStyle = dataGridViewCellStyle40;
            resources.ApplyResources(this.col_TotalTax, "col_TotalTax");
            this.col_TotalTax.Name = "col_TotalTax";
            this.col_TotalTax.ReadOnly = true;
            // 
            // col_FK_DiscountSlabID
            // 
            this.col_FK_DiscountSlabID.DataPropertyName = "FK_DiscountSlabID";
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_DiscountSlabID.DefaultCellStyle = dataGridViewCellStyle41;
            resources.ApplyResources(this.col_FK_DiscountSlabID, "col_FK_DiscountSlabID");
            this.col_FK_DiscountSlabID.Name = "col_FK_DiscountSlabID";
            // 
            // col_SlabDiscountPerc
            // 
            this.col_SlabDiscountPerc.DataPropertyName = "SlabDiscountPerc";
            resources.ApplyResources(this.col_SlabDiscountPerc, "col_SlabDiscountPerc");
            this.col_SlabDiscountPerc.Name = "col_SlabDiscountPerc";
            // 
            // col_SlabDiscount
            // 
            this.col_SlabDiscount.DataPropertyName = "SlabDiscount";
            resources.ApplyResources(this.col_SlabDiscount, "col_SlabDiscount");
            this.col_SlabDiscount.Name = "col_SlabDiscount";
            // 
            // col_TotalDiscount
            // 
            this.col_TotalDiscount.DataPropertyName = "TotalDiscount";
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TotalDiscount.DefaultCellStyle = dataGridViewCellStyle42;
            resources.ApplyResources(this.col_TotalDiscount, "col_TotalDiscount");
            this.col_TotalDiscount.Name = "col_TotalDiscount";
            // 
            // col_TaxableAmount
            // 
            this.col_TaxableAmount.DataPropertyName = "TaxableAmount";
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_TaxableAmount.DefaultCellStyle = dataGridViewCellStyle43;
            resources.ApplyResources(this.col_TaxableAmount, "col_TaxableAmount");
            this.col_TaxableAmount.Name = "col_TaxableAmount";
            this.col_TaxableAmount.ReadOnly = true;
            // 
            // col_ExcisePerc
            // 
            this.col_ExcisePerc.DataPropertyName = "ExcisePerc";
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExcisePerc.DefaultCellStyle = dataGridViewCellStyle44;
            resources.ApplyResources(this.col_ExcisePerc, "col_ExcisePerc");
            this.col_ExcisePerc.Name = "col_ExcisePerc";
            this.col_ExcisePerc.ReadOnly = true;
            // 
            // col_ExciseAmount
            // 
            this.col_ExciseAmount.DataPropertyName = "ExciseAmount";
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_ExciseAmount.DefaultCellStyle = dataGridViewCellStyle45;
            resources.ApplyResources(this.col_ExciseAmount, "col_ExciseAmount");
            this.col_ExciseAmount.Name = "col_ExciseAmount";
            this.col_ExciseAmount.ReadOnly = true;
            // 
            // col_FK_ExciseSlabID
            // 
            this.col_FK_ExciseSlabID.DataPropertyName = "FK_ExciseSlabID";
            resources.ApplyResources(this.col_FK_ExciseSlabID, "col_FK_ExciseSlabID");
            this.col_FK_ExciseSlabID.Name = "col_FK_ExciseSlabID";
            // 
            // col_Tax1Perc
            // 
            this.col_Tax1Perc.DataPropertyName = "Tax1Perc";
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Perc.DefaultCellStyle = dataGridViewCellStyle46;
            resources.ApplyResources(this.col_Tax1Perc, "col_Tax1Perc");
            this.col_Tax1Perc.Name = "col_Tax1Perc";
            this.col_Tax1Perc.ReadOnly = true;
            // 
            // col_Tax1Amount
            // 
            this.col_Tax1Amount.DataPropertyName = "Tax1Amount";
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax1Amount.DefaultCellStyle = dataGridViewCellStyle47;
            resources.ApplyResources(this.col_Tax1Amount, "col_Tax1Amount");
            this.col_Tax1Amount.Name = "col_Tax1Amount";
            this.col_Tax1Amount.ReadOnly = true;
            // 
            // col_FK_TAX1SlabID
            // 
            this.col_FK_TAX1SlabID.DataPropertyName = "FK_TAX1SlabID";
            resources.ApplyResources(this.col_FK_TAX1SlabID, "col_FK_TAX1SlabID");
            this.col_FK_TAX1SlabID.Name = "col_FK_TAX1SlabID";
            // 
            // col_Tax2Perc
            // 
            this.col_Tax2Perc.DataPropertyName = "Tax2Perc";
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Perc.DefaultCellStyle = dataGridViewCellStyle48;
            resources.ApplyResources(this.col_Tax2Perc, "col_Tax2Perc");
            this.col_Tax2Perc.Name = "col_Tax2Perc";
            this.col_Tax2Perc.ReadOnly = true;
            // 
            // col_Tax2Amount
            // 
            this.col_Tax2Amount.DataPropertyName = "Tax2Amount";
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax2Amount.DefaultCellStyle = dataGridViewCellStyle49;
            resources.ApplyResources(this.col_Tax2Amount, "col_Tax2Amount");
            this.col_Tax2Amount.Name = "col_Tax2Amount";
            this.col_Tax2Amount.ReadOnly = true;
            // 
            // col_FK_TAX2SlabID
            // 
            this.col_FK_TAX2SlabID.DataPropertyName = "FK_TAX2SlabID";
            resources.ApplyResources(this.col_FK_TAX2SlabID, "col_FK_TAX2SlabID");
            this.col_FK_TAX2SlabID.Name = "col_FK_TAX2SlabID";
            // 
            // col_Tax3Perc
            // 
            this.col_Tax3Perc.DataPropertyName = "Tax3Perc";
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Perc.DefaultCellStyle = dataGridViewCellStyle50;
            resources.ApplyResources(this.col_Tax3Perc, "col_Tax3Perc");
            this.col_Tax3Perc.Name = "col_Tax3Perc";
            this.col_Tax3Perc.ReadOnly = true;
            // 
            // col_Tax3Amount
            // 
            this.col_Tax3Amount.DataPropertyName = "Tax3Amount";
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Tax3Amount.DefaultCellStyle = dataGridViewCellStyle51;
            resources.ApplyResources(this.col_Tax3Amount, "col_Tax3Amount");
            this.col_Tax3Amount.Name = "col_Tax3Amount";
            this.col_Tax3Amount.ReadOnly = true;
            // 
            // col_FK_TAX3SlabID
            // 
            this.col_FK_TAX3SlabID.DataPropertyName = "FK_TAX3SlabID";
            resources.ApplyResources(this.col_FK_TAX3SlabID, "col_FK_TAX3SlabID");
            this.col_FK_TAX3SlabID.Name = "col_FK_TAX3SlabID";
            // 
            // col_AddnlTaxPerc
            // 
            this.col_AddnlTaxPerc.DataPropertyName = "AddnlTaxPerc";
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxPerc.DefaultCellStyle = dataGridViewCellStyle52;
            resources.ApplyResources(this.col_AddnlTaxPerc, "col_AddnlTaxPerc");
            this.col_AddnlTaxPerc.Name = "col_AddnlTaxPerc";
            this.col_AddnlTaxPerc.ReadOnly = true;
            // 
            // col_AddnlTaxAmount
            // 
            this.col_AddnlTaxAmount.DataPropertyName = "AddnlTaxAmount";
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_AddnlTaxAmount.DefaultCellStyle = dataGridViewCellStyle53;
            resources.ApplyResources(this.col_AddnlTaxAmount, "col_AddnlTaxAmount");
            this.col_AddnlTaxAmount.Name = "col_AddnlTaxAmount";
            this.col_AddnlTaxAmount.ReadOnly = true;
            // 
            // col_FK_AddnlTaxSlabID
            // 
            this.col_FK_AddnlTaxSlabID.DataPropertyName = "FK_AddnlTaxSlabID";
            resources.ApplyResources(this.col_FK_AddnlTaxSlabID, "col_FK_AddnlTaxSlabID");
            this.col_FK_AddnlTaxSlabID.Name = "col_FK_AddnlTaxSlabID";
            // 
            // col_VATPerc
            // 
            this.col_VATPerc.DataPropertyName = "VATPerc";
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATPerc.DefaultCellStyle = dataGridViewCellStyle54;
            resources.ApplyResources(this.col_VATPerc, "col_VATPerc");
            this.col_VATPerc.Name = "col_VATPerc";
            this.col_VATPerc.ReadOnly = true;
            // 
            // col_VATAmount
            // 
            this.col_VATAmount.DataPropertyName = "VATAmount";
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_VATAmount.DefaultCellStyle = dataGridViewCellStyle55;
            resources.ApplyResources(this.col_VATAmount, "col_VATAmount");
            this.col_VATAmount.Name = "col_VATAmount";
            this.col_VATAmount.ReadOnly = true;
            // 
            // col_FK_VATSlabID
            // 
            this.col_FK_VATSlabID.DataPropertyName = "FK_VATSlabID";
            resources.ApplyResources(this.col_FK_VATSlabID, "col_FK_VATSlabID");
            this.col_FK_VATSlabID.Name = "col_FK_VATSlabID";
            // 
            // col_CGSTPerc
            // 
            this.col_CGSTPerc.DataPropertyName = "CGSTPerc";
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTPerc.DefaultCellStyle = dataGridViewCellStyle56;
            resources.ApplyResources(this.col_CGSTPerc, "col_CGSTPerc");
            this.col_CGSTPerc.Name = "col_CGSTPerc";
            this.col_CGSTPerc.ReadOnly = true;
            // 
            // col_CGSTAmount
            // 
            this.col_CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CGSTAmount.DefaultCellStyle = dataGridViewCellStyle57;
            resources.ApplyResources(this.col_CGSTAmount, "col_CGSTAmount");
            this.col_CGSTAmount.Name = "col_CGSTAmount";
            this.col_CGSTAmount.ReadOnly = true;
            // 
            // col_SGSTPerc
            // 
            this.col_SGSTPerc.DataPropertyName = "SGSTPerc";
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTPerc.DefaultCellStyle = dataGridViewCellStyle58;
            resources.ApplyResources(this.col_SGSTPerc, "col_SGSTPerc");
            this.col_SGSTPerc.Name = "col_SGSTPerc";
            this.col_SGSTPerc.ReadOnly = true;
            // 
            // col_SGSTAmount
            // 
            this.col_SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_SGSTAmount.DefaultCellStyle = dataGridViewCellStyle59;
            resources.ApplyResources(this.col_SGSTAmount, "col_SGSTAmount");
            this.col_SGSTAmount.Name = "col_SGSTAmount";
            this.col_SGSTAmount.ReadOnly = true;
            // 
            // col_IGSTPerc
            // 
            this.col_IGSTPerc.DataPropertyName = "IGSTPerc";
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTPerc.DefaultCellStyle = dataGridViewCellStyle60;
            resources.ApplyResources(this.col_IGSTPerc, "col_IGSTPerc");
            this.col_IGSTPerc.Name = "col_IGSTPerc";
            this.col_IGSTPerc.ReadOnly = true;
            // 
            // col_IGSTAmount
            // 
            this.col_IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_IGSTAmount.DefaultCellStyle = dataGridViewCellStyle61;
            resources.ApplyResources(this.col_IGSTAmount, "col_IGSTAmount");
            this.col_IGSTAmount.Name = "col_IGSTAmount";
            this.col_IGSTAmount.ReadOnly = true;
            // 
            // col_FK_GSTSlabID
            // 
            this.col_FK_GSTSlabID.DataPropertyName = "FK_GSTSlabID";
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_FK_GSTSlabID.DefaultCellStyle = dataGridViewCellStyle62;
            resources.ApplyResources(this.col_FK_GSTSlabID, "col_FK_GSTSlabID");
            this.col_FK_GSTSlabID.Name = "col_FK_GSTSlabID";
            // 
            // col_NetAmount
            // 
            this.col_NetAmount.DataPropertyName = "NetAmount";
            dataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_NetAmount.DefaultCellStyle = dataGridViewCellStyle63;
            resources.ApplyResources(this.col_NetAmount, "col_NetAmount");
            this.col_NetAmount.Name = "col_NetAmount";
            this.col_NetAmount.ReadOnly = true;
            // 
            // txtCheckInTotal
            // 
            resources.ApplyResources(this.txtCheckInTotal, "txtCheckInTotal");
            this.txtCheckInTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtCheckInTotal, resources.GetString("txtCheckInTotal.Error"));
            this.txtCheckInTotal.ForeColor = System.Drawing.Color.Black;
            this.txtCheckInTotal.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtCheckInTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtCheckInTotal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtCheckInTotal, ((int)(resources.GetObject("txtCheckInTotal.IconPadding"))));
            this.txtCheckInTotal.Name = "txtCheckInTotal";
            this.txtCheckInTotal.RequiredField = false;
            this.txtCheckInTotal.UseCompatibleTextRendering = true;
            this.txtCheckInTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnRefund
            // 
            resources.ApplyResources(this.btnRefund, "btnRefund");
            this.btnRefund.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnRefund, resources.GetString("btnRefund.Error"));
            this.btnRefund.FlatAppearance.BorderSize = 0;
            this.btnRefund.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnRefund, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnRefund.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnRefund, ((int)(resources.GetObject("btnRefund.IconPadding"))));
            this.btnRefund.Name = "btnRefund";
            this.btnRefund.UseVisualStyleBackColor = false;
            this.btnRefund.Click += new System.EventHandler(this.btnRefund_Click);
            // 
            // txtRefund
            // 
            resources.ApplyResources(this.txtRefund, "txtRefund");
            this.txtRefund.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtRefund, resources.GetString("txtRefund.Error"));
            this.txtRefund.ForeColor = System.Drawing.Color.Black;
            this.txtRefund.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtRefund, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRefund.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtRefund, ((int)(resources.GetObject("txtRefund.IconPadding"))));
            this.txtRefund.Name = "txtRefund";
            this.txtRefund.RequiredField = false;
            this.txtRefund.UseCompatibleTextRendering = true;
            this.txtRefund.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotQty
            // 
            resources.ApplyResources(this.lblTotQty, "lblTotQty");
            this.lblTotQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.lblTotQty, resources.GetString("lblTotQty.Error"));
            this.lblTotQty.ForeColor = System.Drawing.Color.Black;
            this.lblTotQty.Format = "N2";
            this.errProvider.SetIconAlignment(this.lblTotQty, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotQty.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTotQty, ((int)(resources.GetObject("lblTotQty.IconPadding"))));
            this.lblTotQty.Name = "lblTotQty";
            this.lblTotQty.RequiredField = false;
            this.lblTotQty.UseCompatibleTextRendering = true;
            this.lblTotQty.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // totqtycap
            // 
            resources.ApplyResources(this.totqtycap, "totqtycap");
            this.errProvider.SetError(this.totqtycap, resources.GetString("totqtycap.Error"));
            this.errProvider.SetIconAlignment(this.totqtycap, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("totqtycap.IconAlignment"))));
            this.errProvider.SetIconPadding(this.totqtycap, ((int)(resources.GetObject("totqtycap.IconPadding"))));
            this.totqtycap.Name = "totqtycap";
            this.totqtycap.RequiredField = false;
            // 
            // txtAdvance
            // 
            resources.ApplyResources(this.txtAdvance, "txtAdvance");
            this.txtAdvance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtAdvance, resources.GetString("txtAdvance.Error"));
            this.txtAdvance.ForeColor = System.Drawing.Color.Black;
            this.txtAdvance.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtAdvance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAdvance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtAdvance, ((int)(resources.GetObject("txtAdvance.IconPadding"))));
            this.txtAdvance.Name = "txtAdvance";
            this.txtAdvance.RequiredField = false;
            this.txtAdvance.UseCompatibleTextRendering = true;
            this.txtAdvance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAdvance
            // 
            resources.ApplyResources(this.lblAdvance, "lblAdvance");
            this.errProvider.SetError(this.lblAdvance, resources.GetString("lblAdvance.Error"));
            this.errProvider.SetIconAlignment(this.lblAdvance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdvance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAdvance, ((int)(resources.GetObject("lblAdvance.IconPadding"))));
            this.lblAdvance.Name = "lblAdvance";
            this.lblAdvance.RequiredField = false;
            // 
            // txtGross
            // 
            resources.ApplyResources(this.txtGross, "txtGross");
            this.txtGross.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtGross, resources.GetString("txtGross.Error"));
            this.txtGross.ForeColor = System.Drawing.Color.Black;
            this.txtGross.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtGross, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtGross.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtGross, ((int)(resources.GetObject("txtGross.IconPadding"))));
            this.txtGross.Name = "txtGross";
            this.txtGross.RequiredField = false;
            this.txtGross.UseCompatibleTextRendering = true;
            this.txtGross.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblExtraServices
            // 
            resources.ApplyResources(this.lblExtraServices, "lblExtraServices");
            this.errProvider.SetError(this.lblExtraServices, resources.GetString("lblExtraServices.Error"));
            this.errProvider.SetIconAlignment(this.lblExtraServices, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExtraServices.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblExtraServices, ((int)(resources.GetObject("lblExtraServices.IconPadding"))));
            this.lblExtraServices.Name = "lblExtraServices";
            this.lblExtraServices.RequiredField = false;
            // 
            // txtTotalDiscount
            // 
            resources.ApplyResources(this.txtTotalDiscount, "txtTotalDiscount");
            this.txtTotalDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtTotalDiscount, resources.GetString("txtTotalDiscount.Error"));
            this.txtTotalDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalDiscount.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtTotalDiscount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTotalDiscount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtTotalDiscount, ((int)(resources.GetObject("txtTotalDiscount.IconPadding"))));
            this.txtTotalDiscount.Name = "txtTotalDiscount";
            this.txtTotalDiscount.RequiredField = false;
            this.txtTotalDiscount.UseCompatibleTextRendering = true;
            this.txtTotalDiscount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblTotalDisc
            // 
            resources.ApplyResources(this.lblTotalDisc, "lblTotalDisc");
            this.errProvider.SetError(this.lblTotalDisc, resources.GetString("lblTotalDisc.Error"));
            this.errProvider.SetIconAlignment(this.lblTotalDisc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalDisc.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTotalDisc, ((int)(resources.GetObject("lblTotalDisc.IconPadding"))));
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.RequiredField = false;
            // 
            // lblTotalTax
            // 
            resources.ApplyResources(this.lblTotalTax, "lblTotalTax");
            this.lblTotalTax.DisabledLinkColor = System.Drawing.Color.Red;
            this.errProvider.SetError(this.lblTotalTax, resources.GetString("lblTotalTax.Error"));
            this.lblTotalTax.Format = null;
            this.errProvider.SetIconAlignment(this.lblTotalTax, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTotalTax.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTotalTax, ((int)(resources.GetObject("lblTotalTax.IconPadding"))));
            this.lblTotalTax.lblAddnlTax = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblCGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblExciseDuty = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblIGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblSGST = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax1 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax2 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblTax3 = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.lblVAT = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.lblTotalTax.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblTotalTax.LinkColor = System.Drawing.Color.Black;
            this.lblTotalTax.Name = "lblTotalTax";
            this.lblTotalTax.TabStop = true;
            this.lblTotalTax.VisitedLinkColor = System.Drawing.Color.Blue;
            // 
            // btnPayment
            // 
            resources.ApplyResources(this.btnPayment, "btnPayment");
            this.btnPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnPayment, resources.GetString("btnPayment.Error"));
            this.btnPayment.FlatAppearance.BorderSize = 0;
            this.btnPayment.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnPayment, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnPayment.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnPayment, ((int)(resources.GetObject("btnPayment.IconPadding"))));
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // txtBalance
            // 
            resources.ApplyResources(this.txtBalance, "txtBalance");
            this.txtBalance.BackColor = System.Drawing.SystemColors.Window;
            this.txtBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtBalance, resources.GetString("txtBalance.Error"));
            this.txtBalance.Format = null;
            this.errProvider.SetIconAlignment(this.txtBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtBalance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtBalance, ((int)(resources.GetObject("txtBalance.IconPadding"))));
            this.txtBalance.isAllowNegative = true;
            this.txtBalance.isAllowSpecialChar = false;
            this.txtBalance.isNumeric = true;
            this.txtBalance.isTouchable = false;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.TabStop = false;
            this.txtBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            // 
            // txtPayment
            // 
            resources.ApplyResources(this.txtPayment, "txtPayment");
            this.txtPayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtPayment, resources.GetString("txtPayment.Error"));
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtPayment, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtPayment.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtPayment, ((int)(resources.GetObject("txtPayment.IconPadding"))));
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.RequiredField = false;
            this.txtPayment.UseCompatibleTextRendering = true;
            this.txtPayment.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBalance
            // 
            resources.ApplyResources(this.lblBalance, "lblBalance");
            this.errProvider.SetError(this.lblBalance, resources.GetString("lblBalance.Error"));
            this.errProvider.SetIconAlignment(this.lblBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblBalance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblBalance, ((int)(resources.GetObject("lblBalance.IconPadding"))));
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.RequiredField = false;
            // 
            // txtNetTotal
            // 
            resources.ApplyResources(this.txtNetTotal, "txtNetTotal");
            this.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtNetTotal, resources.GetString("txtNetTotal.Error"));
            this.txtNetTotal.ForeColor = System.Drawing.Color.Black;
            this.txtNetTotal.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtNetTotal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtNetTotal, ((int)(resources.GetObject("txtNetTotal.IconPadding"))));
            this.txtNetTotal.Name = "txtNetTotal";
            this.txtNetTotal.RequiredField = false;
            this.txtNetTotal.UseCompatibleTextRendering = true;
            this.txtNetTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblNetTotal
            // 
            resources.ApplyResources(this.lblNetTotal, "lblNetTotal");
            this.errProvider.SetError(this.lblNetTotal, resources.GetString("lblNetTotal.Error"));
            this.errProvider.SetIconAlignment(this.lblNetTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblNetTotal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblNetTotal, ((int)(resources.GetObject("lblNetTotal.IconPadding"))));
            this.lblNetTotal.Name = "lblNetTotal";
            this.lblNetTotal.RequiredField = false;
            // 
            // txtTotalTax
            // 
            resources.ApplyResources(this.txtTotalTax, "txtTotalTax");
            this.txtTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtTotalTax, resources.GetString("txtTotalTax.Error"));
            this.txtTotalTax.ForeColor = System.Drawing.Color.Black;
            this.txtTotalTax.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtTotalTax, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTotalTax.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtTotalTax, ((int)(resources.GetObject("txtTotalTax.IconPadding"))));
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.RequiredField = false;
            this.txtTotalTax.UseCompatibleTextRendering = true;
            this.txtTotalTax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator1
            // 
            resources.ApplyResources(this.btnSeperator1, "btnSeperator1");
            this.errProvider.SetError(this.btnSeperator1, resources.GetString("btnSeperator1.Error"));
            this.btnSeperator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.errProvider.SetIconAlignment(this.btnSeperator1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnSeperator1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnSeperator1, ((int)(resources.GetObject("btnSeperator1.IconPadding"))));
            this.btnSeperator1.Name = "btnSeperator1";
            this.btnSeperator1.UseVisualStyleBackColor = true;
            // 
            // lblGrandTotal
            // 
            resources.ApplyResources(this.lblGrandTotal, "lblGrandTotal");
            this.lblGrandTotal.BackColor = System.Drawing.SystemColors.Window;
            this.lblGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.lblGrandTotal, resources.GetString("lblGrandTotal.Error"));
            this.lblGrandTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.lblGrandTotal.Format = "N2";
            this.errProvider.SetIconAlignment(this.lblGrandTotal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblGrandTotal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblGrandTotal, ((int)(resources.GetObject("lblGrandTotal.IconPadding"))));
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.RequiredField = false;
            this.lblGrandTotal.UseCompatibleTextRendering = true;
            this.lblGrandTotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atlblTot
            // 
            resources.ApplyResources(this.atlblTot, "atlblTot");
            this.atlblTot.BackColor = System.Drawing.Color.Transparent;
            this.errProvider.SetError(this.atlblTot, resources.GetString("atlblTot.Error"));
            this.errProvider.SetIconAlignment(this.atlblTot, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atlblTot.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atlblTot, ((int)(resources.GetObject("atlblTot.IconPadding"))));
            this.atlblTot.Name = "atlblTot";
            this.atlblTot.RequiredField = false;
            // 
            // pnlFooter
            // 
            resources.ApplyResources(this.pnlFooter, "pnlFooter");
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.txtAddnlRoundoff);
            this.pnlFooter.Controls.Add(this.lblAdnlRoundoff);
            this.pnlFooter.Controls.Add(this.lblExternal);
            this.pnlFooter.Controls.Add(this.txtExternalAmt);
            this.pnlFooter.Controls.Add(this.lblOpBalance);
            this.pnlFooter.Controls.Add(this.txtOpBalance);
            this.pnlFooter.Controls.Add(this.lblCancelStatus);
            this.pnlFooter.Controls.Add(this.atLabel1);
            this.pnlFooter.Controls.Add(this.btnSeperator1);
            this.pnlFooter.Controls.Add(this.lblBalance);
            this.pnlFooter.Controls.Add(this.txtBalance);
            this.pnlFooter.Controls.Add(this.txtCheckInTotal);
            this.pnlFooter.Controls.Add(this.lblNetTotal);
            this.pnlFooter.Controls.Add(this.txtNetTotal);
            this.pnlFooter.Controls.Add(this.lblAdvance);
            this.pnlFooter.Controls.Add(this.btnRefund);
            this.pnlFooter.Controls.Add(this.txtPayment);
            this.pnlFooter.Controls.Add(this.btnPayment);
            this.pnlFooter.Controls.Add(this.txtRefund);
            this.pnlFooter.Controls.Add(this.txtAdvance);
            this.pnlFooter.Controls.Add(this.lblTotQty);
            this.pnlFooter.Controls.Add(this.totqtycap);
            this.pnlFooter.Controls.Add(this.txtTotalTax);
            this.pnlFooter.Controls.Add(this.lblTotalTax);
            this.pnlFooter.Controls.Add(this.txtGross);
            this.pnlFooter.Controls.Add(this.lblTotalDisc);
            this.pnlFooter.Controls.Add(this.lblExtraServices);
            this.pnlFooter.Controls.Add(this.txtTotalDiscount);
            this.errProvider.SetError(this.pnlFooter, resources.GetString("pnlFooter.Error"));
            this.errProvider.SetIconAlignment(this.pnlFooter, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlFooter.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlFooter, ((int)(resources.GetObject("pnlFooter.IconPadding"))));
            this.pnlFooter.Name = "pnlFooter";
            // 
            // txtAddnlRoundoff
            // 
            resources.ApplyResources(this.txtAddnlRoundoff, "txtAddnlRoundoff");
            this.txtAddnlRoundoff.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddnlRoundoff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtAddnlRoundoff, resources.GetString("txtAddnlRoundoff.Error"));
            this.txtAddnlRoundoff.Format = null;
            this.errProvider.SetIconAlignment(this.txtAddnlRoundoff, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAddnlRoundoff.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtAddnlRoundoff, ((int)(resources.GetObject("txtAddnlRoundoff.IconPadding"))));
            this.txtAddnlRoundoff.isAllowNegative = true;
            this.txtAddnlRoundoff.isAllowSpecialChar = false;
            this.txtAddnlRoundoff.isNumeric = true;
            this.txtAddnlRoundoff.isTouchable = false;
            this.txtAddnlRoundoff.Name = "txtAddnlRoundoff";
            this.txtAddnlRoundoff.Value = new decimal(new int[] {
            0,
            0,
            0,
            131072});
            this.txtAddnlRoundoff.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAddnlRoundoff_KeyUp);
            // 
            // lblAdnlRoundoff
            // 
            resources.ApplyResources(this.lblAdnlRoundoff, "lblAdnlRoundoff");
            this.errProvider.SetError(this.lblAdnlRoundoff, resources.GetString("lblAdnlRoundoff.Error"));
            this.errProvider.SetIconAlignment(this.lblAdnlRoundoff, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdnlRoundoff.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAdnlRoundoff, ((int)(resources.GetObject("lblAdnlRoundoff.IconPadding"))));
            this.lblAdnlRoundoff.Name = "lblAdnlRoundoff";
            this.lblAdnlRoundoff.RequiredField = false;
            // 
            // lblExternal
            // 
            resources.ApplyResources(this.lblExternal, "lblExternal");
            this.lblExternal.DataSource = null;
            this.errProvider.SetError(this.lblExternal, resources.GetString("lblExternal.Error"));
            this.lblExternal.Format = null;
            this.errProvider.SetIconAlignment(this.lblExternal, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExternal.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblExternal, ((int)(resources.GetObject("lblExternal.IconPadding"))));
            this.lblExternal.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblExternal.Name = "lblExternal";
            this.lblExternal.TabStop = true;
            // 
            // txtExternalAmt
            // 
            resources.ApplyResources(this.txtExternalAmt, "txtExternalAmt");
            this.txtExternalAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtExternalAmt, resources.GetString("txtExternalAmt.Error"));
            this.txtExternalAmt.ForeColor = System.Drawing.Color.Black;
            this.txtExternalAmt.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtExternalAmt, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtExternalAmt.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtExternalAmt, ((int)(resources.GetObject("txtExternalAmt.IconPadding"))));
            this.txtExternalAmt.Name = "txtExternalAmt";
            this.txtExternalAmt.RequiredField = false;
            this.txtExternalAmt.UseCompatibleTextRendering = true;
            this.txtExternalAmt.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblOpBalance
            // 
            resources.ApplyResources(this.lblOpBalance, "lblOpBalance");
            this.lblOpBalance.DataSource = null;
            this.errProvider.SetError(this.lblOpBalance, resources.GetString("lblOpBalance.Error"));
            this.lblOpBalance.Format = null;
            this.errProvider.SetIconAlignment(this.lblOpBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblOpBalance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblOpBalance, ((int)(resources.GetObject("lblOpBalance.IconPadding"))));
            this.lblOpBalance.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lblOpBalance.Name = "lblOpBalance";
            this.lblOpBalance.TabStop = true;
            // 
            // txtOpBalance
            // 
            resources.ApplyResources(this.txtOpBalance, "txtOpBalance");
            this.txtOpBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errProvider.SetError(this.txtOpBalance, resources.GetString("txtOpBalance.Error"));
            this.txtOpBalance.ForeColor = System.Drawing.Color.Black;
            this.txtOpBalance.Format = "N2";
            this.errProvider.SetIconAlignment(this.txtOpBalance, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtOpBalance.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtOpBalance, ((int)(resources.GetObject("txtOpBalance.IconPadding"))));
            this.txtOpBalance.Name = "txtOpBalance";
            this.txtOpBalance.RequiredField = false;
            this.txtOpBalance.UseCompatibleTextRendering = true;
            this.txtOpBalance.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblCancelStatus
            // 
            resources.ApplyResources(this.lblCancelStatus, "lblCancelStatus");
            this.lblCancelStatus.BackColor = System.Drawing.Color.Transparent;
            this.errProvider.SetError(this.lblCancelStatus, resources.GetString("lblCancelStatus.Error"));
            this.lblCancelStatus.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblCancelStatus, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCancelStatus.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCancelStatus, ((int)(resources.GetObject("lblCancelStatus.IconPadding"))));
            this.lblCancelStatus.Name = "lblCancelStatus";
            // 
            // atLabel1
            // 
            resources.ApplyResources(this.atLabel1, "atLabel1");
            this.errProvider.SetError(this.atLabel1, resources.GetString("atLabel1.Error"));
            this.errProvider.SetIconAlignment(this.atLabel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atLabel1, ((int)(resources.GetObject("atLabel1.IconPadding"))));
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            // 
            // CheckOutView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.pnlGrid);
            this.Controls.Add(this.pnlMain);
            this.Name = "CheckOutView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.CheckOutView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.CheckOutView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.CheckOutView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.CheckOutView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.CheckOutView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.CheckOutView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.CheckOutView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.CheckOutView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.CheckOutView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.CheckOutView_atValidate);
            this.atPrint += new atACCFramework.BaseClasses.OnPrintEventHandler(this.CheckOutView_atPrint);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.CheckOutView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.CheckOutView_atBeforeSearch);
            this.Shown += new System.EventHandler(this.CheckOutView_Shown);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlGrid, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlFooter, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindExtraServiceDTL)).EndInit();
            this.pnlFooter.ResumeLayout(false);
            this.pnlFooter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atUpDown txtVoucherNo;
        private atACCFramework.UserControls.atDateTimePicker dtVoucherDate;
        private atACCFramework.UserControls.atLabel lblVoucherNo;
        private atACCFramework.UserControls.atLabel lblVoucherDate;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atDateTimePicker dtpArrivalDate;
        private atACCFramework.UserControls.atDateTimePicker dtpDepartureDate;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atLabel lblArrivalDate;
        private atACCFramework.UserControls.ComboBoxExt cmbCheckIn;
        private atACCFramework.UserControls.atLabel lblCheckIn;
        private atACCFramework.UserControls.TextBoxExt txtNoOfDays;
        private atACCFramework.UserControls.atLabel lblNoOfDays;
        private System.Windows.Forms.Label lblMandatory3;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.atPanel pnlGrid;
        private atACCFramework.UserControls.atNumericLabel lblTotQty;
        private atACCFramework.UserControls.atLabel totqtycap;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.atNumericLabel txtAdvance;
        private atACCFramework.UserControls.atLabel lblAdvance;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.atNumericLabel txtGross;
        private atACCFramework.UserControls.atLabel lblExtraServices;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.atNumericLabel txtTotalDiscount;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.atLabel lblTotalDisc;
        private atACCFramework.UserControls.TaxLabel lblTotalTax;
        private atACCFramework.UserControls.atButton btnPayment;
        private atACCFramework.UserControls.TextBoxNormal txtBalance;
        private atACCFramework.UserControls.atNumericLabel txtPayment;
        private atACCFramework.UserControls.atLabel lblBalance;
        private atACCFramework.UserControls.atNumericLabel txtNetTotal;
        private atACCFramework.UserControls.atLabel lblNetTotal;
        private atACCFramework.UserControls.atNumericLabel txtTotalTax;
        private System.Windows.Forms.Button btnSeperator1;
        private atACCFramework.UserControls.atGridView dgDetails;
        private atACCFramework.UserControls.atButton btnRefund;
        private atACCFramework.UserControls.atNumericLabel txtRefund;
        private atACCFramework.UserControls.atNumericLabel lblGrandTotal;
        private atACCFramework.UserControls.atLabel atlblTot;
        private System.Windows.Forms.BindingSource bindExtraServiceDTL;
        private atACCFramework.UserControls.atNumericLabel txtCheckInTotal;
        private atACCFramework.UserControls.TextBoxExt txtRoom;
        private atACCFramework.UserControls.atLabel lblRoom;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private System.Windows.Forms.Button btnCheckIn;
        private atACCFramework.UserControls.atLabel atLabel1;
        private System.Windows.Forms.Label lblCancelStatus;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.atLabel lblCurrencyCap;
        private atACCFramework.UserControls.TextBoxExt txtExRate;
        private atACCFramework.UserControls.ComboBoxExt cmbCurrency;
        private atACCFramework.UserControls.atLabel lblExRateCap;
        private AccountLabel lblExternal;
        private atACCFramework.UserControls.atNumericLabel txtExternalAmt;
        private AccountLabel lblOpBalance;
        private atACCFramework.UserControls.atNumericLabel txtOpBalance;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Service;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExtraServiceID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_InclusiveRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DeductionAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_DiscountSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscountPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SlabDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TotalDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TaxableAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExcisePerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ExciseAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_ExciseSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax1Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX1SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax2Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX2SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Tax3Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_TAX3SlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AddnlTaxAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_AddnlTaxSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_VATAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_VATSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_IGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_FK_GSTSlabID;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_NetAmount;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory4;
        private atACCFramework.UserControls.TextBoxNormal txtAddnlRoundoff;
        private atACCFramework.UserControls.atLabel lblAdnlRoundoff;
    }
}