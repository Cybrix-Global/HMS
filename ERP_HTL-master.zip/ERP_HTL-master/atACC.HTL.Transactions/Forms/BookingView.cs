﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.BaseForms;
using atACC.Common;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.ORM;
using atACC.HTL.Masters;
using System.Data.SqlClient;
using System.IO;
using System.Net.Mail;
using atACC.HTL.Transactions.Sub_Forms;
using atACCFramework;

namespace atACC.HTL.Transactions
{
    public partial class BookingView : SearchFormBase2
    {
        #region Private Variable
        Booking entBooking;
        RoomTypes e_RoomTypes;
        RoomTariffs e_RoomTariffs;
        List<Booking> e_BookingList;
        GuestDTLs e_GuestDTLs;
        Guests entGuest;
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        ToolTip tooltip;
        string NumberFormat, sQtyFormat;
        int AgentLedgerID;
        List<atACC.HTL.ORM.AccountLedger> entGuestAccounts;
        decimal RoomRate = 0, GuestDeduction = 0, AdvanceAmount, TotalAmount;
        List<Employee> entEmployees;
        List<Agent> entAgents;
        List<Guests> entGuestlist;
        List<Rooms> entRooms;
        List<RoomTypes> entRoomTypes;        
        List<BookingPayment> entBookingPaymentList;
        List<BookingPayment> entOldBookingPaymenteList;
        List<CurrencyClass> entCurrencys;
        DateTime? _arrivalDate;
        DateTime? _departureDate;
        int _SelectedRoomID;
        int _BookingId;
        bool _OnLoad;
        GetAccounts getAccc;
        VoucherHDR entVoucherHdrPayment;
        bool blnPartyUnderCashInHand = false;
        ANIHelper aniHelper;
        bool blnSanctioningRequired = false;
        decimal previousExRate;
        int DefaultCreditCard;
        string DefaultCreditCardNumber;
        #endregion

        #region Constructor
        public BookingView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            aniHelper = new ANIHelper();
            getAccc = new GetAccounts();
            objLib = new CommonLibClasses();
            _OnLoad = false;
            ShareButton.Visible = false;

            ToolStripMenuItem mnuSendEmail = new ToolStripMenuItem();
            mnuSendEmail.BackColor = Color.White;
            mnuSendEmail.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendEmail.Text = MessageKeys.MsgSendEmail;
            mnuSendEmail.Image = Properties.Resources.Mail;
            mnuSendEmail.Click += new EventHandler(mnuSendEmail_Click);
            ShareMenu.Items.Add(mnuSendEmail);

            ToolStripMenuItem mnuSendSMS = new ToolStripMenuItem();
            mnuSendSMS.BackColor = Color.White;
            mnuSendSMS.Font = new Font("Open Sans", 10, FontStyle.Regular);
            mnuSendSMS.Text = MessageKeys.MsgSendSMS;
            mnuSendSMS.Image = Properties.Resources.SMS;
            mnuSendSMS.Click += new EventHandler(mnuSendSMS_Click);
            ShareMenu.Items.Add(mnuSendSMS);
        }
        public BookingView(int id) : this()
        {
            _BookingId = id;
        }
        public BookingView(int id, int selectedRoomID) :this()
        {
            _SelectedRoomID = selectedRoomID;
            _BookingId = id;
        }
        public BookingView(int id, int selectedRoomID, DateTime? arrivalDate, DateTime? departureDate) : this()
        {
            _SelectedRoomID = selectedRoomID;
            _BookingId = id;
            _arrivalDate = arrivalDate;
            _departureDate = departureDate;
        }
        #endregion

        #region Overide Methods
        public override void onSettingsClick()
        {
            base.onSettingsClick();
            UserWiseSettingsView settings = new UserWiseSettingsView(1);
            if (settings.ShowDialog() == DialogResult.OK)
            {

            }
        }
        #endregion

        #region Share Methods
        void mnuSendEmail_Click(object sender, EventArgs e)
        {
            SendEmail();
        }
        void mnuSendSMS_Click(object sender, EventArgs e)
        {
            SendSMS();
        }
        private void SendEmail()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (cmbGuest.SelectedValue == null) 
                {
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                    this.Cursor = Cursors.Arrow; 
                    return;
                }
                if (entBooking != null && entBooking.id != null && entBooking.id != 0)
                {
                    string sTo = "";
                    int iGuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                    GuestDTLs _GuDtl = dbh.GuestDTLs.Where(x => x.FK_GuestID == iGuestID).SingleOrDefault();
                    if (_GuDtl != null)
                    {
                        sTo = _GuDtl.Email;
                    }
                    if (sTo.Trim() == "")
                    {
                        MessageBox.Show(MessageKeys.MsgEmailAddressOfGuestMustBeSet);
                        this.Cursor = Cursors.Arrow;
                        return;
                    }
                    string sExportPath = Application.StartupPath + "\\Temp\\Sales_" + txtVoucherNo.Text + ".pdf";
                    string sBody = "";
                    MailHelper _mailHelper = new MailHelper();
                    _mailHelper.sTo = sTo;
                    MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "Email").SingleOrDefault();
                    sBody = _Message.Booking;
                    sBody = sBody.Replace("@VoucherNo", txtVoucherNo.Text)
                    .Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString())
                    .Replace("@GuestName@", cmbGuest.Text)
                    .Replace("@RoomType@", cmbRoomType.Text)
                    .Replace("@Room@", cmbRoom.Text)
                    .Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString())
                    .Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString())
                    .Replace("@NoofDays@", txtNoOfDays.Text)
                    .Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat))
                    .Replace("@Payment@", "")
                    .Replace("@Refund@", "")
                    .Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));

                    _mailHelper.sSubject = MessageKeys.MsgBookingVoucherNo + " : " + txtVoucherNo.Text;
                    _mailHelper.sBody = sBody;
                    if (GlobalFunctions.blnConfirmationForEmail)
                    {
                        EmailConfirmationView emailConfirm = new EmailConfirmationView(_mailHelper.sSubject, _mailHelper.sBody);
                        if (emailConfirm.ShowDialog() == DialogResult.OK)
                        {
                            _mailHelper.sSubject = emailConfirm.sSubject;
                            _mailHelper.sBody = emailConfirm.sBody;
                        }
                        this.Cursor = Cursors.WaitCursor;
                    }
                    if (entBooking.id != 0) 
                    {
                        if (File.Exists(sExportPath))
                        {
                            File.Delete(sExportPath);
                        }
                        PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                        printInvoice.PrintOut("Hotel Booking", entBooking.id, 0, true, sExportPath);
                        if (File.Exists(sExportPath))
                        {
                            _mailHelper.entAttachments.Add(new Attachment(sExportPath)); 
                        }
                    }
                    _mailHelper.SendEmail();
                    if (File.Exists(sExportPath))
                    {
                        File.Delete(sExportPath);
                    }
                    atMessageBox.Show(MessageKeys.MsgMailSendSuccessfully);
                }
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex);
                this.Cursor = Cursors.Arrow;
            }
        }
        private bool SendSMS()
        {
            if (cmbGuest.SelectedValue == null)
            {
                errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                return false;
            }
            if (entBooking == null || entBooking.id == null || entBooking.id != 0)
            {
                atMessageBox.Show(MessageKeys.MsgRecordNotFound);
                return false;
            }
            int iGuestID = cmbGuest.SelectedValue.ToInt32();
            try
            {
                if (cmbGuest.Text.Trim() == "") { return false; }
                if (txtMobile.Text.Trim() == "") { return false; }
                MessageTemplate _Message = dbh.MessageTemplates.Where(x => x.Type == "SMS").SingleOrDefault();
                string sMessage = _Message.Booking;
                sMessage = sMessage.Replace("@VoucherNo", txtVoucherNo.Text);
                sMessage = sMessage.Replace("@VoucherDate", dtVoucherDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@GuestName@", cmbGuest.Text);
                sMessage = sMessage.Replace("@RoomType@", cmbRoomType.Text);
                sMessage = sMessage.Replace("@Room@", cmbRoom.Text);
                sMessage = sMessage.Replace("@ArrivalDate@", dtpArrivalDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@DepartureDate@", dtpDepartureDate.Value.ToShortDateString());
                sMessage = sMessage.Replace("@NoofDays@", txtNoOfDays.Text);
                sMessage = sMessage.Replace("@Advance@", txtAdvance.Value.ToString(NumberFormat));
                sMessage = sMessage.Replace("@Payment@", "");
                sMessage = sMessage.Replace("@Refund@", "");
                sMessage = sMessage.Replace("@GrandTotal", lblGrandTotal.Value.ToString(NumberFormat));
                string sResult = SMSHelper.SendSMSBash(txtMobile.Text.Trim(), sMessage);
                MessageBox.Show("SMS : " + sResult);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion

        #region Private Methods
        private void InitControls()
        {
            dtVoucherDate.MaxDate = DateTime.Now.ToEnd();
            dtVoucherDate.MinDate = GlobalFunctions.dtFinancialFromDate.ToBegin();

            dtpArrivalDate.SetCustomFormat();
            dtpDepartureDate.SetCustomFormat();
            dtpArrivalDate.DisbaleShortDateTimeFormat = true;
            dtpDepartureDate.DisbaleShortDateTimeFormat = true;
        }
        private bool IsActiveControl(object ctrl)
        {
            return ActiveControl != null && ActiveControl.Name == ((Control)ctrl).Name;
        }
        private void CalculateSlab(bool blnUpdateDeductionAmount)
        {
            try
            {
                List<Slab> slabs = null;
                int iRoomTypeID = cmbRoomType.SelectedValue.ToInt32();
                int iLastRoomTypeID = (cmbRoomType.Tag ?? 0).ToInt32();
                if (iRoomTypeID != iLastRoomTypeID)
                {
                    slabs = (from rs in dbh.RoomTypeSlabs
                             join s in dbh.Slabs on rs.FK_SlabID equals s.id
                             where rs.FK_RoomTypeID == iRoomTypeID
                             select s).ToList();
                    cmbRoomType.Tag = iRoomTypeID;
                }
                entBooking.Amount = txtGross.Value;
                entBooking.DeductionPerc = txtDeductionPerc.Value;
                entBooking.DeductionAmount = txtDeductionAmount.Value;
                entBooking.CalculateSlabAmount(dbh, slabs, blnUpdateDeductionAmount);
            }
            catch (Exception)
            {
                throw;
            }
        }        
        private void ApplyExRate()
        {
            decimal dcCurrentExRate = txtExRate.Value;
            Booking dtl = entBooking;
            decimal dcExRateChange = ((previousExRate == 0 ? 1 : previousExRate) / (dcCurrentExRate == 0 ? 1 : dcCurrentExRate));
            dtl.Rate = dcExRateChange * dtl.Rate;
            dtl.AdditionalBedRate = dcExRateChange * dtl.AdditionalBedRate;
            dtl.AdditionalPersonRate = dcExRateChange * dtl.AdditionalPersonRate;
            dtl.InclusiveRate = dcExRateChange * dtl.InclusiveRate;
            dtl.Amount = dcExRateChange * dtl.Amount;
            dtl.TaxableAmount = dcExRateChange * dtl.TaxableAmount;
            dtl.SlabDiscount = dcExRateChange * dtl.SlabDiscount;
            dtl.DeductionAmount = dcExRateChange * dtl.DeductionAmount;            
            dtl.ExciseAmount = dcExRateChange * dtl.ExciseAmount;
            dtl.Tax1Amount = dcExRateChange * dtl.Tax1Amount;
            dtl.Tax2Amount = dcExRateChange * dtl.Tax2Amount;
            dtl.Tax3Amount = dcExRateChange * dtl.Tax3Amount;
            dtl.AddnlTaxAmount = dcExRateChange * dtl.AddnlTaxAmount;
            dtl.VATAmount = dcExRateChange * dtl.VATAmount;
            dtl.CGSTAmount = dcExRateChange * dtl.CGSTAmount;
            dtl.SGSTAmount = dcExRateChange * dtl.SGSTAmount;
            dtl.IGSTAmount = dcExRateChange * dtl.IGSTAmount;
            dtl.NetAmount = dcExRateChange * dtl.NetAmount;

            txtRate.Value *= dcExRateChange;
            txtAddPersonRate.Value *= dcExRateChange;
            txtAddBedRate.Value *= dcExRateChange;
            
            foreach(BookingPayment payment in entBookingPaymentList)
            {
                payment.Payment = dcExRateChange * payment.Payment;
            }

            CalcNetTotal();
            previousExRate = txtExRate.Value;
        }
        private void PostVoucher()
        {            
            bool blnNewPaymentRecord = true;
            entVoucherHdrPayment = new VoucherHDR();
            if (!NewRecord)
            {
                if ((entBooking.FK_PaymentVoucherHDRID ?? 0) != 0)
                {
                    entVoucherHdrPayment = dbh.VoucherHDRs.Where(x => x.id == entBooking.FK_PaymentVoucherHDRID).SingleOrDefault();
                    blnNewPaymentRecord = false;
                }
            }
                                   
            int iCashorPartyAccountID = cmbBillingAccount.SelectedValue.ToInt32();            
            blnPartyUnderCashInHand = aniHelper.isUnderCashInHand(iCashorPartyAccountID);
                        
            #region Payment Posting
            List<VoucherDTL> entVoucherDtlsPayment = new List<VoucherDTL>();
            if (entBookingPaymentList.Count() > 0) // Payment Found
            {
                if (entVoucherHdrPayment.id == 0)
                {
                    entVoucherHdrPayment.id = -1;
                }
                //Voucher Hdr Entry
                GlobalMethods.DecorateVoucherHdr(entVoucherHdrPayment, iContextID, "", dtVoucherDate.Value
                    , cmbCurrency.SelectedValue.ToInt32(), 0, txtVoucherNo.Text, "H-BK-PAY");

                decimal dcExRate = txtExRate.Value;
                foreach (BookingPayment payment in entBookingPaymentList)
                {
                    #region isCash
                    if (payment.isCash.toBool()) // Cash Payment
                    {
                        if (!blnPartyUnderCashInHand)
                        {
                            int iCashAccountID = payment.FK_AccountID == null ? (int)ENAccountLedgers.CashAccount_10 : (int)payment.FK_AccountID;
                            string sAccountName = aniHelper.getLedNameFromAccountID(iCashAccountID);
                            // Debit to Cash Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashAccountID, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                            // Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sAccountName, dcExRate, payment.Payment.ToDecimal() * -1, cmbRoom.Text, txtRemarks.Text);
                        }
                    }
                    #endregion

                    #region Non Cash
                    else
                    {
                        int iSelectedBankAccount = (int)payment.FK_AccountID;
                        string sBankName = aniHelper.getLedNameFromAccountID(iSelectedBankAccount);
                        string sRentAccountName = aniHelper.getLedNameFromAccountID(GlobalProperties.RentAccountID);
                        if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.CreditCard)
                        {
                            string sCreditCardReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.CreditCardReceived_16);
                            
                            // Debit to Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * -1, cmbRoom.Text, txtRemarks.Text);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sCreditCardReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                            //Credit From Credit Card Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.CreditCardReceived_16, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.Cheque)
                        {
                            string sChequeReceivedAccountName = aniHelper.getLedNameFromAccountID((int)ENAccountLedgers.ChequesReceived_15);
                            
                            //Debit to Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sRentAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                            if (!blnPartyUnderCashInHand)
                            {
                                // Credit From Party Account
                                GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                            }

                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, sChequeReceivedAccountName, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                            //Credit From Cheque Received
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, (int)ENAccountLedgers.ChequesReceived_15, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                        }
                        else if (payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.DD
                            || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.OnlineBanking || payment.FK_MVInstrumentTypeID == (int)ENMVInstrumentType.EWallet)
                        {
                            //Debit to Bank Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iSelectedBankAccount, cmbBillingAccount.Text, dcExRate, payment.Payment.ToDecimal(), cmbRoom.Text, txtRemarks.Text);
                            //Credit From Party Account
                            GlobalMethods.AddVoucherDtl(entVoucherDtlsPayment, -1, iCashorPartyAccountID, sBankName, dcExRate, payment.Payment.ToDecimal() * (-1), cmbRoom.Text, txtRemarks.Text);
                        }
                    }
                    #endregion
                }
                List<AnalysisDTL> entAnalysisDTLs = new List<AnalysisDTL>();
                GlobalMethods.PostVoucher(blnNewPaymentRecord, entVoucherHdrPayment, entVoucherDtlsPayment, ref dbh, entAnalysisDTLs);
            }
            #endregion


        }
        private void GetSeqNo()
        {
            try
            {
                txtVoucherNo.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Booking, 0, 0, txtVoucherNo.Text, GlobalFunctions.CurrentFiscalPeriodID);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateBooking()
        {
            try
            {
                e_BookingList = dbh.Bookings.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRateType()
        {
            try
            {
                List <RateTypes> rateTypes = dbh.RateTypes.ToList();
                rateTypes.Add(new RateTypes()
                {
                    id = 0,
                    Name = MessageKeys.MsgDefault
                });
                cmbRateType.DataSource = rateTypes.OrderBy(x=>x.id).ToList();
                cmbRateType.DisplayMember = "Name";
                cmbRateType.ValueMember = "id";
                cmbRateType.SelectedIndex = cmbRateType.Items.Count == 1 ? 0 : -1;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Guest
                var entGuests = dbh.Guests.Where(x => x.Active == true).Select(x => new { id = x.id, Name = x.Name }).ToList();
                cmbGuest.DataSource = entGuests;
                cmbGuest.DisplayMember = "Name";
                cmbGuest.ValueMember = "id";
                cmbGuest.SelectedIndex = -1;
                #endregion

                #region BillingAccount
                List<AccountLedger> entDebtors = getAccc.GetAccountLedgers(25);
                cmbBillingAccount.DataSource = entDebtors;
                cmbBillingAccount.DisplayMember = "LedgerName";
                cmbBillingAccount.ValueMember = "id";
                cmbBillingAccount.SelectedIndex = -1;
                #endregion

                #region BookingType
                List<EnquiryBookingType> entEnquiryBookingTypes = dbh.EnquiryBookingTypes.ToList();
                EnquiryBookingType entEnquiryBookingType = new EnquiryBookingType();
                entEnquiryBookingType.id = 0;
                entEnquiryBookingType.Name = MessageKeys.MsgNone;
                entEnquiryBookingTypes.Insert(0, entEnquiryBookingType);
                cmbType.DataSource = entEnquiryBookingTypes;
                cmbType.DisplayMember = "Name";
                cmbType.ValueMember = "id";
                #endregion

                #region GuestType
                List<GuestType> entGuestTypes = dbh.GuestTypes.ToList();
                GuestType entGuestType = new GuestType();
                entGuestType.id = 0;
                entGuestType.Name = MessageKeys.MsgNone;
                entGuestTypes.Insert(0, entGuestType);
                cmbGuestType.DataSource = entGuestTypes;
                cmbGuestType.DisplayMember = "Name";
                cmbGuestType.ValueMember = "id";
                #endregion

                #region Source
                List<Source> entSources = dbh.Sources.ToList();
                Source entSource = new Source();
                entSource.id = 0;
                entSource.Name = MessageKeys.MsgNone;
                entSources.Insert(0, entSource);
                cmbSource.DataSource = entSources;
                cmbSource.DisplayMember = "Name";
                cmbSource.ValueMember = "id";
                #endregion

                #region Agent
                entAgents = dbh.Agents.Where(x => x.Status == 1).ToList();
                Agent entAgent = new Agent();
                entAgent.id = 0;
                entAgent.Name = MessageKeys.MsgNone;
                entAgents.Insert(0, entAgent);
                cmbAgent.DataSource = entAgents;
                cmbAgent.DisplayMember = "Name";
                cmbAgent.ValueMember = "id";
                #endregion

                #region Employee
                entEmployees = dbh.Employees.Where(x => x.FK_MVEmployeeTypeID == (int)ENMVEmployeeType.Receptionist).Where(x => x.Status == 1).ToList();
                cmbEmployee.DataSource = entEmployees;
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                HTL_LoginUser user = dbh.HTL_LoginUsers.Where(x => x.id == GlobalFunctions.LoginUserID).SingleOrDefault();
                if (user.FK_EmployeeID != null)
                {
                    cmbEmployee.SelectedValue = user.FK_EmployeeID;
                }
                #endregion

                #region Currency
                cmbCurrency.DataSource = entCurrencys;
                cmbCurrency.DisplayMember = "CurrencyName";
                cmbCurrency.ValueMember = "id";
                #endregion

                #region RoomOrHall
                cmbRoomOrHall.Items.Add(MessageKeys.MsgRoom);
                cmbRoomOrHall.Items.Add(MessageKeys.MsgHall);
                #endregion

                PopulateRateType();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void PopulateRoomTypes()
        {
            try
            {
                if (cmbRoomOrHall.Text == MessageKeys.MsgHall)
                {
                    cmbRoomType.DataSource = entRoomTypes.Where(x => x.IsHallType == true).ToList();
                }
                else
                {
                    cmbRoomType.DataSource = entRoomTypes.Where(x => x.IsHallType == false).ToList();
                }
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                if (cmbRoomType.Items.Count == 1)
                {
                    cmbRoomType.SelectedIndex = 0;
                    PopulateRooms();
                }
                else
                {
                    cmbRoomType.SelectedIndex = -1;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRooms()
        {
            try
            {                
                int iRoomTypeID = cmbRoomType.SelectedValue.ToInt32();
                cmbRoom.DataSource = entRooms.Where(x => x.FK_RoomTypeID == iRoomTypeID).ToList();
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
                cmbRoom.SelectedIndex = cmbRoom.Items.Count == 1 ? 0 : -1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateSelectedRoom()
        {
            if (_SelectedRoomID > 0)
            {
                Rooms room = entRooms.Where(x => x.id == _SelectedRoomID).SingleOrDefault();
                if (room != null)
                {
                    ActiveControl = cmbRoomOrHall;
                    cmbRoomOrHall.Text = room.IsHall.Value ? MessageKeys.MsgHall : MessageKeys.MsgRoom;

                    ActiveControl = cmbRoomType;
                    cmbRoomType.SelectedValue = room.FK_RoomTypeID;

                    cmbRoom.SelectedValue = room.id;
                }
            }
            if(_arrivalDate != null && _departureDate != null)
            {

                dtpArrivalDate.Value = new DateTime(_arrivalDate.Value.Year, _arrivalDate.Value.Month, _arrivalDate.Value.Day,
                                                    DateTime.Now.Hour, DateTime.Now.Minute, 0);
                dtpDepartureDate.Value = new DateTime(_departureDate.Value.Year, _departureDate.Value.Month, _departureDate.Value.Day,
                                                    DateTime.Now.Hour, DateTime.Now.Minute, 0);
                txtNoOfDays.Text = GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpDepartureDate.Value).ToString();
                CalcRoomRent();
            }
        }
        private void InitEntities()
        {                                                
            entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).ToList();
            entRoomTypes = dbh.RoomTypes.ToList();
            entRooms = dbh.Rooms.ToList();            
        }
        private void ChangeLabelCaptions()
        {
            try
            {
                if (cmbRoomOrHall.Text == MessageKeys.MsgHall)
                {
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        lblRoomType.Text = MessageKeys.MsgHallType;
                        lblRoom.Text = MessageKeys.MsgHall;
                    }
                    else
                    {
                        lblRoomType.Text = MessageKeys.MsgHallType + " :";
                        lblRoom.Text = MessageKeys.MsgHall + " :";
                    }
                }
                else
                {
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        lblRoomType.Text = MessageKeys.MsgRoomType;
                        lblRoom.Text = MessageKeys.MsgRoom;
                    }
                    else
                    {
                        lblRoomType.Text = MessageKeys.MsgRoomType + " :";
                        lblRoom.Text = MessageKeys.MsgRoom + " :";
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {            
            entBooking = new Booking();
            entBookingPaymentList = new List<BookingPayment>();
            entOldBookingPaymenteList = new List<BookingPayment>();             
            cmbRoomType.Tag = null;            
            errProvider.Clear();
        }
        private void SetDefaultComboValues()
        {
            cmbType.SelectedValue = cmbGuestType.SelectedValue =
                cmbSource.SelectedValue = cmbAgent.SelectedValue = 0;
            
            ActiveControl = cmbRateType;
            cmbRateType.SelectedValue = 0;

            ActiveControl = cmbCurrency;
            cmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;

            ActiveControl = cmbRoomOrHall;
            cmbRoomOrHall.Text = MessageKeys.MsgRoom;
        }
        private void CalcRoomRent()
        {
            if (!_OnLoad)
            {
                if (!ValidateRoomRate() ) 
                {
                    txtRate.Value = 0;
                    txtAddBedRate.Value = 0;
                    txtAddPersonRate.Value = 0;
                    CalcNetTotal();
                    return; 
                }
                
                int iRateTypeId = cmbRateType.SelectedValue.ToInt32();
                int iRoomTypeId =cmbRoomType.SelectedValue.ToInt32();
                e_RoomTariffs = RateCalculationClass.GetTariffs(dbh, iRoomTypeId, iRateTypeId);
                if (e_RoomTariffs != null)
                {
                    txtRate.Value = e_RoomTariffs.BaseRate.ToDecimal() / txtExRate.Value;
                    txtAddBedRate.Value = e_RoomTariffs.ExtraBedRate.ToDecimal() / txtExRate.Value;
                    txtAddPersonRate.Value = e_RoomTariffs.AdditionalPersonRate.ToDecimal() / txtExRate.Value;
                }
                else
                {
                    txtRate.Value = 0;
                    txtAddBedRate.Value = 0;
                    txtAddPersonRate.Value = 0;
                }
                CalcNetTotal();
            }
        }
        private void CalcGrandTotal()
        {
            try
            {
                lblGrandTotal.Value = txtNetTotal.Value;
                txtBalance.Value = lblGrandTotal.Value - txtAdvance.Value;                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool ValidateRoomRate()
        {
            try
            {
                if (cmbRoomType.Text.Trim() == "") { return false; }
                if (cmbRateType.Text.Trim() == "") { return false; }
                if (txtExRate.Value == 0) { return false; }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void CalcNetTotal(bool blnUpdateDeductionAmount = true)
        {
            try
            {
                if (_OnLoad) { return; }
                txtRoomTotal.Value = txtNoOfDays.Value * txtRate.Value;
                txtAddlBedTotal.Value = txtAdditionalBeds.Value * txtAddBedRate.Value;
                txtAddlPsnTotal.Value = txtAddPersons.Value * txtAddPersonRate.Value;
                txtGross.Value = txtRoomTotal.Value + txtAddlBedTotal.Value + txtAddlPsnTotal.Value;

                CalculateSlab(blnUpdateDeductionAmount);

                if (!blnUpdateDeductionAmount)
                {
                    txtDeductionPerc.Value = entBooking.DeductionPerc.ToDecimal();
                }
                else
                {
                    txtDeductionAmount.Value = entBooking.DeductionAmount.ToDecimal();
                }
                txtGross.Value = entBooking.Amount.ToDecimal();
                txtTotalDiscount.Value = entBooking.SlabDiscount.ToDecimal() + entBooking.DeductionAmount.ToDecimal();
                lblTotalTax.lblTax1 = entBooking.Tax1Amount.ToDecimal();
                lblTotalTax.lblTax2 = entBooking.Tax2Amount.ToDecimal();
                lblTotalTax.lblTax3 = entBooking.Tax3Amount.ToDecimal();
                lblTotalTax.lblAddnlTax = entBooking.AddnlTaxAmount.ToDecimal();
                lblTotalTax.lblExciseDuty = entBooking.ExciseAmount.ToDecimal();
                lblTotalTax.lblVAT = entBooking.VATAmount.ToDecimal();
                lblTotalTax.lblCGST = entBooking.CGSTAmount.ToDecimal();
                lblTotalTax.lblSGST = entBooking.SGSTAmount.ToDecimal();
                lblTotalTax.lblIGST = entBooking.IGSTAmount.ToDecimal();
                txtTotalTax.Value = lblTotalTax.TotalTax;
                txtNetTotal.Value = (txtGross.Value + txtTotalTax.Value) - txtTotalDiscount.Value;                
                CalcGrandTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CalcPaymentTotal()
        {
            try
            {
                txtAdvance.Value = entBookingPaymentList.Sum(x => x.Payment).ToDecimal();
                txtBalance.Value = lblGrandTotal.Value - txtAdvance.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTips()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                tooltip.SetToolTip(txtNoOfDays, MessageKeys.MsgNumberOfDays);
                tooltip.SetToolTip(txtAdult, MessageKeys.MsgAdult);
                tooltip.SetToolTip(cmbRoomOrHall, MessageKeys.MsgRoomOrHallMustBeChosen);
                tooltip.SetToolTip(cmbRoomType, MessageKeys.MsgRoomTypeMustBeChosen);
                tooltip.SetToolTip(cmbRoom, MessageKeys.MsgRoomMustBeChosen);
                tooltip.SetToolTip(cmbRateType, MessageKeys.MsgRateTypeMustBeChosen);
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void LoadSettings()
        {
            try
            {
                NumberFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimals;
                sQtyFormat = GlobalFunctions.NmChar + GlobalFunctions.CompanyNoofDecimalsQty;

                txtRate.Format = NumberFormat;
                txtDeductionPerc.Format = NumberFormat;
                txtDeductionAmount.Format = NumberFormat;

                txtGross.Format = NumberFormat;
                txtTotalTax.Format = NumberFormat;
                txtTotalDiscount.Format = NumberFormat;

                txtNetTotal.Format = NumberFormat;
                txtAdvance.Format = NumberFormat;
                txtBalance.Format = NumberFormat;
                lblGrandTotal.Format = NumberFormat;
                txtAdditionalBeds.Format = txtAddBedRate.Format = NumberFormat;
                txtAddPersons.Format = txtAddPersonRate.Format = NumberFormat;
                lblTotalTax.Format = NumberFormat;
                txtExRate.Format = NumberFormat;

                lblCurrencyCap.Visible = GlobalFunctions.blnMultiCurrency;
                cmbCurrency.Visible = GlobalFunctions.blnMultiCurrency;
                lblExRateCap.Visible = GlobalFunctions.blnMultiCurrency;
                txtExRate.Visible = GlobalFunctions.blnMultiCurrency;
                lblMandatory11.Visible = GlobalFunctions.blnMultiCurrency;
            }
            catch (Exception)
            {
                throw;
            }
        }        
        private void SetDefaultDateAndTime()
        {
            try
            {
                dtpArrivalDate.Value = GlobalMethods.GetDefaultArrivalTime();
                dtpDepartureDate.Value = GlobalMethods.GetDefaultDepartureTime(dtpArrivalDate.Value);
                txtNoOfDays.Value = 1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ClearGuestInfo()
        {
            txtTelephone.Text = "";
            cmbBillingAccount.SelectedIndex = -1;
            txtMobile.Text = "";
            txtAdd1.Text = "";
            entGuest = new Guests();
            e_GuestDTLs = new GuestDTLs();
            DefaultCreditCard = 0;
            DefaultCreditCardNumber = string.Empty;
        }
        private void LoadGuestInfo(Int64 Guestid)
        {
            try
            {
                entGuest = dbh.Guests.Where(x => x.id == Guestid).SingleOrDefault();
                e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == Guestid).SingleOrDefault();
                if (entGuest != null && e_GuestDTLs != null)
                {
                    txtTelephone.Text = e_GuestDTLs.Telephone;
                    txtMobile.Text = e_GuestDTLs.Mobile;
                    txtAdd1.Text = e_GuestDTLs.Address1;
                    DefaultCreditCard = e_GuestDTLs.FK_CreditCardType.ToInt32();
                    DefaultCreditCardNumber = e_GuestDTLs.CreditCardNo.ToString();
                    if (NewRecord)
                    {
                        if (txtDeductionPerc.Value != e_GuestDTLs.DiscountPerc.Value)
                        {
                            if (atMessageBox.Show(MessageKeys.MsgDoYouWantApplyDedcutionPercentage, MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                txtDeductionPerc.Value = e_GuestDTLs.DiscountPerc.Value;
                            }
                        }
                    }
                    if (cmbGuest.SelectedValue.ToInt32() != entBooking.FK_GuestID)
                    {
                        cmbBillingAccount.SelectedValue = entGuest.FK_AccountID.ToString().ToInt32();
                        cmbCurrency.SelectedValue = entGuest.FK_CurrencyHDRID.ToInt32();
                    }
                    else
                    {
                        cmbBillingAccount.SelectedValue = entBooking.FK_BillingAccountID;
                        cmbCurrency.SelectedValue = entBooking.FK_CurrencyHdrID;
                        txtExRate.Value = entBooking.ExRate.ToDecimal();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        #endregion

        #region Public Methods
        public override void LoadVouchers()
        {
            try
            {
                string sTempVno = txtVoucherNo.Text;
                dbh = atHotelContext.CreateContext();
                List<UpDownData> _Vouchers = dbh.Bookings.OrderByDescending(x => x.id)
                    .Where(x => (GlobalFunctions.blnLockBranch == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .Where(x => x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID)
                    .Select(x => new UpDownData { id = x.id, Value = x.VoucherNo }).ToList();
                txtVoucherNo.Items.Clear();
                txtVoucherNo.DataSource = _Vouchers;
                if (_Vouchers.Count > 0) { txtVoucherNo.SelectedIndex = 0; }
                txtVoucherNo.Text = sTempVno;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public override void ReLoadData(string VoucherNo)
        {
            Booking booking = dbh.Bookings.Where(x => x.VoucherNo == VoucherNo &&
                                        x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID).SingleOrDefault();
            if (booking != null)
            {
                ReLoadData(booking.id);
                onPopulate();
                AfterOnPopulate();
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                FnClearAll();
                dbh = atHotelContext.CreateContext();

                entBooking = dbh.Bookings.Where(x => x.id == ID).SingleOrDefault();
                if (entBooking != null)
                {
                    #region Add Inactive Accounts
                    #region Employee
                    if (entBooking.FK_EmployeeID != null) 
                    {
                        if (entEmployees.Where(x => x.id == entBooking.FK_EmployeeID).ToList().Count == 0)
                        {
                            Employee _Employee = new Employee();
                            _Employee = dbh.Employees.Where(x => x.id == entBooking.FK_EmployeeID).SingleOrDefault();
                            entEmployees.Add(_Employee);
                            objLib.fnFillCombo(ref cmbEmployee, entEmployees, "Name", "id");
                        }
                    }
                    #endregion

                    #region Agent
                    if (entBooking.FK_AgentID != null)
                    {
                        if (entAgents.Where(x => x.id == entBooking.FK_AgentID).ToList().Count == 0)
                        {
                            Agent _Agent = new Agent();
                            _Agent = dbh.Agents.Where(x => x.id == entBooking.FK_AgentID).SingleOrDefault();
                            entAgents.Add(_Agent);
                            objLib.fnFillCombo(ref cmbAgent, entAgents, "Name", "id");
                        }
                    }
                    #endregion
                    #endregion

                    NewRecord = false;
                    _OnLoad = true;
                    #region Bookings Data
                    txtVoucherNo.Text = entBooking.VoucherNo;
                    dtVoucherDate.Value = entBooking.VoucherDate.Value;
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = entBooking.FK_GuestID;

                    cmbBillingAccount.SelectedValue = entBooking.FK_BillingAccountID;
                    cmbCurrency.SelectedValue = entBooking.FK_CurrencyHdrID ?? cmbCurrency.SelectedValue;
                    txtExRate.Value = entBooking.ExRate.ToDecimal();
                    if (entBooking.Type != null)
                    {
                        cmbType.Text = entBooking.Type;
                    }
                    else
                    {
                        cmbType.Text = MessageKeys.MsgNone;
                    }
                    if (entBooking.GuestType != null)
                    {
                        cmbGuestType.Text = entBooking.GuestType;
                    }
                    else
                    {
                        cmbGuestType.Text = MessageKeys.MsgNone;
                    }
                    if (entBooking.Source != null)
                    {
                        cmbSource.Text = entBooking.Source;
                    }
                    else
                    {
                        cmbSource.Text = MessageKeys.MsgNone;
                    }
                    if (entBooking.FK_AgentID != null)
                    {
                        cmbAgent.SelectedValue = entBooking.FK_AgentID;
                    }
                    else
                    {
                        cmbAgent.SelectedValue = 0;
                    }
                    if (entBooking.FK_EmployeeID != null)
                    {
                        cmbEmployee.SelectedValue = entBooking.FK_EmployeeID;
                    }
                    else
                    {
                        cmbEmployee.SelectedIndex = -1;
                    }
                    txtRemarks.Text = entBooking.Remarks;


                    dtpArrivalDate.Text = entBooking.ArrivalDate.Value.ToString();
                    dtpDepartureDate.Text = entBooking.DepartureDate.Value.ToString();
                    txtNoOfDays.Text = entBooking.NoofDays.ToString();
                    txtAdult.Value = entBooking.Adult.Value;
                    txtChild.Value = entBooking.Child.Value;

                    ActiveControl = cmbRoomOrHall;
                    cmbRoomOrHall.Text = entBooking.RoomorHall == 1 ? MessageKeys.MsgHall : MessageKeys.MsgRoom;

                    ActiveControl = cmbRoomType;
                    cmbRoomType.SelectedValue = entBooking.FK_RoomTypeID;
                    cmbRoomType.Tag = cmbRoomType.SelectedValue;
                    cmbRoom.SelectedValue = entBooking.FK_RoomID;
                    if (entBooking.FK_RateTypeID == null)
                        cmbRateType.SelectedValue = 0;
                    else
                        cmbRateType.SelectedValue = entBooking.FK_RateTypeID;
                    txtRate.Value = entBooking.Rate.Value;
                    txtAddPersons.Value = entBooking.AdditionalPersons.Value;
                    txtAddPersonRate.Value = entBooking.AdditionalPersonRate.Value;
                    txtAddBedRate.Value = entBooking.AdditionalBedRate.Value;
                    txtAdditionalBeds.Value = entBooking.AdditionalBeds.Value;
                    txtDeductionPerc.Value = entBooking.DeductionPerc ?? 0;
                    txtDeductionAmount.Value = entBooking.DeductionAmount ?? 0;
                    txtTotalTax.Value = entBooking.TotalTaxAmount.Value;
                    txtAdvance.Value = entBooking.Advance.Value;
                    txtBalance.Value = entBooking.Balance.Value;
                    #endregion

                    #region Reload Payment Details
                    entBookingPaymentList = dbh.BookingPayments.Where(x => x.FK_BookingID == entBooking.id).ToList();
                    entOldBookingPaymenteList = new List<BookingPayment>(entBookingPaymentList);
                    #endregion
                    _OnLoad = false;
                    CalcPaymentTotal();
                    CalcNetTotal(false);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form event
        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            CheckInView checkInView = new CheckInView(0, 0, entBooking.id);
            checkInView.Show();
        }
        private void cmbGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    cmbGuest.SelectedValue = frm.SelectedGuestID;
                    cmbGuest.Text = frm.SelectedGuestName;
                    cmbGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurrency.ValueMember == "") { return; }
                if (cmbCurrency.SelectedValue == null) { return; }
                int iCurrencyID = cmbCurrency.SelectedValue.ToString2().ToInt32();

                CurrencyClass entCurrency = entCurrencys.Where(x => x.id == iCurrencyID).Single();
                Company company = dbh.Companies.Single();
                int _sourcecurrencyId = company.FK_Currency.toInt32();
                int _destinationCurrencyID = entCurrency.id;
                if (_sourcecurrencyId == _destinationCurrencyID)
                {
                    txtExRate.Enabled = false;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
                txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                ApplyExRate();
            }
            catch (Exception) { }
        }
        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {

        }
        private void btnNewType_Click(object sender, EventArgs e)
        {
            EnquiryBookingTypeView EnquiryBookingType = new EnquiryBookingTypeView();
            EnquiryBookingType.ShowDialog();
            cmbType.DataSource = GlobalMethods.GetEnquiryBookingTypes();
            cmbType.SelectedValue = EnquiryBookingType.CurrentID;
            cmbType.Focus();
        }
        private void txtVoucherNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dbh = atHotelContext.CreateContext();
                int _id = dbh.Bookings
                    .Where(x => x.VoucherNo == txtVoucherNo.Text
                    && x.FinancialPeriodID == GlobalFunctions.CurrentFiscalPeriodID
                    ).Select(x => x.id).FirstOrDefault();
                if (_id != 0)
                {
                    ReLoadData(_id);
                    onPopulate();
                    AfterOnPopulate();
                }
                else
                {
                    string sEnteredVNO = txtVoucherNo.Text;
                    NewClick();
                    txtVoucherNo.Text = sEnteredVNO;
                    cmbGuest.Focus();
                    e.Handled = true;
                }
            }
        }        
        private void cmbGuest_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (!IsActiveControl(sender)) { return; }
                ClearGuestInfo();
                LoadGuestInfo(cmbGuest.SelectedValue.ToInt32());
                CalcNetTotal();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private void txtAdult_KeyUp(object sender, KeyEventArgs e)
        {


            if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab && cmbRateType.Text.Trim() != null)
            {
                CalcNetTotal();
            }
        }
        private void cmbRateType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (IsActiveControl(sender))
                CalcRoomRent();
        }
        private void cmbHall_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (IsActiveControl(sender))
                {
                    PopulateRoomTypes();
                    ChangeLabelCaptions();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbRoomType_SelectedValueChanged(object sender, EventArgs e)
        {
            if (IsActiveControl(sender))
            {
                PopulateRooms();
                CalcRoomRent();
            }
        }
        private void btnAdvance_Click(object sender, EventArgs e)
        {

            BookingPaymentView payment = new BookingPaymentView(entBookingPaymentList, lblGrandTotal.Value, NumberFormat, DefaultCreditCard, DefaultCreditCardNumber);
            if (payment.ShowDialog() == DialogResult.OK)
            {
                CalcPaymentTotal();
                CalcGrandTotal();
            }
            else
            {
                cmbGuest.Focus();
            }
        }
        private void dtpArrivalDate_ValueChanged(object sender, EventArgs e)
        {
            if (this.IsActiveControl(sender, true))
            {
                txtNoOfDays.Text = GlobalMethods.GetNoOfDays(dtpArrivalDate.Value, dtpDepartureDate.Value).ToString();
                CalcRoomRent();
            }
        }
        private void txtRate_TextChanged(object sender, EventArgs e)
        {
            if (IsActiveControl(sender))
                CalcNetTotal();
        }
        private void txtDeductionPerc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab)
            {
                CalcNetTotal();
            }
        }
        private void txtDeductionAmount_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter && e.KeyCode != Keys.Tab)
            {
                if (txtRate.Value == 0)
                {
                    errProvider.SetError(txtRate, MessageKeys.MsgRateMustBeGreaterThanZero);
                    txtRate.Focus();
                    return;
                }
                CalcNetTotal(false);
            }
        }
        private void txtAdditionalBeds_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void txtAddBedRate_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void txtAddPersons_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void txtAddPersonRate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtAddlPsnTotal.Value = txtAddPersons.Value * txtAddPersonRate.Value;
                CalcNetTotal();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewGuestType_Click(object sender, EventArgs e)
        {
            try
            {
                GuestTypeView guestType = new GuestTypeView();
                guestType.ShowDialog();
                cmbGuestType.DataSource = GlobalMethods.GetGuestTypes();
                cmbGuestType.SelectedValue = guestType.CurrentID;
                cmbGuestType.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewSource_Click(object sender, EventArgs e)
        {
            try
            {
                SourceView Source = new SourceView();
                Source.ShowDialog();
                cmbSource.DataSource = GlobalMethods.GetSources();
                cmbSource.SelectedValue = Source.CurrentID;
                cmbSource.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewGuest_Click_1(object sender, EventArgs e)
        {
            try
            {
                GuestView guestView = new GuestView(true);
                guestView.EditButton.Visible = false;
                guestView.SearchButton.Visible = false;
                if (guestView.ShowDialog() == DialogResult.OK)
                {
                    cmbGuest.DataSource = GlobalMethods.GetGuests();
                    ActiveControl = cmbGuest;
                    cmbGuest.SelectedValue = guestView.CurrentID;

                    List<AccountLedger> entDebtors = getAccc.GetAccountLedgers(25);
                    cmbBillingAccount.DataSource = entDebtors;
                    cmbBillingAccount.DisplayMember = "LedgerName";
                    cmbBillingAccount.ValueMember = "id";
                    cmbBillingAccount.SelectedIndex = -1;                    
                    cmbType.Focus();
                }
                else
                {
                    cmbGuest.Focus();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtExRate_Enter(object sender, EventArgs e)
        {
            previousExRate = txtExRate.Value;
        }
        private void txtExRate_KeyUp(object sender, KeyEventArgs e)
        {
            ApplyExRate();
        }
        
        #endregion

        #region Framework events
        private void BookingView_atInitialise()
        {
            try
            {
                InitEntities();
                InitControls();
                LoadSettings();
                ShowToolTips();
                PopulateCombos();
                ShareButton.Visible = true;
                SettingsButton.Visible = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void BookingView_atAfterInitialise()
        {
            try
            {
                _OnLoad = false;
                BookingView_atNewClick(null);
                
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    pnlflow.Location = new Point(pnlflow.Location.X - 20, 2);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void BookingView_atNewClick(object source)
        {
            try
            {
                PopulateBooking();                
                FnClearAll();
                ClearGuestInfo();
                SetDefaultDateAndTime();
                SetDefaultComboValues();
                GetSeqNo();
                CalcNetTotal();                
                cmbGuest.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool BookingView_atValidate(object source)
        {
            try
            {
                if (txtVoucherNo.Text.Trim() == "") 
                { 
                    errProvider.SetError(txtVoucherNo, MessageKeys.MsgVoucherNumberCannotBeBlank); 
                    txtVoucherNo.Focus(); 
                    return false; 
                }
                if (cmbGuest.Text.Trim() == "") 
                { 
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen); 
                    cmbGuest.Focus();
                    return false; 
                }
                if (cmbBillingAccount.Text.Trim() == "")
                { 
                    errProvider.SetError(cmbBillingAccount, MessageKeys.MsgBillingAccountMustBeChosen); 
                    cmbBillingAccount.Focus(); 
                    return false; 
                }
                if (cmbEmployee.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEmployee, MessageKeys.MsgEmployeeMustBeChosen);
                    cmbEmployee.Focus();
                    return false;
                }
                if (txtNoOfDays.Text.Trim() == "") 
                { 
                    errProvider.SetError(dtpArrivalDate, MessageKeys.MsgNumberofDaysMustBeEntered); 
                    dtpArrivalDate.Focus(); 
                    return false; 
                }
                if (txtNoOfDays.Value <= 0) 
                { 
                    errProvider.SetError(txtNoOfDays, MessageKeys.MsgNumberofDaysMustBeGreaterThanZero); 
                    txtNoOfDays.Focus(); 
                    return false; 
                }
                if (txtAdult.Text.Trim() == "") 
                { 
                    errProvider.SetError(txtAdult, MessageKeys.MsgNumberOfAdultsMustBeEntered); 
                    txtAdult.Focus(); 
                    return false; 
                }
                if (txtAdult.Value == 0)
                {
                    errProvider.SetError(txtAdult, MessageKeys.MsgValueMustBeGreaterThanZero);
                    txtAdult.Focus();
                    return false;
                }
                int iRoomType = cmbRoomType.SelectedValue.ToInt32();
                e_RoomTypes = entRoomTypes.Where(x => x.id == iRoomType).SingleOrDefault();
                if (txtAdult.Text.ToInt32() > e_RoomTypes.AdultOccupancy) 
                { 
                    errProvider.SetError(txtAdult, MessageKeys.MsgNumberOfAdultsExceededRoomOccupancy + " ( " + e_RoomTypes.AdultOccupancy + " ) "); 
                    txtAdult.Focus();
                    return false; 
                }
                if (cmbRoomOrHall.Text.Trim() == "") 
                { 
                    errProvider.SetError(cmbRoomOrHall, MessageKeys.MsgRoomOrHallMustBeChosen); 
                    cmbRoomOrHall.Focus(); 
                    return false; 
                }
                if (cmbRoomType.Text.Trim() == "") 
                { 
                    errProvider.SetError(cmbRoomType, MessageKeys.MsgRoomTypeMustBeChosen); 
                    cmbRoomType.Focus(); 
                    return false; 
                }
                if (cmbRoom.Text.Trim() == "") 
                { 
                    errProvider.SetError(cmbRoom, MessageKeys.MsgRoomMustBeChosen); 
                    cmbRoom.Focus(); 
                    return false;
                }
                if (cmbRateType.Text.Trim() == "") 
                { 
                    errProvider.SetError(cmbRateType, MessageKeys.MsgRateTypeMustBeChosen); 
                    cmbRateType.Focus(); 
                    return false; 
                }
                if (txtRate.Text.Trim() == "")
                {
                    errProvider.SetError(txtRate, MessageKeys.MsgRateMustBeEntered);
                    txtAdult.Focus();
                    return false;
                }
                if (txtRate.Value == 0)
                {
                    errProvider.SetError(txtRate, MessageKeys.MsgRateMustBeGreaterThanZero);
                    txtAdult.Focus();
                    return false;
                }
                int _RoomType = cmbRoomType.SelectedValue.ToInt32();
                RoomTypes roomtype = entRoomTypes.Where(x => x.id == _RoomType).SingleOrDefault();
                int AllowedAddBed = roomtype.MaxExtraBeds.toInt32();
                if (txtAdditionalBeds.Value > AllowedAddBed)
                {
                    errProvider.SetError(txtAdditionalBeds, MessageKeys.MsgAllowedNumberOfAdditionalBedsExceeded);
                    txtAdditionalBeds.Focus();
                    return false;
                }
                if (GlobalFunctions.blnMultiCurrency)
                {
                    if (cmbCurrency.SelectedValue == null) 
                    { 
                        errProvider.SetError(cmbCurrency, MessageKeys.MsgCurrencyMustBeSelected); 
                        cmbCurrency.Focus(); 
                        return false; 
                    }
                    if (txtExRate.Value == 0)
                    {
                        errProvider.SetError(txtExRate, MessageKeys.MsgExchangeRate + " " + MessageKeys.MsgValueMustBeGreaterThanZero);
                        txtExRate.Focus();
                        return false;
                    }
                }

                List<Rooms> rooms = GlobalMethods.GetAvailableRooms(dtpArrivalDate.Value, dtpDepartureDate.Value, 
                                                                    ENMVMTTransactionType.HTL_Booking, entBooking.id);
                int iRoomID = cmbRoom.SelectedValue.ToInt32();
                if (!rooms.Where(x => x.id == iRoomID).Any())
                {
                    errProvider.SetError(cmbRoom, "Room not available.");
                    cmbRoom.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Process(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool BookingView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    dbh = atHotelContext.CreateContext();
                    GetSeqNo();
                }
                #region Voucher Posting
                entBooking.Sanctioned = !blnSanctioningRequired;
                if (!blnSanctioningRequired)
                {
                    PostVoucher();                    
                }
                
                if (!blnSanctioningRequired && entBookingPaymentList.Count() > 0)
                {
                    entBooking.FK_PaymentVoucherHDRID = entVoucherHdrPayment.id;
                }
                else
                {
                    GlobalMethods.DeleteVoucher(entBooking.FK_PaymentVoucherHDRID, ref dbh);
                    entBooking.FK_PaymentVoucherHDRID = null;
                }
                #endregion

                #region Booking Details 
                entBooking.ContextID = iContextID;                
                entBooking.LocationID = GlobalFunctions.LoginLocationID;
                entBooking.LoginUserID = GlobalFunctions.LoginUserID;
                entBooking.VoucherNo = txtVoucherNo.Text;
                entBooking.VoucherDate = dtVoucherDate.Value;
                entBooking.FK_GuestID = cmbGuest.SelectedValue.ToString().ToInt32();
                entBooking.FK_BillingAccountID = cmbBillingAccount.SelectedValue.ToString().ToInt32();
                entBooking.FK_CurrencyHdrID = cmbCurrency.SelectedValue.ToString2().ToInt32();
                entBooking.ExRate = txtExRate.Value;
                if (cmbType.Text != MessageKeys.MsgNone)
                {
                    entBooking.Type = cmbType.Text;
                }
                else 
                {
                    entBooking.Type = null;
                }
                if (cmbGuestType.Text != MessageKeys.MsgNone)
                {
                    entBooking.GuestType = cmbGuestType.Text.ToString();
                }
                else
                {
                    entBooking.GuestType = null;
                }
                if (cmbSource.Text != MessageKeys.MsgNone)
                {
                    entBooking.Source = cmbSource.Text.ToString();
                }
                else
                {
                    entBooking.Source = null;
                }
                if (cmbAgent.Text != MessageKeys.MsgNone && cmbAgent.SelectedValue.ToInt32() != 0)
                {
                    entBooking.FK_AgentID = cmbAgent.SelectedValue.ToString().ToInt32();
                }
                else 
                { 
                    entBooking.FK_AgentID = null; 
                }
                if (cmbEmployee.Text != null && cmbEmployee.SelectedValue.ToInt32() != 0)
                {
                    entBooking.FK_EmployeeID = cmbEmployee.SelectedValue.ToString().ToInt32();
                }
                else 
                { 
                    entBooking.FK_EmployeeID = null; 
                }
                entBooking.Remarks = txtRemarks.Text;
                entBooking.ArrivalDate = dtpArrivalDate.Value;
                entBooking.DepartureDate = dtpDepartureDate.Value;
                entBooking.NoofDays = txtNoOfDays.Text.ToInt32();
                entBooking.Adult = txtAdult.Text.ToInt32();
                entBooking.Child = txtChild.Text.ToInt32();
                if (cmbRoomOrHall.Text == MessageKeys.MsgHall)
                    entBooking.RoomorHall = 1;
                else
                    entBooking.RoomorHall = 0;
                entBooking.FK_RoomTypeID = cmbRoomType.SelectedValue.ToString().ToInt32();
                entBooking.FK_RoomID = cmbRoom.SelectedValue.ToString().ToInt32();
                if (cmbRateType.Text == MessageKeys.MsgDefault && cmbRateType.SelectedValue.ToInt32() == 0)
                { entBooking.FK_RateTypeID = null; }
                else
                { entBooking.FK_RateTypeID = cmbRateType.SelectedValue.ToString().ToInt32(); }
                entBooking.Rate = txtRate.Value;
                entBooking.AdditionalBedRate = txtAddBedRate.Value;
                entBooking.AdditionalBeds = txtAdditionalBeds.Text.ToInt32();
                entBooking.AdditionalPersonRate = txtAddPersonRate.Value;
                entBooking.AdditionalPersons = txtAddPersons.Text.ToInt32();
                entBooking.DeductionPerc = txtDeductionPerc.Text.ToDecimal();
                entBooking.DeductionAmount = txtDeductionAmount.Text.ToDecimal();
                entBooking.TotalTaxAmount =  txtTotalTax.Text.ToDecimal();
                entBooking.GrandTotal = txtNetTotal.Text.ToDecimal();
                entBooking.Advance = txtAdvance.Text.ToDecimal();
                entBooking.Balance = txtBalance.Text.ToDecimal();
                entBooking.FinancialPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entBooking.Cancelled = false;
                if (NewRecord)
                {
                    dbh.Bookings.AddObject(entBooking);
                }
                else
                {
                    entBooking.ModifiedDate = System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(entBooking, EntityState.Modified);
                }
                #endregion

                #region Removing Deleted Payments
                var p1 = entOldBookingPaymenteList.Select(x => new { id = x.id });
                var p2 = entBookingPaymentList.Select(y => new { id = y.id });
                var deletedpayments = p1.Except(p2);
                foreach (var deletedItem in deletedpayments)
                {
                    BookingPayment delItPay = entOldBookingPaymenteList.Where(x => x.id == deletedItem.id).First();
                    dbh.BookingPayments.DeleteObject(delItPay);
                }
                #endregion

                #region Adding or Updating Payments
                foreach (BookingPayment BookingPayment in entBookingPaymentList)
                {
                    if (BookingPayment.Payment != 0)
                    {
                        BookingPayment.FK_BookingID = entBooking.id;
                        if (BookingPayment.FK_MVInstrumentTypeID == 0)
                        {
                            BookingPayment.FK_MVInstrumentTypeID = null;
                        }
                        if (dbh.BookingPayments.Where(x => x.id == BookingPayment.id).ToList().Count == 0)
                        {
                            dbh.BookingPayments.AddObject(BookingPayment);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(BookingPayment, System.Data.EntityState.Modified);
                        }
                    }
                }
                #endregion

                #region Save to RoomStatusRegister
                GlobalMethods.SaveRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_Booking, entBooking);
                #endregion

                dbh.SaveChanges();

                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_BookingVoucherNo"))
                    {
                        return BookingView_atSaveClick(source, e);
                    }                    
                }
                ExceptionManager.Process(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Save);
                return false;
            }
        }
        private void BookingView_atBeforeInitialise()
        {
            _OnLoad = true;
        }        
        private bool BookingView_atAfterSave(object source)
        {
            try
            {
                if (GlobalProperties.PrintWhileSavingInBooking)
                {
                    PrintClick();
                }
                if (GlobalProperties.SendEmailWhileSavingInBooking)
                {
                    SendEmail();
                }
                if (GlobalProperties.SendSMSWhileSavingInBooking)
                {
                    SendSMS();
                }
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }        
        private void BookingView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vBooking = e_BookingList.Select(x => new { id = x.id, VoucherNo = x.VoucherNo }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vBooking;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }        
        private bool BookingView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vBookings = new { id = 0, VoucherNo = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(vBookings).id);
                }
                else 
                {
                    cmbGuest.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool BookingView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }

        private void BookingView_Shown(object sender, EventArgs e)
        {
            if (_BookingId != 0)
            {
                ReLoadData(_BookingId);
                onPopulate();
            }
            else
            {
                PopulateSelectedRoom();
            }
        }


        private void BookingView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbGuest.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool BookingView_atPrint(object source)
        {
            try
            {
                if (entBooking.id == 0)
                {
                    atMessageBox.Show(MessageKeys.MsgSaveInvoiceBeforePrint, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                PrintInvoiceHelper printInvoice = new PrintInvoiceHelper();
                printInvoice.PrintOut("Hotel Booking", entBooking.id, 0, GlobalProperties.PrintPreview);
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return false;
            }
        }
        private bool BookingView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                GlobalMethods.DeleteRoomStatusRegister(dbh, ENMVMTTransactionType.HTL_Booking, entBooking);
                GlobalMethods.DeleteVoucher(entBooking.FK_PaymentVoucherHDRID, ref dbh);
                foreach (BookingPayment Payment in entBookingPaymentList) //**Delete Payments **
                {
                    dbh.BookingPayments.DeleteObject(Payment);
                }
                dbh.DeleteObject(entBooking);        //**Delete Bookings**
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }            
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Process(ex, ENOperation.Delete);
                return false;
            }
        }
        private void BookingView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
