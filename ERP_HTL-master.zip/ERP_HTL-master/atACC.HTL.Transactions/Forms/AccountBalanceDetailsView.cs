﻿using atACCFramework.BaseClasses;
using System.Data;
using System.Drawing;

namespace atACC.HTL.Transactions
{
    public partial class AccountBalanceDetailsView : FormBase
    {
        public AccountBalanceDetailsView(DataTable dataTable, string sNumberFormat)
        {
            InitializeComponent();
            dgDetails.AutoGenerateColumns = false;
            dgDetails.DataSource = dataTable;
            col_Amount.DefaultCellStyle.Format = sNumberFormat;
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void btnClose_MouseEnter(object sender, System.EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }

        private void btnClose_MouseLeave(object sender, System.EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
    }
}
