﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using System.Data.Objects.SqlClient;
using atACC.CommonMessages;
using atACC.Common;
using atACC.CommonExtensions;
namespace atACC.HTL.Transactions
{
    public partial class EmailConfirmationView : FormBase
    {
        public string sSubject { get; set; }
        public string sBody { get; set; }
        public EmailConfirmationView(string _subject,string _sbody)
        {
            InitializeComponent();
            sSubject = _subject;
            sBody = _sbody;
            txtsubject.Text = _subject;
            txtBody.Text = _sbody;
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            sSubject = txtsubject.Text;
            sBody = txtBody.Text;
            this.DialogResult = DialogResult.OK;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
    }
}
