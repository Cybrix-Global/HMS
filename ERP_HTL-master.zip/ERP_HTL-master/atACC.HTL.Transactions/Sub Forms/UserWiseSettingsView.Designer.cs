﻿namespace atACC.HTL.Transactions.Sub_Forms
{
    partial class UserWiseSettingsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserWiseSettingsView));
            this.btnSeperator2 = new System.Windows.Forms.Button();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.btnClose = new System.Windows.Forms.Button();
            this.lstLoginSettings = new System.Windows.Forms.CheckedListBox();
            this.cmbTransactions = new atACCFramework.UserControls.ComboBoxExt();
            this.lblTransactions = new atACCFramework.UserControls.atLabel();
            this.btnCancel = new atACCFramework.UserControls.atButton();
            this.btnOK = new atACCFramework.UserControls.atButton();
            this.SuspendLayout();
            // 
            // btnSeperator2
            // 
            this.btnSeperator2.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator2, "btnSeperator2");
            this.btnSeperator2.Name = "btnSeperator2";
            this.btnSeperator2.UseVisualStyleBackColor = false;
            // 
            // lblHeading
            // 
            resources.ApplyResources(this.lblHeading, "lblHeading");
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // lstLoginSettings
            // 
            resources.ApplyResources(this.lstLoginSettings, "lstLoginSettings");
            this.lstLoginSettings.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstLoginSettings.FormattingEnabled = true;
            this.lstLoginSettings.Name = "lstLoginSettings";
            // 
            // cmbTransactions
            // 
            this.cmbTransactions.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTransactions.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTransactions.DropDownHeight = 300;
            this.cmbTransactions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbTransactions, "cmbTransactions");
            this.cmbTransactions.FormattingEnabled = true;
            this.cmbTransactions.Name = "cmbTransactions";
            this.cmbTransactions.SelectedValueChanged += new System.EventHandler(this.cmbTransactions_SelectedValueChanged);
            // 
            // lblTransactions
            // 
            resources.ApplyResources(this.lblTransactions, "lblTransactions");
            this.lblTransactions.Name = "lblTransactions";
            this.lblTransactions.RequiredField = false;
            // 
            // btnCancel
            // 
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnOK.FlatAppearance.BorderSize = 0;
            this.btnOK.ForeColor = System.Drawing.Color.White;
            this.btnOK.Name = "btnOK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // UserWiseSettingsView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lblTransactions);
            this.Controls.Add(this.cmbTransactions);
            this.Controls.Add(this.lstLoginSettings);
            this.Controls.Add(this.btnSeperator2);
            this.Controls.Add(this.lblHeading);
            this.Name = "UserWiseSettingsView";
            this.Load += new System.EventHandler(this.UserWiseSettingsView_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSeperator2;
        private atACCFramework.UserControls.atLabel lblHeading;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.CheckedListBox lstLoginSettings;
        private atACCFramework.UserControls.ComboBoxExt cmbTransactions;
        private atACCFramework.UserControls.atLabel lblTransactions;
        private atACCFramework.UserControls.atButton btnCancel;
        private atACCFramework.UserControls.atButton btnOK;
    }
}