﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;
using System.Data.SqlClient;
using atACC.HTL.Masters;
using atACC.HTL.Masters.Classes;
namespace atACC.HTL.Transactions.Sub_Forms
{
    public partial class UserWiseSettingsView : FormBase
    {
        #region Constructor
        public UserWiseSettingsView(int _TransactionID)
        {
            InitializeComponent();
            TransactionID = _TransactionID;
        }
        #endregion

        #region Private Variables
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        List<DefaultUserSetting> entDefaultUserSettings;
        DefaultUserSettingMapping entDefaultUserSettingMapping;
        List<DefaultUserSettingMapping> entDefaultUserSettingMappings;
        int TransactionID;
        #endregion

        #region Populate Events
        private void PopulateCombos()
        {
            var items = new[] {
                      new { Text = "Enquiry", Value = "0" },
                      new { Text = "Booking", Value = "1" },
                      new { Text = "Group Booking", Value = "2" },
                      new { Text = "Check In", Value = "3" },
                      new { Text = "Group Check In", Value = "4" },
                      new { Text = "Check Out", Value = "5" },
                      new { Text = "Group Check Out", Value = "6" },
                      new { Text = "House Keeping", Value = "7" },
                      new { Text = "Laundry", Value = "8" },
                      new { Text = "Room Service", Value = "9" },
                      new { Text = "Complaint Register", Value = "10" },
                      new { Text = "Room Shift", Value = "11" },
                  };
            cmbTransactions.DisplayMember = "Text";
            cmbTransactions.ValueMember = "Value";
            cmbTransactions.DataSource = items;
            cmbTransactions.SelectedIndex = TransactionID;
        }
        private void PopulateDefaultUserSettings(int iUserID)
        {
            entDefaultUserSettings = dbh.DefaultUserSettings.Where(x => x.SettingsName.Contains(cmbTransactions.Text)).OrderBy(x => x.DisplayPosition).ToList();
            lstLoginSettings.Items.Clear();
            entDefaultUserSettingMappings = dbh.DefaultUserSettingMappings.Where(x => x.FK_LoginUserID == iUserID).ToList();
            foreach (DefaultUserSetting loginSetting in entDefaultUserSettings)
            {
                atListBoxItem itm = new atListBoxItem();
                itm.Text = loginSetting.SettingsName;
                itm.Value = loginSetting.id;
                if (entDefaultUserSettingMappings.Where(x => x.FK_DefaultUserSettingsID == loginSetting.id).ToList().Count > 0)
                {
                    lstLoginSettings.Items.Add(itm, true);
                }
                else
                {
                    lstLoginSettings.Items.Add(itm, false);
                }
            }
        }
        #endregion

        #region Form Events
        private void UserWiseSettingsView_Load(object sender, EventArgs e)
        {
            objLib = new CommonLibClasses();
            dbh = atHotelContext.CreateContext();
            PopulateCombos();
            PopulateDefaultUserSettings(GlobalFunctions.LoginLocationID);
            if (cmbTransactions.Text != string.Empty)
            {
                cmbTransactions.Enabled = false;
            }
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                int iSelectedUser = GlobalFunctions.LoginUserID;

                #region Delete
                foreach (DefaultUserSettingMapping mapp in entDefaultUserSettingMappings)
                {
                    dbh.DefaultUserSettingMappings.DeleteObject(mapp);
                }
                #endregion

                #region Save
                for (int i = 0; i < lstLoginSettings.Items.Count; i++)
                {
                    if (lstLoginSettings.GetItemChecked(i))
                    {
                        atListBoxItem itm = (atListBoxItem)lstLoginSettings.Items[i];
                        DefaultUserSettingMapping NewMapp = new DefaultUserSettingMapping();
                        NewMapp.FK_LoginUserID = GlobalFunctions.LoginUserID;
                        NewMapp.FK_DefaultUserSettingsID = itm.Value;
                        NewMapp.Value = 1;
                        dbh.DefaultUserSettingMappings.AddObject(NewMapp);
                    }
                }
                #endregion

                MessageBox.Show(MessageKeys.MsgRecordSavedSuccessfully);
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void cmbTransactions_SelectedValueChanged(object sender, EventArgs e)
        {
            PopulateDefaultUserSettings(GlobalFunctions.LoginLocationID);
        }
        #endregion 
    }
}
