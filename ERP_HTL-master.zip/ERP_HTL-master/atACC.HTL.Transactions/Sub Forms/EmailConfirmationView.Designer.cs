﻿namespace atACC.HTL.Transactions
{
    partial class EmailConfirmationView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmailConfirmationView));
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSeperator2 = new System.Windows.Forms.Button();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.txtsubject = new atACCFramework.UserControls.TextBoxExt();
            this.txtBody = new atACCFramework.UserControls.TextBoxExt();
            this.atPanel1 = new atACCFramework.UserControls.atPanel();
            this.btnCancel = new atACCFramework.UserControls.atButton();
            this.btnOK = new atACCFramework.UserControls.atButton();
            this.atPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // btnSeperator2
            // 
            this.btnSeperator2.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator2, "btnSeperator2");
            this.btnSeperator2.Name = "btnSeperator2";
            this.btnSeperator2.UseVisualStyleBackColor = false;
            // 
            // lblHeading
            // 
            resources.ApplyResources(this.lblHeading, "lblHeading");
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            // 
            // txtsubject
            // 
            this.txtsubject.BackColor = System.Drawing.SystemColors.Window;
            this.txtsubject.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtsubject, "txtsubject");
            this.txtsubject.Format = null;
            this.txtsubject.isAllowNegative = false;
            this.txtsubject.isAllowSpecialChar = false;
            this.txtsubject.isNumbersOnly = false;
            this.txtsubject.isNumeric = false;
            this.txtsubject.isTouchable = true;
            this.txtsubject.Name = "txtsubject";
            this.txtsubject.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtBody
            // 
            this.txtBody.BackColor = System.Drawing.SystemColors.Window;
            this.txtBody.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtBody, "txtBody");
            this.txtBody.Format = null;
            this.txtBody.isAllowNegative = false;
            this.txtBody.isAllowSpecialChar = false;
            this.txtBody.isNumbersOnly = false;
            this.txtBody.isNumeric = false;
            this.txtBody.isTouchable = false;
            this.txtBody.Name = "txtBody";
            this.txtBody.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // atPanel1
            // 
            this.atPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.atPanel1.Controls.Add(this.btnCancel);
            this.atPanel1.Controls.Add(this.btnOK);
            resources.ApplyResources(this.atPanel1, "atPanel1");
            this.atPanel1.ForeColor = System.Drawing.Color.White;
            this.atPanel1.Name = "atPanel1";
            // 
            // btnCancel
            // 
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnOK.FlatAppearance.BorderSize = 0;
            this.btnOK.ForeColor = System.Drawing.Color.White;
            this.btnOK.Name = "btnOK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // EmailConfirmationView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.atPanel1);
            this.Controls.Add(this.txtBody);
            this.Controls.Add(this.txtsubject);
            this.Controls.Add(this.btnSeperator2);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.btnClose);
            this.Name = "EmailConfirmationView";
            this.atPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSeperator2;
        private atACCFramework.UserControls.atLabel lblHeading;
        private atACCFramework.UserControls.TextBoxExt txtsubject;
        private atACCFramework.UserControls.TextBoxExt txtBody;
        private atACCFramework.UserControls.atPanel atPanel1;
        private atACCFramework.UserControls.atButton btnCancel;
        private atACCFramework.UserControls.atButton btnOK;
    }
}