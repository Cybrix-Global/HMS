﻿namespace atACC.HTL.UI
{
    partial class SplashScreenView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SplashScreenView));
            this.lblStat = new System.Windows.Forms.Label();
            this.tmr = new System.Windows.Forms.Timer(this.components);
            this.pcImage = new System.Windows.Forms.PictureBox();
            this.pnlMain = new atACCFramework.UserControls.atGradientPanel();
            ((System.ComponentModel.ISupportInitialize)(this.pcImage)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblStat
            // 
            this.lblStat.AutoSize = true;
            this.lblStat.BackColor = System.Drawing.Color.Transparent;
            this.lblStat.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStat.ForeColor = System.Drawing.Color.Black;
            this.lblStat.Location = new System.Drawing.Point(9, 275);
            this.lblStat.Name = "lblStat";
            this.lblStat.Size = new System.Drawing.Size(17, 18);
            this.lblStat.TabIndex = 0;
            this.lblStat.Text = "...";
            // 
            // tmr
            // 
            this.tmr.Enabled = true;
            this.tmr.Interval = 10;
            this.tmr.Tick += new System.EventHandler(this.tmr_Tick);
            // 
            // pcImage
            // 
            this.pcImage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pcImage.BackColor = System.Drawing.Color.Transparent;
            this.pcImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pcImage.Image = ((System.Drawing.Image)(resources.GetObject("pcImage.Image")));
            this.pcImage.Location = new System.Drawing.Point(0, 0);
            this.pcImage.Name = "pcImage";
            this.pcImage.Size = new System.Drawing.Size(500, 300);
            this.pcImage.TabIndex = 1;
            this.pcImage.TabStop = false;
            this.pcImage.Click += new System.EventHandler(this.pcImage_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.AllowMultiSelect = false;
            this.pnlMain.Angle = 90F;
            this.pnlMain.BottomColor = System.Drawing.Color.Empty;
            this.pnlMain.Controls.Add(this.lblStat);
            this.pnlMain.Controls.Add(this.pcImage);
            this.pnlMain.Location = new System.Drawing.Point(1, 1);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Selected = false;
            this.pnlMain.Size = new System.Drawing.Size(500, 300);
            this.pnlMain.TabIndex = 2;
            this.pnlMain.TextAdjestmentHeight = 0;
            this.pnlMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlMain.TopColor = System.Drawing.Color.Empty;
            // 
            // SplashScreenView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(502, 302);
            this.Controls.Add(this.pnlMain);
            this.Name = "SplashScreenView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SplashScreenView";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SplashScreenView_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pcImage)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblStat;
        private System.Windows.Forms.Timer tmr;
        private System.Windows.Forms.PictureBox pcImage;
        private atACCFramework.UserControls.atGradientPanel pnlMain;
    }
}