﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.UI.UIClasses;
using atACC.Common;
using System.Globalization;
using LocalORM;
using atACC.HTL.Masters;
using atACC.HTL.UI;
using atACC.HTL.ORM;

namespace atACC.HTL.UI
{
    public partial class NumberLoginView : FormBase
    {
        #region Private Variables
        atACCContextEntities db;
        DateTime dtCurrent;
        List<FinanPeriod> financialPeriods;
        List<Branch> branches;
        string UserName;
        #endregion

        #region Constructor
        public NumberLoginView()
        {
            if (GlobalFunctions.LanguageCulture == null)
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentCulture;
            }
            else
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(GlobalFunctions.LanguageCulture);
            }
            db = atContext.CreateContext();
            InitializeComponent();
            this.Icon = UICommon._currentICon;
            pcPoweredBy.BackgroundImage = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.OEMLogo);
            ShowOpenCompany = false;
        }
        #endregion

        #region Public Properties
        public bool ShowOpenCompany { get; set; }
        #endregion

        #region Public Methods
        private void Populations()
        {
            cmbFinancialPeriod.DataSource = financialPeriods;
            cmbFinancialPeriod.DisplayMember = "Name";
            cmbFinancialPeriod.ValueMember = "id";

            cmbLocation.DataSource = branches;
            cmbLocation.DisplayMember = "Name";
            cmbLocation.ValueMember = "id";
        }
        private bool ResetPIN()
        {
            ResetPinNumber reset = new ResetPinNumber();
            if (reset.ShowDialog() == DialogResult.OK)
            {
                txtPIN.Focus();
            }
            return false;
        }
        #endregion

        #region Form Events
        private void NumberLoginView_Activated(object sender, EventArgs e)
        {
            txtPIN.Focus();
        }
        private void NumberLoginView_Load(object sender, EventArgs e)
        {
            if (GlobalFunctions.iCurrentEdition == (int)ENEditions.BasicEdition)
            {
                cmbLocation.Enabled = false;
            }
            dtCurrent = DateTime.Now.ToEnd();
            financialPeriods = db.FinanPeriods.OrderByDescending(x => x.ToDate).ToList();
            branches = db.Branches.Where(x => x.FK_BranchType != (int)ENMVBranchType.Depot).ToList();
            Populations();
            txtPIN.Focus();
        }
        private bool ValidateLogin()
        {
            errProvider.Clear();
            if (txtPIN.Text.Trim() == "") 
            {
                atMessageBox.Show(MessageKeys.MsgPINMustBeEntered);
                return false; 
            }
            if (cmbFinancialPeriod.SelectedValue.ToString2().ToInt32() == 0) { errProvider.SetError(cmbFinancialPeriod,  MessageKeys.MsgFinancialPeriodMustBeSelected); return false; }
            if (cmbLocation.SelectedValue.ToString2().ToInt32() == 0) { errProvider.SetError(cmbLocation, MessageKeys.MsgBranchMustBeSelected); return false; };
            int ifinPeriodID = cmbFinancialPeriod.SelectedValue.ToString2().ToInt32();
            string sMonthAndYear = dtCurrent.ToMonthName() + "-" + dtCurrent.Year;
            List<FinanPeriodDTL> fdtl = (from fis in db.FinanPeriods
                                         join dtl in db.FinanPeriodDTLs on fis.id equals dtl.FK_FinanPeriodID
                                         where (fis.id == ifinPeriodID)
                                         && (dtl.MonthName == sMonthAndYear)
                                         && (dtl.Status == (int)ENMVFinancialYearStatus.Open
                                         && fis.ToDate >= dtCurrent
                                         )
                                         select dtl).ToList();
            GlobalFunctions.CurrentFiscalPeriodID = ifinPeriodID;
            if (fdtl.Count > 0)
            {
                GlobalFunctions.CurrentMonthID = fdtl.FirstOrDefault().id;
            }
            return true;
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
#if DEBUG
            if (txtPIN.Text.Trim() == "")
            {
                UserName = "admin";
                txtPIN.Text = "admin";
            }
#endif
            GlobalFunctions.LoadAutoBackupSettings();
            if (!ValidateLogin()) { return; }
            int EnteredPinNumber = txtPIN.Text.ToInt32();
            if (GlobalFunctions.ANISettings == null)
            {
                GlobalFunctions.ANISettings = db.ANISetings.ToList();
            }
            GlobalFunctions.blnFilterBranchInMasters = GlobalFunctions.GetANISettings((int)ENANISettings.FilterBranchInMasters);
            GlobalFunctions.blnMultiBranchManagement = GlobalFunctions.GetANISettings((int)ENANISettings.MultiBranch);
            LoginUser _currentUser;
            _currentUser = db.LoginUsers.Where(x => x.PINNumber == EnteredPinNumber
                    &&
                    (x.PINNumber == EnteredPinNumber)
                    ).FirstOrDefault();

            if (_currentUser == null)
            {
                atMessageBox.Show(MessageKeys.MsgInvalidPIN);
                UICommon.isLogined = false;
                txtPIN.Focus();
            }
            else
            {
                List<int> entUserLocations = new List<int>();
                if ((GlobalFunctions.blnFilterBranchInMasters || GlobalFunctions.blnMultiBranchManagement)
                    && _currentUser.FK_RoleID != (int)ENUserRole.Administrators
                    && _currentUser.FK_RoleID != (int)ENUserRole.BuiltinAdmin && _currentUser.FK_RoleID != (int)ENUserRole.PowerUsers
                    )
                {
                    GlobalFunctions.LoginLocationID = cmbLocation.SelectedValue.ToString2().ToInt32();
                    ANIHelper _anihelper = new ANIHelper();
                    int iUserLocationID = _currentUser.LocationID.ToInt32();
                    entUserLocations = _anihelper.GetBranchIDs(iUserLocationID);
                    if (!entUserLocations.Contains(GlobalFunctions.LoginLocationID))
                    {
                        atMessageBox.Show(MessageKeys.MsgUserNotFoundOnSelectedBranch);
                        UICommon.isLogined = false;
                        txtPIN.Focus();
                        return;
                    }
                }

                UICommon.isLogined = true;
                LoginUser loginUser = db.LoginUsers.Where(x => x.PINNumber == EnteredPinNumber).SingleOrDefault();
                UserName = loginUser.UserName;

                GlobalFunctions.LoginUserID = loginUser.id;
                GlobalFunctions.LoginLocationID = cmbLocation.SelectedValue.ToString2().ToInt32();
                ANIHelper _anihelp = new ANIHelper();
                GlobalFunctions.entCurrentLocations = _anihelp.GetBranchIDs(GlobalFunctions.LoginLocationID);
                GlobalFunctions.fnLoadANISettings();

                string sMdiCaption = "";
                if (GlobalFunctions.blnModernDashboard)
                {
                    sMdiCaption = MessageKeys.MsgApplicationName + "        Current Company:  " + GlobalFunctions.DatabaseName
                    + "        Financial Period:  " + GlobalFunctions.sfinancialPeriodName
                    + "     Location : " + cmbLocation.Text;
                }
                else
                {
                    sMdiCaption = MessageKeys.MsgApplicationName + "        Current Company:  " + GlobalFunctions.DatabaseName
                    + "        Financial Period:  " + GlobalFunctions.sfinancialPeriodName + "         Login User: " + UserName
                    + "     Location : " + cmbLocation.Text;
                    UICommon.frmMdi.Text = sMdiCaption;
                }
                ANIHelper anihelper = new ANIHelper();
                GlobalFunctions.LoginSessionID = anihelper.GetSessionID(loginUser.id);

                if (GlobalFunctions.sAutoBackupPath != "" && GlobalFunctions.blnBackupWhileLogin)
                {
                    UICommon.AutoBackup(true);
                }

                this.DialogResult = DialogResult.OK;
            }
        }
        private void btnLogin_Paint(object sender, PaintEventArgs e)
        {

        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                btnLogin_Click(sender, e);
            }
        }
        private void lblAboutUs_Click(object sender, EventArgs e)
        {
            HotelAboutUSView abt = new HotelAboutUSView();
            abt.Show();
        }
        private void lblOpenCompany_Click(object sender, EventArgs e)
        {
            ShowOpenCompany = true;
            this.DialogResult = DialogResult.Cancel;
        }
        private void lblForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            atACC.ADM.Tools.AdminVerificationView frmAdm = new atACC.ADM.Tools.AdminVerificationView();
            if (frmAdm.ShowDialog() == DialogResult.OK)
            {
                if (!frmAdm.blnSuccess)
                {
                    return;
                }
                else
                {
                    ResetPIN();
                }
            }
            else
            {
                return;
            }
        }
        private void lblPasswordLogin_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Abort;
        }
        #endregion

        #region Login Button Click
        private void btn1_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "1";
        }
        private void btn2_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "2";
        }
        private void btn3_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "3";
        }
        private void btn4_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "4";
        }
        private void btn5_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "5";
        }
        private void btn6_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "6";
        }
        private void btn7_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "7";
        }
        private void btn8_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "8";
        }
        private void btn9_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "9";
        }
        private void btn0_Click(object sender, EventArgs e)
        {
            txtPIN.Text = txtPIN.Text + "0";
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPIN.Text = string.Empty;
        }
        private void btnBackSpace_Click(object sender, EventArgs e)
        {
            int textlength = txtPIN.Text.Length;
            if (textlength > 0)
            {
                txtPIN.Text = txtPIN.Text.Substring(0, textlength - 1);
            }
            txtPIN.Focus();
            txtPIN.SelectionStart = txtPIN.Text.Length;
            txtPIN.SelectionLength = 0;
        }
        #endregion

        #region Public Events
        private void pnlMain_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = new Point(e.X, e.Y);
        }
        private void pnlMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (downPoint == Point.Empty)
            {
                return;
            }
            Point location = new Point(
                this.Left + e.X - downPoint.X,
                this.Top + e.Y - downPoint.Y);
            this.Location = location;
        }
        private void pnlMain_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = Point.Empty;
        }

        #endregion

        
    }
}
