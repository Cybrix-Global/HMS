﻿namespace atACC.HTL.UI
{
    partial class LoginView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginView));
            this.lblUserName = new atACCFramework.UserControls.atLabel();
            this.txtUserName = new atACCFramework.UserControls.TextBoxExt();
            this.txtPassword = new atACCFramework.UserControls.TextBoxExt();
            this.lblPassword = new atACCFramework.UserControls.atLabel();
            this.lblFinancialPeriod = new atACCFramework.UserControls.atLabel();
            this.cmbFinancialPeriod = new atACCFramework.UserControls.ComboBoxExt();
            this.lblBranch = new atACCFramework.UserControls.atLabel();
            this.errProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.cmbLocation = new atACCFramework.UserControls.ComboBoxExt();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atGradientPanel();
            this.pcPoweredBy = new System.Windows.Forms.PictureBox();
            this.btnPanel = new atACCFramework.UserControls.atPOSButton2();
            this.lblPinLogin = new atACCFramework.UserControls.atLabel();
            this.lblForgotPassword = new System.Windows.Forms.LinkLabel();
            this.lblOpenCompany = new atACCFramework.UserControls.atLabel();
            this.lblAboutUs = new atACCFramework.UserControls.atLabel();
            this.lblLogin = new atACCFramework.UserControls.atLabel();
            this.btnLogin = new atACCFramework.UserControls.atGradientPanel();
            this.lblBtnLogin = new atACCFramework.UserControls.atLabel();
            this.btnSepearator1 = new System.Windows.Forms.Button();
            this.lblLogintoContinue = new atACCFramework.UserControls.atLabel();
            this.pcLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcPoweredBy)).BeginInit();
            this.btnPanel.SuspendLayout();
            this.btnLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblUserName
            // 
            resources.ApplyResources(this.lblUserName, "lblUserName");
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.RequiredField = false;
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtUserName, "txtUserName");
            this.txtUserName.Format = null;
            this.txtUserName.isAllowNegative = false;
            this.txtUserName.isAllowSpecialChar = false;
            this.txtUserName.isNumbersOnly = false;
            this.txtUserName.isNumeric = false;
            this.txtUserName.isTouchable = false;
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtUserName.Validating += new System.ComponentModel.CancelEventHandler(this.txtUserName_Validating);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.Window;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtPassword, "txtPassword");
            this.txtPassword.Format = null;
            this.txtPassword.isAllowNegative = false;
            this.txtPassword.isAllowSpecialChar = false;
            this.txtPassword.isNumbersOnly = false;
            this.txtPassword.isNumeric = false;
            this.txtPassword.isTouchable = false;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblPassword
            // 
            resources.ApplyResources(this.lblPassword, "lblPassword");
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.RequiredField = false;
            // 
            // lblFinancialPeriod
            // 
            resources.ApplyResources(this.lblFinancialPeriod, "lblFinancialPeriod");
            this.lblFinancialPeriod.Name = "lblFinancialPeriod";
            this.lblFinancialPeriod.RequiredField = false;
            // 
            // cmbFinancialPeriod
            // 
            this.cmbFinancialPeriod.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbFinancialPeriod.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbFinancialPeriod.DropDownHeight = 300;
            this.cmbFinancialPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbFinancialPeriod, "cmbFinancialPeriod");
            this.cmbFinancialPeriod.FormattingEnabled = true;
            this.cmbFinancialPeriod.Name = "cmbFinancialPeriod";
            // 
            // lblBranch
            // 
            resources.ApplyResources(this.lblBranch, "lblBranch");
            this.lblBranch.Name = "lblBranch";
            this.lblBranch.RequiredField = false;
            // 
            // errProvider
            // 
            this.errProvider.ContainerControl = this;
            // 
            // cmbLocation
            // 
            this.cmbLocation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbLocation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLocation.DropDownHeight = 300;
            this.cmbLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbLocation, "cmbLocation");
            this.cmbLocation.FormattingEnabled = true;
            this.cmbLocation.Name = "cmbLocation";
            this.cmbLocation.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbLocation_KeyDown);
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.TabStop = false;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // pnlMain
            // 
            this.pnlMain.AllowMultiSelect = false;
            this.pnlMain.Angle = 90F;
            this.pnlMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pnlMain.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.pnlMain.Controls.Add(this.pcPoweredBy);
            this.pnlMain.Controls.Add(this.btnClose);
            this.pnlMain.Controls.Add(this.btnPanel);
            this.pnlMain.Controls.Add(this.pcLogo);
            this.pnlMain.Cursor = System.Windows.Forms.Cursors.Default;
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Selected = false;
            this.pnlMain.TextAdjestmentHeight = 0;
            this.pnlMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlMain.TopColor = System.Drawing.Color.SteelBlue;
            this.pnlMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseDown);
            this.pnlMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseMove);
            this.pnlMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseUp);
            // 
            // pcPoweredBy
            // 
            this.pcPoweredBy.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.pcPoweredBy, "pcPoweredBy");
            this.pcPoweredBy.Name = "pcPoweredBy";
            this.pcPoweredBy.TabStop = false;
            // 
            // btnPanel
            // 
            this.btnPanel.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btnPanel.AllowMultiSelect = false;
            this.btnPanel.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnPanel, "btnPanel");
            this.btnPanel.Color = System.Drawing.Color.White;
            this.btnPanel.Controls.Add(this.lblPinLogin);
            this.btnPanel.Controls.Add(this.lblForgotPassword);
            this.btnPanel.Controls.Add(this.lblOpenCompany);
            this.btnPanel.Controls.Add(this.cmbLocation);
            this.btnPanel.Controls.Add(this.lblAboutUs);
            this.btnPanel.Controls.Add(this.lblBranch);
            this.btnPanel.Controls.Add(this.lblLogin);
            this.btnPanel.Controls.Add(this.cmbFinancialPeriod);
            this.btnPanel.Controls.Add(this.lblFinancialPeriod);
            this.btnPanel.Controls.Add(this.btnLogin);
            this.btnPanel.Controls.Add(this.txtPassword);
            this.btnPanel.Controls.Add(this.btnSepearator1);
            this.btnPanel.Controls.Add(this.lblPassword);
            this.btnPanel.Controls.Add(this.lblLogintoContinue);
            this.btnPanel.Controls.Add(this.txtUserName);
            this.btnPanel.Controls.Add(this.lblUserName);
            this.btnPanel.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnPanel.Disabled = false;
            this.btnPanel.DisabledColor = System.Drawing.SystemColors.InactiveBorder;
            this.btnPanel.Icon = null;
            this.btnPanel.IconAdjestmentHeight = 0;
            this.btnPanel.IconAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPanel.InColor = System.Drawing.Color.White;
            this.btnPanel.Name = "btnPanel";
            this.btnPanel.Selected = false;
            this.btnPanel.SelectTypeButton = false;
            this.btnPanel.TextAdjestmentHeight = 0;
            this.btnPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPinLogin
            // 
            resources.ApplyResources(this.lblPinLogin, "lblPinLogin");
            this.lblPinLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblPinLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPinLogin.ForeColor = System.Drawing.Color.Gray;
            this.lblPinLogin.Name = "lblPinLogin";
            this.lblPinLogin.RequiredField = false;
            this.lblPinLogin.Click += new System.EventHandler(this.lblPinLogin_Click);
            // 
            // lblForgotPassword
            // 
            resources.ApplyResources(this.lblForgotPassword, "lblForgotPassword");
            this.lblForgotPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblForgotPassword.LinkColor = System.Drawing.Color.Navy;
            this.lblForgotPassword.Name = "lblForgotPassword";
            this.lblForgotPassword.TabStop = true;
            this.lblForgotPassword.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblForgotPassword_LinkClicked);
            // 
            // lblOpenCompany
            // 
            resources.ApplyResources(this.lblOpenCompany, "lblOpenCompany");
            this.lblOpenCompany.BackColor = System.Drawing.Color.Transparent;
            this.lblOpenCompany.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblOpenCompany.ForeColor = System.Drawing.Color.Gray;
            this.lblOpenCompany.Name = "lblOpenCompany";
            this.lblOpenCompany.RequiredField = false;
            this.lblOpenCompany.Click += new System.EventHandler(this.lblOpenCompany_Click);
            // 
            // lblAboutUs
            // 
            resources.ApplyResources(this.lblAboutUs, "lblAboutUs");
            this.lblAboutUs.BackColor = System.Drawing.Color.Transparent;
            this.lblAboutUs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAboutUs.ForeColor = System.Drawing.Color.Gray;
            this.lblAboutUs.Name = "lblAboutUs";
            this.lblAboutUs.RequiredField = false;
            this.lblAboutUs.Click += new System.EventHandler(this.lblAboutUs_Click);
            // 
            // lblLogin
            // 
            resources.ApplyResources(this.lblLogin, "lblLogin");
            this.lblLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblLogin.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.RequiredField = false;
            // 
            // btnLogin
            // 
            this.btnLogin.AllowMultiSelect = false;
            this.btnLogin.Angle = 45F;
            this.btnLogin.BackColor = System.Drawing.Color.Aqua;
            this.btnLogin.BottomColor = System.Drawing.Color.RoyalBlue;
            this.btnLogin.Controls.Add(this.lblBtnLogin);
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.btnLogin, "btnLogin");
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Selected = false;
            this.btnLogin.TabStop = true;
            this.btnLogin.TextAdjestmentHeight = 0;
            this.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogin.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(66)))), ((int)(((byte)(5)))));
            this.btnLogin.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblBtnLogin
            // 
            resources.ApplyResources(this.lblBtnLogin, "lblBtnLogin");
            this.lblBtnLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblBtnLogin.ForeColor = System.Drawing.Color.White;
            this.lblBtnLogin.Name = "lblBtnLogin";
            this.lblBtnLogin.RequiredField = false;
            this.lblBtnLogin.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnSepearator1
            // 
            this.btnSepearator1.BackColor = System.Drawing.Color.LightGray;
            this.btnSepearator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSepearator1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSepearator1, "btnSepearator1");
            this.btnSepearator1.Name = "btnSepearator1";
            this.btnSepearator1.UseVisualStyleBackColor = false;
            // 
            // lblLogintoContinue
            // 
            resources.ApplyResources(this.lblLogintoContinue, "lblLogintoContinue");
            this.lblLogintoContinue.BackColor = System.Drawing.Color.Transparent;
            this.lblLogintoContinue.ForeColor = System.Drawing.Color.Gray;
            this.lblLogintoContinue.Name = "lblLogintoContinue";
            this.lblLogintoContinue.RequiredField = false;
            // 
            // pcLogo
            // 
            this.pcLogo.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.pcLogo, "pcLogo");
            this.pcLogo.Name = "pcLogo";
            this.pcLogo.TabStop = false;
            // 
            // LoginView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoginView";
            this.Activated += new System.EventHandler(this.LoginView_Activated);
            this.Load += new System.EventHandler(this.LoginView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcPoweredBy)).EndInit();
            this.btnPanel.ResumeLayout(false);
            this.btnPanel.PerformLayout();
            this.btnLogin.ResumeLayout(false);
            this.btnLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atLabel lblUserName;
        private atACCFramework.UserControls.TextBoxExt txtUserName;
        private atACCFramework.UserControls.TextBoxExt txtPassword;
        private atACCFramework.UserControls.atLabel lblPassword;
        private atACCFramework.UserControls.atLabel lblFinancialPeriod;
        private atACCFramework.UserControls.ComboBoxExt cmbFinancialPeriod;
        private atACCFramework.UserControls.atLabel lblBranch;
        private System.Windows.Forms.ErrorProvider errProvider;
        private atACCFramework.UserControls.ComboBoxExt cmbLocation;
        private System.Windows.Forms.Button btnClose;
        private atACCFramework.UserControls.atGradientPanel pnlMain;
        private System.Windows.Forms.PictureBox pcPoweredBy;
        private atACCFramework.UserControls.atPOSButton2 btnPanel;
        private System.Windows.Forms.LinkLabel lblForgotPassword;
        private atACCFramework.UserControls.atLabel lblOpenCompany;
        private atACCFramework.UserControls.atLabel lblAboutUs;
        private atACCFramework.UserControls.atLabel lblLogin;
        private atACCFramework.UserControls.atGradientPanel btnLogin;
        private atACCFramework.UserControls.atLabel lblBtnLogin;
        private System.Windows.Forms.Button btnSepearator1;
        private atACCFramework.UserControls.atLabel lblLogintoContinue;
        private System.Windows.Forms.PictureBox pcLogo;
        private atACCFramework.UserControls.atLabel lblPinLogin;
    }
}