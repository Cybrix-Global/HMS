﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using atACC.Common;
using atACC.CommonExtensions;
using atACC.CommonMessages;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using AtCryptoGraphy2;
using LocalORM;
namespace atACC.UI
{
    public partial class OneTimeRegistrationWizard : FormBase
    {
        #region Private Variable
        DataTable dtCDKeyToProduct;
        RegistrationHelper regHelper;
        List<Edition> entEditions;
        int iCurrentPanelID;
        AtCryptoGraphy2.AtCryptoGraphy2 _cryptography;
        int iLicenseAvailable;
        ENWizardPanels CurrentPanel;
        string sCDKeyProductName;
        string sEditionTag;
        #endregion
        #region Constructor
        public OneTimeRegistrationWizard()
        {
            InitializeComponent();
            regHelper=new RegistrationHelper();
            _cryptography=new AtCryptoGraphy2.AtCryptoGraphy2();
        }
        #endregion
        #region Private Methods
        private void PopulateEditions()
        {
            using (SettingsDbEntities sdb = new SettingsDbEntities())
            {
                entEditions = sdb.Editions.ToList();
                cmbEditions.DisplayMember = "Name";
                cmbEditions.ValueMember = "id";
                cmbEditions.DataSource = entEditions;
                cmbEditionActivate.DisplayMember = "Name";
                cmbEditionActivate.ValueMember = "id";
                cmbEditionActivate.DataSource = entEditions;

            }
        }
        private void PopulateCountry()
        {
            try
            {
                
                if (CmbCountry.DataSource != null) { return; }
                using (MySqlConnection conn = new MySqlConnection(RegistrationHelper.sRegistrationConnectionString))
                {
                    conn.Open();
                    try
                    {
                        
                        string sql = "SELECT DISTINCT country FROM regnoregister WHERE TRIM(country)<>'' ORDER BY country";
                        DataTable dtCountry = new DataTable();
                        RegistrationHelper reg = new RegistrationHelper();
                        dtCountry= reg.GetData(sql, conn);
                        CmbCountry.DisplayMember = "country";
                        CmbCountry.ValueMember = "country";
                        CmbCountry.DataSource = dtCountry;
                    }
                    catch (Exception ex)
                    {
                        ExceptionManager.Publish(ex);
                        
                    }
                    finally
                    {
                        conn.Close();
                        this.Cursor = Cursors.Arrow;
                    }
                        
                }
            }
            catch (Exception)
            {
                
            }
        }
        private bool ValidateRegistrationForm()
        {
            if (txtCustomerName.Text == "") { errPrvdr.SetError(txtCustomerName, "Customer Name Must be Entered!"); txtCustomerName.Focus(); return false; }
            if (txtAddress.Text == "") { errPrvdr.SetError(txtCustomerName, "Address Must be Entered!"); txtAddress.Focus(); return false; }
            if (txtCity.Text == "") { errPrvdr.SetError(txtCity, "City Must be Entered!"); txtCity.Focus(); return false; }
            if (txtTelephone.Text == "" || txtMobile.Text == "") { errPrvdr.SetError(txtTelephone, "Telephone or Mobile Must be Entered!"); txtTelephone.Focus(); return false; }
            return true;
        }
        private bool ValidateCDKey()
        {
            

            using (MySqlConnection conn = new MySqlConnection(RegistrationHelper.sRegistrationConnectionString))
            {
                conn.Open();
                try
                {
                    string sql = @"SELECT License,ifnull(PartyName,'') as PartyName,prd.ProductName,prd.Tag  FROM regcdkeytoproduct cdk
                                INNER JOIN regproductmaster prd ON cdk.ProductMID=prd.ProductMID ";
                    sql += " WHERE CDKey='" + txtCDKey.Text + "' AND `Status`='Y'";
                    dtCDKeyToProduct = new DataTable();
                    dtCDKeyToProduct = regHelper.GetData(sql, conn);
                    if (dtCDKeyToProduct.Rows.Count > 0)
                    {
                        iLicenseAvailable = dtCDKeyToProduct.Rows[0]["License"].ToString().ToInt32();
                        sCDKeyProductName = dtCDKeyToProduct.Rows[0]["ProductName"].ToString();
                        sEditionTag = dtCDKeyToProduct.Rows[0]["Tag"].ToString();
                        if (iLicenseAvailable <= 0)
                        {
                            txtCDKey.Focus();
                            throw new Exception("License Limit Exceeded!");
                        }
                        if (sEditionTag != CDKeyEditionTags.Basic19 && sEditionTag != CDKeyEditionTags.ERP19)
                        {
                            txtCDKey.Focus();
                            throw new Exception("Invalid CD Key!");
                        }
                        if (sEditionTag == CDKeyEditionTags.Basic19)
                        {
                            if (cmbEditions.SelectedValue.ToInt32() !=(int)ENEditions.BasicEdition) { cmbEditions.Focus(); throw new Exception("CD Key Not Valid For Selected Edition!"); }
                        }
                        if (sEditionTag == CDKeyEditionTags.ERP19)
                        {
                            if (cmbEditions.SelectedValue.ToInt32() != (int)ENEditions.ERPEdition) { cmbEditions.Focus(); throw new Exception("CD Key Not Valid For Selected Edition!"); }
                        }
                    }
                    else
                    {
                        txtCDKey.Focus();
                        throw new Exception("Invalid CD Key!");
                    }
                }
                catch (Exception ex)
                {
                    ExceptionManager.Publish(ex);
                    MessageBox.Show(ex.Message);
                    return false;
                }
                finally
                {
                    conn.Close();
                    this.Cursor = Cursors.Arrow;
                }
            }
            return true;
        }
        private bool ActivateLicense()
        {
            errPrvdr.Clear();
            if (cmbEditions.SelectedValue == null) { errPrvdr.SetError(cmbEditions, "Edition Must be Selected!"); return false; }
            if (cmbEditions.SelectedIndex == -1) { errPrvdr.SetError(cmbEditions, "Edition Must be Selected!"); return false; }
            if (txtRegistrationNo.Text.Trim() == "") { errPrvdr.SetError(txtRegistrationNo, "Registration No Must be Entered!"); txtRegistrationNo.Focus(); return false; }
            if (cmbEditions.SelectedValue.ToInt32() == (int)ENEditions.BasicEdition)
            {
                if (!_cryptography.IsKeyOK(txtRegistrationNo.Text, txtProductID.Text, (int)ENEditionKeys.BasicEdition))
                {
                    MessageBox.Show("Invalid Registration No!", MessageKeys.MsgApplicationName);
                    return false;
                }
            }
            else if (cmbEditions.SelectedValue.ToInt32() == (int)ENEditions.ERPEdition)
            {
                if (!_cryptography.IsKeyOK(txtRegistrationNo.Text, txtProductID.Text, (int)ENEditionKeys.ERPEDition))
                {
                    MessageBox.Show("Invalid Registration No!", MessageKeys.MsgApplicationName);
                    return false;
                }
            }
            return true;
        }
        private bool OnlineRegistration()
        {
            errPrvdr.Clear();
            if (txtCDKey.Text.Trim() == "") { errPrvdr.SetError(txtCDKey, "CD Key Must be Entered!"); txtCDKey.Focus(); return false; }
            if (cmbEditions.SelectedValue == null) { errPrvdr.SetError(cmbEditions, "Edition Must be Selected!"); return false; }
            if (cmbEditions.SelectedIndex == -1) { errPrvdr.SetError(cmbEditions, "Edition Must be Selected!"); return false; }
            if (!ValidateCDKey()) { return false; }
            if (!ValidateRegistrationForm()) { return false; }
            if (cmbEditions.SelectedValue.ToInt32() == (int)ENEditions.BasicEdition)
            {
                txtRegistrationNo.Text = _cryptography.GenerateRegNo(txtProductID.Text, (int)ENEditionKeys.BasicEdition);
            }
            else if (cmbEditions.SelectedValue.ToInt32() == (int)ENEditions.ERPEdition)
            {
                txtRegistrationNo.Text = _cryptography.GenerateRegNo(txtProductID.Text, (int)ENEditionKeys.ERPEDition);
            }
            return true;
        }
        #endregion
        

      

        private void OneTimeRegistrationWizard_Load(object sender, EventArgs e)
        {
            txtProductID.Text = regHelper.GetUUID().Substring(1,20);
            txtProductIDActivate.Text = txtProductID.Text;
            pnlWelcome.Location = pnlFinish.Location = pnlActivate.Location = pnlOnline.Location;
            pnlWelcome.Size = pnlFinish.Size = pnlActivate.Size = pnlOnline.Size;
            PopulateEditions();
            pnlWelcome.Visible = true;
            btnBack.Enabled = false;
            btnFinish.Enabled = false;
            CurrentPanel = ENWizardPanels.Welcome;
        }

        private void SelectPanel(ENWizardPanels _selectedpanel)
        {
            if (_selectedpanel == ENWizardPanels.Welcome)
            {
                pnlWelcome.Visible = true;
                pnlOnline.Visible = false;
                pnlFinish.Visible = false;
                pnlActivate.Visible = false;
                btnBack.Enabled = false;
            }
            else if (_selectedpanel == ENWizardPanels.ActivateLicense)
            {
                pnlWelcome.Visible = false;
                pnlOnline.Visible = false;
                pnlFinish.Visible = false;
                pnlActivate.Visible = true;
                btnBack.Enabled = true;
            }
            else if (_selectedpanel == ENWizardPanels.Finish)
            {
                pnlWelcome.Visible = false;
                pnlOnline.Visible = false;
                pnlFinish.Visible = true;
                pnlActivate.Visible = false;
                btnBack.Enabled = false;
            }
            else if (_selectedpanel == ENWizardPanels.Online)
            {
                pnlWelcome.Visible = false;
                pnlOnline.Visible = true;
                pnlFinish.Visible = false;
                pnlActivate.Visible = false;
                btnBack.Enabled = true;
            }
            CurrentPanel = _selectedpanel;
        }

        private void stepWizardControl1_Validating(object sender, CancelEventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (CurrentPanel == ENWizardPanels.Welcome)
            {
                if (radOnline.Checked)
                {
                    this.Cursor = Cursors.WaitCursor;
                    PopulateCountry();
                    this.Cursor = Cursors.Arrow;
                    SelectPanel(ENWizardPanels.Online);
                    txtCDKey.Focus();
                }
                else
                {
                    SelectPanel(ENWizardPanels.ActivateLicense);
                    cmbEditionActivate.Focus();
                }
            }
            else if (CurrentPanel == ENWizardPanels.Online)
            {
                if (OnlineRegistration())
                {
                    SelectPanel(ENWizardPanels.ActivateLicense);
                    txtRegistrationNo.Focus();
                }
            }
            else if (CurrentPanel == ENWizardPanels.ActivateLicense)
            {
                if (ActivateLicense())
                {
                    SelectPanel(ENWizardPanels.Finish);
                }
            }
            else if (CurrentPanel == ENWizardPanels.Finish)
            {
                this.DialogResult = DialogResult.OK;
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
           
            if (CurrentPanel == ENWizardPanels.Online)
            {
                SelectPanel(ENWizardPanels.Welcome);
            }
            else if (CurrentPanel == ENWizardPanels.ActivateLicense)
            {
                if (radOnline.Checked)
                {
                    SelectPanel(ENWizardPanels.Online);
                }
                else
                {
                    SelectPanel(ENWizardPanels.Welcome);
                }
            }
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
    }
}
// Pending Works
// Save registration to site
// update license
// save registration data to local db
// visible finish button and hide next button on finish
//