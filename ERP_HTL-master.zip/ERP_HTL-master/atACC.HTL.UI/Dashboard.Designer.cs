﻿namespace atACC.HTL.UI
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlRemindContain = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlGuestSearch = new atACCFramework.UserControls.atPanel();
            this.dgDetails = new System.Windows.Forms.DataGridView();
            this.colid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColContactPerson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColMobileNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColCheckType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRoom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColTransactionid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColVehicleNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColVehicleName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlCenter = new atACC.HTL.UI.UserControls.DashPanel();
            this.tabMain = new atACC.HTL.UI.UserControls.atDashTab();
            this.tbpHome = new System.Windows.Forms.TabPage();
            this.pnlHomeBottom = new System.Windows.Forms.Panel();
            this.chkAsOn = new atACCFramework.UserControls.atCheckBox();
            this.cmbCalendarDays = new atACCFramework.UserControls.ComboBoxExt();
            this.lblCalendarDays = new atACCFramework.UserControls.atLabel();
            this.cmbStyle = new atACCFramework.UserControls.ComboBoxExt();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.dtpAsOn = new atACCFramework.UserControls.atDateTimePicker1();
            this.cmbRoomStatus = new atACCFramework.UserControls.ComboBoxExt();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.cmbRoomHallType = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbBlock = new atACCFramework.UserControls.ComboBoxExt();
            this.lblBlock = new atACCFramework.UserControls.atLabel();
            this.cmbFloor = new atACCFramework.UserControls.ComboBoxExt();
            this.lblFloor = new atACCFramework.UserControls.atLabel();
            this.cmbRoomHall = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomOrHall = new atACCFramework.UserControls.atLabel();
            this.pnlHome = new atACC.HTL.UI.UserControls.atDashFlowLayout();
            this.tbpDashboard = new System.Windows.Forms.TabPage();
            this.atdashflowpanel = new atACC.HTL.UI.UserControls.atDashFlowLayout();
            this.pnlFavourites = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlHeder = new atACCFramework.UserControls.atGradientPanel();
            this.lblReminderCount = new System.Windows.Forms.Label();
            this.lblLanguage = new System.Windows.Forms.Label();
            this.cmbLanguage = new atACCFramework.UserControls.ComboBoxExt();
            this.grpsearch = new System.Windows.Forms.GroupBox();
            this.txtSearch = new atACC.HTL.UI.UserControls.usrDashTextbox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblnoofNotifications = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnNotification = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.pnlOptional = new atACCFramework.UserControls.atGradientPanel();
            this.pnlMenus = new atACCFramework.UserControls.atGradientPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.lblTime = new atACCFramework.UserControls.atLabel();
            this.btnUserImage = new System.Windows.Forms.Button();
            this.lblDate = new atACCFramework.UserControls.atLabel();
            this.lblUserName = new System.Windows.Forms.Label();
            this.btnDatePicker = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnSeperator2 = new System.Windows.Forms.Button();
            this.btnTools = new System.Windows.Forms.Button();
            this.llblLogOut = new System.Windows.Forms.LinkLabel();
            this.btnAddOns = new System.Windows.Forms.Button();
            this.btnMasters = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnTransactions = new System.Windows.Forms.Button();
            this.lblVersionNumber = new System.Windows.Forms.LinkLabel();
            this.btnSeperator3 = new System.Windows.Forms.Button();
            this.lblVersionCap = new atACCFramework.UserControls.atLabel();
            this.btnSeperator1 = new System.Windows.Forms.Button();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.notify = new System.Windows.Forms.NotifyIcon(this.components);
            this.tooltips = new System.Windows.Forms.ToolTip(this.components);
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pnlMain.SuspendLayout();
            this.pnlGuestSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.pnlCenter.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tbpHome.SuspendLayout();
            this.pnlHomeBottom.SuspendLayout();
            this.tbpDashboard.SuspendLayout();
            this.pnlHeder.SuspendLayout();
            this.grpsearch.SuspendLayout();
            this.pnlOptional.SuspendLayout();
            this.pnlMenus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pnlRemindContain);
            this.pnlMain.Controls.Add(this.pnlGuestSearch);
            this.pnlMain.Controls.Add(this.pnlCenter);
            this.pnlMain.Controls.Add(this.pnlFavourites);
            this.pnlMain.Controls.Add(this.pnlHeder);
            this.pnlMain.Controls.Add(this.pnlOptional);
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.Name = "pnlMain";
            // 
            // pnlRemindContain
            // 
            resources.ApplyResources(this.pnlRemindContain, "pnlRemindContain");
            this.pnlRemindContain.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlRemindContain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRemindContain.Name = "pnlRemindContain";
            // 
            // pnlGuestSearch
            // 
            this.pnlGuestSearch.BackColor = System.Drawing.SystemColors.Window;
            this.pnlGuestSearch.Controls.Add(this.dgDetails);
            resources.ApplyResources(this.pnlGuestSearch, "pnlGuestSearch");
            this.pnlGuestSearch.Name = "pnlGuestSearch";
            // 
            // dgDetails
            // 
            this.dgDetails.AllowUserToAddRows = false;
            this.dgDetails.AllowUserToDeleteRows = false;
            this.dgDetails.AllowUserToResizeColumns = false;
            this.dgDetails.AllowUserToResizeRows = false;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgDetails.BackgroundColor = System.Drawing.Color.White;
            this.dgDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colid,
            this.colCode,
            this.ColName,
            this.ColContactPerson,
            this.ColMobileNumber,
            this.ColCheckType,
            this.ColRoom,
            this.ColTransactionid,
            this.ColVehicleNumber,
            this.ColVehicleName});
            this.dgDetails.Name = "dgDetails";
            this.dgDetails.RowHeadersVisible = false;
            // 
            // colid
            // 
            this.colid.DataPropertyName = "id";
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9F);
            this.colid.DefaultCellStyle = dataGridViewCellStyle1;
            this.colid.FillWeight = 118.7817F;
            resources.ApplyResources(this.colid, "colid");
            this.colid.Name = "colid";
            this.colid.ReadOnly = true;
            // 
            // colCode
            // 
            this.colCode.DataPropertyName = "Code";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9F);
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.colCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.colCode.FillWeight = 70F;
            resources.ApplyResources(this.colCode, "colCode");
            this.colCode.Name = "colCode";
            this.colCode.ReadOnly = true;
            // 
            // ColName
            // 
            this.ColName.DataPropertyName = "Name";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColName.DefaultCellStyle = dataGridViewCellStyle3;
            resources.ApplyResources(this.ColName, "ColName");
            this.ColName.Name = "ColName";
            this.ColName.ReadOnly = true;
            // 
            // ColContactPerson
            // 
            this.ColContactPerson.DataPropertyName = "ContactPerson";
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColContactPerson.DefaultCellStyle = dataGridViewCellStyle4;
            resources.ApplyResources(this.ColContactPerson, "ColContactPerson");
            this.ColContactPerson.Name = "ColContactPerson";
            this.ColContactPerson.ReadOnly = true;
            // 
            // ColMobileNumber
            // 
            this.ColMobileNumber.DataPropertyName = "MobileNumber";
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColMobileNumber.DefaultCellStyle = dataGridViewCellStyle5;
            resources.ApplyResources(this.ColMobileNumber, "ColMobileNumber");
            this.ColMobileNumber.Name = "ColMobileNumber";
            this.ColMobileNumber.ReadOnly = true;
            // 
            // ColCheckType
            // 
            this.ColCheckType.DataPropertyName = "CheckType";
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColCheckType.DefaultCellStyle = dataGridViewCellStyle6;
            resources.ApplyResources(this.ColCheckType, "ColCheckType");
            this.ColCheckType.Name = "ColCheckType";
            this.ColCheckType.ReadOnly = true;
            // 
            // ColRoom
            // 
            this.ColRoom.DataPropertyName = "Room";
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColRoom.DefaultCellStyle = dataGridViewCellStyle7;
            this.ColRoom.FillWeight = 70F;
            resources.ApplyResources(this.ColRoom, "ColRoom");
            this.ColRoom.Name = "ColRoom";
            this.ColRoom.ReadOnly = true;
            // 
            // ColTransactionid
            // 
            this.ColTransactionid.DataPropertyName = "Transactionid";
            resources.ApplyResources(this.ColTransactionid, "ColTransactionid");
            this.ColTransactionid.Name = "ColTransactionid";
            this.ColTransactionid.ReadOnly = true;
            // 
            // ColVehicleNumber
            // 
            this.ColVehicleNumber.DataPropertyName = "VehicleNumber";
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColVehicleNumber.DefaultCellStyle = dataGridViewCellStyle8;
            this.ColVehicleNumber.FillWeight = 80F;
            resources.ApplyResources(this.ColVehicleNumber, "ColVehicleNumber");
            this.ColVehicleNumber.Name = "ColVehicleNumber";
            this.ColVehicleNumber.ReadOnly = true;
            // 
            // ColVehicleName
            // 
            this.ColVehicleName.DataPropertyName = "VehicleName";
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColVehicleName.DefaultCellStyle = dataGridViewCellStyle9;
            this.ColVehicleName.FillWeight = 80F;
            resources.ApplyResources(this.ColVehicleName, "ColVehicleName");
            this.ColVehicleName.Name = "ColVehicleName";
            this.ColVehicleName.ReadOnly = true;
            // 
            // pnlCenter
            // 
            this.pnlCenter.Controls.Add(this.tabMain);
            resources.ApplyResources(this.pnlCenter, "pnlCenter");
            this.pnlCenter.Name = "pnlCenter";
            // 
            // tabMain
            // 
            resources.ApplyResources(this.tabMain, "tabMain");
            this.tabMain.Controls.Add(this.tbpHome);
            this.tabMain.Controls.Add(this.tbpDashboard);
            this.tabMain.Multiline = true;
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.SelectedIndexChanged += new System.EventHandler(this.tabMain_SelectedIndexChanged);
            // 
            // tbpHome
            // 
            this.tbpHome.BackColor = System.Drawing.Color.Gainsboro;
            this.tbpHome.Controls.Add(this.pnlHomeBottom);
            this.tbpHome.Controls.Add(this.pnlHome);
            resources.ApplyResources(this.tbpHome, "tbpHome");
            this.tbpHome.Name = "tbpHome";
            // 
            // pnlHomeBottom
            // 
            this.pnlHomeBottom.Controls.Add(this.chkAsOn);
            this.pnlHomeBottom.Controls.Add(this.cmbCalendarDays);
            this.pnlHomeBottom.Controls.Add(this.lblCalendarDays);
            this.pnlHomeBottom.Controls.Add(this.cmbStyle);
            this.pnlHomeBottom.Controls.Add(this.atLabel3);
            this.pnlHomeBottom.Controls.Add(this.dtpAsOn);
            this.pnlHomeBottom.Controls.Add(this.cmbRoomStatus);
            this.pnlHomeBottom.Controls.Add(this.atLabel1);
            this.pnlHomeBottom.Controls.Add(this.lblRoomType);
            this.pnlHomeBottom.Controls.Add(this.cmbRoomHallType);
            this.pnlHomeBottom.Controls.Add(this.cmbBlock);
            this.pnlHomeBottom.Controls.Add(this.lblBlock);
            this.pnlHomeBottom.Controls.Add(this.cmbFloor);
            this.pnlHomeBottom.Controls.Add(this.lblFloor);
            this.pnlHomeBottom.Controls.Add(this.cmbRoomHall);
            this.pnlHomeBottom.Controls.Add(this.lblRoomOrHall);
            resources.ApplyResources(this.pnlHomeBottom, "pnlHomeBottom");
            this.pnlHomeBottom.Name = "pnlHomeBottom";
            // 
            // chkAsOn
            // 
            resources.ApplyResources(this.chkAsOn, "chkAsOn");
            this.chkAsOn.Name = "chkAsOn";
            this.chkAsOn.UseVisualStyleBackColor = true;
            this.chkAsOn.CheckedChanged += new System.EventHandler(this.chkAsOn_CheckedChanged);
            // 
            // cmbCalendarDays
            // 
            this.cmbCalendarDays.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCalendarDays.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCalendarDays.DropDownHeight = 300;
            this.cmbCalendarDays.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbCalendarDays, "cmbCalendarDays");
            this.cmbCalendarDays.FormattingEnabled = true;
            this.cmbCalendarDays.Name = "cmbCalendarDays";
            this.cmbCalendarDays.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // lblCalendarDays
            // 
            resources.ApplyResources(this.lblCalendarDays, "lblCalendarDays");
            this.lblCalendarDays.Name = "lblCalendarDays";
            this.lblCalendarDays.RequiredField = false;
            // 
            // cmbStyle
            // 
            this.cmbStyle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbStyle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbStyle.DropDownHeight = 300;
            this.cmbStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbStyle, "cmbStyle");
            this.cmbStyle.FormattingEnabled = true;
            this.cmbStyle.Name = "cmbStyle";
            this.cmbStyle.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // dtpAsOn
            // 
            resources.ApplyResources(this.dtpAsOn, "dtpAsOn");
            this.dtpAsOn.Checked = false;
            this.dtpAsOn.DisbaleDateTimeFormat = false;
            this.dtpAsOn.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAsOn.Name = "dtpAsOn";
            this.dtpAsOn.ValueChanged += new System.EventHandler(this.dtpAsOn_ValueChanged);
            // 
            // cmbRoomStatus
            // 
            this.cmbRoomStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomStatus.DropDownHeight = 300;
            this.cmbRoomStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomStatus, "cmbRoomStatus");
            this.cmbRoomStatus.FormattingEnabled = true;
            this.cmbRoomStatus.Items.AddRange(new object[] {
            resources.GetString("cmbRoomStatus.Items"),
            resources.GetString("cmbRoomStatus.Items1"),
            resources.GetString("cmbRoomStatus.Items2")});
            this.cmbRoomStatus.Name = "cmbRoomStatus";
            this.cmbRoomStatus.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // atLabel1
            // 
            resources.ApplyResources(this.atLabel1, "atLabel1");
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // cmbRoomHallType
            // 
            this.cmbRoomHallType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomHallType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomHallType.DropDownHeight = 300;
            this.cmbRoomHallType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomHallType, "cmbRoomHallType");
            this.cmbRoomHallType.FormattingEnabled = true;
            this.cmbRoomHallType.Name = "cmbRoomHallType";
            this.cmbRoomHallType.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // cmbBlock
            // 
            this.cmbBlock.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBlock.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBlock.DropDownHeight = 300;
            this.cmbBlock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbBlock, "cmbBlock");
            this.cmbBlock.FormattingEnabled = true;
            this.cmbBlock.Name = "cmbBlock";
            this.cmbBlock.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // lblBlock
            // 
            resources.ApplyResources(this.lblBlock, "lblBlock");
            this.lblBlock.Name = "lblBlock";
            this.lblBlock.RequiredField = false;
            // 
            // cmbFloor
            // 
            this.cmbFloor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbFloor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbFloor.DropDownHeight = 300;
            this.cmbFloor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbFloor, "cmbFloor");
            this.cmbFloor.FormattingEnabled = true;
            this.cmbFloor.Name = "cmbFloor";
            this.cmbFloor.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // lblFloor
            // 
            resources.ApplyResources(this.lblFloor, "lblFloor");
            this.lblFloor.Name = "lblFloor";
            this.lblFloor.RequiredField = false;
            // 
            // cmbRoomHall
            // 
            this.cmbRoomHall.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomHall.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomHall.DropDownHeight = 300;
            this.cmbRoomHall.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomHall, "cmbRoomHall");
            this.cmbRoomHall.FormattingEnabled = true;
            this.cmbRoomHall.Items.AddRange(new object[] {
            resources.GetString("cmbRoomHall.Items"),
            resources.GetString("cmbRoomHall.Items1"),
            resources.GetString("cmbRoomHall.Items2")});
            this.cmbRoomHall.Name = "cmbRoomHall";
            this.cmbRoomHall.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // lblRoomOrHall
            // 
            resources.ApplyResources(this.lblRoomOrHall, "lblRoomOrHall");
            this.lblRoomOrHall.Name = "lblRoomOrHall";
            this.lblRoomOrHall.RequiredField = false;
            // 
            // pnlHome
            // 
            resources.ApplyResources(this.pnlHome, "pnlHome");
            this.pnlHome.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlHome.Name = "pnlHome";
            // 
            // tbpDashboard
            // 
            this.tbpDashboard.Controls.Add(this.atdashflowpanel);
            resources.ApplyResources(this.tbpDashboard, "tbpDashboard");
            this.tbpDashboard.Name = "tbpDashboard";
            this.tbpDashboard.UseVisualStyleBackColor = true;
            // 
            // atdashflowpanel
            // 
            resources.ApplyResources(this.atdashflowpanel, "atdashflowpanel");
            this.atdashflowpanel.BackColor = System.Drawing.Color.Gainsboro;
            this.atdashflowpanel.Name = "atdashflowpanel";
            // 
            // pnlFavourites
            // 
            this.pnlFavourites.BackColor = System.Drawing.Color.Gainsboro;
            resources.ApplyResources(this.pnlFavourites, "pnlFavourites");
            this.pnlFavourites.Name = "pnlFavourites";
            // 
            // pnlHeder
            // 
            this.pnlHeder.AllowMultiSelect = false;
            this.pnlHeder.Angle = 95F;
            this.pnlHeder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlHeder.BottomColor = System.Drawing.Color.DarkGray;
            this.pnlHeder.Controls.Add(this.lblReminderCount);
            this.pnlHeder.Controls.Add(this.lblLanguage);
            this.pnlHeder.Controls.Add(this.cmbLanguage);
            this.pnlHeder.Controls.Add(this.grpsearch);
            this.pnlHeder.Controls.Add(this.lblnoofNotifications);
            this.pnlHeder.Controls.Add(this.btnClose);
            this.pnlHeder.Controls.Add(this.btnNotification);
            this.pnlHeder.Controls.Add(this.btnMinimize);
            this.pnlHeder.Controls.Add(this.btnMaximize);
            this.pnlHeder.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.pnlHeder, "pnlHeder");
            this.pnlHeder.Name = "pnlHeder";
            this.pnlHeder.Selected = false;
            this.pnlHeder.TextAdjestmentHeight = 0;
            this.pnlHeder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlHeder.TopColor = System.Drawing.Color.SlateGray;
            // 
            // lblReminderCount
            // 
            resources.ApplyResources(this.lblReminderCount, "lblReminderCount");
            this.lblReminderCount.BackColor = System.Drawing.Color.Red;
            this.lblReminderCount.ForeColor = System.Drawing.SystemColors.Window;
            this.lblReminderCount.Name = "lblReminderCount";
            this.lblReminderCount.Click += new System.EventHandler(this.btnNotification_Click);
            // 
            // lblLanguage
            // 
            resources.ApplyResources(this.lblLanguage, "lblLanguage");
            this.lblLanguage.BackColor = System.Drawing.Color.Transparent;
            this.lblLanguage.ForeColor = System.Drawing.Color.White;
            this.lblLanguage.Name = "lblLanguage";
            // 
            // cmbLanguage
            // 
            resources.ApplyResources(this.cmbLanguage, "cmbLanguage");
            this.cmbLanguage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbLanguage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLanguage.BackColor = System.Drawing.Color.DarkGray;
            this.cmbLanguage.DropDownHeight = 300;
            this.cmbLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLanguage.FormattingEnabled = true;
            this.cmbLanguage.Name = "cmbLanguage";
            this.cmbLanguage.SelectedIndexChanged += new System.EventHandler(this.cmbLanguage_SelectedIndexChanged);
            this.cmbLanguage.SelectedValueChanged += new System.EventHandler(this.cmbLanguage_SelectedValueChanged);
            // 
            // grpsearch
            // 
            this.grpsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpsearch.Controls.Add(this.txtSearch);
            this.grpsearch.Controls.Add(this.btnSearch);
            resources.ApplyResources(this.grpsearch, "grpsearch");
            this.grpsearch.Name = "grpsearch";
            this.grpsearch.TabStop = false;
            // 
            // txtSearch
            // 
            resources.ApplyResources(this.txtSearch, "txtSearch");
            this.txtSearch.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSearch.ForeColor = System.Drawing.Color.Gray;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnSearch
            // 
            resources.ApplyResources(this.btnSearch, "btnSearch");
            this.btnSearch.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.ForeColor = System.Drawing.Color.DarkGray;
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.UseVisualStyleBackColor = false;
            // 
            // lblnoofNotifications
            // 
            resources.ApplyResources(this.lblnoofNotifications, "lblnoofNotifications");
            this.lblnoofNotifications.BackColor = System.Drawing.Color.Red;
            this.lblnoofNotifications.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblnoofNotifications.ForeColor = System.Drawing.Color.White;
            this.lblnoofNotifications.Name = "lblnoofNotifications";
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnClose.Name = "btnClose";
            this.btnClose.TabStop = false;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnNotification
            // 
            resources.ApplyResources(this.btnNotification, "btnNotification");
            this.btnNotification.BackColor = System.Drawing.Color.Transparent;
            this.btnNotification.FlatAppearance.BorderSize = 0;
            this.btnNotification.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNotification.ForeColor = System.Drawing.Color.White;
            this.btnNotification.Name = "btnNotification";
            this.btnNotification.UseVisualStyleBackColor = false;
            this.btnNotification.Click += new System.EventHandler(this.btnNotification_Click);
            // 
            // btnMinimize
            // 
            resources.ApplyResources(this.btnMinimize, "btnMinimize");
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.TabStop = false;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnMaximize
            // 
            resources.ApplyResources(this.btnMaximize, "btnMaximize");
            this.btnMaximize.BackColor = System.Drawing.Color.Transparent;
            this.btnMaximize.FlatAppearance.BorderSize = 0;
            this.btnMaximize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMaximize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.TabStop = false;
            this.btnMaximize.UseVisualStyleBackColor = false;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // pnlOptional
            // 
            this.pnlOptional.AllowMultiSelect = false;
            this.pnlOptional.Angle = 95F;
            this.pnlOptional.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(95)))), ((int)(((byte)(103)))));
            this.pnlOptional.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(86)))), ((int)(((byte)(103)))));
            this.pnlOptional.Controls.Add(this.pnlMenus);
            this.pnlOptional.Controls.Add(this.lblVersionNumber);
            this.pnlOptional.Controls.Add(this.btnSeperator3);
            this.pnlOptional.Controls.Add(this.lblVersionCap);
            this.pnlOptional.Controls.Add(this.btnSeperator1);
            this.pnlOptional.Controls.Add(this.picBox);
            this.pnlOptional.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.pnlOptional, "pnlOptional");
            this.pnlOptional.Name = "pnlOptional";
            this.pnlOptional.Selected = false;
            this.pnlOptional.TextAdjestmentHeight = 0;
            this.pnlOptional.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptional.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(86)))), ((int)(((byte)(103)))));
            // 
            // pnlMenus
            // 
            this.pnlMenus.AllowMultiSelect = false;
            resources.ApplyResources(this.pnlMenus, "pnlMenus");
            this.pnlMenus.Angle = 95F;
            this.pnlMenus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(95)))), ((int)(((byte)(103)))));
            this.pnlMenus.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(86)))), ((int)(((byte)(103)))));
            this.pnlMenus.Controls.Add(this.button1);
            this.pnlMenus.Controls.Add(this.lblTime);
            this.pnlMenus.Controls.Add(this.btnUserImage);
            this.pnlMenus.Controls.Add(this.lblDate);
            this.pnlMenus.Controls.Add(this.lblUserName);
            this.pnlMenus.Controls.Add(this.btnDatePicker);
            this.pnlMenus.Controls.Add(this.btnHelp);
            this.pnlMenus.Controls.Add(this.btnSeperator2);
            this.pnlMenus.Controls.Add(this.btnTools);
            this.pnlMenus.Controls.Add(this.llblLogOut);
            this.pnlMenus.Controls.Add(this.btnAddOns);
            this.pnlMenus.Controls.Add(this.btnMasters);
            this.pnlMenus.Controls.Add(this.btnSettings);
            this.pnlMenus.Controls.Add(this.btnReports);
            this.pnlMenus.Controls.Add(this.btnTransactions);
            this.pnlMenus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlMenus.Name = "pnlMenus";
            this.pnlMenus.Selected = false;
            this.pnlMenus.TextAdjestmentHeight = 0;
            this.pnlMenus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlMenus.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(86)))), ((int)(((byte)(103)))));
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.button1, "button1");
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // lblTime
            // 
            resources.ApplyResources(this.lblTime, "lblTime");
            this.lblTime.BackColor = System.Drawing.Color.Transparent;
            this.lblTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblTime.Name = "lblTime";
            this.lblTime.RequiredField = false;
            // 
            // btnUserImage
            // 
            resources.ApplyResources(this.btnUserImage, "btnUserImage");
            this.btnUserImage.BackColor = System.Drawing.Color.White;
            this.btnUserImage.FlatAppearance.BorderSize = 0;
            this.btnUserImage.ForeColor = System.Drawing.Color.DarkGray;
            this.btnUserImage.Name = "btnUserImage";
            this.btnUserImage.UseVisualStyleBackColor = false;
            // 
            // lblDate
            // 
            resources.ApplyResources(this.lblDate, "lblDate");
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblDate.Name = "lblDate";
            this.lblDate.RequiredField = false;
            // 
            // lblUserName
            // 
            resources.ApplyResources(this.lblUserName, "lblUserName");
            this.lblUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Name = "lblUserName";
            // 
            // btnDatePicker
            // 
            this.btnDatePicker.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnDatePicker, "btnDatePicker");
            this.btnDatePicker.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btnDatePicker.FlatAppearance.BorderSize = 0;
            this.btnDatePicker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDatePicker.ForeColor = System.Drawing.Color.White;
            this.btnDatePicker.Name = "btnDatePicker";
            this.btnDatePicker.UseVisualStyleBackColor = false;
            // 
            // btnHelp
            // 
            this.btnHelp.BackColor = System.Drawing.Color.Transparent;
            this.btnHelp.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnHelp.FlatAppearance.BorderSize = 0;
            this.btnHelp.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnHelp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnHelp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.btnHelp, "btnHelp");
            this.btnHelp.ForeColor = System.Drawing.SystemColors.Window;
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.UseVisualStyleBackColor = false;
            this.btnHelp.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnSeperator2
            // 
            this.btnSeperator2.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator2, "btnSeperator2");
            this.btnSeperator2.Name = "btnSeperator2";
            this.btnSeperator2.UseVisualStyleBackColor = false;
            // 
            // btnTools
            // 
            this.btnTools.BackColor = System.Drawing.Color.Transparent;
            this.btnTools.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnTools.FlatAppearance.BorderSize = 0;
            this.btnTools.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnTools.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTools.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.btnTools, "btnTools");
            this.btnTools.ForeColor = System.Drawing.SystemColors.Window;
            this.btnTools.Name = "btnTools";
            this.btnTools.UseVisualStyleBackColor = false;
            this.btnTools.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // llblLogOut
            // 
            resources.ApplyResources(this.llblLogOut, "llblLogOut");
            this.llblLogOut.BackColor = System.Drawing.Color.Transparent;
            this.llblLogOut.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.llblLogOut.Name = "llblLogOut";
            this.llblLogOut.TabStop = true;
            this.llblLogOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblLogOut_LinkClicked);
            // 
            // btnAddOns
            // 
            this.btnAddOns.BackColor = System.Drawing.Color.Transparent;
            this.btnAddOns.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAddOns.FlatAppearance.BorderSize = 0;
            this.btnAddOns.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnAddOns.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAddOns.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.btnAddOns, "btnAddOns");
            this.btnAddOns.ForeColor = System.Drawing.SystemColors.Window;
            this.btnAddOns.Name = "btnAddOns";
            this.btnAddOns.UseVisualStyleBackColor = false;
            this.btnAddOns.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnMasters
            // 
            this.btnMasters.BackColor = System.Drawing.Color.Transparent;
            this.btnMasters.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnMasters.FlatAppearance.BorderSize = 0;
            this.btnMasters.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnMasters.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMasters.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.btnMasters, "btnMasters");
            this.btnMasters.ForeColor = System.Drawing.SystemColors.Window;
            this.btnMasters.Name = "btnMasters";
            this.btnMasters.UseVisualStyleBackColor = false;
            this.btnMasters.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.Color.Transparent;
            this.btnSettings.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSettings.FlatAppearance.BorderSize = 0;
            this.btnSettings.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.btnSettings, "btnSettings");
            this.btnSettings.ForeColor = System.Drawing.SystemColors.Window;
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnReports
            // 
            this.btnReports.BackColor = System.Drawing.Color.Transparent;
            this.btnReports.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnReports.FlatAppearance.BorderSize = 0;
            this.btnReports.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.btnReports, "btnReports");
            this.btnReports.ForeColor = System.Drawing.SystemColors.Window;
            this.btnReports.Name = "btnReports";
            this.btnReports.UseVisualStyleBackColor = false;
            this.btnReports.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnTransactions
            // 
            this.btnTransactions.BackColor = System.Drawing.Color.Transparent;
            this.btnTransactions.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnTransactions.FlatAppearance.BorderSize = 0;
            this.btnTransactions.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnTransactions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTransactions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.btnTransactions, "btnTransactions");
            this.btnTransactions.ForeColor = System.Drawing.SystemColors.Window;
            this.btnTransactions.Name = "btnTransactions";
            this.btnTransactions.UseVisualStyleBackColor = false;
            this.btnTransactions.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // lblVersionNumber
            // 
            resources.ApplyResources(this.lblVersionNumber, "lblVersionNumber");
            this.lblVersionNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblVersionNumber.ForeColor = System.Drawing.Color.White;
            this.lblVersionNumber.LinkColor = System.Drawing.Color.White;
            this.lblVersionNumber.Name = "lblVersionNumber";
            this.lblVersionNumber.TabStop = true;
            // 
            // btnSeperator3
            // 
            resources.ApplyResources(this.btnSeperator3, "btnSeperator3");
            this.btnSeperator3.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator3.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator3.FlatAppearance.BorderSize = 0;
            this.btnSeperator3.Name = "btnSeperator3";
            this.btnSeperator3.UseVisualStyleBackColor = false;
            // 
            // lblVersionCap
            // 
            resources.ApplyResources(this.lblVersionCap, "lblVersionCap");
            this.lblVersionCap.BackColor = System.Drawing.Color.Transparent;
            this.lblVersionCap.ForeColor = System.Drawing.Color.White;
            this.lblVersionCap.Name = "lblVersionCap";
            this.lblVersionCap.RequiredField = false;
            // 
            // btnSeperator1
            // 
            this.btnSeperator1.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator1, "btnSeperator1");
            this.btnSeperator1.Name = "btnSeperator1";
            this.btnSeperator1.UseVisualStyleBackColor = false;
            // 
            // picBox
            // 
            this.picBox.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.picBox, "picBox");
            this.picBox.Name = "picBox";
            this.picBox.TabStop = false;
            // 
            // notify
            // 
            resources.ApplyResources(this.notify, "notify");
            // 
            // timer
            // 
            this.timer.Interval = 500;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Dashboard
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Dashboard_Activated);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlGuestSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.pnlCenter.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            this.tbpHome.ResumeLayout(false);
            this.tbpHome.PerformLayout();
            this.pnlHomeBottom.ResumeLayout(false);
            this.pnlHomeBottom.PerformLayout();
            this.tbpDashboard.ResumeLayout(false);
            this.tbpDashboard.PerformLayout();
            this.pnlHeder.ResumeLayout(false);
            this.pnlHeder.PerformLayout();
            this.grpsearch.ResumeLayout(false);
            this.grpsearch.PerformLayout();
            this.pnlOptional.ResumeLayout(false);
            this.pnlOptional.PerformLayout();
            this.pnlMenus.ResumeLayout(false);
            this.pnlMenus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblnoofNotifications;
        public System.Windows.Forms.Button btnUserImage;
        private System.Windows.Forms.Button btnNotification;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.PictureBox picBox;
        private atACCFramework.UserControls.atGradientPanel pnlHeder;
        private System.Windows.Forms.Button btnDatePicker;
        private atACCFramework.UserControls.atLabel lblDate;
        private atACCFramework.UserControls.atGradientPanel pnlOptional;
        private System.Windows.Forms.Button btnSeperator2;
        public System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Button btnSeperator1;
        private System.Windows.Forms.LinkLabel llblLogOut;
        private System.Windows.Forms.FlowLayoutPanel pnlFavourites;
        private System.Windows.Forms.LinkLabel lblVersionNumber;
        private System.Windows.Forms.Button btnSeperator3;
        private atACCFramework.UserControls.atLabel lblVersionCap;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Button btnTools;
        private System.Windows.Forms.Button btnAddOns;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnTransactions;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnMasters;
        private UserControls.DashPanel pnlCenter;
        public UserControls.atDashTab tabMain;
        private System.Windows.Forms.TabPage tbpDashboard;
        private UserControls.atDashFlowLayout atdashflowpanel;
        private System.Windows.Forms.GroupBox grpsearch;
        private UserControls.usrDashTextbox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private atACCFramework.UserControls.ComboBoxExt cmbLanguage;
        private System.Windows.Forms.Label lblLanguage;
        private UserControls.atTotalValues atTotalValues1;
        private System.Windows.Forms.TabPage tbpHome;
        private UserControls.atDashFlowLayout pnlHome;
        private System.Windows.Forms.NotifyIcon notify;
        private atACCFramework.UserControls.atGradientPanel pnlMenus;
        private System.Windows.Forms.ToolTip tooltips;
        private System.Windows.Forms.Panel pnlHomeBottom;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomHall;
        private atACCFramework.UserControls.atLabel lblRoomOrHall;
        private atACCFramework.UserControls.ComboBoxExt cmbBlock;
        private atACCFramework.UserControls.atLabel lblBlock;
        private atACCFramework.UserControls.ComboBoxExt cmbFloor;
        private atACCFramework.UserControls.atLabel lblFloor;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomHallType;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomStatus;
        private atACCFramework.UserControls.atLabel atLabel1;
        private atACCFramework.UserControls.atLabel lblTime;
        private System.Windows.Forms.Timer timer;
        private atACCFramework.UserControls.atDateTimePicker1 dtpAsOn;
        private System.Windows.Forms.Button button1;
        private atACCFramework.UserControls.ComboBoxExt cmbStyle;
        private atACCFramework.UserControls.atLabel atLabel3;
        private atACCFramework.UserControls.ComboBoxExt cmbCalendarDays;
        private atACCFramework.UserControls.atLabel lblCalendarDays;
        private atACCFramework.UserControls.atCheckBox chkAsOn;
        private atACCFramework.UserControls.atPanel pnlGuestSearch;
        private System.Windows.Forms.DataGridView dgDetails;
        private System.Windows.Forms.FlowLayoutPanel pnlRemindContain;
        private System.Windows.Forms.DataGridViewTextBoxColumn colid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColContactPerson;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColMobileNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCheckType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRoom;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColTransactionid;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColVehicleNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColVehicleName;
        private System.Windows.Forms.Label lblReminderCount;
    }
}