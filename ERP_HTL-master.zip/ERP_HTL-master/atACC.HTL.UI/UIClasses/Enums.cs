﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.UI
{
    public enum ENEditionKeys
    {
        BasicEdition=50,
        StandardEdition = 60,
        OldStandard=24,
        OldPremium=40,
        OldERP=30
    }
    public enum DashboardState
    {
        Closed=0,
        Opened=1
        
    }
    public class CDKeyEditionTags
    {
        public static string Basic19 = "Basic19";
        public static string ERP19 = "ERP19";
        public static string BasicSUB19 = "BasicSUB19";
        public static string ERPSUB19 = "ERPSUB19";
    }
    public enum ENWizardPanels
    {
        Welcome=0,
        Online=1,
        ActivateLicense=2,
        Finish=3
    }
}
