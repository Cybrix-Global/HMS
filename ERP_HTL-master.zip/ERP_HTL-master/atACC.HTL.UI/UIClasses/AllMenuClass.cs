﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACCORM;
namespace atACC.HTL.UI
{
    public class AllMenuClass
    {
        private MenuDetail _md;
        private int _id;

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        public MenuDetail Md
        {
            get { return _md; }
            set { _md = value; }
        }
        private string _MenuCaption;

        public string MenuCaption
        {
            get { return _MenuCaption; }
            set { _MenuCaption = value; }
        }
        private MenuDetail _parent;

        public MenuDetail Parent
        {
            get { return _parent; }
            set { _parent = value; }
        }
        private string _MenuName;

        public string MenuName
        {
            get { return _MenuName; }
            set { _MenuName = value; }
        }
    }
}
