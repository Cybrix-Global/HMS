﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACC.Common;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.UI.UIClasses;
using Microsoft.SqlServer.Management.Smo;

using Microsoft.SqlServer.Management.Common;
using System.IO;
using System.Reflection;
using atACCORM;
using System.Diagnostics;
using System.Data.SqlClient;
using atACC.CommonExtensions;
using System.Data;
using System.Windows;

namespace atACC.UI
{
    public class UpgradeHelper
    {
        #region private Methods
        private static bool ExecuteScriptsFromFile(string sFilePath, bool windowsAuthenticationMode)
        {
            string sConnectionstring = "";
            if (windowsAuthenticationMode)
            {
                sConnectionstring = GlobalFunctions.sWindowsAuthenticationConnectionString;
            }
            else
            {
                sConnectionstring = GlobalFunctions.sSqlAuthenticationConnectionString;
            }
            if (File.Exists(sFilePath))
            {
                string script = null;
                script = File.ReadAllText(sFilePath);
                string[] ScriptSplitter = script.Split(new string[] { "GO","go","Go","gO" }, StringSplitOptions.None);
                using (SqlConnection con = new SqlConnection(sConnectionstring))
                {
                    con.Open();
                    try
                    {
                        Server db = new Server(new ServerConnection(con));
                        db.ConnectionContext.ExecuteNonQuery(script);
                    }
                    catch (Exception ex)
                    {
                        ExceptionManager.Publish(ex);
                    }
                    finally
                    {
                        con.Close();
                    }

                    //foreach (string str in ScriptSplitter)
                    //{
                    //    using (SqlCommand command = con.CreateCommand())
                    //    {
                    //        try
                    //        {
                                
                    //            command.CommandText = str;
                    //            command.CommandTimeout = 0;
                    //            command.ExecuteNonQuery();

                    //        }
                    //        catch (Exception ex)
                    //        {
                    //            ExceptionManager.Publish(ex);
                    //        }
                    //        finally
                    //        {
                                
                    //        }
                    //    }

                    //}
                    //con.Close();
                }
            }

            return true;
        }
        private static bool isUpgradeRequired(bool windowsAuthenticationMode)
        {
            try
            {
                // 19.0.1001
                FileVersionInfo fileVersionInfo = System.Diagnostics.FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
                GlobalFunctions.BuildVersion = fileVersionInfo.FileMajorPart.ToString() + "." + fileVersionInfo.FileMinorPart.ToString()
                    + "." + fileVersionInfo.FileBuildPart.ToString();
                string sMajour = fileVersionInfo.FileMajorPart.ToString();
                string sMinor = fileVersionInfo.FileMinorPart.ToString();
                string sBuildNumber = fileVersionInfo.FileBuildPart.ToString();
                int iAppVersionSum = (sMajour + sMinor + sBuildNumber).ToInt32();
                ApplyDatabaseVersion(windowsAuthenticationMode);
                string sMajourDb = GlobalFunctions.DatabaseVersion.Substring(0, 2);
                string sMinorDb = GlobalFunctions.DatabaseVersion.Substring(3, 1);
                string sRivisionDb = GlobalFunctions.DatabaseVersion.Substring(5, 4);
                int iDbVersionSum = (sMajourDb + sMinorDb + sRivisionDb).ToInt32();
                if (iAppVersionSum < iDbVersionSum)
                {
                    throw new Exception("Application Version: " + GlobalFunctions.BuildVersion + " Less Than Database Version:" + GlobalFunctions.DatabaseVersion);
                }
                if (iAppVersionSum > iDbVersionSum)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw ex;
            }
        }
        private static void UpdateVersionToDatabase(bool windowsAuthenticationMode)
        {
            string sConnectionstring = "";
            if (windowsAuthenticationMode)
            {
                sConnectionstring = GlobalFunctions.sWindowsAuthenticationConnectionString;
            }
            else
            {
                sConnectionstring = GlobalFunctions.sSqlAuthenticationConnectionString;
            }
            using (SqlConnection con = new SqlConnection(sConnectionstring))
            {
                con.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "update TB_ADM_Company set Version='" + GlobalFunctions.BuildVersion + "'";
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }

        }
        private static void ApplyDatabaseVersion(bool windowsAuthenticationMode)
        {
            string sConnectionstring = "";
            if (windowsAuthenticationMode)
            {
                sConnectionstring = GlobalFunctions.sWindowsAuthenticationConnectionString;
            }
            else
            {
                sConnectionstring = GlobalFunctions.sSqlAuthenticationConnectionString;
            }
            using (SqlConnection con = new SqlConnection(sConnectionstring))
            {
                con.Open();
                try
                {
                    SqlDataAdapter dad = new SqlDataAdapter("select Version from TB_ADM_Company ", con);
                    DataTable dtCompany = new DataTable();
                    dad.Fill(dtCompany);
                    if (dtCompany.Rows.Count > 0)
                    {
                        GlobalFunctions.DatabaseVersion = dtCompany.Rows[0]["Version"].ToString();
                    }
                    else
                    {
                        GlobalFunctions.DatabaseVersion = "";
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }

          
        }
        #endregion
        #region Public Methods
        public static bool UpgradeDatabase(bool WindowsAuthentication)
        {
            try
            {
                if (!isUpgradeRequired(WindowsAuthentication)) { return false; }
                if (GlobalFunctions.DatabaseVersion == "19.0.1001")
                {
                    return false;
                }
                string sMajourDb = GlobalFunctions.DatabaseVersion.Substring(0, 2);
                string sMinorDb = GlobalFunctions.DatabaseVersion.Substring(3, 1);
                string sRivisionDb = GlobalFunctions.DatabaseVersion.Substring(5, 4);
                int iDbVersionSum = (sMajourDb + sMinorDb + sRivisionDb).ToInt32();
                string sDirectoryPath;
                sDirectoryPath = AppDomain.CurrentDomain.BaseDirectory + @"Upgrade";
                DirectoryInfo d = new DirectoryInfo(sDirectoryPath);
                FileInfo[] Files = d.GetFiles("*.sql"); //Getting Sql files
                int counter = 0;
                foreach (FileInfo file in Files.OrderBy(x=>x.Name))
                {
                    
                    int iFileVersionNumber = file.Name.Substring(0, 7).ToInt32(); // 1901004
                    if (iFileVersionNumber > iDbVersionSum)
                    {
                        ExecuteScriptsFromFile(file.FullName, WindowsAuthentication);
                    }
                    counter++;
                }
                UpdateVersionToDatabase(WindowsAuthentication);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        #endregion

    }
}
