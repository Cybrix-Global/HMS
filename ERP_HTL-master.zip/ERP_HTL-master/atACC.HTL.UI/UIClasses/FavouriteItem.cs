﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACCORM;
using System.Windows.Forms;
using System.Drawing;
namespace atACC.HTL.UI.UIClasses
{
   public  class FavouriteItem
    {
        public string Path { get; set; }
        public string Text { get; set; }
        public MenuDetail menuItem { get; set; }
    }
}
