﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
using atACCORM;
using System.IO;
using System.Drawing;
using System.Drawing.Design;
using atACC.Common;
using atACC.CommonExtensions;
using LocalORM;
using atACC.CommonMessages;
using atACCFramework.Common;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using System.Xml.Serialization;
namespace atACC.HTL.UI.UIClasses
{
   public class UICommon:IUICommon
   {
       #region "Private Variables"
       public static Dashboard AppDashboard;
        public static atMDI frmMdi;
        public static Icon _currentICon;
       public static bool isLogined = false;
        public static List<TabPage> PreviousPages;
        public static readonly Color ColorDash = Color.FromArgb(27, 33, 51);
       public static readonly Color ColorDashButtonHover = Color.FromArgb(68, 85, 130);
       public static readonly Color ColorDashButtonClick = Color.FromArgb(77, 94, 145);
       public static DashboardState CurrentDashboardState;
       #endregion
       #region Public Methods
       public static bool ValidateDemo()
       {
           
           using (SettingsDbEntities setDb = new SettingsDbEntities())
           {
               if (setDb.Installations.ToList().Count <= 0) // New Installation
               {
                   Installation Newinst = new Installation();
                   Newinst.InstallationDate = DateTime.Now;
                   setDb.Installations.AddObject(Newinst);
                   setDb.SaveChanges();
               }
               else
               {
                   Installation existingInst = setDb.Installations.SingleOrDefault();
                   if ((DateTime.Now.Date-existingInst.InstallationDate.ToDateTime().Date).Days > 30)
                   {
                       MessageBox.Show(MessageKeys.MsgEvaluationPeriodIsOver, MessageKeys.MsgApplicationName);
                       return false;
                   }   
               }
           }
           return true;
       }
       public static OEM ReadOEMData()
       {
           string sFileName = Application.StartupPath + @"\\OEMData.dll";
           if (!File.Exists(sFileName))
           {

               MessageBox.Show("Sensitive file missing!");
               return null;
           }
           XmlSerializer serializer = new XmlSerializer(typeof(OEM));
           serializer.UnknownNode += new XmlNodeEventHandler(serializer_UnknownNode);
           serializer.UnknownAttribute += new XmlAttributeEventHandler(serializer_UnknownAttribute);
           // Declare an object variable of the type to be deserialized.
           OEM _oem;
           // A FileStream is needed to read the XML document.
           using (FileStream fs = new FileStream(sFileName, FileMode.Open))
           {
               /* Use the Deserialize method to restore the object's state with
               data from the XML document. */
               _oem = (OEM)serializer.Deserialize(fs);
               fs.Close();
           }
           return _oem;
       }

       static void serializer_UnknownAttribute(object sender, XmlAttributeEventArgs e)
       {
           
       }

       static void serializer_UnknownNode(object sender, XmlNodeEventArgs e)
       {
           
       }
       public static byte[] imageToByteArray(System.Drawing.Image imageIn)
       {
           MemoryStream ms = new MemoryStream();
           imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
           return ms.ToArray();
       }
       public void ShowCompanyLogo()
       {
           atACCContextEntities db = atContext.CreateContext();
           Company _company = db.Companies.SingleOrDefault();
           //DashboardSingleton.Instance.picCompanyLogo.Image = null;
           //DashboardSingleton.Instance.picCompanyLogo.Visible = false;
           //if (_company.CompanyLogo != null)
           //{
           //    DashboardSingleton.Instance.picCompanyLogo.Image = ANIHelper.byteArrayToImage(_company.CompanyLogo);
           //    DashboardSingleton.Instance.picCompanyLogo.Visible = true;
           //}
       }
       public  void ShowLoginEmployeeImage()
       {
           //DashboardSingleton.Instance.picLogin.Image = null;
           atACCContextEntities db = atContext.CreateContext();
           Employee employee = (from emp in db.Employees
                                join user in db.LoginUsers on emp.id equals user.FK_EmployeeID
                                where user.id == GlobalFunctions.LoginUserID
                                select emp).FirstOrDefault();
           if (employee != null)
           {
               int iEmployeeID = employee.id;
               //DashboardSingleton.Instance.lnkEmployeeName.Text = "Hello " + employee.Name;
               //DashboardSingleton.Instance.lnkEmployeeName.Tag = employee.id;
               EmployeeDTL empDtl = db.EmployeeDTLs.Where(x => x.FK_EmployeeID == iEmployeeID).FirstOrDefault();
               if (empDtl != null && empDtl.EmployeeImage != null)
               {
                   //DashboardSingleton.Instance.picLogin.Image = ANIHelper.byteArrayToImage(empDtl.EmployeeImage);
               }
               else
               {
                   //DashboardSingleton.Instance.picLogin.Image = null;
               }
           }
           else
           {
               //DashboardSingleton.Instance.picLogin.Image = null;
           }

           //DashboardSingleton.Instance.picLogin.Refresh();
       }
       public static bool isUpgradeRequired(bool windowsAuthenticationMode)
       {
           try
           {
               // 19.0.1001
               FileVersionInfo fileVersionInfo = System.Diagnostics.FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
               GlobalFunctions.BuildVersion = fileVersionInfo.FileMajorPart.ToString() + "." + fileVersionInfo.FileMinorPart.ToString()
                   + "." + fileVersionInfo.FileBuildPart.ToString();
               string sMajour = fileVersionInfo.FileMajorPart.ToString();
               string sMinor = fileVersionInfo.FileMinorPart.ToString();
               string sBuildNumber = fileVersionInfo.FileBuildPart.ToString();
               int iAppVersionSum = (sMajour + sMinor + sBuildNumber).ToInt32();
               ApplyDatabaseVersion(windowsAuthenticationMode);
               string sMajourDb = GlobalFunctions.DatabaseVersion.Substring(0, 2);
               string sMinorDb = GlobalFunctions.DatabaseVersion.Substring(3, 1);
               string sRivisionDb = GlobalFunctions.DatabaseVersion.Substring(5, 4);
               int iDbVersionSum = (sMajourDb + sMinorDb + sRivisionDb).ToInt32();
               if (iAppVersionSum < iDbVersionSum)
               {
                   throw new Exception("Application Version: " + GlobalFunctions.BuildVersion + " Less Than Database Version:" + GlobalFunctions.DatabaseVersion);
               }
               if (iAppVersionSum > iDbVersionSum)
               {

                   return true;
               }
               else
               {

                   return false;
               }
           }
           catch (Exception ex)
           {
               ExceptionManager.Publish(ex);
               throw ex;
           }
       }
       private static void ApplyDatabaseVersion(bool windowsAuthenticationMode)
       {
           string sConnectionstring = "";
           if (windowsAuthenticationMode)
           {
               sConnectionstring = GlobalFunctions.sWindowsAuthenticationConnectionString;
           }
           else
           {
               sConnectionstring = GlobalFunctions.sSqlAuthenticationConnectionString;
           }
           using (SqlConnection con = new SqlConnection(sConnectionstring))
           {
               con.Open();
               try
               {
                   SqlDataAdapter dad = new SqlDataAdapter("select Version from TB_ADM_Company ", con);
                   DataTable dtCompany = new DataTable();
                   dad.Fill(dtCompany);
                   if (dtCompany.Rows.Count > 0)
                   {
                       GlobalFunctions.DatabaseVersion = dtCompany.Rows[0]["Version"].ToString();
                   }
                   else
                   {
                       GlobalFunctions.DatabaseVersion = "";
                   }
               }
               catch (Exception ex)
               {
                   throw ex;
               }
               finally
               {
                   con.Close();
               }
           }


       }
       public static Image byteArrayToImage(byte[] byteArrayIn)
       {
           if (byteArrayIn == null) { return null; }         
           MemoryStream ms = new MemoryStream(byteArrayIn);
           Image returnImage = Image.FromStream(ms);
           return returnImage;
       }
       public static void fnActivateForm(string AssemblyName, string ClassName,MenuDetail md)
       {
           try
           {
               
               Assembly assembly;
                AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.UI")
               {
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
               }
               else
               {
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
               }
               Type type = assembly.GetType(ClassName);
               Form form = (Form)Activator.CreateInstance(type);
               form.Icon = UICommon._currentICon;
               if (form is ISearchFormBase)
               {
                   ((ISearchFormBase)form).iContextID = md.id;
               }
               form.MdiParent = UICommon.frmMdi;
               
               switch (GlobalFunctions.LanguageCulture.ToString2())
               {
                   case "":
                       form.Text = md.MenuCaption;
                       break;
                   case "en-US":
                       form.Text = md.MenuCaption;
                       break;
                   case "ar-QA":
                       form.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                       break;
                   case "fr-FR":
                       form.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                       break;
                   case "ml-IN":
                       form.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                       break;
                   case "hi-IN":
                       form.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                       break;
                   case "es-ES":
                       form.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                       break;
                   case "si-LK":
                       form.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                       break;
               }
               
               form.Show();
               form.StartPosition = FormStartPosition.CenterScreen;
               
           }
           catch (Exception ex)
           {
               ExceptionManager.Publish(ex);
              MessageBox.Show("On Development");
           }
       }
       public static void fnActivateForm(string AssemblyName, string ClassName)
       {
           try
           {
               Assembly assembly;
                AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.UI")
               {
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
               }
               else
               {
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
               }
               Type type = assembly.GetType(ClassName);
               Form form = (Form)Activator.CreateInstance(type);
               form.Icon = UICommon._currentICon;
               form.MdiParent = UICommon.frmMdi;
               form.Show();
               form.StartPosition = FormStartPosition.CenterScreen;

           }
           catch (Exception ex)
           {
               ExceptionManager.Publish(ex);
               MessageBox.Show("On Development");
           }
       }
       public static void UpgradeView(bool isWindowsAuthentication)
       {
           Process process = new Process();
           process.StartInfo.FileName = "UpgradeHelper.exe";
           string sArguments = @GlobalFunctions.ServerName + " \"" + GlobalFunctions.DatabaseName + "\" " + isWindowsAuthentication;
           process.StartInfo.Arguments = sArguments;
           process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
           process.Start();
           process.WaitForExit();
       }
      
       public static void AutoBackup(bool isLogin)
       {
           int iLogin=isLogin?0:1;
           Process process = new Process();
           process.StartInfo.FileName = "ERP.AutoBackupProcess.exe";
           string sArguments = @GlobalFunctions.ServerName + " \"" + GlobalFunctions.DatabaseName + "\" " + iLogin + ".bak";
           process.StartInfo.Arguments = sArguments;
           process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
           process.Start();
           process.WaitForExit();
       }
       public static void fnActivateProcess(string ClassName, MenuDetail md)
       {
           Process process = new Process();
           process.StartInfo.FileName = ClassName;
           string sArguments = @GlobalFunctions.ServerName + " \"" + GlobalFunctions.DatabaseName + "\" " + GlobalFunctions.LoginLocationID + " " + GlobalFunctions.CurrentFiscalPeriodID + " " + GlobalFunctions.LoginUserID + " " + GlobalFunctions.CompanyCurrencyID;
           process.StartInfo.Arguments = sArguments;
           process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
           process.Start();
           
       }
       public static void fnActivateDialog(string AssemblyName, string ClassName,MenuDetail md)
       {
           try
           {
               if (ClassName.Contains("AboutUSView"))
               {
                   ClassName = "atACC.UI.AboutUSView";
                   AssemblyName = "atACC.UI";
               }
               Assembly assembly;
               AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.UI")
               {
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
               }
               else
               { 
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
               }
               Type type = assembly.GetType(ClassName);
               Form form = (Form)Activator.CreateInstance(type);
               form.Icon = UICommon._currentICon;
               if (form is ISearchFormBase)
               {
                   ((ISearchFormBase)form).iContextID = md.id;
               }
               switch (GlobalFunctions.LanguageCulture.ToString2())
               {
                   case "":
                       form.Text = md.MenuCaption;
                       break;
                   case "en-US":
                       form.Text = md.MenuCaption;
                       break;
                   case "ar-QA":
                       form.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                       break;
                   case "fr-FR":
                       form.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                       break;
                   case "ml-IN":
                       form.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                       break;
                   case "hi-IN":
                       form.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                       break;
                   case "es-ES":
                       form.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                       break;
                   case "si-LK":
                       form.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                       break;
               }
               //form.MdiParent = Common.frmMdi;
               form.StartPosition = FormStartPosition.CenterScreen;
               form.ShowDialog();


           }
           catch (Exception ex)
           {
               ExceptionManager.Publish(ex);
               MessageBox.Show("On Development");
           }
       }
       public static void fnActivateDialog(string AssemblyName, string ClassName)
       {
           try
           {
               Assembly assembly;
               if (ClassName.Contains("AboutUSView"))
               {
                   ClassName = "atACC.UI.AboutUSView";
                   AssemblyName = "atACC.UI";
               }
                AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.UI")
               {
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
               }
               else
               {
                   assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
               }
               Type type = assembly.GetType(ClassName);
               Form form = (Form)Activator.CreateInstance(type);
               form.Icon = UICommon._currentICon;
               //form.MdiParent = Common.frmMdi;
               form.StartPosition = FormStartPosition.CenterScreen;
               form.ShowDialog();


           }
           catch (Exception ex)
           {
               ExceptionManager.Publish(ex);
               MessageBox.Show("On Development");
           }
       }
       #endregion
   }

}
