﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using atACC.Common;
using atACCORM;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.CommonMessages;
using System.Windows.Forms;
using atACC.HTL.UI.UIClasses;
using System.Runtime.InteropServices;
namespace atACC.HTL.UI
{
  public  class NewDash
  {
      #region Activate Forms
        public static void CreateNewPage(Form obj,MenuDetail md)
        {            
            obj.TopLevel = false;
            TabPage tbp = new TabPage(obj.Text);
            tbp.Tag = md.id;
            UICommon.AppDashboard.tabMain.TabPages.Add(tbp);
            UICommon.AppDashboard.tabMain.SelectedTab = tbp;
            if (md != null)
            {
                tbp.ImageKey = md.id.ToString();
            }
            tbp.Controls.Add(obj);
            obj.FormClosing += new FormClosingEventHandler(obj_FormClosing);
            //obj.StartPosition = FormStartPosition.CenterParent;
            obj.StartPosition = FormStartPosition.Manual;
            obj.Left = (tbp.Width - obj.Width) / 2;
            obj.Top = (tbp.Height - obj.Height) / 2;
            obj.Show();

            obj.Focus();
            obj.BringToFront();
        }
        public static void CreateNewPage(Form obj)
        {
            obj.TopLevel = false;
            TabPage tbp = new TabPage(obj.Text);
            tbp.Tag = 1;
            UICommon.AppDashboard.tabMain.TabPages.Add(tbp);
            UICommon.AppDashboard.tabMain.SelectedTab = tbp;
            tbp.Controls.Add(obj);
            obj.FormClosing += new FormClosingEventHandler(obj_FormClosing);
            //obj.StartPosition = FormStartPosition.CenterParent;
            obj.StartPosition = FormStartPosition.Manual;
            obj.Left = (tbp.Width - obj.Width) / 2;
            obj.Top = (tbp.Height - obj.Height) / 2;
            obj.Show();

            obj.Focus();
            obj.BringToFront();
        }
        static void obj_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form frm = (Form)sender;
            if (frm.Parent is TabPage)
            {
                TabPage tbp = (TabPage)frm.Parent;
                TabPage tabPage = UICommon.AppDashboard.tabMain.TabPages[UICommon.AppDashboard.tabMain.TabPages.Count - 1];
                if (UICommon.PreviousPages != null)
                {
                    while (UICommon.PreviousPages.Count > 0)
                    {
                        UICommon.PreviousPages.RemoveAt(0);
                        if (UICommon.PreviousPages.Count > 0)
                        {
                            if (UICommon.PreviousPages[0] != tbp && UICommon.AppDashboard.tabMain.TabPages.Contains(UICommon.PreviousPages[0]))
                            {
                                tabPage = UICommon.PreviousPages[0];
                                break;
                            }
                        }
                    }
                }
                UICommon.AppDashboard.tabMain.SelectedTab = tabPage;                
                UICommon.AppDashboard.tabMain.TabPages.Remove(tbp);                
                frm.Dispose();
            }
        }
        public static void fnActivateForm(string AssemblyName, string ClassName, MenuDetail md, params object[] parameters)
        {
            try
            {
                Assembly assembly;
                AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.UI")
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
                }
                else
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
                }
                Type type = assembly.GetType(ClassName); 
                Form form = (Form)Activator.CreateInstance(type, parameters);
                form.Icon = UICommon._currentICon;
                if (form is ISearchFormBase)
                {
                    ((ISearchFormBase)form).iContextID = md.id;
                }
                switch (GlobalFunctions.LanguageCulture.ToString2())
                {
                    case "":
                        form.Text = md.MenuCaption;
                        break;
                    case "en-US":
                        form.Text = md.MenuCaption;
                        break;
                    case "ar-QA":
                        form.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                        break;
                    case "fr-FR":
                        form.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                        break;
                    case "ml-IN":
                        form.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                        break;
                    case "hi-IN":
                        form.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                        break;
                    case "es-ES":
                        form.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                        break;
                    case "si-LK":
                        form.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                        break;
                }
                CreateNewPage(form,md);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show("On Development");
            }
        }
        public static void fnActivateForm(string AssemblyName, string ClassName)
        {
            try
            {
                Assembly assembly;
                AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.UI")
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
                }
                else
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
                }
                Type type = assembly.GetType(ClassName);
                Form form = (Form)Activator.CreateInstance(type);
                form.Icon = UICommon._currentICon;
                form.Show();
                CreateNewPage(form, null);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show("On Development");
            }
        }
        public static void fnActivateProcess(string ClassName, MenuDetail md)
        {
            Process process = new Process();
            process.StartInfo.FileName = ClassName;
            string sArguments = @GlobalFunctions.ServerName + " \"" + GlobalFunctions.DatabaseName + "\" " + GlobalFunctions.LoginLocationID + " " + GlobalFunctions.CurrentFiscalPeriodID + " " + GlobalFunctions.LoginUserID + " " + GlobalFunctions.CompanyCurrencyID;
            process.StartInfo.Arguments = sArguments;
            process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            process.Start();

        }
        public static void fnActivateDialog(string AssemblyName, string ClassName, MenuDetail md)
        {
            try
            {
                if (ClassName.Contains("HotelAboutUSView"))
                {
                    ClassName = "atACC.HTL.UI.HotelAboutUSView";
                    AssemblyName = "atACC.HTL.UI";
                }
                Assembly assembly;
                AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.HTL.UI")
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
                }
                else
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
                }
                Type type = assembly.GetType(ClassName);
                Form form = (Form)Activator.CreateInstance(type);
                form.Icon = UICommon._currentICon;
                if (form is ISearchFormBase)
                {
                    ((ISearchFormBase)form).iContextID = md.id;
                }
                switch (GlobalFunctions.LanguageCulture.ToString2())
                {
                    case "":
                        form.Text = md.MenuCaption;
                        break;
                    case "en-US":
                        form.Text = md.MenuCaption;
                        break;
                    case "ar-QA":
                        form.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                        break;
                    case "fr-FR":
                        form.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                        break;
                    case "ml-IN":
                        form.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                        break;
                    case "hi-IN":
                        form.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                        break;
                    case "es-ES":
                        form.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                        break;
                    case "si-LK":
                        form.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                        break;
                }
                form.StartPosition = FormStartPosition.CenterScreen;
                form.ShowDialog();


            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show("On Development");
            }
        }
        public static void fnActivateDialog(string AssemblyName, string ClassName)
        {
            try
            {
                Assembly assembly;
                if (ClassName.Contains("AboutUSView"))
                {
                    ClassName = "atACC.UI.AboutUSView";
                    AssemblyName = "atACC.UI";
                }
                AssemblyName = AssemblyName.Replace("atACC", "ERP");
                if (AssemblyName == "ERP.UI")
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".exe");
                }
                else
                {
                    assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
                }
                Type type = assembly.GetType(ClassName);
                Form form = (Form)Activator.CreateInstance(type);
                form.Icon = UICommon._currentICon;
                form.StartPosition = FormStartPosition.CenterScreen;
                form.ShowDialog();


            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show("On Development");
            }
        }
        #endregion
    }
}
