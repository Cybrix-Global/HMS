﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
namespace atACC.UI.UIClasses
{
   public class Common
   {
       #region "Private Variables"
       public static atMDI frmMdi;
       public static bool isLogined = false;
       #endregion
       #region Public Methods
       
       public void fnActivateForm(string AssemblyName, string ClassName)
       {
           try
           {
               
               Assembly assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
               Type type = assembly.GetType(ClassName);
               Form form = (Form)Activator.CreateInstance(type);
               form.MdiParent = Common.frmMdi;
               form.Show();
               form.StartPosition = FormStartPosition.CenterScreen;
               
           }
           catch (Exception ex)
           {
              MessageBox.Show(ex.Message);
           }
       }
       public void fnActivateDialog(string AssemblyName, string ClassName)
       {
           try
           {
               Assembly assembly = Assembly.LoadFile(Application.StartupPath + "\\" + AssemblyName + ".dll");
               Type type = assembly.GetType(ClassName);
               Form form = (Form)Activator.CreateInstance(type);
               //form.MdiParent = Common.frmMdi;
               form.StartPosition = FormStartPosition.CenterScreen;
               form.ShowDialog();
               

           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
       }
       #endregion
   }

}
