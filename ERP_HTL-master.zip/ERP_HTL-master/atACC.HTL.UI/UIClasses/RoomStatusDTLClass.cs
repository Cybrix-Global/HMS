﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACC.HTL.ORM;

namespace atACC.HTL.UI
{
    public class RoomStatusDTLClass
    {
        public Rooms rooms;
        public RoomTypes roomTypes;
        public Blocks blocks;
        public Floors floors;
        public RoomStatusRegister roomStatusRegisters;
        public RoomStatus roomStatuses;
        public RoomStatusColorSetting RoomStatusColorSetting;
    }
}
