﻿namespace atACC.HTL.UI
{
    partial class atMDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atMDI));
            this.menuStripAcc = new System.Windows.Forms.MenuStrip();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.lblloadTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.notify = new System.Windows.Forms.NotifyIcon(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.btnBlocks = new System.Windows.Forms.Button();
            this.btlFloor = new System.Windows.Forms.Button();
            this.btnAmenities = new System.Windows.Forms.Button();
            this.btnRateTypes = new System.Windows.Forms.Button();
            this.btnRoomTypes = new System.Windows.Forms.Button();
            this.btnRooms = new System.Windows.Forms.Button();
            this.btnHalls = new System.Windows.Forms.Button();
            this.btnHallTypes = new System.Windows.Forms.Button();
            this.btnExtraServ = new System.Windows.Forms.Button();
            this.btnRoomTariff = new System.Windows.Forms.Button();
            this.btnEnq = new System.Windows.Forms.Button();
            this.btnBooking = new System.Windows.Forms.Button();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripAcc
            // 
            this.menuStripAcc.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.menuStripAcc.Location = new System.Drawing.Point(0, 0);
            this.menuStripAcc.Name = "menuStripAcc";
            this.menuStripAcc.Size = new System.Drawing.Size(861, 24);
            this.menuStripAcc.TabIndex = 1;
            this.menuStripAcc.Text = "menuStrip1";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblloadTime,
            this.lbl});
            this.statusStrip.Location = new System.Drawing.Point(0, 435);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(861, 22);
            this.statusStrip.TabIndex = 3;
            this.statusStrip.Text = "statusStrip1";
            // 
            // lblloadTime
            // 
            this.lblloadTime.Name = "lblloadTime";
            this.lblloadTime.Size = new System.Drawing.Size(22, 17);
            this.lblloadTime.Text = "---";
            // 
            // lbl
            // 
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(0, 17);
            // 
            // notify
            // 
            this.notify.Text = "notifyIcon1";
            this.notify.Visible = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 29);
            this.button1.TabIndex = 5;
            this.button1.Text = "Test";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBlocks
            // 
            this.btnBlocks.Location = new System.Drawing.Point(99, 45);
            this.btnBlocks.Name = "btnBlocks";
            this.btnBlocks.Size = new System.Drawing.Size(86, 29);
            this.btnBlocks.TabIndex = 7;
            this.btnBlocks.Text = "Blocks";
            this.btnBlocks.UseVisualStyleBackColor = true;
            this.btnBlocks.Click += new System.EventHandler(this.btnBlocks_Click);
            // 
            // btlFloor
            // 
            this.btlFloor.Location = new System.Drawing.Point(197, 45);
            this.btlFloor.Name = "btlFloor";
            this.btlFloor.Size = new System.Drawing.Size(86, 29);
            this.btlFloor.TabIndex = 8;
            this.btlFloor.Text = "Floors";
            this.btlFloor.UseVisualStyleBackColor = true;
            this.btlFloor.Click += new System.EventHandler(this.btlFloor_Click);
            // 
            // btnAmenities
            // 
            this.btnAmenities.Location = new System.Drawing.Point(99, 80);
            this.btnAmenities.Name = "btnAmenities";
            this.btnAmenities.Size = new System.Drawing.Size(86, 29);
            this.btnAmenities.TabIndex = 9;
            this.btnAmenities.Text = "Amenities";
            this.btnAmenities.UseVisualStyleBackColor = true;
            this.btnAmenities.Click += new System.EventHandler(this.btnAmenities_Click);
            // 
            // btnRateTypes
            // 
            this.btnRateTypes.Location = new System.Drawing.Point(197, 80);
            this.btnRateTypes.Name = "btnRateTypes";
            this.btnRateTypes.Size = new System.Drawing.Size(86, 29);
            this.btnRateTypes.TabIndex = 10;
            this.btnRateTypes.Text = "RateTypes";
            this.btnRateTypes.UseVisualStyleBackColor = true;
            this.btnRateTypes.Click += new System.EventHandler(this.btnRateTypes_Click);
            // 
            // btnRoomTypes
            // 
            this.btnRoomTypes.Location = new System.Drawing.Point(99, 115);
            this.btnRoomTypes.Name = "btnRoomTypes";
            this.btnRoomTypes.Size = new System.Drawing.Size(86, 29);
            this.btnRoomTypes.TabIndex = 11;
            this.btnRoomTypes.Text = "Room Types";
            this.btnRoomTypes.UseVisualStyleBackColor = true;
            this.btnRoomTypes.Click += new System.EventHandler(this.btnRoomTypes_Click);
            // 
            // btnRooms
            // 
            this.btnRooms.Location = new System.Drawing.Point(197, 115);
            this.btnRooms.Name = "btnRooms";
            this.btnRooms.Size = new System.Drawing.Size(86, 29);
            this.btnRooms.TabIndex = 12;
            this.btnRooms.Text = "Rooms";
            this.btnRooms.UseVisualStyleBackColor = true;
            this.btnRooms.Click += new System.EventHandler(this.btnRooms_Click);
            // 
            // btnHalls
            // 
            this.btnHalls.Location = new System.Drawing.Point(197, 150);
            this.btnHalls.Name = "btnHalls";
            this.btnHalls.Size = new System.Drawing.Size(86, 29);
            this.btnHalls.TabIndex = 14;
            this.btnHalls.Text = "Halls";
            this.btnHalls.UseVisualStyleBackColor = true;
            this.btnHalls.Click += new System.EventHandler(this.btnHalls_Click);
            // 
            // btnHallTypes
            // 
            this.btnHallTypes.Location = new System.Drawing.Point(99, 150);
            this.btnHallTypes.Name = "btnHallTypes";
            this.btnHallTypes.Size = new System.Drawing.Size(86, 29);
            this.btnHallTypes.TabIndex = 13;
            this.btnHallTypes.Text = "Hall Types";
            this.btnHallTypes.UseVisualStyleBackColor = true;
            this.btnHallTypes.Click += new System.EventHandler(this.btnHallTypes_Click);
            // 
            // btnExtraServ
            // 
            this.btnExtraServ.Location = new System.Drawing.Point(99, 185);
            this.btnExtraServ.Name = "btnExtraServ";
            this.btnExtraServ.Size = new System.Drawing.Size(86, 29);
            this.btnExtraServ.TabIndex = 15;
            this.btnExtraServ.Text = "Extra Serv";
            this.btnExtraServ.UseVisualStyleBackColor = true;
            this.btnExtraServ.Click += new System.EventHandler(this.btnExtraServ_Click);
            // 
            // btnRoomTariff
            // 
            this.btnRoomTariff.Location = new System.Drawing.Point(197, 185);
            this.btnRoomTariff.Name = "btnRoomTariff";
            this.btnRoomTariff.Size = new System.Drawing.Size(86, 29);
            this.btnRoomTariff.TabIndex = 16;
            this.btnRoomTariff.Text = "Room Tariff";
            this.btnRoomTariff.UseVisualStyleBackColor = true;
            this.btnRoomTariff.Click += new System.EventHandler(this.btnRoomTariff_Click);
            // 
            // btnEnq
            // 
            this.btnEnq.Location = new System.Drawing.Point(328, 45);
            this.btnEnq.Name = "btnEnq";
            this.btnEnq.Size = new System.Drawing.Size(86, 29);
            this.btnEnq.TabIndex = 18;
            this.btnEnq.Text = "Enquery";
            this.btnEnq.UseVisualStyleBackColor = true;
            this.btnEnq.Click += new System.EventHandler(this.btnEnq_Click);
            // 
            // btnBooking
            // 
            this.btnBooking.Location = new System.Drawing.Point(420, 45);
            this.btnBooking.Name = "btnBooking";
            this.btnBooking.Size = new System.Drawing.Size(86, 29);
            this.btnBooking.TabIndex = 20;
            this.btnBooking.Text = "Booking";
            this.btnBooking.UseVisualStyleBackColor = true;
            this.btnBooking.Click += new System.EventHandler(this.btnBooking_Click);
            // 
            // atMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(861, 457);
            this.Controls.Add(this.btnBooking);
            this.Controls.Add(this.btnEnq);
            this.Controls.Add(this.btnRoomTariff);
            this.Controls.Add(this.btnExtraServ);
            this.Controls.Add(this.btnHalls);
            this.Controls.Add(this.btnHallTypes);
            this.Controls.Add(this.btnRooms);
            this.Controls.Add(this.btnRoomTypes);
            this.Controls.Add(this.btnRateTypes);
            this.Controls.Add(this.btnAmenities);
            this.Controls.Add(this.btlFloor);
            this.Controls.Add(this.btnBlocks);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStripAcc);
            this.DoubleBuffered = true;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStripAcc;
            this.Name = "atMDI";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.atMDI_FormClosing);
            this.Load += new System.EventHandler(this.atMDI_Load);
            this.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.atMDI_MouseDoubleClick);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripAcc;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.NotifyIcon notify;
        private System.Windows.Forms.ToolStripStatusLabel lblloadTime;
        private System.Windows.Forms.ToolStripStatusLabel lbl;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnBlocks;
        private System.Windows.Forms.Button btlFloor;
        private System.Windows.Forms.Button btnAmenities;
        private System.Windows.Forms.Button btnRateTypes;
        private System.Windows.Forms.Button btnRoomTypes;
        private System.Windows.Forms.Button btnRooms;
        private System.Windows.Forms.Button btnHalls;
        private System.Windows.Forms.Button btnHallTypes;
        private System.Windows.Forms.Button btnExtraServ;
        private System.Windows.Forms.Button btnRoomTariff;
        private System.Windows.Forms.Button btnEnq;
        private System.Windows.Forms.Button btnBooking;
    }
}

