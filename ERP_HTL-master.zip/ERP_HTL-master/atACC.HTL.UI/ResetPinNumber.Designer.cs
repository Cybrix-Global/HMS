﻿namespace atACC.HTL.UI
{
    partial class ResetPinNumber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResetPinNumber));
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.txtConfirmPIN = new atACCFramework.UserControls.TextBoxExt();
            this.txtPIN = new atACCFramework.UserControls.TextBoxExt();
            this.txtUserName = new atACCFramework.UserControls.TextBoxExt();
            this.lblUserName = new atACCFramework.UserControls.atLabel();
            this.lblPassword = new atACCFramework.UserControls.atLabel();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblConfirmPassword = new atACCFramework.UserControls.atLabel();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.txtConfirmPIN);
            this.pnlMain.Controls.Add(this.txtPIN);
            this.pnlMain.Controls.Add(this.txtUserName);
            this.pnlMain.Controls.Add(this.lblUserName);
            this.pnlMain.Controls.Add(this.lblPassword);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblConfirmPassword);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Name = "pnlMain";
            // 
            // txtConfirmPIN
            // 
            resources.ApplyResources(this.txtConfirmPIN, "txtConfirmPIN");
            this.txtConfirmPIN.BackColor = System.Drawing.SystemColors.Window;
            this.txtConfirmPIN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtConfirmPIN.Format = null;
            this.txtConfirmPIN.isAllowNegative = false;
            this.txtConfirmPIN.isAllowSpecialChar = false;
            this.txtConfirmPIN.isNumbersOnly = true;
            this.txtConfirmPIN.isNumeric = false;
            this.txtConfirmPIN.isTouchable = false;
            this.txtConfirmPIN.Name = "txtConfirmPIN";
            this.txtConfirmPIN.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtConfirmPIN.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtConfirmPIN_KeyDown);
            // 
            // txtPIN
            // 
            resources.ApplyResources(this.txtPIN, "txtPIN");
            this.txtPIN.BackColor = System.Drawing.SystemColors.Window;
            this.txtPIN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPIN.Format = null;
            this.txtPIN.isAllowNegative = false;
            this.txtPIN.isAllowSpecialChar = false;
            this.txtPIN.isNumbersOnly = true;
            this.txtPIN.isNumeric = false;
            this.txtPIN.isTouchable = false;
            this.txtPIN.Name = "txtPIN";
            this.txtPIN.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtUserName
            // 
            resources.ApplyResources(this.txtUserName, "txtUserName");
            this.txtUserName.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUserName.Format = null;
            this.txtUserName.isAllowNegative = false;
            this.txtUserName.isAllowSpecialChar = false;
            this.txtUserName.isNumbersOnly = false;
            this.txtUserName.isNumeric = false;
            this.txtUserName.isTouchable = false;
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblUserName
            // 
            resources.ApplyResources(this.lblUserName, "lblUserName");
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.RequiredField = false;
            // 
            // lblPassword
            // 
            resources.ApplyResources(this.lblPassword, "lblPassword");
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.RequiredField = false;
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblConfirmPassword
            // 
            resources.ApplyResources(this.lblConfirmPassword, "lblConfirmPassword");
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.RequiredField = false;
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // ResetPinNumber
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "ResetPinNumber";
            this.NewRecord = true;
            this.atOkClick += new atACCFramework.BaseClasses.OKClickEventHandler(this.ResetPinNumber_atOkClick);
            this.atCancelClick += new atACCFramework.BaseClasses.CancelClickEventHandler(this.ResetPinNumber_atCancelClick);
            this.atValidate += new atACCFramework.BaseClasses.ValidateOKClickHandler(this.ResetPinNumber_atValidate);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.ResetPinNumber_atInitialise);
            this.Activated += new System.EventHandler(this.ResetPinNumber_Activated);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblConfirmPassword;
        private atACCFramework.UserControls.TextBoxExt txtConfirmPIN;
        private atACCFramework.UserControls.TextBoxExt txtPIN;
        private atACCFramework.UserControls.TextBoxExt txtUserName;
        private atACCFramework.UserControls.atLabel lblUserName;
        private atACCFramework.UserControls.atLabel lblPassword;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory3;
    }
}