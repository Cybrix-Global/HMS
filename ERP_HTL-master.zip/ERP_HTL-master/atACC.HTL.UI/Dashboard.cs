﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.Runtime.InteropServices;
using atACC.Common;
using atACC.Common.Classes;
using atACC.HTL.UI.UIClasses;
using atACCORM;
using atACC.CommonMessages;
using LocalORM;
using atACC.CommonExtensions;
using atACCFramework.BaseClasses;
using atACCFramework.UserControls;
using atACCFramework.Common;
using atACC.HTL.UI.UserControls;
using atACC.HTL.ORM;
using atACC.HTL.UI.UIClasses;

namespace atACC.HTL.UI
{
    public partial class Dashboard : FormBase
    {
        #region Private Fields
        atACCContextEntities db;
        public List<MenuDetail> m_MenuDetails;
        public ImageList tabImages;
        public ContextMenu userContext;
        ContextMenu favouriteContext;
        ContextMenuStrip roomContext;
        MenuItem menuItemUser;
        TabPage tbpDash;
        TabPage tbpHom;
        bool LanguageSet = false;
        string strAddCaption;
        string strHomeCaption;
        string strDashboardCaption;
        bool _OnLoad;
        DateTime _dtLastReminderTime;        
        enum ENStyle
        {
            List, Calendar
        }
        #endregion

        #region Constructor
        public Dashboard()
        {
            InitializeComponent();
            db = atContext.CreateContext();            
            pnlMenus.Visible = false;
            tbpDash = tabMain.TabPages["tbpDashboard"];
            tbpHom = tabMain.TabPages["tbpHome"];
            strAddCaption = "Add";
            strHomeCaption = "Home";
            strDashboardCaption = "Dashboard";            
        }
        #endregion
            
        #region Menu Methods
        public void PopulateMenuDetails()
        {
            db = atContext.CreateContext();
            GlobalFunctions.LoadMenuDetails(ref db);
            m_MenuDetails = GlobalFunctions.entMenuDetails;

        }
        private void fnPopulateMenuStrips()
        {
            fnPopulateMenuByParentID(btnMasters, 1403);
            fnPopulateMenuByParentID(btnTransactions, 1404);
            fnPopulateMenuByParentID(btnReports, 1405);
            fnPopulateMenuByParentID(btnSettings, 1406);
            fnPopulateMenuByParentID(btnTools, 1407);
            fnPopulateMenuByParentID(btnAddOns, 1408);
            fnPopulateMenuByParentID(btnHelp, 1409);
        }
        private void ApplyDesign(ref ToolStripMenuItem menuItem)
        {
            menuItem.BackColor = Color.DarkGray; //.FromArgb(27, 33, 51);
            menuItem.ForeColor = Color.Black;
            menuItem.AutoSize = true;
            menuItem.Font = new System.Drawing.Font("Open Sans", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //menuItem.Size = new Size(130, 35);
        }
        private void fnPopulateMenuByParentID(Button parent, int parentID)
        {
            try
            {
                ContextMenuStrip menuStripAcc = new ContextMenuStrip();
                foreach (MenuDetail md in m_MenuDetails.Where(x => x.Parentid == parentID).OrderBy(x => x.DisplayPosition).ToList())
                {
                    if (md.MenuVisible.toBool())
                    {
                        ToolStripMenuItem menuItem = new ToolStripMenuItem(md.MenuName);
                        ApplyDesign(ref menuItem);
                        switch (GlobalFunctions.LanguageCulture.ToString2())
                        {
                            case "":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "en-US":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "ar-QA":
                                menuItem.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                                break;
                            case "fr-FR":
                                menuItem.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                                break;
                            case "ml-IN":
                                menuItem.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                                break;
                            case "hi-IN":
                                menuItem.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                                break;
                            case "es-ES":
                                menuItem.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                                break;
                            case "si-LK":
                                menuItem.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                                break;
                        }
                        menuItem.Text = menuItem.Text.PadRight(20);
                        menuItem.Name = md.MenuName;
                        menuItem.Click += new EventHandler(ToolStripMenuItem_Click);
                        menuItem.MouseEnter += new EventHandler(menuItem_MouseEnter);
                        menuItem.MouseHover += new EventHandler(menuItem_MouseHover);
                        menuItem.MouseLeave += new EventHandler(menuItem_MouseLeave);
                        menuItem.Tag = md;
                        menuItem.Image = UICommon.byteArrayToImage(md.Icon);
                        menuStripAcc.Items.Add(menuItem);
                        fnAddChildMenu(menuItem, md.id);
                    }
                }
                parent.ContextMenuStrip = menuStripAcc;

            }
            catch (Exception)
            {

                throw;
            }

        }
        void menuItem_MouseEnter(object sender, EventArgs e)
        {
            ((ToolStripMenuItem)sender).ForeColor = Color.DarkBlue;
        }
        void menuItem_MouseLeave(object sender, EventArgs e)
        {
            ((ToolStripMenuItem)sender).ForeColor = Color.Black;
        }
        void menuItem_MouseHover(object sender, EventArgs e)
        {
            ((ToolStripMenuItem)sender).ForeColor = Color.DarkBlue;
        }
        private void fnAddChildMenu(ToolStripMenuItem MenuItem, int MenueID)
        {
            try
            {
                foreach (MenuDetail md in m_MenuDetails.Where(x => x.Parentid == MenueID).OrderBy(x => x.DisplayPosition).ToList())
                {
                    if (md.MenuVisible.toBool())
                    {
                        ToolStripMenuItem menuItem = new ToolStripMenuItem(md.MenuName);
                        menuItem.Tag = md;
                        ApplyDesign(ref menuItem);
                        switch (GlobalFunctions.LanguageCulture.ToString2())
                        {
                            case "":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "en-US":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "ar-QA":
                                menuItem.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                                break;
                            case "fr-FR":
                                menuItem.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                                break;
                            case "ml-IN":
                                menuItem.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                                break;
                            case "hi-IN":
                                menuItem.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                                break;
                            case "es-ES":
                                menuItem.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                                break;
                            case "si-LK":
                                menuItem.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                                break;
                        }
                        menuItem.Name = md.MenuName;
                        menuItem.Image = UICommon.byteArrayToImage(md.Icon);
                        menuItem.Click += new EventHandler(ToolStripMenuItem_Click);
                        menuItem.MouseEnter += new EventHandler(menuItem_MouseEnter);
                        menuItem.MouseHover += new EventHandler(menuItem_MouseHover);
                        menuItem.MouseLeave += new EventHandler(menuItem_MouseLeave);
                        if (md.ShortCutID != null && md.ShortCutID.toInt32() != 0)
                        {
                            menuItem.ShortcutKeys = getShortCutKeys(md.ShortCutID.toInt32());
                        }
                        MenuItem.DropDownItems.Add(menuItem);

                        fnAddChildMenu(menuItem, md.id);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private Keys getShortCutKeys(int id)
        {
            Keys _key = (Keys)id;
            return _key;
        }
        private void ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ToolStripMenuItem menuItem = (ToolStripMenuItem)sender;
                if (menuItem.Tag != null)
                {
                    if (menuItem.Tag is MenuDetail)
                    {
                        int menuid = ((MenuDetail)menuItem.Tag).id;
                        MenuDetail md = m_MenuDetails.Where(x => x.id == menuid).Single();
                        UICommon common = new UICommon();
                        if (md.AssemblyName != "" && md.ClassName != "")
                        {
                            if (md.isDialog.toBool())
                            {
                                NewDash.fnActivateDialog(md.AssemblyName, md.ClassName, md);
                            }
                            else
                            {
                                this.Cursor = Cursors.WaitCursor;
                                if(md.ClassName == "atACC.ADM.Tools.InvoiceDesignerView")
                                    NewDash.fnActivateForm(md.AssemblyName, md.ClassName, md, 4);
                                else
                                    NewDash.fnActivateForm(md.AssemblyName, md.ClassName, md);
                            }
                        }
                        else if (md.ClassName != "")
                        {
                            this.Cursor = Cursors.WaitCursor;
                            NewDash.fnActivateProcess(md.ClassName, md);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            this.Cursor = Cursors.Arrow;
        }
        private void RoomContextMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ToolStripMenuItem menuItem = (ToolStripMenuItem)sender;
                if (menuItem.Tag != null)
                {
                    if (menuItem.Tag is MenuDetail)
                    {
                        int menuid = ((MenuDetail)menuItem.Tag).id;
                        MenuDetail md = m_MenuDetails.Where(x => x.id == menuid).Single();
                        int RoomID = 0;
                        DateTime? dtFrom = null, dtTo = null;
                        if (cmbStyle.SelectedValue.ToInt32() == (int)ENStyle.List)
                        {
                            atRoomView atRoom = (atRoomView)roomContext.SourceControl;
                            RoomID = atRoom.RoomID;
                        }
                        else
                        {
                            atRoomGrid atRoomGrid = (atRoomGrid)roomContext.SourceControl;                            
                            RoomID = atRoomGrid.CurrentRoom.id;
                            dtFrom = atRoomGrid.SelectedFromDate;
                            dtTo = atRoomGrid.SelectedToDate;
                        }
                        
                        this.Cursor = Cursors.WaitCursor;
                        if (menuid == (int)EnContextID.HTL_BookingView || menuid == (int)EnContextID.HTL_CheckInView)
                            NewDash.fnActivateForm(md.AssemblyName, md.ClassName, md, 0, RoomID, dtFrom, dtTo);
                        else
                            NewDash.fnActivateForm(md.AssemblyName, md.ClassName, md, RoomID);
                        this.Cursor = Cursors.Arrow;
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            this.Cursor = Cursors.Arrow;
        }
        private void ShowContextMenu(Button button)
        {
            if (button.ContextMenuStrip != null)
            {
                button.ContextMenuStrip.Show(button, new Point(pnlOptional.Width, 0));
            }
        }
        public void CreateFavouriteContext()
        {
            favouriteContext = new ContextMenu();
            favouriteContext.MenuItems.Clear();
            MenuItem favMenuItem = new MenuItem("Delete");
            favMenuItem.Click += new EventHandler(favMenuItem_Click);
            favouriteContext.MenuItems.Add(favMenuItem);
        }
        public void CreateRoomContext()
        {
            using (atACCContextEntities db = atContext.CreateContext())
            {
                roomContext = new ContextMenuStrip();
                List<MenuDetail> menuDetails = m_MenuDetails.Where(x =>
                                                x.id == (int)EnContextID.HTL_BookingView ||
                                                x.id == (int)EnContextID.HTL_CheckInView ||
                                                x.id == (int)EnContextID.HTL_RoomServiceView).ToList();
                foreach (MenuDetail md in menuDetails.OrderBy(x => x.DisplayPosition).ToList())
                {
                    if (md.MenuVisible.toBool())
                    {
                        ToolStripMenuItem menuItem = new ToolStripMenuItem(md.MenuName);
                        ApplyDesign(ref menuItem);
                        switch (GlobalFunctions.LanguageCulture.ToString2())
                        {
                            case "":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "en-US":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "ar-QA":
                                menuItem.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                                break;
                            case "fr-FR":
                                menuItem.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                                break;
                            case "ml-IN":
                                menuItem.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                                break;
                            case "hi-IN":
                                menuItem.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                                break;
                            case "es-ES":
                                menuItem.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                                break;
                            case "si-LK":
                                menuItem.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                                break;
                        }
                        menuItem.Text = menuItem.Text.PadRight(20);
                        menuItem.Name = md.MenuName;
                        menuItem.Click += new EventHandler(RoomContextMenuItem_Click);
                        menuItem.MouseEnter += new EventHandler(menuItem_MouseEnter);
                        menuItem.MouseHover += new EventHandler(menuItem_MouseHover);
                        menuItem.MouseLeave += new EventHandler(menuItem_MouseLeave);
                        menuItem.Tag = md;
                        menuItem.Image = UICommon.byteArrayToImage(md.Icon);
                        roomContext.Items.Add(menuItem);                        
                    }
                }
                
            }
        }
        void favMenuItem_Click(object sender, EventArgs e)
        {
            if (favouriteContext.SourceControl != null)
            {
                FavouriteItem item = (FavouriteItem)((atFavoritesButton)favouriteContext.SourceControl).Tag;
                MenuDetail menudetail = (MenuDetail)item.menuItem;
                DeleteFromFavourite(menudetail.id);
                PopulateFavourites();
            }
        }
        #endregion

        #region PopulateEvents
        private void RefreshDashboard(bool blnRefreshCombo = true, bool blnRefreshAllTabs = false)
        {
            if (tabMain.SelectedTab == tbpHom || blnRefreshAllTabs)
            {
                if (blnRefreshCombo)
                {
                    RefreshCombos();
                }

                if (cmbStyle.SelectedValue.ToInt32() == (int)ENStyle.List)
                    PopulateRooms();
                else
                    PopulateRoomGrid();
                
            }
            if(tabMain.SelectedTab == tbpDash || blnRefreshAllTabs)
            {
                PopulateDashboardTab();
            }
        }
        public void RefreshCombos()
        {
            _OnLoad = true;
            int iBlock = cmbBlock.SelectedValue.ToInt32();
            int iFloor = cmbFloor.SelectedValue.ToInt32();
            int iRoomHall = cmbRoomHall.SelectedValue.ToInt32();
            int iRoomHallType = cmbRoomHallType.SelectedValue.ToInt32();
            int iRoomStatus = cmbRoomStatus.SelectedValue.ToInt32();
            int iStyle = cmbStyle.SelectedValue.ToInt32();
            int iCalendarDays = cmbCalendarDays.SelectedValue.ToInt32();

            PopulateCombos();

            cmbBlock.SelectedValue = iBlock;
            cmbFloor.SelectedValue = iFloor;
            cmbRoomHall.SelectedValue = iRoomHall;
            cmbRoomHallType.SelectedValue = iRoomHallType;
            cmbRoomStatus.SelectedValue = iRoomStatus;
            cmbStyle.SelectedValue = iStyle;
            cmbCalendarDays.SelectedValue = iCalendarDays;
            _OnLoad = false;
        }
        public void PopulateCombos()
        {
            PopulateComboRoomType();
            PopulateComboFloor();
            PopulateComboBlock();
            PopulateComboRoomHall();
            PopulateComboRoomStatus();
            PopulateComboStyle();
            PopulateComboCalendarDays();
        }
        public void PopulateComboBlock()
        {
            try
            {
                using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                {
                    
                    #region Block
                    var Block = dbh.Blocks.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                    Block.Insert(0, new Blocks
                    {
                        id = 0,
                        Name = MessageKeys.MsgAll
                    });
                    cmbBlock.DataSource = Block.ToList();
                    cmbBlock.DisplayMember = "Name";
                    cmbBlock.ValueMember = "id";
                    cmbBlock.SelectedValue = 0;
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public void PopulateComboFloor()
        {
            try
            {
                using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                {
                    
                    #region Floor
                    var Floor = dbh.Floors.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                    Floor.Insert(0, new Floors
                    {
                        id = 0,
                        Name = MessageKeys.MsgAll
                    });
                    cmbFloor.DataSource = Floor.ToList();
                    cmbFloor.DisplayMember = "Name";
                    cmbFloor.ValueMember = "id";
                    cmbFloor.SelectedValue = 0;
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public void PopulateComboRoomHall()
        {
            try
            {
                List<HTL.ORM.MasterValue> masterValues = new List<HTL.ORM.MasterValue>();
                masterValues.Add(new HTL.ORM.MasterValue { id = 0, Name = MessageKeys.MsgAll });
                masterValues.Add(new HTL.ORM.MasterValue { id = 1, Name = MessageKeys.MsgRoom });
                masterValues.Add(new HTL.ORM.MasterValue { id = 2, Name = MessageKeys.MsgHall });
                cmbRoomHall.DataSource = masterValues;
                cmbRoomHall.DisplayMember = "Name";
                cmbRoomHall.ValueMember = "id";
                cmbRoomHall.SelectedValue = 0;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public void PopulateComboStyle()
        {
            try
            {
                List<HTL.ORM.MasterValue> masterValues = new List<HTL.ORM.MasterValue>();
                masterValues.Add(new HTL.ORM.MasterValue { id = 0, Name = "List" });
                masterValues.Add(new HTL.ORM.MasterValue { id = 1, Name = "Calendar" });
                cmbStyle.DataSource = masterValues;
                cmbStyle.DisplayMember = "Name";
                cmbStyle.ValueMember = "id";
                cmbStyle.SelectedValue = Properties.Settings.Default.RoomViewStyle;
                SetCalendarComboVisibility();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public void PopulateComboCalendarDays()
        {
            try
            {
                List<HTL.ORM.MasterValue> masterValues = new List<HTL.ORM.MasterValue>();
                masterValues.Add(new HTL.ORM.MasterValue { id = 7, Name = "1 Week" });
                masterValues.Add(new HTL.ORM.MasterValue { id = 14, Name = "2 Weeks" });
                masterValues.Add(new HTL.ORM.MasterValue { id = 28, Name = "4 Weeks" });
                cmbCalendarDays.DataSource = masterValues;
                cmbCalendarDays.DisplayMember = "Name";
                cmbCalendarDays.ValueMember = "id";
                cmbCalendarDays.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public void PopulateComboRoomType()
        {
            try
            {
                using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                {
                    #region RoomType
                    bool? blnIsHallType = (cmbRoomHall.Text == MessageKeys.MsgAll
                                            ? null
                                            : (bool?)(cmbRoomHall.Text == MessageKeys.MsgHall));
                    var RoomType = dbh.RoomTypes.Where(x => (blnIsHallType == null || x.IsHallType == blnIsHallType)).ToList();
                    RoomType.Insert(0, new RoomTypes
                    {
                        id = 0,
                        Name = MessageKeys.MsgAll
                    });
                    cmbRoomHallType.DataSource = RoomType.ToList();
                    cmbRoomHallType.DisplayMember = "Name";
                    cmbRoomHallType.ValueMember = "id";
                    cmbRoomHallType.SelectedValue = 0;
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public void PopulateComboRoomStatus()
        {
            try
            {
                using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                {
                    #region Status
                    
                    var roomStatus = dbh.RoomStatus.ToList();
                    roomStatus.Insert(0, new RoomStatus
                    {
                        id = 0,
                        Name = MessageKeys.MsgAll
                    });
                    cmbRoomStatus.DataSource = roomStatus.ToList();
                    cmbRoomStatus.DisplayMember = "Name";
                    cmbRoomStatus.ValueMember = "id";
                    cmbRoomStatus.SelectedValue = 0;
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public List<RoomStatusDTLClass> GetRoomStatusDTLClasses()
        {
            //Return Status of all Rooms/Halls As on a DateTime
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                int iBlock = cmbBlock.SelectedValue.ToInt32();
                int iFloor = cmbFloor.SelectedValue.ToInt32();
                int iRoomHallType = cmbRoomHallType.SelectedValue.ToInt32();
                int iRoomStatus = cmbRoomStatus.SelectedValue.ToInt32();
                DateTime dtAsOn = chkAsOn.Checked ? dtpAsOn.Value : DateTime.Now;
                List<RoomStatusRegister> roomStatusReg = GlobalMethods.GetRoomStatusByDate(dtAsOn);
                bool? blnIsHall = (cmbRoomHall.Text == MessageKeys.MsgAll
                                            ? null
                                            : (bool?)(cmbRoomHall.Text == MessageKeys.MsgHall));

                return  (from r in dbh.Rooms.Where(x => x.Actice == true).ToList()
                                join rt in dbh.RoomTypes.Where(x => x.Active == true).ToList() on r.FK_RoomTypeID equals rt.id
                                join b in dbh.Blocks.Where(x => x.Active == true).ToList() on r.FK_BlockID equals b.id
                                join f in dbh.Floors.Where(x => x.Active == true).ToList() on r.FK_FloorID equals f.id
                                join rsr in roomStatusReg on r.id equals rsr.FK_RoomID
                                join rs in dbh.RoomStatus.ToList() on rsr.FK_StatusID equals rs.id
                                join rsc in dbh.RoomStatusColorSettings on rs.id equals rsc.FK_RoomStatusID
                                where (iBlock == 0 || iBlock == b.id) &&
                                      (iFloor == 0 || iFloor == f.id) &&
                                      (blnIsHall == null || blnIsHall == r.IsHall) &&
                                      (iRoomHallType == 0 || iRoomHallType == rt.id) &&
                                      (iRoomStatus == 0 || iRoomStatus == rs.id)
                                select new RoomStatusDTLClass 
                                { 
                                    rooms = r, 
                                    roomTypes= rt, 
                                    blocks = b, 
                                    floors = f, 
                                    roomStatusRegisters = rsr, 
                                    roomStatuses = rs,
                                    RoomStatusColorSetting = rsc
                                }).ToList();
            }
        }
        public void PopulateRooms()
        {
            var roomDTLs = GetRoomStatusDTLClasses();

            int iIndex = 0;
            if (pnlHome.Controls.Count > 0 && !(pnlHome.Controls[0] is atRoomView))
                pnlHome.Controls.Clear();
            int iCurrentCount = pnlHome.Controls.Count;
            foreach (var roomDtl in roomDTLs)
            {
                iIndex++;
                #region Create / Select control
                atRoomView room;
                if (iIndex > iCurrentCount)
                {
                    room = new atRoomView();
                }
                else
                {
                    room = (atRoomView)pnlHome.Controls[iIndex - 1];
                }
                #endregion

                #region Set control properties
                room.RoomID = roomDtl.rooms.id;
                room.RoomName = roomDtl.rooms.Name;
                room.GuestName = roomDtl.roomStatusRegisters.GuestName;
                room.RoomTypeImage = GetImageFromColor(Color.FromArgb(roomDtl.roomTypes.Color.ToInt32()));
                room.StatusName = roomDtl.roomStatuses.Name;
                room.ArrivalDate = roomDtl.roomStatusRegisters.FromDate.Value;
                room.DepartureDate = roomDtl.roomStatusRegisters.ToDate.Value;
                room.HideArrivalDepartureDates = roomDtl.roomStatusRegisters.FromDate == roomDtl.roomStatusRegisters.ToDate;
                room.Adults = roomDtl.roomStatusRegisters.Adult.Value;
                room.Childs = roomDtl.roomStatusRegisters.Child.Value;
                room.FK_TransactionTypeID = roomDtl.roomStatusRegisters.FK_TransactionTypeID.ToInt32();
                room.FK_TransactionID = roomDtl.roomStatusRegisters.FK_TransactionID.ToInt32();
                room.Margin = new Padding(10);
                room.MouseClick -= Room_MouseClick;
                room.MouseClick += Room_MouseClick;
                room.MouseDoubleClick -= Room_MouseDoubleClick;
                room.MouseDoubleClick += Room_MouseDoubleClick;
                room.StatusColor = Color.FromArgb(roomDtl.RoomStatusColorSetting.Color.Value);
                #endregion

                #region Add object
                if (iIndex > iCurrentCount)
                {
                    pnlHome.Controls.Add(room);
                }
                #endregion
            }
            #region Remove extra controls
            if (iIndex < iCurrentCount)
            {
                for (int i = iIndex; i < iCurrentCount; i++)
                {
                    pnlHome.Controls.RemoveAt(iIndex);
                }
            }
            #endregion

            GlobalProperties.RefreshDashboard = false;

        }
        public void PopulateRoomGrid()
        {
            atRoomGrid roomGrid = new atRoomGrid();            
            roomGrid.Width = pnlHome.Width - 10;
            roomGrid.Height = pnlHome.Height - 120;
            roomGrid.MouseDoubleClick -= Room_MouseDoubleClick;
            roomGrid.MouseDoubleClick += Room_MouseDoubleClick;
            roomGrid.MouseClick -= Room_MouseClick;
            roomGrid.MouseClick += Room_MouseClick;
            pnlHome.Controls.Clear();
            pnlHome.Controls.Add(roomGrid);

            var roomDTLs = GetRoomStatusDTLClasses();
            roomGrid.PopulateGrids(dtpAsOn.Value.Date, cmbCalendarDays.SelectedValue.ToInt32(), roomDTLs);
            GlobalProperties.RefreshDashboard = false;
        }

        public void PopulateDashboardTab()
        {
            atdashflowpanel.Controls.Clear();

            //Total control
            atdashflowpanel.Controls.Add(new atTotalValues());
            atdashflowpanel.Controls.Add(new atRateListView());
            atdashflowpanel.Controls.Add(new atAmenityList());
            atdashflowpanel.Controls.Add(new ComplaintList());
            atdashflowpanel.Controls.Add(new atBookingReminder());
        }
        private void UpdateReminder()
        {
            atACC.HTL.ORM.SqlHelper sqlHelper = new atACC.HTL.ORM.SqlHelper();
            List<SqlParameter> sqlParameter = new List<SqlParameter>
            {
                new SqlParameter("FromDate", DateTime.Now)
            };
            DataTable dtReminder = sqlHelper.ExecuteProcedure("SPGetGuestReminder", sqlParameter).Tables[0];            
            lblReminderCount.Text = dtReminder.Rows.Count.ToString();
            lblReminderCount.Visible = dtReminder.Rows.Count > 0;            
            pnlRemindContain.Controls.Clear();
            foreach (DataRow dr in dtReminder.Rows)
            {
                atReminderListView reminderListView = new atReminderListView()
                {
                    ReminderID = dr["id"].ToInt32(),
                    GuestName = dr["Name"].ToString2(),
                    Room = dr["Room"].ToString2(),
                    Message = dr["Message"].ToString2(),
                    ReminderDate = dr["ReminderDate"].ToString2().toDateTime(),
                };
                reminderListView.RemoveReminder += (s, e) => UpdateReminder();
                pnlRemindContain.Controls.Add(reminderListView);
            }
            _dtLastReminderTime = DateTime.Now;
            _dtLastReminderTime.AddSeconds(-1 * _dtLastReminderTime.Second);
        }

        private void Room_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                int iTransTypeID = 0, iTransID = 0;
                if (cmbStyle.SelectedValue.ToInt32() == (int)ENStyle.List)
                {
                    atRoomView atRoom = (atRoomView)((Control)sender);
                    iTransTypeID = atRoom.FK_TransactionTypeID;
                    iTransID = atRoom.FK_TransactionID;
                }
                else
                {
                    atRoomGrid roomGrid = (atRoomGrid)((Control)sender);
                    if (roomGrid.CurrentCell != null && roomGrid.CurrentCell.Tag != null)
                    {
                        RoomStatusRegister roomStatusRegister = (RoomStatusRegister)roomGrid.CurrentCell.Tag;
                        iTransTypeID = roomStatusRegister.FK_TransactionTypeID ?? 0;
                        iTransID = roomStatusRegister.FK_TransactionID ?? 0;
                    }

                }
                if (iTransTypeID > 0 && iTransID > 0)
                {
                    int menuid = 0;
                    switch (iTransTypeID)
                    {
                        case (int)ENMVMTTransactionType.HTL_Booking:
                            menuid = (int)EnContextID.HTL_BookingView;
                            break;
                        case (int)ENMVMTTransactionType.HTL_CheckIn:
                            menuid = (int)EnContextID.HTL_CheckInView;
                            break;
                        case (int)ENMVMTTransactionType.HTL_GroupBooking:
                            menuid = (int)EnContextID.HTL_GroupBookingView;
                            iTransID = GetGroupBookingIDFromDTLID(iTransID);
                            break;
                        case (int)ENMVMTTransactionType.HTL_GroupCheckIn:
                            menuid = (int)EnContextID.HTL_GroupCheckInView;
                            iTransID = GetGroupChechIDFromDTLID(iTransID);
                            break;
                        default:
                            return;
                    }

                    MenuDetail md = m_MenuDetails.Where(x => x.id == menuid).Single();
                    this.Cursor = Cursors.WaitCursor;
                    NewDash.fnActivateForm(md.AssemblyName, md.ClassName, md, iTransID);
                    this.Cursor = Cursors.Arrow;
                }
            }
        }

        private void Room_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (cmbStyle.SelectedValue.ToInt32() == (int)ENStyle.List)
                    roomContext.Show((Control)sender, ((Control)sender).Width / 2, ((Control)sender).Height / 2);
                else if(((atRoomGrid)sender).CurrentCell != null)
                    roomContext.Show((Control)sender, e.X, e.Y + 40);
            }
            
        }
        private int GetGroupBookingIDFromDTLID(int iDTLID)
        {
            using(atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                return dbh.GroupBookingDTLs.Where(x => x.id == iDTLID).Select(x => x.FK_GroupBookingID).SingleOrDefault().ToInt32();
            }
        }
        private int GetGroupChechIDFromDTLID(int iDTLID)
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                return dbh.GroupCheckInDTLs.Where(x => x.id == iDTLID).Select(x => x.FK_GroupCheckInID).SingleOrDefault().ToInt32();
            }
        }
        private void SetCalendarComboVisibility()
        {
            cmbCalendarDays.Visible = lblCalendarDays.Visible =
                    cmbStyle.SelectedValue.ToInt32() == (int)ENStyle.Calendar;
        }
        private Image GetImageFromColor(Color clr)
        {
            int width = 50, height = 50;
            Bitmap Bmp = new Bitmap(width, height);
            using (Graphics gfx = Graphics.FromImage(Bmp))
            using (SolidBrush brush = new SolidBrush(clr))
            {
                gfx.FillRectangle(brush, 0, 0, width, height);
            }
            return Bmp;
        }
        private void PopulateLanguage()
        {
            SettingsDbEntities sdb = new SettingsDbEntities();
            cmbLanguage.DataSource = sdb.Languages.Where(x => x.id == 1 || x.id == 2).ToList();
            cmbLanguage.DisplayMember = "Name";
            cmbLanguage.ValueMember = "id";

            Language lang = sdb.Languages.Where(x => x.Active == true).SingleOrDefault();
            cmbLanguage.SelectedValue = lang.id;
            LanguageSet = true;
        }
        public void PopulateTabImages()
        {
            tabImages = new ImageList();
            foreach (MenuDetail md in db.MenuDetails.ToList())
            {
                if (md.Icon != null)
                {
                    tabImages.Images.Add(md.id.ToString(), ANIHelper.byteArrayToImage(md.Icon));
                }
            }
            tabMain.ImageList = tabImages;
        }
        public void InitUserMenu()
        {
            userContext = new ContextMenu();
            userContext.MenuItems.Clear();
            menuItemUser = new MenuItem("Log In");
            userContext.MenuItems.Add(menuItemUser);
        }
        
        private void Login()
        {
            LoginView frmLogin = new UI.LoginView();
            if (frmLogin.ShowDialog() == DialogResult.OK)
            {
                tbpDash.BackgroundImage = null;
                UICommon.isLogined = true;
                llblLogOut.Text = MessageKeys.MsgLogOut;
                PopulateMenuDetails();
                fnPopulateMenuStrips();
                CreateRoomContext();
                ShowLoginEmployeeImage();
                pnlMenus.Visible = true;
                PopulateFavourites();
                RefreshDashboard(false, true);
                UpdateReminder();
                timer.Enabled = true;
                GlobalMethods.LoadAccountSettings();
                GlobalMethods.LoadUserSettings();
                GlobalMethods.LoadDefaultSettings();
                //FillAllMenus();
                //AddComponents();
                //PopulateDummyMenus();
                atdashflowpanel.Visible = true;
                this.Show();
            }
            else
            {
                if (frmLogin.ShowOpenCompany)
                {
                    frmOpenCompany frm = new frmOpenCompany();
                    if(frm.ShowDialog() == DialogResult.OK)
                    {
                        Dashboard_Load(null, null);
                    }
                    else
                    {
                        this.Close();
                    }

                }
                else
                {
                    this.Close();
                }
            }
        }
        private void LogOut()
        {
            llblLogOut.Text = MessageKeys.MsgLogIn;
            UICommon.isLogined = false;
            pnlMenus.Visible = false;
            timer.Enabled = false;
            pnlFavourites.Controls.Clear();
            tbpDash = tabMain.TabPages["tbpDashboard"];
            tbpDash.Text = MessageKeys.MsgDashboard;
            tbpHom = tabMain.TabPages["tbpHome"];
            tbpHom.Text = MessageKeys.MsgHome;
            tabMain.TabPages.Clear();            
            tabMain.TabPages.Add(tbpHom);
            tabMain.TabPages.Add(tbpDash);
            atdashflowpanel.Controls.Clear();
            //lstAllmenus.Visible = false;
            //lblUserName.Text = "";
            atdashflowpanel.Visible = false;
            //SetBackGroundImage();
            this.Hide();
            Login();
        }
        private void AddToFavourite()
        {
            int _menuid = 0;
            string sMenuCaption = "";
            if (ActiveForm is Dashboard)
            {
                TabPage tbp = tabMain.SelectedTab;
                if (tbp == null) { atMessageBox.Show(MessageKeys.MsgNothingToAdd); return; }
                if (tbp.Tag == null) { atMessageBox.Show(MessageKeys.MsgNothingToAdd); return; }
                _menuid = (int)tbp.Tag;
                sMenuCaption = tbp.Text;
            }
            else
            {

            }
            MenuDetail menudetail = db.MenuDetails.Where(x => x.id == _menuid).SingleOrDefault();
            if (menudetail == null) { MessageBox.Show(MessageKeys.MsgNothingToAdd); return; }
            if (!menudetail.isForm.toBool()) { atMessageBox.Show(MessageKeys.MsgInvalidMenu); return; }
            foreach (atFavoritesButton btn in pnlFavourites.Controls)
            {
                FavouriteItem itm = (FavouriteItem)btn.Tag;
                if (itm != null)
                {
                    MenuDetail menuItm = (MenuDetail)itm.menuItem;
                    if (menuItm.id == menudetail.id)
                    {
                        atMessageBox.Show(MessageKeys.MsgMenuAlreadyExists);
                        return;
                    }
                }
            }
            FavouriteItem favouriteItem = new FavouriteItem();
            favouriteItem.Text = sMenuCaption; 
            favouriteItem.menuItem = menudetail;
            favouriteItem.Path = favouriteItem.Text;            
            AddFavouriteDb(favouriteItem.Path, menudetail.id);
            PopulateFavourites();
        }
        public void AddToFavouriteList(FavouriteItem favouriteItem)
        {
            MenuDetail menudetail = (MenuDetail)favouriteItem.menuItem;
            atFavoritesButton btn = new atFavoritesButton();
            if (menudetail != null)
            {
                btn.Name = menudetail.MenuName;
                switch (GlobalFunctions.LanguageCulture.ToString2())
                {
                    case "":
                        btn.Text = menudetail.MenuCaption;
                        break;
                    case "en-US":
                        btn.Text = menudetail.MenuCaption;
                        break;
                    case "ar-QA":
                        btn.Text = menudetail.CaptionArabic == null ? menudetail.MenuCaption : menudetail.CaptionArabic;
                        break;
                    case "fr-FR":
                        btn.Text = menudetail.CaptionFrench == null ? menudetail.MenuCaption : menudetail.CaptionFrench;
                        break;
                    case "ml-IN":
                        btn.Text = menudetail.CaptionMalayalam == null ? menudetail.MenuCaption : menudetail.CaptionMalayalam;
                        break;
                    case "hi-IN":
                        btn.Text = menudetail.CaptionHindi == null ? menudetail.MenuCaption : menudetail.CaptionHindi;
                        break;
                    case "es-ES":
                        btn.Text = menudetail.CaptionSpanish == null ? menudetail.MenuCaption : menudetail.CaptionSpanish;
                        break;
                    case "si-LK":
                        btn.Text = menudetail.CaptionSinhala == null ? menudetail.MenuCaption : menudetail.CaptionSinhala;
                        break;
                }
                if (btn.Text.Length > 10)
                    btn.Text = btn.Text.Substring(0, 10);
                btn.Tag = favouriteItem;
                if (menudetail.Icon != null)
                {
                    Image favImage = UICommon.byteArrayToImage(menudetail.Icon);
                    Size destSize = ResizeKeepAspect(favImage.Size, 30, 30, false);
                    Bitmap bmp = new Bitmap(favImage, destSize);
                    btn.MenuImage = bmp;
                }
                tooltips.SetToolTip(btn, favouriteItem.Path);
                btn.ContextMenu = favouriteContext;
                btn.fnMouseDown += (snd, e) =>
                {
                    if (e.Button == System.Windows.Forms.MouseButtons.Right)
                    {
                        favouriteContext.Show(btn, e.Location);
                    }

                };
            }
            else
            {
                btn.Name = btn.Text = favouriteItem.Text;
                if (favouriteItem.Text == strHomeCaption)
                {                    
                    btn.MenuImage = Properties.Resources.Home;
                }
                else if (favouriteItem.Text == strDashboardCaption)
                {
                    btn.MenuImage = Properties.Resources.Dash;
                }
            }
            btn.fnMouseClick += (snd, e) =>
            {
                try
                {
                    if(menudetail == null)
                    {
                        if (favouriteItem.Text == strHomeCaption)
                        {
                            tabMain.SelectedTab = tbpHom;                            
                        }
                        else if (favouriteItem.Text == strDashboardCaption)
                        {
                            tabMain.SelectedTab = tbpDash;                            
                        }
                        else
                        {
                            AddToFavourite();
                        }
                    }
                    else if (menudetail.isDialog.toBool())
                    {
                        if (menudetail.AssemblyName == "")
                        {
                            this.Cursor = Cursors.WaitCursor;
                            NewDash.fnActivateProcess(menudetail.ClassName, menudetail);
                            this.Cursor = Cursors.Arrow;
                        }
                        else
                        {
                            NewDash.fnActivateDialog(menudetail.AssemblyName, menudetail.ClassName, menudetail);
                        }
                    }
                    else
                    {
                        if (menudetail.AssemblyName == "")
                        {
                            this.Cursor = Cursors.WaitCursor;
                            NewDash.fnActivateProcess(menudetail.ClassName, menudetail);
                            this.Cursor = Cursors.Arrow;
                        }
                        else
                        {
                            this.Cursor = Cursors.WaitCursor;
                            NewDash.fnActivateForm(menudetail.AssemblyName, menudetail.ClassName, menudetail);
                            this.Cursor = Cursors.Arrow;
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            };
            pnlFavourites.Controls.Add(btn);
        }
        public void AddFavouriteDb(string sFavouritePath, int imenuid)
        {
            using (atACCHotelEntities sdb = atHotelContext.CreateContext())
            {
                HTL_Favorites favExisting = sdb.HTL_Favorites
                                            .Where(x => x.MenuID == imenuid && x.FK_LoginUserID == GlobalFunctions.LoginUserID)
                                            .SingleOrDefault();
                if (favExisting != null)
                {                    
                    sdb.HTL_Favorites.DeleteObject(favExisting);
                }
                HTL_Favorites favourite = new HTL_Favorites();
                favourite.MenuID = imenuid;
                favourite.MenuPath= sFavouritePath;
                favourite.FK_LoginUserID = GlobalFunctions.LoginUserID;
                sdb.HTL_Favorites.AddObject(favourite);
                sdb.SaveChanges();
            }
        }
        public void DeleteFromFavourite(int imenuid)
        {
            using (atACCHotelEntities sdb = atHotelContext.CreateContext())
            {
                HTL_Favorites favExisting = sdb.HTL_Favorites
                                            .Where(x => x.MenuID == imenuid && x.FK_LoginUserID == GlobalFunctions.LoginUserID)
                                            .SingleOrDefault();
                if (favExisting != null)
                {
                    sdb.HTL_Favorites.DeleteObject(favExisting);
                }
                sdb.SaveChanges();
            }
        }
        public void PopulateFavourites()
        {
            pnlFavourites.Controls.Clear();
            AddToFavouriteList(new FavouriteItem() { Text = strHomeCaption });
            AddToFavouriteList(new FavouriteItem() { Text = strDashboardCaption });
            List<HTL_Favorites> entFavourites = new List<HTL_Favorites>();
            using (atACCHotelEntities sdb = atHotelContext.CreateContext())
            {
                entFavourites = sdb.HTL_Favorites.Where(x=> x.FK_LoginUserID == GlobalFunctions.LoginUserID).ToList();
                foreach (HTL_Favorites favourite in entFavourites)
                {
                    MenuDetail menudetail = GlobalFunctions.entMenuDetails.Where(x => x.id == favourite.MenuID).SingleOrDefault();
                    if (menudetail != null && menudetail.MenuVisible.toBool())
                    {
                        FavouriteItem favouriteItem = new FavouriteItem();
                        favouriteItem.Text = favourite.MenuPath;
                        favouriteItem.menuItem = menudetail;
                        favouriteItem.Path = favourite.MenuPath;
                        AddToFavouriteList(favouriteItem);
                    }
                }
                AddToFavouriteList(new FavouriteItem() { Text = strAddCaption });  //Add To Favorites Button
            }
        }
        public Size ResizeKeepAspect(Size src, int maxWidth, int maxHeight, bool enlarge = false)
        {
            maxWidth = enlarge ? maxWidth : Math.Min(maxWidth, src.Width);
            maxHeight = enlarge ? maxHeight : Math.Min(maxHeight, src.Height);

            decimal rnd = Math.Min(maxWidth / (decimal)src.Width, maxHeight / (decimal)src.Height);
            return new Size((int)Math.Round(src.Width * rnd), (int)Math.Round(src.Height * rnd));
        }
        public void ShowLoginEmployeeImage()
        {
            btnUserImage.BackgroundImage = null;
            atACCHotelEntities db = atHotelContext.CreateContext();
            atACC.HTL.ORM.Employee employee = (from emp in db.Employees
                                 join user in db.HTL_LoginUsers on emp.id equals user.FK_EmployeeID
                                 where user.id == GlobalFunctions.LoginUserID
                                 select emp).FirstOrDefault();
            if (employee != null)
            {
                int iEmployeeID = employee.id;
                lblUserName.Text = employee.Name;
                lblUserName.Tag = employee.id;
                atACC.HTL.ORM.EmployeeDTL empDtl = db.EmployeeDTLs.Where(x => x.FK_EmployeeID == iEmployeeID).FirstOrDefault();
                if (empDtl != null && empDtl.EmployeeImage != null)
                {
                    btnUserImage.Image = null;
                    btnUserImage.BackgroundImage = ANIHelper.byteArrayToImage(empDtl.EmployeeImage);
                }
                else
                {
                    btnUserImage.Image = Properties.Resources.User;
                    btnUserImage.BackgroundImage = null;
                }
            }
            else
            {
                lblUserName.Text = "Admin";
                btnUserImage.Image = Properties.Resources.User;
                btnUserImage.BackgroundImage = null;
            }
            btnUserImage.Refresh();
        }
        public void ShowSubscriptionEndNotification()
        {
            if (GlobalFunctions.iCurrentRegistrationMode != (int)ENRegistrationModes.Subscription)
            {
                return;
            }
            ContextMenu contextmenu = new ContextMenu();
            contextmenu.MenuItems.Clear();
            MenuItem menuItemRenewSubscription = new MenuItem("Renew Subscription");
            menuItemRenewSubscription.Click += new EventHandler(menuItemRenewSubscription_Click);
            contextmenu.MenuItems.Add(menuItemRenewSubscription);
            MenuItem menuItemShowAllSubscriptions = new MenuItem("Show All Subscription");
            menuItemShowAllSubscriptions.Click += new EventHandler(menuItemShowAllSubscriptions_Click);
            contextmenu.MenuItems.Add(menuItemShowAllSubscriptions);
            MenuItem menuItemRegistration = new MenuItem("One Time Registration");
            menuItemRegistration.Click += new EventHandler(menuItemRegistration_Click);
            contextmenu.MenuItems.Add(menuItemRegistration);
            using (SettingsDbEntities sdb = new SettingsDbEntities())
            {
                Registration _registration = sdb.Registrations.Where(x => x.FK_RegistrationMode == (int)ENRegistrationModes.Subscription
                    ).OrderByDescending(x => x.id).FirstOrDefault();

                if (_registration != null)
                {
                    int daydiff = (_registration.SubscriptionEndDate.Value.Date - DateTime.Now.Date).Days;
                    if (daydiff <= 3)
                    {
                        SubscriptionNotificationView frm = new SubscriptionNotificationView(_registration, daydiff);
                        frm.ShowDialog();
                    }
                    else if (daydiff <= 15)
                    {
                        string sSubscriptionText = daydiff + " Day(s) to end your Subscription \n";
                        sSubscriptionText += " Subscription End Date:" + _registration.SubscriptionEndDate.Value.Date.ToEnd();
                        notify.Visible = true;
                        notify.Text = "Subscription";
                        notify.ContextMenu = contextmenu;
                        notify.BalloonTipTitle = MessageKeys.MsgApplicationName;
                        notify.BalloonTipText = sSubscriptionText;
                        notify.Icon = SystemIcons.Warning;
                        notify.BalloonTipClicked += new EventHandler(notify_BalloonTipClicked);
                        notify.ShowBalloonTip(1000);
                    }
                }
            }
        }
        private void CheckSystemDateAndInstallationDate()
        {
            using (SettingsDbEntities sdb = new SettingsDbEntities())
            {
                Installation _Installation = sdb.Installations.ToList().SingleOrDefault();
                if (_Installation.InstallationDate >= DateTime.Now)
                {
                    if (DialogResult.OK == atMessageBox.Show("Installation date and system date are not matching"))
                    {
                        this.Close();
                    }
                }
            }
        }
        void notify_BalloonTipClicked(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.SubscriptionView");
        }
        void menuItemRegistration_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.OneTimeRegistrationWizard");
        }
        void menuItemShowAllSubscriptions_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.RegistrationDetailsView");
        }
        void menuItemRenewSubscription_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.SubscriptionView");
        }
        #endregion

        #region Form Events
        private void chkAsOn_CheckedChanged(object sender, EventArgs e)
        {
            dtpAsOn.Enabled = chkAsOn.Checked;
        }
        private void Dashboard_Activated(object sender, EventArgs e)
        {
            if(GlobalProperties.RefreshDashboard)
                RefreshDashboard();
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            if (atMessageBox.Show(MessageKeys.MsgAreYouSureToClose, MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void btnMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Normal;
                this.Height = Screen.PrimaryScreen.WorkingArea.Height;
                this.Width = Screen.PrimaryScreen.WorkingArea.Width;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void Dashboard_Load(object sender, EventArgs e)
        {
            try
            {
                _OnLoad = true;
                lblDate.Text = DateTime.Now.ToShortDateString();
                this.Text = MessageKeys.MsgApplicationName;
                dtpAsOn.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                chkAsOn.Checked = false;
                lblVersionNumber.Text = GlobalFunctions.BuildVersion;
                PopulateLanguage();
                //picBox.BackgroundImage = UICommon.byteArrayToImage(GlobalFunctions._oemData.POSLogo);
                this.Hide();
                GlobalFunctions.fnLoadCompanyDetails();
                PopulateTabImages();
                PopulateCombos();
                InitUserMenu();
                CreateFavouriteContext();
                atdashflowpanel.Controls.Clear();
                //SetBackGroundImage();
                atdashflowpanel.Visible = false;
                Login();
                ShowSubscriptionEndNotification();
                CheckSystemDateAndInstallationDate();
                _OnLoad = false;
                pnlGuestSearch.Visible = false; pnlRemindContain.Visible = false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void llblLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (UICommon.isLogined)
            {
                LogOut();

            }
            else
            {
                Login();
            }
        }
        
        private void cmbLanguage_SelectedValueChanged(object sender, EventArgs e)
        {
            SettingsDbEntities sdb = new SettingsDbEntities();
            Language lastlang = sdb.Languages.Where(x => x.Active == true).SingleOrDefault();
            if (LanguageSet == true && cmbLanguage.SelectedValue.ToInt32() != lastlang.id)
            {
                if (atMessageBox.Show(MessageKeys.MsgAreYouSureYouWantToChangeDisplayLanguage, MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    foreach (Language lang in sdb.Languages.ToList())
                    {
                        if (lang.id == cmbLanguage.SelectedValue.ToString2().ToInt32())
                        {
                            lang.Active = true;
                        }
                        else
                        {
                            lang.Active = false;
                        }
                        sdb.ObjectStateManager.ChangeObjectState(lang, System.Data.EntityState.Modified);
                    }
                    sdb.SaveChanges();
                    if (atMessageBox.Show(MessageKeys.MsgPleaseReLoginToApplyChanges, MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        LogOut();
                    }
                }
                else
                {
                    cmbLanguage.SelectedValue = lastlang.id;
                    LanguageSet = true;
                }
            }
        }
        private void cmbLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        
        private void btnMenu_Click(object sender, EventArgs e)
        {
            ShowContextMenu((Button)sender);
        }
        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (UICommon.PreviousPages == null)
            {
                UICommon.PreviousPages = new List<TabPage>();
            }
            if (tabMain.SelectedTab != null)
            {
                if (UICommon.PreviousPages.Contains(tabMain.SelectedTab))
                {
                    UICommon.PreviousPages.Remove(tabMain.SelectedTab);
                }
                UICommon.PreviousPages.Insert(0, tabMain.SelectedTab);
            }
            if (GlobalProperties.RefreshDashboard)
            {
                RefreshDashboard();
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
            if((DateTime.Now - _dtLastReminderTime).Minutes >=1)
            {
                UpdateReminder();                
            }
        }
        private void dtpAsOn_ValueChanged(object sender, EventArgs e)
        {
            if (_OnLoad) return;
            RefreshDashboard(false);
        }
        
        private void cmb_SelectedValueChanged(object sender, EventArgs e)
        {
            if (_OnLoad) return;
            if (((ComboBoxExt)sender).Name == cmbRoomHall.Name)
            {
                PopulateComboRoomType();
            }
            RefreshDashboard(false);
            if(((ComboBoxExt)sender).Name == cmbStyle.Name)
            {
                SetCalendarComboVisibility();
                Properties.Settings.Default.RoomViewStyle = cmbStyle.SelectedValue.ToInt32();
                Properties.Settings.Default.Save();
            }
        }   
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch.Text != string.Empty)
            {
                pnlGuestSearch.Visible = true;
                DataSet ds = new DataSet();
                atACC.HTL.ORM.SqlHelper _sqlhelper = new atACC.HTL.ORM.SqlHelper();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("SearchString", txtSearch.Text));
                sqlParameters.Add(new SqlParameter("BranchID", GlobalFunctions.LoginLocationID));
                sqlParameters.Add(new SqlParameter("Status", 1));
                sqlParameters.Add(new SqlParameter("DateFrom", DateTime.Now.ToBegin()));
                sqlParameters.Add(new SqlParameter("DateTo", DateTime.Now.ToEnd()));
                ds = _sqlhelper.ExecuteProcedure("SpSearchCheckInGuest", sqlParameters);
                dgDetails.AutoGenerateColumns = false;
                dgDetails.DataSource = ds.Tables[0];    
            }
            else
            {
                pnlGuestSearch.Visible = false;
            }
        }
        private void btnNotification_Click(object sender, EventArgs e)
        {
            if (pnlRemindContain.Visible)
            {
                pnlRemindContain.Visible = false;
            }
            else
            {
                pnlRemindContain.Visible = true;                
            }
            
        }
        #endregion
    }
}
