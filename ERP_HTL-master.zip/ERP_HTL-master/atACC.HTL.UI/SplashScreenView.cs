﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACC.CommonMessages;
using atACC.Common;
namespace atACC.HTL.UI
{
    public partial class SplashScreenView : FormBase
    {

        int i = 0;
		string _msg = "";
        public SplashScreenView()
        {
            InitializeComponent();
            i = 0;
			this.Text = MessageKeys.MsgApplicationName;
            pcImage.Image = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.HotelSplash);
        }

        private void tmr_Tick(object sender, EventArgs e)
        {
            switch(i)
            {
                case 1:
                    _msg = "Preparing Initial Connection Please Wait...";
                    break;
                case 2:
                    _msg = "Checking for Updates...";
                    break;
                case 3:
                    _msg = "Launching " + MessageKeys.MsgApplicationName + " Hotel Management";
                    break;

                //case 3:
                //    _msg = "Constructing Framework Data...";
                //    break;
                //case 5:
                //    _msg = "Loading Menu Data...";
                //    break;
                //case 7:
                //    _msg = "Loading all Entities...";
                //    break;
                //case 9:
                //    _msg = "Fetching ORM Mapping Cache...";
                //    break;
                //case 11:
                //    _msg = "Synchronising Relationships...";
                //    break;
                //case 13:
                //    _msg = "Loading Global Settings...";
                //    break;
                //case 15:
                //    _msg = "Checking for Updates...";
                //    break;
                //case 17:
                //    _msg = "Verifications Completed!";
                //    break;
                //case 19:
                //     _msg = "Launching " + MessageKeys.MsgApplicationName;
                //    break;
            }
			lblStat.Text = _msg;
			
            i++;
        }
		private void SplashScreenView_FormClosing(object sender, FormClosingEventArgs e)
		{
			
		}

        private void pcImage_Click(object sender, EventArgs e)
        {

        }

    }
}
