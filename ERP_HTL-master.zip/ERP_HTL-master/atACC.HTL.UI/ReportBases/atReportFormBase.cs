﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonExtensions;
using Microsoft.Reporting.WinForms;
using atACC.Common;
using System.IO;
using atACCFramework.UserControls;
using System.Diagnostics;
using atACC.CommonMessages;

namespace atACC.HTL.UI
{
    public partial class atReportFormBase : BFormBase
    {
        #region Private Variables
        atReportViewer rptV;
        
        #endregion

        #region Public Events
        public event PreviewClickEventHandler atPreviewClick;
        public event DesignClickEventHandler atDesignClick;
        public event ValidateEventHandler atValidate;
        public event SubreportProcessingEventHandler atSubReportProcessing;
        public event HyperlinkEventHandler atHyperLinkClick;
        #endregion
        #region Public Properties
        public bool blnEmailReportAfterPreview = false;
        public bool blnHidePreview = false;
        public PreviewClickEventArgs PreviewClickArgs;
        #endregion
        #region Constructor
        public new FormBorderStyle FormBorderStyle { get { return base.FormBorderStyle; } set { base.FormBorderStyle = FormBorderStyle.None; } }
        public atReportFormBase()
        {
            InitializeComponent();
            atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.atReportFormBase_atPreviewClick);
            atValidate += new ValidateEventHandler(atReportFormBase_atValidate);
           // atSubReportProcessing += new SubreportProcessingEventHandler(atReportFormBase_atSubReportProcessing);
        }
        public void fnSubReportProcessing(object sender, SubreportProcessingEventArgs e)
        {
            atSubReportProcessing(sender, e);
        }
        public void fnHyperLinkClick(object sender, HyperlinkEventArgs e)
        {
            atHyperLinkClick(sender, e);
        }
        #endregion

        #region DummyEvents
        public void atReportFormBase_atPreviewClick(object source, PreviewClickEventArgs e) { }
            private bool atReportFormBase_atValidate(object source) { return true; }
        #endregion

        #region Public Clicks
        public void PreviewClick2(object sender, EventArgs e)
        {
            errProvider.Clear();
            this.Cursor = Cursors.WaitCursor;
            if (atValidate(this) == false) { this.Cursor = Cursors.Arrow; return; }
            PreviewClickArgs = new PreviewClickEventArgs();
            atPreviewClick(sender, PreviewClickArgs);

            if (PreviewClickArgs.DataSource == null)
            {
                atMessageBox.Show(MessageKeys.MsgRecordNotFound);
                this.Cursor = Cursors.Arrow;
                return;
            }
            if (PreviewClickArgs.ReportPath == "")
            {
                atMessageBox.Show(MessageKeys.MsgProvideReportPath);
                this.Cursor = Cursors.Arrow;
                return;
            }
            if (PreviewClickArgs.reportParameters != null)
            {

            }

            if (GlobalFunctions.GetANISettings((int)ENANISettings.ModernDashboard))
            {
               // rptV = new atReportViewer();
                rptV.blnEmailReportAfterPreview = blnEmailReportAfterPreview;
                rptV.blnHidePreview = blnHidePreview;
                rptV.frmReportBase = this;
                //rptV.Show();
                rptV.Text = this.Text;
                if (!PreviewClickArgs.blnFromPOS)
                {
                    rptV.ShowReport(PreviewClickArgs.ReportPath, PreviewClickArgs.DataSource, PreviewClickArgs.reportParameters);
                    //atACC.UI.NewDash.CreateNewPage(rptV);
                }
                else
                {
                    rptV.ShowReport(PreviewClickArgs.ReportPath, PreviewClickArgs.DataSource, PreviewClickArgs.reportParameters);
                  //  rptV.ShowDialog();

                }
                this.Cursor = Cursors.Arrow;
            }
            else
            {
               // rptV = new atReportViewer();
                rptV.blnEmailReportAfterPreview = blnEmailReportAfterPreview;
                rptV.blnHidePreview = blnHidePreview;
                rptV.frmReportBase = this;
              //  rptV.Show();
                rptV.ShowReport(PreviewClickArgs.ReportPath, PreviewClickArgs.DataSource, PreviewClickArgs.reportParameters);
                this.Cursor = Cursors.Arrow;
            }
        }
        public void PreviewClick(object sender,EventArgs e)
        {
            errProvider.Clear();
			this.Cursor = Cursors.WaitCursor;
			if(atValidate(this) == false) { this.Cursor = Cursors.Arrow; return; }
             PreviewClickArgs = new PreviewClickEventArgs();
            atPreviewClick(sender, PreviewClickArgs);

            if (PreviewClickArgs.DataSource == null)
            {
                atMessageBox.Show(MessageKeys.MsgRecordNotFound);
				this.Cursor = Cursors.Arrow;
                return;
            }
            if (PreviewClickArgs.ReportPath == "")
            {
                atMessageBox.Show(MessageKeys.MsgProvideReportPath);
				this.Cursor = Cursors.Arrow;
                return;
            }
            if (PreviewClickArgs.reportParameters != null)
            {

            }

            if (GlobalFunctions.GetANISettings((int)ENANISettings.ModernDashboard))
            {
                rptV = new atReportViewer();
                rptV.blnEmailReportAfterPreview = blnEmailReportAfterPreview;
                rptV.blnHidePreview = blnHidePreview;
                rptV.frmReportBase = this;
                //rptV.Show();
                rptV.Text = this.Text;
                if (!PreviewClickArgs.blnFromPOS)
                {
                    rptV.ShowReport(PreviewClickArgs.ReportPath, PreviewClickArgs.DataSource, PreviewClickArgs.reportParameters);
                    atACC.HTL.UI.NewDash.CreateNewPage(rptV);
                }
                else
                {
                    rptV.ShowReport(PreviewClickArgs.ReportPath, PreviewClickArgs.DataSource, PreviewClickArgs.reportParameters);
                    rptV.ShowDialog();
                    
                }
                this.Cursor = Cursors.Arrow;
            }
            else
            {
                rptV = new atReportViewer();
                rptV.blnEmailReportAfterPreview = blnEmailReportAfterPreview;
                rptV.blnHidePreview = blnHidePreview;
                rptV.frmReportBase = this;
                rptV.Show();
                rptV.ShowReport(PreviewClickArgs.ReportPath, PreviewClickArgs.DataSource, PreviewClickArgs.reportParameters);
                this.Cursor = Cursors.Arrow;
            }
        }
        public void PrintClick(object sender, EventArgs e)
        {

        }
        #endregion

        #region Form Events
        private void tsClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void tsPreview_Click(object sender, EventArgs e)
        {
            PreviewClick(sender, e);
        }
        private void tsPrint_Click(object sender, EventArgs e)
        {
            PrintClick(sender, e);
        }
        private void tsDesign_Click(object sender, EventArgs e)
        {
            DesignClickEventArgs DesignClickArgs = new DesignClickEventArgs();
            atDesignClick(sender, DesignClickArgs);
            if (DesignClickArgs.ReportPath == "")
            {
                atMessageBox.Show(MessageKeys.MsgProvideReportPath);
                return;
            }
            if(!File.Exists(DesignClickArgs.ReportPath))
            {
                atMessageBox.Show(MessageKeys.MsgInvalidReportPath);
            }

            string sProgramFiles;
            if (IntPtr.Size == 8)
            {
                sProgramFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            }
            else
            {
                sProgramFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            }
            if (!File.Exists(sProgramFiles + "\\Microsoft SQL Server\\Report Builder 2.0\\MSReportBuilder.exe"))
            {
                atMessageBox.Show(MessageKeys.MsgReportBuilderNotInstalledPleaseContactAdministrator);
                return;
            }
            Process.Start(sProgramFiles + "\\Microsoft SQL Server\\Report Builder 2.0\\MSReportBuilder.exe","\"" + DesignClickArgs.ReportPath + "\"");

        }
        private void atReportFormBase_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawRectangle(new Pen(Color.Silver, 2),
                           this.DisplayRectangle);
        }
        #endregion
    }
}
