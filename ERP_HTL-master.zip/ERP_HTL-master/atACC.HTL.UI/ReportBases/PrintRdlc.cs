﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Reporting.WinForms;
using System.Drawing.Imaging;
using System.Drawing;
using System.Drawing.Printing;
using System.Data;
using atACC.Common;
using atACC.Framework.NepaliDateConversion;
using atACC.CommonExtensions;
using atACCFramework.ReportBases;

namespace atACC.HTL.UI
{
    public class PrintRdlc : IDisposable
    {
        private int m_currentPageIndex;
        private IList<Stream> m_streams;
        // Routine to provide to the report renderer, in order to
        //    save an image for each page of the report.
        private Stream CreateStream(string name,
          string fileNameExtension, Encoding encoding,
          string mimeType, bool willSeek)
        {
            Stream stream = new MemoryStream();
            m_streams.Add(stream);
            return stream;
        }
        // Export the given report as an EMF (Enhanced Metafile) file.
        private void Export(LocalReport report)
        {

            string deviceInfo =
              @"<DeviceInfo>
                <OutputFormat>EMF</OutputFormat>
                <PageWidth>8in</PageWidth>
                <PageHeight>11in</PageHeight>
                <MarginTop>0.0in</MarginTop>
                <MarginLeft>0.0in</MarginLeft>
                <MarginRight>0.0in</MarginRight>
                <MarginBottom>0.0in</MarginBottom>
            </DeviceInfo>";
            Warning[] warnings;
            m_streams = new List<Stream>();
            report.Render("Image", deviceInfo, CreateStream,
               out warnings);
            foreach (Stream stream in m_streams)
                stream.Position = 0;
        }
        // Handler for PrintPageEvents
        private void PrintPage(object sender, PrintPageEventArgs ev)
        {
            Metafile pageImage = new
               Metafile(m_streams[m_currentPageIndex]);

            // Adjust rectangular area with printer margins.
            Rectangle adjustedRect = new Rectangle(
                ev.PageBounds.Left - (int)ev.PageSettings.HardMarginX,
                ev.PageBounds.Top - (int)ev.PageSettings.HardMarginY,
                ev.PageBounds.Width,
                ev.PageBounds.Height);

            // Draw a white background for the report
            ev.Graphics.FillRectangle(Brushes.White, adjustedRect);

            // Draw the report content
            ev.Graphics.DrawImage(pageImage, adjustedRect);

            // Prepare for the next page. Make sure we haven't hit the end.
            m_currentPageIndex++;
            ev.HasMorePages = (m_currentPageIndex < m_streams.Count);
        }

        private void Print(PrinterSettings sett)
        {
            if (m_streams == null || m_streams.Count == 0)
                throw new Exception("Error: no stream to print.");
            PrintDocument printDoc = new PrintDocument();
            if (!printDoc.PrinterSettings.IsValid)
            {
                throw new Exception("Error: cannot find the default printer.");
            }
            else
            {
                if (sett != null)
                {
                    printDoc.PrinterSettings = sett;
                }
                printDoc.PrintPage += new PrintPageEventHandler(PrintPage);
                m_currentPageIndex = 0;

                printDoc.Print();
            }
        }
        // Create a local report for Report.rdlc, load the data,
        //    export the report to an .emf file, and print it.
        public void PrintReport(string sReportPath, PrinterSettings sett,DataSet dsPrint,List<atReportParameter> reportParameters)
        {
            if (dsPrint == null) { throw new Exception("Data Source Property Cannot be Null!"); }
            if (sReportPath == "") { throw new Exception("Invalid Report Path!"); }
            if (File.Exists(sReportPath) == false) { throw new Exception("Report File Not Found!"); }
            LocalReport report = new LocalReport();
            report.ReportPath = sReportPath;
            report.EnableHyperlinks = true;
           
            foreach (DataTable dt in dsPrint.Tables)
            {
                if (GlobalFunctions.CurrentCalendar == (int)ENCalendars.NepaliCalendar)
                {
                    try
                    {
                        foreach (DataRow drow in dt.Rows)
                        {
                            if (dt.Columns.Contains(Enums.VoucherDate))
                            {
                                drow[Enums.VoucherDate] = atNepaliDateConverter.convertToBS(drow[Enums.VoucherDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.DeliveryDate))
                            {
                                drow[Enums.DeliveryDate] = atNepaliDateConverter.convertToBS(drow[Enums.DeliveryDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.DueDate))
                            {
                                drow[Enums.DueDate] = atNepaliDateConverter.convertToBS(drow[Enums.DueDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.IssueDate))
                            {
                                drow[Enums.IssueDate] = atNepaliDateConverter.convertToBS(drow[Enums.IssueDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.ReceiptDate))
                            {
                                drow[Enums.ReceiptDate] = atNepaliDateConverter.convertToBS(drow[Enums.ReceiptDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.ExpiryDate))
                            {
                                drow[Enums.ExpiryDate] = atNepaliDateConverter.convertToBS(drow[Enums.ExpiryDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.ManufDate))
                            {
                                drow[Enums.ManufDate] = atNepaliDateConverter.convertToBS(drow[Enums.ManufDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.StartDate))
                            {
                                drow[Enums.StartDate] = atNepaliDateConverter.convertToBS(drow[Enums.StartDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.EndDate))
                            {
                                drow[Enums.EndDate] = atNepaliDateConverter.convertToBS(drow[Enums.EndDate].ToString().toDateTime());
                            }
                        }
                    }
                    catch { }
                }
                report.DataSources.Add(
                   new ReportDataSource(dt.TableName, dt));
            }
            ReportParameterInfoCollection rptParams = report.GetParameters();
            if (reportParameters == null && rptParams.Count > 6)
            {
                throw new Exception("Report Parameters Not Supplied!");
            }
            if (reportParameters != null && reportParameters.ToList().Count > (rptParams.Count + 6))
            {
                throw new Exception("Supplied Parameter Count is Greater Than Available Parameter in Report!");
            }
            if (rptParams.Where(X => X.Name == Enums.Company).ToList().Count > 0)
            {
                ReportParameter par = new ReportParameter(Enums.Company, GlobalFunctions.sCompanyName);
                report.SetParameters(par);
            }
            if (rptParams.Where(X => X.Name == Enums.CompanyAddress).ToList().Count > 0)
            {
                ReportParameter par = new ReportParameter(Enums.CompanyAddress, GlobalFunctions.sCompanyAddress);
                report.SetParameters(par);
            }
            if (rptParams.Where(X => X.Name == Enums.LoginLocation).ToList().Count > 0)
            {
                ReportParameter par = new ReportParameter(Enums.LoginLocation, GlobalFunctions.sLoginLocation);
                report.SetParameters(par);
            }
            if (rptParams.Where(X => X.Name == Enums.LoginUserName).ToList().Count > 0)
            {
                ReportParameter par = new ReportParameter(Enums.LoginUserName, GlobalFunctions.sLoginUserName);
                report.SetParameters(par);
            }
            if (rptParams.Where(X => X.Name == Enums.AmountFormat).ToList().Count > 0)
            {
                ReportParameter par = new ReportParameter(Enums.AmountFormat, GlobalFunctions.ReportAmountFormat);
                report.SetParameters(par);
            }
            if (rptParams.Where(X => X.Name == Enums.QtyFormat).ToList().Count > 0)
            {
                ReportParameter par = new ReportParameter(Enums.QtyFormat, GlobalFunctions.ReportQtyFormat);
                report.SetParameters(par);
            }
            if (rptParams.Where(X => X.Name == Enums.DateTimeFormat).ToList().Count > 0)
            {
                ReportParameter par;
                if (GlobalFunctions.CurrentCalendar == (int)ENCalendars.GregorianCalendar)
                {
                    par = new ReportParameter(Enums.DateTimeFormat, "dd/MMM/yyyy");
                }
                else
                {
                    par = new ReportParameter(Enums.DateTimeFormat, "dd/MM/yyyy");
                }
                report.SetParameters(par);
            }
            if (reportParameters != null)
            {
                foreach (ReportParameterInfo rptParam in report.GetParameters())
                {
                    if (reportParameters.Where(x => x.ParameterName == rptParam.Name).ToList().Count > 0)
                    {
                        atReportParameter atPar = new atReportParameter();
                        atPar = reportParameters.Where(x => x.ParameterName == rptParam.Name).Single();
                        ReportParameter par = new ReportParameter(atPar.ParameterName, atPar.ParameterValue == "" ? "--" : atPar.ParameterValue);
                        report.SetParameters(par);
                    }
                }
            }

            //Export(report);
            //Print(sett);
            
        }
        

        public void Dispose()
        {
            if (m_streams != null)
            {
                foreach (Stream stream in m_streams)
                    stream.Close();
                m_streams = null;
            }
        }


    }
}
