﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.UI
{
    public class atReportParameter
    {
        public atReportParameter() { }
        public atReportParameter(string _parameterName,string _parameterValue)
        {
            ParameterName = _parameterName;
            ParameterValue = _parameterValue;
        }
        public string ParameterName { get; set; }
        public string ParameterValue { get; set; }
    }
}
