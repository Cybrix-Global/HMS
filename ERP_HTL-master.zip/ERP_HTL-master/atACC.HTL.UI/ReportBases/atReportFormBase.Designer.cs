﻿namespace atACC.HTL.UI
{
    partial class atReportFormBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atReportFormBase));
            this.errProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnDesign = new atACCFramework.UserControls.atButton();
            this.btnPreview = new atACCFramework.UserControls.atButton();
            this.btnPrint = new atACCFramework.UserControls.atButton();
            this.btnCloseold = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // errProvider
            // 
            this.errProvider.ContainerControl = this;
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            this.pnlBottom.BackColor = System.Drawing.Color.Transparent;
            this.pnlBottom.Controls.Add(this.btnDesign);
            this.pnlBottom.Controls.Add(this.btnPreview);
            this.pnlBottom.Controls.Add(this.btnPrint);
            this.errProvider.SetError(this.pnlBottom, resources.GetString("pnlBottom.Error"));
            this.errProvider.SetIconAlignment(this.pnlBottom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlBottom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlBottom, ((int)(resources.GetObject("pnlBottom.IconPadding"))));
            this.pnlBottom.Name = "pnlBottom";
            // 
            // btnDesign
            // 
            resources.ApplyResources(this.btnDesign, "btnDesign");
            this.btnDesign.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnDesign, resources.GetString("btnDesign.Error"));
            this.btnDesign.FlatAppearance.BorderSize = 0;
            this.btnDesign.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnDesign, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnDesign.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnDesign, ((int)(resources.GetObject("btnDesign.IconPadding"))));
            this.btnDesign.Name = "btnDesign";
            this.btnDesign.UseVisualStyleBackColor = false;
            this.btnDesign.Click += new System.EventHandler(this.tsDesign_Click);
            // 
            // btnPreview
            // 
            resources.ApplyResources(this.btnPreview, "btnPreview");
            this.btnPreview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnPreview, resources.GetString("btnPreview.Error"));
            this.btnPreview.FlatAppearance.BorderSize = 0;
            this.btnPreview.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnPreview, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnPreview.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnPreview, ((int)(resources.GetObject("btnPreview.IconPadding"))));
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.UseVisualStyleBackColor = false;
            this.btnPreview.Click += new System.EventHandler(this.PreviewClick);
            // 
            // btnPrint
            // 
            resources.ApplyResources(this.btnPrint, "btnPrint");
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnPrint, resources.GetString("btnPrint.Error"));
            this.btnPrint.FlatAppearance.BorderSize = 0;
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnPrint, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnPrint.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnPrint, ((int)(resources.GetObject("btnPrint.IconPadding"))));
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.tsPrint_Click);
            // 
            // btnCloseold
            // 
            resources.ApplyResources(this.btnCloseold, "btnCloseold");
            this.btnCloseold.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.errProvider.SetError(this.btnCloseold, resources.GetString("btnCloseold.Error"));
            this.btnCloseold.ForeColor = System.Drawing.Color.White;
            this.errProvider.SetIconAlignment(this.btnCloseold, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnCloseold.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnCloseold, ((int)(resources.GetObject("btnCloseold.IconPadding"))));
            this.btnCloseold.Name = "btnCloseold";
            this.btnCloseold.UseVisualStyleBackColor = false;
            this.btnCloseold.Click += new System.EventHandler(this.tsClose_Click);
            // 
            // atReportFormBase
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlBottom);
            this.Name = "atReportFormBase";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.atReportFormBase_Paint);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.ErrorProvider errProvider;
        private System.Windows.Forms.Button btnCloseold;
        public System.Windows.Forms.Panel pnlBottom;
        private atACCFramework.UserControls.atButton btnDesign;
        private atACCFramework.UserControls.atButton btnPrint;
        private atACCFramework.UserControls.atButton btnPreview;
    }
}