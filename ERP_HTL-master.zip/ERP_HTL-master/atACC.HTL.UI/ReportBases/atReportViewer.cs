﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACCFramework.BaseClasses;
using System.Windows.Forms;
using atACCFramework.Common;
using atACC.CommonExtensions;
using Microsoft.Reporting.WinForms;
using System.Data;
using atACC.Common;
using System.IO;
using System.Reflection;
using System.Drawing.Printing;
using atACC.CommonMessages;
using atACC.Framework.NepaliDateConversion;
using System.Net.Mail;
using atACCFramework.ReportBases;
using atACCFramework;

namespace atACC.HTL.UI
{
   public class atReportViewer:BFormBase
    {
        #region Private Variables
        private string _ReportPath;
        private DataSet _DataSource;
        public atReportFormBase frmReportBase;
        public string sCurrentReportCaption;
        #endregion

        #region Public Properties
        public string ReportPath { set { _ReportPath = value; } }
        public DataSet DataSource { set { _DataSource = value; } }
        public PrinterSettings _printersett { get; set; }
        public bool blnFromTransactions = false;
        public bool blnEmailReportAfterPreview = false;
        public bool blnHidePreview = false;
        #endregion

        #region Public Variables
        List<atReportParameter> reportParameters;
        #endregion

        private ToolTip tooltip1;
        private System.ComponentModel.IContainer components;
        private Button btnSendEmail;
        
        #region Designer Codes
        public Microsoft.Reporting.WinForms.ReportViewer rptVwr;
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atReportViewer));
            this.tooltip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnSendEmail = new System.Windows.Forms.Button();
            this.rptVwr = new Microsoft.Reporting.WinForms.ReportViewer();
            this.SuspendLayout();
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Size = new System.Drawing.Size(523, 32);
            // 
            // btnSendEmail
            // 
            this.btnSendEmail.BackgroundImage = global::atACCFramework.Properties.Resources.Mail;
            this.btnSendEmail.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSendEmail.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnSendEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSendEmail.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendEmail.Location = new System.Drawing.Point(645, 40);
            this.btnSendEmail.Name = "btnSendEmail";
            this.btnSendEmail.Size = new System.Drawing.Size(104, 27);
            this.btnSendEmail.TabIndex = 2;
            this.btnSendEmail.Text = "Send Email";
            this.btnSendEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSendEmail.UseVisualStyleBackColor = true;
            this.btnSendEmail.Click += new System.EventHandler(this.picEmail_Click);
            // 
            // rptVwr
            // 
            this.rptVwr.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("rptVwr.BackgroundImage")));
            this.rptVwr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rptVwr.Location = new System.Drawing.Point(0, 38);
            this.rptVwr.Name = "rptVwr";
            this.rptVwr.Size = new System.Drawing.Size(1024, 562);
            this.rptVwr.TabIndex = 0;
            this.rptVwr.Hyperlink += new Microsoft.Reporting.WinForms.HyperlinkEventHandler(this.rptVwr_Hyperlink);
            this.rptVwr.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rptVwr_KeyDown);
            // 
            // atReportViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1024, 600);
            this.Controls.Add(this.btnSendEmail);
            this.Controls.Add(this.rptVwr);
            this.MinimumSize = new System.Drawing.Size(1020, 600);
            this.Name = "atReportViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.atReportViewer_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.atReportViewer_KeyDown);
            this.Controls.SetChildIndex(this.rptVwr, 0);
            this.Controls.SetChildIndex(this.btnSendEmail, 0);
            this.ResumeLayout(false);

        }
        #endregion

        #region Constructor
        public atReportViewer()
        {
            InitializeComponent();
            MinimizeButton.Visible = true;
            MaximizeButton.Visible = true;
            rptVwr.ReportRefresh += new System.ComponentModel.CancelEventHandler(rptVwr_ReportRefresh);
            
        }

        void rptVwr_ReportRefresh(object sender, System.ComponentModel.CancelEventArgs e)
        {
            frmReportBase.PreviewClick2(sender, e);
        }
        #endregion

        public void ShowReport(string sReportPath,DataSet _ds,List<atReportParameter> _reportParameters)
        {
            DataSource = _ds;
            ReportPath = sReportPath;
            reportParameters = _reportParameters;
             ShowReport();
        }
        public void ShowReport()
        {
            try
            {
                if (_DataSource == null) { throw new Exception(MessageKeys.MsgDataSourcePropertyCannotBeNull); }
                if (_ReportPath == "") { throw new Exception(MessageKeys.MsgInvalidReportPath); }
                if (File.Exists(_ReportPath) == false) { throw new Exception(MessageKeys.MsgReportFileNotFound); }
                
                rptVwr.ProcessingMode = ProcessingMode.Local;
                rptVwr.LocalReport.ReportPath = _ReportPath;
                rptVwr.LocalReport.EnableHyperlinks = true;
                rptVwr.LocalReport.DataSources.Clear();
               

                foreach ( DataTable dt in _DataSource.Tables )
				{
                    if (GlobalFunctions.CurrentCalendar == (int)ENCalendars.NepaliCalendar)
                    {
                        try
                        {
                            foreach (DataRow drow in dt.Rows)
                            {
                                if (dt.Columns.Contains(Enums.VoucherDate))
                                {
                                    drow[Enums.VoucherDate] = atNepaliDateConverter.convertToBS(drow[Enums.VoucherDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.DeliveryDate))
                                {
                                    drow[Enums.DeliveryDate] = atNepaliDateConverter.convertToBS(drow[Enums.DeliveryDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.DueDate))
                                {
                                    drow[Enums.DueDate] = atNepaliDateConverter.convertToBS(drow[Enums.DueDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.IssueDate))
                                {
                                    drow[Enums.IssueDate] = atNepaliDateConverter.convertToBS(drow[Enums.IssueDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.ReceiptDate))
                                {
                                    drow[Enums.ReceiptDate] = atNepaliDateConverter.convertToBS(drow[Enums.ReceiptDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.ExpiryDate))
                                {
                                    drow[Enums.ExpiryDate] = atNepaliDateConverter.convertToBS(drow[Enums.ExpiryDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.ManufDate))
                                {
                                    drow[Enums.ManufDate] = atNepaliDateConverter.convertToBS(drow[Enums.ManufDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.StartDate))
                                {
                                    drow[Enums.StartDate] = atNepaliDateConverter.convertToBS(drow[Enums.StartDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.EndDate))
                                {
                                    drow[Enums.EndDate] = atNepaliDateConverter.convertToBS(drow[Enums.EndDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.ChequeDate))
                                {
                                    drow[Enums.ChequeDate] = atNepaliDateConverter.convertToBS(drow[Enums.ChequeDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.BouncedDate))
                                {
                                    drow[Enums.BouncedDate] = atNepaliDateConverter.convertToBS(drow[Enums.BouncedDate].ToString().toDateTime());
                                }
                            }
                        }
                        catch { }
                    }
                    else
                    {

                    }

					ReportDataSource rds = new ReportDataSource( dt.TableName, dt );
					rptVwr.LocalReport.DataSources.Add( rds );
				}
                ReportParameterInfoCollection rptParams =rptVwr.LocalReport.GetParameters();
                if(reportParameters.Count>0)
                {
                    if (reportParameters[0].ParameterName == "ReportCaption")
                    {
                        sCurrentReportCaption = reportParameters[0].ParameterValue.Replace("\\","_").Replace("/","_");
                    }
                    else
                    {
                        int iindex= rptVwr.LocalReport.ReportPath.LastIndexOf("\\");
                        sCurrentReportCaption = rptVwr.LocalReport.ReportPath.Substring(iindex+1);
                    }
                }
                if (reportParameters == null && rptParams.Count > 6)
                {
                    throw new Exception(MessageKeys.MsgReportParametersNotSupplied);
                }
                if (reportParameters != null && reportParameters.ToList().Count > (rptParams.Count + 6))
				{
					throw new Exception( MessageKeys.MsgSuppliedParameterCountIsGreaterThanAvailableParameterInReport );
				}

                rptVwr.Visible = true;
                
                if (rptParams.Where(X => X.Name == Enums.Company).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.Company, GlobalFunctions.sCompanyName);
                    rptVwr.LocalReport.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.CompanyAddress).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.CompanyAddress, GlobalFunctions.sCompanyAddress);
                    rptVwr.LocalReport.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.LoginLocation).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.LoginLocation, GlobalFunctions.sLoginLocation);
                    rptVwr.LocalReport.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.LoginUserName).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.LoginUserName, GlobalFunctions.sLoginUserName);
                    rptVwr.LocalReport.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.AmountFormat).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.AmountFormat, GlobalFunctions.ReportAmountFormat);
                    rptVwr.LocalReport.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.QtyFormat).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.QtyFormat, GlobalFunctions.ReportQtyFormat);
                    rptVwr.LocalReport.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.DateTimeFormat).ToList().Count > 0)
                {
                    ReportParameter par;
                    if (GlobalFunctions.CurrentCalendar == (int)ENCalendars.GregorianCalendar)
                    {
                        par = new ReportParameter(Enums.DateTimeFormat, "dd/MMM/yyyy");
                    }
                    else
                    {
                        par = new ReportParameter(Enums.DateTimeFormat, "dd/MM/yyyy");
                    }
                    rptVwr.LocalReport.SetParameters(par);
                }
                rptVwr.ReportExport += RptVwr_ReportExport;
                if (reportParameters != null)
                {
                    foreach (ReportParameterInfo rptParam in rptVwr.LocalReport.GetParameters())
                    {
                        if (reportParameters.Where(x => x.ParameterName == rptParam.Name).ToList().Count > 0)
                        {
                            atReportParameter atPar = new atReportParameter();
                            atPar = reportParameters.Where(x => x.ParameterName == rptParam.Name).Single();
                            ReportParameter par = new ReportParameter(atPar.ParameterName, atPar.ParameterValue==""?"--":atPar.ParameterValue);
                            rptVwr.LocalReport.SetParameters(par);
                        }
                    }
                }
                rptVwr.LocalReport.SubreportProcessing += new SubreportProcessingEventHandler(LocalReport_SubreportProcessing);
                if (GlobalFunctions.blnShowPrintDialog && blnFromTransactions)
                {
                    //if (_printersett != null)
                    //{
                    //    ReportPageSettings _rptPageSettings = rptVwr.LocalReport.GetDefaultPageSettings();
                    //    _printersett.DefaultPageSettings.PaperSize = _rptPageSettings.PaperSize;
                    //    _printersett.DefaultPageSettings.Landscape = _rptPageSettings.IsLandscape;
                    //    if (_rptPageSettings.PaperSize.Width > _rptPageSettings.PaperSize.Height)
                    //    {
                    //        _printersett.DefaultPageSettings.Landscape = false;
                    //    }
                        rptVwr.PrinterSettings = _printersett;
                    //    rptVwr.SetPageSettings(_printersett.DefaultPageSettings);
                    //}
                    rptVwr.RefreshReport();
                    rptVwr.RenderingComplete += new RenderingCompleteEventHandler(PrintVoucher);
                }
                else
                {
                    rptVwr.RefreshReport();
                }
                
                if(blnEmailReportAfterPreview)
                {
                    SendReportEmail();
                }
                if(blnHidePreview)
                {
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void RptVwr_ReportExport(object sender, ReportExportEventArgs e)
        {
            e.Cancel = true;
            string strExtension = "";
            switch(e.Extension.Name.ToUpper())
            {
                case "PDF":
                    strExtension = ".pdf";
                    break;
                case "EXCEL":
                    strExtension = ".xls";
                    break;
                case "WORD":
                    strExtension = ".doc";
                    break;
            }
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            saveFileDialog.Filter = e.Extension.LocalizedName + " (*" + strExtension + ")|*" + strExtension + "|All files(*.*)|*.*";
            saveFileDialog.FileName = sCurrentReportCaption.Replace(".rdlc",string.Empty);
            if (saveFileDialog.ShowDialog()==DialogResult.OK)
            {
                rptVwr.ExportDialog(e.Extension, e.DeviceInfo, saveFileDialog.FileName);
                MessageBox.Show("Report Exported!");
            }
            
        }

        public void PrintVoucher(object sender, RenderingCompleteEventArgs e)
        {
            try
            {
                rptVwr.PrintDialog(_printersett);
                rptVwr.Clear();
                rptVwr.LocalReport.ReleaseSandboxAppDomain();
                this.Close();
            }
            catch (Exception)
            {
            }
        }
        void LocalReport_SubreportProcessing(object sender, SubreportProcessingEventArgs e)
        {
            frmReportBase.fnSubReportProcessing(sender, e);
            if (e.DataSources == null) { return; } 
            List<ReportDataSource> _reportDataSources = e.DataSources.ToList();
            foreach (ReportDataSource _rds in _reportDataSources)
            {
                DataTable dt = (DataTable)_rds.Value;

                if (GlobalFunctions.CurrentCalendar == (int)ENCalendars.NepaliCalendar)
                {
                    try
                    {
                        foreach (DataRow drow in dt.Rows)
                        {
                            if (dt.Columns.Contains(Enums.VoucherDate))
                            {
                                drow[Enums.VoucherDate] = atNepaliDateConverter.convertToBS(drow[Enums.VoucherDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.DeliveryDate))
                            {
                                drow[Enums.DeliveryDate] = atNepaliDateConverter.convertToBS(drow[Enums.DeliveryDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.DueDate))
                            {
                                drow[Enums.DueDate] = atNepaliDateConverter.convertToBS(drow[Enums.DueDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.IssueDate))
                            {
                                drow[Enums.IssueDate] = atNepaliDateConverter.convertToBS(drow[Enums.IssueDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.ReceiptDate))
                            {
                                drow[Enums.ReceiptDate] = atNepaliDateConverter.convertToBS(drow[Enums.ReceiptDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.ExpiryDate))
                            {
                                drow[Enums.ExpiryDate] = atNepaliDateConverter.convertToBS(drow[Enums.ExpiryDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.ManufDate))
                            {
                                drow[Enums.ManufDate] = atNepaliDateConverter.convertToBS(drow[Enums.ManufDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.StartDate))
                            {
                                drow[Enums.StartDate] = atNepaliDateConverter.convertToBS(drow[Enums.StartDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.EndDate))
                            {
                                drow[Enums.EndDate] = atNepaliDateConverter.convertToBS(drow[Enums.EndDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.ChequeDate))
                            {
                                drow[Enums.ChequeDate] = atNepaliDateConverter.convertToBS(drow[Enums.ChequeDate].ToString().toDateTime());
                            }
                            if (dt.Columns.Contains(Enums.BouncedDate))
                            {
                                drow[Enums.BouncedDate] = atNepaliDateConverter.convertToBS(drow[Enums.BouncedDate].ToString().toDateTime());
                            }
                        }
                    }
                    catch { }
                }
            }
        }
        private void ApplyActionToInternalReportViewerControls(Action<Control> action)
        {
            try
            {
                // Lets just dig in, not even bothering with any null checks or other preventive coding. If things go bad just bail to exception handler
                var reportViewerType = typeof(Microsoft.Reporting.WinForms.ReportViewer);
                var winRSviewerField = reportViewerType.GetField("winRSviewer", BindingFlags.Instance | BindingFlags.NonPublic);
                var reportPanelField = winRSviewerField.FieldType.GetField("m_reportPanel", BindingFlags.Instance | BindingFlags.NonPublic);
                var renderPanelField = reportPanelField.FieldType.GetField("m_renderPanel", BindingFlags.Instance | BindingFlags.NonPublic);

                var winRSviewer = winRSviewerField.GetValue(this.rptVwr) as Control;
                var reportPanel = reportPanelField.GetValue(winRSviewer) as Control;
                var renderPanel = renderPanelField.GetValue(reportPanel) as Control;

                action(winRSviewer);
                action(reportPanel);
                action(renderPanel);
            }
            catch (Exception)
            {
                // Log or ignore
            }
        }

        private void atReportViewer_Load(object sender, EventArgs e)
        {
            this.rptVwr.RefreshReport();
            rptVwr.Focus();
        }
        private void rptVwr_Hyperlink(object sender, HyperlinkEventArgs e)
        {
            frmReportBase.fnHyperLinkClick(sender, e);
        }
        public void SendReportEmail()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                if (!Directory.Exists(Application.StartupPath + @"\Emails"))
                {
                    Directory.CreateDirectory(Application.StartupPath + @"\Emails");
                }
                string sdatetime = DateTime.Now.Day + "_" + DateTime.Now.Month + "_" + DateTime.Now.Year + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".pdf";
                string sReportCap = this.Text.Replace("View", "") + "_" + sdatetime;
                string sPath = Application.StartupPath + @"\Emails\" + sReportCap;
                String v_mimetype;
                String v_encoding;
                String v_filename_extension;
                String[] v_streamids;
                Microsoft.Reporting.WinForms.Warning[] warnings;
                byte[] byteViewer = rptVwr.LocalReport.Render("PDF", null, out v_mimetype, out v_encoding, out v_filename_extension, out v_streamids, out warnings);
                FileStream newFile = new FileStream(sPath, FileMode.Create);
                newFile.Write(byteViewer, 0, byteViewer.Length);
                newFile.Close();

                if (!blnEmailReportAfterPreview)
                {
                    atACCFramework.InputBoxView objInput = new atACCFramework.InputBoxView("Enter Email Address", "Email", Properties.Settings.Default.sendemails);
                    objInput.ShowDialog();
                    if (objInput.ReturnValue != "")
                    {
                        this.Cursor = Cursors.WaitCursor;
                        MailHelper _mailHelper = new MailHelper();
                        _mailHelper.sTo = objInput.ReturnValue;
                        _mailHelper.sSubject = this.Text;
                        _mailHelper.sBody = this.Text;
                        if (File.Exists(sPath))
                        {
                            _mailHelper.entAttachments.Add(new Attachment(sPath));
                        }
                        _mailHelper.SendEmail();
                        Properties.Settings.Default.sendemails = objInput.ReturnValue;
                        Properties.Settings.Default.Save();
                        this.Cursor = Cursors.Arrow;
                        MessageBox.Show("Email Send!");
                    }
                }
                else
                {
                    this.Cursor = Cursors.WaitCursor;
                    MailHelper _mailHelper = new MailHelper();
                    _mailHelper.sTo = GlobalFunctions.sCompanyEmail;
                    _mailHelper.sSubject = this.Text;
                    _mailHelper.sBody = this.Text;
                    if (File.Exists(sPath))
                    {
                        _mailHelper.entAttachments.Add(new Attachment(sPath));
                    }
                    _mailHelper.SendEmail();
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show("Email Send!");
                }
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Arrow;
                MessageBox.Show(ex.Message);
            }
        }
        private void picEmail_Click(object sender, EventArgs e)
        {
            SendReportEmail();

        }

        private void atReportViewer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control)
            {
                if (e.KeyCode == Keys.E)
                {
                    picEmail_Click(sender,e);
                }
                if (e.KeyCode == Keys.W)
                {
                    this.Close();
                }
            }
        }
        private void rptVwr_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Control)
            {
                if (e.KeyCode == Keys.E)
                {
                    picEmail_Click(sender, e);
                }
                if (e.KeyCode == Keys.W)
                {
                    this.Close();
                }
            }
        }

    }
}
