﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Reporting.WinForms;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Data;
using atACCFramework.ReportBases;
using atACC.Common;
using atACC.Framework.NepaliDateConversion;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.CommonMessages;
namespace atACC.HTL.UI
{
        public class DirectReportPrint : IDisposable
        {
            private double[] PageBounds = { 0, 0, 0, 0, 0, 0 };
            private int m_currentPageIndex;
            private IList<Stream> m_streams;

            private DataTable _table = new DataTable();
            /// <summary>
            /// Must set this to get the report data
            /// </summary>
            public DataTable ReportTable
            {
                get { return _table; }
                set { _table = value; }
            }

            private Stream CreateStream(string name,
    string fileNameExtension, Encoding encoding,
    string mimeType, bool willSeek)
            {
                Stream stream = new MemoryStream();
                m_streams.Add(stream);
                return stream;
            }


            private string ReadEmbeddedResource(string ResourceName)
            {
                var assembly = Assembly.GetExecutingAssembly();
                using (Stream stream = assembly.GetManifestResourceStream(ResourceName))
                using (StreamReader reader = new StreamReader(stream))
                {
                    string result = reader.ReadToEnd();
                    string temp = result.Replace('\r', ' ');
                    return temp;
                }
            }

            private string ReadReportXML(string ReportName)
            {
                try
                {
                    string s = " ", temp = "", t = "";
                    int x, y, z;
                    string result="";
                    using(StreamReader sr = new StreamReader(ReportName))
                    {
                        result= sr.ReadToEnd();
                    }
                    if (result.Contains("<PageHeight>") && result.Contains("</PageHeight>"))
                    {
                        x = result.IndexOf("<PageHeight>");
                        y = result.IndexOf("</PageHeight>");
                        temp = result.Substring(x, y - x);
                        s += temp + "</PageHeight>";
                        z = temp.IndexOf('>') + 1;
                        t = temp.Substring(z, temp.Length - z);
                        PageBounds[0] = Math.Round(Convert.ToDouble(t.Substring(0, t.Length - 2)), 2);
                    }
                    if (result.Contains("<PageWidth>") && result.Contains("</PageWidth>"))
                    {
                        x = result.IndexOf("<PageWidth>");
                        y = result.IndexOf("</PageWidth>");
                        temp = result.Substring(x, y - x);
                        s += temp + "</PageWidth>";
                        z = temp.IndexOf('>') + 1;
                        t = temp.Substring(z, temp.Length - z);
                        PageBounds[1] = Math.Round(Convert.ToDouble(t.Substring(0, t.Length - 2)), 2);
                    }
                    if (result.Contains("<LeftMargin>") && result.Contains("</LeftMargin>"))
                    {
                        x = result.IndexOf("<LeftMargin>");
                        y = result.IndexOf("</LeftMargin>");
                        temp = result.Substring(x, y - x);
                        s += temp + "</LeftMargin>";
                        z = temp.IndexOf('>') + 1;
                        t = temp.Substring(z, temp.Length - z);
                        PageBounds[2] = Math.Round(Convert.ToDouble(t.Substring(0, t.Length - 2)), 2);
                    }
                    if (result.Contains("<RightMargin>") && result.Contains("</RightMargin>"))
                    {
                        x = result.IndexOf("<RightMargin>");
                        y = result.IndexOf("</RightMargin>");
                        temp = result.Substring(x, y - x);
                        s += temp + "</RightMargin>";
                        z = temp.IndexOf('>') + 1;
                        t = temp.Substring(z, temp.Length - z);
                        PageBounds[3] = Math.Round(Convert.ToDouble(t.Substring(0, t.Length - 2)), 2);
                    }
                    if (result.Contains("<TopMargin>") && result.Contains("</TopMargin>"))
                    {
                        x = result.IndexOf("<TopMargin>");
                        y = result.IndexOf("</TopMargin>");
                        temp = result.Substring(x, y - x);
                        s += temp + "</TopMargin>";
                        z = temp.IndexOf('>') + 1;
                        t = temp.Substring(z, temp.Length - z);
                        PageBounds[4] = Math.Round(Convert.ToDouble(t.Substring(0, t.Length - 2)), 2);
                    }
                    if (result.Contains("<BottomMargin>") && result.Contains("</BottomMargin>"))
                    {
                        x = result.IndexOf("<BottomMargin>");
                        y = result.IndexOf("</BottomMargin>");
                        temp = result.Substring(x, y - x);
                        s += temp + "</BottomMargin>";
                        z = temp.IndexOf('>') + 1;
                        t = temp.Substring(z, temp.Length - z);
                        PageBounds[5] = Math.Round(Convert.ToDouble(t.Substring(0, t.Length - 2)), 2);
                    }
                    return s;
                }
                catch (Exception ex)
                {
                    ExceptionManager.Publish(ex);
                    return null;
                }
            }
            // Export the given report as an EMF (Enhanced Metafile) file.
            private void Export(LocalReport report, string ReportName)
            {
                try
                {
                    string temp = ReadReportXML(ReportName);
                    if (temp != null)
                    {
                        string deviceInfo =
                          "<DeviceInfo>" +
                          "  <OutputFormat>EMF</OutputFormat>"
                          + temp +
                          "</DeviceInfo>";

                        Warning[] warnings;
                        m_streams = new List<Stream>();
                        report.Render("Image", deviceInfo, CreateStream,
                           out warnings);
                        foreach (Stream stream in m_streams)
                            stream.Position = 0;
                    }
                    else
                    {
                        throw new Exception(MessageKeys.MsgSomethingWentWrongUnableToPrintReport);
                    }
                }
                catch (Exception ex)
                {
                    atMessageBox.Show(ex.Message);
                    if (ex.InnerException != null)
                    {
                        atMessageBox.Show(ex.InnerException.Message);
                    }
                }
            }

            // Handler for PrintPageEvents
            private void PrintPage(object sender, PrintPageEventArgs ev)
            {
                Metafile pageImage = new
          Metafile(m_streams[m_currentPageIndex]);

                // Adjust rectangular area with printer margins.
                Rectangle adjustedRect = new Rectangle(
                    ev.PageBounds.Left - (int)ev.PageSettings.HardMarginX,
                    ev.PageBounds.Top - (int)ev.PageSettings.HardMarginY,
                    ev.PageBounds.Width,
                    ev.PageBounds.Height);

                // Draw a white background for the report
                ev.Graphics.FillRectangle(Brushes.White, adjustedRect);

                // Draw the report content
                ev.Graphics.DrawImage(pageImage, adjustedRect);

                // Prepare for the next page. Make sure we haven't hit the end.
                m_currentPageIndex++;
                ev.HasMorePages = (m_currentPageIndex < m_streams.Count);


                //Metafile pageImage = new
                //Metafile(m_streams[m_currentPageIndex]);

                //// Adjust rectangular area with printer margins.
                //Rectangle adjustedRect = new Rectangle(
                //    ev.PageBounds.Left - (int)ev.PageSettings.HardMarginX,
                //    ev.PageBounds.Top - (int)ev.PageSettings.HardMarginY,
                //    ev.PageBounds.Width,
                //    ev.PageBounds.Height);

                //// Draw a white background for the report
                //ev.Graphics.FillRectangle(Brushes.White, adjustedRect);

                //// Draw the report content
                //ev.Graphics.DrawImage(pageImage, adjustedRect);

                //// Prepare for the next page. Make sure we haven't hit the end.
                //m_currentPageIndex++;
                //ev.HasMorePages = (m_currentPageIndex < m_streams.Count);
            }
            private void Print(PrinterSettings sett)
            {
                if (m_streams == null || m_streams.Count == 0)
                    throw new Exception("Error: no stream to print.");
                PrintDocument printDoc = new PrintDocument();

                if (!printDoc.PrinterSettings.IsValid)
                {
                    throw new Exception("Error: cannot find the default printer.");
                }
                else
                {
                    if (sett != null)
                    {
                        printDoc.PrinterSettings = sett;
                        //  printDoc.DefaultPageSettings.Landscape = sett.DefaultPageSettings.Landscape; @Lenin Problem by shefeer
                    }
                    printDoc.PrintPage += new PrintPageEventHandler(PrintPage);
                    m_currentPageIndex = 0;

                    printDoc.Print();
                }
            }
            //private void Print()
            //{
            //    PrinterSettings settings = new PrinterSettings();

            //    if (m_streams == null || m_streams.Count == 0)
            //        return;
            //    PrintDocument printDoc = new PrintDocument();
            //    printDoc.PrinterSettings.PrinterName = settings.PrinterName;

            //    PaperSize CustomSize = new PaperSize("Custom", (int)PageBounds[1] * 100, (int)PageBounds[0] * 100);
            //    CustomSize.RawKind = (int)PaperKind.Custom;
            //    printDoc.DefaultPageSettings.PaperSize = CustomSize;


            //    if (!printDoc.PrinterSettings.IsValid)
            //    {
            //        string msg = String.Format(
            //           "Can't find printer \"{0}\".", settings.PrinterName);
            //        MessageBox.Show(msg, "Print Error");
            //        return;
            //    }
            //    printDoc.PrintPage += new PrintPageEventHandler(PrintPage);
            //    printDoc.Print();
            //}

            /// <summary>
            ///  Create a local report for Report.rdlc, load the data,
            ///  export the report to an .emf file, and print it.
            /// Prints the report directly
            /// </summary>
            /// <param name="ReportName">Name of the report</param>
            /// <param name="DS_Name">Dataset name for the report. Provide the name which was used during RDLC file creation</param>
            //public void Run(string ReportName, string DS_Name)
            //{
            //    LocalReport report = new LocalReport();
            //    report.ReportEmbeddedResource = ReportName;
            //    report.DataSources.Add(new ReportDataSource(DS_Name, ReportTable));
            //    Export(report, ReportName);
            //    m_currentPageIndex = 0;
            //    Print();
            //    Dispose();
            //}
            public void PrintReport(string sReportPath, PrinterSettings sett, DataSet dsPrint, List<atReportParameter> reportParameters)
            {
                if (dsPrint == null) { throw new Exception(MessageKeys.MsgDataSourcePropertyCannotBeNull); }
                if (sReportPath == "") { throw new Exception(MessageKeys.MsgInvalidReportPath); }
                if (File.Exists(sReportPath) == false) { throw new Exception(MessageKeys.MsgReportFileNotFound); }
                LocalReport report = new LocalReport();
                report.ReportPath = sReportPath;
                report.EnableHyperlinks = true;
                ReportPageSettings _rptPageSettings= report.GetDefaultPageSettings();
                sett.DefaultPageSettings.PaperSize = _rptPageSettings.PaperSize;
                sett.DefaultPageSettings.Landscape = _rptPageSettings.IsLandscape;
                //if(_rptPageSettings.PaperSize.Width > _rptPageSettings.PaperSize.Height)
                //{
                //    sett.DefaultPageSettings.Landscape = false;  // Problem Reported by shefeer
                //}
                
                sett.DefaultPageSettings.Margins = _rptPageSettings.Margins;
                
                    
                
                foreach (DataTable dt in dsPrint.Tables)
                {
                    if (GlobalFunctions.CurrentCalendar == (int)ENCalendars.NepaliCalendar)
                    {
                        try
                        {
                            foreach (DataRow drow in dt.Rows)
                            {
                                if (dt.Columns.Contains(Enums.VoucherDate))
                                {
                                    drow[Enums.VoucherDate] = atNepaliDateConverter.convertToBS(drow[Enums.VoucherDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.DeliveryDate))
                                {
                                    drow[Enums.DeliveryDate] = atNepaliDateConverter.convertToBS(drow[Enums.DeliveryDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.DueDate))
                                {
                                    drow[Enums.DueDate] = atNepaliDateConverter.convertToBS(drow[Enums.DueDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.IssueDate))
                                {
                                    drow[Enums.IssueDate] = atNepaliDateConverter.convertToBS(drow[Enums.IssueDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.ReceiptDate))
                                {
                                    drow[Enums.ReceiptDate] = atNepaliDateConverter.convertToBS(drow[Enums.ReceiptDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.ExpiryDate))
                                {
                                    drow[Enums.ExpiryDate] = atNepaliDateConverter.convertToBS(drow[Enums.ExpiryDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.ManufDate))
                                {
                                    drow[Enums.ManufDate] = atNepaliDateConverter.convertToBS(drow[Enums.ManufDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.StartDate))
                                {
                                    drow[Enums.StartDate] = atNepaliDateConverter.convertToBS(drow[Enums.StartDate].ToString().toDateTime());
                                }
                                if (dt.Columns.Contains(Enums.EndDate))
                                {
                                    drow[Enums.EndDate] = atNepaliDateConverter.convertToBS(drow[Enums.EndDate].ToString().toDateTime());
                                }
                            }
                        }
                        catch { }
                    }
                    report.DataSources.Add(
                       new ReportDataSource(dt.TableName, dt));
                }
                ReportParameterInfoCollection rptParams = report.GetParameters();
                if (reportParameters == null && rptParams.Count > 6)
                {
                    throw new Exception(MessageKeys.MsgReportParametersNotSupplied);
                }
                if (reportParameters != null && reportParameters.ToList().Count > (rptParams.Count + 6))
                {
                    throw new Exception(MessageKeys.MsgSuppliedParameterCountIsGreaterThanAvailableParameterInReport);
                }
                if (rptParams.Where(X => X.Name == Enums.Company).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.Company, GlobalFunctions.sCompanyName);
                    report.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.CompanyAddress).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.CompanyAddress, GlobalFunctions.sCompanyAddress);
                    report.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.LoginLocation).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.LoginLocation, GlobalFunctions.sLoginLocation);
                    report.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.LoginUserName).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.LoginUserName, GlobalFunctions.sLoginUserName);
                    report.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.AmountFormat).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.AmountFormat, GlobalFunctions.ReportAmountFormat);
                    report.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.QtyFormat).ToList().Count > 0)
                {
                    ReportParameter par = new ReportParameter(Enums.QtyFormat, GlobalFunctions.ReportQtyFormat);
                    report.SetParameters(par);
                }
                if (rptParams.Where(X => X.Name == Enums.DateTimeFormat).ToList().Count > 0)
                {
                    ReportParameter par;
                    if (GlobalFunctions.CurrentCalendar == (int)ENCalendars.GregorianCalendar)
                    {
                        par = new ReportParameter(Enums.DateTimeFormat, "dd/MMM/yyyy");
                    }
                    else
                    {
                        par = new ReportParameter(Enums.DateTimeFormat, "dd/MM/yyyy");
                    }
                    report.SetParameters(par);
                }
                if (reportParameters != null)
                {
                    foreach (ReportParameterInfo rptParam in report.GetParameters())
                    {
                        if (reportParameters.Where(x => x.ParameterName == rptParam.Name).ToList().Count > 0)
                        {
                            atReportParameter atPar = new atReportParameter();
                            atPar = reportParameters.Where(x => x.ParameterName == rptParam.Name).Single();
                            ReportParameter par = new ReportParameter(atPar.ParameterName, atPar.ParameterValue == "" ? "--" : atPar.ParameterValue);
                            report.SetParameters(par);
                        }
                    }
                }
                Export(report, sReportPath);
                m_currentPageIndex = 0;
                Print(sett);
                Dispose();

            }
            public void Dispose()
            {
                if (m_streams != null)
                {
                    foreach (Stream stream in m_streams)
                        stream.Close();
                    m_streams = null;
                }
            }
        }
}

