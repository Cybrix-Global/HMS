﻿namespace atACC.HTL.UI
{
    partial class HotelAboutUSView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HotelAboutUSView));
            this.lblVersion = new System.Windows.Forms.Label();
            this.lblLink = new System.Windows.Forms.LinkLabel();
            this.lblEdition = new System.Windows.Forms.Label();
            this.btnYouTube = new System.Windows.Forms.Button();
            this.btnTwitter = new System.Windows.Forms.Button();
            this.btnFacebook = new System.Windows.Forms.Button();
            this.btnGooglePlus = new System.Windows.Forms.Button();
            this.lblBuildVersion = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblVersion
            // 
            this.lblVersion.BackColor = System.Drawing.Color.Transparent;
            this.lblVersion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.Location = new System.Drawing.Point(132, 418);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(84, 17);
            this.lblVersion.TabIndex = 1;
            this.lblVersion.Text = "21.0.1001";
            // 
            // lblLink
            // 
            this.lblLink.AutoSize = true;
            this.lblLink.BackColor = System.Drawing.Color.Transparent;
            this.lblLink.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLink.DisabledLinkColor = System.Drawing.Color.White;
            this.lblLink.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lblLink.LinkColor = System.Drawing.Color.Black;
            this.lblLink.Location = new System.Drawing.Point(431, 389);
            this.lblLink.Name = "lblLink";
            this.lblLink.Size = new System.Drawing.Size(147, 20);
            this.lblLink.TabIndex = 3;
            this.lblLink.TabStop = true;
            this.lblLink.Text = "www.atlanta-it.com";
            this.lblLink.VisitedLinkColor = System.Drawing.Color.Black;
            this.lblLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLink_LinkClicked);
            this.lblLink.MouseEnter += new System.EventHandler(this.lblLink_MouseEnter);
            this.lblLink.MouseLeave += new System.EventHandler(this.lblLink_MouseLeave);
            // 
            // lblEdition
            // 
            this.lblEdition.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEdition.BackColor = System.Drawing.Color.Transparent;
            this.lblEdition.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdition.Location = new System.Drawing.Point(12, 389);
            this.lblEdition.Name = "lblEdition";
            this.lblEdition.Size = new System.Drawing.Size(234, 31);
            this.lblEdition.TabIndex = 2;
            this.lblEdition.Text = "atACC ERP - Premium Edition";
            this.lblEdition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnYouTube
            // 
            this.btnYouTube.BackColor = System.Drawing.Color.Transparent;
            this.btnYouTube.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnYouTube.FlatAppearance.BorderSize = 0;
            this.btnYouTube.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnYouTube.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnYouTube.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYouTube.Location = new System.Drawing.Point(603, 438);
            this.btnYouTube.Name = "btnYouTube";
            this.btnYouTube.Size = new System.Drawing.Size(22, 20);
            this.btnYouTube.TabIndex = 8;
            this.btnYouTube.UseVisualStyleBackColor = false;
            this.btnYouTube.Click += new System.EventHandler(this.btnYouTube_Click);
            // 
            // btnTwitter
            // 
            this.btnTwitter.BackColor = System.Drawing.Color.Transparent;
            this.btnTwitter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTwitter.FlatAppearance.BorderSize = 0;
            this.btnTwitter.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnTwitter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTwitter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTwitter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTwitter.Location = new System.Drawing.Point(568, 438);
            this.btnTwitter.Name = "btnTwitter";
            this.btnTwitter.Size = new System.Drawing.Size(22, 20);
            this.btnTwitter.TabIndex = 9;
            this.btnTwitter.UseVisualStyleBackColor = false;
            this.btnTwitter.Click += new System.EventHandler(this.btnTwitter_Click);
            // 
            // btnFacebook
            // 
            this.btnFacebook.BackColor = System.Drawing.Color.Transparent;
            this.btnFacebook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFacebook.FlatAppearance.BorderSize = 0;
            this.btnFacebook.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnFacebook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnFacebook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnFacebook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFacebook.Location = new System.Drawing.Point(534, 438);
            this.btnFacebook.Name = "btnFacebook";
            this.btnFacebook.Size = new System.Drawing.Size(22, 20);
            this.btnFacebook.TabIndex = 10;
            this.btnFacebook.UseVisualStyleBackColor = false;
            this.btnFacebook.Click += new System.EventHandler(this.btnFacebook_Click);
            // 
            // btnGooglePlus
            // 
            this.btnGooglePlus.BackColor = System.Drawing.Color.Transparent;
            this.btnGooglePlus.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnGooglePlus.Enabled = false;
            this.btnGooglePlus.FlatAppearance.BorderSize = 0;
            this.btnGooglePlus.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGooglePlus.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGooglePlus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGooglePlus.Location = new System.Drawing.Point(501, 438);
            this.btnGooglePlus.Name = "btnGooglePlus";
            this.btnGooglePlus.Size = new System.Drawing.Size(22, 20);
            this.btnGooglePlus.TabIndex = 11;
            this.btnGooglePlus.UseVisualStyleBackColor = false;
            this.btnGooglePlus.Click += new System.EventHandler(this.btnGooglePlus_Click);
            // 
            // lblBuildVersion
            // 
            this.lblBuildVersion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBuildVersion.BackColor = System.Drawing.Color.Transparent;
            this.lblBuildVersion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuildVersion.Location = new System.Drawing.Point(26, 418);
            this.lblBuildVersion.Name = "lblBuildVersion";
            this.lblBuildVersion.Size = new System.Drawing.Size(100, 17);
            this.lblBuildVersion.TabIndex = 12;
            this.lblBuildVersion.Text = "Build Version :";
            this.lblBuildVersion.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 14F);
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(738, 1);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(28, 34);
            this.btnClose.TabIndex = 13;
            this.btnClose.TabStop = false;
            this.btnClose.Text = "x";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // HotelAboutUSView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(767, 498);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblBuildVersion);
            this.Controls.Add(this.btnGooglePlus);
            this.Controls.Add(this.btnFacebook);
            this.Controls.Add(this.btnTwitter);
            this.Controls.Add(this.btnYouTube);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.lblLink);
            this.Controls.Add(this.lblEdition);
            this.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "HotelAboutUSView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About us";
            this.Load += new System.EventHandler(this.AboutUSView_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.LinkLabel lblLink;
        private System.Windows.Forms.Label lblEdition;
        private System.Windows.Forms.Button btnYouTube;
        private System.Windows.Forms.Button btnTwitter;
        private System.Windows.Forms.Button btnFacebook;
        private System.Windows.Forms.Button btnGooglePlus;
        private System.Windows.Forms.Label lblBuildVersion;
        private System.Windows.Forms.Button btnClose;
    }
}