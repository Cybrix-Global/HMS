﻿namespace atACC.HTL.UI
{
    partial class ResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResetPassword));
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblConfirmPassword = new atACCFramework.UserControls.atLabel();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new atACCFramework.UserControls.TextBoxExt();
            this.txtPassword = new atACCFramework.UserControls.TextBoxExt();
            this.txtUserName = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblPassword = new atACCFramework.UserControls.atLabel();
            this.lblUserName = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblConfirmPassword);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.txtConfirmPassword);
            this.pnlMain.Controls.Add(this.txtPassword);
            this.pnlMain.Controls.Add(this.txtUserName);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblPassword);
            this.pnlMain.Controls.Add(this.lblUserName);
            this.pnlMain.Name = "pnlMain";
            // 
            // lblConfirmPassword
            // 
            resources.ApplyResources(this.lblConfirmPassword, "lblConfirmPassword");
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.RequiredField = false;
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // txtConfirmPassword
            // 
            resources.ApplyResources(this.txtConfirmPassword, "txtConfirmPassword");
            this.txtConfirmPassword.BackColor = System.Drawing.SystemColors.Window;
            this.txtConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtConfirmPassword.Format = null;
            this.txtConfirmPassword.isAllowNegative = false;
            this.txtConfirmPassword.isAllowSpecialChar = false;
            this.txtConfirmPassword.isNumbersOnly = false;
            this.txtConfirmPassword.isNumeric = false;
            this.txtConfirmPassword.isTouchable = false;
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtConfirmPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtConfirmPassword_KeyDown);
            // 
            // txtPassword
            // 
            resources.ApplyResources(this.txtPassword, "txtPassword");
            this.txtPassword.BackColor = System.Drawing.SystemColors.Window;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassword.Format = null;
            this.txtPassword.isAllowNegative = false;
            this.txtPassword.isAllowSpecialChar = false;
            this.txtPassword.isNumbersOnly = false;
            this.txtPassword.isNumeric = false;
            this.txtPassword.isTouchable = false;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtUserName
            // 
            resources.ApplyResources(this.txtUserName, "txtUserName");
            this.txtUserName.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUserName.Format = null;
            this.txtUserName.isAllowNegative = false;
            this.txtUserName.isAllowSpecialChar = false;
            this.txtUserName.isNumbersOnly = false;
            this.txtUserName.isNumeric = false;
            this.txtUserName.isTouchable = false;
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblPassword
            // 
            resources.ApplyResources(this.lblPassword, "lblPassword");
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.RequiredField = false;
            // 
            // lblUserName
            // 
            resources.ApplyResources(this.lblUserName, "lblUserName");
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.RequiredField = false;
            // 
            // ResetPassword
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "ResetPassword";
            this.NewRecord = true;
            this.atOkClick += new atACCFramework.BaseClasses.OKClickEventHandler(this.ResetPassword_atOkClick);
            this.atCancelClick += new atACCFramework.BaseClasses.CancelClickEventHandler(this.ResetPassword_atCancelClick);
            this.atValidate += new atACCFramework.BaseClasses.ValidateOKClickHandler(this.ResetPassword_atValidate);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.ResetPassword_atInitialise);
            this.Activated += new System.EventHandler(this.ResetPassword_Activated);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblConfirmPassword;
        private System.Windows.Forms.Label lblMandatory3;
        private atACCFramework.UserControls.TextBoxExt txtConfirmPassword;
        private atACCFramework.UserControls.TextBoxExt txtPassword;
        private atACCFramework.UserControls.TextBoxExt txtUserName;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atLabel lblPassword;
        private atACCFramework.UserControls.atLabel lblUserName;
    }
}