﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.UI
{
    public partial class ResetPinNumber : DialogBase
    {
        #region Constructor
        public ResetPinNumber()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion

        #region Private Variables
        HTL_LoginUser m_Loginuser;
        atACCHotelEntities dbh;
        #endregion

        #region Form Events
        private void ResetPinNumber_Activated(object sender, EventArgs e)
        {
            txtUserName.Focus();
        }
        private void ResetPinNumber_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                txtUserName.Focus();
                MinimizeButton.Visible = MaximizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private bool ResetPinNumber_atValidate(object source)
        {
            try
            {
                if (txtUserName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtUserName, MessageKeys.MsgUsernameMustBeEntered);
                    txtUserName.Focus();
                    return false;
                }
                if (txtPIN.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtPIN, MessageKeys.MsgPasswordMustBeEntered);
                    txtPIN.Focus();
                    return false;
                }
                if (txtConfirmPIN.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtConfirmPIN, MessageKeys.MsgPasswordMustBeConfirmed);
                    txtConfirmPIN.Focus();
                    return false;
                }
                if (txtUserName.Text.ToLower() == "admin" || txtUserName.Text.ToLower() == "poweruser")
                {
                    atMessageBox.Show(MessageKeys.MsgYouDonotHaveThePrevilegeForEdit);
                    return false;
                }
                if (txtPIN.Text.Trim() != txtConfirmPIN.Text.Trim())
                {
                    errProvider.SetError(txtConfirmPIN, MessageKeys.MsgBothPasswordAndConfirmPasswordMustBeSame);
                    txtConfirmPIN.Focus();
                    return false;
                }
                if (txtConfirmPIN.Text.Trim() != string.Empty)
                {
                    HTL_LoginUser _User = dbh.HTL_LoginUsers.Where(x => x.UserName != txtUserName.Text && x.Password == txtConfirmPIN.Text).SingleOrDefault();
                    if (_User != null)
                    {
                        atMessageBox.Show(MessageKeys.MsgDuplicateValuesNotAllowed);
                        return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool ResetPinNumber_atOkClick(object source, OKClickEventArgs e)
        {
            try
            {
                m_Loginuser = dbh.HTL_LoginUsers.Where(x => x.UserName == txtUserName.Text).SingleOrDefault();
                m_Loginuser.PINNumber = txtPIN.Text.ToInt32();
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.OK);
                return false;
            }
        }
        private void ResetPinNumber_atCancelClick(object source, CancelClickEventArgs e)
        {
            this.Close();
        }
        private void txtConfirmPIN_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
