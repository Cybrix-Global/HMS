﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using System.Data.SqlClient;
using atACC.Common;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.UI.UIClasses;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
using System.IO;
using System.Reflection;
using atACCORM;
namespace atACC.UI
{
    public partial class UpgradeView : FormBase
    {
        #region Private Variables
        SqlHelper sqlhelper;
        #endregion
        #region Constructor
        public UpgradeView()
        {
            InitializeComponent();
            sqlhelper = new SqlHelper();
        }
        #endregion
        #region private Methods
        public bool ExecuteScriptsFromFile(string sFilePath)
        {
            if (File.Exists(sFilePath))
            {
                pbar.Minimum = 0;
                string script = null;
                script = File.ReadAllText(sFilePath);
                string[] ScriptSplitter = script.Split(new string[] { "GO" }, StringSplitOptions.None);
                using (SqlConnection con = new SqlConnection(sqlhelper.getConnectionString()))
                {
                    con.Open();
                    foreach (string str in ScriptSplitter)
                    {
                        using (SqlCommand command = con.CreateCommand())
                        {
                            try
                            {
                                command.CommandText = str;
                                command.CommandTimeout = 0;
                                command.ExecuteNonQuery();

                            }
                            catch(Exception ex)
                            {
                                ExceptionManager.Publish(ex);
                            }
                            finally
                            {
                                con.Close();
                            }
                        }
                        
                    }
                }
            }
            
            return true;
        }
        public bool UpgradeDatabase()
        {
            string sDirectoryPath;
            #if DEBUG
                sDirectoryPath=@"F:\Dot Net Project\Upgrade\";
            #else
                sDirectoryPath=Application.StartupPath + @"\Upgrade";
            #endif
            DirectoryInfo d = new DirectoryInfo(sDirectoryPath);
            FileInfo[] Files = d.GetFiles("*.sql"); //Getting Sql files
            pbar.Minimum = 0;
            pbar.Maximum = Files.Length;
            double dblPercentage = 0, dblLength = 0;
            dblLength = Files.Length;
            int counter = 0;
            foreach (FileInfo file in Files)
            {
                Application.DoEvents();
                dblPercentage = (counter / dblLength) * 100.00;
                lblPercentage.Text = Math.Round(dblPercentage, 0).ToString() + "%";
                lblPercentage.Refresh();
                ExecuteScriptsFromFile(file.FullName);
                pbar.Value = counter;
                counter++;
            }
            return true;
        }
        #endregion
        #region Form Events
        private void UpgradeView_Load(object sender, EventArgs e)
        {
            if (UpgradeDatabase())
            {
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                this.DialogResult = DialogResult.Cancel;
            }
        }
        #endregion
    }
}
