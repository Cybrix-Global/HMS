﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using LocalORM;
namespace atACC.HTL.UI
{
    public partial class HotelAboutUSView : FormBase
    {
        #region Constructor
        public HotelAboutUSView()
        {
            InitializeComponent();
            this.BackgroundImage = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.HotelAboutUs);
            if (GlobalFunctions._oemData.ProductName == "atACC ERP")
            {
                lblLink.Visible = btnGooglePlus.Visible = btnFacebook.Visible = btnTwitter.Visible = btnYouTube.Visible = true;
            }
            else
            {
                lblLink.Visible = btnGooglePlus.Visible = btnFacebook.Visible = btnTwitter.Visible = btnYouTube.Visible = false;
            }

        }
        #endregion

        #region Form Events
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        private void lblLink_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                lblLink.Font = new Font("Segoe UI", 12, FontStyle.Bold);
                lblLink.LinkColor = Color.DarkMagenta;
                lblLink.ForeColor = Color.DarkMagenta;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void lblLink_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                lblLink.Font = new Font("Segoe UI", 11, FontStyle.Bold);
                lblLink.LinkColor = Color.Black;
                lblLink.ForeColor = Color.Black;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void AboutUSView_Load(object sender, EventArgs e)
        {
            try
            {
                if (GlobalFunctions.iCurrentRegistrationMode == (int)ENRegistrationModes.Demo)
                {
                    lblEdition.Text = MessageKeys.MsgApplicationName+ " - Demo Version";
                }
                else
                {
                    if (GlobalFunctions.iCurrentEdition == (int)ENEditions.BasicEdition)
                    {
                        lblEdition.Text = MessageKeys.MsgApplicationName+ " - Basic Edition";
                    }
                    else if (GlobalFunctions.iCurrentEdition == (int)ENEditions.StandardEdition)
                    {
                        lblEdition.Text = MessageKeys.MsgApplicationName+" - Standard Edition";
                    }
                    else if (GlobalFunctions.iCurrentEdition == (int)ENEditions.PremiumEdition)
                    {
                        lblEdition.Text = MessageKeys.MsgApplicationName + " - Premium Edition";
                    }
                }
                //lblVersion.Text = GlobalFunctions.BuildVersion;
                lblLink.Links.Add(0, 18, "http://www.atlanta-it.com");
                if (GlobalFunctions.iCurrentRegistrationMode == (int)ENRegistrationModes.Subscription)
                {
                    SettingsDbEntities sdb = new SettingsDbEntities();
                    Registration _registration = sdb.Registrations.Where(x => x.FK_RegistrationMode
                        == (int)ENRegistrationModes.Subscription)
                        .OrderByDescending(x => x.id).FirstOrDefault();
                }
                lblVersion.Text = GlobalFunctions.BuildVersion;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void lblLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                lblLink.LinkVisited = true;
                System.Diagnostics.Process.Start("http://www.atlanta-it.com");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnGooglePlus_Click(object sender, EventArgs e)
        {
            try
            {
                //System.Diagnostics.Process.Start("https://plus.google.com/u/0/102461612652407119103");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnFacebook_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("https://www.facebook.com/atlanta.atacc");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnTwitter_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("https://twitter.com/atlanta_it");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnYouTube_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("https://www.youtube.com/user/AtlantaITSolutions");
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        ///pending case
        ///1.Vers from dll
    }
}
