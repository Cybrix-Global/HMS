﻿namespace atACC.HTL.UI
{
    partial class frmNewCompany
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewCompany));
            this.label1 = new System.Windows.Forms.Label();
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.btnCancel = new atACCFramework.UserControls.atButton();
            this.btnOK = new atACCFramework.UserControls.atButton();
            this.btnSqlAuthentication = new atACCFramework.UserControls.atButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCompany = new atACCFramework.UserControls.TextBoxExt();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.errprvdr = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblPercentage = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.pbar = new System.Windows.Forms.ProgressBar();
            this.svFileDilog = new System.Windows.Forms.SaveFileDialog();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.btnClose = new System.Windows.Forms.Button();
            this.chktemplate = new System.Windows.Forms.CheckBox();
            this.cmbdatabase = new System.Windows.Forms.ComboBox();
            this.pnlFooter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errprvdr)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // pnlFooter
            // 
            resources.ApplyResources(this.pnlFooter, "pnlFooter");
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.btnCancel);
            this.pnlFooter.Controls.Add(this.btnOK);
            this.pnlFooter.Controls.Add(this.btnSqlAuthentication);
            this.pnlFooter.Name = "pnlFooter";
            // 
            // btnCancel
            // 
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnOK.FlatAppearance.BorderSize = 0;
            this.btnOK.ForeColor = System.Drawing.Color.White;
            this.btnOK.Name = "btnOK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnSqlAuthentication
            // 
            this.btnSqlAuthentication.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnSqlAuthentication.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSqlAuthentication, "btnSqlAuthentication");
            this.btnSqlAuthentication.ForeColor = System.Drawing.Color.White;
            this.btnSqlAuthentication.Name = "btnSqlAuthentication";
            this.btnSqlAuthentication.UseVisualStyleBackColor = false;
            this.btnSqlAuthentication.Click += new System.EventHandler(this.btnSqlAuthentication_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // txtCompany
            // 
            this.txtCompany.BackColor = System.Drawing.SystemColors.Window;
            this.txtCompany.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtCompany, "txtCompany");
            this.txtCompany.Format = null;
            this.txtCompany.isAllowNegative = false;
            this.txtCompany.isAllowSpecialChar = false;
            this.txtCompany.isNumbersOnly = false;
            this.txtCompany.isNumeric = false;
            this.txtCompany.isTouchable = false;
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnBrowse.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnBrowse, "btnBrowse");
            this.btnBrowse.ForeColor = System.Drawing.Color.White;
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // errprvdr
            // 
            this.errprvdr.ContainerControl = this;
            // 
            // lblPercentage
            // 
            resources.ApplyResources(this.lblPercentage, "lblPercentage");
            this.lblPercentage.Name = "lblPercentage";
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.lblStatus.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lblStatus.Name = "lblStatus";
            // 
            // pbar
            // 
            this.pbar.BackColor = System.Drawing.SystemColors.Highlight;
            resources.ApplyResources(this.pbar, "pbar");
            this.pbar.Name = "pbar";
            // 
            // lblHeading
            // 
            resources.ApplyResources(this.lblHeading, "lblHeading");
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // chktemplate
            // 
            resources.ApplyResources(this.chktemplate, "chktemplate");
            this.chktemplate.Name = "chktemplate";
            this.chktemplate.UseVisualStyleBackColor = true;
            this.chktemplate.CheckedChanged += new System.EventHandler(this.chktemplate_CheckedChanged);
            // 
            // cmbdatabase
            // 
            this.cmbdatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbdatabase, "cmbdatabase");
            this.cmbdatabase.FormattingEnabled = true;
            this.cmbdatabase.Name = "cmbdatabase";
            // 
            // frmNewCompany
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cmbdatabase);
            this.Controls.Add(this.chktemplate);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.lblPercentage);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pbar);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtCompany);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "frmNewCompany";
            this.pnlFooter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errprvdr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private atACCFramework.UserControls.atButton btnCancel;
        private atACCFramework.UserControls.atButton btnOK;
        private System.Windows.Forms.Label label3;
        private atACCFramework.UserControls.TextBoxExt txtCompany;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.ErrorProvider errprvdr;
        private System.Windows.Forms.SaveFileDialog svFileDilog;
        private System.Windows.Forms.Label lblPercentage;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ProgressBar pbar;
        private atACCFramework.UserControls.atButton btnSqlAuthentication;
        private atACCFramework.UserControls.atLabel lblHeading;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cmbdatabase;
        private System.Windows.Forms.CheckBox chktemplate;
    }
}