﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.UserControls;
using atACCORM;
using atACCFramework.Common;
using System.Reflection;
using atACC.HTL.UI.UIClasses;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.Common;
using System.Threading;
using LocalORM;
using atACC.HTL.ORM;
using atACC.HTL.Masters;


namespace atACC.HTL.UI
{
    public partial class atMDI : Form
    {
        #region Private Variables
        atACCContextEntities db;
        public List<MenuDetail> m_MenuDetails;
        List<DefaultMenu> m_DefaultMenus;

        #endregion
        #region Constructor
        public atMDI()
        {
            db = atContext.CreateContext();
            InitializeComponent();
            SetBackGroundImage();
        }
        #endregion
        #region Private and Public Methods
        private void SetBackGroundImage()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atMDI));
            if (GlobalFunctions.iCurrentRegistrationMode == (int)ENRegistrationModes.Demo)
            {
                this.BackgroundImage = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.MDIDemo);  // ((System.Drawing.Image)(resources.GetObject("mdidemo")));
            }
            else
            {
                if (GlobalFunctions.iCurrentEdition == (int)ENEditions.BasicEdition)
                {
                    this.BackgroundImage = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.MDIBasic); // ((System.Drawing.Image)(resources.GetObject("mdibasic")));
                }
                else if (GlobalFunctions.iCurrentEdition == (int)ENEditions.StandardEdition)
                {
                    this.BackgroundImage = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.MDIStandard); // ((System.Drawing.Image)(resources.GetObject("mdistandard")));
                }
                else
                {
                    this.BackgroundImage = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.MDIBasic); // ((System.Drawing.Image)(resources.GetObject("mdibasic")));
                }
            }

            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
		private void ResizeForm(Form frm)
		{
			frm.Width = Screen.PrimaryScreen.Bounds.Width - 5;
			frm.Height = Screen.PrimaryScreen.Bounds.Height - menuStripAcc.Height - 88;
		}
        public void fnPopulateDefaultMenus()
        {
            try
            {
                foreach (DefaultMenu md in m_DefaultMenus.Where(x => x.parentid == 0).ToList())
                {
                    ToolStripMenuItem menuItem = new ToolStripMenuItem(md.MenuName);
                    switch (GlobalFunctions.LanguageCulture.ToString2())
                    {
                        case "":
                            menuItem.Text = md.MenuName;
                            break;
                        case "en-US":
                            menuItem.Text = md.MenuName;
                            break;
                        case "ar-QA":
                            menuItem.Text = md.CaptionArabic;
                            break;
                        case "fr-FR":
                            menuItem.Text = md.CaptionFrench;
                            break;
                        case "ml-IN":
                            menuItem.Text = md.CaptionMalayalam;
                            break;
                        case "hi-IN":
                            menuItem.Text = md.CaptionHindi;
                            break;
                        case "es-ES":
                            menuItem.Text = md.CaptionSpanish;
                            break;
                        case "si-LK":
                            menuItem.Text = md.CaptionSinhala;
                            break;
                    }
                    menuItem.Tag = md;
                    menuStripAcc.Items.Add(menuItem);
                    fnAddDefaultChildMenu(menuItem, md.id);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void fnAddDefaultChildMenu(ToolStripMenuItem MenuItem, int MenueID)
        {
            try
            {
                foreach (DefaultMenu md in m_DefaultMenus.Where(x => x.parentid == MenueID).ToList())
                {
                    ToolStripMenuItem menuItem = new ToolStripMenuItem(md.MenuName);
                    menuItem.Tag = md;
                    switch (GlobalFunctions.LanguageCulture.ToString2())
                    {
                        case "":
                            menuItem.Text = md.MenuName;
                            break;
                        case "en-US":
                            menuItem.Text = md.MenuName;
                            break;
                        case "ar-QA":
                            menuItem.Text = md.CaptionArabic;
                            break;
                        case "fr-FR":
                            menuItem.Text = md.CaptionFrench;
                            break;
                        case "ml-IN":
                            menuItem.Text = md.CaptionMalayalam;
                            break;
                        case "hi-IN":
                            menuItem.Text = md.CaptionHindi;
                            break;
                        case "es-ES":
                            menuItem.Text = md.CaptionSpanish;
                            break;
                        case "si-LK":
                            menuItem.Text = md.CaptionSinhala;
                            break;
                    }
                    menuItem.Click += new EventHandler(ToolStripMenuItem_Click);
                    MenuItem.DropDownItems.Add(menuItem);
                   
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void fnPopulateMenuByModuleID(int ModuleID)
        {
            try
            {
                foreach (MenuDetail md in m_MenuDetails.Where(x => x.Parentid == 0 && x.FK_ModuleID == ModuleID).OrderBy(x=>x.DisplayPosition).ToList())
                {
                    if (md.MenuVisible.toBool())
                    {
                        ToolStripMenuItem menuItem = new ToolStripMenuItem(md.MenuName);
                        switch (GlobalFunctions.LanguageCulture.ToString2())
                        {
                            case "":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "en-US":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "ar-QA":
                                menuItem.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                                break;
                            case "fr-FR":
                                menuItem.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                                break;
                            case "ml-IN":
                                menuItem.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                                break;
                            case "hi-IN":
                                menuItem.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                                break;
                            case "es-ES":
                                menuItem.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                                break;
                            case "si-LK":
                                menuItem.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                                break;
                        }
                        menuItem.Name = md.MenuName;
                        menuItem.Tag = md;
                        menuItem.Image = UICommon.byteArrayToImage(md.Icon);
                        menuStripAcc.Items.Add(menuItem);
                        fnAddChildMenu(menuItem, md.id);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

        }
        private void fnAddChildMenu(ToolStripMenuItem MenuItem, int MenueID)
        {
            try
            {
                foreach (MenuDetail md in m_MenuDetails.Where(x => x.Parentid == MenueID).OrderBy(x=>x.DisplayPosition).ToList())
                {
                    if (md.MenuVisible.toBool())
                    {
                        ToolStripMenuItem menuItem = new ToolStripMenuItem(md.MenuName);
                        menuItem.Tag = md;
                        switch (GlobalFunctions.LanguageCulture.ToString2())
                        {
                            case "":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "en-US":
                                menuItem.Text = md.MenuCaption;
                                break;
                            case "ar-QA":
                                menuItem.Text = md.CaptionArabic == null ? md.MenuCaption : md.CaptionArabic;
                                break;
                            case "fr-FR":
                                menuItem.Text = md.CaptionFrench == null ? md.MenuCaption : md.CaptionFrench;
                                break;
                            case "ml-IN":
                                menuItem.Text = md.CaptionMalayalam == null ? md.MenuCaption : md.CaptionMalayalam;
                                break;
                            case "hi-IN":
                                menuItem.Text = md.CaptionHindi == null ? md.MenuCaption : md.CaptionHindi;
                                break;
                            case "es-ES":
                                menuItem.Text = md.CaptionSpanish == null ? md.MenuCaption : md.CaptionSpanish;
                                break;
                            case "si-LK":
                                menuItem.Text = md.CaptionSinhala == null ? md.MenuCaption : md.CaptionSinhala;
                                break;
                        }
                        menuItem.Name = md.MenuName;
                        menuItem.Image = UICommon.byteArrayToImage(md.Icon);
                        menuItem.Click += new EventHandler(ToolStripMenuItem_Click);
                        MenuItem.DropDownItems.Add(menuItem);
                        fnAddChildMenu(menuItem, md.id);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public void PopulateMenuesByModules(int ModuleID)
        {
            try
            {
                Properties.Settings.Default.CurrentModule = ModuleID;
                Properties.Settings.Default.Save();
                menuStripAcc.Items.Clear();
                fnPopulateDefaultMenus();
                fnPopulateMenuByModuleID(ModuleID);
            }
            catch (Exception)
            {

                throw;
            }
           
        }
        
        public void DisposeAllChild()
        {
            foreach (Form frm in this.MdiChildren)
            {
                    frm.Dispose();
                    frm.Close();   
            }
        }
        private bool ShowLogin()
        {
            if (UICommon.isLogined) { MessageBox.Show("Already Logged in!", MessageKeys.MsgApplicationName); return false; }

            //NumberLoginView frmLogin = new UI.NumberLoginView();
            LoginView frmLogin = new UI.LoginView();
            if (frmLogin.ShowDialog() == DialogResult.OK)
            {
                UICommon.isLogined = true;
                PopulateMenuDetails();
                ActivateDashboard();
                return true;
            }
            return false;
        }
        public void ClearAllMDIContent()
        {
            //UICommon.frmMdi.Text = "";
            menuStripAcc.Items.Clear();
            fnPopulateDefaultMenus();
            UICommon.isLogined = false;
            DisposeAllChild();
        }
        public void ReLoadMdiMenu()
        {
            menuStripAcc.Items.Clear();
            fnPopulateDefaultMenus();
            GlobalFunctions.LoadMenuDetails(ref db);
            m_MenuDetails = GlobalFunctions.entMenuDetails;
            ActivateDashboard();

        }
        public bool isVisibleMenuInsideModule(int iModuleID)
        {
            if (m_MenuDetails.Where(x => x.FK_ModuleID == iModuleID && x.MenuVisible == true).ToList().Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void fnActivateDefaultMenu(DefaultMenu defaultmenu)
        {
            try
            {
                switch (defaultmenu.MenuName)
                {
                    case "New Company":
                        ClearAllMDIContent();
                        frmNewCompany frmNew = new frmNewCompany();
                        if (frmNew.ShowDialog() == DialogResult.OK)
                        {
                            try
                            {
                                // Initial Query
                                bool done = false;

                                ThreadPool.QueueUserWorkItem((x) =>
                                {
                                    using (var splashForm = new SplashScreenView())
                                    {
                                        splashForm.Show();
                                        while (!done)
                                            Application.DoEvents();
                                        splashForm.Close();
                                    }
                                });

                               
                                done = true;
                            }
                            catch (Exception ex)
                            {
                                frmOpenCompany frm = new frmOpenCompany();
                                if (frm.ShowDialog() == DialogResult.Cancel) { return; }
                            }
                            UICommon.fnActivateDialog("ERP.ADM.Masters", "atACC.ADM.Masters.FinancialPeriodView");
                            if (ShowLogin())
                            {
                                UICommon.fnActivateDialog("ERP.ADM.Masters", "atACC.ADM.Masters.CompanyView");
                                UICommon.fnActivateDialog("ERP.ANI.Settings", "atACC.ANI.Settings.SettingsView");
                                //DashboardSingleton.Instance.Refresh();
                            }
                        }
                        break;
                    case "Open Company":
                        ClearAllMDIContent();
                         frmOpenCompany frmOpen = new frmOpenCompany();
                         if (frmOpen.ShowDialog() == DialogResult.OK)
                         {
                             MDILoad();
                         }
                         break;
                    case "Dashboard":
                        ActivateDashboard();
                        break;
                    case "Exit":
                        if (MessageBox.Show(CommonMessages.MessageKeys.MsgAreYouSureToClose.GetMsg(), "ERP", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            this.Close();
                        }
                        break;
                    case "Log In":
                        ShowLogin();
                        break;
                    case "Log Out":
                        if(UICommon.isLogined==false){MessageBox.Show("Already Log Out!",MessageKeys.MsgApplicationName);return;}
                        if(MessageBox.Show("Are You Sure you want to Log Out?",MessageKeys.MsgApplicationName,MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)
                        {
                            return;
                        }
                        GlobalFunctions.LoginUserID = 0;
                        ClearAllMDIContent();
                        break;
                    case "Financial Period":
                        UICommon.fnActivateForm("ERP.ADM.Masters", "atACC.ADM.Masters.FinancialPeriodView");
                        break;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        public  void ActivateDashboard()
        {
            try
            {
                if (UICommon.isLogined == false)
                {
                    MessageBox.Show("Please Log In!");
                    return;
                }
                //DashboardSingleton.Instance.Dock = DockStyle.Fill;
                
                //DashboardSingleton.Instance.Show();
                
                //DashboardSingleton.Instance.MdiParent = this;

                //DashboardSingleton.Instance.WindowState = FormWindowState.Normal;
                //ResizeForm(DashboardSingleton.Instance);
                UICommon _uicommon = new UICommon();
                _uicommon.ShowLoginEmployeeImage();
                _uicommon.ShowCompanyLogo();
				
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void PopulateMenuDetails()
        {
           db = atContext.CreateContext();
           GlobalFunctions.LoadMenuDetails(ref db);
           m_MenuDetails = GlobalFunctions.entMenuDetails;
        }
        public void MDILoad()
        {
            try
            {
                this.Text = MessageKeys.MsgApplicationName;
                
                m_DefaultMenus = db.DefaultMenus.ToList();       
                menuStripAcc.Items.Clear();
                fnPopulateDefaultMenus();
                GlobalFunctions.fnLoadCompanyDetails();
                
                //NumberLoginView frmLogin = new UI.NumberLoginView();
                LoginView frmLogin = new UI.LoginView();
                if (frmLogin.ShowDialog() == DialogResult.OK)
                {
                    UICommon.isLogined = true;
                    PopulateMenuDetails();
                    ActivateDashboard();
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
        #region Private Events
        private void ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
               
                ToolStripMenuItem menuItem = (ToolStripMenuItem)sender;
                if (menuItem.Tag != null)
                {
                    if (menuItem.Tag is DefaultMenu)
                    {
                        DefaultMenu defaultmenu = (DefaultMenu)menuItem.Tag;
                        fnActivateDefaultMenu(defaultmenu);
                    }
                    else if (menuItem.Tag is MenuDetail)
                    {
                        int menuid = ((MenuDetail)menuItem.Tag).id;
                        MenuDetail md = m_MenuDetails.Where(x => x.id == menuid).Single();
                        UICommon common = new UICommon();
                        if (md.AssemblyName != "" && md.ClassName != "")
                        {
                            if (md.isDialog.toBool())
                            {
                                UICommon.fnActivateDialog(md.AssemblyName, md.ClassName,md);
                            }
                            else
                            {
                                this.Cursor = Cursors.WaitCursor;
                                UICommon.fnActivateForm(md.AssemblyName, md.ClassName, md);
                            }
                        }
                        else if (md.ClassName != "")
                        {
                            this.Cursor = Cursors.WaitCursor;
                            UICommon.fnActivateProcess(md.ClassName,md);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            this.Cursor = Cursors.Arrow;
        }
        public  void ShowSubscriptionEndNotification()
        {
            if (GlobalFunctions.iCurrentRegistrationMode != (int)ENRegistrationModes.Subscription)
            {
                return;
            }
            ContextMenu contextmenu = new ContextMenu();
            contextmenu.MenuItems.Clear();
            MenuItem menuItemRenewSubscription = new MenuItem("Renew Subscription");
            menuItemRenewSubscription.Click += new EventHandler(menuItemRenewSubscription_Click);
            contextmenu.MenuItems.Add(menuItemRenewSubscription);
            MenuItem menuItemShowAllSubscriptions = new MenuItem("Show All Subscription");
            menuItemShowAllSubscriptions.Click += new EventHandler(menuItemShowAllSubscriptions_Click);
            contextmenu.MenuItems.Add(menuItemShowAllSubscriptions);
            MenuItem menuItemRegistration = new MenuItem("One Time Registration");
            menuItemRegistration.Click += new EventHandler(menuItemRegistration_Click);
            contextmenu.MenuItems.Add(menuItemRegistration);
            using (SettingsDbEntities sdb = new SettingsDbEntities())
            {
                Registration _registration = sdb.Registrations.Where(x => x.FK_RegistrationMode == (int)ENRegistrationModes.Subscription
                    ).OrderByDescending(x => x.id).FirstOrDefault();

                if (_registration != null)
                {
                    int daydiff = (_registration.SubscriptionEndDate.Value.Date - DateTime.Now.Date).Days;
                    if (daydiff <= 3)
                    {
                        //SubscriptionNotificationView frm = new SubscriptionNotificationView(_registration, daydiff);
                        //frm.ShowDialog();
                    }
                    else if (daydiff <= 15)
                    {
                        string sSubscriptionText =daydiff + " Day(s) to end your Subscription \n";
                        sSubscriptionText += " Subscription End Date:" + _registration.SubscriptionEndDate.Value.Date.ToEnd();
                        notify.Visible = true;
                        notify.Text = "Subscription";
                        notify.ContextMenu = contextmenu;
                        notify.BalloonTipTitle = MessageKeys.MsgApplicationName;
                        notify.BalloonTipText = sSubscriptionText;
                        notify.Icon = SystemIcons.Warning;
                        notify.BalloonTipClicked += new EventHandler(notify_BalloonTipClicked);
                        notify.ShowBalloonTip(1000);
                    }
                }
            }
        }

        void notify_BalloonTipClicked(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.SubscriptionView");
        }
        void menuItemRegistration_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.OneTimeRegistrationWizard");
        }
        void menuItemShowAllSubscriptions_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.RegistrationDetailsView");
        }
        void menuItemRenewSubscription_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.SubscriptionView");
        }
        private void atMDI_Load(object sender, EventArgs e)
        {
            try
            {
                MDILoad();
                ShowSubscriptionEndNotification();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        private void atMDI_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (GlobalFunctions.sAutoBackupPath != "" && GlobalFunctions.blnBackupWhileLogoff)
            {
                UICommon.AutoBackup(false);
            }
        }

        private void atMDI_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            atACCHotelEntities db = atHotelContext.CreateContext();
            Blocks b = new Blocks();
            b.Code = "1";
            b.Name = "Ground";
            db.Blocks.AddObject(b);
            db.SaveChanges();
            MessageBox.Show("Done");
        }

        private void btnBlocks_Click(object sender, EventArgs e)
        {
            BlocksView blocksView = new BlocksView();
            blocksView.Show();
        }

        private void btlFloor_Click(object sender, EventArgs e)
        {
            FloorsView floorsView = new FloorsView();
            floorsView.Show();
        }

        private void btnAmenities_Click(object sender, EventArgs e)
        {
            AmenityView amenityView = new AmenityView();
            amenityView.Show();
        }

        private void btnRateTypes_Click(object sender, EventArgs e)
        {
            RateTypeView rateTypeView = new RateTypeView();
            rateTypeView.Show();
        }

        private void btnRoomTypes_Click(object sender, EventArgs e)
        {
            RoomTypesView roomTypesView = new RoomTypesView();
            roomTypesView.Show();
        }

        private void btnRooms_Click(object sender, EventArgs e)
        {
            RoomView roomView = new RoomView();
            roomView.Show();
        }

        private void btnHallTypes_Click(object sender, EventArgs e)
        {
            
        }

        private void btnHalls_Click(object sender, EventArgs e)
        {
            HallView hallView = new HallView();
            hallView.Show();
        }

        private void btnExtraServ_Click(object sender, EventArgs e)
        {
            ExtraServicesView extraServicesView = new ExtraServicesView();
            extraServicesView.Show();
        }

        private void btnRoomTariff_Click(object sender, EventArgs e)
        {
            RoomTariffView roomTariffView = new RoomTariffView();
            roomTariffView.Show();
        }

        private void btnEnq_Click(object sender, EventArgs e)
        {
            //EnquiryView enqueryView = new EnquiryView();
            //enqueryView.Show();
        }

        private void btnBooking_Click(object sender, EventArgs e)
        {
            //BookingView bookingView = new BookingView();
            //bookingView.Show();
        }
        
    }
}
