﻿namespace atACC.HTL.UI
{
    partial class NumberLoginView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NumberLoginView));
            this.lblLogin = new atACCFramework.UserControls.atLabel();
            this.btnSepearator1 = new System.Windows.Forms.Button();
            this.btnLogin = new atACCFramework.UserControls.atGradientPanel();
            this.lblBtnLogin = new atACCFramework.UserControls.atLabel();
            this.pnlNumberPad = new System.Windows.Forms.Panel();
            this.btnClear = new atACCFramework.UserControls.atExButton();
            this.btn9 = new atACCFramework.UserControls.atExButton();
            this.btn8 = new atACCFramework.UserControls.atExButton();
            this.btn0 = new atACCFramework.UserControls.atExButton();
            this.btn4 = new atACCFramework.UserControls.atExButton();
            this.btn3 = new atACCFramework.UserControls.atExButton();
            this.btn7 = new atACCFramework.UserControls.atExButton();
            this.btn2 = new atACCFramework.UserControls.atExButton();
            this.btnBackSpace = new atACCFramework.UserControls.atExButton();
            this.btn5 = new atACCFramework.UserControls.atExButton();
            this.btn6 = new atACCFramework.UserControls.atExButton();
            this.btn1 = new atACCFramework.UserControls.atExButton();
            this.cmbLocation = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbFinancialPeriod = new atACCFramework.UserControls.ComboBoxExt();
            this.pnlMain = new atACCFramework.UserControls.atGradientPanel();
            this.btnClose = new System.Windows.Forms.Button();
            this.pcPoweredBy = new System.Windows.Forms.PictureBox();
            this.btnPanel = new atACCFramework.UserControls.atPOSButton2();
            this.lblPasswordLogin = new atACCFramework.UserControls.atLabel();
            this.txtPIN = new System.Windows.Forms.TextBox();
            this.lblForgotPassword = new System.Windows.Forms.LinkLabel();
            this.lblOpenCompany = new atACCFramework.UserControls.atLabel();
            this.lblAboutUs = new atACCFramework.UserControls.atLabel();
            this.lblLogintoContinue = new atACCFramework.UserControls.atLabel();
            this.pnlFYIcon = new System.Windows.Forms.Panel();
            this.pnlBranchIcon = new System.Windows.Forms.Panel();
            this.pcLogo = new System.Windows.Forms.PictureBox();
            this.errProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnLogin.SuspendLayout();
            this.pnlNumberPad.SuspendLayout();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcPoweredBy)).BeginInit();
            this.btnPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogin
            // 
            resources.ApplyResources(this.lblLogin, "lblLogin");
            this.lblLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblLogin.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.RequiredField = false;
            // 
            // btnSepearator1
            // 
            this.btnSepearator1.BackColor = System.Drawing.Color.LightGray;
            this.btnSepearator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSepearator1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSepearator1, "btnSepearator1");
            this.btnSepearator1.Name = "btnSepearator1";
            this.btnSepearator1.UseVisualStyleBackColor = false;
            // 
            // btnLogin
            // 
            this.btnLogin.AllowMultiSelect = false;
            this.btnLogin.Angle = 45F;
            this.btnLogin.BackColor = System.Drawing.Color.Aqua;
            this.btnLogin.BottomColor = System.Drawing.Color.RoyalBlue;
            this.btnLogin.Controls.Add(this.lblBtnLogin);
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.btnLogin, "btnLogin");
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Selected = false;
            this.btnLogin.TabStop = true;
            this.btnLogin.TextAdjestmentHeight = 0;
            this.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogin.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(66)))), ((int)(((byte)(5)))));
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            this.btnLogin.Paint += new System.Windows.Forms.PaintEventHandler(this.btnLogin_Paint);
            // 
            // lblBtnLogin
            // 
            resources.ApplyResources(this.lblBtnLogin, "lblBtnLogin");
            this.lblBtnLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblBtnLogin.ForeColor = System.Drawing.Color.White;
            this.lblBtnLogin.Name = "lblBtnLogin";
            this.lblBtnLogin.RequiredField = false;
            this.lblBtnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // pnlNumberPad
            // 
            this.pnlNumberPad.BackColor = System.Drawing.Color.Transparent;
            this.pnlNumberPad.Controls.Add(this.btnClear);
            this.pnlNumberPad.Controls.Add(this.btn9);
            this.pnlNumberPad.Controls.Add(this.btn8);
            this.pnlNumberPad.Controls.Add(this.btn0);
            this.pnlNumberPad.Controls.Add(this.btn4);
            this.pnlNumberPad.Controls.Add(this.btn3);
            this.pnlNumberPad.Controls.Add(this.btn7);
            this.pnlNumberPad.Controls.Add(this.btn2);
            this.pnlNumberPad.Controls.Add(this.btnBackSpace);
            this.pnlNumberPad.Controls.Add(this.btn5);
            this.pnlNumberPad.Controls.Add(this.btn6);
            this.pnlNumberPad.Controls.Add(this.btn1);
            resources.ApplyResources(this.pnlNumberPad, "pnlNumberPad");
            this.pnlNumberPad.Name = "pnlNumberPad";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.DarkGray;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btnClear.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnClear, "btnClear");
            this.btnClear.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnClear.Name = "btnClear";
            this.btnClear.Tag = "7";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.DarkGray;
            this.btn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn9.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn9.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn9, "btn9");
            this.btn9.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn9.Name = "btn9";
            this.btn9.Tag = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.DarkGray;
            this.btn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn8.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn8.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn8, "btn8");
            this.btn8.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn8.Name = "btn8";
            this.btn8.Tag = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.DarkGray;
            this.btn0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn0.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn0.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn0, "btn0");
            this.btn0.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn0.Name = "btn0";
            this.btn0.Tag = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.DarkGray;
            this.btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn4.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn4, "btn4");
            this.btn4.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn4.Name = "btn4";
            this.btn4.Tag = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.DarkGray;
            this.btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn3.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn3.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn3, "btn3");
            this.btn3.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn3.Name = "btn3";
            this.btn3.Tag = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.DarkGray;
            this.btn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn7.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn7.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn7, "btn7");
            this.btn7.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn7.Name = "btn7";
            this.btn7.Tag = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.DarkGray;
            this.btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn2.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn2.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn2, "btn2");
            this.btn2.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn2.Name = "btn2";
            this.btn2.Tag = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btnBackSpace
            // 
            this.btnBackSpace.BackColor = System.Drawing.Color.DarkGray;
            this.btnBackSpace.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBackSpace.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btnBackSpace.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnBackSpace, "btnBackSpace");
            this.btnBackSpace.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnBackSpace.Name = "btnBackSpace";
            this.btnBackSpace.Tag = "C";
            this.btnBackSpace.UseVisualStyleBackColor = false;
            this.btnBackSpace.Click += new System.EventHandler(this.btnBackSpace_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.DarkGray;
            this.btn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn5.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn5.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn5, "btn5");
            this.btn5.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn5.Name = "btn5";
            this.btn5.Tag = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.DarkGray;
            this.btn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn6.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn6.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn6, "btn6");
            this.btn6.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn6.Name = "btn6";
            this.btn6.Tag = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.DarkGray;
            this.btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn1.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            this.btn1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn1, "btn1");
            this.btn1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btn1.Name = "btn1";
            this.btn1.Tag = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // cmbLocation
            // 
            this.cmbLocation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbLocation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLocation.DropDownHeight = 300;
            this.cmbLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbLocation, "cmbLocation");
            this.cmbLocation.FormattingEnabled = true;
            this.cmbLocation.Name = "cmbLocation";
            // 
            // cmbFinancialPeriod
            // 
            this.cmbFinancialPeriod.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbFinancialPeriod.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbFinancialPeriod.DropDownHeight = 300;
            this.cmbFinancialPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbFinancialPeriod, "cmbFinancialPeriod");
            this.cmbFinancialPeriod.FormattingEnabled = true;
            this.cmbFinancialPeriod.Name = "cmbFinancialPeriod";
            // 
            // pnlMain
            // 
            this.pnlMain.AllowMultiSelect = false;
            this.pnlMain.Angle = 90F;
            this.pnlMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pnlMain.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.pnlMain.Controls.Add(this.btnClose);
            this.pnlMain.Controls.Add(this.pcPoweredBy);
            this.pnlMain.Controls.Add(this.btnPanel);
            this.pnlMain.Controls.Add(this.pcLogo);
            this.pnlMain.Cursor = System.Windows.Forms.Cursors.Default;
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Selected = false;
            this.pnlMain.TextAdjestmentHeight = 0;
            this.pnlMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlMain.TopColor = System.Drawing.Color.SteelBlue;
            this.pnlMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseDown);
            this.pnlMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseMove);
            this.pnlMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlMain_MouseUp);
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.TabStop = false;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // pcPoweredBy
            // 
            this.pcPoweredBy.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.pcPoweredBy, "pcPoweredBy");
            this.pcPoweredBy.Name = "pcPoweredBy";
            this.pcPoweredBy.TabStop = false;
            // 
            // btnPanel
            // 
            this.btnPanel.AllowMultiSelect = false;
            this.btnPanel.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnPanel, "btnPanel");
            this.btnPanel.Color = System.Drawing.Color.White;
            this.btnPanel.Controls.Add(this.lblPasswordLogin);
            this.btnPanel.Controls.Add(this.txtPIN);
            this.btnPanel.Controls.Add(this.lblForgotPassword);
            this.btnPanel.Controls.Add(this.lblOpenCompany);
            this.btnPanel.Controls.Add(this.pnlNumberPad);
            this.btnPanel.Controls.Add(this.lblAboutUs);
            this.btnPanel.Controls.Add(this.lblLogin);
            this.btnPanel.Controls.Add(this.btnLogin);
            this.btnPanel.Controls.Add(this.btnSepearator1);
            this.btnPanel.Controls.Add(this.lblLogintoContinue);
            this.btnPanel.Controls.Add(this.cmbLocation);
            this.btnPanel.Controls.Add(this.pnlFYIcon);
            this.btnPanel.Controls.Add(this.pnlBranchIcon);
            this.btnPanel.Controls.Add(this.cmbFinancialPeriod);
            this.btnPanel.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnPanel.Disabled = false;
            this.btnPanel.DisabledColor = System.Drawing.SystemColors.InactiveBorder;
            this.btnPanel.Icon = null;
            this.btnPanel.IconAdjestmentHeight = 0;
            this.btnPanel.IconAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPanel.InColor = System.Drawing.Color.White;
            this.btnPanel.Name = "btnPanel";
            this.btnPanel.Selected = false;
            this.btnPanel.SelectTypeButton = false;
            this.btnPanel.TextAdjestmentHeight = 0;
            this.btnPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPasswordLogin
            // 
            resources.ApplyResources(this.lblPasswordLogin, "lblPasswordLogin");
            this.lblPasswordLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblPasswordLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPasswordLogin.ForeColor = System.Drawing.Color.Gray;
            this.lblPasswordLogin.Name = "lblPasswordLogin";
            this.lblPasswordLogin.RequiredField = false;
            this.lblPasswordLogin.Click += new System.EventHandler(this.lblPasswordLogin_Click);
            // 
            // txtPIN
            // 
            this.txtPIN.BackColor = System.Drawing.Color.White;
            this.txtPIN.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.txtPIN, "txtPIN");
            this.txtPIN.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.txtPIN.Name = "txtPIN";
            this.txtPIN.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyDown);
            // 
            // lblForgotPassword
            // 
            resources.ApplyResources(this.lblForgotPassword, "lblForgotPassword");
            this.lblForgotPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblForgotPassword.LinkColor = System.Drawing.Color.Navy;
            this.lblForgotPassword.Name = "lblForgotPassword";
            this.lblForgotPassword.TabStop = true;
            this.lblForgotPassword.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblForgotPassword_LinkClicked);
            // 
            // lblOpenCompany
            // 
            resources.ApplyResources(this.lblOpenCompany, "lblOpenCompany");
            this.lblOpenCompany.BackColor = System.Drawing.Color.Transparent;
            this.lblOpenCompany.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblOpenCompany.ForeColor = System.Drawing.Color.Gray;
            this.lblOpenCompany.Name = "lblOpenCompany";
            this.lblOpenCompany.RequiredField = false;
            this.lblOpenCompany.Click += new System.EventHandler(this.lblOpenCompany_Click);
            // 
            // lblAboutUs
            // 
            resources.ApplyResources(this.lblAboutUs, "lblAboutUs");
            this.lblAboutUs.BackColor = System.Drawing.Color.Transparent;
            this.lblAboutUs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAboutUs.ForeColor = System.Drawing.Color.Gray;
            this.lblAboutUs.Name = "lblAboutUs";
            this.lblAboutUs.RequiredField = false;
            this.lblAboutUs.Click += new System.EventHandler(this.lblAboutUs_Click);
            // 
            // lblLogintoContinue
            // 
            resources.ApplyResources(this.lblLogintoContinue, "lblLogintoContinue");
            this.lblLogintoContinue.BackColor = System.Drawing.Color.Transparent;
            this.lblLogintoContinue.ForeColor = System.Drawing.Color.Gray;
            this.lblLogintoContinue.Name = "lblLogintoContinue";
            this.lblLogintoContinue.RequiredField = false;
            // 
            // pnlFYIcon
            // 
            this.pnlFYIcon.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.pnlFYIcon, "pnlFYIcon");
            this.pnlFYIcon.Name = "pnlFYIcon";
            // 
            // pnlBranchIcon
            // 
            this.pnlBranchIcon.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.pnlBranchIcon, "pnlBranchIcon");
            this.pnlBranchIcon.Name = "pnlBranchIcon";
            // 
            // pcLogo
            // 
            this.pcLogo.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.pcLogo, "pcLogo");
            this.pcLogo.Name = "pcLogo";
            this.pcLogo.TabStop = false;
            // 
            // errProvider
            // 
            this.errProvider.ContainerControl = this;
            // 
            // NumberLoginView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Controls.Add(this.pnlMain);
            this.Name = "NumberLoginView";
            this.Activated += new System.EventHandler(this.NumberLoginView_Activated);
            this.Load += new System.EventHandler(this.NumberLoginView_Load);
            this.btnLogin.ResumeLayout(false);
            this.btnLogin.PerformLayout();
            this.pnlNumberPad.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcPoweredBy)).EndInit();
            this.btnPanel.ResumeLayout(false);
            this.btnPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atLabel lblLogin;
        private System.Windows.Forms.Button btnSepearator1;
        private atACCFramework.UserControls.atGradientPanel btnLogin;
        private atACCFramework.UserControls.atLabel lblBtnLogin;
        private System.Windows.Forms.PictureBox pcPoweredBy;
        private System.Windows.Forms.Panel pnlFYIcon;
        private System.Windows.Forms.Panel pnlBranchIcon;
        private atACCFramework.UserControls.ComboBoxExt cmbLocation;
        private atACCFramework.UserControls.ComboBoxExt cmbFinancialPeriod;
        private atACCFramework.UserControls.atExButton btn9;
        private atACCFramework.UserControls.atExButton btn0;
        private atACCFramework.UserControls.atExButton btn8;
        private atACCFramework.UserControls.atExButton btn7;
        private atACCFramework.UserControls.atExButton btnBackSpace;
        private atACCFramework.UserControls.atExButton btn6;
        private atACCFramework.UserControls.atExButton btn1;
        private atACCFramework.UserControls.atExButton btn5;
        private atACCFramework.UserControls.atExButton btn2;
        private atACCFramework.UserControls.atExButton btn3;
        private atACCFramework.UserControls.atExButton btn4;
        private System.Windows.Forms.Panel pnlNumberPad;
        private System.Windows.Forms.PictureBox pcLogo;
        private atACCFramework.UserControls.atExButton btnClear;
        private atACCFramework.UserControls.atGradientPanel pnlMain;
        private System.Windows.Forms.LinkLabel lblForgotPassword;
        private atACCFramework.UserControls.atLabel lblLogintoContinue;
        private atACCFramework.UserControls.atLabel lblOpenCompany;
        private atACCFramework.UserControls.atLabel lblAboutUs;
        private atACCFramework.UserControls.atPOSButton2 btnPanel;
        private System.Windows.Forms.ErrorProvider errProvider;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtPIN;
        private atACCFramework.UserControls.atLabel lblPasswordLogin;
    }
}