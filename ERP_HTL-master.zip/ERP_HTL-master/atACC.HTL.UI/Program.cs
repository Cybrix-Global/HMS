﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using atACC.HTL.UI.UIClasses;
using System.Data.Entity;
using System.Data.EntityModel;
using System.Data.SqlClient;
using System.Data.EntityClient;
using atACC.Common;
using LocalORM;
using System.Threading;
using System.Data.Objects;
using System.Diagnostics;
using System.Drawing;
using atACCFramework.Common;
using atACC.CommonExtensions;

namespace atACC.HTL.UI
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            GlobalFunctions._oemData=UICommon.ReadOEMData();
            
            if (GlobalFunctions._oemData == null)
            {
                MessageBox.Show("Sensitive file missing!");
                return;
            }
            atACC.CommonMessages.MessageKeys.MsgApplicationName = GlobalFunctions._oemData.ProductName;
            
             SettingsDbEntities sdb = new SettingsDbEntities();
            
            Language lng = sdb.Languages.Where(x => x.Active == true).SingleOrDefault();
                if (lng != null)
                {
                    GlobalFunctions.LanguageCulture = lng.Culture;
                }
            
            ServerDetail serverDetail = sdb.ServerDetails.SingleOrDefault();
                GlobalFunctions.DbUserName = serverDetail.ServerUserName;
                GlobalFunctions.DbPassword = serverDetail.ServerPassword;

            RegistrationHelper regHelper = new RegistrationHelper();
            GlobalFunctions.boolSubScriptionExpired = false;
            if (!regHelper.isRegistered())
            {
                RegistrationView frmReg = new RegistrationView();
                if (frmReg.ShowDialog() == DialogResult.OK)
                {
                    if (frmReg.SelectedRegistrationMode == ENRegistrationModes.Demo)
                    {
                        // Check for Any Previous Subscription
                        string sProductID = regHelper.GetUUID();
                        if (sdb.Registrations.Where(x => x.FK_RegistrationMode == (int)ENRegistrationModes.Subscription
                            && x.ProductID == sProductID
                            ).Any())
                        {
                            GlobalFunctions.iCurrentRegistrationMode = (int)ENRegistrationModes.Subscription;
                            GlobalFunctions.boolSubScriptionExpired = true;
                        }
                        else
                        {
                            GlobalFunctions.iCurrentRegistrationMode = (int)frmReg.SelectedRegistrationMode;
                            GlobalFunctions.boolSubScriptionExpired = false;
                            if (!UICommon.ValidateDemo())
                            {
                                return;
                            }
                        }
                    }
                    else if (frmReg.SelectedRegistrationMode == ENRegistrationModes.OneTime)
                    {
                        GlobalFunctions.iCurrentRegistrationMode = (int)frmReg.SelectedRegistrationMode;
                        GlobalFunctions.iCurrentEdition = (int)frmReg.SelectedEdition;
                        GlobalFunctions.boolSubScriptionExpired = false;
                    }
                    else if (frmReg.SelectedRegistrationMode == ENRegistrationModes.Subscription)
                    {
                        GlobalFunctions.iCurrentRegistrationMode = (int)frmReg.SelectedRegistrationMode;
                        GlobalFunctions.boolSubScriptionExpired = false;
                    }
                }
                else
                {
                    return;

                }

            }


            if (serverDetail.DefaultServer != "" &&
                serverDetail.DefaultDatabase.Trim() != "") // Auto Open Company
            {
                
                GlobalFunctions.ServerName = serverDetail.DefaultServer;
                GlobalFunctions.DatabaseName = serverDetail.DefaultDatabase;
                GlobalFunctions.sWindowsAuthenticationConnectionString =@"Server=" + GlobalFunctions.ServerName + ";Integrated security=SSPI;database=" + GlobalFunctions.DatabaseName + ";";
                GlobalFunctions.sSqlAuthenticationConnectionString = @"Server=" + GlobalFunctions.ServerName + ";Integrated Security=False;User ID=" + GlobalFunctions.DbUserName + ";Password=" + GlobalFunctions.DbPassword + ";database=" + GlobalFunctions.DatabaseName + ";";
                try
                {
                    if (UICommon.isUpgradeRequired(false))
                    {
                        UICommon.UpgradeView(false);
                    }
                }
                catch (Exception ex) 
                {
                    MessageBox.Show("Invalid auto open company! reset it through settings");
                    frmOpenCompany frm = new frmOpenCompany();
                    
                    if (frm.ShowDialog() == DialogResult.Cancel) { return; }
                }
                GlobalFunctions.GenerateEntityConnection();
            }
            else
            {
                frmOpenCompany frm = new frmOpenCompany();
                if (frm.ShowDialog() == DialogResult.Cancel) { return; }
            }
            int iHotelManagementModuleId = 9;
            atACC.HTL.ORM.atACCHotelEntities db = atACC.HTL.ORM.atHotelContext.CreateContext();
            if (!db.Modules.Any(x => x.id == iHotelManagementModuleId && x.status == true))
            {
                atMessageBox.Show("Hotel Management Module is not enabled in this company.");
                return;
            }
            //if (GlobalFunctions.iCurrentEdition == (int)ENEditions.StandardEdition)
            //{
            //    atMessageBox.Show("Hotel Management Module is not available in Standard Edition.");
            //    return;
            //}
            if (GlobalFunctions.iCurrentEdition == (int)ENEditions.BasicEdition)
            {
                atMessageBox.Show("Hotel Management Module is not available in Standard Edition.");
                return;
            }
            //(System.Data.EntityClient.EntityConnection)db.Connection;
            bool done = false;
            try
            {
                // Initial Query
//#if !DEBUG
                ThreadPool.QueueUserWorkItem((x) =>
                {
                    using (var splashForm = new SplashScreenView())
                    {
                        splashForm.Show();
                        while (!done)
                            Application.DoEvents();
                        splashForm.Close();
                    }
                });
                
                atACC.HTL.ORM.Company company = db.Companies.SingleOrDefault();
                done = true;
//#endif
            }
            catch (Exception ex)
            {
                frmOpenCompany frm = new frmOpenCompany();
                if (frm.ShowDialog() == DialogResult.Cancel) { return; }
                db = atACC.HTL.ORM.atHotelContext.CreateContext();
                atACC.HTL.ORM.Company company = db.Companies.SingleOrDefault();
                done = true;
            }

            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
            UICommon._currentICon = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.IConData).ToIcon();
            
            UICommon.AppDashboard = new Dashboard();
            UICommon.AppDashboard.Icon = UICommon._currentICon;
            Application.Run(UICommon.AppDashboard);

            

        }
        
        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            
        }
    }
}
