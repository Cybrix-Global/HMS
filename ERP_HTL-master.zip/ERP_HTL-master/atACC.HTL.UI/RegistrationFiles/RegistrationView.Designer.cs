﻿namespace atACC.HTL.UI
{
    partial class RegistrationView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrationView));
            this.btnOneTime = new System.Windows.Forms.Button();
            this.btnSubscription = new System.Windows.Forms.Button();
            this.btnRegisterLater = new System.Windows.Forms.Button();
            this.pnlHeader = new atACCFramework.UserControls.atPanel();
            this.lblClose = new System.Windows.Forms.Label();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            this.atPanel2 = new atACCFramework.UserControls.atPanel();
            this.btnLine = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.btnLine5 = new System.Windows.Forms.Button();
            this.btnLine4 = new System.Windows.Forms.Button();
            this.btnLine3 = new System.Windows.Forms.Button();
            this.btnLine2 = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlHeader.SuspendLayout();
            this.atPanel2.SuspendLayout();
            this.pnlFooter.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOneTime
            // 
            this.btnOneTime.BackColor = System.Drawing.Color.Transparent;
            this.btnOneTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOneTime.FlatAppearance.BorderSize = 0;
            this.btnOneTime.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnOneTime.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnOneTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOneTime.Font = new System.Drawing.Font("Noto Sans", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOneTime.Image = ((System.Drawing.Image)(resources.GetObject("btnOneTime.Image")));
            this.btnOneTime.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOneTime.Location = new System.Drawing.Point(9, 7);
            this.btnOneTime.Name = "btnOneTime";
            this.btnOneTime.Size = new System.Drawing.Size(179, 38);
            this.btnOneTime.TabIndex = 0;
            this.btnOneTime.Text = "  One Time Licence";
            this.btnOneTime.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnOneTime.UseVisualStyleBackColor = false;
            this.btnOneTime.Click += new System.EventHandler(this.btnOneTime_Click);
            // 
            // btnSubscription
            // 
            this.btnSubscription.BackColor = System.Drawing.Color.Transparent;
            this.btnSubscription.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubscription.FlatAppearance.BorderSize = 0;
            this.btnSubscription.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSubscription.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSubscription.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubscription.Font = new System.Drawing.Font("Noto Sans", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubscription.Image = ((System.Drawing.Image)(resources.GetObject("btnSubscription.Image")));
            this.btnSubscription.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSubscription.Location = new System.Drawing.Point(221, 6);
            this.btnSubscription.Name = "btnSubscription";
            this.btnSubscription.Size = new System.Drawing.Size(135, 38);
            this.btnSubscription.TabIndex = 1;
            this.btnSubscription.Text = "Subscription";
            this.btnSubscription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSubscription.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSubscription.UseVisualStyleBackColor = false;
            this.btnSubscription.Click += new System.EventHandler(this.btnSubscription_Click);
            // 
            // btnRegisterLater
            // 
            this.btnRegisterLater.BackColor = System.Drawing.Color.Transparent;
            this.btnRegisterLater.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegisterLater.FlatAppearance.BorderSize = 0;
            this.btnRegisterLater.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRegisterLater.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnRegisterLater.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegisterLater.Font = new System.Drawing.Font("Noto Sans", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisterLater.Image = ((System.Drawing.Image)(resources.GetObject("btnRegisterLater.Image")));
            this.btnRegisterLater.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegisterLater.Location = new System.Drawing.Point(395, 7);
            this.btnRegisterLater.Name = "btnRegisterLater";
            this.btnRegisterLater.Size = new System.Drawing.Size(152, 38);
            this.btnRegisterLater.TabIndex = 2;
            this.btnRegisterLater.Text = "  Register Later";
            this.btnRegisterLater.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegisterLater.UseVisualStyleBackColor = false;
            this.btnRegisterLater.Click += new System.EventHandler(this.btnRegisterLater_Click);
            // 
            // pnlHeader
            // 
            this.pnlHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlHeader.BackColor = System.Drawing.SystemColors.Window;
            this.pnlHeader.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlHeader.BackgroundImage")));
            this.pnlHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlHeader.Controls.Add(this.lblClose);
            this.pnlHeader.Controls.Add(this.lblHead);
            this.pnlHeader.Location = new System.Drawing.Point(1, 1);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(561, 50);
            this.pnlHeader.TabIndex = 3;
            // 
            // lblClose
            // 
            this.lblClose.AutoSize = true;
            this.lblClose.BackColor = System.Drawing.Color.Transparent;
            this.lblClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblClose.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClose.ForeColor = System.Drawing.Color.DarkGray;
            this.lblClose.Location = new System.Drawing.Point(533, 2);
            this.lblClose.Name = "lblClose";
            this.lblClose.Size = new System.Drawing.Size(26, 25);
            this.lblClose.TabIndex = 1;
            this.lblClose.Text = "X";
            this.lblClose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblClose.Click += new System.EventHandler(this.lblClose_Click);
            this.lblClose.MouseEnter += new System.EventHandler(this.lblClose_MouseEnter);
            this.lblClose.MouseLeave += new System.EventHandler(this.lblClose_MouseLeave);
            // 
            // lblHead
            // 
            this.lblHead.AutoSize = true;
            this.lblHead.BackColor = System.Drawing.Color.Transparent;
            this.lblHead.Font = new System.Drawing.Font("Open Sans", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHead.ForeColor = System.Drawing.Color.White;
            this.lblHead.Location = new System.Drawing.Point(178, 1);
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            this.lblHead.Size = new System.Drawing.Size(252, 47);
            this.lblHead.TabIndex = 0;
            this.lblHead.Text = "Demo Version";
            // 
            // atPanel2
            // 
            this.atPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.atPanel2.BackColor = System.Drawing.SystemColors.Window;
            this.atPanel2.Controls.Add(this.btnLine);
            this.atPanel2.Controls.Add(this.label3);
            this.atPanel2.Controls.Add(this.label2);
            this.atPanel2.Controls.Add(this.label1);
            this.atPanel2.Location = new System.Drawing.Point(1, 47);
            this.atPanel2.Name = "atPanel2";
            this.atPanel2.Size = new System.Drawing.Size(561, 139);
            this.atPanel2.TabIndex = 4;
            // 
            // btnLine
            // 
            this.btnLine.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine.Location = new System.Drawing.Point(0, 137);
            this.btnLine.Name = "btnLine";
            this.btnLine.Size = new System.Drawing.Size(565, 2);
            this.btnLine.TabIndex = 8;
            this.btnLine.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Open Sans", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(508, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "register the software. Click ‘Register Later’ to proceed in \'Evaluation Mode\'.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Open Sans", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(538, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "till the evaluation period expires. This message will continue appearing till you" +
    "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Open Sans", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(547, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "This software is currently unregistered and you are free to use it in its full ef" +
    "fect";
            // 
            // pnlFooter
            // 
            this.pnlFooter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.btnLine5);
            this.pnlFooter.Controls.Add(this.btnLine4);
            this.pnlFooter.Controls.Add(this.btnLine3);
            this.pnlFooter.Controls.Add(this.btnLine2);
            this.pnlFooter.Controls.Add(this.btnRegisterLater);
            this.pnlFooter.Controls.Add(this.btnOneTime);
            this.pnlFooter.Controls.Add(this.btnSubscription);
            this.pnlFooter.Location = new System.Drawing.Point(1, 185);
            this.pnlFooter.Name = "pnlFooter";
            this.pnlFooter.Size = new System.Drawing.Size(561, 52);
            this.pnlFooter.TabIndex = 2;
            // 
            // btnLine5
            // 
            this.btnLine5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine5.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine5.Location = new System.Drawing.Point(555, 6);
            this.btnLine5.Name = "btnLine5";
            this.btnLine5.Size = new System.Drawing.Size(2, 37);
            this.btnLine5.TabIndex = 16;
            this.btnLine5.UseVisualStyleBackColor = true;
            // 
            // btnLine4
            // 
            this.btnLine4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine4.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine4.Location = new System.Drawing.Point(381, 6);
            this.btnLine4.Name = "btnLine4";
            this.btnLine4.Size = new System.Drawing.Size(2, 37);
            this.btnLine4.TabIndex = 11;
            this.btnLine4.UseVisualStyleBackColor = true;
            // 
            // btnLine3
            // 
            this.btnLine3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine3.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine3.Location = new System.Drawing.Point(192, 6);
            this.btnLine3.Name = "btnLine3";
            this.btnLine3.Size = new System.Drawing.Size(2, 37);
            this.btnLine3.TabIndex = 10;
            this.btnLine3.UseVisualStyleBackColor = true;
            // 
            // btnLine2
            // 
            this.btnLine2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine2.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine2.Location = new System.Drawing.Point(7, 6);
            this.btnLine2.Name = "btnLine2";
            this.btnLine2.Size = new System.Drawing.Size(2, 37);
            this.btnLine2.TabIndex = 9;
            this.btnLine2.UseVisualStyleBackColor = true;
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMain.Controls.Add(this.pnlFooter);
            this.pnlMain.Controls.Add(this.pnlHeader);
            this.pnlMain.Controls.Add(this.atPanel2);
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(565, 240);
            this.pnlMain.TabIndex = 5;
            // 
            // RegistrationView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(565, 240);
            this.Controls.Add(this.pnlMain);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RegistrationView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "";
            this.Load += new System.EventHandler(this.RegistrationView_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RegistrationView_KeyDown);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.atPanel2.ResumeLayout(false);
            this.atPanel2.PerformLayout();
            this.pnlFooter.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOneTime;
        private System.Windows.Forms.Button btnSubscription;
        private atACCFramework.UserControls.atPanel pnlHeader;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.atPanel atPanel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlMain;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private System.Windows.Forms.Button btnRegisterLater;
        private System.Windows.Forms.Button btnLine;
        private System.Windows.Forms.Label lblClose;
        private System.Windows.Forms.Button btnLine2;
        private System.Windows.Forms.Button btnLine3;
        private System.Windows.Forms.Button btnLine4;
        private System.Windows.Forms.Button btnLine5;
    }
}