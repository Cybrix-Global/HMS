﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonExtensions;
using atACC.CommonMessages;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using AtCryptoGraphy2;
using LocalORM;
using System.Diagnostics;
namespace atACC.HTL.UI
{

    public partial class RegistrationDetailsView : FormBase
    {

        public RegistrationDetailsView()
        {
            InitializeComponent();
            PopulateRegistrations();
        }
        private void PopulateRegistrations()
        {
            SettingsDbEntities sdb = new SettingsDbEntities();
            var entRegistrations = sdb.Registrations.OrderBy(x => x.id)
                .Select(x => new RegtistrationClass
                {
                    Id= x.id,
                    CDKey= x.CDKey,
                    ProductID= x.ProductID,
                    RegistrationMode= x.FK_RegistrationMode==(int)ENRegistrationModes.OneTime?"One Time":"Subscription",
                    RegistrationNo= x.RegistrationNo,
                    RegistrationDate= x.RegistrationDate,
                    SubscriptionDays= x.SubscriptionDays,
                    SubscriptionEndDate= x.SubscriptionEndDate,
                    Edition=x.FK_Edition==(int)ENEditions.BasicEdition?"Basic Edition":"Standard Edition"
                }).ToList();
            dgRegistrations.AutoGenerateColumns = false;
            dgRegistrations.DataSource = entRegistrations;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }

        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
    }
}
