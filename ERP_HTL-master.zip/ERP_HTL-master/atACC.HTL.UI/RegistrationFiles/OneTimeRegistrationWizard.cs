﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using atACC.Common;
using atACC.CommonExtensions;
using atACC.CommonMessages;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using AtCryptoGraphy2;
using LocalORM;
using System.Diagnostics;
namespace atACC.HTL.UI
{
    public partial class OneTimeRegistrationWizard : FormBase
    {
        #region Private Variable
        DataTable dtCDKeyToProduct;
        RegistrationHelper regHelper;
        List<Edition> entEditions;
        int iCurrentPanelID;
        AtCryptoGraphy2.AtCryptoGraphy2 _cryptography;
        int iLicenseAvailable;
        int iProductMID;
        ENWizardPanels CurrentPanel;
        string sCDKeyProductName;
        string sEditionTag;
        #endregion

        #region Constructor
        public OneTimeRegistrationWizard()
        {
            InitializeComponent();
            regHelper=new RegistrationHelper();
            _cryptography=new AtCryptoGraphy2.AtCryptoGraphy2();
            lblcap1.Text = "Welcome to " + MessageKeys.MsgApplicationName + " 19.0 Registration Wizard.";
            lblContent1.Text = "This wizard will unlock the demo version of " + MessageKeys.MsgApplicationName + " 19.0 and register the software for full use. ";
            if (MessageKeys.MsgApplicationName.Trim() != MessageKeys.MsgApplicationName)
            {
                lblVisit.Visible = false;
                lblWebLink.Visible = false;
                lblforRegistration.Visible = false;
            }
            if (GlobalFunctions._oemData.ProductName == "atACC ERP")
            {
                lblforRegistration.Visible = lblWebLink.Visible = lblVisit.Visible = true;
            }
            else
            {
                lblforRegistration.Visible = lblWebLink.Visible = lblVisit.Visible = false;
            }
        }
        #endregion

        #region Public Properties
        public ENEditions SelectedEdition { get; set; }
        #endregion

        #region Private Methods
        private void PopulateEditions()
        {
            using (SettingsDbEntities sdb = new SettingsDbEntities())
            {
                entEditions = sdb.Editions.ToList();
                cmbEditions.DisplayMember = "Name";
                cmbEditions.ValueMember = "id";
                cmbEditions.DataSource = entEditions;
                cmbEditionActivate.DisplayMember = "Name";
                cmbEditionActivate.ValueMember = "id";
                cmbEditionActivate.DataSource = entEditions;
            }
        }
        private void PopulateCountry()
        {
            try
            {
                
                if (CmbCountry.DataSource != null) { return; }
                using (MySqlConnection conn = new MySqlConnection(RegistrationHelper.sRegistrationConnectionString))
                {
                    conn.Open();
                    try
                    {
                        
                        string sql = "SELECT DISTINCT country FROM regnoregister WHERE TRIM(country)<>'' ORDER BY country";
                        DataTable dtCountry = new DataTable();
                        RegistrationHelper reg = new RegistrationHelper();
                        dtCountry= reg.GetData(sql, conn);
                        CmbCountry.DisplayMember = "country";
                        CmbCountry.ValueMember = "country";
                        CmbCountry.DataSource = dtCountry;
                    }
                    catch (Exception ex)
                    {
                        ExceptionManager.Publish(ex);
                        
                    }
                    finally
                    {
                        conn.Close();
                        this.Cursor = Cursors.Arrow;
                    }
                }
            }
            catch (Exception)
            {
                
            }
        }
        private bool ValidateRegistrationForm()
        {
            if (txtCustomerName.Text == "") { errPrvdr.SetError(txtCustomerName, "Customer name must be entered!"); txtCustomerName.Focus(); return false; }
            if (txtBusinessType.Text == "") { errPrvdr.SetError(txtBusinessType, "Businees Type must be entered!"); txtBusinessType.Focus(); return false; }
            if (txtAddress.Text == "") { errPrvdr.SetError(txtAddress, "Address must be entered!"); txtAddress.Focus(); return false; }
            if (txtCity.Text == "") { errPrvdr.SetError(txtCity, "City must be entered!"); txtCity.Focus(); return false; }
            if (txtState.Text == "") { errPrvdr.SetError(txtState, "State must be entered!"); txtState.Focus(); return false; }
            if (txtTelephone.Text == "") { errPrvdr.SetError(txtTelephone, "Telephone number must be entered!"); txtTelephone.Focus(); return false; }
            if (txtMobile.Text == "") { errPrvdr.SetError(txtTelephone, "Mobile number must be entered!"); txtMobile.Focus(); return false; }
            if (txtEmail.Text == "") { errPrvdr.SetError(txtEmail, "Email must be entered!"); txtEmail.Focus(); return false; }
            if (txtProductID.Text == "") { errPrvdr.SetError(txtProductID, "Product ID must be entered!"); txtProductID.Focus(); return false; }
            if (!GlobalFunctions.IsValidEmailId(txtEmail.Text))
            {
                errPrvdr.SetError(txtEmail, MessageKeys.MsgInvalidEmailAddress);
                txtEmail.Focus();
                return false;
            }
            return true;
        }
        private bool ValidateCDKey()
        {
            using (MySqlConnection conn = new MySqlConnection(RegistrationHelper.sRegistrationConnectionString))
            {
                conn.Open();
                try
                {
                    string sql = @"SELECT License,ifnull(PartyName,'') as PartyName,prd.ProductName,prd.Tag,cdk.ProductMID  FROM regcdkeytoproduct cdk
                                INNER JOIN regproductmaster prd ON cdk.ProductMID=prd.ProductMID ";
                    sql += " WHERE CDKey='" + txtCDKey.Text + "' AND `Status`='Y'";
                    dtCDKeyToProduct = new DataTable();
                    dtCDKeyToProduct = regHelper.GetData(sql, conn);
                    if (dtCDKeyToProduct.Rows.Count > 0)
                    {
                        iLicenseAvailable = dtCDKeyToProduct.Rows[0]["License"].ToString().ToInt32();
                        sCDKeyProductName = dtCDKeyToProduct.Rows[0]["ProductName"].ToString();
                        sEditionTag = dtCDKeyToProduct.Rows[0]["Tag"].ToString();
                        iProductMID = dtCDKeyToProduct.Rows[0]["ProductMID"].ToString().ToInt32();
                        if (sEditionTag == CDKeyEditionTags.Basic19)
                        {
                            if (cmbEditions.SelectedValue.ToInt32() != (int)ENEditions.BasicEdition) { cmbEditions.Focus(); throw new Exception("CD Key Not Valid For Selected Edition!"); }
                        }
                        if (sEditionTag == CDKeyEditionTags.ERP19)
                        {
                            if (cmbEditions.SelectedValue.ToInt32() != (int)ENEditions.StandardEdition) { cmbEditions.Focus(); throw new Exception("CD Key Not Valid For Selected Edition!"); }
                        }
                        if (sEditionTag != CDKeyEditionTags.Basic19 && sEditionTag != CDKeyEditionTags.ERP19)
                        {
                            txtCDKey.Focus();
                            throw new Exception("Invalid CD Key!");
                        }
                        if (iLicenseAvailable <= 0)
                        {
                            txtCDKey.Focus();
                            throw new Exception("Licence Limit Exceeded!");
                        }
                    }
                    else
                    {
                        txtCDKey.Focus();
                        throw new Exception("Invalid CD Key!");
                    }

                    if (txtCDKey.Text.Trim() != "" && txtCustomerName.Text.Trim() != "")
                    {
                        DataTable dtProduct = new DataTable();
                        string CDKeyCheck = "";
                        CDKeyCheck = "SELECT MIN(RegID),CustName FROM regnoregister WHERE CDKey ='" + txtCDKey.Text + "'";
                        dtProduct = regHelper.GetData(CDKeyCheck, conn);
                        if (dtProduct.Rows.Count > 0)
                        {
                            string iCustName = dtProduct.Rows[0]["CustName"].ToString().ToUpper();
                            if(iCustName.Trim()!="")
                            {
                                iCustName = iCustName.Substring(0, 3);
                                if (iCustName != txtCustomerName.Text.Trim().ToUpper().Substring(0,3))
                                {
                                    atMessageBox.Show("This cd key has already used in association with another customer name, Either please enter the same customer name or enter a differnent cd key");
                                    txtCDKey.Focus();
                                    return false;
                                }
                            }
                            return true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionManager.Publish(ex);
                    MessageBox.Show(ex.Message);
                    return false;
                }
                finally
                {
                    conn.Close();
                    this.Cursor = Cursors.Arrow;
                }
            }
            return true;
        }
        private bool ActivateLicense()
        {
            errPrvdr.Clear();
            if (txtCDKeyActivate.Text == "") { errPrvdr.SetError(txtCDKeyActivate, "CD Key must be entered!"); txtCDKeyActivate.Focus(); return false; }
            if (cmbEditions.SelectedValue == null) { errPrvdr.SetError(cmbEditionActivate, "Edition must be selected!"); cmbEditionActivate.Focus(); return false; }
            if (cmbEditions.SelectedIndex == -1) { errPrvdr.SetError(cmbEditionActivate, "Edition must be selected!"); cmbEditionActivate.Focus(); return false; }
            if (txtRegistrationNo.Text.Trim() == "") { errPrvdr.SetError(txtRegistrationNo, "Registration number must be entered!"); txtRegistrationNo.Focus(); return false; }
            if (cmbEditionActivate.SelectedValue.ToInt32() == (int)ENEditions.BasicEdition)
            {
                if (!_cryptography.IsKeyOK(txtRegistrationNo.Text, txtProductID.Text, (int)ENEditionKeys.BasicEdition))
                {
                    MessageBox.Show("Invalid Registration Number!", MessageKeys.MsgApplicationName);
                    return false;
                }
            }
            else if (cmbEditionActivate.SelectedValue.ToInt32() == (int)ENEditions.StandardEdition)
            {
                if (!_cryptography.IsKeyOK(txtRegistrationNo.Text, txtProductID.Text, (int)ENEditionKeys.StandardEdition))
                {
                    MessageBox.Show("Invalid Registration Number!", MessageKeys.MsgApplicationName);
                    return false;
                }
            }
            using (SettingsDbEntities sdb = new SettingsDbEntities())
            {
                Registration reg = new Registration();
                reg.id = sdb.Registrations.Count() + 1;
                reg.CDKey = txtCDKeyActivate.Text;
                reg.FK_Edition = cmbEditionActivate.SelectedValue.ToInt32();
                reg.FK_RegistrationMode = (int)ENRegistrationModes.OneTime;
                reg.ProductID = txtProductIDActivate.Text;
                reg.RegistrationDate = DateTime.Now;
                reg.RegistrationNo = txtRegistrationNo.Text;
                sdb.Registrations.AddObject(reg);
                sdb.SaveChanges();
            }
            if (cmbEditionActivate.SelectedValue.ToInt32() == 1)
            {
                SelectedEdition = ENEditions.BasicEdition;
            }
            else if (cmbEditionActivate.SelectedValue.ToInt32() == 2)
            {
                SelectedEdition = ENEditions.StandardEdition;
            }
            return true;
        }
        private bool OnlineRegistration()
        {
            errPrvdr.Clear();
            if (txtCDKey.Text.Trim() == "") { errPrvdr.SetError(txtCDKey, "CD Key must be entered!"); txtCDKey.Focus(); return false; }
            if (cmbEditions.SelectedValue == null) { errPrvdr.SetError(cmbEditions, "Edition must be selected!"); return false; }
            if (cmbEditions.SelectedIndex == -1) { errPrvdr.SetError(cmbEditions, "Edition must be selected!"); return false; }
            if (!ValidateCDKey()) { return false; }
            if (!ValidateRegistrationForm()) { return false; }
            if (cmbEditions.SelectedValue.ToInt32() == (int)ENEditions.BasicEdition)
            {
                txtRegistrationNo.Text = _cryptography.GenerateRegNo(txtProductID.Text, (int)ENEditionKeys.BasicEdition);
            }
            else if (cmbEditions.SelectedValue.ToInt32() == (int)ENEditions.StandardEdition)
            {
                txtRegistrationNo.Text = _cryptography.GenerateRegNo(txtProductID.Text, (int)ENEditionKeys.StandardEdition);
            }
            using (MySqlConnection conn = new MySqlConnection(RegistrationHelper.sRegistrationConnectionString))
            {
                conn.Open();
                try
                {
                    DataTable dtProduct = new DataTable();
                    string sqlSelect = "";
                    sqlSelect = "select reg.RegNumber,reg.CustName,reg.CustAddress,reg.CDKey,reg.ProductMID,reg.CustID,prd.ProductName,reg.RDate from regnoregister reg ";
                    sqlSelect = sqlSelect + " inner join regproductmaster prd on prd.ProductMID=reg.ProductMID ";
                    sqlSelect = sqlSelect + " where reg.CDKey='" + txtCDKey.Text + "'";
                    sqlSelect += " and reg.CustID='" + txtProductID.Text + "'";
                    dtProduct = regHelper.GetData(sqlSelect, conn);
                    if (dtProduct.Rows.Count > 0)
                    {
                        if (MessageBox.Show("Already registered! Do you want to show certificate?", MessageKeys.MsgApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            dtProduct.TableName = "dtCertificate";
                            ShowCertificateView cert = new ShowCertificateView();
                            cert.ShowCertificate(dtProduct,0);
                            cert.ShowDialog();
                            return true;
                           
                        }
                    }
                    MySqlTransaction _trans = conn.BeginTransaction();
                    try
                    {
                        string sqlInsert = @"INSERT INTO regnoregister(RDate,ProductMID,CDKey,ProductID,CustName,CustAddress,Phone,RegNumber,Business,Email,country,City,Mobile,
                    BussinessType,state,CustID,Warranty,ExtWarranty)";
                        sqlInsert += " VALUES('" + DateTime.Now.ToString("yyyyMMdd") + "','" + iProductMID.ToString() + "','" + txtCDKey.Text + "','" + txtProductID.Text + "','" + txtCustomerName.Text + "','" + txtAddress.Text + "','" + txtTelephone.Text + "','" + txtRegistrationNo.Text + "'";
                        sqlInsert += ",'Atlanta Head Office','" + txtEmail.Text + "','" + CmbCountry.Text + "','" + txtCity.Text + "','" + txtMobile.Text + "'";
                        sqlInsert += ",'" + txtBusinessType.Text + "','" + txtState.Text + "','" + txtProductID.Text + "',6,0)";
                        regHelper.ExecuteNonQuery(sqlInsert, _trans);
                        string sUpdate = "UPDATE regcdkeytoproduct SET License=License-1 WHERE CDKey='" + txtCDKey.Text + "'";
                        regHelper.ExecuteNonQuery(sUpdate, _trans);

                        _trans.Commit();
                    }
                    catch (Exception ex)
                    {
                        _trans.Rollback();
                        throw ex;
                    }

                    dtProduct = regHelper.GetData(sqlSelect, conn);
                    if (dtProduct.Rows.Count > 0)
                    {
                        if (MessageBox.Show("Do you want to show certificate?", MessageKeys.MsgApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            dtProduct.TableName = "dtCertificate";
                            ShowCertificateView cert = new ShowCertificateView();
                            cert.ShowCertificate(dtProduct,0);
                            cert.ShowDialog();
                            
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    ExceptionManager.Publish(ex);
                    MessageBox.Show(ex.Message);
                    txtRegistrationNo.Text = "";
                    
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
            
        }
        private void SelectPanel(ENWizardPanels _selectedpanel)
        {
            if (_selectedpanel == ENWizardPanels.Welcome)
            {
                pnlWelcome.Visible = true;
                pnlOnline.Visible = false;
                pnlFinish.Visible = false;
                pnlActivate.Visible = false;
                btnBack.Enabled = false;
                btnNext.Enabled = true;
                btnFinish.Visible = false;
            }
            else if (_selectedpanel == ENWizardPanels.ActivateLicense)
            {
                pnlWelcome.Visible = false;
                pnlOnline.Visible = false;
                pnlFinish.Visible = false;
                pnlActivate.Visible = true;
                if (radOnline.Checked)
                {
                    btnBack.Enabled = false;
                }
                else
                {
                    btnBack.Enabled = true;
                }
                btnNext.Enabled = true;
                btnFinish.Visible = false;
            }
            else if (_selectedpanel == ENWizardPanels.Finish)
            {
                pnlWelcome.Visible = false;
                pnlOnline.Visible = false;
                pnlFinish.Visible = true;
                pnlActivate.Visible = false;
                btnBack.Enabled = false;
                btnNext.Enabled = false;
                btnFinish.Visible = true;

            }
            else if (_selectedpanel == ENWizardPanels.Online)
            {
                pnlWelcome.Visible = false;
                pnlOnline.Visible = true;
                pnlFinish.Visible = false;
                pnlActivate.Visible = false;
                btnBack.Enabled = true;
                btnNext.Enabled = true;
                btnFinish.Visible = false;
            }
            CurrentPanel = _selectedpanel;
        }
        #endregion

        #region Form Events
        private void OneTimeRegistrationWizard_Load(object sender, EventArgs e)
        {
            txtProductID.Text = regHelper.GetUUID();
            txtProductIDActivate.Text = txtProductID.Text;
            pnlWelcome.Location = pnlFinish.Location = pnlActivate.Location = pnlOnline.Location;
            pnlWelcome.Size = pnlFinish.Size = pnlActivate.Size = pnlOnline.Size;
            PopulateEditions();
            pnlWelcome.Visible = true;
            btnBack.Enabled = false;
            btnFinish.Visible = false;
            CurrentPanel = ENWizardPanels.Welcome;
        }
        private void stepWizardControl1_Validating(object sender, CancelEventArgs e)
        {

        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            if (CurrentPanel == ENWizardPanels.Welcome)
            {
                if (radOnline.Checked)
                {
                    this.Cursor = Cursors.WaitCursor;
                    PopulateCountry();
                    this.Cursor = Cursors.Arrow;
                    SelectPanel(ENWizardPanels.Online);
                    txtCDKey.Focus();
                }
                else
                {
                    SelectPanel(ENWizardPanels.ActivateLicense);
                    txtCDKeyActivate.Focus();
                }
            }
            else if (CurrentPanel == ENWizardPanels.Online)
            {
                if (OnlineRegistration())
                {
                    SelectPanel(ENWizardPanels.ActivateLicense);
                    txtRegistrationNo.Focus();
                }
            }
            else if (CurrentPanel == ENWizardPanels.ActivateLicense)
            {
                if (ActivateLicense())
                {
                    SelectPanel(ENWizardPanels.Finish);
                    MessageBox.Show(MessageKeys.MsgApplicationName+" 19 registration successful.", MessageKeys.MsgApplicationName);

                }
            }
            else if (CurrentPanel == ENWizardPanels.Finish)
            {
                this.DialogResult = DialogResult.OK;
            }

        }
        private void btnBack_Click(object sender, EventArgs e)
        {
           
            if (CurrentPanel == ENWizardPanels.Online)
            {
                SelectPanel(ENWizardPanels.Welcome);
            }
            else if (CurrentPanel == ENWizardPanels.ActivateLicense)
            {
                if (radOnline.Checked)
                {
                    SelectPanel(ENWizardPanels.Online);
                }
                else
                {
                    SelectPanel(ENWizardPanels.Welcome);
                }
            }
            
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
        private void txtCDKey_TextChanged(object sender, EventArgs e)
        {
            txtCDKeyActivate.Text = txtCDKey.Text;
        }
        private void btnFinish_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            Process.Start("http://www.atlanta-it.com/erpregisternew.php?A=" + txtCDKeyActivate.Text + "&B=" + txtProductIDActivate.Text + "&C=1");
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }

        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        #endregion

        private void atLabel7_Click(object sender, EventArgs e)
        {

        }
    }
}
// Pending Works
// CD Key Generation Program
// Change in Registration web site
// Add Images
// Subscription Part
