﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.UI
{
   public class RegtistrationClass
    {
        int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        string _CDKey;

        public string CDKey
        {
            get { return _CDKey; }
            set { _CDKey = value; }
        }
        string _Edition;

        public string Edition
        {
            get { return _Edition; }
            set { _Edition = value; }
        }

        string _ProductID;

        public string ProductID
        {
            get { return _ProductID; }
            set { _ProductID = value; }
        }
        string _RegistrationMode;

        public string RegistrationMode
        {
            get { return _RegistrationMode; }
            set { _RegistrationMode = value; }
        }
        string _RegistrationNo;

        public string RegistrationNo
        {
            get { return _RegistrationNo; }
            set { _RegistrationNo = value; }
        }
        DateTime? _RegistrationDate;

        public DateTime? RegistrationDate
        {
            get { return _RegistrationDate; }
            set { _RegistrationDate = value; }
        }
        int? _SubscriptionDays;

        public int? SubscriptionDays
        {
            get { return _SubscriptionDays; }
            set { _SubscriptionDays = value; }
        }
        DateTime? _SubscriptionEndDate;

        public DateTime? SubscriptionEndDate
        {
            get { return _SubscriptionEndDate; }
            set { _SubscriptionEndDate = value; }
        }
    }
}
