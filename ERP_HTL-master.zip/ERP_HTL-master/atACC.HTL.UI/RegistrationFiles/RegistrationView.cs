﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.UI.UIClasses;
using atACC.Common;
using System.Globalization;
using LocalORM;
namespace atACC.HTL.UI
{
    public partial class RegistrationView : FormBase
    {
        #region Constructor
        public RegistrationView()
        {
            InitializeComponent();
        }
        #endregion

        #region Public Properties
        public ENRegistrationModes SelectedRegistrationMode { get; set; }
        public ENEditions SelectedEdition { get; set; }
        #endregion

        #region Form Events
        private void btnOneTime_Click(object sender, EventArgs e)
        {
            try
            {
                OneTimeRegistrationWizard frm = new OneTimeRegistrationWizard();
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    SelectedRegistrationMode = ENRegistrationModes.OneTime;
                    SelectedEdition = frm.SelectedEdition;
                    this.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnRegisterLater_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedRegistrationMode = ENRegistrationModes.Demo;
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnSubscription_Click(object sender, EventArgs e)
        {
            try
            {
                SubscriptionView frm = new SubscriptionView();
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    SelectedRegistrationMode = ENRegistrationModes.Subscription;
                    this.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void RegistrationView_Load(object sender, EventArgs e)
        {
            try
            {

                using (SettingsDbEntities sdb = new SettingsDbEntities())
                {
                    if (sdb.Registrations.Where(x => x.FK_RegistrationMode == (int)ENRegistrationModes.Subscription).Any())
                    {
                        btnSubscription.Text = "Renew Subscription";
                        btnSubscription.Width = 190;
                        btnSubscription.Location = new Point(195, 7);
                    }
                    else
                    {
                        btnSubscription.Text = "Subscription";
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void RegistrationView_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {

                if (e.KeyCode == Keys.Escape)
                {
                    this.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void lblClose_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void lblClose_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                lblClose.ForeColor = Color.Red;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void lblClose_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                lblClose.ForeColor = Color.DarkGray;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
