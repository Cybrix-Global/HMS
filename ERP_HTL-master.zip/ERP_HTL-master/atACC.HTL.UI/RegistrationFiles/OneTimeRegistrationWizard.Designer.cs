﻿namespace atACC.HTL.UI
{
    partial class OneTimeRegistrationWizard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OneTimeRegistrationWizard));
            this.errPrvdr = new System.Windows.Forms.ErrorProvider(this.components);
            this.pnlSide1 = new System.Windows.Forms.Panel();
            this.pnlWelcome = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblContent1 = new System.Windows.Forms.Label();
            this.radOffline = new System.Windows.Forms.RadioButton();
            this.radOnline = new System.Windows.Forms.RadioButton();
            this.lblcap1 = new System.Windows.Forms.Label();
            this.pnlOnline = new System.Windows.Forms.Panel();
            this.pnlCustomerDetails = new atACCFramework.UserControls.atGroupBox();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.txtCustomerName = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.cmbEditions = new atACCFramework.UserControls.ComboBoxExt();
            this.txtBusinessType = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel8 = new atACCFramework.UserControls.atLabel();
            this.txtProductID = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel2 = new atACCFramework.UserControls.atLabel();
            this.atLabel6 = new atACCFramework.UserControls.atLabel();
            this.txtAddress = new atACCFramework.UserControls.TextBoxExt();
            this.lblCode = new atACCFramework.UserControls.atLabel();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.txtCDKey = new atACCFramework.UserControls.TextBoxExt();
            this.txtCity = new atACCFramework.UserControls.TextBoxExt();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel4 = new atACCFramework.UserControls.atLabel();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.txtState = new atACCFramework.UserControls.TextBoxExt();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel5 = new atACCFramework.UserControls.atLabel();
            this.txtEmail = new atACCFramework.UserControls.TextBoxExt();
            this.CmbCountry = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEmail = new atACCFramework.UserControls.atLabel();
            this.lblCountry = new atACCFramework.UserControls.atLabel();
            this.lblMobileNumber = new atACCFramework.UserControls.atLabel();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.lblMandatory6 = new System.Windows.Forms.Label();
            this.lblMandatory7 = new System.Windows.Forms.Label();
            this.lblMandatory8 = new System.Windows.Forms.Label();
            this.lblMandatory9 = new System.Windows.Forms.Label();
            this.lblMandatory10 = new System.Windows.Forms.Label();
            this.lblMandatory11 = new System.Windows.Forms.Label();
            this.lblMandatory12 = new System.Windows.Forms.Label();
            this.pnlActivate = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblforRegistration = new atACCFramework.UserControls.atLabel();
            this.atLabel7 = new atACCFramework.UserControls.atLabel();
            this.txtRegistrationNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblVisit = new atACCFramework.UserControls.atLabel();
            this.lblWebLink = new System.Windows.Forms.LinkLabel();
            this.atLabel9 = new atACCFramework.UserControls.atLabel();
            this.atLabel11 = new atACCFramework.UserControls.atLabel();
            this.txtProductIDActivate = new atACCFramework.UserControls.TextBoxExt();
            this.txtCDKeyActivate = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel10 = new atACCFramework.UserControls.atLabel();
            this.cmbEditionActivate = new atACCFramework.UserControls.ComboBoxExt();
            this.pnlFinish = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.pnlFooter = new System.Windows.Forms.Panel();
            this.btnBack = new atACCFramework.UserControls.atButton();
            this.btnCancel = new atACCFramework.UserControls.atButton();
            this.btnFinish = new atACCFramework.UserControls.atButton();
            this.btnNext = new atACCFramework.UserControls.atButton();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errPrvdr)).BeginInit();
            this.pnlWelcome.SuspendLayout();
            this.pnlOnline.SuspendLayout();
            this.pnlCustomerDetails.SuspendLayout();
            this.pnlActivate.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlFinish.SuspendLayout();
            this.pnlFooter.SuspendLayout();
            this.SuspendLayout();
            // 
            // errPrvdr
            // 
            this.errPrvdr.ContainerControl = this;
            // 
            // pnlSide1
            // 
            this.pnlSide1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlSide1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSide1.BackgroundImage")));
            this.pnlSide1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlSide1.Location = new System.Drawing.Point(3, 40);
            this.pnlSide1.Name = "pnlSide1";
            this.pnlSide1.Size = new System.Drawing.Size(147, 368);
            this.pnlSide1.TabIndex = 1;
            // 
            // pnlWelcome
            // 
            this.pnlWelcome.Controls.Add(this.label4);
            this.pnlWelcome.Controls.Add(this.lblContent1);
            this.pnlWelcome.Controls.Add(this.radOffline);
            this.pnlWelcome.Controls.Add(this.radOnline);
            this.pnlWelcome.Controls.Add(this.lblcap1);
            this.pnlWelcome.Location = new System.Drawing.Point(152, 40);
            this.pnlWelcome.Name = "pnlWelcome";
            this.pnlWelcome.Size = new System.Drawing.Size(460, 367);
            this.pnlWelcome.TabIndex = 0;
            this.pnlWelcome.Visible = false;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(426, 59);
            this.label4.TabIndex = 4;
            this.label4.Text = "Click \'Next\' to continue with the demo unlock and registration.  Click \'Cancel\' t" +
                "o quit Registration Wizard.             ";
            // 
            // lblContent1
            // 
            this.lblContent1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContent1.Location = new System.Drawing.Point(15, 83);
            this.lblContent1.Name = "lblContent1";
            this.lblContent1.Size = new System.Drawing.Size(428, 39);
            this.lblContent1.TabIndex = 3;
            this.lblContent1.Text = "This wizard will unlock the demo version of atACC ERP 19.0 and register the softw" +
                "are for full use. ";
            // 
            // radOffline
            // 
            this.radOffline.AutoSize = true;
            this.radOffline.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radOffline.Location = new System.Drawing.Point(89, 205);
            this.radOffline.Name = "radOffline";
            this.radOffline.Size = new System.Drawing.Size(66, 22);
            this.radOffline.TabIndex = 1;
            this.radOffline.Text = "Offline";
            this.radOffline.UseVisualStyleBackColor = true;
            // 
            // radOnline
            // 
            this.radOnline.AutoSize = true;
            this.radOnline.Checked = true;
            this.radOnline.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radOnline.Location = new System.Drawing.Point(18, 205);
            this.radOnline.Name = "radOnline";
            this.radOnline.Size = new System.Drawing.Size(65, 22);
            this.radOnline.TabIndex = 0;
            this.radOnline.TabStop = true;
            this.radOnline.Text = "Online";
            this.radOnline.UseVisualStyleBackColor = true;
            // 
            // lblcap1
            // 
            this.lblcap1.Font = new System.Drawing.Font("Open Sans", 13F, System.Drawing.FontStyle.Bold);
            this.lblcap1.Location = new System.Drawing.Point(12, 12);
            this.lblcap1.Name = "lblcap1";
            this.lblcap1.Size = new System.Drawing.Size(432, 52);
            this.lblcap1.TabIndex = 0;
            this.lblcap1.Text = "Welcome to atACC ERP 19.0 Registration Wizard.";
            this.lblcap1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pnlOnline
            // 
            this.pnlOnline.Controls.Add(this.pnlCustomerDetails);
            this.pnlOnline.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlOnline.Location = new System.Drawing.Point(152, 40);
            this.pnlOnline.Name = "pnlOnline";
            this.pnlOnline.Size = new System.Drawing.Size(460, 367);
            this.pnlOnline.TabIndex = 0;
            this.pnlOnline.Visible = false;
            // 
            // pnlCustomerDetails
            // 
            this.pnlCustomerDetails.BackColor = System.Drawing.Color.Transparent;
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory2);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory1);
            this.pnlCustomerDetails.Controls.Add(this.txtCustomerName);
            this.pnlCustomerDetails.Controls.Add(this.atLabel1);
            this.pnlCustomerDetails.Controls.Add(this.cmbEditions);
            this.pnlCustomerDetails.Controls.Add(this.txtBusinessType);
            this.pnlCustomerDetails.Controls.Add(this.atLabel8);
            this.pnlCustomerDetails.Controls.Add(this.txtProductID);
            this.pnlCustomerDetails.Controls.Add(this.atLabel2);
            this.pnlCustomerDetails.Controls.Add(this.atLabel6);
            this.pnlCustomerDetails.Controls.Add(this.txtAddress);
            this.pnlCustomerDetails.Controls.Add(this.lblCode);
            this.pnlCustomerDetails.Controls.Add(this.atLabel3);
            this.pnlCustomerDetails.Controls.Add(this.txtCDKey);
            this.pnlCustomerDetails.Controls.Add(this.txtCity);
            this.pnlCustomerDetails.Controls.Add(this.txtMobile);
            this.pnlCustomerDetails.Controls.Add(this.atLabel4);
            this.pnlCustomerDetails.Controls.Add(this.lblTelephone);
            this.pnlCustomerDetails.Controls.Add(this.txtState);
            this.pnlCustomerDetails.Controls.Add(this.txtTelephone);
            this.pnlCustomerDetails.Controls.Add(this.atLabel5);
            this.pnlCustomerDetails.Controls.Add(this.txtEmail);
            this.pnlCustomerDetails.Controls.Add(this.CmbCountry);
            this.pnlCustomerDetails.Controls.Add(this.lblEmail);
            this.pnlCustomerDetails.Controls.Add(this.lblCountry);
            this.pnlCustomerDetails.Controls.Add(this.lblMobileNumber);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory3);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory4);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory5);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory6);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory7);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory8);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory9);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory10);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory11);
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory12);
            this.pnlCustomerDetails.Location = new System.Drawing.Point(8, 2);
            this.pnlCustomerDetails.Name = "pnlCustomerDetails";
            this.pnlCustomerDetails.Size = new System.Drawing.Size(445, 359);
            this.pnlCustomerDetails.TabIndex = 0;
            this.pnlCustomerDetails.TabStop = false;
            this.pnlCustomerDetails.Text = "Online Registration";
            // 
            // lblMandatory2
            // 
            this.lblMandatory2.AutoSize = true;
            this.lblMandatory2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory2.Location = new System.Drawing.Point(48, 59);
            this.lblMandatory2.Name = "lblMandatory2";
            this.lblMandatory2.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory2.TabIndex = 46;
            this.lblMandatory2.Text = "*";
            // 
            // lblMandatory1
            // 
            this.lblMandatory1.AutoSize = true;
            this.lblMandatory1.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory1.Location = new System.Drawing.Point(50, 33);
            this.lblMandatory1.Name = "lblMandatory1";
            this.lblMandatory1.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory1.TabIndex = 45;
            this.lblMandatory1.Text = "*";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerName.BackColor = System.Drawing.SystemColors.Window;
            this.txtCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCustomerName.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Format = null;
            this.txtCustomerName.isAllowNegative = false;
            this.txtCustomerName.isAllowSpecialChar = false;
            this.txtCustomerName.isNumeric = false;
            this.txtCustomerName.isTouchable = false;
            this.txtCustomerName.Location = new System.Drawing.Point(125, 89);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(300, 18);
            this.txtCustomerName.TabIndex = 2;
            this.txtCustomerName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCustomerName.WaterMark = null;
            // 
            // atLabel1
            // 
            this.atLabel1.AutoSize = true;
            this.atLabel1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel1.Location = new System.Drawing.Point(7, 87);
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            this.atLabel1.Size = new System.Drawing.Size(112, 18);
            this.atLabel1.TabIndex = 16;
            this.atLabel1.Tag = "";
            this.atLabel1.Text = "Customer Name :";
            this.atLabel1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbEditions
            // 
            this.cmbEditions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbEditions.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEditions.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEditions.DropDownHeight = 300;
            this.cmbEditions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEditions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbEditions.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbEditions.FormattingEnabled = true;
            this.cmbEditions.IntegralHeight = false;
            this.cmbEditions.Location = new System.Drawing.Point(125, 56);
            this.cmbEditions.Name = "cmbEditions";
            this.cmbEditions.Size = new System.Drawing.Size(300, 26);
            this.cmbEditions.TabIndex = 1;
            // 
            // txtBusinessType
            // 
            this.txtBusinessType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBusinessType.BackColor = System.Drawing.SystemColors.Window;
            this.txtBusinessType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBusinessType.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBusinessType.Format = null;
            this.txtBusinessType.isAllowNegative = false;
            this.txtBusinessType.isAllowSpecialChar = false;
            this.txtBusinessType.isNumeric = false;
            this.txtBusinessType.isTouchable = false;
            this.txtBusinessType.Location = new System.Drawing.Point(125, 115);
            this.txtBusinessType.Name = "txtBusinessType";
            this.txtBusinessType.Size = new System.Drawing.Size(300, 18);
            this.txtBusinessType.TabIndex = 3;
            this.txtBusinessType.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtBusinessType.WaterMark = null;
            // 
            // atLabel8
            // 
            this.atLabel8.AutoSize = true;
            this.atLabel8.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel8.Location = new System.Drawing.Point(63, 60);
            this.atLabel8.Name = "atLabel8";
            this.atLabel8.RequiredField = false;
            this.atLabel8.Size = new System.Drawing.Size(56, 18);
            this.atLabel8.TabIndex = 44;
            this.atLabel8.Text = "Edition :";
            this.atLabel8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtProductID
            // 
            this.txtProductID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProductID.BackColor = System.Drawing.SystemColors.Window;
            this.txtProductID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProductID.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductID.Format = null;
            this.txtProductID.isAllowNegative = false;
            this.txtProductID.isAllowSpecialChar = false;
            this.txtProductID.isNumeric = false;
            this.txtProductID.isTouchable = false;
            this.txtProductID.Location = new System.Drawing.Point(125, 331);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.ReadOnly = true;
            this.txtProductID.Size = new System.Drawing.Size(300, 18);
            this.txtProductID.TabIndex = 11;
            this.txtProductID.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtProductID.WaterMark = null;
            // 
            // atLabel2
            // 
            this.atLabel2.AutoSize = true;
            this.atLabel2.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel2.Location = new System.Drawing.Point(21, 114);
            this.atLabel2.Name = "atLabel2";
            this.atLabel2.RequiredField = false;
            this.atLabel2.Size = new System.Drawing.Size(98, 18);
            this.atLabel2.TabIndex = 18;
            this.atLabel2.Text = "Business Type :";
            this.atLabel2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // atLabel6
            // 
            this.atLabel6.AutoSize = true;
            this.atLabel6.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel6.Location = new System.Drawing.Point(41, 330);
            this.atLabel6.Name = "atLabel6";
            this.atLabel6.RequiredField = false;
            this.atLabel6.Size = new System.Drawing.Size(78, 18);
            this.atLabel6.TabIndex = 36;
            this.atLabel6.Text = "Product ID :";
            this.atLabel6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtAddress
            // 
            this.txtAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddress.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddress.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Format = null;
            this.txtAddress.isAllowNegative = false;
            this.txtAddress.isAllowSpecialChar = false;
            this.txtAddress.isNumeric = false;
            this.txtAddress.isTouchable = false;
            this.txtAddress.Location = new System.Drawing.Point(125, 141);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(300, 18);
            this.txtAddress.TabIndex = 4;
            this.txtAddress.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAddress.WaterMark = null;
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCode.Location = new System.Drawing.Point(63, 33);
            this.lblCode.Name = "lblCode";
            this.lblCode.RequiredField = false;
            this.lblCode.Size = new System.Drawing.Size(56, 18);
            this.lblCode.TabIndex = 14;
            this.lblCode.Text = "CD Key :";
            this.lblCode.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // atLabel3
            // 
            this.atLabel3.AutoSize = true;
            this.atLabel3.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel3.Location = new System.Drawing.Point(57, 141);
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            this.atLabel3.Size = new System.Drawing.Size(62, 18);
            this.atLabel3.TabIndex = 20;
            this.atLabel3.Text = "Address :";
            this.atLabel3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtCDKey
            // 
            this.txtCDKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCDKey.BackColor = System.Drawing.SystemColors.Window;
            this.txtCDKey.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCDKey.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCDKey.Format = null;
            this.txtCDKey.isAllowNegative = false;
            this.txtCDKey.isAllowSpecialChar = false;
            this.txtCDKey.isNumeric = false;
            this.txtCDKey.isTouchable = false;
            this.txtCDKey.Location = new System.Drawing.Point(125, 33);
            this.txtCDKey.Name = "txtCDKey";
            this.txtCDKey.Size = new System.Drawing.Size(300, 18);
            this.txtCDKey.TabIndex = 0;
            this.txtCDKey.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCDKey.WaterMark = null;
            this.txtCDKey.TextChanged += new System.EventHandler(this.txtCDKey_TextChanged);
            // 
            // txtCity
            // 
            this.txtCity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCity.BackColor = System.Drawing.SystemColors.Window;
            this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCity.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Format = null;
            this.txtCity.isAllowNegative = false;
            this.txtCity.isAllowSpecialChar = false;
            this.txtCity.isNumeric = false;
            this.txtCity.isTouchable = false;
            this.txtCity.Location = new System.Drawing.Point(125, 167);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(300, 18);
            this.txtCity.TabIndex = 5;
            this.txtCity.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCity.WaterMark = null;
            // 
            // txtMobile
            // 
            this.txtMobile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMobile.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobile.Format = null;
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumeric = true;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Location = new System.Drawing.Point(125, 279);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(300, 18);
            this.txtMobile.TabIndex = 9;
            this.txtMobile.Text = "0";
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtMobile.WaterMark = null;
            // 
            // atLabel4
            // 
            this.atLabel4.AutoSize = true;
            this.atLabel4.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel4.Location = new System.Drawing.Point(82, 168);
            this.atLabel4.Name = "atLabel4";
            this.atLabel4.RequiredField = false;
            this.atLabel4.Size = new System.Drawing.Size(37, 18);
            this.atLabel4.TabIndex = 22;
            this.atLabel4.Text = "City :";
            this.atLabel4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTelephone
            // 
            this.lblTelephone.AutoSize = true;
            this.lblTelephone.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelephone.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTelephone.Location = new System.Drawing.Point(42, 249);
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            this.lblTelephone.Size = new System.Drawing.Size(77, 18);
            this.lblTelephone.TabIndex = 32;
            this.lblTelephone.Text = "Telephone :";
            this.lblTelephone.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtState
            // 
            this.txtState.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtState.BackColor = System.Drawing.SystemColors.Window;
            this.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtState.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtState.Format = null;
            this.txtState.isAllowNegative = false;
            this.txtState.isAllowSpecialChar = false;
            this.txtState.isNumeric = false;
            this.txtState.isTouchable = false;
            this.txtState.Location = new System.Drawing.Point(125, 193);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(300, 18);
            this.txtState.TabIndex = 6;
            this.txtState.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtState.WaterMark = null;
            // 
            // txtTelephone
            // 
            this.txtTelephone.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelephone.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelephone.Format = null;
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumeric = true;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Location = new System.Drawing.Point(125, 253);
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Size = new System.Drawing.Size(300, 18);
            this.txtTelephone.TabIndex = 8;
            this.txtTelephone.Text = "0";
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtTelephone.WaterMark = null;
            // 
            // atLabel5
            // 
            this.atLabel5.AutoSize = true;
            this.atLabel5.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel5.Location = new System.Drawing.Point(74, 195);
            this.atLabel5.Name = "atLabel5";
            this.atLabel5.RequiredField = false;
            this.atLabel5.Size = new System.Drawing.Size(45, 18);
            this.atLabel5.TabIndex = 24;
            this.atLabel5.Text = "State :";
            this.atLabel5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtEmail
            // 
            this.txtEmail.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmail.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Format = null;
            this.txtEmail.isAllowNegative = false;
            this.txtEmail.isAllowSpecialChar = false;
            this.txtEmail.isNumeric = false;
            this.txtEmail.isTouchable = false;
            this.txtEmail.Location = new System.Drawing.Point(125, 305);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(300, 18);
            this.txtEmail.TabIndex = 10;
            this.txtEmail.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtEmail.WaterMark = null;
            // 
            // CmbCountry
            // 
            this.CmbCountry.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.CmbCountry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CmbCountry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCountry.DropDownHeight = 300;
            this.CmbCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCountry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CmbCountry.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.CmbCountry.FormattingEnabled = true;
            this.CmbCountry.IntegralHeight = false;
            this.CmbCountry.Location = new System.Drawing.Point(125, 220);
            this.CmbCountry.Name = "CmbCountry";
            this.CmbCountry.Size = new System.Drawing.Size(300, 26);
            this.CmbCountry.TabIndex = 7;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmail.Location = new System.Drawing.Point(73, 303);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.RequiredField = false;
            this.lblEmail.Size = new System.Drawing.Size(46, 18);
            this.lblEmail.TabIndex = 34;
            this.lblEmail.Text = "Email :";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCountry.Location = new System.Drawing.Point(56, 222);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.RequiredField = false;
            this.lblCountry.Size = new System.Drawing.Size(63, 18);
            this.lblCountry.TabIndex = 28;
            this.lblCountry.Text = "Country :";
            this.lblCountry.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMobileNumber
            // 
            this.lblMobileNumber.AutoSize = true;
            this.lblMobileNumber.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobileNumber.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMobileNumber.Location = new System.Drawing.Point(64, 276);
            this.lblMobileNumber.Name = "lblMobileNumber";
            this.lblMobileNumber.RequiredField = false;
            this.lblMobileNumber.Size = new System.Drawing.Size(55, 18);
            this.lblMobileNumber.TabIndex = 33;
            this.lblMobileNumber.Text = "Mobile :";
            this.lblMobileNumber.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMandatory3
            // 
            this.lblMandatory3.AutoSize = true;
            this.lblMandatory3.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory3.Location = new System.Drawing.Point(-2, 86);
            this.lblMandatory3.Name = "lblMandatory3";
            this.lblMandatory3.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory3.TabIndex = 47;
            this.lblMandatory3.Text = "*";
            // 
            // lblMandatory4
            // 
            this.lblMandatory4.AutoSize = true;
            this.lblMandatory4.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory4.Location = new System.Drawing.Point(11, 113);
            this.lblMandatory4.Name = "lblMandatory4";
            this.lblMandatory4.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory4.TabIndex = 48;
            this.lblMandatory4.Text = "*";
            // 
            // lblMandatory5
            // 
            this.lblMandatory5.AutoSize = true;
            this.lblMandatory5.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory5.Location = new System.Drawing.Point(48, 139);
            this.lblMandatory5.Name = "lblMandatory5";
            this.lblMandatory5.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory5.TabIndex = 49;
            this.lblMandatory5.Text = "*";
            // 
            // lblMandatory6
            // 
            this.lblMandatory6.AutoSize = true;
            this.lblMandatory6.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory6.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory6.Location = new System.Drawing.Point(73, 167);
            this.lblMandatory6.Name = "lblMandatory6";
            this.lblMandatory6.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory6.TabIndex = 50;
            this.lblMandatory6.Text = "*";
            // 
            // lblMandatory7
            // 
            this.lblMandatory7.AutoSize = true;
            this.lblMandatory7.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory7.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory7.Location = new System.Drawing.Point(64, 193);
            this.lblMandatory7.Name = "lblMandatory7";
            this.lblMandatory7.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory7.TabIndex = 51;
            this.lblMandatory7.Text = "*";
            // 
            // lblMandatory8
            // 
            this.lblMandatory8.AutoSize = true;
            this.lblMandatory8.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory8.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory8.Location = new System.Drawing.Point(47, 221);
            this.lblMandatory8.Name = "lblMandatory8";
            this.lblMandatory8.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory8.TabIndex = 52;
            this.lblMandatory8.Text = "*";
            // 
            // lblMandatory9
            // 
            this.lblMandatory9.AutoSize = true;
            this.lblMandatory9.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory9.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory9.Location = new System.Drawing.Point(32, 247);
            this.lblMandatory9.Name = "lblMandatory9";
            this.lblMandatory9.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory9.TabIndex = 53;
            this.lblMandatory9.Text = "*";
            // 
            // lblMandatory10
            // 
            this.lblMandatory10.AutoSize = true;
            this.lblMandatory10.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory10.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory10.Location = new System.Drawing.Point(55, 274);
            this.lblMandatory10.Name = "lblMandatory10";
            this.lblMandatory10.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory10.TabIndex = 54;
            this.lblMandatory10.Text = "*";
            // 
            // lblMandatory11
            // 
            this.lblMandatory11.AutoSize = true;
            this.lblMandatory11.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory11.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory11.Location = new System.Drawing.Point(64, 301);
            this.lblMandatory11.Name = "lblMandatory11";
            this.lblMandatory11.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory11.TabIndex = 55;
            this.lblMandatory11.Text = "*";
            // 
            // lblMandatory12
            // 
            this.lblMandatory12.AutoSize = true;
            this.lblMandatory12.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory12.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory12.Location = new System.Drawing.Point(32, 329);
            this.lblMandatory12.Name = "lblMandatory12";
            this.lblMandatory12.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory12.TabIndex = 56;
            this.lblMandatory12.Text = "*";
            // 
            // pnlActivate
            // 
            this.pnlActivate.Controls.Add(this.panel3);
            this.pnlActivate.Location = new System.Drawing.Point(152, 40);
            this.pnlActivate.Name = "pnlActivate";
            this.pnlActivate.Size = new System.Drawing.Size(460, 367);
            this.pnlActivate.TabIndex = 2;
            this.pnlActivate.Visible = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lblforRegistration);
            this.panel3.Controls.Add(this.atLabel7);
            this.panel3.Controls.Add(this.txtRegistrationNo);
            this.panel3.Controls.Add(this.lblVisit);
            this.panel3.Controls.Add(this.lblWebLink);
            this.panel3.Controls.Add(this.atLabel9);
            this.panel3.Controls.Add(this.atLabel11);
            this.panel3.Controls.Add(this.txtProductIDActivate);
            this.panel3.Controls.Add(this.txtCDKeyActivate);
            this.panel3.Controls.Add(this.atLabel10);
            this.panel3.Controls.Add(this.cmbEditionActivate);
            this.panel3.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(10, 11);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(443, 350);
            this.panel3.TabIndex = 0;
            // 
            // lblforRegistration
            // 
            this.lblforRegistration.AutoSize = true;
            this.lblforRegistration.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblforRegistration.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblforRegistration.Location = new System.Drawing.Point(254, 205);
            this.lblforRegistration.Name = "lblforRegistration";
            this.lblforRegistration.RequiredField = false;
            this.lblforRegistration.Size = new System.Drawing.Size(94, 17);
            this.lblforRegistration.TabIndex = 54;
            this.lblforRegistration.Text = "for Registration";
            this.lblforRegistration.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // atLabel7
            // 
            this.atLabel7.AutoSize = true;
            this.atLabel7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel7.Location = new System.Drawing.Point(37, 255);
            this.atLabel7.Name = "atLabel7";
            this.atLabel7.RequiredField = false;
            this.atLabel7.Size = new System.Drawing.Size(133, 18);
            this.atLabel7.TabIndex = 53;
            this.atLabel7.Text = "Registration Number";
            this.atLabel7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.atLabel7.Click += new System.EventHandler(this.atLabel7_Click);
            // 
            // txtRegistrationNo
            // 
            this.txtRegistrationNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtRegistrationNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegistrationNo.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegistrationNo.Format = null;
            this.txtRegistrationNo.isAllowNegative = false;
            this.txtRegistrationNo.isAllowSpecialChar = false;
            this.txtRegistrationNo.isNumeric = false;
            this.txtRegistrationNo.isTouchable = false;
            this.txtRegistrationNo.Location = new System.Drawing.Point(37, 285);
            this.txtRegistrationNo.Name = "txtRegistrationNo";
            this.txtRegistrationNo.Size = new System.Drawing.Size(340, 18);
            this.txtRegistrationNo.TabIndex = 3;
            this.txtRegistrationNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRegistrationNo.WaterMark = null;
            // 
            // lblVisit
            // 
            this.lblVisit.AutoSize = true;
            this.lblVisit.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVisit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblVisit.Location = new System.Drawing.Point(98, 205);
            this.lblVisit.Name = "lblVisit";
            this.lblVisit.RequiredField = false;
            this.lblVisit.Size = new System.Drawing.Size(31, 17);
            this.lblVisit.TabIndex = 52;
            this.lblVisit.Text = "Visit\r\n";
            this.lblVisit.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblWebLink
            // 
            this.lblWebLink.AutoSize = true;
            this.lblWebLink.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWebLink.Location = new System.Drawing.Point(130, 205);
            this.lblWebLink.Name = "lblWebLink";
            this.lblWebLink.Size = new System.Drawing.Size(125, 17);
            this.lblWebLink.TabIndex = 51;
            this.lblWebLink.TabStop = true;
            this.lblWebLink.Text = "www.atlanta-it.com";
            this.lblWebLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // atLabel9
            // 
            this.atLabel9.AutoSize = true;
            this.atLabel9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel9.Location = new System.Drawing.Point(34, 132);
            this.atLabel9.Name = "atLabel9";
            this.atLabel9.RequiredField = false;
            this.atLabel9.Size = new System.Drawing.Size(72, 18);
            this.atLabel9.TabIndex = 44;
            this.atLabel9.Text = "Product ID";
            this.atLabel9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // atLabel11
            // 
            this.atLabel11.AutoSize = true;
            this.atLabel11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel11.Location = new System.Drawing.Point(34, 12);
            this.atLabel11.Name = "atLabel11";
            this.atLabel11.RequiredField = false;
            this.atLabel11.Size = new System.Drawing.Size(108, 18);
            this.atLabel11.TabIndex = 48;
            this.atLabel11.Text = "Enter the CD Key";
            this.atLabel11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtProductIDActivate
            // 
            this.txtProductIDActivate.BackColor = System.Drawing.SystemColors.Window;
            this.txtProductIDActivate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProductIDActivate.Format = null;
            this.txtProductIDActivate.isAllowNegative = false;
            this.txtProductIDActivate.isAllowSpecialChar = false;
            this.txtProductIDActivate.isNumeric = false;
            this.txtProductIDActivate.isTouchable = false;
            this.txtProductIDActivate.Location = new System.Drawing.Point(37, 170);
            this.txtProductIDActivate.Name = "txtProductIDActivate";
            this.txtProductIDActivate.ReadOnly = true;
            this.txtProductIDActivate.Size = new System.Drawing.Size(340, 18);
            this.txtProductIDActivate.TabIndex = 2;
            this.txtProductIDActivate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtProductIDActivate.WaterMark = null;
            // 
            // txtCDKeyActivate
            // 
            this.txtCDKeyActivate.BackColor = System.Drawing.SystemColors.Window;
            this.txtCDKeyActivate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCDKeyActivate.Format = null;
            this.txtCDKeyActivate.isAllowNegative = false;
            this.txtCDKeyActivate.isAllowSpecialChar = false;
            this.txtCDKeyActivate.isNumeric = false;
            this.txtCDKeyActivate.isTouchable = false;
            this.txtCDKeyActivate.Location = new System.Drawing.Point(37, 37);
            this.txtCDKeyActivate.Name = "txtCDKeyActivate";
            this.txtCDKeyActivate.Size = new System.Drawing.Size(340, 18);
            this.txtCDKeyActivate.TabIndex = 0;
            this.txtCDKeyActivate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCDKeyActivate.WaterMark = null;
            // 
            // atLabel10
            // 
            this.atLabel10.AutoSize = true;
            this.atLabel10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel10.Location = new System.Drawing.Point(34, 69);
            this.atLabel10.Name = "atLabel10";
            this.atLabel10.RequiredField = false;
            this.atLabel10.Size = new System.Drawing.Size(88, 18);
            this.atLabel10.TabIndex = 46;
            this.atLabel10.Text = "Select Edition";
            this.atLabel10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbEditionActivate
            // 
            this.cmbEditionActivate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEditionActivate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEditionActivate.DropDownHeight = 300;
            this.cmbEditionActivate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEditionActivate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbEditionActivate.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbEditionActivate.FormattingEnabled = true;
            this.cmbEditionActivate.IntegralHeight = false;
            this.cmbEditionActivate.Location = new System.Drawing.Point(37, 100);
            this.cmbEditionActivate.Name = "cmbEditionActivate";
            this.cmbEditionActivate.Size = new System.Drawing.Size(339, 26);
            this.cmbEditionActivate.TabIndex = 1;
            // 
            // pnlFinish
            // 
            this.pnlFinish.Controls.Add(this.label2);
            this.pnlFinish.Location = new System.Drawing.Point(152, 40);
            this.pnlFinish.Name = "pnlFinish";
            this.pnlFinish.Size = new System.Drawing.Size(460, 367);
            this.pnlFinish.TabIndex = 5;
            this.pnlFinish.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(25, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Thank You";
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Open Sans SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(10, 10);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            this.lblHeading.Size = new System.Drawing.Size(215, 26);
            this.lblHeading.TabIndex = 12;
            this.lblHeading.Text = "One Time Registration";
            // 
            // pnlFooter
            // 
            this.pnlFooter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlFooter.Controls.Add(this.btnBack);
            this.pnlFooter.Controls.Add(this.btnCancel);
            this.pnlFooter.Controls.Add(this.btnFinish);
            this.pnlFooter.Controls.Add(this.btnNext);
            this.pnlFooter.Location = new System.Drawing.Point(3, 409);
            this.pnlFooter.Name = "pnlFooter";
            this.pnlFooter.Size = new System.Drawing.Size(609, 43);
            this.pnlFooter.TabIndex = 13;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(312, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(93, 35);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "< &Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(213, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(93, 35);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnFinish
            // 
            this.btnFinish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFinish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnFinish.FlatAppearance.BorderSize = 0;
            this.btnFinish.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinish.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinish.ForeColor = System.Drawing.Color.White;
            this.btnFinish.Location = new System.Drawing.Point(510, 2);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(93, 35);
            this.btnFinish.TabIndex = 5;
            this.btnFinish.Text = "&Finish";
            this.btnFinish.UseVisualStyleBackColor = false;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNext.FlatAppearance.BorderSize = 0;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.Color.White;
            this.btnNext.Location = new System.Drawing.Point(411, 2);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(93, 35);
            this.btnNext.TabIndex = 7;
            this.btnNext.Text = "&Next >";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 14.25F);
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(584, 1);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 35);
            this.btnClose.TabIndex = 127;
            this.btnClose.TabStop = false;
            this.btnClose.Text = "x";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // OneTimeRegistrationWizard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 455);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.pnlSide1);
            this.Controls.Add(this.pnlWelcome);
            this.Controls.Add(this.pnlFinish);
            this.Controls.Add(this.pnlOnline);
            this.Controls.Add(this.pnlActivate);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "OneTimeRegistrationWizard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "One Time Licence";
            this.Load += new System.EventHandler(this.OneTimeRegistrationWizard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errPrvdr)).EndInit();
            this.pnlWelcome.ResumeLayout(false);
            this.pnlWelcome.PerformLayout();
            this.pnlOnline.ResumeLayout(false);
            this.pnlCustomerDetails.ResumeLayout(false);
            this.pnlCustomerDetails.PerformLayout();
            this.pnlActivate.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnlFinish.ResumeLayout(false);
            this.pnlFinish.PerformLayout();
            this.pnlFooter.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ErrorProvider errPrvdr;
        private System.Windows.Forms.Panel pnlSide1;
        private System.Windows.Forms.Panel pnlWelcome;
        private System.Windows.Forms.Panel pnlOnline;
        private System.Windows.Forms.Label lblcap1;
        private atACCFramework.UserControls.atGroupBox pnlCustomerDetails;
        private atACCFramework.UserControls.TextBoxExt txtCustomerName;
        private atACCFramework.UserControls.atLabel atLabel1;
        private atACCFramework.UserControls.ComboBoxExt cmbEditions;
        private atACCFramework.UserControls.TextBoxExt txtBusinessType;
        private atACCFramework.UserControls.atLabel atLabel8;
        private atACCFramework.UserControls.TextBoxExt txtProductID;
        private atACCFramework.UserControls.atLabel atLabel2;
        private atACCFramework.UserControls.atLabel atLabel6;
        private atACCFramework.UserControls.TextBoxExt txtAddress;
        private atACCFramework.UserControls.atLabel lblCode;
        private atACCFramework.UserControls.atLabel atLabel3;
        private atACCFramework.UserControls.TextBoxExt txtCDKey;
        private atACCFramework.UserControls.TextBoxExt txtCity;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atLabel atLabel4;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.TextBoxExt txtState;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.atLabel atLabel5;
        private atACCFramework.UserControls.TextBoxExt txtEmail;
        private atACCFramework.UserControls.ComboBoxExt CmbCountry;
        private atACCFramework.UserControls.atLabel lblEmail;
        private atACCFramework.UserControls.atLabel lblCountry;
        private atACCFramework.UserControls.atLabel lblMobileNumber;
        private System.Windows.Forms.Panel pnlActivate;
        private atACCFramework.UserControls.TextBoxExt txtProductIDActivate;
        private atACCFramework.UserControls.atLabel atLabel9;
        private atACCFramework.UserControls.TextBoxExt txtRegistrationNo;
        private System.Windows.Forms.Panel pnlFinish;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radOffline;
        private System.Windows.Forms.RadioButton radOnline;
        private atACCFramework.UserControls.ComboBoxExt cmbEditionActivate;
        private atACCFramework.UserControls.atLabel atLabel10;
        private System.Windows.Forms.Panel panel3;
        private atACCFramework.UserControls.atLabel lblVisit;
        private System.Windows.Forms.LinkLabel lblWebLink;
        private atACCFramework.UserControls.atLabel atLabel11;
        private atACCFramework.UserControls.TextBoxExt txtCDKeyActivate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblContent1;
        private atACCFramework.UserControls.atLabel lblHeading;
        private System.Windows.Forms.Panel pnlFooter;
        private atACCFramework.UserControls.atButton btnBack;
        private atACCFramework.UserControls.atButton btnCancel;
        private atACCFramework.UserControls.atButton btnFinish;
        private atACCFramework.UserControls.atButton btnNext;
        private atACCFramework.UserControls.atLabel atLabel7;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory4;
        private System.Windows.Forms.Label lblMandatory5;
        private System.Windows.Forms.Label lblMandatory6;
        private System.Windows.Forms.Label lblMandatory7;
        private System.Windows.Forms.Label lblMandatory8;
        private System.Windows.Forms.Label lblMandatory9;
        private System.Windows.Forms.Label lblMandatory10;
        private System.Windows.Forms.Label lblMandatory11;
        private System.Windows.Forms.Label lblMandatory12;
        private atACCFramework.UserControls.atLabel lblforRegistration;
    }
}