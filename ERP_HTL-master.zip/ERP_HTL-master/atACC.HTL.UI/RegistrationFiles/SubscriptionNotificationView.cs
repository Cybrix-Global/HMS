﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LocalORM;
using atACC.Common;
using atACC.CommonExtensions;
using atACC.CommonMessages;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
namespace atACC.HTL.UI
{
    public partial class SubscriptionNotificationView : FormBase
    {
        #region Constructor
        Registration registration;
        int iDaysToEnd;
        public SubscriptionNotificationView(Registration _registration,int _DaysToEnd)
        {
            InitializeComponent();
            registration = _registration;
            iDaysToEnd = _DaysToEnd;
            ShowDetails();
        }
        #endregion

        #region Form Events
        private void ShowDetails()
        {
            string sEdition,sCaption,sWarning;
            if (registration.FK_Edition == (int)ENEditions.BasicEdition)
            {
                sEdition = "- Basic Edition";
            }
            else
            {
                sEdition = "- Standard Edition";
            }
            if (GlobalFunctions.boolSubScriptionExpired)
            {
                sCaption = "Your subscription of " + MessageKeys.MsgApplicationName+" "+sEdition + " has expired on "
                            + registration.SubscriptionEndDate.ToDateTime().Date.ToShortDateString()
                            + ". You still have access to your data, but cannot use the full functionality. To continue using "
                            + MessageKeys.MsgApplicationName
                            +" , please choose an option below to reactivate immediatly. Kindly contact our support team for further details.";
                sWarning = "Subscription Expired!";
            }
            else
            {
                if (iDaysToEnd == 0)
                {
                    sCaption = "Warning! Your subscription of " + MessageKeys.MsgApplicationName + " " + sEdition 
                               + " will expire today. For hassle-free usage, choose an option below to reactivate or contact our support team.";
                }
                else
                {
                    sCaption = "Please note! Your subscription of " + MessageKeys.MsgApplicationName + " " + sEdition 
                               + " is about to expire within " + iDaysToEnd + " days. To keep using " + MessageKeys.MsgApplicationName 
                               + " without any interruption, choose an option below to reactivate.";
                }
                sWarning = "Subscription Warning!";
            }
            lblCaption.Text = sCaption;
            lblWarning.Text = sWarning;
        }
        private void lblClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
        private void btnOneTimeReg_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.OneTimeRegistrationWizard");
            this.DialogResult = DialogResult.OK;
        }
        private void btnRenew_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.SubscriptionView");
            this.DialogResult = DialogResult.OK;
        }
        private void btnRegDetails_Click(object sender, EventArgs e)
        {
            UIClasses.UICommon.fnActivateForm("ERP.UI", "atACC.UI.RegistrationDetailsView");
            this.DialogResult = DialogResult.OK;
        }

        private void SubscriptionNotificationView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Escape)
            {
                this.Close();
            }
        }
        private void lblClose_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                lblClose.ForeColor = Color.Red;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void lblClose_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                lblClose.ForeColor = Color.DarkGray;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
