﻿namespace atACC.HTL.UI
{
    partial class RegistrationDetailsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgRegistrations = new System.Windows.Forms.DataGridView();
            this.colSlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCDKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRegistrationNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRegDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubscriptionDays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubscriptionEndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgRegistrations)).BeginInit();
            this.SuspendLayout();
            // 
            // dgRegistrations
            // 
            this.dgRegistrations.AllowUserToAddRows = false;
            this.dgRegistrations.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgRegistrations.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgRegistrations.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgRegistrations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRegistrations.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSlNo,
            this.colCDKey,
            this.colEdition,
            this.colProductID,
            this.colMode,
            this.colRegistrationNo,
            this.colRegDate,
            this.colSubscriptionDays,
            this.colSubscriptionEndDate});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgRegistrations.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgRegistrations.Location = new System.Drawing.Point(8, 52);
            this.dgRegistrations.Name = "dgRegistrations";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgRegistrations.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgRegistrations.Size = new System.Drawing.Size(846, 392);
            this.dgRegistrations.TabIndex = 0;
            // 
            // colSlNo
            // 
            this.colSlNo.DataPropertyName = "Id";
            this.colSlNo.FillWeight = 48.69477F;
            this.colSlNo.HeaderText = "Sl.No";
            this.colSlNo.Name = "colSlNo";
            this.colSlNo.ReadOnly = true;
            // 
            // colCDKey
            // 
            this.colCDKey.DataPropertyName = "CDKey";
            this.colCDKey.FillWeight = 124.7253F;
            this.colCDKey.HeaderText = "CDKey";
            this.colCDKey.Name = "colCDKey";
            this.colCDKey.ReadOnly = true;
            // 
            // colEdition
            // 
            this.colEdition.DataPropertyName = "Edition";
            this.colEdition.FillWeight = 101.1769F;
            this.colEdition.HeaderText = "Edition";
            this.colEdition.Name = "colEdition";
            this.colEdition.ReadOnly = true;
            // 
            // colProductID
            // 
            this.colProductID.DataPropertyName = "ProductID";
            this.colProductID.FillWeight = 128.148F;
            this.colProductID.HeaderText = "Product ID";
            this.colProductID.Name = "colProductID";
            this.colProductID.ReadOnly = true;
            // 
            // colMode
            // 
            this.colMode.DataPropertyName = "RegistrationMode";
            this.colMode.FillWeight = 101.1769F;
            this.colMode.HeaderText = "Mode";
            this.colMode.Name = "colMode";
            this.colMode.ReadOnly = true;
            // 
            // colRegistrationNo
            // 
            this.colRegistrationNo.DataPropertyName = "RegistrationNo";
            this.colRegistrationNo.FillWeight = 101.1769F;
            this.colRegistrationNo.HeaderText = "Reg.No";
            this.colRegistrationNo.Name = "colRegistrationNo";
            this.colRegistrationNo.ReadOnly = true;
            // 
            // colRegDate
            // 
            this.colRegDate.DataPropertyName = "RegistrationDate";
            this.colRegDate.FillWeight = 101.1769F;
            this.colRegDate.HeaderText = "Reg.Date";
            this.colRegDate.Name = "colRegDate";
            this.colRegDate.ReadOnly = true;
            // 
            // colSubscriptionDays
            // 
            this.colSubscriptionDays.DataPropertyName = "SubscriptionDays";
            this.colSubscriptionDays.FillWeight = 91.37055F;
            this.colSubscriptionDays.HeaderText = "Subscription Days";
            this.colSubscriptionDays.Name = "colSubscriptionDays";
            this.colSubscriptionDays.ReadOnly = true;
            // 
            // colSubscriptionEndDate
            // 
            this.colSubscriptionEndDate.DataPropertyName = "SubscriptionEndDate";
            this.colSubscriptionEndDate.FillWeight = 101.1769F;
            this.colSubscriptionEndDate.HeaderText = "Sub.EndDate";
            this.colSubscriptionEndDate.Name = "colSubscriptionEndDate";
            this.colSubscriptionEndDate.ReadOnly = true;
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblHeading.Location = new System.Drawing.Point(10, 10);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            this.lblHeading.Size = new System.Drawing.Size(187, 26);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Registration Details";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 14.25F);
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(834, 1);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 35);
            this.btnClose.TabIndex = 126;
            this.btnClose.Text = "x";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // RegistrationDetailsView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 455);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.dgRegistrations);
            this.Name = "RegistrationDetailsView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration Details";
            ((System.ComponentModel.ISupportInitialize)(this.dgRegistrations)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgRegistrations;
        private atACCFramework.UserControls.atLabel lblHeading;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCDKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdition;
        private System.Windows.Forms.DataGridViewTextBoxColumn colProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRegistrationNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRegDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubscriptionDays;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubscriptionEndDate;
        private System.Windows.Forms.Button btnClose;
    }
}