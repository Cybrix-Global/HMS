﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;
using atACC.Common;
using System.Management;
using LocalORM;
using AtCryptoGraphy2;
using System.Data.Objects;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;

namespace atACC.HTL.UI
{
    public class RegistrationHelper
    {
        #region Public Variables
        public static string sRegistrationConnectionString = "server=199.79.62.23;User Id=atroot;Password=12345;database=atreport;max pool size=250";
        #endregion

        #region Public Methods
        public int ExecuteNonQuery(string sql, MySqlConnection conn)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand();
                cmd.CommandTimeout = 0;
                cmd.Connection = conn;
                cmd.CommandText = sql;
                cmd.CommandType = System.Data.CommandType.Text;
                
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public  string CreateRandomPassword(int PasswordLength)
        {
            string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
            Random randNum = new Random();
            char[] chars = new char[PasswordLength];
            int allowedCharCount = _allowedChars.Length;
            for (int i = 0; i < PasswordLength; i++)
            {
                chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
            }
            return new string(chars);
        }
        public int ExecuteNonQuery(string sql, MySqlTransaction trans)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand();
                cmd.CommandTimeout = 0;
                cmd.Connection = trans.Connection;
                cmd.Transaction = trans;
                cmd.CommandText = sql;
                cmd.CommandType = System.Data.CommandType.Text;
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable GetData(string sql, MySqlConnection conn)
        {
            try
            {
                DataTable dt = new DataTable();
                MySqlDataAdapter dad = new MySqlDataAdapter(sql, conn);
                dad.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetUUID()
        {
            try
            {
                ManagementObjectCollection instances = new ManagementClass("Win32_ComputerSystemProduct").GetInstances();
                string str = "";
                foreach (ManagementObject obj2 in instances)
                {
                    str = obj2["UUID"].ToString();
                    obj2.Dispose();
                }
                return str.Substring(1, 25);
            }
            catch (Exception)
            {
                return "";
            }
        }
        public bool isRegistered()
        {
#if DEBUG
            return true;
#endif
            string sProductID=GetUUID();
            AtCryptoGraphy2.AtCryptoGraphy2 _crypto=new AtCryptoGraphy2.AtCryptoGraphy2();
            SettingsDbEntities sdb = new SettingsDbEntities();
            List<Registration> entRegistration = sdb.Registrations.ToList();

         var _registrations=entRegistration.Where(x => (
                    x.FK_RegistrationMode == (int)ENRegistrationModes.OneTime
                    && x.FK_Edition==(int)ENEditions.BasicEdition
                    && _crypto.IsKeyOK(x.RegistrationNo,sProductID,(int)ENEditionKeys.BasicEdition)
                    )
                    ||
                    (
                    x.FK_RegistrationMode == (int)ENRegistrationModes.OneTime
                    && x.FK_Edition == (int)ENEditions.StandardEdition
                    && _crypto.IsKeyOK(x.RegistrationNo, sProductID, (int)ENEditionKeys.StandardEdition)
                    )
                    || 
                    (
                    x.FK_RegistrationMode == (int)ENRegistrationModes.Subscription
                    && x.SubscriptionEndDate.Value.Date >= DateTime.Now.Date && x.RegistrationDate.Value.Date<=DateTime.Now.Date
                    && _crypto.IsKeyOK(x.RegistrationNo,sProductID+x.RandomPassword,(int)ENEditionKeys.BasicEdition)
                    )
                    ||
                    (
                    x.FK_RegistrationMode == (int)ENRegistrationModes.Subscription
                    && x.SubscriptionEndDate.Value.Date >= DateTime.Now.Date && x.RegistrationDate.Value.Date <= DateTime.Now.Date
                    && _crypto.IsKeyOK(x.RegistrationNo, sProductID + x.RandomPassword, (int)ENEditionKeys.StandardEdition)
                    )
                    ).OrderByDescending(x=>x.id).ToList();
         if (_registrations.Count > 0)
            {
                if (_registrations != null)
                {
                    GlobalFunctions.iCurrentRegistrationMode = (int)_registrations.First().FK_RegistrationMode;
                    GlobalFunctions.iCurrentEdition = (int)_registrations.First().FK_Edition;
                }
                return true;
            }
            else
            {
                GlobalFunctions.iCurrentRegistrationMode =(int)ENRegistrationModes.Demo;
                return false;
            }
        }
        #endregion
    }
}
