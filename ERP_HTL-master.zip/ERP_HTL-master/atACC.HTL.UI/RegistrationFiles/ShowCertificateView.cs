﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using atACC.Common;
using atACC.CommonExtensions;
using atACC.CommonMessages;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using AtCryptoGraphy2;
using LocalORM;
using Microsoft.Reporting.WinForms;
using System.IO;
namespace atACC.HTL.UI
{
    public partial class ShowCertificateView : FormBase
    {
        public ShowCertificateView()
        {
            InitializeComponent();
        }
        public void ShowCertificate(DataTable dt,int iType)
        {
            string sCertificate1 = Application.StartupPath + "\\Certificate.rdlc";
            string sCertificate2 = Application.StartupPath + "\\CertificateSub.rdlc";
            if (GlobalFunctions._oemData.Certificate1Path != "")
            {
                File.WriteAllBytes(sCertificate1, GlobalFunctions._oemData.Certificate1Data); // Requires System.IO
            }
            if (GlobalFunctions._oemData.Certificate2Path != "")
            {
                File.WriteAllBytes(sCertificate2, GlobalFunctions._oemData.Certificate2Data); // Requires System.IO
            }
            

            try
            {   rptVwr.ProcessingMode = ProcessingMode.Local;
            if (iType == 0)
            {
                rptVwr.LocalReport.ReportPath = sCertificate1;
            }
            else
            {
                rptVwr.LocalReport.ReportPath = sCertificate2;
            }
                
                rptVwr.LocalReport.EnableExternalImages = true;
                rptVwr.LocalReport.EnableHyperlinks = true;
                rptVwr.LocalReport.DataSources.Clear();
                ReportDataSource rds = new ReportDataSource(dt.TableName, dt);
                rptVwr.LocalReport.DataSources.Add(rds);
                rptVwr.Visible = true;
                
                rptVwr.RefreshReport();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
