﻿namespace atACC.HTL.UI
{
    partial class SubscriptionNotificationView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubscriptionNotificationView));
            this.lblCaption = new System.Windows.Forms.Label();
            this.lblWarning = new atACCFramework.UserControls.atLabel();
            this.lblClose = new System.Windows.Forms.Label();
            this.pnlHeader = new atACCFramework.UserControls.atPanel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.btnLine5 = new System.Windows.Forms.Button();
            this.btnLine4 = new System.Windows.Forms.Button();
            this.btnLine2 = new System.Windows.Forms.Button();
            this.btnLine3 = new System.Windows.Forms.Button();
            this.btnLine = new System.Windows.Forms.Button();
            this.btnOneTimeReg = new System.Windows.Forms.Button();
            this.btnRenew = new System.Windows.Forms.Button();
            this.btnRegDetails = new System.Windows.Forms.Button();
            this.pnlHeader.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCaption
            // 
            this.lblCaption.BackColor = System.Drawing.Color.Transparent;
            this.lblCaption.Font = new System.Drawing.Font("Noto Sans", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaption.ForeColor = System.Drawing.Color.Black;
            this.lblCaption.Location = new System.Drawing.Point(7, 65);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Size = new System.Drawing.Size(572, 113);
            this.lblCaption.TabIndex = 1;
            this.lblCaption.Text = "---";
            this.lblCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblWarning
            // 
            this.lblWarning.AutoSize = true;
            this.lblWarning.BackColor = System.Drawing.Color.Transparent;
            this.lblWarning.Font = new System.Drawing.Font("Noto Sans", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.ForeColor = System.Drawing.Color.Crimson;
            this.lblWarning.Location = new System.Drawing.Point(104, 1);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.RequiredField = false;
            this.lblWarning.Size = new System.Drawing.Size(387, 47);
            this.lblWarning.TabIndex = 7;
            this.lblWarning.Text = "Subscription Warning!";
            // 
            // lblClose
            // 
            this.lblClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblClose.AutoSize = true;
            this.lblClose.BackColor = System.Drawing.Color.Transparent;
            this.lblClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblClose.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClose.ForeColor = System.Drawing.Color.DarkGray;
            this.lblClose.Location = new System.Drawing.Point(558, 3);
            this.lblClose.Name = "lblClose";
            this.lblClose.Size = new System.Drawing.Size(26, 25);
            this.lblClose.TabIndex = 8;
            this.lblClose.Text = "X";
            this.lblClose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblClose.Click += new System.EventHandler(this.lblClose_Click);
            this.lblClose.MouseEnter += new System.EventHandler(this.lblClose_MouseEnter);
            this.lblClose.MouseLeave += new System.EventHandler(this.lblClose_MouseLeave);
            // 
            // pnlHeader
            // 
            this.pnlHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlHeader.BackColor = System.Drawing.SystemColors.Window;
            this.pnlHeader.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlHeader.BackgroundImage")));
            this.pnlHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlHeader.Controls.Add(this.lblWarning);
            this.pnlHeader.Controls.Add(this.lblClose);
            this.pnlHeader.Location = new System.Drawing.Point(-1, -1);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(587, 50);
            this.pnlHeader.TabIndex = 9;
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMain.Controls.Add(this.btnRegDetails);
            this.pnlMain.Controls.Add(this.lblCaption);
            this.pnlMain.Controls.Add(this.btnLine5);
            this.pnlMain.Controls.Add(this.pnlHeader);
            this.pnlMain.Controls.Add(this.btnLine4);
            this.pnlMain.Controls.Add(this.btnLine2);
            this.pnlMain.Controls.Add(this.btnLine3);
            this.pnlMain.Controls.Add(this.btnLine);
            this.pnlMain.Controls.Add(this.btnOneTimeReg);
            this.pnlMain.Controls.Add(this.btnRenew);
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(587, 257);
            this.pnlMain.TabIndex = 0;
            // 
            // btnLine5
            // 
            this.btnLine5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine5.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine5.Location = new System.Drawing.Point(577, 212);
            this.btnLine5.Name = "btnLine5";
            this.btnLine5.Size = new System.Drawing.Size(2, 37);
            this.btnLine5.TabIndex = 15;
            this.btnLine5.UseVisualStyleBackColor = true;
            // 
            // btnLine4
            // 
            this.btnLine4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine4.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine4.Location = new System.Drawing.Point(381, 212);
            this.btnLine4.Name = "btnLine4";
            this.btnLine4.Size = new System.Drawing.Size(2, 37);
            this.btnLine4.TabIndex = 4;
            this.btnLine4.UseVisualStyleBackColor = true;
            // 
            // btnLine2
            // 
            this.btnLine2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine2.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine2.Location = new System.Drawing.Point(7, 212);
            this.btnLine2.Name = "btnLine2";
            this.btnLine2.Size = new System.Drawing.Size(2, 37);
            this.btnLine2.TabIndex = 2;
            this.btnLine2.UseVisualStyleBackColor = true;
            // 
            // btnLine3
            // 
            this.btnLine3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLine3.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine3.Location = new System.Drawing.Point(186, 212);
            this.btnLine3.Name = "btnLine3";
            this.btnLine3.Size = new System.Drawing.Size(2, 37);
            this.btnLine3.TabIndex = 3;
            this.btnLine3.UseVisualStyleBackColor = true;
            // 
            // btnLine
            // 
            this.btnLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLine.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLine.Location = new System.Drawing.Point(1, 200);
            this.btnLine.Name = "btnLine";
            this.btnLine.Size = new System.Drawing.Size(584, 2);
            this.btnLine.TabIndex = 9;
            this.btnLine.UseVisualStyleBackColor = true;
            // 
            // btnOneTimeReg
            // 
            this.btnOneTimeReg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOneTimeReg.FlatAppearance.BorderSize = 0;
            this.btnOneTimeReg.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnOneTimeReg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnOneTimeReg.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnOneTimeReg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOneTimeReg.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOneTimeReg.Image = ((System.Drawing.Image)(resources.GetObject("btnOneTimeReg.Image")));
            this.btnOneTimeReg.Location = new System.Drawing.Point(10, 211);
            this.btnOneTimeReg.Name = "btnOneTimeReg";
            this.btnOneTimeReg.Size = new System.Drawing.Size(179, 38);
            this.btnOneTimeReg.TabIndex = 16;
            this.btnOneTimeReg.Text = "  One Time Licence";
            this.btnOneTimeReg.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnOneTimeReg.UseVisualStyleBackColor = true;
            this.btnOneTimeReg.Click += new System.EventHandler(this.btnOneTimeReg_Click);
            // 
            // btnRenew
            // 
            this.btnRenew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRenew.FlatAppearance.BorderSize = 0;
            this.btnRenew.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnRenew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRenew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnRenew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRenew.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRenew.Image = ((System.Drawing.Image)(resources.GetObject("btnRenew.Image")));
            this.btnRenew.Location = new System.Drawing.Point(189, 211);
            this.btnRenew.Name = "btnRenew";
            this.btnRenew.Size = new System.Drawing.Size(194, 38);
            this.btnRenew.TabIndex = 17;
            this.btnRenew.Text = "  Renew Subscription";
            this.btnRenew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRenew.UseVisualStyleBackColor = true;
            this.btnRenew.Click += new System.EventHandler(this.btnRenew_Click);
            // 
            // btnRegDetails
            // 
            this.btnRegDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegDetails.FlatAppearance.BorderSize = 0;
            this.btnRegDetails.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnRegDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRegDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnRegDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegDetails.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegDetails.Image = ((System.Drawing.Image)(resources.GetObject("btnRegDetails.Image")));
            this.btnRegDetails.Location = new System.Drawing.Point(388, 211);
            this.btnRegDetails.Name = "btnRegDetails";
            this.btnRegDetails.Size = new System.Drawing.Size(194, 38);
            this.btnRegDetails.TabIndex = 18;
            this.btnRegDetails.Text = " Registration Details";
            this.btnRegDetails.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegDetails.UseVisualStyleBackColor = true;
            this.btnRegDetails.Click += new System.EventHandler(this.btnRegDetails_Click);
            // 
            // SubscriptionNotificationView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(587, 257);
            this.Controls.Add(this.pnlMain);
            this.Name = "SubscriptionNotificationView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Subcription Expiry";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SubscriptionNotificationView_KeyDown);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblCaption;
        private atACCFramework.UserControls.atLabel lblWarning;
        private System.Windows.Forms.Label lblClose;
        private atACCFramework.UserControls.atPanel pnlHeader;
        private atACCFramework.UserControls.atPanel pnlMain;
        private System.Windows.Forms.Button btnLine;
        private System.Windows.Forms.Button btnLine3;
        private System.Windows.Forms.Button btnLine5;
        private System.Windows.Forms.Button btnLine4;
        private System.Windows.Forms.Button btnLine2;
        private System.Windows.Forms.Button btnOneTimeReg;
        private System.Windows.Forms.Button btnRenew;
        private System.Windows.Forms.Button btnRegDetails;
    }
}