﻿namespace atACC.HTL.UI
{
    partial class SubscriptionView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubscriptionView));
            this.pnlSide1 = new System.Windows.Forms.Panel();
            this.pnlFooter = new System.Windows.Forms.Panel();
            this.btnBack = new atACCFramework.UserControls.atButton();
            this.btnCancel = new atACCFramework.UserControls.atButton();
            this.btnFinish = new atACCFramework.UserControls.atButton();
            this.btnNext = new atACCFramework.UserControls.atButton();
            this.pnlOnline = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtRegistrationNo = new atACCFramework.UserControls.TextBoxExt();
            this.pnlCustomerDetails = new atACCFramework.UserControls.atGroupBox();
            this.txtCustomerName = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.cmbEditions = new atACCFramework.UserControls.ComboBoxExt();
            this.txtBusinessType = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel8 = new atACCFramework.UserControls.atLabel();
            this.txtProductID = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel2 = new atACCFramework.UserControls.atLabel();
            this.atLabel6 = new atACCFramework.UserControls.atLabel();
            this.txtAddress = new atACCFramework.UserControls.TextBoxExt();
            this.lblCode = new atACCFramework.UserControls.atLabel();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.txtCDKey = new atACCFramework.UserControls.TextBoxExt();
            this.txtCity = new atACCFramework.UserControls.TextBoxExt();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel4 = new atACCFramework.UserControls.atLabel();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.txtState = new atACCFramework.UserControls.TextBoxExt();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.atLabel5 = new atACCFramework.UserControls.atLabel();
            this.txtEmail = new atACCFramework.UserControls.TextBoxExt();
            this.CmbCountry = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEmail = new atACCFramework.UserControls.atLabel();
            this.lblCountry = new atACCFramework.UserControls.atLabel();
            this.lblMobileNumber = new atACCFramework.UserControls.atLabel();
            this.pnlFinish = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.errPrvdr = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.pnlWelcome = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lbldescript = new System.Windows.Forms.Label();
            this.lblcap = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pnlFooter.SuspendLayout();
            this.pnlOnline.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnlCustomerDetails.SuspendLayout();
            this.pnlFinish.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errPrvdr)).BeginInit();
            this.pnlWelcome.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSide1
            // 
            this.pnlSide1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlSide1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSide1.BackgroundImage")));
            this.pnlSide1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlSide1.Location = new System.Drawing.Point(3, 40);
            this.pnlSide1.Name = "pnlSide1";
            this.pnlSide1.Size = new System.Drawing.Size(147, 431);
            this.pnlSide1.TabIndex = 0;
            // 
            // pnlFooter
            // 
            this.pnlFooter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlFooter.Controls.Add(this.btnBack);
            this.pnlFooter.Controls.Add(this.btnCancel);
            this.pnlFooter.Controls.Add(this.btnFinish);
            this.pnlFooter.Controls.Add(this.btnNext);
            this.pnlFooter.Location = new System.Drawing.Point(3, 472);
            this.pnlFooter.Name = "pnlFooter";
            this.pnlFooter.Size = new System.Drawing.Size(609, 43);
            this.pnlFooter.TabIndex = 1;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(312, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(93, 35);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "< &Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(213, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(93, 35);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnFinish
            // 
            this.btnFinish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFinish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnFinish.FlatAppearance.BorderSize = 0;
            this.btnFinish.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinish.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinish.ForeColor = System.Drawing.Color.White;
            this.btnFinish.Location = new System.Drawing.Point(510, 2);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(93, 35);
            this.btnFinish.TabIndex = 5;
            this.btnFinish.Text = "&Finish";
            this.btnFinish.UseVisualStyleBackColor = false;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNext.FlatAppearance.BorderSize = 0;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.Color.White;
            this.btnNext.Location = new System.Drawing.Point(411, 2);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(93, 35);
            this.btnNext.TabIndex = 7;
            this.btnNext.Text = "&Next >";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // pnlOnline
            // 
            this.pnlOnline.Controls.Add(this.groupBox1);
            this.pnlOnline.Controls.Add(this.pnlCustomerDetails);
            this.pnlOnline.Location = new System.Drawing.Point(152, 40);
            this.pnlOnline.Name = "pnlOnline";
            this.pnlOnline.Size = new System.Drawing.Size(460, 430);
            this.pnlOnline.TabIndex = 1;
            this.pnlOnline.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtRegistrationNo);
            this.groupBox1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(8, 361);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(442, 63);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter The Registration Number";
            // 
            // txtRegistrationNo
            // 
            this.txtRegistrationNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtRegistrationNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegistrationNo.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegistrationNo.Format = null;
            this.txtRegistrationNo.isAllowNegative = false;
            this.txtRegistrationNo.isAllowSpecialChar = false;
            this.txtRegistrationNo.isNumeric = false;
            this.txtRegistrationNo.isTouchable = false;
            this.txtRegistrationNo.Location = new System.Drawing.Point(12, 32);
            this.txtRegistrationNo.Name = "txtRegistrationNo";
            this.txtRegistrationNo.Size = new System.Drawing.Size(412, 18);
            this.txtRegistrationNo.TabIndex = 0;
            this.txtRegistrationNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRegistrationNo.WaterMark = null;
            // 
            // pnlCustomerDetails
            // 
            this.pnlCustomerDetails.BackColor = System.Drawing.Color.Transparent;
            this.pnlCustomerDetails.Controls.Add(this.lblMandatory1);
            this.pnlCustomerDetails.Controls.Add(this.txtCustomerName);
            this.pnlCustomerDetails.Controls.Add(this.atLabel1);
            this.pnlCustomerDetails.Controls.Add(this.cmbEditions);
            this.pnlCustomerDetails.Controls.Add(this.txtBusinessType);
            this.pnlCustomerDetails.Controls.Add(this.atLabel8);
            this.pnlCustomerDetails.Controls.Add(this.txtProductID);
            this.pnlCustomerDetails.Controls.Add(this.atLabel2);
            this.pnlCustomerDetails.Controls.Add(this.atLabel6);
            this.pnlCustomerDetails.Controls.Add(this.txtAddress);
            this.pnlCustomerDetails.Controls.Add(this.lblCode);
            this.pnlCustomerDetails.Controls.Add(this.atLabel3);
            this.pnlCustomerDetails.Controls.Add(this.txtCDKey);
            this.pnlCustomerDetails.Controls.Add(this.txtCity);
            this.pnlCustomerDetails.Controls.Add(this.txtMobile);
            this.pnlCustomerDetails.Controls.Add(this.atLabel4);
            this.pnlCustomerDetails.Controls.Add(this.lblTelephone);
            this.pnlCustomerDetails.Controls.Add(this.txtState);
            this.pnlCustomerDetails.Controls.Add(this.txtTelephone);
            this.pnlCustomerDetails.Controls.Add(this.atLabel5);
            this.pnlCustomerDetails.Controls.Add(this.txtEmail);
            this.pnlCustomerDetails.Controls.Add(this.CmbCountry);
            this.pnlCustomerDetails.Controls.Add(this.lblEmail);
            this.pnlCustomerDetails.Controls.Add(this.lblCountry);
            this.pnlCustomerDetails.Controls.Add(this.lblMobileNumber);
            this.pnlCustomerDetails.Controls.Add(this.label1);
            this.pnlCustomerDetails.Controls.Add(this.label3);
            this.pnlCustomerDetails.Controls.Add(this.label5);
            this.pnlCustomerDetails.Controls.Add(this.label6);
            this.pnlCustomerDetails.Controls.Add(this.label7);
            this.pnlCustomerDetails.Controls.Add(this.label8);
            this.pnlCustomerDetails.Controls.Add(this.label9);
            this.pnlCustomerDetails.Controls.Add(this.label10);
            this.pnlCustomerDetails.Controls.Add(this.label11);
            this.pnlCustomerDetails.Controls.Add(this.label12);
            this.pnlCustomerDetails.Controls.Add(this.label13);
            this.pnlCustomerDetails.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlCustomerDetails.Location = new System.Drawing.Point(8, 2);
            this.pnlCustomerDetails.Name = "pnlCustomerDetails";
            this.pnlCustomerDetails.Size = new System.Drawing.Size(445, 359);
            this.pnlCustomerDetails.TabIndex = 0;
            this.pnlCustomerDetails.TabStop = false;
            this.pnlCustomerDetails.Text = "Online Registration";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.BackColor = System.Drawing.SystemColors.Window;
            this.txtCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCustomerName.Format = null;
            this.txtCustomerName.isAllowNegative = false;
            this.txtCustomerName.isAllowSpecialChar = false;
            this.txtCustomerName.isNumeric = false;
            this.txtCustomerName.isTouchable = false;
            this.txtCustomerName.Location = new System.Drawing.Point(124, 86);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(300, 18);
            this.txtCustomerName.TabIndex = 2;
            this.txtCustomerName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCustomerName.WaterMark = null;
            // 
            // atLabel1
            // 
            this.atLabel1.AutoSize = true;
            this.atLabel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel1.Location = new System.Drawing.Point(7, 86);
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            this.atLabel1.Size = new System.Drawing.Size(112, 18);
            this.atLabel1.TabIndex = 16;
            this.atLabel1.Text = "Customer Name :";
            this.atLabel1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbEditions
            // 
            this.cmbEditions.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEditions.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEditions.DropDownHeight = 300;
            this.cmbEditions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEditions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbEditions.Font = new System.Drawing.Font("Open Sans", 8.25F);
            this.cmbEditions.FormattingEnabled = true;
            this.cmbEditions.IntegralHeight = false;
            this.cmbEditions.Location = new System.Drawing.Point(125, 56);
            this.cmbEditions.Name = "cmbEditions";
            this.cmbEditions.Size = new System.Drawing.Size(300, 23);
            this.cmbEditions.TabIndex = 1;
            // 
            // txtBusinessType
            // 
            this.txtBusinessType.BackColor = System.Drawing.SystemColors.Window;
            this.txtBusinessType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBusinessType.Format = null;
            this.txtBusinessType.isAllowNegative = false;
            this.txtBusinessType.isAllowSpecialChar = false;
            this.txtBusinessType.isNumeric = false;
            this.txtBusinessType.isTouchable = false;
            this.txtBusinessType.Location = new System.Drawing.Point(125, 112);
            this.txtBusinessType.Name = "txtBusinessType";
            this.txtBusinessType.Size = new System.Drawing.Size(300, 18);
            this.txtBusinessType.TabIndex = 3;
            this.txtBusinessType.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtBusinessType.WaterMark = null;
            // 
            // atLabel8
            // 
            this.atLabel8.AutoSize = true;
            this.atLabel8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel8.Location = new System.Drawing.Point(63, 57);
            this.atLabel8.Name = "atLabel8";
            this.atLabel8.RequiredField = false;
            this.atLabel8.Size = new System.Drawing.Size(56, 18);
            this.atLabel8.TabIndex = 44;
            this.atLabel8.Text = "Edition :";
            this.atLabel8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtProductID
            // 
            this.txtProductID.BackColor = System.Drawing.SystemColors.Window;
            this.txtProductID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProductID.Format = null;
            this.txtProductID.isAllowNegative = false;
            this.txtProductID.isAllowSpecialChar = false;
            this.txtProductID.isNumeric = false;
            this.txtProductID.isTouchable = false;
            this.txtProductID.Location = new System.Drawing.Point(125, 321);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.ReadOnly = true;
            this.txtProductID.Size = new System.Drawing.Size(300, 18);
            this.txtProductID.TabIndex = 11;
            this.txtProductID.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtProductID.WaterMark = null;
            // 
            // atLabel2
            // 
            this.atLabel2.AutoSize = true;
            this.atLabel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel2.Location = new System.Drawing.Point(21, 112);
            this.atLabel2.Name = "atLabel2";
            this.atLabel2.RequiredField = false;
            this.atLabel2.Size = new System.Drawing.Size(98, 18);
            this.atLabel2.TabIndex = 18;
            this.atLabel2.Text = "Business Type :";
            this.atLabel2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // atLabel6
            // 
            this.atLabel6.AutoSize = true;
            this.atLabel6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel6.Location = new System.Drawing.Point(41, 321);
            this.atLabel6.Name = "atLabel6";
            this.atLabel6.RequiredField = false;
            this.atLabel6.Size = new System.Drawing.Size(78, 18);
            this.atLabel6.TabIndex = 36;
            this.atLabel6.Text = "Product ID :";
            this.atLabel6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddress.Format = null;
            this.txtAddress.isAllowNegative = false;
            this.txtAddress.isAllowSpecialChar = false;
            this.txtAddress.isNumeric = false;
            this.txtAddress.isTouchable = false;
            this.txtAddress.Location = new System.Drawing.Point(125, 138);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(300, 18);
            this.txtAddress.TabIndex = 4;
            this.txtAddress.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAddress.WaterMark = null;
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCode.Location = new System.Drawing.Point(63, 31);
            this.lblCode.Name = "lblCode";
            this.lblCode.RequiredField = false;
            this.lblCode.Size = new System.Drawing.Size(56, 18);
            this.lblCode.TabIndex = 14;
            this.lblCode.Text = "CD Key :";
            this.lblCode.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // atLabel3
            // 
            this.atLabel3.AutoSize = true;
            this.atLabel3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel3.Location = new System.Drawing.Point(57, 138);
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            this.atLabel3.Size = new System.Drawing.Size(62, 18);
            this.atLabel3.TabIndex = 20;
            this.atLabel3.Text = "Address :";
            this.atLabel3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtCDKey
            // 
            this.txtCDKey.BackColor = System.Drawing.SystemColors.Window;
            this.txtCDKey.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCDKey.Format = null;
            this.txtCDKey.isAllowNegative = false;
            this.txtCDKey.isAllowSpecialChar = false;
            this.txtCDKey.isNumeric = false;
            this.txtCDKey.isTouchable = false;
            this.txtCDKey.Location = new System.Drawing.Point(125, 33);
            this.txtCDKey.Name = "txtCDKey";
            this.txtCDKey.Size = new System.Drawing.Size(300, 18);
            this.txtCDKey.TabIndex = 0;
            this.txtCDKey.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCDKey.WaterMark = null;
            // 
            // txtCity
            // 
            this.txtCity.BackColor = System.Drawing.SystemColors.Window;
            this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCity.Format = null;
            this.txtCity.isAllowNegative = false;
            this.txtCity.isAllowSpecialChar = false;
            this.txtCity.isNumeric = false;
            this.txtCity.isTouchable = false;
            this.txtCity.Location = new System.Drawing.Point(125, 164);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(300, 18);
            this.txtCity.TabIndex = 5;
            this.txtCity.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCity.WaterMark = null;
            // 
            // txtMobile
            // 
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMobile.Format = null;
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumeric = true;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Location = new System.Drawing.Point(125, 269);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(300, 18);
            this.txtMobile.TabIndex = 9;
            this.txtMobile.Text = "0";
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtMobile.WaterMark = null;
            // 
            // atLabel4
            // 
            this.atLabel4.AutoSize = true;
            this.atLabel4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel4.Location = new System.Drawing.Point(82, 164);
            this.atLabel4.Name = "atLabel4";
            this.atLabel4.RequiredField = false;
            this.atLabel4.Size = new System.Drawing.Size(37, 18);
            this.atLabel4.TabIndex = 22;
            this.atLabel4.Text = "City :";
            this.atLabel4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTelephone
            // 
            this.lblTelephone.AutoSize = true;
            this.lblTelephone.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTelephone.Location = new System.Drawing.Point(42, 243);
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            this.lblTelephone.Size = new System.Drawing.Size(77, 18);
            this.lblTelephone.TabIndex = 32;
            this.lblTelephone.Text = "Telephone :";
            this.lblTelephone.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtState
            // 
            this.txtState.BackColor = System.Drawing.SystemColors.Window;
            this.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtState.Format = null;
            this.txtState.isAllowNegative = false;
            this.txtState.isAllowSpecialChar = false;
            this.txtState.isNumeric = false;
            this.txtState.isTouchable = false;
            this.txtState.Location = new System.Drawing.Point(125, 190);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(300, 18);
            this.txtState.TabIndex = 6;
            this.txtState.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtState.WaterMark = null;
            // 
            // txtTelephone
            // 
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelephone.Format = null;
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumeric = true;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Location = new System.Drawing.Point(125, 243);
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Size = new System.Drawing.Size(300, 18);
            this.txtTelephone.TabIndex = 8;
            this.txtTelephone.Text = "0";
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtTelephone.WaterMark = null;
            // 
            // atLabel5
            // 
            this.atLabel5.AutoSize = true;
            this.atLabel5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel5.Location = new System.Drawing.Point(74, 190);
            this.atLabel5.Name = "atLabel5";
            this.atLabel5.RequiredField = false;
            this.atLabel5.Size = new System.Drawing.Size(45, 18);
            this.atLabel5.TabIndex = 24;
            this.atLabel5.Text = "State :";
            this.atLabel5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Format = null;
            this.txtEmail.isAllowNegative = false;
            this.txtEmail.isAllowSpecialChar = false;
            this.txtEmail.isNumeric = false;
            this.txtEmail.isTouchable = false;
            this.txtEmail.Location = new System.Drawing.Point(125, 295);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(300, 18);
            this.txtEmail.TabIndex = 10;
            this.txtEmail.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtEmail.WaterMark = null;
            // 
            // CmbCountry
            // 
            this.CmbCountry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CmbCountry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCountry.DropDownHeight = 300;
            this.CmbCountry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CmbCountry.Font = new System.Drawing.Font("Open Sans", 8.25F);
            this.CmbCountry.FormattingEnabled = true;
            this.CmbCountry.IntegralHeight = false;
            this.CmbCountry.Location = new System.Drawing.Point(125, 213);
            this.CmbCountry.Name = "CmbCountry";
            this.CmbCountry.Size = new System.Drawing.Size(299, 23);
            this.CmbCountry.TabIndex = 7;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmail.Location = new System.Drawing.Point(73, 295);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.RequiredField = false;
            this.lblEmail.Size = new System.Drawing.Size(46, 18);
            this.lblEmail.TabIndex = 34;
            this.lblEmail.Text = "Email :";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCountry.Location = new System.Drawing.Point(56, 214);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.RequiredField = false;
            this.lblCountry.Size = new System.Drawing.Size(63, 18);
            this.lblCountry.TabIndex = 28;
            this.lblCountry.Text = "Country :";
            this.lblCountry.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMobileNumber
            // 
            this.lblMobileNumber.AutoSize = true;
            this.lblMobileNumber.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMobileNumber.Location = new System.Drawing.Point(64, 269);
            this.lblMobileNumber.Name = "lblMobileNumber";
            this.lblMobileNumber.RequiredField = false;
            this.lblMobileNumber.Size = new System.Drawing.Size(55, 18);
            this.lblMobileNumber.TabIndex = 33;
            this.lblMobileNumber.Text = "Mobile :";
            this.lblMobileNumber.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pnlFinish
            // 
            this.pnlFinish.Controls.Add(this.label2);
            this.pnlFinish.Location = new System.Drawing.Point(152, 40);
            this.pnlFinish.Name = "pnlFinish";
            this.pnlFinish.Size = new System.Drawing.Size(460, 430);
            this.pnlFinish.TabIndex = 10;
            this.pnlFinish.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Thank You.";
            // 
            // errPrvdr
            // 
            this.errPrvdr.ContainerControl = this;
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Open Sans SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(10, 10);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            this.lblHeading.Size = new System.Drawing.Size(125, 26);
            this.lblHeading.TabIndex = 11;
            this.lblHeading.Text = "Subscription";
            // 
            // pnlWelcome
            // 
            this.pnlWelcome.Controls.Add(this.label4);
            this.pnlWelcome.Controls.Add(this.lbldescript);
            this.pnlWelcome.Controls.Add(this.lblcap);
            this.pnlWelcome.Location = new System.Drawing.Point(152, 40);
            this.pnlWelcome.Name = "pnlWelcome";
            this.pnlWelcome.Size = new System.Drawing.Size(460, 430);
            this.pnlWelcome.TabIndex = 0;
            this.pnlWelcome.Visible = false;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(426, 59);
            this.label4.TabIndex = 4;
            this.label4.Text = "Click \'Next\' to continue with the demo unlock and registration.  Click \'Cancel\' t" +
                "o quit Subscription Wizard.             ";
            // 
            // lbldescript
            // 
            this.lbldescript.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescript.Location = new System.Drawing.Point(15, 83);
            this.lbldescript.Name = "lbldescript";
            this.lbldescript.Size = new System.Drawing.Size(428, 39);
            this.lbldescript.TabIndex = 3;
            this.lbldescript.Text = "This wizard will unlock the demo version of atACC ERP 19.0 and use the software u" +
                "pto end of subscription.";
            // 
            // lblcap
            // 
            this.lblcap.Font = new System.Drawing.Font("Open Sans", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcap.Location = new System.Drawing.Point(12, 12);
            this.lblcap.Name = "lblcap";
            this.lblcap.Size = new System.Drawing.Size(432, 52);
            this.lblcap.TabIndex = 0;
            this.lblcap.Text = "Welcome to atACC ERP 19.0 Subscription Wizard.";
            this.lblcap.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 14.25F);
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(584, 1);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 35);
            this.btnClose.TabIndex = 126;
            this.btnClose.Text = "x";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // lblMandatory1
            // 
            this.lblMandatory1.AutoSize = true;
            this.lblMandatory1.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMandatory1.Location = new System.Drawing.Point(52, 30);
            this.lblMandatory1.Name = "lblMandatory1";
            this.lblMandatory1.Size = new System.Drawing.Size(15, 18);
            this.lblMandatory1.TabIndex = 46;
            this.lblMandatory1.Text = "*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label1.ForeColor = System.Drawing.Color.Crimson;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(53, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 18);
            this.label1.TabIndex = 47;
            this.label1.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label3.ForeColor = System.Drawing.Color.Crimson;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(-2, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 18);
            this.label3.TabIndex = 48;
            this.label3.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label5.ForeColor = System.Drawing.Color.Crimson;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(12, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 18);
            this.label5.TabIndex = 49;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label6.ForeColor = System.Drawing.Color.Crimson;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(48, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 18);
            this.label6.TabIndex = 50;
            this.label6.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label7.ForeColor = System.Drawing.Color.Crimson;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(72, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 18);
            this.label7.TabIndex = 51;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label8.ForeColor = System.Drawing.Color.Crimson;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(64, 189);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 18);
            this.label8.TabIndex = 52;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label9.ForeColor = System.Drawing.Color.Crimson;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(46, 213);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 18);
            this.label9.TabIndex = 53;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label10.ForeColor = System.Drawing.Color.Crimson;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(32, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 18);
            this.label10.TabIndex = 54;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label11.ForeColor = System.Drawing.Color.Crimson;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(55, 268);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 18);
            this.label11.TabIndex = 55;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label12.ForeColor = System.Drawing.Color.Crimson;
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(63, 294);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 18);
            this.label12.TabIndex = 56;
            this.label12.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.label13.ForeColor = System.Drawing.Color.Crimson;
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(31, 320);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 18);
            this.label13.TabIndex = 57;
            this.label13.Text = "*";
            // 
            // SubscriptionView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 518);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.pnlSide1);
            this.Controls.Add(this.pnlWelcome);
            this.Controls.Add(this.pnlFinish);
            this.Controls.Add(this.pnlOnline);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SubscriptionView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Subscription";
            this.Load += new System.EventHandler(this.SubscriptionView_Load);
            this.pnlFooter.ResumeLayout(false);
            this.pnlOnline.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnlCustomerDetails.ResumeLayout(false);
            this.pnlCustomerDetails.PerformLayout();
            this.pnlFinish.ResumeLayout(false);
            this.pnlFinish.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errPrvdr)).EndInit();
            this.pnlWelcome.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSide1;
        private System.Windows.Forms.Panel pnlFooter;
        private System.Windows.Forms.Panel pnlOnline;
        private atACCFramework.UserControls.atGroupBox pnlCustomerDetails;
        private atACCFramework.UserControls.TextBoxExt txtCustomerName;
        private atACCFramework.UserControls.atLabel atLabel1;
        private atACCFramework.UserControls.ComboBoxExt cmbEditions;
        private atACCFramework.UserControls.TextBoxExt txtBusinessType;
        private atACCFramework.UserControls.atLabel atLabel8;
        private atACCFramework.UserControls.TextBoxExt txtProductID;
        private atACCFramework.UserControls.atLabel atLabel2;
        private atACCFramework.UserControls.atLabel atLabel6;
        private atACCFramework.UserControls.TextBoxExt txtAddress;
        private atACCFramework.UserControls.atLabel lblCode;
        private atACCFramework.UserControls.atLabel atLabel3;
        private atACCFramework.UserControls.TextBoxExt txtCDKey;
        private atACCFramework.UserControls.TextBoxExt txtCity;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.atLabel atLabel4;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.TextBoxExt txtState;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.atLabel atLabel5;
        private atACCFramework.UserControls.TextBoxExt txtEmail;
        private atACCFramework.UserControls.ComboBoxExt CmbCountry;
        private atACCFramework.UserControls.atLabel lblEmail;
        private atACCFramework.UserControls.atLabel lblCountry;
        private atACCFramework.UserControls.atLabel lblMobileNumber;
        private System.Windows.Forms.Panel pnlFinish;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ErrorProvider errPrvdr;
        private System.Windows.Forms.GroupBox groupBox1;
        private atACCFramework.UserControls.TextBoxExt txtRegistrationNo;
        private atACCFramework.UserControls.atLabel lblHeading;
        private atACCFramework.UserControls.atButton btnFinish;
        private atACCFramework.UserControls.atButton btnBack;
        private atACCFramework.UserControls.atButton btnNext;
        private atACCFramework.UserControls.atButton btnCancel;
        private System.Windows.Forms.Panel pnlWelcome;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbldescript;
        private System.Windows.Forms.Label lblcap;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}