﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.CommonExtensions;
using atACCFramework.BaseClasses;
using atACC.Common;
using System.Data.SqlClient;
using atACC.Common.Classes;
using atACC.HTL.ORM;
using atACC.HTL.Masters.Classes;

namespace atACC.HTL.UI.UserControls
{
    public partial class atReminderDetailView : FormBase
    {
        #region Private Variables
        int ReminderID;
        string Message;
        string GuestName;
        string Room;
        string ReminderDate;
        atACCHotelEntities dbh;
        GuestReminder entGuestReminder;
        GuestReminderPending entGuestReminderPending;
        #endregion

        #region Constructor
        public atReminderDetailView(int _ReminderID,string _Message, string _GuestName,string _Room,string _ReminderDate)
        {
            InitializeComponent();
            ReminderID = _ReminderID;
            Message = _Message;
            GuestName = _GuestName;
            Room = _Room;
            ReminderDate = _ReminderDate;
        }
        #endregion

        #region Form Events
        private void atReminderDetailView_Load(object sender, EventArgs e)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                lblMessage.Text = Message;
                lblGuestName.Text = GuestName;
                lblRoomNo.Text = Room;
                lblReminderDate.Text = ReminderDate;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                entGuestReminder = dbh.GuestReminders.Where(x => x.id == ReminderID).SingleOrDefault();
                entGuestReminderPending = dbh.GuestReminderPendings.Where(x => x.FK_GuestReminderID == ReminderID).SingleOrDefault();

                entGuestReminder.Status = false;
                dbh.ObjectStateManager.ChangeObjectState(entGuestReminder, EntityState.Modified);
                dbh.DeleteObject(entGuestReminderPending);
                dbh.SaveChanges();
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
