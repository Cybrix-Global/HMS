﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.CommonExtensions;
using atACC.HTL.UI.UserControls;
using atACC.HTL.ORM;

namespace atACC.HTL.UI.UserControls
{
    public partial class atReminderListView : UserControl
    {   
        
        #region Public Variable
        public int ReminderID {set {lblMessage.Tag = value ; } get { return lblMessage.Tag.ToInt32(); } }
        public string GuestName { set { lblGuestName.Text = value; } }
        public string Message { set { lblMessage.Text = value; } }
        public string Room { set { lblRoomNo.Text = value; } }
        public DateTime ReminderDate { set { lblReminderDate.Text = value.ToString("dd-MM-yyyy hh:mm tt"); } }

        public event EventHandler RemoveReminder;
        #endregion

        #region Constructor
        public atReminderListView()
        {
            InitializeComponent();
        }
        #endregion

        #region Form Events
        private void atReminderListView_Load(object sender, EventArgs e)
        {

        }
        private void btnView_Click(object sender, EventArgs e)
        {
            atReminderDetailView frm = new atReminderDetailView(lblMessage.Tag.ToInt32(), lblMessage.Text, lblGuestName.Text,lblRoomNo.Text,lblReminderDate.Text);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                {
                    GuestReminder entGuestReminder = dbh.GuestReminders.Where(x=> x.id == ReminderID).SingleOrDefault();
                    GuestReminderPending entGuestReminderPending = dbh.GuestReminderPendings.Where(x => x.FK_GuestReminderID == ReminderID).SingleOrDefault();
                    if (entGuestReminder != null)
                    {
                        entGuestReminder.Status = false;
                        entGuestReminder.FK_ClosedUserID = atACC.Common.GlobalFunctions.LoginUserID;
                        dbh.ObjectStateManager.ChangeObjectState(entGuestReminder, EntityState.Modified);
                    }
                    if (entGuestReminderPending != null)
                        dbh.DeleteObject(entGuestReminderPending);
                    dbh.SaveChanges();
                    RemoveReminder(null, null);
                }
            }
            
        }
        #endregion
    }
}
