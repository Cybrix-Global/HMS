﻿namespace atACC.HTL.UI.UserControls
{
    partial class atReminderListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atReminderListView));
            this.grpReminder = new System.Windows.Forms.GroupBox();
            this.lblRoomNo = new System.Windows.Forms.Label();
            this.lblReminderDate = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.lblGuestName = new System.Windows.Forms.Label();
            this.grpReminder.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpReminder
            // 
            this.grpReminder.Controls.Add(this.lblRoomNo);
            this.grpReminder.Controls.Add(this.lblReminderDate);
            this.grpReminder.Controls.Add(this.btnView);
            this.grpReminder.Controls.Add(this.lblMessage);
            this.grpReminder.Controls.Add(this.lblGuestName);
            resources.ApplyResources(this.grpReminder, "grpReminder");
            this.grpReminder.Name = "grpReminder";
            this.grpReminder.TabStop = false;
            // 
            // lblRoomNo
            // 
            resources.ApplyResources(this.lblRoomNo, "lblRoomNo");
            this.lblRoomNo.Name = "lblRoomNo";
            // 
            // lblReminderDate
            // 
            resources.ApplyResources(this.lblReminderDate, "lblReminderDate");
            this.lblReminderDate.Name = "lblReminderDate";
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnView.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnView.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnView, "btnView");
            this.btnView.ForeColor = System.Drawing.Color.White;
            this.btnView.Name = "btnView";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // lblMessage
            // 
            resources.ApplyResources(this.lblMessage, "lblMessage");
            this.lblMessage.Name = "lblMessage";
            // 
            // lblGuestName
            // 
            resources.ApplyResources(this.lblGuestName, "lblGuestName");
            this.lblGuestName.Name = "lblGuestName";
            // 
            // atReminderListView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.grpReminder);
            this.Name = "atReminderListView";
            this.Load += new System.EventHandler(this.atReminderListView_Load);
            this.grpReminder.ResumeLayout(false);
            this.grpReminder.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpReminder;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label lblGuestName;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Label lblReminderDate;
        private System.Windows.Forms.Label lblRoomNo;
    }
}
