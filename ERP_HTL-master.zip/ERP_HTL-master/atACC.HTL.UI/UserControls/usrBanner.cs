﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCORM;
using atACC.Common;

namespace atACC.HTL.UI.UserControls
{
    public partial class usrBanner : UserControl
    {
        
        public usrBanner()
        {
            InitializeComponent();
            
        }
        public void ShowCompanyLogo()
        {
            atACCContextEntities db = atContext.CreateContext();
            Company _company = db.Companies.SingleOrDefault();
            //DashboardSingleton.Instance.picCompanyLogo.Image = null;
            if (_company.CompanyLogo != null)
            {
                picCompanyLogo.BackgroundImage = ANIHelper.byteArrayToImage(_company.CompanyLogo);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text=DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void usrBanner_Load(object sender, EventArgs e)
        {

        }
    }
}
