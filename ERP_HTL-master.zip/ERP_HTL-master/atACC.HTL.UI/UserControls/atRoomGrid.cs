﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.HTL.ORM;
using static System.Windows.Forms.DataGridView;

namespace atACC.HTL.UI.UserControls
{
    public partial class atRoomGrid : UserControl
    {
        #region Constructor
        public atRoomGrid()
        {
            InitializeComponent();
        }
        #endregion
        #region Public Properties
        public DataGridViewCell CurrentCell { get { return dgBody.CurrentCell; } set { dgBody.CurrentCell = value; } }
        public Rooms CurrentRoom
        {
            get
            {
                if (dgBody.CurrentCell == null) return new Rooms();
                else { return (Rooms)dgBody.Rows[dgBody.CurrentCell.RowIndex].Tag; }
            }
        }
        public DateTime? SelectedFromDate
        {
            get
            {
                DataGridViewCell[] cells = new DataGridViewCell[dgBody.SelectedCells.Count];
                dgBody.SelectedCells.CopyTo(cells, 0);
                int iMinIndex = cells.Select(x=> x.ColumnIndex).Min();
                if (dgBody.SelectedCells.Count > 0 && dgBody.Columns[iMinIndex].Tag != null)
                {
                    return (DateTime)dgBody.Columns[iMinIndex].Tag;
                }
                else
                { return null; }
                
            }
        }
        public DateTime? SelectedToDate
        {
            get
            {
                DataGridViewCell[] cells = new DataGridViewCell[dgBody.SelectedCells.Count];
                dgBody.SelectedCells.CopyTo(cells, 0);
                int iMaxIndex = cells.Select(x => x.ColumnIndex).Max();
                if (dgBody.SelectedCells.Count > 0 && dgBody.Columns[iMaxIndex].Tag != null)
                {
                    return ((DateTime)dgBody.Columns[iMaxIndex].Tag).AddDays(1);
                }
                else
                { return null; }
            }
        }
        #endregion
        #region Public Methods
        public void PopulateGrids(DateTime dtStart, int iCount, List<RoomStatusDTLClass> roomDTLs)
        {
            int iRoomColWidth = 120;
            int iDayColWidth = (dgHeader.Width - iRoomColWidth) / iCount;
            iDayColWidth -= iDayColWidth % 2; //convert to even no
            iRoomColWidth -= (iDayColWidth * iCount + iRoomColWidth - dgHeader.Width + 5) ; // Adjust Roundoff
                        
            if (iDayColWidth < 70) iDayColWidth = 70;
            DateTime dtDate = dtStart;
            string sDateFormat = "dd-MM-yyyy";
            dgHeader.Columns.Clear();
            dgHeader.Rows.Clear();
            dgBody.Columns.Clear();
            dgBody.Rows.Clear();
            
            dgHeader.Columns.Add("Rooms", "Rooms");
            dgBody.Columns.Add("Rooms", "Rooms");
            dgHeader.Columns["Rooms"].Width = dgBody.Columns["Rooms"].Width = iRoomColWidth;
            dgHeader.Columns["Rooms"].Frozen = dgBody.Columns["Rooms"].Frozen = true;
            dgBody.AlternatingRowsDefaultCellStyle = dgBody.DefaultCellStyle;
            for (int i = 0; i < iCount; i++)
            {                                
                dgHeader.Columns.Add(dtDate.ToString(sDateFormat), dtDate.ToShortDateString() + Environment.NewLine + dtDate.ToString("ddd"));
                dgHeader.Columns[dtDate.ToString(sDateFormat)].Width = iDayColWidth;                
                dgHeader.Columns[dtDate.ToString(sDateFormat)].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgHeader.Columns[dtDate.ToString(sDateFormat)].Tag = dtDate;
                if (i == 0)
                {
                    dgBody.Columns.Add(dtDate.AddDays(-1).ToString(sDateFormat), "");                                        
                    dgBody.Columns[dtDate.AddDays(-1).ToString(sDateFormat)].Width = iDayColWidth / 2;
                }
                dgBody.Columns.Add(dtDate.ToString(sDateFormat), "");                
                dgBody.Columns[dtDate.ToString(sDateFormat)].Width = (i==iCount - 1 ? iDayColWidth / 2 : iDayColWidth);
                dgBody.Columns[dtDate.ToString(sDateFormat)].Tag = dtDate;

                dtDate = dtDate.AddDays(1);
            }
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {                
                foreach (var roomDTL in roomDTLs.Select(x =>new { x.rooms, x.roomTypes }).ToList())
                {
                    Rooms room = roomDTL.rooms;
                    int iRow = dgBody.Rows.Add(room.Name);
                    dgBody.Rows[iRow].Tag = room; 
                    dgBody.Rows[iRow].Cells["Rooms"].Style.BackColor = Color.FromArgb(roomDTL.roomTypes.Color.Value);
                    dgBody.Rows[iRow].Cells["Rooms"].Style.ForeColor = roomDTL.roomTypes.Color.Value == -1 ? Color.Black : Color.White;
                    
                    var statusDTLs = (from statusRegister in GlobalMethods.GetRoomStatusByPeriod(dtStart, dtStart.AddDays(iCount))
                                          join statusColor in dbh.RoomStatusColorSettings on statusRegister.FK_StatusID equals statusColor.FK_RoomStatusID
                                          select new { statusRegister, statusColor }).ToList();
                    foreach (var statusDTL in statusDTLs.Where(x=> x.statusRegister.FK_RoomID == room.id).ToList())
                    {
                        Color color = Color.FromArgb(statusDTL.statusColor.Color.Value);
                        //Fill Arrival Date Column
                        string sColName = statusDTL.statusRegister.FromDate.Value.ToString(sDateFormat);
                        if (statusDTL.statusRegister.FromDate.Value.Date >= dtStart.AddDays(-1) && dgBody.Columns.Contains(sColName))
                        {
                            dgBody.Rows[iRow].Cells[sColName].Value = "";
                            dgBody.Rows[iRow].Cells[sColName].Tag = statusDTL.statusRegister;
                            dgBody.Rows[iRow].Cells[sColName].Style.BackColor = color;
                            dgBody.Rows[iRow].Cells[sColName].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                        }

                        //Fill Departure Date Column
                        sColName = statusDTL.statusRegister.ToDate.Value.AddDays(-1).ToString(sDateFormat);
                        if (statusDTL.statusRegister.ToDate.Value.Date <= dtStart.AddDays(iCount) && dgBody.Columns.Contains(sColName))
                        {
                            dgBody.Rows[iRow].Cells[sColName].Value = "";
                            dgBody.Rows[iRow].Cells[sColName].Tag = statusDTL.statusRegister;
                            dgBody.Rows[iRow].Cells[sColName].Style.BackColor = color;
                            dgBody.Rows[iRow].Cells[sColName].Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                        }

                        //Fill Date Column between Arrival Date And Departue Date
                        for (DateTime i = statusDTL.statusRegister.FromDate.Value.Date.AddDays(1); i < statusDTL.statusRegister.ToDate.Value.AddDays(-1).Date; i = i.AddDays(1))
                        {
                            sColName = i.ToString(sDateFormat);
                            if (dgBody.Columns.Contains(sColName))
                            {
                                dgBody.Rows[iRow].Cells[sColName].Tag = statusDTL.statusRegister;
                                dgBody.Rows[iRow].Cells[sColName].Style.BackColor = color;
                            }
                        }
                    }
                }
                
                
            }
            dgBody.CurrentCell = dgHeader.CurrentCell = null;
        }
        #endregion
        #region Grid Events
        private void dgBody_Scroll(object sender, ScrollEventArgs e)
        {            
            dgHeader.HorizontalScrollingOffset = dgBody.HorizontalScrollingOffset;
        }

        private void dgBody_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //DataGridViewAdvancedCellBorderStyle cellBorderStyle = DataGridViewAdvancedCellBorderStyle.Outset;
            //e.AdvancedBorderStyle.Right = cellBorderStyle;
            //e.AdvancedBorderStyle.Left = cellBorderStyle;
            //e.AdvancedBorderStyle.Top = cellBorderStyle;
            //e.AdvancedBorderStyle.Bottom = cellBorderStyle;
        }
        private void dgBody_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            OnMouseDoubleClick(e);
        }

        private void dgBody_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                HitTestInfo info = dgBody.HitTest(e.X, e.Y);
                if (info.Type == DataGridViewHitTestType.Cell && !dgBody.SelectedCells.Contains(dgBody.Rows[info.RowIndex].Cells[info.ColumnIndex]))
                    dgBody.CurrentCell = dgBody.Rows[info.RowIndex].Cells[info.ColumnIndex];
            }
            OnMouseClick(e);
        }
        #endregion




    }
}
