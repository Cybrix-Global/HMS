﻿namespace atACC.HTL.UI.UserControls
{
    partial class atRoomGrid
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgHeader = new atACCFramework.UserControls.atGridView();
            this.dgBody = new atACCFramework.UserControls.atGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgBody)).BeginInit();
            this.SuspendLayout();
            // 
            // dgHeader
            // 
            this.dgHeader.AllowUserToAddRows = false;
            this.dgHeader.AllowUserToOrderColumns = true;
            this.dgHeader.AllowUserToResizeColumns = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgHeader.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgHeader.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgHeader.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgHeader.ColumnHeadersHeight = 40;
            this.dgHeader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgHeader.EnableHeadersVisualStyles = false;
            this.dgHeader.EnterKeyNavigation = false;
            this.dgHeader.LastKey = System.Windows.Forms.Keys.None;
            this.dgHeader.Location = new System.Drawing.Point(0, 0);
            this.dgHeader.Name = "dgHeader";
            this.dgHeader.ReadOnly = true;
            this.dgHeader.RowHeadersVisible = false;
            this.dgHeader.sGridID = null;
            this.dgHeader.Size = new System.Drawing.Size(791, 40);
            this.dgHeader.TabIndex = 8;
            // 
            // dgBody
            // 
            this.dgBody.AllowUserToAddRows = false;
            this.dgBody.AllowUserToOrderColumns = true;
            this.dgBody.AllowUserToResizeColumns = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgBody.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgBody.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBody.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgBody.ColumnHeadersHeight = 31;
            this.dgBody.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgBody.ColumnHeadersVisible = false;
            this.dgBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgBody.EnableHeadersVisualStyles = false;
            this.dgBody.EnterKeyNavigation = false;
            this.dgBody.LastKey = System.Windows.Forms.Keys.None;
            this.dgBody.Location = new System.Drawing.Point(0, 40);
            this.dgBody.Name = "dgBody";
            this.dgBody.ReadOnly = true;
            this.dgBody.RowHeadersVisible = false;
            this.dgBody.sGridID = null;
            this.dgBody.Size = new System.Drawing.Size(791, 352);
            this.dgBody.TabIndex = 9;
            this.dgBody.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgBody_CellPainting);
            this.dgBody.Scroll += new System.Windows.Forms.ScrollEventHandler(this.dgBody_Scroll);
            this.dgBody.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgBody_MouseClick);
            this.dgBody.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dgBody_MouseDoubleClick);
            // 
            // atRoomGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dgBody);
            this.Controls.Add(this.dgHeader);
            this.Name = "atRoomGrid";
            this.Size = new System.Drawing.Size(791, 392);
            ((System.ComponentModel.ISupportInitialize)(this.dgHeader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgBody)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGridView dgHeader;
        private atACCFramework.UserControls.atGridView dgBody;
    }
}
