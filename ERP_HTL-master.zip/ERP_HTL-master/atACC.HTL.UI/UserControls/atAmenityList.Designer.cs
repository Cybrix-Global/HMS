﻿namespace atACC.HTL.UI.UserControls
{
    partial class atAmenityList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atAmenityList));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.atgradPanel = new atACCFramework.UserControls.atGradientPanel();
            this.lblDownArrow = new atACCFramework.UserControls.atLabel();
            this.lblUsrCap = new System.Windows.Forms.Label();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.cmbRoomType = new System.Windows.Forms.ComboBox();
            this.dgDetails = new System.Windows.Forms.DataGridView();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.atgradPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // atgradPanel
            // 
            resources.ApplyResources(this.atgradPanel, "atgradPanel");
            this.atgradPanel.AllowMultiSelect = false;
            this.atgradPanel.Angle = 110F;
            this.atgradPanel.BackColor = System.Drawing.Color.SteelBlue;
            this.atgradPanel.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(145)))), ((int)(((byte)(235)))));
            this.atgradPanel.Controls.Add(this.lblDownArrow);
            this.atgradPanel.Controls.Add(this.lblUsrCap);
            this.atgradPanel.Controls.Add(this.lblRoomType);
            this.atgradPanel.Controls.Add(this.cmbRoomType);
            this.atgradPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.atgradPanel.Name = "atgradPanel";
            this.atgradPanel.Selected = false;
            this.atgradPanel.TextAdjestmentHeight = 0;
            this.atgradPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.atgradPanel.TopColor = System.Drawing.Color.DarkOrange;
            // 
            // lblDownArrow
            // 
            resources.ApplyResources(this.lblDownArrow, "lblDownArrow");
            this.lblDownArrow.BackColor = System.Drawing.Color.Transparent;
            this.lblDownArrow.Name = "lblDownArrow";
            this.lblDownArrow.RequiredField = false;
            this.lblDownArrow.Click += new System.EventHandler(this.lblDownArrow_Click);
            // 
            // lblUsrCap
            // 
            resources.ApplyResources(this.lblUsrCap, "lblUsrCap");
            this.lblUsrCap.BackColor = System.Drawing.Color.Transparent;
            this.lblUsrCap.ForeColor = System.Drawing.Color.White;
            this.lblUsrCap.Name = "lblUsrCap";
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.BackColor = System.Drawing.Color.Transparent;
            this.lblRoomType.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // cmbRoomType
            // 
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.BackColor = System.Drawing.Color.White;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Name = "cmbRoomType";
            this.cmbRoomType.SelectedIndexChanged += new System.EventHandler(this.cmbRoomType_SelectedIndexChanged);
            // 
            // dgDetails
            // 
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.AllowUserToAddRows = false;
            this.dgDetails.AllowUserToDeleteRows = false;
            this.dgDetails.AllowUserToResizeColumns = false;
            this.dgDetails.AllowUserToResizeRows = false;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgDetails.BackgroundColor = System.Drawing.Color.White;
            this.dgDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colName,
            this.colDescription});
            this.dgDetails.Name = "dgDetails";
            this.dgDetails.RowHeadersVisible = false;
            // 
            // colName
            // 
            this.colName.DataPropertyName = "Name";
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9F);
            this.colName.DefaultCellStyle = dataGridViewCellStyle1;
            this.colName.FillWeight = 118.7817F;
            resources.ApplyResources(this.colName, "colName");
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colDescription
            // 
            this.colDescription.DataPropertyName = "Description";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9F);
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.colDescription.DefaultCellStyle = dataGridViewCellStyle2;
            this.colDescription.FillWeight = 81.21828F;
            resources.ApplyResources(this.colDescription, "colDescription");
            this.colDescription.Name = "colDescription";
            this.colDescription.ReadOnly = true;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.dgDetails);
            this.pnlMain.Name = "pnlMain";
            // 
            // atAmenityList
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.atgradPanel);
            this.Name = "atAmenityList";
            this.Load += new System.EventHandler(this.atAmenityList_Load);
            this.atgradPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel atgradPanel;
        public System.Windows.Forms.Label lblUsrCap;
        private System.Windows.Forms.DataGridView dgDetails;
        private System.Windows.Forms.ComboBox cmbRoomType;
        private atACCFramework.UserControls.atLabel lblDownArrow;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDescription;
        private atACCFramework.UserControls.atPanel pnlMain;
    }
}