﻿namespace atACC.HTL.UI.UserControls
{
    partial class atBookingReminder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atBookingReminder));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.atgradPanel = new atACCFramework.UserControls.atGradientPanel();
            this.lblUsrCap = new System.Windows.Forms.Label();
            this.dgDetails = new System.Windows.Forms.DataGridView();
            this.colGuest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColMobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColArrivalDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRoomType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRoom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.atgradPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // atgradPanel
            // 
            this.atgradPanel.AllowMultiSelect = false;
            this.atgradPanel.Angle = 110F;
            this.atgradPanel.BackColor = System.Drawing.Color.SteelBlue;
            this.atgradPanel.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(145)))), ((int)(((byte)(235)))));
            this.atgradPanel.Controls.Add(this.lblUsrCap);
            this.atgradPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.atgradPanel, "atgradPanel");
            this.atgradPanel.Name = "atgradPanel";
            this.atgradPanel.Selected = false;
            this.atgradPanel.TextAdjestmentHeight = 0;
            this.atgradPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.atgradPanel.TopColor = System.Drawing.Color.Firebrick;
            // 
            // lblUsrCap
            // 
            resources.ApplyResources(this.lblUsrCap, "lblUsrCap");
            this.lblUsrCap.BackColor = System.Drawing.Color.Transparent;
            this.lblUsrCap.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblUsrCap.ForeColor = System.Drawing.Color.White;
            this.lblUsrCap.Name = "lblUsrCap";
            // 
            // dgDetails
            // 
            this.dgDetails.AllowUserToAddRows = false;
            this.dgDetails.AllowUserToDeleteRows = false;
            this.dgDetails.AllowUserToResizeColumns = false;
            this.dgDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9F);
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgDetails.BackgroundColor = System.Drawing.Color.White;
            this.dgDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colGuest,
            this.ColMobile,
            this.ColArrivalDate,
            this.ColRoomType,
            this.ColRoom});
            this.dgDetails.Name = "dgDetails";
            this.dgDetails.RowHeadersVisible = false;
            // 
            // colGuest
            // 
            this.colGuest.DataPropertyName = "Guest";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9F);
            this.colGuest.DefaultCellStyle = dataGridViewCellStyle2;
            this.colGuest.FillWeight = 130F;
            resources.ApplyResources(this.colGuest, "colGuest");
            this.colGuest.Name = "colGuest";
            this.colGuest.ReadOnly = true;
            // 
            // ColMobile
            // 
            this.ColMobile.DataPropertyName = "Mobile";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColMobile.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColMobile.FillWeight = 120F;
            resources.ApplyResources(this.ColMobile, "ColMobile");
            this.ColMobile.Name = "ColMobile";
            this.ColMobile.ReadOnly = true;
            // 
            // ColArrivalDate
            // 
            this.ColArrivalDate.DataPropertyName = "ArrivalDate";
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColArrivalDate.DefaultCellStyle = dataGridViewCellStyle4;
            resources.ApplyResources(this.ColArrivalDate, "ColArrivalDate");
            this.ColArrivalDate.Name = "ColArrivalDate";
            this.ColArrivalDate.ReadOnly = true;
            // 
            // ColRoomType
            // 
            this.ColRoomType.DataPropertyName = "RoomType";
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColRoomType.DefaultCellStyle = dataGridViewCellStyle5;
            resources.ApplyResources(this.ColRoomType, "ColRoomType");
            this.ColRoomType.Name = "ColRoomType";
            this.ColRoomType.ReadOnly = true;
            // 
            // ColRoom
            // 
            this.ColRoom.DataPropertyName = "Room";
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColRoom.DefaultCellStyle = dataGridViewCellStyle6;
            resources.ApplyResources(this.ColRoom, "ColRoom");
            this.ColRoom.Name = "ColRoom";
            this.ColRoom.ReadOnly = true;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.dgDetails);
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.Name = "pnlMain";
            // 
            // atBookingReminder
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.atgradPanel);
            this.Name = "atBookingReminder";
            this.Load += new System.EventHandler(this.atBookingReminder_Load);
            this.atgradPanel.ResumeLayout(false);
            this.atgradPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel atgradPanel;
        public System.Windows.Forms.Label lblUsrCap;
        private System.Windows.Forms.DataGridView dgDetails;
        private atACCFramework.UserControls.atPanel pnlMain;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGuest;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColMobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColArrivalDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRoomType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRoom;
    }
}