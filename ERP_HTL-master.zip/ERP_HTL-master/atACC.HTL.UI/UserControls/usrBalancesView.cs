﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework;
using atACCFramework.Common;
using atACCORM;
using System.Data.SqlClient;
namespace atACC.HTL.UI.UserControls
{
    public partial class usrBalancesView : UserControl
    {
        public string spName { get; set; }
        public string m_NumberFormat;
        public usrBalancesView()
        {
            InitializeComponent();
            m_NumberFormat = "N" + GlobalFunctions.CompanyNoofDecimals;
            colBalance.DefaultCellStyle.Format = m_NumberFormat;
        }
        public void fnPopulateBalances(string _spName)
        {
            spName = _spName;
            fnPopulateBalances();
        }
        public void fnPopulateBalances()
        {
            if (spName == "") { return; }
            DataSet ds = new DataSet();
            SqlHelper _sqlhelper = new SqlHelper();
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("BranchID", GlobalFunctions.LoginLocationID));
            ds = _sqlhelper.ExecuteProcedure(spName, sqlParameters);
            
            dgDetails.AutoGenerateColumns = false;
            dgDetails.DataSource = ds.Tables[0];
            
        }
        private void lblERPCap_Click(object sender, EventArgs e)
        {

        }
    }
}
