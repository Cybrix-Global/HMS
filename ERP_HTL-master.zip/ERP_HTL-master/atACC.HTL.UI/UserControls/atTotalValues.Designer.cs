﻿namespace atACC.HTL.UI.UserControls
{
    partial class atTotalValues
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlTotalCheckOutHalls = new atACCFramework.UserControls.atGradientPanel();
            this.lblGpCheckOutPeriod = new atACCFramework.UserControls.atLabel();
            this.lblGpCheckOutCap = new atACCFramework.UserControls.atLabel();
            this.lblGpCheckOutTotal = new atACCFramework.UserControls.atLabel();
            this.cmbGpCheckOut = new atACCFramework.UserControls.ComboBoxExt();
            this.atLabel6 = new atACCFramework.UserControls.atLabel();
            this.pnlTotalCheckOutRooms = new atACCFramework.UserControls.atGradientPanel();
            this.lblCheckOutPeriod = new atACCFramework.UserControls.atLabel();
            this.lblCheckOutCap = new atACCFramework.UserControls.atLabel();
            this.lblCheckOutTotal = new atACCFramework.UserControls.atLabel();
            this.cmbCheckOut = new atACCFramework.UserControls.ComboBoxExt();
            this.atLabel4 = new atACCFramework.UserControls.atLabel();
            this.pnlTotalCheckInHalls = new atACCFramework.UserControls.atGradientPanel();
            this.lblGpCheckInPeriod = new atACCFramework.UserControls.atLabel();
            this.lblGpCheckInCap = new atACCFramework.UserControls.atLabel();
            this.lblGpCheckInTotal = new atACCFramework.UserControls.atLabel();
            this.cmbGpCheckIn = new atACCFramework.UserControls.ComboBoxExt();
            this.atLabel8 = new atACCFramework.UserControls.atLabel();
            this.pnlTotalCheckInRooms = new atACCFramework.UserControls.atGradientPanel();
            this.lblCheckInPeriod = new atACCFramework.UserControls.atLabel();
            this.cmbCheckIn = new atACCFramework.UserControls.ComboBoxExt();
            this.lblCheckInCap = new atACCFramework.UserControls.atLabel();
            this.lblCheckInTotal = new atACCFramework.UserControls.atLabel();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.pnlMain.SuspendLayout();
            this.pnlTotalCheckOutHalls.SuspendLayout();
            this.pnlTotalCheckOutRooms.SuspendLayout();
            this.pnlTotalCheckInHalls.SuspendLayout();
            this.pnlTotalCheckInRooms.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.pnlTotalCheckOutHalls);
            this.pnlMain.Controls.Add(this.pnlTotalCheckOutRooms);
            this.pnlMain.Controls.Add(this.pnlTotalCheckInHalls);
            this.pnlMain.Controls.Add(this.pnlTotalCheckInRooms);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(399, 202);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlTotalCheckOutHalls
            // 
            this.pnlTotalCheckOutHalls.AllowMultiSelect = false;
            this.pnlTotalCheckOutHalls.Angle = 45F;
            this.pnlTotalCheckOutHalls.BackColor = System.Drawing.Color.Aqua;
            this.pnlTotalCheckOutHalls.BottomColor = System.Drawing.Color.Salmon;
            this.pnlTotalCheckOutHalls.Controls.Add(this.lblGpCheckOutPeriod);
            this.pnlTotalCheckOutHalls.Controls.Add(this.lblGpCheckOutCap);
            this.pnlTotalCheckOutHalls.Controls.Add(this.lblGpCheckOutTotal);
            this.pnlTotalCheckOutHalls.Controls.Add(this.cmbGpCheckOut);
            this.pnlTotalCheckOutHalls.Controls.Add(this.atLabel6);
            this.pnlTotalCheckOutHalls.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlTotalCheckOutHalls.Location = new System.Drawing.Point(202, 104);
            this.pnlTotalCheckOutHalls.Name = "pnlTotalCheckOutHalls";
            this.pnlTotalCheckOutHalls.Selected = false;
            this.pnlTotalCheckOutHalls.Size = new System.Drawing.Size(192, 94);
            this.pnlTotalCheckOutHalls.TabIndex = 6;
            this.pnlTotalCheckOutHalls.TextAdjestmentHeight = 0;
            this.pnlTotalCheckOutHalls.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlTotalCheckOutHalls.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(25)))), ((int)(((byte)(160)))));
            // 
            // lblGpCheckOutPeriod
            // 
            this.lblGpCheckOutPeriod.AutoSize = true;
            this.lblGpCheckOutPeriod.BackColor = System.Drawing.Color.Transparent;
            this.lblGpCheckOutPeriod.Font = new System.Drawing.Font("Open Sans SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGpCheckOutPeriod.ForeColor = System.Drawing.Color.White;
            this.lblGpCheckOutPeriod.Location = new System.Drawing.Point(118, 70);
            this.lblGpCheckOutPeriod.Name = "lblGpCheckOutPeriod";
            this.lblGpCheckOutPeriod.RequiredField = false;
            this.lblGpCheckOutPeriod.Size = new System.Drawing.Size(44, 17);
            this.lblGpCheckOutPeriod.TabIndex = 10;
            this.lblGpCheckOutPeriod.Text = "Period";
            this.lblGpCheckOutPeriod.Click += new System.EventHandler(this.lblPeriod_Click);
            // 
            // lblGpCheckOutCap
            // 
            this.lblGpCheckOutCap.AutoSize = true;
            this.lblGpCheckOutCap.BackColor = System.Drawing.Color.Transparent;
            this.lblGpCheckOutCap.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGpCheckOutCap.ForeColor = System.Drawing.Color.Black;
            this.lblGpCheckOutCap.Location = new System.Drawing.Point(6, 69);
            this.lblGpCheckOutCap.Name = "lblGpCheckOutCap";
            this.lblGpCheckOutCap.RequiredField = false;
            this.lblGpCheckOutCap.Size = new System.Drawing.Size(36, 17);
            this.lblGpCheckOutCap.TabIndex = 2;
            this.lblGpCheckOutCap.Text = "Halls";
            // 
            // lblGpCheckOutTotal
            // 
            this.lblGpCheckOutTotal.AutoSize = true;
            this.lblGpCheckOutTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblGpCheckOutTotal.Font = new System.Drawing.Font("Open Sans SemiBold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGpCheckOutTotal.Location = new System.Drawing.Point(6, 27);
            this.lblGpCheckOutTotal.Name = "lblGpCheckOutTotal";
            this.lblGpCheckOutTotal.RequiredField = false;
            this.lblGpCheckOutTotal.Size = new System.Drawing.Size(34, 39);
            this.lblGpCheckOutTotal.TabIndex = 1;
            this.lblGpCheckOutTotal.Text = "1";
            this.lblGpCheckOutTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbGpCheckOut
            // 
            this.cmbGpCheckOut.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGpCheckOut.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGpCheckOut.BackColor = System.Drawing.Color.Salmon;
            this.cmbGpCheckOut.DropDownHeight = 300;
            this.cmbGpCheckOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbGpCheckOut.Font = new System.Drawing.Font("Open Sans", 8.25F);
            this.cmbGpCheckOut.FormattingEnabled = true;
            this.cmbGpCheckOut.IntegralHeight = false;
            this.cmbGpCheckOut.Location = new System.Drawing.Point(156, 7);
            this.cmbGpCheckOut.Name = "cmbGpCheckOut";
            this.cmbGpCheckOut.Size = new System.Drawing.Size(29, 23);
            this.cmbGpCheckOut.TabIndex = 9;
            this.cmbGpCheckOut.Visible = false;
            this.cmbGpCheckOut.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // atLabel6
            // 
            this.atLabel6.AutoSize = true;
            this.atLabel6.BackColor = System.Drawing.Color.Transparent;
            this.atLabel6.Font = new System.Drawing.Font("Open Sans SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel6.ForeColor = System.Drawing.Color.White;
            this.atLabel6.Location = new System.Drawing.Point(3, 7);
            this.atLabel6.Name = "atLabel6";
            this.atLabel6.RequiredField = false;
            this.atLabel6.Size = new System.Drawing.Size(145, 20);
            this.atLabel6.TabIndex = 0;
            this.atLabel6.Text = "Total G. Check Out";
            // 
            // pnlTotalCheckOutRooms
            // 
            this.pnlTotalCheckOutRooms.AllowMultiSelect = false;
            this.pnlTotalCheckOutRooms.Angle = 110F;
            this.pnlTotalCheckOutRooms.BackColor = System.Drawing.Color.Aqua;
            this.pnlTotalCheckOutRooms.BottomColor = System.Drawing.Color.Magenta;
            this.pnlTotalCheckOutRooms.Controls.Add(this.lblCheckOutPeriod);
            this.pnlTotalCheckOutRooms.Controls.Add(this.lblCheckOutCap);
            this.pnlTotalCheckOutRooms.Controls.Add(this.lblCheckOutTotal);
            this.pnlTotalCheckOutRooms.Controls.Add(this.cmbCheckOut);
            this.pnlTotalCheckOutRooms.Controls.Add(this.atLabel4);
            this.pnlTotalCheckOutRooms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlTotalCheckOutRooms.Location = new System.Drawing.Point(202, 4);
            this.pnlTotalCheckOutRooms.Name = "pnlTotalCheckOutRooms";
            this.pnlTotalCheckOutRooms.Selected = false;
            this.pnlTotalCheckOutRooms.Size = new System.Drawing.Size(192, 94);
            this.pnlTotalCheckOutRooms.TabIndex = 4;
            this.pnlTotalCheckOutRooms.TextAdjestmentHeight = 0;
            this.pnlTotalCheckOutRooms.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlTotalCheckOutRooms.TopColor = System.Drawing.Color.RoyalBlue;
            // 
            // lblCheckOutPeriod
            // 
            this.lblCheckOutPeriod.AutoSize = true;
            this.lblCheckOutPeriod.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckOutPeriod.Font = new System.Drawing.Font("Open Sans SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckOutPeriod.ForeColor = System.Drawing.Color.White;
            this.lblCheckOutPeriod.Location = new System.Drawing.Point(116, 71);
            this.lblCheckOutPeriod.Name = "lblCheckOutPeriod";
            this.lblCheckOutPeriod.RequiredField = false;
            this.lblCheckOutPeriod.Size = new System.Drawing.Size(44, 17);
            this.lblCheckOutPeriod.TabIndex = 7;
            this.lblCheckOutPeriod.Text = "Period";
            this.lblCheckOutPeriod.Click += new System.EventHandler(this.lblPeriod_Click);
            // 
            // lblCheckOutCap
            // 
            this.lblCheckOutCap.AutoSize = true;
            this.lblCheckOutCap.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckOutCap.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckOutCap.ForeColor = System.Drawing.Color.Black;
            this.lblCheckOutCap.Location = new System.Drawing.Point(6, 70);
            this.lblCheckOutCap.Name = "lblCheckOutCap";
            this.lblCheckOutCap.RequiredField = false;
            this.lblCheckOutCap.Size = new System.Drawing.Size(46, 17);
            this.lblCheckOutCap.TabIndex = 2;
            this.lblCheckOutCap.Text = "Rooms";
            // 
            // lblCheckOutTotal
            // 
            this.lblCheckOutTotal.AutoSize = true;
            this.lblCheckOutTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckOutTotal.Font = new System.Drawing.Font("Open Sans SemiBold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckOutTotal.Location = new System.Drawing.Point(6, 33);
            this.lblCheckOutTotal.Name = "lblCheckOutTotal";
            this.lblCheckOutTotal.RequiredField = false;
            this.lblCheckOutTotal.Size = new System.Drawing.Size(51, 39);
            this.lblCheckOutTotal.TabIndex = 1;
            this.lblCheckOutTotal.Text = "80";
            this.lblCheckOutTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbCheckOut
            // 
            this.cmbCheckOut.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCheckOut.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCheckOut.BackColor = System.Drawing.Color.RoyalBlue;
            this.cmbCheckOut.DropDownHeight = 300;
            this.cmbCheckOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCheckOut.Font = new System.Drawing.Font("Open Sans", 8.25F);
            this.cmbCheckOut.FormattingEnabled = true;
            this.cmbCheckOut.IntegralHeight = false;
            this.cmbCheckOut.Location = new System.Drawing.Point(160, 4);
            this.cmbCheckOut.Name = "cmbCheckOut";
            this.cmbCheckOut.Size = new System.Drawing.Size(29, 23);
            this.cmbCheckOut.TabIndex = 6;
            this.cmbCheckOut.Visible = false;
            this.cmbCheckOut.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // atLabel4
            // 
            this.atLabel4.AutoSize = true;
            this.atLabel4.BackColor = System.Drawing.Color.Transparent;
            this.atLabel4.Font = new System.Drawing.Font("Open Sans SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel4.ForeColor = System.Drawing.Color.White;
            this.atLabel4.Location = new System.Drawing.Point(3, 5);
            this.atLabel4.Name = "atLabel4";
            this.atLabel4.RequiredField = false;
            this.atLabel4.Size = new System.Drawing.Size(126, 20);
            this.atLabel4.TabIndex = 0;
            this.atLabel4.Text = "Total Check Out";
            // 
            // pnlTotalCheckInHalls
            // 
            this.pnlTotalCheckInHalls.AllowMultiSelect = false;
            this.pnlTotalCheckInHalls.Angle = 45F;
            this.pnlTotalCheckInHalls.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlTotalCheckInHalls.BottomColor = System.Drawing.Color.SpringGreen;
            this.pnlTotalCheckInHalls.Controls.Add(this.lblGpCheckInPeriod);
            this.pnlTotalCheckInHalls.Controls.Add(this.lblGpCheckInCap);
            this.pnlTotalCheckInHalls.Controls.Add(this.lblGpCheckInTotal);
            this.pnlTotalCheckInHalls.Controls.Add(this.cmbGpCheckIn);
            this.pnlTotalCheckInHalls.Controls.Add(this.atLabel8);
            this.pnlTotalCheckInHalls.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlTotalCheckInHalls.Location = new System.Drawing.Point(4, 103);
            this.pnlTotalCheckInHalls.Name = "pnlTotalCheckInHalls";
            this.pnlTotalCheckInHalls.Selected = false;
            this.pnlTotalCheckInHalls.Size = new System.Drawing.Size(192, 94);
            this.pnlTotalCheckInHalls.TabIndex = 5;
            this.pnlTotalCheckInHalls.TextAdjestmentHeight = 0;
            this.pnlTotalCheckInHalls.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlTotalCheckInHalls.TopColor = System.Drawing.Color.DodgerBlue;
            // 
            // lblGpCheckInPeriod
            // 
            this.lblGpCheckInPeriod.AutoSize = true;
            this.lblGpCheckInPeriod.BackColor = System.Drawing.Color.Transparent;
            this.lblGpCheckInPeriod.Font = new System.Drawing.Font("Open Sans SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGpCheckInPeriod.ForeColor = System.Drawing.Color.White;
            this.lblGpCheckInPeriod.Location = new System.Drawing.Point(116, 71);
            this.lblGpCheckInPeriod.Name = "lblGpCheckInPeriod";
            this.lblGpCheckInPeriod.RequiredField = false;
            this.lblGpCheckInPeriod.Size = new System.Drawing.Size(44, 17);
            this.lblGpCheckInPeriod.TabIndex = 11;
            this.lblGpCheckInPeriod.Text = "Period";
            this.lblGpCheckInPeriod.Click += new System.EventHandler(this.lblPeriod_Click);
            // 
            // lblGpCheckInCap
            // 
            this.lblGpCheckInCap.AutoSize = true;
            this.lblGpCheckInCap.BackColor = System.Drawing.Color.Transparent;
            this.lblGpCheckInCap.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGpCheckInCap.ForeColor = System.Drawing.Color.Black;
            this.lblGpCheckInCap.Location = new System.Drawing.Point(5, 70);
            this.lblGpCheckInCap.Name = "lblGpCheckInCap";
            this.lblGpCheckInCap.RequiredField = false;
            this.lblGpCheckInCap.Size = new System.Drawing.Size(46, 17);
            this.lblGpCheckInCap.TabIndex = 10;
            this.lblGpCheckInCap.Text = "Rooms";
            // 
            // lblGpCheckInTotal
            // 
            this.lblGpCheckInTotal.AutoSize = true;
            this.lblGpCheckInTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblGpCheckInTotal.Font = new System.Drawing.Font("Open Sans SemiBold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGpCheckInTotal.Location = new System.Drawing.Point(5, 29);
            this.lblGpCheckInTotal.Name = "lblGpCheckInTotal";
            this.lblGpCheckInTotal.RequiredField = false;
            this.lblGpCheckInTotal.Size = new System.Drawing.Size(85, 39);
            this.lblGpCheckInTotal.TabIndex = 9;
            this.lblGpCheckInTotal.Text = "1200";
            this.lblGpCheckInTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbGpCheckIn
            // 
            this.cmbGpCheckIn.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGpCheckIn.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGpCheckIn.BackColor = System.Drawing.Color.Aquamarine;
            this.cmbGpCheckIn.DropDownHeight = 300;
            this.cmbGpCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbGpCheckIn.Font = new System.Drawing.Font("Open Sans", 8.25F);
            this.cmbGpCheckIn.FormattingEnabled = true;
            this.cmbGpCheckIn.IntegralHeight = false;
            this.cmbGpCheckIn.Location = new System.Drawing.Point(160, 5);
            this.cmbGpCheckIn.Name = "cmbGpCheckIn";
            this.cmbGpCheckIn.Size = new System.Drawing.Size(29, 23);
            this.cmbGpCheckIn.TabIndex = 6;
            this.cmbGpCheckIn.Visible = false;
            this.cmbGpCheckIn.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // atLabel8
            // 
            this.atLabel8.AutoSize = true;
            this.atLabel8.BackColor = System.Drawing.Color.Transparent;
            this.atLabel8.Font = new System.Drawing.Font("Open Sans SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel8.ForeColor = System.Drawing.Color.White;
            this.atLabel8.Location = new System.Drawing.Point(3, 5);
            this.atLabel8.Name = "atLabel8";
            this.atLabel8.RequiredField = false;
            this.atLabel8.Size = new System.Drawing.Size(132, 20);
            this.atLabel8.TabIndex = 0;
            this.atLabel8.Text = "Total G. Check In";
            // 
            // pnlTotalCheckInRooms
            // 
            this.pnlTotalCheckInRooms.AllowMultiSelect = false;
            this.pnlTotalCheckInRooms.Angle = 110F;
            this.pnlTotalCheckInRooms.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlTotalCheckInRooms.BottomColor = System.Drawing.Color.Turquoise;
            this.pnlTotalCheckInRooms.Controls.Add(this.lblCheckInPeriod);
            this.pnlTotalCheckInRooms.Controls.Add(this.cmbCheckIn);
            this.pnlTotalCheckInRooms.Controls.Add(this.lblCheckInCap);
            this.pnlTotalCheckInRooms.Controls.Add(this.lblCheckInTotal);
            this.pnlTotalCheckInRooms.Controls.Add(this.atLabel1);
            this.pnlTotalCheckInRooms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlTotalCheckInRooms.Location = new System.Drawing.Point(4, 4);
            this.pnlTotalCheckInRooms.Name = "pnlTotalCheckInRooms";
            this.pnlTotalCheckInRooms.Selected = false;
            this.pnlTotalCheckInRooms.Size = new System.Drawing.Size(192, 94);
            this.pnlTotalCheckInRooms.TabIndex = 3;
            this.pnlTotalCheckInRooms.TextAdjestmentHeight = 0;
            this.pnlTotalCheckInRooms.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlTotalCheckInRooms.TopColor = System.Drawing.Color.DeepSkyBlue;
            // 
            // lblCheckInPeriod
            // 
            this.lblCheckInPeriod.AutoSize = true;
            this.lblCheckInPeriod.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckInPeriod.Font = new System.Drawing.Font("Open Sans SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckInPeriod.ForeColor = System.Drawing.Color.White;
            this.lblCheckInPeriod.Location = new System.Drawing.Point(116, 70);
            this.lblCheckInPeriod.Name = "lblCheckInPeriod";
            this.lblCheckInPeriod.RequiredField = false;
            this.lblCheckInPeriod.Size = new System.Drawing.Size(44, 17);
            this.lblCheckInPeriod.TabIndex = 4;
            this.lblCheckInPeriod.Text = "Period";
            this.lblCheckInPeriod.Click += new System.EventHandler(this.lblPeriod_Click);
            // 
            // cmbCheckIn
            // 
            this.cmbCheckIn.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCheckIn.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCheckIn.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.cmbCheckIn.DropDownHeight = 300;
            this.cmbCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCheckIn.Font = new System.Drawing.Font("Open Sans", 8.25F);
            this.cmbCheckIn.FormattingEnabled = true;
            this.cmbCheckIn.IntegralHeight = false;
            this.cmbCheckIn.Location = new System.Drawing.Point(160, 4);
            this.cmbCheckIn.Name = "cmbCheckIn";
            this.cmbCheckIn.Size = new System.Drawing.Size(29, 23);
            this.cmbCheckIn.TabIndex = 3;
            this.cmbCheckIn.Visible = false;
            this.cmbCheckIn.SelectedValueChanged += new System.EventHandler(this.cmb_SelectedValueChanged);
            // 
            // lblCheckInCap
            // 
            this.lblCheckInCap.AutoSize = true;
            this.lblCheckInCap.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckInCap.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckInCap.ForeColor = System.Drawing.Color.Black;
            this.lblCheckInCap.Location = new System.Drawing.Point(5, 71);
            this.lblCheckInCap.Name = "lblCheckInCap";
            this.lblCheckInCap.RequiredField = false;
            this.lblCheckInCap.Size = new System.Drawing.Size(46, 17);
            this.lblCheckInCap.TabIndex = 2;
            this.lblCheckInCap.Text = "Rooms";
            // 
            // lblCheckInTotal
            // 
            this.lblCheckInTotal.AutoSize = true;
            this.lblCheckInTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckInTotal.Font = new System.Drawing.Font("Open Sans SemiBold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckInTotal.Location = new System.Drawing.Point(5, 30);
            this.lblCheckInTotal.Name = "lblCheckInTotal";
            this.lblCheckInTotal.RequiredField = false;
            this.lblCheckInTotal.Size = new System.Drawing.Size(85, 39);
            this.lblCheckInTotal.TabIndex = 1;
            this.lblCheckInTotal.Text = "1200";
            this.lblCheckInTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // atLabel1
            // 
            this.atLabel1.AutoSize = true;
            this.atLabel1.BackColor = System.Drawing.Color.Transparent;
            this.atLabel1.Font = new System.Drawing.Font("Open Sans SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atLabel1.ForeColor = System.Drawing.Color.White;
            this.atLabel1.Location = new System.Drawing.Point(3, 6);
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            this.atLabel1.Size = new System.Drawing.Size(113, 20);
            this.atLabel1.TabIndex = 0;
            this.atLabel1.Text = "Total Check In";
            // 
            // atTotalValues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Margin = new System.Windows.Forms.Padding(5, 5, 0, 5);
            this.Name = "atTotalValues";
            this.Size = new System.Drawing.Size(399, 202);
            this.pnlMain.ResumeLayout(false);
            this.pnlTotalCheckOutHalls.ResumeLayout(false);
            this.pnlTotalCheckOutHalls.PerformLayout();
            this.pnlTotalCheckOutRooms.ResumeLayout(false);
            this.pnlTotalCheckOutRooms.PerformLayout();
            this.pnlTotalCheckInHalls.ResumeLayout(false);
            this.pnlTotalCheckInHalls.PerformLayout();
            this.pnlTotalCheckInRooms.ResumeLayout(false);
            this.pnlTotalCheckInRooms.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private atACCFramework.UserControls.atGradientPanel pnlTotalCheckInRooms;
        private atACCFramework.UserControls.atLabel lblCheckInCap;
        private atACCFramework.UserControls.atLabel lblCheckInTotal;
        private atACCFramework.UserControls.atLabel atLabel1;
        private atACCFramework.UserControls.atGradientPanel pnlTotalCheckOutHalls;
        private atACCFramework.UserControls.atLabel lblGpCheckOutCap;
        private atACCFramework.UserControls.atLabel lblGpCheckOutTotal;
        private atACCFramework.UserControls.atLabel atLabel6;
        private atACCFramework.UserControls.atGradientPanel pnlTotalCheckOutRooms;
        private atACCFramework.UserControls.atLabel lblCheckOutCap;
        private atACCFramework.UserControls.atLabel lblCheckOutTotal;
        private atACCFramework.UserControls.atLabel atLabel4;
        private atACCFramework.UserControls.atGradientPanel pnlTotalCheckInHalls;
        private atACCFramework.UserControls.atLabel atLabel8;
        private atACCFramework.UserControls.ComboBoxExt cmbCheckIn;
        private atACCFramework.UserControls.ComboBoxExt cmbGpCheckOut;
        private atACCFramework.UserControls.ComboBoxExt cmbCheckOut;
        private atACCFramework.UserControls.ComboBoxExt cmbGpCheckIn;
        private atACCFramework.UserControls.atLabel lblGpCheckInCap;
        private atACCFramework.UserControls.atLabel lblGpCheckInTotal;
        private atACCFramework.UserControls.atLabel lblGpCheckOutPeriod;
        private atACCFramework.UserControls.atLabel lblCheckOutPeriod;
        private atACCFramework.UserControls.atLabel lblGpCheckInPeriod;
        private atACCFramework.UserControls.atLabel lblCheckInPeriod;
    }
}
