﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.HTL.ORM;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.BaseClasses;

namespace atACC.HTL.UI.UserControls
{
    public partial class atTotalValues : UserControl
    {
        #region Private Variables
        enum ENPeriod
        {
            Week = 1,
            Month,
            Year
        }
        #endregion
        #region Constructor
        public atTotalValues()
        {
            InitializeComponent();
            PopulateCombos();
        }
        #endregion
        #region Private Methods
        private void PopulateCombos()
        {
            List<MasterValue> masterValues = new List<MasterValue>()
            {
                new MasterValue(){ id = 1, Name = MessageKeys.MsgLastWeek },
                new MasterValue(){ id = 2, Name = MessageKeys.MsgThisMonth},
                new MasterValue(){ id = 3, Name = MessageKeys.MsgThisYear}
            };
            cmbCheckIn.DisplayMember = cmbCheckOut.DisplayMember =
                cmbGpCheckIn.DisplayMember = cmbGpCheckOut.DisplayMember = "Name";
            cmbCheckIn.ValueMember = cmbCheckOut.ValueMember =
                cmbGpCheckIn.ValueMember = cmbGpCheckOut.ValueMember = "id";
            cmbCheckIn.DataSource = masterValues.ToList();
            cmbCheckOut.DataSource = masterValues.ToList();
            cmbGpCheckIn.DataSource = masterValues.ToList();
            cmbGpCheckOut.DataSource = masterValues.ToList();

            cmbCheckIn.SelectedValue = cmbCheckOut.SelectedValue =
                cmbGpCheckIn.SelectedValue = cmbGpCheckOut.SelectedValue = 1;
            lblCheckInPeriod.Text = cmbCheckIn.Text;
            lblGpCheckInPeriod.Text = cmbGpCheckIn.Text;
            lblCheckOutPeriod.Text = cmbCheckOut.Text;
            lblGpCheckOutPeriod.Text = cmbGpCheckOut.Text;

            lblCheckInPeriod.Tag = cmbCheckIn;
            lblGpCheckInPeriod.Tag = cmbGpCheckIn;
            lblCheckOutPeriod.Tag = cmbCheckOut;
            lblGpCheckOutPeriod.Tag = cmbGpCheckOut;
        }
        private void ChangeComboSelectedValue( Label label)
        {
            ComboBox cmb = (ComboBox)label.Tag;
            int i = cmb.SelectedValue.ToInt32();
            i++;
            if (i > cmb.Items.Count) i = 1;
            cmb.SelectedValue = i;
            label.Text = cmb.Text;
        }
        #endregion
        #region Events
        private void lblPeriod_Click(object sender, EventArgs e)
        {
            ChangeComboSelectedValue((Label)sender);
        }
        private void cmb_SelectedValueChanged(object sender, EventArgs e)
        {
            DateTime dtFrom, dtTo;
            ComboBox cmb = (ComboBox)sender;
            switch (cmb.SelectedValue.ToInt32())
            {
                case (int)ENPeriod.Week:
                    dtFrom = DateTime.Now.Date.AddDays(-7);
                    break;
                case (int)ENPeriod.Month:
                    dtFrom = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                    break;
                case (int)ENPeriod.Year:
                    dtFrom = new DateTime(DateTime.Now.Year, 1, 1);
                    break;
                default:
                    dtFrom = DateTime.Now.Date;
                    break;
            }
            dtTo = DateTime.Now.ToEnd();
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                if (cmb.Name == cmbCheckIn.Name)
                {
                    var dtl = (from c in dbh.CheckIns
                               join r in dbh.Rooms on c.FK_RoomID equals r.id
                               where c.ArrivalDate >= dtFrom && c.ArrivalDate <= dtTo && c.Cancelled == false
                               select new { r }).ToList();
                    int iRooms = dtl.Where(x => x.r.IsHall == false).Count();
                    int iHalls = dtl.Where(x => x.r.IsHall == true).Count();
                    lblCheckInTotal.Text = iRooms.ToString();
                    lblCheckInCap.Text = MessageKeys.MsgRooms;
                    if(iHalls > 0)
                    {
                        lblCheckInTotal.Text += " / " + iHalls.ToString();
                        lblCheckInCap.Text += " / " + MessageKeys.MsgHalls;
                    }
                }
                else if (cmb.Name == cmbCheckOut.Name)
                {
                    var dtl = (from co in dbh.CheckOuts
                               join ci in dbh.CheckIns on co.FK_CheckInID equals ci.id
                               join r in dbh.Rooms on ci.FK_RoomID equals r.id
                               where ci.DepartureDate >= dtFrom && ci.DepartureDate <= dtTo && co.Cancelled == false
                               select new { r }).ToList();
                    int iRooms = dtl.Where(x => x.r.IsHall == false).Count();
                    int iHalls = dtl.Where(x => x.r.IsHall == true).Count();
                    lblCheckOutTotal.Text = iRooms.ToString();
                    lblCheckOutCap.Text = MessageKeys.MsgRooms;
                    if (iHalls > 0)
                    {
                        lblCheckOutTotal.Text += " / " + iHalls.ToString();
                        lblCheckOutCap.Text += " / " + MessageKeys.MsgHalls;
                    }
                }
                else if (cmb.Name == cmbGpCheckIn.Name)
                {
                    var dtl = (from ci in dbh.GroupCheckIns 
                               join cd in dbh.GroupCheckInDTLs on ci.id equals cd.FK_GroupCheckInID
                               join r in dbh.Rooms on cd.FK_RoomID equals r.id
                               where ci.ArrivalDate >= dtFrom && ci.ArrivalDate <= dtTo && ci.Cancelled == false
                               select new { r }).ToList();
                    int iRooms = dtl.Where(x => x.r.IsHall == false).Count();
                    int iHalls = dtl.Where(x => x.r.IsHall == true).Count();
                    lblGpCheckInTotal.Text = iRooms.ToString();
                    lblGpCheckInCap.Text = MessageKeys.MsgRooms;
                    if (iHalls > 0)
                    {
                        lblGpCheckInTotal.Text += " / " + iHalls.ToString();
                        lblGpCheckInCap.Text += " / " + MessageKeys.MsgHalls;
                    }
                }
                else if (cmb.Name == cmbGpCheckOut.Name)
                {
                    var dtl = (from co in dbh.GroupCheckOuts
                               join ci in dbh.GroupCheckIns on co.FK_GroupCheckInID equals ci.id
                               join cd in dbh.GroupCheckInDTLs on ci.id equals cd.FK_GroupCheckInID
                               join r in dbh.Rooms on cd.FK_RoomID equals r.id
                               where ci.DepartureDate >= dtFrom && ci.DepartureDate <= dtTo && co.Cancelled == false
                               select new { r }).ToList();
                    int iRooms = dtl.Where(x => x.r.IsHall == false).Count();
                    int iHalls = dtl.Where(x => x.r.IsHall == true).Count();
                    lblGpCheckOutTotal.Text = iRooms.ToString();
                    lblGpCheckOutCap.Text = MessageKeys.MsgRooms;
                    if (iHalls > 0)
                    {
                        lblGpCheckOutTotal.Text += " / " + iHalls.ToString();
                        lblGpCheckOutCap.Text += " / " + MessageKeys.MsgHalls;
                    }
                }
            }
        }
        #endregion


    }
}
