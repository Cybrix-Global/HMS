﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.CommonExtensions;
using atACCORM;
using atACC.Common;
using atACC.HTL.ORM;

namespace atACC.HTL.UI.UserControls
{
    public partial class atRoomView : UserControl
    {
        public atRoomView()
        {
            InitializeComponent();
        }
        #region Public Properties
        public int RoomID { get; set; }
        public int FK_TransactionTypeID { get; set; }
        public int FK_TransactionID { get; set; }
        public string RoomName { set { lblRoomNo.Text = value; } }
        public string GuestName { set { lblGuestName.Text = value; } }
        public Image RoomTypeImage { set { pcImage.BackgroundImage = value; } }
        public int Adults { set { lblNoPersons.Text = value.ToString(); } }
        public int Childs { set { lblChild.Text = value.ToString(); } }
        public DateTime ArrivalDate { set { lblArrivedDate.Text = value.ToString("dd-MM-yyyy hh:mm tt"); } }
        public DateTime DepartureDate { set { lblDepartureDate.Text = value.ToString("dd-MM-yyyy hh:mm tt"); } }
        public string StatusName { set { lblStatus.Text = value; } }
        public Color StatusColor { set { pnlColor.BackColor = value; } }
        public bool HideArrivalDepartureDates { set { lblArrivedDate.Visible = lblDepartureDate.Visible = !value; } }
        #endregion
        #region Events
        private void btnCommon_MouseClick(object sender, MouseEventArgs e)
        {
            OnMouseClick(e);
        }

        private void btnCommon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            OnMouseDoubleClick(e);
        }
        #endregion
    }
}
