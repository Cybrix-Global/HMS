﻿namespace atACC.HTL.UI.UserControls
{
    partial class atFavoritesButton
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atFavoritesButton));
            this.lblCaption = new atACCFramework.UserControls.atLabel();
            this.picMenuImage = new atACC.HTL.UI.UserControls.atRoundPictureBox();
            this.SuspendLayout();
            // 
            // lblCaption
            // 
            this.lblCaption.BackColor = System.Drawing.Color.Transparent;
            this.lblCaption.Font = new System.Drawing.Font("Open Sans SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCaption.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCaption.Location = new System.Drawing.Point(0, 43);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.RequiredField = false;
            this.lblCaption.Size = new System.Drawing.Size(65, 20);
            this.lblCaption.TabIndex = 173;
            this.lblCaption.Text = "Add";
            this.lblCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCaption.Click += new System.EventHandler(this.lblCaption_Click);
            this.lblCaption.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseClick);
            this.lblCaption.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseDown);
            // 
            // picMenuImage
            // 
            this.picMenuImage.BackColor = System.Drawing.Color.White;
            this.picMenuImage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picMenuImage.FlatAppearance.BorderSize = 0;
            this.picMenuImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue;
            this.picMenuImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.picMenuImage.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.picMenuImage.Image = ((System.Drawing.Image)(resources.GetObject("picMenuImage.Image")));
            this.picMenuImage.Location = new System.Drawing.Point(11, 2);
            this.picMenuImage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picMenuImage.Name = "picMenuImage";
            this.picMenuImage.Size = new System.Drawing.Size(43, 41);
            this.picMenuImage.TabIndex = 0;
            this.picMenuImage.UseVisualStyleBackColor = false;
            this.picMenuImage.Click += new System.EventHandler(this.lblCaption_Click);
            this.picMenuImage.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseClick);
            this.picMenuImage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseDown);
            // 
            // atFavoritesButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.picMenuImage);
            this.Controls.Add(this.lblCaption);
            this.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "atFavoritesButton";
            this.Size = new System.Drawing.Size(65, 65);
            this.Click += new System.EventHandler(this.lblCaption_Click);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseDown);
            this.ResumeLayout(false);

        }

        #endregion
        private atACCFramework.UserControls.atLabel lblCaption;
        public atRoundPictureBox picMenuImage;
    }
}
