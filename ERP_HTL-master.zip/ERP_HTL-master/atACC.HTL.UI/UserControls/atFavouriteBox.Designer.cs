﻿namespace atACC.HTL.UI.UserControls
{
    partial class atFavouriteBox
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atFavouriteBox));
            this.FavIcon = new atACCFramework.UserControls.atRoundPictureBox();
            this.lblFavCaption = new atACCFramework.UserControls.atLabel();
            this.SuspendLayout();
            // 
            // FavIcon
            // 
            this.FavIcon.BackColor = System.Drawing.Color.White;
            this.FavIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.FavIcon.FlatAppearance.BorderSize = 0;
            this.FavIcon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FavIcon.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FavIcon.Image = ((System.Drawing.Image)(resources.GetObject("FavIcon.Image")));
            this.FavIcon.Location = new System.Drawing.Point(11, 2);
            this.FavIcon.Name = "FavIcon";
            this.FavIcon.Size = new System.Drawing.Size(43, 41);
            this.FavIcon.TabIndex = 0;
            this.FavIcon.UseVisualStyleBackColor = false;
            // 
            // lblFavCaption
            // 
            this.lblFavCaption.BackColor = System.Drawing.Color.Transparent;
            this.lblFavCaption.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFavCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblFavCaption.Location = new System.Drawing.Point(1, 44);
            this.lblFavCaption.Name = "lblFavCaption";
            this.lblFavCaption.RequiredField = false;
            this.lblFavCaption.Size = new System.Drawing.Size(64, 20);
            this.lblFavCaption.TabIndex = 173;
            this.lblFavCaption.Text = "Home";
            this.lblFavCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // atFavouriteBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.FavIcon);
            this.Controls.Add(this.lblFavCaption);
            this.Name = "atFavouriteBox";
            this.Size = new System.Drawing.Size(65, 65);
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atRoundPictureBox FavIcon;
        private atACCFramework.UserControls.atLabel lblFavCaption;
    }
}
