﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace atACC.HTL.UI.UserControls
{
    public partial class atFavoritesButton : UserControl
    {

        public atFavoritesButton()
        {
            InitializeComponent();
        }
        #region Public Properties & Events
        public new string Text { set { lblCaption.Text = value; } get { return lblCaption.Text; } }
        public Image MenuImage { set { picMenuImage.Image = value; } }
        public event EventHandler fnClick;
        public event MouseEventHandler fnMouseClick;
        public event MouseEventHandler fnMouseDown;
        #endregion

        #region Events
        private void lblCaption_Click(object sender, EventArgs e)
        {
            if (fnClick != null)
                fnClick(sender, e);
        }

        private void lblCaption_MouseClick(object sender, MouseEventArgs e)
        {
            if (fnMouseClick != null)
                fnMouseClick(sender, e);
        }
        private void lblCaption_MouseDown(object sender, MouseEventArgs e)
        {
            if (fnMouseDown != null)
                fnMouseDown(sender, e);
        }

        #endregion



    }
}
