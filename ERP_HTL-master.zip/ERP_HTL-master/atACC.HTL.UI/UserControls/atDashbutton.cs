﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.HTL.UI.UIClasses;
using atACC.HTL.UI;
namespace atACC.HTL.UI.UserControls
{
    public partial class atDashbutton : UserControl
    {
        public event EventHandler fnClick;
        public event MouseEventHandler fnMouseClick;
        public event MouseEventHandler fnMouseDown;
    
        public atDashbutton()
        {
            InitializeComponent();
            this.BackColor = UICommon.ColorDash;
        }
        public bool Selected
        {
            get { return  atgradPanel.Visible; }
            set 
            {
                atgradPanel.Visible = value;
            }
        }
        public string Text
        {
            get { return lblCaption.Text; }
            set { lblCaption.Text = value; }
        }
        public Image Image
        {
            get { return picicon.BackgroundImage; }
            set { picicon.BackgroundImage = value; }
        }
        public override Font Font
        {
            get
            {
                return base.Font;
            }
            set
            {
                base.Font = value;
                lblCaption.Font = value;
            }
        }
        private void lblCaption_Click(object sender, EventArgs e)
        {
            foreach (Control btn in this.Parent.Controls)
            {
                if (btn is atDashbutton)
                {
                    if (((atDashbutton)btn).Name != this.Name)
                    {
                        ((atDashbutton)btn).Selected = false;
                    }
                    else
                    {
                        ((atDashbutton)btn).Selected = true;
                    }
                }
            }
            if (fnClick != null) 
            fnClick(sender, e);
            
        }

        private void atDashbutton_Load(object sender, EventArgs e)
        {
           
        }

        private void atDashbutton_Click(object sender, EventArgs e)
        {
            lblCaption_Click(sender, e);
        }

        private void lblCaption_MouseClick(object sender, MouseEventArgs e)
        {
            if (fnMouseClick != null) 
            fnMouseClick(sender, e);
        }

        private void atDashbutton_MouseClick(object sender, MouseEventArgs e)
        {
            lblCaption_MouseClick(sender, e);
        }

        private void picicon_Click(object sender, EventArgs e)
        {
            lblCaption_Click(sender, e);
        }

        private void picicon_MouseClick(object sender, MouseEventArgs e)
        {
            lblCaption_MouseClick(sender, e);
        }

        private void lblCaption_MouseHover(object sender, EventArgs e)
        {
            this.BackColor = UICommon.ColorDashButtonHover;
        }
        private void lblCaption_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = UICommon.ColorDash;
        }

        private void lblCaption_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void lblCaption_MouseDown(object sender, MouseEventArgs e)
        {
            if(fnMouseDown!=null)
            fnMouseDown(sender, e);
            this.BackColor = UICommon.ColorDashButtonClick;
        }

        private void lblCaption_MouseUp(object sender, MouseEventArgs e)
        {
            this.BackColor = UICommon.ColorDashButtonHover;
        }

        private void picicon_MouseHover(object sender, EventArgs e)
        {
            lblCaption_MouseHover(sender, e);
        }

        private void picicon_MouseDown(object sender, MouseEventArgs e)
        {
            lblCaption_MouseDown(sender, e);
        }

        private void picicon_MouseLeave(object sender, EventArgs e)
        {
            lblCaption_MouseLeave(sender, e);
        }

        private void picicon_MouseUp(object sender, MouseEventArgs e)
        {
            lblCaption_MouseUp(sender, e);
        }
    }
}
