﻿namespace atACC.HTL.UI.UserControls
{
    partial class atReminderDetailView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atReminderDetailView));
            this.btnOK = new atACCFramework.UserControls.atButton();
            this.lblGuestName = new atACCFramework.UserControls.atLabel();
            this.lblMessage = new atACCFramework.UserControls.atLabel();
            this.btnCancel = new atACCFramework.UserControls.atButton();
            this.lblRoomNo = new atACCFramework.UserControls.atLabel();
            this.lblReminderDate = new atACCFramework.UserControls.atLabel();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnOK.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.ForeColor = System.Drawing.Color.White;
            this.btnOK.Name = "btnOK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblGuestName
            // 
            resources.ApplyResources(this.lblGuestName, "lblGuestName");
            this.lblGuestName.Name = "lblGuestName";
            this.lblGuestName.RequiredField = false;
            // 
            // lblMessage
            // 
            resources.ApplyResources(this.lblMessage, "lblMessage");
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.RequiredField = false;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblRoomNo
            // 
            resources.ApplyResources(this.lblRoomNo, "lblRoomNo");
            this.lblRoomNo.Name = "lblRoomNo";
            this.lblRoomNo.RequiredField = false;
            // 
            // lblReminderDate
            // 
            resources.ApplyResources(this.lblReminderDate, "lblReminderDate");
            this.lblReminderDate.Name = "lblReminderDate";
            this.lblReminderDate.RequiredField = false;
            // 
            // atReminderDetailView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblReminderDate);
            this.Controls.Add(this.lblRoomNo);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblGuestName);
            this.Controls.Add(this.btnOK);
            this.Name = "atReminderDetailView";
            this.Load += new System.EventHandler(this.atReminderDetailView_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atACCFramework.UserControls.atButton btnOK;
        private atACCFramework.UserControls.atLabel lblGuestName;
        private atACCFramework.UserControls.atLabel lblMessage;
        private atACCFramework.UserControls.atButton btnCancel;
        private atACCFramework.UserControls.atLabel lblRoomNo;
        private atACCFramework.UserControls.atLabel lblReminderDate;
    }
}