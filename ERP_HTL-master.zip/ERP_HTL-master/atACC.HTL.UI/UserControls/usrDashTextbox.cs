﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;
namespace atACC.HTL.UI.UserControls
{
  public  class usrDashTextbox:TextBox
  {
      private string mCue;
      [DllImport("user32.dll", CharSet = CharSet.Unicode)]
      private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, string lp);
      public usrDashTextbox()
      {

      }
      [Localizable(true)]
      public string WaterMark
      {
          get { return mCue; }
          set { mCue = value; updateCue(); }
      }
      private void updateCue()
      {
          if (this.IsHandleCreated && mCue != null)
          {
              SendMessage(this.Handle, 0x1501, (IntPtr)1, mCue);
          }
      }
      protected override void OnHandleCreated(EventArgs e)
      {
          base.OnHandleCreated(e);
          updateCue();
      }
    }
}
