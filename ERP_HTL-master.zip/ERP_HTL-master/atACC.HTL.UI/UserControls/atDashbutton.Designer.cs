﻿namespace atACC.HTL.UI.UserControls
{
    partial class atDashbutton
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCaption = new System.Windows.Forms.Label();
            this.picicon = new System.Windows.Forms.PictureBox();
            this.atgradPanel = new atACCFramework.UserControls.atGradientPanel();
            this.pnlSpace = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.picicon)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCaption
            // 
            this.lblCaption.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCaption.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaption.ForeColor = System.Drawing.Color.White;
            this.lblCaption.Location = new System.Drawing.Point(42, 0);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Size = new System.Drawing.Size(153, 35);
            this.lblCaption.TabIndex = 1;
            this.lblCaption.Text = "label1";
            this.lblCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCaption.Click += new System.EventHandler(this.lblCaption_Click);
            this.lblCaption.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseClick);
            this.lblCaption.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseDown);
            this.lblCaption.MouseLeave += new System.EventHandler(this.lblCaption_MouseLeave);
            this.lblCaption.MouseHover += new System.EventHandler(this.lblCaption_MouseHover);
            this.lblCaption.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseMove);
            this.lblCaption.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lblCaption_MouseUp);
            // 
            // picicon
            // 
            this.picicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picicon.Dock = System.Windows.Forms.DockStyle.Left;
            this.picicon.Location = new System.Drawing.Point(7, 0);
            this.picicon.Name = "picicon";
            this.picicon.Size = new System.Drawing.Size(35, 35);
            this.picicon.TabIndex = 0;
            this.picicon.TabStop = false;
            this.picicon.Click += new System.EventHandler(this.picicon_Click);
            this.picicon.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picicon_MouseClick);
            this.picicon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picicon_MouseDown);
            this.picicon.MouseLeave += new System.EventHandler(this.picicon_MouseLeave);
            this.picicon.MouseHover += new System.EventHandler(this.picicon_MouseHover);
            this.picicon.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picicon_MouseUp);
            // 
            // atgradPanel
            // 
            this.atgradPanel.AllowMultiSelect = false;
            this.atgradPanel.Angle = 110F;
            this.atgradPanel.BackColor = System.Drawing.Color.SteelBlue;
            this.atgradPanel.BottomColor = System.Drawing.Color.SpringGreen;
            this.atgradPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.atgradPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.atgradPanel.Location = new System.Drawing.Point(0, 0);
            this.atgradPanel.Name = "atgradPanel";
            this.atgradPanel.Selected = false;
            this.atgradPanel.Size = new System.Drawing.Size(4, 35);
            this.atgradPanel.TabIndex = 2;
            this.atgradPanel.TextAdjestmentHeight = 0;
            this.atgradPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.atgradPanel.TopColor = System.Drawing.Color.DodgerBlue;
            this.atgradPanel.Visible = false;
            // 
            // pnlSpace
            // 
            this.pnlSpace.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSpace.Location = new System.Drawing.Point(4, 0);
            this.pnlSpace.Name = "pnlSpace";
            this.pnlSpace.Size = new System.Drawing.Size(3, 35);
            this.pnlSpace.TabIndex = 3;
            // 
            // atDashbutton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(68)))), ((int)(((byte)(104)))));
            this.Controls.Add(this.lblCaption);
            this.Controls.Add(this.picicon);
            this.Controls.Add(this.pnlSpace);
            this.Controls.Add(this.atgradPanel);
            this.Name = "atDashbutton";
            this.Size = new System.Drawing.Size(195, 35);
            this.Load += new System.EventHandler(this.atDashbutton_Load);
            this.Click += new System.EventHandler(this.atDashbutton_Click);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.atDashbutton_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.picicon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picicon;
        private System.Windows.Forms.Label lblCaption;
        private atACCFramework.UserControls.atGradientPanel atgradPanel;
        private System.Windows.Forms.Panel pnlSpace;
    }
}
