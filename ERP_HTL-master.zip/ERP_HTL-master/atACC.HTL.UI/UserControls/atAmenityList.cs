﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACCFramework;
using atACCFramework.Common;
using atACC.HTL.ORM;
using System.Data.SqlClient;

namespace atACC.HTL.UI.UserControls
{
    public partial class atAmenityList : UserControl
    {
        #region Private Variables
        atACCHotelEntities dbh;
        public string m_NumberFormat;
        #endregion

        #region Constructor
        public atAmenityList()
        {
            InitializeComponent();
        }
        #endregion

        #region Populate Events
        private void PopulateRoomType()
        {
            List<RoomTypes> entRoomTypes = dbh.RoomTypes.Where(x=>x.Active == true).ToList();
            cmbRoomType.DisplayMember = "Name";
            cmbRoomType.ValueMember = "id";
            cmbRoomType.DataSource = entRoomTypes;
            cmbRoomType.SelectedIndex = -1;
        }
        public void fnPopulateAmenity()
        {
            DataSet ds = new DataSet();
            SqlHelper _sqlhelper = new SqlHelper();
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("RoomType", cmbRoomType.SelectedValue));
            ds = _sqlhelper.ExecuteProcedure("SPAmenityList", sqlParameters);
            if (cmbRoomType.Text != string.Empty)
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.DataSource = ds.Tables[0];
            }
            else 
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.DataSource = null;
            }
        }
        #endregion

        #region Form Events
        private void atAmenityList_Load(object sender, EventArgs e)
        {
            dbh = atHotelContext.CreateContext();
            PopulateRoomType();
            dgDetails.AutoGenerateColumns = false;
            dgDetails.DataSource = null;
            lblRoomType.Text = "";
            dgDetails.ColumnHeadersDefaultCellStyle.Font = dgDetails.ColumnHeadersDefaultCellStyle.Font;
        }
        private void cmbRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRoomType.Text != string.Empty)
            {
                fnPopulateAmenity();
                lblRoomType.Text = cmbRoomType.Text;
            }
            else
            {
                lblRoomType.Text = "";
            }
        }
        private void lblDownArrow_Click(object sender, EventArgs e)
        {
            cmbRoomType.DroppedDown = true;
        }
        #endregion
    }
}
