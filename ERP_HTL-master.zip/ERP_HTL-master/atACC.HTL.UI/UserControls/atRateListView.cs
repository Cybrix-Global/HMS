﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACCFramework;
using atACCFramework.Common;
using atACC.HTL.ORM;
using System.Data.SqlClient;

namespace atACC.HTL.UI.UserControls
{
    public partial class atRateListView : UserControl
    {
        #region Private Variables
        atACCHotelEntities dbh;
        public string m_NumberFormat;
        #endregion

        #region Constructor
        public atRateListView()
        {
            InitializeComponent();
            m_NumberFormat = "N" + GlobalFunctions.CompanyNoofDecimals;
            colBaseRate.DefaultCellStyle.Format = m_NumberFormat;
            ColAdditionalPersonRate.DefaultCellStyle.Format = m_NumberFormat;
            ColExtraBedRate.DefaultCellStyle.Format = m_NumberFormat;
        }
        #endregion

        #region Populate Events
        private void PopulateRateType()
        {
            List<RateTypes> entRateTypes = dbh.RateTypes.ToList();
            RateTypes entRateType = new RateTypes();
            entRateType.id = 0;
            entRateType.Name = MessageKeys.MsgDefault;
            entRateTypes.Insert(0, entRateType);
            cmbRateType.DisplayMember = "Name";
            cmbRateType.ValueMember = "id";
            cmbRateType.DataSource = entRateTypes;
        }
        public void fnPopulateRate()
        {
            DataSet ds = new DataSet();
            SqlHelper _sqlhelper = new SqlHelper();
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("RateType", cmbRateType.SelectedValue));
            ds = _sqlhelper.ExecuteProcedure("SPRateList", sqlParameters);
            if (cmbRateType.Text != string.Empty)
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.DataSource = ds.Tables[0];
            }
            else 
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.DataSource = null;
            }
            
        }
        #endregion

        #region Form Events
        private void cmbRateType_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnPopulateRate();
            lblRateType.Text = cmbRateType.Text;
        }
        private void cmbRateType_SelectedValueChanged(object sender, EventArgs e)
        {

        }
        private void atRateListView_Load(object sender, EventArgs e)
        {
            dbh = atHotelContext.CreateContext();
            PopulateRateType();
        }
        private void lblDownArrow_Click(object sender, EventArgs e)
        {
            cmbRateType.DroppedDown = true;
        }
        #endregion
    }
}
