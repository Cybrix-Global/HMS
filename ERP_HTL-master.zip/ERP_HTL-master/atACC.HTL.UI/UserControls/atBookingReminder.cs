﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACCFramework;
using atACCFramework.Common;
using atACC.HTL.ORM;
using System.Data.SqlClient;

namespace atACC.HTL.UI.UserControls
{
    public partial class atBookingReminder : UserControl
    {
        #region Private Variables
        atACCHotelEntities dbh;
        #endregion

        #region Constructor
        public atBookingReminder()
        {
            InitializeComponent();
        }
        #endregion

        #region Populate Events
        public void fnPopulateBookingReminder()
        {
            DataSet ds = new DataSet();
            SqlHelper _sqlhelper = new SqlHelper();
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("BranchID", GlobalFunctions.LoginLocationID));
            ds = _sqlhelper.ExecuteProcedure("SPBookingReminder", sqlParameters);
            dgDetails.AutoGenerateColumns = false;
            dgDetails.DataSource = ds.Tables[0];
        }
        #endregion

        #region Form Events
        private void atBookingReminder_Load(object sender, EventArgs e)
        {
            dbh = atHotelContext.CreateContext();
            fnPopulateBookingReminder();
        }
        #endregion
    }
}
