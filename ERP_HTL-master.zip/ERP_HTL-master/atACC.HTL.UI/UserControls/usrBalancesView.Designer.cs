﻿namespace atACC.HTL.UI.UserControls
{
    partial class usrBalancesView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(usrBalancesView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgDetails = new System.Windows.Forms.DataGridView();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBalance = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblUsrCap = new System.Windows.Forms.Label();
            this.atgradPanel = new atACCFramework.UserControls.atGradientPanel();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.atgradPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgDetails
            // 
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.AllowUserToAddRows = false;
            this.dgDetails.AllowUserToDeleteRows = false;
            this.dgDetails.AllowUserToResizeColumns = false;
            this.dgDetails.AllowUserToResizeRows = false;
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgDetails.BackgroundColor = System.Drawing.Color.White;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colName,
            this.colBalance});
            this.dgDetails.Name = "dgDetails";
            this.dgDetails.RowHeadersVisible = false;
            // 
            // colName
            // 
            this.colName.DataPropertyName = "LedgerName";
            this.colName.FillWeight = 118.7817F;
            resources.ApplyResources(this.colName, "colName");
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colBalance
            // 
            this.colBalance.DataPropertyName = "Balance";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.colBalance.DefaultCellStyle = dataGridViewCellStyle2;
            this.colBalance.FillWeight = 81.21828F;
            resources.ApplyResources(this.colBalance, "colBalance");
            this.colBalance.Name = "colBalance";
            this.colBalance.ReadOnly = true;
            // 
            // lblUsrCap
            // 
            resources.ApplyResources(this.lblUsrCap, "lblUsrCap");
            this.lblUsrCap.BackColor = System.Drawing.Color.Transparent;
            this.lblUsrCap.ForeColor = System.Drawing.Color.White;
            this.lblUsrCap.Name = "lblUsrCap";
            this.lblUsrCap.Click += new System.EventHandler(this.lblERPCap_Click);
            // 
            // atgradPanel
            // 
            resources.ApplyResources(this.atgradPanel, "atgradPanel");
            this.atgradPanel.AllowMultiSelect = false;
            this.atgradPanel.Angle = 110F;
            this.atgradPanel.BackColor = System.Drawing.Color.SteelBlue;
            this.atgradPanel.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(145)))), ((int)(((byte)(235)))));
            this.atgradPanel.Controls.Add(this.lblUsrCap);
            this.atgradPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.atgradPanel.Name = "atgradPanel";
            this.atgradPanel.Selected = false;
            this.atgradPanel.TextAdjestmentHeight = 0;
            this.atgradPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.atgradPanel.TopColor = System.Drawing.Color.DodgerBlue;
            // 
            // usrBalancesView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dgDetails);
            this.Controls.Add(this.atgradPanel);
            this.Name = "usrBalancesView";
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.atgradPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgDetails;
        private atACCFramework.UserControls.atGradientPanel atgradPanel;
        public System.Windows.Forms.Label lblUsrCap;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBalance;
    }
}
