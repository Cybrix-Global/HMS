﻿namespace atACC.HTL.UI.UserControls
{
    partial class atRoomView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atRoomView));
            this.lblDepartureDate = new atACCFramework.UserControls.atLabel();
            this.lblArrivedDate = new atACCFramework.UserControls.atLabel();
            this.lblNoPersons = new atACCFramework.UserControls.atLabel();
            this.lblRoomNo = new atACCFramework.UserControls.atLabel();
            this.pcImage = new System.Windows.Forms.PictureBox();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.lblChild = new atACCFramework.UserControls.atLabel();
            this.pnlChildImage = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlColor = new System.Windows.Forms.Panel();
            this.pnlNoOf = new System.Windows.Forms.Panel();
            this.btnCommon = new atACCFramework.UserControls.atPOSButton2();
            this.lblGuestName = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pcImage)).BeginInit();
            this.btnCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDepartureDate
            // 
            this.lblDepartureDate.AutoSize = true;
            this.lblDepartureDate.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartureDate.Location = new System.Drawing.Point(4, 84);
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.RequiredField = false;
            this.lblDepartureDate.Size = new System.Drawing.Size(113, 15);
            this.lblDepartureDate.TabIndex = 6;
            this.lblDepartureDate.Text = "03-01-2021 06:30 PM";
            this.lblDepartureDate.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.lblDepartureDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // lblArrivedDate
            // 
            this.lblArrivedDate.AutoSize = true;
            this.lblArrivedDate.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArrivedDate.Location = new System.Drawing.Point(4, 65);
            this.lblArrivedDate.Name = "lblArrivedDate";
            this.lblArrivedDate.RequiredField = false;
            this.lblArrivedDate.Size = new System.Drawing.Size(113, 15);
            this.lblArrivedDate.TabIndex = 5;
            this.lblArrivedDate.Text = "01-01-2021 08:06 AM";
            this.lblArrivedDate.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.lblArrivedDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // lblNoPersons
            // 
            this.lblNoPersons.AutoSize = true;
            this.lblNoPersons.Location = new System.Drawing.Point(84, 39);
            this.lblNoPersons.Name = "lblNoPersons";
            this.lblNoPersons.RequiredField = false;
            this.lblNoPersons.Size = new System.Drawing.Size(13, 13);
            this.lblNoPersons.TabIndex = 3;
            this.lblNoPersons.Text = "4";
            this.lblNoPersons.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.lblNoPersons.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // lblRoomNo
            // 
            this.lblRoomNo.AutoSize = true;
            this.lblRoomNo.Font = new System.Drawing.Font("Open Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomNo.ForeColor = System.Drawing.Color.Black;
            this.lblRoomNo.Location = new System.Drawing.Point(83, 14);
            this.lblRoomNo.Name = "lblRoomNo";
            this.lblRoomNo.RequiredField = false;
            this.lblRoomNo.Size = new System.Drawing.Size(78, 20);
            this.lblRoomNo.TabIndex = 2;
            this.lblRoomNo.Text = "R1-12345";
            this.lblRoomNo.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.lblRoomNo.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // pcImage
            // 
            this.pcImage.Location = new System.Drawing.Point(12, 14);
            this.pcImage.Name = "pcImage";
            this.pcImage.Size = new System.Drawing.Size(45, 40);
            this.pcImage.TabIndex = 7;
            this.pcImage.TabStop = false;
            this.pcImage.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.pcImage.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(121, 84);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            this.lblStatus.Size = new System.Drawing.Size(55, 17);
            this.lblStatus.TabIndex = 11;
            this.lblStatus.Text = "Check In";
            this.lblStatus.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.lblStatus.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // lblChild
            // 
            this.lblChild.AutoSize = true;
            this.lblChild.Location = new System.Drawing.Point(138, 38);
            this.lblChild.Name = "lblChild";
            this.lblChild.RequiredField = false;
            this.lblChild.Size = new System.Drawing.Size(13, 13);
            this.lblChild.TabIndex = 10;
            this.lblChild.Text = "2";
            this.lblChild.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.lblChild.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // pnlChildImage
            // 
            this.pnlChildImage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlChildImage.BackgroundImage")));
            this.pnlChildImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlChildImage.Location = new System.Drawing.Point(116, 36);
            this.pnlChildImage.Name = "pnlChildImage";
            this.pnlChildImage.Size = new System.Drawing.Size(18, 18);
            this.pnlChildImage.TabIndex = 9;
            this.pnlChildImage.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.pnlChildImage.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Location = new System.Drawing.Point(63, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(18, 17);
            this.panel1.TabIndex = 9;
            this.panel1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.panel1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // pnlColor
            // 
            this.pnlColor.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.pnlColor.Location = new System.Drawing.Point(126, 65);
            this.pnlColor.Name = "pnlColor";
            this.pnlColor.Size = new System.Drawing.Size(58, 18);
            this.pnlColor.TabIndex = 9;
            this.pnlColor.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.pnlColor.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // pnlNoOf
            // 
            this.pnlNoOf.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlNoOf.BackgroundImage")));
            this.pnlNoOf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlNoOf.Location = new System.Drawing.Point(62, 36);
            this.pnlNoOf.Name = "pnlNoOf";
            this.pnlNoOf.Size = new System.Drawing.Size(18, 18);
            this.pnlNoOf.TabIndex = 8;
            this.pnlNoOf.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.pnlNoOf.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // btnCommon
            // 
            this.btnCommon.AllowMultiSelect = false;
            this.btnCommon.BackColor = System.Drawing.Color.Transparent;
            this.btnCommon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCommon.Color = System.Drawing.Color.White;
            this.btnCommon.Controls.Add(this.lblGuestName);
            this.btnCommon.Controls.Add(this.lblDepartureDate);
            this.btnCommon.Controls.Add(this.lblArrivedDate);
            this.btnCommon.Controls.Add(this.lblStatus);
            this.btnCommon.Controls.Add(this.pnlColor);
            this.btnCommon.Controls.Add(this.pcImage);
            this.btnCommon.Controls.Add(this.lblChild);
            this.btnCommon.Controls.Add(this.lblRoomNo);
            this.btnCommon.Controls.Add(this.pnlChildImage);
            this.btnCommon.Controls.Add(this.panel1);
            this.btnCommon.Controls.Add(this.lblNoPersons);
            this.btnCommon.Controls.Add(this.pnlNoOf);
            this.btnCommon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCommon.Disabled = false;
            this.btnCommon.DisabledColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnCommon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCommon.ForeColor = System.Drawing.Color.Black;
            this.btnCommon.Icon = null;
            this.btnCommon.IconAdjestmentHeight = 0;
            this.btnCommon.IconAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCommon.InColor = System.Drawing.Color.White;
            this.btnCommon.Location = new System.Drawing.Point(0, 0);
            this.btnCommon.Name = "btnCommon";
            this.btnCommon.Selected = false;
            this.btnCommon.SelectTypeButton = false;
            this.btnCommon.Size = new System.Drawing.Size(200, 125);
            this.btnCommon.TabIndex = 2;
            this.btnCommon.TextAdjestmentHeight = 0;
            this.btnCommon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCommon.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseClick);
            this.btnCommon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.btnCommon_MouseDoubleClick);
            // 
            // lblGuestName
            // 
            this.lblGuestName.AutoSize = true;
            this.lblGuestName.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuestName.Location = new System.Drawing.Point(5, 101);
            this.lblGuestName.Name = "lblGuestName";
            this.lblGuestName.RequiredField = false;
            this.lblGuestName.Size = new System.Drawing.Size(40, 15);
            this.lblGuestName.TabIndex = 12;
            this.lblGuestName.Text = "empty";
            // 
            // atRoomView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.Controls.Add(this.btnCommon);
            this.Name = "atRoomView";
            this.Size = new System.Drawing.Size(200, 125);
            ((System.ComponentModel.ISupportInitialize)(this.pcImage)).EndInit();
            this.btnCommon.ResumeLayout(false);
            this.btnCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlNoOf;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlChildImage;
        private atACCFramework.UserControls.atPOSButton2 btnCommon;
        private atACCFramework.UserControls.atLabel lblDepartureDate;
        private atACCFramework.UserControls.atLabel lblArrivedDate;
        private atACCFramework.UserControls.atLabel lblNoPersons;
        private atACCFramework.UserControls.atLabel lblRoomNo;
        private System.Windows.Forms.PictureBox pcImage;
        private System.Windows.Forms.Panel pnlColor;
        private atACCFramework.UserControls.atLabel lblChild;
        private atACCFramework.UserControls.atLabel lblStatus;
        private atACCFramework.UserControls.atLabel lblGuestName;
    }
}
