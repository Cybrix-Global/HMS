﻿namespace atACC.HTL.UI.UserControls
{
    partial class atRateListView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(atRateListView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.atgradPanel = new atACCFramework.UserControls.atGradientPanel();
            this.lblDownArrow = new atACCFramework.UserControls.atLabel();
            this.lblRateType = new atACCFramework.UserControls.atLabel();
            this.cmbRateType = new System.Windows.Forms.ComboBox();
            this.lblUsrCap = new System.Windows.Forms.Label();
            this.dgDetails = new System.Windows.Forms.DataGridView();
            this.colRoomType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBaseRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColAdditionalPersonRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColExtraBedRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.atgradPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // atgradPanel
            // 
            this.atgradPanel.AllowMultiSelect = false;
            this.atgradPanel.Angle = 110F;
            this.atgradPanel.BackColor = System.Drawing.Color.SteelBlue;
            this.atgradPanel.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(145)))), ((int)(((byte)(235)))));
            this.atgradPanel.Controls.Add(this.lblDownArrow);
            this.atgradPanel.Controls.Add(this.lblRateType);
            this.atgradPanel.Controls.Add(this.cmbRateType);
            this.atgradPanel.Controls.Add(this.lblUsrCap);
            this.atgradPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.atgradPanel, "atgradPanel");
            this.atgradPanel.Name = "atgradPanel";
            this.atgradPanel.Selected = false;
            this.atgradPanel.TextAdjestmentHeight = 0;
            this.atgradPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.atgradPanel.TopColor = System.Drawing.Color.Lime;
            // 
            // lblDownArrow
            // 
            this.lblDownArrow.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.lblDownArrow, "lblDownArrow");
            this.lblDownArrow.Name = "lblDownArrow";
            this.lblDownArrow.RequiredField = false;
            this.lblDownArrow.Click += new System.EventHandler(this.lblDownArrow_Click);
            // 
            // lblRateType
            // 
            this.lblRateType.BackColor = System.Drawing.Color.Transparent;
            this.lblRateType.Cursor = System.Windows.Forms.Cursors.Default;
            resources.ApplyResources(this.lblRateType, "lblRateType");
            this.lblRateType.Name = "lblRateType";
            this.lblRateType.RequiredField = false;
            // 
            // cmbRateType
            // 
            this.cmbRateType.BackColor = System.Drawing.Color.White;
            this.cmbRateType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRateType, "cmbRateType");
            this.cmbRateType.FormattingEnabled = true;
            this.cmbRateType.Name = "cmbRateType";
            this.cmbRateType.SelectedIndexChanged += new System.EventHandler(this.cmbRateType_SelectedIndexChanged);
            this.cmbRateType.SelectedValueChanged += new System.EventHandler(this.cmbRateType_SelectedValueChanged);
            // 
            // lblUsrCap
            // 
            this.lblUsrCap.BackColor = System.Drawing.Color.Transparent;
            this.lblUsrCap.Cursor = System.Windows.Forms.Cursors.Default;
            resources.ApplyResources(this.lblUsrCap, "lblUsrCap");
            this.lblUsrCap.ForeColor = System.Drawing.Color.White;
            this.lblUsrCap.Name = "lblUsrCap";
            // 
            // dgDetails
            // 
            this.dgDetails.AllowUserToAddRows = false;
            this.dgDetails.AllowUserToDeleteRows = false;
            this.dgDetails.AllowUserToResizeColumns = false;
            this.dgDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgDetails.BackgroundColor = System.Drawing.Color.White;
            this.dgDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRoomType,
            this.colBaseRate,
            this.ColAdditionalPersonRate,
            this.ColExtraBedRate});
            this.dgDetails.Name = "dgDetails";
            this.dgDetails.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Open Sans", 9F);
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgDetails.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Open Sans", 9F);
            // 
            // colRoomType
            // 
            this.colRoomType.DataPropertyName = "RoomType";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9F);
            this.colRoomType.DefaultCellStyle = dataGridViewCellStyle2;
            this.colRoomType.FillWeight = 118.7817F;
            resources.ApplyResources(this.colRoomType, "colRoomType");
            this.colRoomType.Name = "colRoomType";
            this.colRoomType.ReadOnly = true;
            // 
            // colBaseRate
            // 
            this.colBaseRate.DataPropertyName = "BaseRate";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Open Sans", 9F);
            dataGridViewCellStyle3.Format = "N2";
            dataGridViewCellStyle3.NullValue = null;
            this.colBaseRate.DefaultCellStyle = dataGridViewCellStyle3;
            this.colBaseRate.FillWeight = 81.21828F;
            resources.ApplyResources(this.colBaseRate, "colBaseRate");
            this.colBaseRate.Name = "colBaseRate";
            this.colBaseRate.ReadOnly = true;
            // 
            // ColAdditionalPersonRate
            // 
            this.ColAdditionalPersonRate.DataPropertyName = "AdditionalPersonRate";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColAdditionalPersonRate.DefaultCellStyle = dataGridViewCellStyle4;
            resources.ApplyResources(this.ColAdditionalPersonRate, "ColAdditionalPersonRate");
            this.ColAdditionalPersonRate.Name = "ColAdditionalPersonRate";
            this.ColAdditionalPersonRate.ReadOnly = true;
            // 
            // ColExtraBedRate
            // 
            this.ColExtraBedRate.DataPropertyName = "ExtraBedRate";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColExtraBedRate.DefaultCellStyle = dataGridViewCellStyle5;
            resources.ApplyResources(this.ColExtraBedRate, "ColExtraBedRate");
            this.ColExtraBedRate.Name = "ColExtraBedRate";
            this.ColExtraBedRate.ReadOnly = true;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.dgDetails);
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.Name = "pnlMain";
            // 
            // atRateListView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.atgradPanel);
            this.Name = "atRateListView";
            this.Load += new System.EventHandler(this.atRateListView_Load);
            this.atgradPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel atgradPanel;
        public System.Windows.Forms.Label lblUsrCap;
        private System.Windows.Forms.DataGridView dgDetails;
        private atACCFramework.UserControls.atLabel lblRateType;
        private atACCFramework.UserControls.atLabel lblDownArrow;
        private System.Windows.Forms.ComboBox cmbRateType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRoomType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBaseRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColAdditionalPersonRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColExtraBedRate;
        private atACCFramework.UserControls.atPanel pnlMain;
    }
}