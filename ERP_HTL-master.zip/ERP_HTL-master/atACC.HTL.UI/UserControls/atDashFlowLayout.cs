﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace atACC.HTL.UI.UserControls
{
    public class atDashFlowLayout:FlowLayoutPanel
    {
        public atDashFlowLayout()
        {
            DoubleBuffered = true;
        }
    }
}
