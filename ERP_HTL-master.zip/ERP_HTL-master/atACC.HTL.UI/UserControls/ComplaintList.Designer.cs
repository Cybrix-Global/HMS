﻿namespace atACC.HTL.UI.UserControls
{
    partial class ComplaintList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ComplaintList));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.atgradPanel = new atACCFramework.UserControls.atGradientPanel();
            this.lblDownArrow = new atACCFramework.UserControls.atLabel();
            this.lblUsrCap = new System.Windows.Forms.Label();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.dgDetails = new System.Windows.Forms.DataGridView();
            this.colGuest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRoom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColComplaint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColExpectedResolvingDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColAssignedServiceMan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.atgradPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // atgradPanel
            // 
            this.atgradPanel.AllowMultiSelect = false;
            this.atgradPanel.Angle = 110F;
            this.atgradPanel.BackColor = System.Drawing.Color.SteelBlue;
            this.atgradPanel.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(145)))), ((int)(((byte)(235)))));
            this.atgradPanel.Controls.Add(this.lblDownArrow);
            this.atgradPanel.Controls.Add(this.lblUsrCap);
            this.atgradPanel.Controls.Add(this.lblRoomType);
            this.atgradPanel.Controls.Add(this.cmbStatus);
            this.atgradPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.atgradPanel, "atgradPanel");
            this.atgradPanel.Name = "atgradPanel";
            this.atgradPanel.Selected = false;
            this.atgradPanel.TextAdjestmentHeight = 0;
            this.atgradPanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.atgradPanel.TopColor = System.Drawing.Color.DarkTurquoise;
            // 
            // lblDownArrow
            // 
            resources.ApplyResources(this.lblDownArrow, "lblDownArrow");
            this.lblDownArrow.BackColor = System.Drawing.Color.Transparent;
            this.lblDownArrow.Name = "lblDownArrow";
            this.lblDownArrow.RequiredField = false;
            this.lblDownArrow.Click += new System.EventHandler(this.lblDownArrow_Click);
            // 
            // lblUsrCap
            // 
            resources.ApplyResources(this.lblUsrCap, "lblUsrCap");
            this.lblUsrCap.BackColor = System.Drawing.Color.Transparent;
            this.lblUsrCap.ForeColor = System.Drawing.Color.White;
            this.lblUsrCap.Name = "lblUsrCap";
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.BackColor = System.Drawing.Color.Transparent;
            this.lblRoomType.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblRoomType.ForeColor = System.Drawing.Color.Black;
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // cmbStatus
            // 
            resources.ApplyResources(this.cmbStatus, "cmbStatus");
            this.cmbStatus.BackColor = System.Drawing.Color.White;
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
            // 
            // dgDetails
            // 
            this.dgDetails.AllowUserToAddRows = false;
            this.dgDetails.AllowUserToDeleteRows = false;
            this.dgDetails.AllowUserToResizeColumns = false;
            this.dgDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            resources.ApplyResources(this.dgDetails, "dgDetails");
            this.dgDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgDetails.BackgroundColor = System.Drawing.Color.White;
            this.dgDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colGuest,
            this.colRoom,
            this.ColType,
            this.ColComplaint,
            this.ColExpectedResolvingDate,
            this.ColAssignedServiceMan,
            this.ColRemarks});
            this.dgDetails.Name = "dgDetails";
            this.dgDetails.RowHeadersVisible = false;
            // 
            // colGuest
            // 
            this.colGuest.DataPropertyName = "Guest";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colGuest.DefaultCellStyle = dataGridViewCellStyle2;
            this.colGuest.FillWeight = 130F;
            resources.ApplyResources(this.colGuest, "colGuest");
            this.colGuest.Name = "colGuest";
            this.colGuest.ReadOnly = true;
            // 
            // colRoom
            // 
            this.colRoom.DataPropertyName = "Room";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Open Sans", 9F);
            dataGridViewCellStyle3.Format = "N2";
            dataGridViewCellStyle3.NullValue = null;
            this.colRoom.DefaultCellStyle = dataGridViewCellStyle3;
            this.colRoom.FillWeight = 81.21828F;
            resources.ApplyResources(this.colRoom, "colRoom");
            this.colRoom.Name = "colRoom";
            this.colRoom.ReadOnly = true;
            // 
            // ColType
            // 
            this.ColType.DataPropertyName = "Type";
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColType.DefaultCellStyle = dataGridViewCellStyle4;
            resources.ApplyResources(this.ColType, "ColType");
            this.ColType.Name = "ColType";
            // 
            // ColComplaint
            // 
            this.ColComplaint.DataPropertyName = "Complaint";
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColComplaint.DefaultCellStyle = dataGridViewCellStyle5;
            resources.ApplyResources(this.ColComplaint, "ColComplaint");
            this.ColComplaint.Name = "ColComplaint";
            // 
            // ColExpectedResolvingDate
            // 
            this.ColExpectedResolvingDate.DataPropertyName = "ExpectedResolvingDate";
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColExpectedResolvingDate.DefaultCellStyle = dataGridViewCellStyle6;
            this.ColExpectedResolvingDate.FillWeight = 75F;
            resources.ApplyResources(this.ColExpectedResolvingDate, "ColExpectedResolvingDate");
            this.ColExpectedResolvingDate.Name = "ColExpectedResolvingDate";
            // 
            // ColAssignedServiceMan
            // 
            this.ColAssignedServiceMan.DataPropertyName = "AssignedServiceMan";
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColAssignedServiceMan.DefaultCellStyle = dataGridViewCellStyle7;
            resources.ApplyResources(this.ColAssignedServiceMan, "ColAssignedServiceMan");
            this.ColAssignedServiceMan.Name = "ColAssignedServiceMan";
            // 
            // ColRemarks
            // 
            this.ColRemarks.DataPropertyName = "Remarks";
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Open Sans", 9F);
            this.ColRemarks.DefaultCellStyle = dataGridViewCellStyle8;
            resources.ApplyResources(this.ColRemarks, "ColRemarks");
            this.ColRemarks.Name = "ColRemarks";
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.dgDetails);
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.Name = "pnlMain";
            // 
            // ComplaintList
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.atgradPanel);
            this.Name = "ComplaintList";
            this.Load += new System.EventHandler(this.ComplaintList_Load);
            this.atgradPanel.ResumeLayout(false);
            this.atgradPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel atgradPanel;
        private atACCFramework.UserControls.atLabel lblDownArrow;
        public System.Windows.Forms.Label lblUsrCap;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.DataGridView dgDetails;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGuest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRoom;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColComplaint;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColExpectedResolvingDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColAssignedServiceMan;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRemarks;
        private atACCFramework.UserControls.atPanel pnlMain;
    }
}