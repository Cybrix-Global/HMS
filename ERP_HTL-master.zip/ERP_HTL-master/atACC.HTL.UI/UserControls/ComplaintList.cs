﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACCFramework;
using atACCFramework.Common;
using atACC.HTL.ORM;
using System.Data.SqlClient;
using atACC.CommonExtensions;

namespace atACC.HTL.UI.UserControls
{
    public partial class ComplaintList : UserControl
    {
        #region Private Variables
        atACCHotelEntities dbh;
        #endregion

        #region Constructor
        public ComplaintList()
        {
            InitializeComponent();
        }
        #endregion

        #region Populate Events
        private void PopulateStatus()
        {
            List<MasterValue> entStatus = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.ComplaintRegisterStatus && x.id != (int)ENMVComplaintRegisterStatus.Close).ToList();
            cmbStatus.DisplayMember = "Description";
            cmbStatus.ValueMember = "id";
            cmbStatus.DataSource = entStatus;
        }
        public void fnPopulateComplaint()
        {
            DataSet ds = new DataSet();
            SqlHelper _sqlhelper = new SqlHelper();
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("Status", cmbStatus.SelectedValue));
            ds = _sqlhelper.ExecuteProcedure("SPPendingComplaint", sqlParameters);
            if (cmbStatus.Text != string.Empty)
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.DataSource = ds.Tables[0];
            }
            else
            {
                dgDetails.AutoGenerateColumns = false;
                dgDetails.DataSource = null;
            }
        }
        #endregion

        #region Form Events
        private void ComplaintList_Load(object sender, EventArgs e)
        {
            dbh = atHotelContext.CreateContext();
            PopulateStatus();
            dgDetails.AutoGenerateColumns = false;
            dgDetails.DataSource = null;
        }
        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbStatus.Text != string.Empty)
            {
                fnPopulateComplaint();
                lblRoomType.Text = cmbStatus.Text;
            }
            else
            {
                lblRoomType.Text = "";
            }
        }
        private void lblDownArrow_Click(object sender, EventArgs e)
        {
            cmbStatus.DroppedDown = true;
        }
        #endregion
    }
}
