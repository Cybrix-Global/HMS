﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using atACCFramework;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACCFramework.BaseClasses;
using Microsoft.SqlServer.Management.Smo;
using LocalORM;
using System.Globalization;
using atACC.HTL.UI.UIClasses;
namespace atACC.HTL.UI
{
    public partial class frmOpenCompany : FormBase
    {
        #region Private Variables

        #endregion
        #region Private Methods
        private void PopulateCompanies()
        {
            try
            {
                if (cmbServer.Text.Trim() == "") 
                {
                    errorprvdr.SetError(cmbServer,MessageKeys.MsgServerNameMustBeProvided);
                    return; 
                }
                string connectionString = "Data Source=" + cmbServer.Text + "; Integrated Security=FALSE;User Id=" + GlobalFunctions.DbUserName + ";Password=" + GlobalFunctions.DbPassword;
                lstCompanies.Items.Clear();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT name from sys.databases order by name asc ", con))
                    {
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                if (isValidCompany(dr[0].ToString()) && isApplicationCompany(dr[0].ToString()))
                                {
                                    lstCompanies.Items.Add(dr[0].ToString());
                                }
                            }
                        }
                    }
                }
				if(lstCompanies.Items.Count > 0)
					lstCompanies.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
				ExceptionManager.Publish(ex);
				MessageBox.Show(ex.Message, MessageKeys.MsgApplicationName);
				this.Cursor = Cursors.Arrow;
            }
        }
        private bool isValidCompany(string sCompanyName)
        {
            switch (sCompanyName)
            {
                case "master":
                    return false;
                case "tempdb":
                    return false;
                case "model":
                    return false;
                case "msdb":
                    return false;
                default:
                    return true;
            }
            
        }
        private bool isApplicationCompany(string sCompanyName)
        {
            string connectionString = @"Server=" + cmbServer.Text + ";Integrated Security=False;User ID=" + GlobalFunctions.DbUserName + ";Password=" + GlobalFunctions.DbPassword + ";database=" + sCompanyName  + ";";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                }
                catch{}
                try
                {
                    
                    using (SqlCommand cmd = new SqlCommand("select name from sys.tables where  type='U' and name='TB_ADM_Company'", conn))
                    {
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                return true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }

            return false;
        }
        private bool SelectCompany()
        {
            try
            {
                errorprvdr.Clear();
                if (cmbServer.Text.Trim() == "")
                {
                    errorprvdr.SetError(cmbServer, MessageKeys.MsgServerNameMustBeSelected);
                    return false;
                }
                if (lstCompanies.SelectedItem == null)
                {
                    //errorprvdr.SetError(lstCompanies, "Please Select a Company!");
                    MessageBox.Show(MessageKeys.MsgPleaseSelectACompany);
                    return false;
                }
                GlobalFunctions.ServerName = cmbServer.Text;
                GlobalFunctions.DatabaseName = lstCompanies.SelectedItem.ToString();
                GlobalFunctions.sWindowsAuthenticationConnectionString = "Server=" + GlobalFunctions.ServerName + ";Integrated security=SSPI;database=" + GlobalFunctions.DatabaseName + ";";
                GlobalFunctions.sSqlAuthenticationConnectionString = @"Server=" + GlobalFunctions.ServerName + ";Integrated Security=False;User ID=" + GlobalFunctions.DbUserName + ";Password=" + GlobalFunctions.DbPassword + ";database=" + GlobalFunctions.DatabaseName + ";";

                if (UICommon.isUpgradeRequired(false))
                {
                    UICommon.UpgradeView(false);
                }
                if (GlobalFunctions.DatabaseVersion == "19.0.1001")
                {
                    MessageBox.Show("Upgrade not available for 19.0.1001 ", MessageKeys.MsgApplicationName);
                    return false;
                }
                GlobalFunctions.GenerateEntityConnection();
                using (SettingsDbEntities sdb = new SettingsDbEntities())
                {
                    ServerDetail serverDetail = sdb.ServerDetails.SingleOrDefault();
                    serverDetail.DefaultServer = cmbServer.Text;
                    sdb.ObjectStateManager.ChangeObjectState(serverDetail, EntityState.Modified);
                    sdb.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void PopulateSqlServers()
        {
            try
            {
                cmbServer.Items.Clear();
                DataTable dtServers = SmoApplication.EnumAvailableSqlServers(true);
                foreach (DataRow drow in dtServers.Rows)
                {
                    cmbServer.Items.Add(drow["Name"].ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
        #region Constructor
        public frmOpenCompany()
        {
            if (GlobalFunctions.LanguageCulture == null)
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentCulture;
            }
            else
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(GlobalFunctions.LanguageCulture);
            }
            InitializeComponent();
            using (SettingsDbEntities sdb = new SettingsDbEntities())
            {
                ServerDetail serverDetail = sdb.ServerDetails.SingleOrDefault();
                cmbServer.Text = serverDetail.DefaultServer;
            }
        }
        #endregion
        #region private Events
        private void cmbServer_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Return)
                {
                    this.Cursor = Cursors.WaitCursor;
                    PopulateCompanies();
                    this.Cursor = Cursors.Arrow;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show(ex.Message);
                this.Cursor = Cursors.Arrow;
            }
        }
        private void lstCompanies_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                if (!SelectCompany()) { this.Cursor = Cursors.Arrow; return; }
                this.Cursor = Cursors.Arrow;
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show(ex.Message);
            }
            this.Cursor = Cursors.Arrow;
        }
        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                if (!SelectCompany()) { this.Cursor = Cursors.Arrow; return; }
                this.Cursor = Cursors.Arrow;
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show(ex.Message);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
        private void frmOpenCompany_Load(object sender, EventArgs e)
        {
            PopulateCompanies();
        }
        private void btnPopulateInstances_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                PopulateSqlServers();
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                ExceptionManager.Publish(ex);
                this.Cursor = Cursors.Arrow;
            }
        }
        private void btnCreateNewCompany_Click(object sender, EventArgs e)
        {
            if (cmbServer.Text.ToString() == string.Empty)
            {
                atMessageBox.Show(MessageKeys.MsgServerNameCannotBeBlank);
                return;
            }
            frmNewCompany frmNew = new frmNewCompany();
            if (frmNew.ShowDialog() == DialogResult.OK)
            {
                this.Cursor = Cursors.WaitCursor;
                PopulateCompanies();
                this.Cursor = Cursors.Arrow;
            }
        }
        private void lstCompanies_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void cmbServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            GlobalFunctions.ServerName = cmbServer.Text;
        }
        private void cmbServer_TextChanged(object sender, EventArgs e)
        {
            GlobalFunctions.ServerName = cmbServer.Text;
        }
        #endregion

        private void btnChangeSqlAuthentication_Click(object sender, EventArgs e)
        {
            

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }

        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
    }
}
