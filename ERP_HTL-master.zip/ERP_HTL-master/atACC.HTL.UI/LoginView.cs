﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.UI.UIClasses;
using atACC.Common;
using System.Globalization;
using LocalORM;
using atACC.HTL.Masters;
using atACC.HTL.UI;
namespace atACC.HTL.UI
{
    public partial class LoginView : FormBase
    {
        #region Private Variables
        atACCContextEntities db;
        DateTime dtCurrent;
        List<LoginUser> loginUsers;
        List<FinanPeriod> financialPeriods;
        List<Branch> branches;
        FinanPeriod entfiscalPeriod;
        #endregion

        #region Constructor
        public LoginView()
        {
            if (GlobalFunctions.LanguageCulture == null)
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentCulture;
            }
            else
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(GlobalFunctions.LanguageCulture);
            }
            db = atContext.CreateContext();
            InitializeComponent();
            this.Icon = UICommon._currentICon;
            pcPoweredBy.BackgroundImage = ANIHelper.byteArrayToImage(GlobalFunctions._oemData.OEMLogo);
            ShowOpenCompany = false;
        }
        #endregion

        #region Public Properties
        public bool ShowOpenCompany { get; set; }
        NumberLoginView pinlogin;
        #endregion

        #region Public Methods
        private void Populations()
        {
            cmbFinancialPeriod.DataSource = financialPeriods;
            cmbFinancialPeriod.DisplayMember = "Name";
            cmbFinancialPeriod.ValueMember = "id";
            PopulateLocations();
        }
        private void PopulateLocations()
        {
            LoginUser _loginUser = db.LoginUsers.Where(x => x.UserName == txtUserName.Text).FirstOrDefault();
            if (_loginUser == null) { cmbLocation.DataSource = null;  return; }
            GlobalFunctions.ANISettings = db.ANISetings.ToList();
            GlobalFunctions.blnUserWiseBranch = GlobalFunctions.GetANISettings((int)ENANISettings.UserwiseBranch);
            if (_loginUser.FK_RoleID!=(int)ENUserRole.Administrators && _loginUser.FK_RoleID!=(int)ENUserRole.PowerUsers && GlobalFunctions.blnUserWiseBranch)
            {
                branches = (from br in db.Branches
                            join map in db.UserBranchMappings on br.id equals map.FK_BranchID
                            join user in db.LoginUsers on map.FK_UserID equals user.id
                            where user.UserName == txtUserName.Text
                            select br).OrderBy(x=>x.id).ToList();
            }
            else
            {
                branches = db.Branches.Where(x=>x.FK_BranchType==(int)ENMVBranchType.HeadOffice
                || x.FK_BranchType==(int)ENMVBranchType.LocalBranch).OrderBy(x => x.id).ToList();
            }
            cmbLocation.DataSource = branches;
            cmbLocation.DisplayMember = "Name";
            cmbLocation.ValueMember = "id";
        }
        private bool ResetPassword()
        {
            ResetPassword reset = new ResetPassword();
            if (reset.ShowDialog() == DialogResult.OK)
            {
                txtUserName.Focus();
            }
            return false;
        }
        #endregion

        #region Form Events
        private void LoginView_Activated(object sender, EventArgs e)
        {
            txtUserName.Focus();
        }
        private void LoginView_Load(object sender, EventArgs e)
        {
            if (GlobalFunctions.iCurrentEdition == (int)ENEditions.BasicEdition)
            {
                cmbLocation.Enabled = false;
            }
            dtCurrent = DateTime.Now.ToEnd();
            financialPeriods = db.FinanPeriods.OrderByDescending(x=>x.ToDate).ToList();
            Populations();
            if(Properties.Settings.Default.NumberLogIn)
            {
                lblPinLogin_Click(sender, e);
            }
            //btnOK_Click(sender, e);
        }
        private bool ValidateLogin()
        {
            errProvider.Clear();
            if (txtUserName.Text.Trim() == "") { errProvider.SetError(txtUserName, MessageKeys.MsgUsernameMustBeEntered);return false; }
            if (txtPassword.Text.Trim() == "") { errProvider.SetError(txtPassword, MessageKeys.MsgPasswordMustBeEntered); return false; }
            if (cmbFinancialPeriod.SelectedValue.ToString2().ToInt32() == 0) { errProvider.SetError(cmbFinancialPeriod, MessageKeys.MsgFinancialPeriodMustBeSelected); return false; }
            if (cmbLocation.SelectedValue.ToString2().ToInt32() == 0) { errProvider.SetError(cmbLocation,MessageKeys.MsgBranchMustBeSelected); return false; };
            int ifinPeriodID=cmbFinancialPeriod.SelectedValue.ToString2().ToInt32();
            string sMonthAndYear=dtCurrent.ToMonthName() + "-" + dtCurrent.Year;
            List<FinanPeriodDTL> fdtl =( from fis in db.FinanPeriods
                       join dtl in db.FinanPeriodDTLs on fis.id equals dtl.FK_FinanPeriodID
                       where (fis.id ==ifinPeriodID)
                       && (dtl.MonthName == sMonthAndYear)
                       && (dtl.Status == (int)ENMVFinancialYearStatus.Open
                       && fis.ToDate >= dtCurrent
                       )
                       select dtl).ToList();
            GlobalFunctions.CurrentFiscalPeriodID = ifinPeriodID;
            if (fdtl.Count > 0)
            {
                GlobalFunctions.CurrentMonthID = fdtl.FirstOrDefault().id;
            }

            return true;

        }
        private void btnOK_Click(object sender, EventArgs e)
        {
#if DEBUG
            if (txtUserName.Text.Trim() == "")
            {
                txtUserName.Text = "admin";
                txtPassword.Text = "admin";
                PopulateLocations();
            }
#endif
            GlobalFunctions.LoadAutoBackupSettings();
            if (!ValidateLogin()) { return; }
            if (GlobalFunctions.ANISettings == null)
            {
                GlobalFunctions.ANISettings = db.ANISetings.ToList();
            }
            GlobalFunctions.blnFilterBranchInMasters = GlobalFunctions.GetANISettings((int)ENANISettings.FilterBranchInMasters);
            GlobalFunctions.blnMultiBranchManagement = GlobalFunctions.GetANISettings((int)ENANISettings.MultiBranch);
            LoginUser _currentUser;
            _currentUser = db.LoginUsers.Where(x => x.UserName.ToUpper() == txtUserName.Text.ToUpper()
                    &&
                    (x.Password == txtPassword.Text)
                    ).FirstOrDefault();
               
            if(_currentUser == null)
            {
                atMessageBox.Show(MessageKeys.MsgInvalidUserNameOrPassword);
                UICommon.isLogined = false;
                txtUserName.Focus();
            }
            else
            {
                List<int> entUserLocations = new List<int>();
                if ((GlobalFunctions.blnFilterBranchInMasters || GlobalFunctions.blnMultiBranchManagement) 
                    && _currentUser.FK_RoleID != (int)ENUserRole.Administrators
                    && _currentUser.FK_RoleID!=(int)ENUserRole.BuiltinAdmin && _currentUser.FK_RoleID!=(int)ENUserRole.PowerUsers
                    )
                {
                    GlobalFunctions.LoginLocationID = cmbLocation.SelectedValue.ToString2().ToInt32();
                    ANIHelper _anihelper = new ANIHelper();
                    int iUserLocationID = _currentUser.LocationID.ToInt32();
                    entUserLocations = _anihelper.GetBranchIDs(iUserLocationID);
                    if (!entUserLocations.Contains(GlobalFunctions.LoginLocationID))
                    {
                        atMessageBox.Show(MessageKeys.MsgUserNotFoundOnSelectedBranch);
                        UICommon.isLogined = false;
                        txtUserName.Focus();
                        return;
                    }
                }

                UICommon.isLogined = true;                

                GlobalFunctions.LoginUserID = _currentUser.id;
                GlobalFunctions.LoginLocationID = cmbLocation.SelectedValue.ToString2().ToInt32();
                ANIHelper _anihelp = new ANIHelper();
                GlobalFunctions.entCurrentLocations = _anihelp.GetBranchIDs(GlobalFunctions.LoginLocationID);
                GlobalFunctions.fnLoadANISettings();

                string sMdiCaption = "";
                if (GlobalFunctions.blnModernDashboard)
                {
                    sMdiCaption = MessageKeys.MsgApplicationName + "        Current Company:  " + GlobalFunctions.DatabaseName
                    + "        Financial Period:  " + GlobalFunctions.sfinancialPeriodName 
                    + "     Location : " + cmbLocation.Text;
                }
                else
                {
                    sMdiCaption = MessageKeys.MsgApplicationName + "        Current Company:  " + GlobalFunctions.DatabaseName
                    + "        Financial Period:  " + GlobalFunctions.sfinancialPeriodName + "         Login User: " + txtUserName.Text
                    + "     Location : " + cmbLocation.Text;
                    UICommon.frmMdi.Text = sMdiCaption;
                }
                ANIHelper anihelper = new ANIHelper();
                GlobalFunctions.LoginSessionID = anihelper.GetSessionID(_currentUser.id);

                if (GlobalFunctions.sAutoBackupPath != "" && GlobalFunctions.blnBackupWhileLogin)
                {
                    UICommon.AutoBackup(true);
                }
                this.DialogResult = DialogResult.OK;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        private void txtUserName_Validating(object sender, CancelEventArgs e)
        {
            PopulateLocations();
        }
        private void cmbLocation_KeyDown(object sender, KeyEventArgs e)
        {
            btnOK_Click(sender, e);
        }
        private void lblAboutUs_Click(object sender, EventArgs e)
        {
            HotelAboutUSView abt = new HotelAboutUSView();
            abt.Show();
        }
        private void lblOpenCompany_Click(object sender, EventArgs e)
        {
            ShowOpenCompany = true;
            this.DialogResult = DialogResult.Cancel;
        }
        private void lblForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            atACC.ADM.Tools.AdminVerificationView frmAdm = new atACC.ADM.Tools.AdminVerificationView();
            if (frmAdm.ShowDialog() == DialogResult.OK)
            {
                if (!frmAdm.blnSuccess)
                {
                    return;
                }
                else
                {
                    ResetPassword();
                }
            }
            else
            {
                return;
            }
        }
        private void lblPinLogin_Click(object sender, EventArgs e)
        {
            if (pinlogin == null)
            {
                pinlogin = new NumberLoginView();
            }
            this.Hide();
            Properties.Settings.Default.NumberLogIn = true;
            Properties.Settings.Default.Save();
            DialogResult dialogResult = pinlogin.ShowDialog();
            if (dialogResult == DialogResult.Abort)
            {
                this.Show();
                Properties.Settings.Default.NumberLogIn = false;
                Properties.Settings.Default.Save();
            }
            else
            {
                this.ShowOpenCompany = pinlogin.ShowOpenCompany;
                this.DialogResult = dialogResult;
            }
        }
        #endregion

        #region Public Events
        private void pnlMain_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = new Point(e.X, e.Y);
        }
        private void pnlMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (downPoint == Point.Empty)
            {
                return;
            }
            Point location = new Point(
                this.Left + e.X - downPoint.X,
                this.Top + e.Y - downPoint.Y);
            this.Location = location;
        }
        private void pnlMain_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = Point.Empty;
        }
        #endregion
        
    }
}
