﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using System.Data.SqlClient;
using atACC.Common;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.HTL.UI.UIClasses;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
using System.IO;
using System.Reflection;
using atACCORM;
using System.Globalization;
using atACC.CommonExtensions;

namespace atACC.HTL.UI
{
    public partial class frmNewCompany : FormBase
    {
        #region private Variables
        string sDatabaseName, sDataBasePath;
        Restore dbRestore;
        Server DbServer;
        #endregion
        #region Constructor
        public frmNewCompany()
        {
            InitializeComponent();
            populateAllDatabases();
        }
        #endregion
        #region Old Method
        private void MakeDbToSingleUserMode(string ServerName, string DatabaseName)
        {
            string connectionString1 = (@"Data Source=" + ServerName + ";Initial Catalog=master;Persist Security Info=True;User ID=" + GlobalFunctions.DbUserName + ";Password=" + GlobalFunctions.DbPassword);
            using (SqlConnection Con = new SqlConnection(connectionString1))
            {
                try
                {
                    Con.Open();

                    string sqlStmt2 = string.Format("ALTER DATABASE [" + DatabaseName + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE");
                    SqlCommand bu2 = new SqlCommand(sqlStmt2, Con);
                    bu2.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (Con.State == ConnectionState.Open)
                    {
                        Con.Close();
                    }
                }
            }
        }
        private void CreateNewCompany(string filePath, string ServerName, string DatabaseName)
        {
            string connectionString1 = (@"Data Source=" + ServerName + ";Initial Catalog=master;Persist Security Info=True;User ID=" + GlobalFunctions.DbUserName + ";Password=" + GlobalFunctions.DbPassword);
            using (SqlConnection Con = new SqlConnection(connectionString1))
            {
                try
                {
                    Con.Open();

                    string sqlStmt2 = string.Format("ALTER DATABASE [" + DatabaseName + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE");
                    SqlCommand bu2 = new SqlCommand(sqlStmt2, Con);
                    bu2.ExecuteNonQuery();

                    string sqlStmt3 = "RESTORE DATABASE [" + DatabaseName + "] FROM  DISK = N'D:\\atACCMas.bak' WITH  FILE = 13,  MOVE N'atACCNetProject' TO N'" + filePath + @"\\" + DatabaseName + "Data.mdf',  MOVE N'atACCNetProject_log' TO N'" + filePath + @"\\" + DatabaseName + "Log.ldf',  NOUNLOAD,  REPLACE,  STATS = 5";
                    SqlCommand bu3 = new SqlCommand(sqlStmt3, Con);
                    bu3.ExecuteNonQuery();

                    string sqlStmt4 = string.Format("ALTER DATABASE [" + DatabaseName + "] SET MULTI_USER");
                    SqlCommand bu4 = new SqlCommand(sqlStmt4, Con);
                    bu4.ExecuteNonQuery();

                    Con.Close();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (Con.State == ConnectionState.Open)
                    {
                        Con.Close();
                    }
                }
            }

        }
        #endregion
        #region private methods
        private void CreateDatabase(string filePath,string ServerName,string DatabaseName)
        {
            lblStatus.Invoke((MethodInvoker)delegate
            {
                lblStatus.Visible = true;
                lblStatus.Text = "Please wait, Creating Blank Database";
            });
            String str;
            using (SqlConnection myConn = new SqlConnection("Server=" + ServerName + ";Integrated security=SSPI;database=master;"))
            {
                str = "CREATE DATABASE [" + DatabaseName + "] ON PRIMARY " +
                   "(NAME = N'" + DatabaseName + "', " +
                   "FILENAME ='" + filePath + @"\\" + DatabaseName + "Data.mdf', " +
                   "SIZE = 5MB, FILEGROWTH = 10%) " +
                   "LOG ON (NAME =N'" + DatabaseName + "_Log', " +
                   "FILENAME = '" + filePath + @"\\" + DatabaseName + "Log.ldf', " +
                   "SIZE = 5MB" +
                   ", " +
                   "FILEGROWTH = 10%)";
                ExecuteSql(str, myConn);
            }
        }
        private void ExecuteSql(string str, SqlConnection myConn)
        {
            SqlCommand myCommand = new SqlCommand(str, myConn);
            try
            {
                myConn.Open();
                myCommand.CommandTimeout = 0;
                myCommand.ExecuteNonQuery();
                lblStatus.Invoke((MethodInvoker)delegate
                {
                    lblStatus.Visible = true;
                    lblStatus.Text = "Please wait, Creating Blank Database";
                });
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (myConn.State == ConnectionState.Open)
                {
                    myConn.Close();
                }
            }
        }
        public  void RestoreDatabase(string serverName, string databaseName)
        {
            DbServer = new Server(new ServerConnection(serverName));
            pbar.Value = 0;
            try
            {
                lblStatus.Invoke((MethodInvoker)delegate
                {
                    lblStatus.Text = "Restoring Mas Database.";
                });

                dbRestore = new Restore();
                string sPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                dbRestore.Devices.AddDevice(sPath + "\\atACCMas.bak", DeviceType.File);
                dbRestore.Database = databaseName;
                RelocateFile DataFile = new RelocateFile();
                string MDF = dbRestore.ReadFileList(DbServer).Rows[0][1].ToString();
                DataFile.LogicalFileName = dbRestore.ReadFileList(DbServer).Rows[0][0].ToString();
                DataFile.PhysicalFileName = DbServer.Databases[databaseName].FileGroups[0].Files[0].FileName;

                RelocateFile LogFile = new RelocateFile();
                string LDF = dbRestore.ReadFileList(DbServer).Rows[1][1].ToString();
                LogFile.LogicalFileName = dbRestore.ReadFileList(DbServer).Rows[1][0].ToString();
                LogFile.PhysicalFileName = DbServer.Databases[databaseName].LogFiles[0].FileName;


                dbRestore.RelocateFiles.Add(DataFile);
                dbRestore.RelocateFiles.Add(LogFile);
                dbRestore.Action = RestoreActionType.Database;
                
                dbRestore.NoRecovery = false;
                dbRestore.ReplaceDatabase = true;
                dbRestore.PercentComplete+=dbRestore_PercentComplete;
                dbRestore.Complete += dbRestore_Complete;
                dbRestore.SqlRestoreAsync(DbServer);
                
            }
            catch (SmoException ex)
            {
                throw new SmoException(ex.Message, ex.InnerException);
            }
            catch (IOException ex)
            {
                throw new IOException(ex.Message, ex.InnerException);
            }
        }
        #endregion
        #region Restore Events
        void dbRestore_Complete(object sender, ServerMessageEventArgs e)
        {
            if (e.Error != null)
            {
                lblStatus.Invoke((MethodInvoker)delegate
                {
                    lblStatus.Text = e.Error.Message;
                });
                GlobalFunctions.DatabaseName = sDatabaseName;
                GlobalFunctions.GenerateEntityConnection();
                MessageBox.Show("New Company Created...", MessageKeys.MsgApplicationName);
                this.DialogResult = DialogResult.OK;
            }
        }
        void dbRestore_PercentComplete(object sender, PercentCompleteEventArgs e)
        {
            pbar.Invoke((MethodInvoker)delegate
            {
                pbar.Value = e.Percent;
                pbar.Update();
            });
            lblPercentage.Invoke((MethodInvoker)delegate
            {
                lblPercentage.Text = e.Percent.ToString() + "%";
            });
        }
        #endregion
        #region private events
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(txtCompany.Text))
                {
                    errprvdr.SetError(txtCompany, "Company already exist choose different name!");
                    return;
                }
                if (txtCompany.Text.Trim() == "")
                {
                    errprvdr.SetError(txtCompany, "Company Must be Selected!");
                    return;
                }
                if(chktemplate.Checked)
                {
                    if(cmbdatabase.Text.Trim()=="")
                    {
                        MessageBox.Show("Template database must be selected!");
                        return;
                    }
                }
                this.Cursor = Cursors.WaitCursor;
                sDatabaseName = txtCompany.Text.Substring(txtCompany.Text.LastIndexOf('\\')+1);
                sDataBasePath = txtCompany.Text.Substring(0, txtCompany.Text.LastIndexOf('\\'));
                CreateDatabase(sDataBasePath, GlobalFunctions.ServerName, sDatabaseName);
                ExecuteScript(GlobalFunctions.ServerName, sDatabaseName, "MasScript.sql");
                GlobalFunctions.DatabaseName = sDatabaseName;
                GlobalFunctions.sWindowsAuthenticationConnectionString = "Server=" + GlobalFunctions.ServerName + ";Integrated security=SSPI;database=" + GlobalFunctions.DatabaseName + ";";
                GlobalFunctions.sSqlAuthenticationConnectionString = @"Server=" + GlobalFunctions.ServerName + ";Integrated Security=False;User ID=" + GlobalFunctions.DbUserName + ";Password=" + GlobalFunctions.DbPassword + ";database=" + GlobalFunctions.DatabaseName + ";";
                try
                {
                    if (UICommon.isUpgradeRequired(true))
                    {
                        UICommon.UpgradeView(true);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Upgrade Failed...Check for Sql Authentication!");
                }
                if(chktemplate.Checked)
                {
                    CopyFromTemplateDb();
                }
                GlobalFunctions.GenerateEntityConnection();
                using (atACCContextEntities db = atContext.CreateContext())
                {
                    RegionInfo regionInfo = RegionInfo.CurrentRegion;

                    List<MasterValue> countryList = db.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.CountryList &&
                        x.Name.ToUpper().Contains(regionInfo.EnglishName.ToUpper())).ToList();
                    if (countryList.Count > 0)
                    {
                        Company company = db.Companies.SingleOrDefault();
                        company.FK_Country = countryList.First().id;
                        company.FK_Currency = db.CurrencyHDRs.Where(x => x.FK_MasterValueCountryID == company.FK_Country).SingleOrDefault().id;
                        db.ObjectStateManager.ChangeObjectState(company, EntityState.Modified);
                        db.SaveChanges();
                    }
                        
                }


                MessageBox.Show("Company Created Successfully");
                lblStatus.Text = "Blank Database Created.";
                this.Cursor = Cursors.Arrow;
                this.DialogResult = DialogResult.OK;
                
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show(ex.Message,MessageKeys.MsgApplicationName);
                this.Cursor = Cursors.Arrow;
            }
            
        }
        #region Script Work for Template
        private static List<string> masTables;
        public static string DeleteMasScript = @"
            delete from TB_ADM_Slab
            delete from TB_ADM_ProductGroup
            delete from TB_ADM_Product
            delete from TB_ADM_ProductVRL
            delete from TB_ADM_ProductUnits
            delete from TB_ADM_ProductRates
            delete from TB_ADM_ProductSlab
            delete from TB_ADM_ProductBatch
            delete from TB_ADM_ProductSupplierMapping
            delete from TB_ADM_ProductOpeningStock
            delete from TB_ANI_AccountGroup
            delete from TB_ANI_AccountLedger
            delete from TB_ADM_Party
            delete from TB_ADM_PartyDTL
            delete from TB_ADM_Supplier
            delete from TB_ADM_SupplierDTL
            delete from TB_ADM_Employee
            delete from TB_ADM_EmployeeDTL
            delete from TB_ADM_FinanPeriod
            delete from TB_ADM_FinanPeriodDTL
            delete from TB_ADM_Project
            delete from TB_ADM_Bank
            delete from TB_ADM_BankDTL
            delete from TB_ADM_Agent
            delete from TB_ADM_AgentDTL
            delete from TB_ADM_Manufacturer
            delete from TB_ADM_LoginUser
            delete from TB_ADM_RoleAccessRights
            delete from TB_ADM_UserRole
            delete from TB_ANI_ANISetings
            delete from TB_ADM_Branch
            delete from TB_ADM_BranchDTL
            delete from TB_ADM_Denomination
            delete from TB_ADM_CurrencyHDR
            delete from TB_ADM_CurrencyDTL
            delete from TB_ADM_Distributer
            delete from TB_ADM_EditLock
            delete from TB_ADM_InvoiceDesignForm
            delete from TB_ADM_LoginSetting
            delete from TB_ADM_LoginSettingsMapping
            delete from TB_ADM_LoyaltyCard
            delete from TB_ADM_LoyaltyCustomer
            delete from TB_ADM_LoginSettingsMapping
            delete from TB_ADM_LoyaltyGeneralSetting
            delete from TB_ADM_LoyaltyPointSetting
            delete from TB_ADM_LoyaltyProgramHDR
            delete from TB_ADM_LoyaltyProgramDTL
            delete from TB_ADM_LoyaltyProductMapping
            delete from TB_ADM_MasterType
            delete from TB_ADM_MasterValue
            delete from TB_ADM_MenuAccessRights
            delete from TB_ADM_MultiRate
            delete from TB_ADM_OtherSetting
            delete from TB_ADM_PeriodRange
            delete from TB_ADM_PriceCode
            delete from TB_ADM_ProjectStatus
            delete from TB_ANI_ANIDecimalSettings
            delete from TB_ANI_ANIVariables
            delete from TB_ANI_DepoPrefix
            delete from TB_ANI_Service
            delete from TB_ANI_ServiceGroup
            delete from TB_ANI_ServiceSlab
            delete from TB_ANI_SlabAccountSetting
            delete from TB_ANI_DepoPrefix
            ";
        private static void initMasTables()
        {
            masTables = new List<string>();
            masTables.Add("TB_ADM_Slab");
            masTables.Add("TB_ADM_ProductGroup");
            masTables.Add("TB_ADM_Product");
            masTables.Add("TB_ADM_ProductVRL");
            masTables.Add("TB_ADM_ProductUnits");
            masTables.Add("TB_ADM_ProductRates");
            masTables.Add("TB_ADM_ProductSlab");
            masTables.Add("TB_ADM_ProductBatch");
            masTables.Add("TB_ADM_ProductSupplierMapping");
            masTables.Add("TB_ANI_AccountGroup");
            masTables.Add("TB_ANI_AccountLedger");
            masTables.Add("TB_ADM_Party");
            masTables.Add("TB_ADM_PartyDTL");
            masTables.Add("TB_ADM_Supplier");
            masTables.Add("TB_ADM_SupplierDTL");
            masTables.Add("TB_ADM_Employee");
            masTables.Add("TB_ADM_EmployeeDTL");
            masTables.Add("TB_ADM_FinanPeriod");
            masTables.Add("TB_ADM_FinanPeriodDTL");
            masTables.Add("TB_ADM_Project");
            masTables.Add("TB_ADM_Bank");
            masTables.Add("TB_ADM_BankDTL");
            masTables.Add("TB_ADM_Agent");
            masTables.Add("TB_ADM_AgentDTL");
            masTables.Add("TB_ADM_Manufacturer");
            masTables.Add("TB_ADM_LoginUser");
            masTables.Add("TB_ADM_RoleAccessRights");
            masTables.Add("TB_ADM_UserRole");
            masTables.Add("TB_ANI_ANISetings");

            masTables.Add("TB_ADM_Branch");
            masTables.Add("TB_ADM_BranchDTL");
            masTables.Add("TB_ADM_Denomination");
            masTables.Add("TB_ADM_CurrencyHDR");
            masTables.Add("TB_ADM_CurrencyDTL");
            masTables.Add("TB_ADM_Distributer");
            masTables.Add("TB_ADM_EditLock");
            masTables.Add("TB_ADM_InvoiceDesignForm");
            masTables.Add("TB_ADM_LoginSetting");
            masTables.Add("TB_ADM_LoginSettingsMapping");
            masTables.Add("TB_ADM_LoyaltyCard");
            masTables.Add("TB_ADM_LoyaltyCustomer");
            masTables.Add("TB_ADM_LoginSettingsMapping");
            masTables.Add("TB_ADM_LoyaltyGeneralSetting");
            masTables.Add("TB_ADM_LoyaltyPointSetting");
            masTables.Add("TB_ADM_LoyaltyProgramHDR");
            masTables.Add("TB_ADM_LoyaltyProgramDTL");
            masTables.Add("TB_ADM_LoyaltyProductMapping");
            masTables.Add("TB_ADM_MasterType");
            masTables.Add("TB_ADM_MasterValue");
            masTables.Add("TB_ADM_MenuAccessRights");
            masTables.Add("TB_ADM_MultiRate");
            masTables.Add("TB_ADM_OtherSetting");
            masTables.Add("TB_ADM_PeriodRange");
            masTables.Add("TB_ADM_PriceCode");
            masTables.Add("TB_ADM_ProjectStatus");
            masTables.Add("TB_ANI_ANIDecimalSettings");
            masTables.Add("TB_ANI_ANIVariables");
            masTables.Add("TB_ANI_DepoPrefix");
            masTables.Add("TB_ANI_Service");
            masTables.Add("TB_ANI_ServiceGroup");
            masTables.Add("TB_ANI_ServiceSlab");
            masTables.Add("TB_ANI_SlabAccountSetting");
            masTables.Add("TB_ANI_DepoPrefix");
        }

        public  void GenerateMasterScript()
        {
            try
            {
                initMasTables();
                string sPath = Application.StartupPath;
                if (!Directory.Exists(sPath))
                {
                    Directory.CreateDirectory(sPath);
                }
                string sFileID = Guid.NewGuid().ToString();
                string sFileName = sPath + "\\MasterFile.sql";
                if (File.Exists(sFileName))
                {
                    File.Delete(sFileName);
                }
                StringBuilder sb = new StringBuilder();
                string sconnString = "Server=" + GlobalFunctions.ServerName + ";Integrated security=SSPI;database=" + cmbdatabase.Text + ";";
                SqlConnection conn = new SqlConnection(sconnString);
                Server srv = new Server(new Microsoft.SqlServer.Management.Common.ServerConnection(conn));
                Database dbs = srv.Databases[cmbdatabase.Text];
                ScriptingOptions options = new ScriptingOptions();
                options.ScriptData = true;
                options.ScriptDrops = false;
                options.FileName = sFileName;
                options.EnforceScriptingOptions = true;
                options.ScriptSchema = false;
                options.IncludeHeaders = true;
                options.AppendToFile = true;
                options.Indexes = true;
                options.WithDependencies = false;
                int i = 1;
                int totalTabs = masTables.Count;
                pbar.Maximum = totalTabs;
                pbar.Value = 0;
                foreach (var tbl in masTables)
                {
                    dbs.Tables[tbl].EnumScript(options);
                    
                    pbar.Value = i;
                    lblStatus.Text = "Generating Master Script " + tbl;
                    Application.DoEvents();
                    i = i + 1;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
          
        }
        //private void ReadMasterScript()
        //{
        //    string sSqlScript = "";
        //    string sPath = Application.StartupPath + @"\MasterFile.sql";
        //    if(!File.Exists(sPath))
        //    {
        //        return;
        //    }
        //    sSqlScript = File.ReadAllText(sPath);
        //    string sconnString = "Server=" + GlobalFunctions.ServerName + ";Integrated security=SSPI;database=" + GlobalFunctions.DatabaseName + ";";
        //    using (SqlConnection _conn = new SqlConnection(sconnString))
        //    {
        //        try
        //        {
        //            _conn.Open();
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = _conn; cmd.CommandTimeout = 0;
        //            cmd.CommandText = " exec sp_MSforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL';";
        //            cmd.ExecuteNonQuery();
        //            Server server = new Server(new ServerConnection(_conn));
        //            server.ConnectionContext.ExecuteNonQuery(DeleteMasScript);
        //            server.ConnectionContext.ExecuteNonQuery(sSqlScript);
        //            cmd = new SqlCommand();
        //            cmd.Connection = _conn; cmd.CommandTimeout = 0;
        //            cmd.CommandText = " exec sp_MSforeachtable 'ALTER TABLE ? CHECK CONSTRAINT ALL';";
        //            cmd.ExecuteNonQuery();


        //            cmd = new SqlCommand();
        //            cmd.Connection = _conn; cmd.CommandTimeout = 0;
        //            cmd.CommandText = "delete from TB_ADM_ProductRates where isnull(isDefault,0)=0";
        //            cmd.ExecuteNonQuery();
        //        }
        //        catch (Exception ex)
        //        {

        //            throw ex;
        //        }
        //        finally
        //        {
        //            _conn.Close();
                    
        //        }
        //    }
        //}
        #endregion
        private void CopyFromTemplateDb()
        {
            try
            {
                lblStatus.Invoke((MethodInvoker)delegate
                {
                    lblStatus.Visible = true;
                    lblStatus.Text = "Please wait, Copying template data...";
                });
                GenerateMasterScript();
                lblStatus.Invoke((MethodInvoker)delegate
                {
                    lblStatus.Visible = true;
                    lblStatus.Text = "Please wait, Restoring master data...";
                });
                ExecuteScriptMaster(GlobalFunctions.ServerName, GlobalFunctions.DatabaseName, "MasterFile.sql");
                
                lblStatus.Invoke((MethodInvoker)delegate
                {
                    lblStatus.Visible = true;
                    lblStatus.Text = "Template Data Copied...";
                });
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void populateAllDatabases()
        {
            DataTable dtDatabases = new DataTable();
            string sql = @"SELECT [name] FROM master.dbo.sysdatabases WHERE dbid > 4 ";
            using (SqlConnection con = new SqlConnection(@"Server=" + GlobalFunctions.ServerName + ";Integrated security=SSPI;database=master;"))
            {
                con.Open();
                try
                {
                    SqlDataAdapter dad = new SqlDataAdapter(sql, con);
                    dad.Fill(dtDatabases);
                    cmbdatabase.DataSource = dtDatabases;
                    cmbdatabase.DisplayMember = "name";
                    cmbdatabase.ValueMember = "name";
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    ExceptionManager.Publish(ex);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        private bool ExecuteScriptMaster(string ServerName, string DatabaseName, string sFileName)
        {
            if (File.Exists(Application.StartupPath + "\\" + sFileName))
            {
                pbar.Minimum = 0;
                string script = null;
                script = File.ReadAllText(Application.StartupPath + "\\" + sFileName);
                string[] ScriptSplitter = script.Split(new string[] { "GO" }, StringSplitOptions.None);
                using (SqlConnection con = new SqlConnection(@"Server=" + ServerName + ";Integrated security=SSPI;database=" + DatabaseName + ";"))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = " exec sp_MSforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL';";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand(); cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "DELETE FROM TB_ADM_FinanPeriod ";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand(); cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "DELETE FROM TB_ADM_FinanPeriodDTL ";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand(); cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "DELETE FROM TB_ANI_ANISetings ";
                    cmd.ExecuteNonQuery();



                    pbar.Maximum = ScriptSplitter.Length;

                    pbar.Value = 0;
                    int counter = 0;
                    double dblPercentage = 0, dblLength = 0;
                    dblLength = ScriptSplitter.Length;
                    foreach (string str in ScriptSplitter)
                    {
                        using (SqlCommand command = con.CreateCommand())
                        {
                            try
                            {
                                Application.DoEvents();
                                dblPercentage = (counter / dblLength) * 100.00;
                                lblPercentage.Text = Math.Round(dblPercentage, 0).ToString() + "%";
                                lblPercentage.Refresh();
                                command.CommandText = str;
                                command.CommandTimeout = 0;
                                command.ExecuteNonQuery();
                            }
                            catch
                            {

                            }
                        }
                        pbar.Value = counter;
                        counter++;
                    }

                    cmd = new SqlCommand();
                    cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "delete from TB_ADM_ProductRates where isnull(isDefault,0)=0";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand();
                    cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "update TB_ADM_Party set FK_VoucherHDRID = null";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand();
                    cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "update TB_ADM_PartyDTL set OpeningBalance = 0";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand();
                    cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "update TB_ADM_Supplier set FK_VoucherHDRID = null";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand();
                    cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = "update TB_ADM_SupplierDTL set OpeningBalance = 0";
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand();
                    cmd.Connection = con; cmd.CommandTimeout = 0;
                    cmd.CommandText = " exec sp_MSforeachtable 'ALTER TABLE ? CHECK CONSTRAINT ALL';";
                    cmd.ExecuteNonQuery();
                }
            }
            else
            {
                MessageBox.Show("Mas File Doesnot Exist Contat Your Administrator!");
            }
            return true;
        }
        private bool ExecuteScript(string ServerName, string DatabaseName,string sFileName)
        {
            if (File.Exists(Application.StartupPath + "\\" + sFileName))
            {
                pbar.Minimum = 0;
                string script = null;
                script = File.ReadAllText(Application.StartupPath + "\\" + sFileName);
                string[] ScriptSplitter = script.Split(new string[] { "GO" }, StringSplitOptions.None);
                using (SqlConnection con = new SqlConnection(@"Server=" + ServerName + ";Integrated security=SSPI;database=" + DatabaseName + ";"))
                {
                    con.Open();

                    pbar.Maximum = ScriptSplitter.Length;

                    pbar.Value = 0;
                    int counter = 0;
                    double dblPercentage = 0,dblLength=0;
                    dblLength = ScriptSplitter.Length;
                    foreach (string str in ScriptSplitter)
                    {
                        using (SqlCommand command = con.CreateCommand())
                        {
                            try
                            {
                                Application.DoEvents();
                                dblPercentage = (counter / dblLength) * 100.00;
                                lblPercentage.Text = Math.Round(dblPercentage, 0).ToString() + "%";
                                lblPercentage.Refresh();
                                command.CommandText = str;
                                command.CommandTimeout = 0;
                                command.ExecuteNonQuery();
                            }
                            catch
                            {

                            }
                        }
                        pbar.Value = counter;
                        counter++;
                    }
                }
            }
            else
            {
                MessageBox.Show("Mas File Doesnot Exist Contat Your Administrator!");
            }
            return true;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            //svFileDilog.Filter = "MDF File(*.MDF)|*.mdf";
            if (svFileDilog.ShowDialog() == DialogResult.OK)
            {
                txtCompany.Text = svFileDilog.FileName;
            }
        }
        #endregion

        private void btnSqlAuthentication_Click(object sender, EventArgs e)
        {
            try
            {
                if (GlobalFunctions.ServerName == "")
                {
                    MessageBox.Show("Server Name Can't be blank!");
                    return;
                }
                this.Cursor = Cursors.WaitCursor;
                 String str;
                 using (SqlConnection myConn = new SqlConnection("Server=" + GlobalFunctions.ServerName + ";Integrated security=SSPI;database=master;"))
                 {
                   
                     try
                     {
                         str = @" EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2 ";
                         ExecuteSql(str, myConn);
                         MessageBox.Show("Authentication Mode applied you must restart the sql service ");
                     }
                     catch { }
                    
                 }
             


                this.Cursor = Cursors.Arrow;
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                MessageBox.Show(ex.Message, MessageKeys.MsgApplicationName);
                this.Cursor = Cursors.Arrow;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }

        private void chktemplate_CheckedChanged(object sender, EventArgs e)
        {
            cmbdatabase.Enabled = chktemplate.Checked;
        }

        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
    }
}
