﻿namespace atACC.HTL.UI
{
    partial class frmOpenCompany
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOpenCompany));
            this.lblServer = new System.Windows.Forms.Label();
            this.errorprvdr = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnClose = new System.Windows.Forms.Button();
            this.btnPopulateInstances = new System.Windows.Forms.Button();
            this.lstCompanies = new atACCFramework.UserControls.atListBox();
            this.atLabel5 = new atACCFramework.UserControls.atLabel();
            this.cmbServer = new atACCFramework.UserControls.ComboBoxExt();
            this.pnlFooter = new atACCFramework.UserControls.atPanel();
            this.btnCancel = new atACCFramework.UserControls.atButton();
            this.btnOpen = new atACCFramework.UserControls.atButton();
            ((System.ComponentModel.ISupportInitialize)(this.errorprvdr)).BeginInit();
            this.pnlFooter.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblServer
            // 
            resources.ApplyResources(this.lblServer, "lblServer");
            this.lblServer.Name = "lblServer";
            // 
            // errorprvdr
            // 
            this.errorprvdr.ContainerControl = this;
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // btnPopulateInstances
            // 
            this.btnPopulateInstances.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnPopulateInstances.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnPopulateInstances, "btnPopulateInstances");
            this.btnPopulateInstances.ForeColor = System.Drawing.Color.White;
            this.btnPopulateInstances.Name = "btnPopulateInstances";
            this.btnPopulateInstances.UseVisualStyleBackColor = false;
            this.btnPopulateInstances.Click += new System.EventHandler(this.btnPopulateInstances_Click);
            // 
            // lstCompanies
            // 
            this.lstCompanies.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lstCompanies.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.lstCompanies, "lstCompanies");
            this.lstCompanies.FormattingEnabled = true;
            this.lstCompanies.Name = "lstCompanies";
            this.lstCompanies.SelectedIndexChanged += new System.EventHandler(this.lstCompanies_SelectedIndexChanged);
            this.lstCompanies.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstCompanies_MouseDoubleClick);
            // 
            // atLabel5
            // 
            resources.ApplyResources(this.atLabel5, "atLabel5");
            this.atLabel5.Name = "atLabel5";
            this.atLabel5.RequiredField = false;
            // 
            // cmbServer
            // 
            this.cmbServer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbServer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbServer.DropDownHeight = 300;
            resources.ApplyResources(this.cmbServer, "cmbServer");
            this.cmbServer.FormattingEnabled = true;
            this.cmbServer.Name = "cmbServer";
            this.cmbServer.SelectedIndexChanged += new System.EventHandler(this.cmbServer_SelectedIndexChanged);
            this.cmbServer.TextChanged += new System.EventHandler(this.cmbServer_TextChanged);
            this.cmbServer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbServer_KeyDown);
            // 
            // pnlFooter
            // 
            resources.ApplyResources(this.pnlFooter, "pnlFooter");
            this.pnlFooter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlFooter.Controls.Add(this.btnCancel);
            this.pnlFooter.Controls.Add(this.btnOpen);
            this.pnlFooter.Name = "pnlFooter";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnOpen.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnOpen, "btnOpen");
            this.btnOpen.ForeColor = System.Drawing.Color.White;
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.UseVisualStyleBackColor = false;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // frmOpenCompany
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnPopulateInstances);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lstCompanies);
            this.Controls.Add(this.atLabel5);
            this.Controls.Add(this.cmbServer);
            this.Controls.Add(this.lblServer);
            this.Controls.Add(this.pnlFooter);
            this.MaximizeBox = false;
            this.Name = "frmOpenCompany";
            this.Load += new System.EventHandler(this.frmOpenCompany_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorprvdr)).EndInit();
            this.pnlFooter.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblServer;
        private atACCFramework.UserControls.atLabel atLabel5;
        private atACCFramework.UserControls.ComboBoxExt cmbServer;
        private atACCFramework.UserControls.atListBox lstCompanies;
        private atACCFramework.UserControls.atPanel pnlFooter;
        private atACCFramework.UserControls.atButton btnCancel;
        private atACCFramework.UserControls.atButton btnOpen;
        private System.Windows.Forms.ErrorProvider errorprvdr;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnPopulateInstances;
    }
}