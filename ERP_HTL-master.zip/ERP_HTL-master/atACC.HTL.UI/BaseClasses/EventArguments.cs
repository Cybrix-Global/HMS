﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACCFramework.ReportBases;
using System.Data;
using atACCORM;
namespace atACC.HTL.UI
{
    #region Event Arguments
    public class SaveClickEventArgs : EventArgs
    {
        private EventArgs EventInfo;
        public SaveClickEventArgs(EventArgs e)
        {
            EventInfo = e;
        }
        public EventArgs GetInfo()
        {
            return EventInfo;
        }
    }
    public class PreviewClickEventArgs : EventArgs
    {
        public PreviewClickEventArgs()
        {
            reportParameters = new List<atReportParameter>();
        }
        public string ReportPath;
        public List<atReportParameter> reportParameters;
        public DataSet DataSource;
        public bool blnFromPOS;
    }
    public class DesignClickEventArgs:EventArgs
    {
        public DesignClickEventArgs()
        {
            
        }
        public string ReportPath;
    }
    public class EditClickEventArgs : EventArgs
    {
        private EventArgs EventInfo;
        public EditClickEventArgs(EventArgs e)
        {
            EventInfo = e;
        }
        public EventArgs GetInfo()
        {
            return EventInfo;
        }
    }
    public class DeleteClickEventArgs : EventArgs
    {
        private EventArgs EventInfo;
        public DeleteClickEventArgs(EventArgs e)
        {
            EventInfo = e;
        }
        public EventArgs GetInfo()
        {
            return EventInfo;
        }
    }
    public class AfterSearchEventArgs : EventArgs
    {
        private object EventInfo;
        public AfterSearchEventArgs(object e)
        {
            EventInfo = e;
        }
        public object GetSelectedEntity()
        {
            return EventInfo;
        }
    }
    public class BeforeSearchEventArgs : EventArgs
    {
        public IEnumerable<Object> SearchEntityList { get; set; }
        public int MVTransactionType { get; set; }
        public BeforeSearchEventArgs()
        {
           
        }
        
    }
    
    #endregion
}
