﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACCFramework.BaseClasses;

namespace atACC.HTL.UI
{
    #region Delegates
    public delegate void BeforeInitialiseEventHandler();
    public delegate void InitialiseEventHandler();
    public delegate void AfterInitialiseEventHandler();
    public delegate void NewClickEventHandler(object source);
    public delegate bool ValidateEventHandler(object source);
    public delegate bool SaveClickEventHandler(object source, SaveClickEventArgs e);
    
    public delegate bool AfterSaveClickEventHandler(object source);
    public delegate bool EditClickEventHandler(object source, EditClickEventArgs e);
    public delegate void AfterEditClickEventHandler(object source, EditClickEventArgs e);
    public delegate bool DeleteClickEventHandler(object source, DeleteClickEventArgs e);
    public delegate void AfterDeleteEventHandler(object source);
    public delegate void BeforeClosingEventHandler(object source);
    public delegate void ClosingEventHandler(object source);
    public delegate void NotClosedEventHandler(object source);

    public delegate bool OnPrintEventHandler(object source);
    public delegate bool BarcodePrintEventHandler(object source);

    public delegate bool ValidateOKClickHandler(object source);
    public delegate bool OKClickEventHandler(object source, OKClickEventArgs e);
    public delegate void CancelClickEventHandler(object source, CancelClickEventArgs e);

    public delegate bool AfterSearchEventHandler(object source, AfterSearchEventArgs e);
    public delegate void BeforeSearchEventHandler(object source, BeforeSearchEventArgs e);
    public delegate void ShareEventHandler(object source);
    public delegate void PreviewClickEventHandler(object source,PreviewClickEventArgs e);
    public delegate void DesignClickEventHandler(object source, DesignClickEventArgs e);
    #endregion
}
