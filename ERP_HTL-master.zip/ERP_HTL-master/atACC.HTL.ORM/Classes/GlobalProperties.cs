﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
    public static class GlobalProperties
    {
        public static bool RefreshDashboard { get; set; }
        public static int RentAccountID { get; set; }
        public static int ExtraServicesAccountID { get; set; }
        public static int DeductionAccountID { get; set; }
        public static int LaundryAccountID { get; set; }
        public static int GuestAccountID { get; set; }
        public static int CashAccountID { get; set; }
        public static int CreditCardAccountID { get; set; }
        public static int ChequeAccountID { get; set; }
        public static int DDAccountID { get; set; }
        public static int OnlineBankingAccountID { get; set; }
        public static int EWalletAccountID { get; set; }
        public static int DiscountAccountID { get; set; }
        public static int ExciseDutyAccountID { get; set; }
        public static int Tax1AccountID { get; set; }
        public static int Tax2AccountID { get; set; }
        public static int Tax3AccountID { get; set; }
        public static int AdditionalTaxAccountID { get; set; }
        public static int VATAccountID { get; set; }
        public static int SGSTAccountID { get; set; }
        public static int CGSTAccountID { get; set; }
        public static int IGSTAccountID { get; set; }
        public static int RoundOffAccountID { get; set; }
        public static int iAnalysisPostCounter = -1;

        public static bool PrintPreview { get; set; }
        public static bool ShowPrintDialogue { get; set; }
        public static bool PrintWhileSavingInEnquiry { get; set; }
        public static bool PrintWhileSavingInBooking { get; set; }
        public static bool PrintWhileSavingInGroupBooking { get; set; }
        public static bool PrintWhileSavingInCheckIn { get; set; }
        public static bool PrintWhileSavingInGroupCheckIn { get; set; }
        public static bool PrintWhileSavingInCheckOut { get; set; }
        public static bool PrintWhileSavingInGroupCheckOut { get; set; }
        public static bool PrintWhileSavingInHouseKeeping { get; set; }
        public static bool PrintWhileSavingInLaundry { get; set; }
        public static bool PrintWhileSavingInRoomService { get; set; }
        public static bool PrintWhileSavingInComplaintRegister { get; set; }
        public static bool PrintWhileSavingInRoomShift { get; set; }

        public static bool SendEmailWhileSavingInBooking { get; set; }
        public static bool SendEmailWhileSavingInGroupBooking { get; set; }
        public static bool SendEmailWhileSavingInCheckIn { get; set; }
        public static bool SendEmailWhileSavingInGroupCheckIn { get; set; }
        public static bool SendEmailWhileSavingInCheckOut { get; set; }
        public static bool SendEmailWhileSavingInGroupCheckOut { get; set; }

        public static bool SendSMSWhileSavingInBooking { get; set; }
        public static bool SendSMSWhileSavingInGroupBooking { get; set; }
        public static bool SendSMSWhileSavingInCheckIn { get; set; }
        public static bool SendSMSWhileSavingInGroupCheckIn { get; set; }
        public static bool SendSMSWhileSavingInCheckOut { get; set; }
        public static bool SendSMSWhileSavingInGroupCheckOut { get; set; }
        public static int FlexibleTime { get; set; }
        public static DateTime? CheckInTime { get; set; }
        public static DateTime? CheckOutTime { get; set; }
    }
    public enum ENRoomStatus
    {
        Available = 1,
        Booking,
        GBooking,
        CheckIn,
        GCheckIn,
        Dirty,
        Clean,
        OutofOrder,
    }
    public enum ENExtraServiceTypes
    {
        Default = 0,
        Laundry = 1,
        RoomService =2
    }
    public enum ENDefaultUserSettings
    { 
        PrintPreview = 1,
        ShowPrintDialogue = 2,
        PrintWhileSavingInEnquiry = 3,
        PrintWhileSavingInBooking = 4,
        PrintWhileSavingInGroupBooking = 5,
        PrintWhileSavingInCheckIn = 6,
        PrintWhileSavingInGroupCheckIn = 7,
        PrintWhileSavingInCheckOut = 8,
        PrintWhileSavingInGroupCheckOut = 9,
        PrintWhileSavingInHouseKeeping = 10,
        PrintWhileSavingInLaundry = 11,
        PrintWhileSavingInRoomService = 12,
        PrintWhileSavingInComplaintRegister = 13,
        PrintWhileSavingInRoomShift = 14,
        SendEmailWhileSavingInBooking = 15,
        SendEmailWhileSavingInGroupBooking = 16,
        SendEmailWhileSavingInCheckIn = 17,
        SendEmailWhileSavingInGroupCheckIn = 18,
        SendEmailWhileSavingInCheckOut = 19,
        SendEmailWhileSavingInGroupCheckOut = 20,
        SendSMSWhileSavingInBooking = 21,
        SendSMSWhileSavingInGroupBooking = 22,
        SendSMSWhileSavingInCheckIn = 23,
        SendSMSWhileSavingInGroupCheckIn = 24,
        SendSMSWhileSavingInCheckOut = 25,
        SendSMSWhileSavingInGroupCheckOut = 26,
    }
}
