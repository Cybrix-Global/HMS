﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
    public partial class ExtraServiceDTLs
    {
        public int id { get; set; }
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }

        public Nullable<global::System.Int32> FK_ExtraServiceID { get; set; }

        public Nullable<global::System.Decimal> Qty { get; set; }

        public Nullable<global::System.Decimal> Rate { get; set; }
        public Nullable<global::System.Decimal> Amount { get; set; }
        public Nullable<global::System.Decimal> DeductionPerc { get; set; }
        public Nullable<global::System.Decimal> DeductionAmount { get; set; }
        public Nullable<global::System.Decimal> TotalTax { get; set; }
        public Nullable<global::System.Decimal> NetAmount { get; set; }
        public Nullable<global::System.Int32> FK_DiscountSlabID { get; set; }
        public Nullable<global::System.Decimal> SlabDiscountPerc { get; set; }
        public Nullable<global::System.Decimal> SlabDiscount { get; set; }
        public Nullable<global::System.Decimal> TotalDiscount { get; set; }
        public Nullable<global::System.Decimal> TaxableAmount { get; set; }
        public Nullable<global::System.Int32> FK_GSTSlabID { get; set; }
        public Nullable<global::System.Decimal> CGSTPerc { get; set; }
        public Nullable<global::System.Decimal> CGSTAmount { get; set; }
        public Nullable<global::System.Decimal> SGSTPerc { get; set; }
        public Nullable<global::System.Decimal> SGSTAmount { get; set; }
        public Nullable<global::System.Decimal> IGSTPerc { get; set; }
        public Nullable<global::System.Decimal> IGSTAmount { get; set; }
        public Nullable<global::System.Int32> FK_VATSlabID { get; set; }
        public Nullable<global::System.Decimal> VATPerc { get; set; }
        public Nullable<global::System.Decimal> VATAmount { get; set; }
        public Nullable<global::System.Int32> FK_ExciseSlabID { get; set; }
        public Nullable<global::System.Decimal> ExcisePerc { get; set; }
        public Nullable<global::System.Decimal> ExciseAmount { get; set; }
        public Nullable<global::System.Int32> FK_TAX1SlabID { get; set; }
        public Nullable<global::System.Decimal> Tax1Perc { get; set; }
        public Nullable<global::System.Decimal> Tax1Amount { get; set; }
        public Nullable<global::System.Int32> FK_TAX2SlabID { get; set; }
        public Nullable<global::System.Decimal> Tax2Perc { get; set; }
        public Nullable<global::System.Decimal> Tax2Amount { get; set; }
        public Nullable<global::System.Int32> FK_TAX3SlabID { get; set; }
        public Nullable<global::System.Decimal> Tax3Perc { get; set; }
        public Nullable<global::System.Decimal> Tax3Amount { get; set; }
        public Nullable<global::System.Int32> FK_AddnlTaxSlabID { get; set; }
        public Nullable<global::System.Decimal> AddnlTaxPerc { get; set; }
        public Nullable<global::System.Decimal> AddnlTaxAmount { get; set; }
        public Nullable<global::System.Decimal> InclusiveRate { get; set; }        
    }
    
}
