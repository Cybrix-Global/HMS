﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
    public interface ITransactionDTL
    {
        int id { get; set; }
        DateTime? ArrivalDate { get; set; }
        DateTime? DepartureDate { get; set; }
        int? FK_RoomID { get; set; }
        int? Adult { get; set; }
        int? Child { get; set; }        
        int? FK_RefTransTypeID { get; set; }        
        int? FK_RefTransID { get; set; }
        int? FK_GuestID { get; set; }
        string GuestName { get; set; }
    }
    public partial class Booking : ITransactionDTL
    {
        public int? FK_RefTransID { get; set; }
        public int? FK_RefTransTypeID { get; set; }
        public string GuestName { get; set; }
    }
    public partial class GroupBookingDTL : ITransactionDTL
    {
        public DateTime? ArrivalDate { get ; set ; }
        public DateTime? DepartureDate { get; set; }
        public int? FK_RefTransID { get; set; }
        public int? FK_RefTransTypeID { get; set; }
        public int? FK_GuestID { get; set; }
        public string GuestName { get; set; }
    }
    public partial class CheckIn : ITransactionDTL 
    {
        public int? FK_RefTransID { get; set; }
        public int? FK_RefTransTypeID { get; set; }
        public string GuestName { get; set; }
    }
    public partial class GroupCheckInDTL : ITransactionDTL
    {
        public DateTime? ArrivalDate { get; set; }
        public DateTime? DepartureDate { get; set; }
        public int? FK_RefTransID { get; set; }
        public int? FK_RefTransTypeID { get; set; }
        public int? FK_GuestID { get; set; }
        public string GuestName { get; set; }
    }
    public partial class RoomOutofOrder : ITransactionDTL
    {
        public DateTime? ArrivalDate { get; set; }
        public DateTime? DepartureDate { get; set; }
        public int? Adult { get; set; }
        public int? Child { get; set; }
        public int? FK_RefTransID { get; set; }
        public int? FK_RefTransTypeID { get; set; }
        public int? FK_GuestID { get; set; }
        public string GuestName { get; set; }
    }
    public partial class HouseKeeping : ITransactionDTL
    {
        public DateTime? ArrivalDate { get; set; }
        public DateTime? DepartureDate { get; set; }
        public int? Adult { get; set; }
        public int? Child { get; set; }
        public int? FK_RefTransID { get; set; }
        public int? FK_RefTransTypeID { get; set; }
        public int? FK_GuestID { get; set; }
        public string GuestName { get; set; }

    }
    
}
