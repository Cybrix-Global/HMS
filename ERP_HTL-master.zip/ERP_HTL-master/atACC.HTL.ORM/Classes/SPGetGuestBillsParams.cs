﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
    public class SPGetGuestBillsParam
    {
        public int AccountID { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int BookingID { get; set; }
        public int CheckInID { get; set; }
        public int CheckOutID { get; set; }
        public decimal ExRate { get; set; }
        public bool IsGroupTrans { get; set; }
        
    }
}
