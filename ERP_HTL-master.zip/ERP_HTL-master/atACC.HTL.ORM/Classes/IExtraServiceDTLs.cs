﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
    public interface IExtraServiceDTLs
    {
        global::System.Int32 id { get; set; }
        string ServiceCode { get; set; }
        string ServiceName { get; set; }

        Nullable<global::System.Int32> FK_ExtraServiceID { get; set; }
        
        Nullable<global::System.Decimal> Qty { get; set; }
        
        Nullable<global::System.Decimal> Rate { get; set; }
        Nullable<global::System.Decimal> Amount { get; set; }
        Nullable<global::System.Decimal> DeductionPerc { get; set; }
        Nullable<global::System.Decimal> DeductionAmount { get; set; }
        Nullable<global::System.Decimal> TotalTax { get; set; }
        Nullable<global::System.Decimal> NetAmount { get; set; }
        Nullable<global::System.Int32> FK_DiscountSlabID { get; set; }
        Nullable<global::System.Decimal> SlabDiscountPerc { get; set; }
        Nullable<global::System.Decimal> SlabDiscount { get; set; }
        Nullable<global::System.Decimal> TotalDiscount { get; set; }
        Nullable<global::System.Decimal> TaxableAmount { get; set; }
        Nullable<global::System.Int32> FK_GSTSlabID { get; set; }
        Nullable<global::System.Decimal> CGSTPerc { get; set; }
        Nullable<global::System.Decimal> CGSTAmount { get; set; }
        Nullable<global::System.Decimal> SGSTPerc { get; set; }
        Nullable<global::System.Decimal> SGSTAmount { get; set; }
        Nullable<global::System.Decimal> IGSTPerc { get; set; }
        Nullable<global::System.Decimal> IGSTAmount { get; set; }
        Nullable<global::System.Int32> FK_VATSlabID { get; set; }
        Nullable<global::System.Decimal> VATPerc { get; set; }
        Nullable<global::System.Decimal> VATAmount { get; set; }
        Nullable<global::System.Int32> FK_ExciseSlabID { get; set; }
        Nullable<global::System.Decimal> ExcisePerc { get; set; }
        Nullable<global::System.Decimal> ExciseAmount { get; set; }
        Nullable<global::System.Int32> FK_TAX1SlabID { get; set; }
        Nullable<global::System.Decimal> Tax1Perc { get; set; }
        Nullable<global::System.Decimal> Tax1Amount { get; set; }
        Nullable<global::System.Int32> FK_TAX2SlabID { get; set; }
        Nullable<global::System.Decimal> Tax2Perc { get; set; }
        Nullable<global::System.Decimal> Tax2Amount { get; set; }
        Nullable<global::System.Int32> FK_TAX3SlabID { get; set; }
        Nullable<global::System.Decimal> Tax3Perc { get; set; }
        Nullable<global::System.Decimal> Tax3Amount { get; set; }
        Nullable<global::System.Int32> FK_AddnlTaxSlabID { get; set; }
        Nullable<global::System.Decimal> AddnlTaxPerc { get; set; }
        Nullable<global::System.Decimal> AddnlTaxAmount { get; set; }
        Nullable<global::System.Decimal> InclusiveRate { get; set; }        
    }

    public partial class CheckInExtraServiceDTL : IExtraServiceDTLs { }
    public partial class GroupCheckInExtraServiceDTL : IExtraServiceDTLs { }
}
