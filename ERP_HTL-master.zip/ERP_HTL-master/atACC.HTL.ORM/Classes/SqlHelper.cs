﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
namespace atACC.HTL.ORM
{
    public class SqlHelper
    {
        
        public List<SqlParameter> SqlParameters {get;set;}
        public string SPName { get; set; }
        public SqlHelper()
        {
           
            
        }
        public DataSet ExecuteProcedure()
        {
            try
            {
                return ExecuteProcedure(SPName, SqlParameters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet ExecuteProcedure(string _spName)
        {
            try
            {
                return ExecuteProcedure(_spName, SqlParameters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet ExecuteProcedure(List<SqlParameter> _sqlParameters)
        {
            try
            {
                return ExecuteProcedure(SPName, _sqlParameters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string getConnectionString()
        {
            try
            {
                atACCHotelEntities db = atHotelContext.CreateContext();
                System.Data.EntityClient.EntityConnection econ = (System.Data.EntityClient.EntityConnection)db.Connection;
                SqlConnection con1 = (SqlConnection)econ.StoreConnection;
                return con1.ConnectionString;
            }
            catch (Exception)
            {
                return "";
            }
        }
        public int ExecuteNonQuery(string sql)
        {
            using (SqlConnection conn = new SqlConnection(getConnectionString()))
            {
                conn.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text; cmd.CommandTimeout = 0;
                   return cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        public int ExecuteNonQuery(string sql,SqlConnection conn)
        {
                try
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text; cmd.CommandTimeout = 0;
                    return cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
        }
        public int ExecuteNonQuery(string sql, SqlTransaction _trans)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(sql, _trans.Connection);
                cmd.CommandType = CommandType.Text; cmd.CommandTimeout = 0;
                cmd.Transaction = _trans;
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable FillData(string sql)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(getConnectionString()))
            {
                conn.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text; cmd.CommandTimeout = 0;
                    SqlDataAdapter dad = new SqlDataAdapter(cmd);
                    dad.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        public string ExecuteScalar(string sql)
        {
            string sResult = "";
            using (SqlConnection conn = new SqlConnection(getConnectionString()))
            {
                conn.Open();
                try
                {

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text; cmd.CommandTimeout = 0;
                    object objResult = cmd.ExecuteScalar();
                    if (objResult != null)
                    {
                        sResult = objResult.ToString();
                    }
                    return sResult;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        public DataSet ExecuteProcedure(string _spName,List<SqlParameter> _sqlParameters)
        {
            SPName = _spName;
            SqlParameters = _sqlParameters; 
            DataSet ds = new DataSet();
            try
            {
                if (SPName == "") { throw new Exception("Stored Procedure Name Must be Supplied"); }
                atACCHotelEntities db = atHotelContext.CreateContext();

                System.Data.EntityClient.EntityConnection econ = (System.Data.EntityClient.EntityConnection)db.Connection;
                SqlConnection con1 =(SqlConnection) econ.StoreConnection;
                using (SqlConnection conn = new SqlConnection(con1.ConnectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = SPName;
                    if (SqlParameters != null)
                    {
                        foreach (SqlParameter par in SqlParameters)
                        {
                            cmd.Parameters.Add(par);
                        }
                    }
                    SqlDataAdapter dad = new SqlDataAdapter(cmd);
                    dad.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
