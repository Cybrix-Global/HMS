﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
    public partial class CheckInExtraServiceDTL
    {
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
    }
    public partial class GroupCheckInExtraServiceDTL
    {
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
    }
    public partial class CheckOutExtraServiceDTL
    {
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
    }
    public partial class GroupCheckOutExtraServiceDTL
    {
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
    }
    public partial class LaundryDTL
    {
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
    }
    public partial class RoomServiceDTL
    {
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
    }
    public partial class RoomStatusRegister
    {
        public int? FK_TransactionID { get; set; }
        public string GuestName { get; set; }
    }
}
