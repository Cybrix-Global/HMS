﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using atACC.CommonExtensions;
using atACC.Common;
using System.Windows.Forms;
using atACC.CommonMessages;

namespace atACC.HTL.ORM
{
    public static class GlobalMethods
    {
        #region Public Methods
        public static List<EnquiryBookingType> GetEnquiryBookingTypes()
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                return dbh.EnquiryBookingTypes.ToList();
        }
        public static List<Source> GetSources()
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                return dbh.Sources.ToList();
        }
        public static List<GuestType> GetGuestTypes()
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                return dbh.GuestTypes.ToList();
        }
        public static List<Guests> GetGuests()
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
                return dbh.Guests.ToList();
        }
        public static List<RoomStatusRegister> GetRoomStatusByDate(DateTime dateTime)
        {
            SqlHelper sqlHelper = new SqlHelper();
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("StatusDate", dateTime)
            };
            List<DataRow> ds = sqlHelper.ExecuteProcedure("spGetHotelRoomStatusByDate", parameters).Tables[0].AsEnumerable().ToList();
            return ds.Select(x => new RoomStatusRegister
            {
                FK_RoomID = x["RoomID"].ToInt32(),
                FK_StatusID = x["StatusID"].ToInt32(),
                StatusDate = Convert.ToDateTime(x["StatusDate"]),
                FromDate = Convert.ToDateTime(x["FromDate"]),
                ToDate = Convert.ToDateTime(x["ToDate"]),
                Adult = x["Adult"].ToInt32(),
                Child = x["Child"].ToInt32(),
                FK_TransactionTypeID = x["FK_TransactionTypeID"].ToInt32(),
                FK_TransactionID = x["FK_TransactionID"].ToInt32(),
                GuestName = x["GuestName"].ToString2()
            }).ToList();
        }
        public static List<RoomStatusRegister> GetRoomStatusByPeriod(DateTime fromDate, DateTime toDate)
        {
            SqlHelper sqlHelper = new SqlHelper();
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("FromDate", fromDate),
                new SqlParameter("ToDate", toDate)
            };
            List<DataRow> ds = sqlHelper.ExecuteProcedure("spGetHotelRoomStatusByPeriod", parameters).Tables[0].AsEnumerable().ToList();
            return ds.Select(x => new RoomStatusRegister
            {
                FK_RoomID = x["FK_RoomID"].ToInt32(),
                FK_StatusID = x["FK_StatusID"].ToInt32(),
                StatusDate = Convert.ToDateTime(x["StatusDate"]),
                FromDate = Convert.ToDateTime(x["FromDate"]),
                ToDate = Convert.ToDateTime(x["ToDate"]),
                Adult = x["Adult"].ToInt32(),
                Child = x["Child"].ToInt32(),
                FK_TransactionTypeID = x["FK_TransactionTypeID"].ToInt32(),
                FK_TransactionID = x["FK_TransactionID"].ToInt32(),
                GuestName = x["GuestName"].ToString2()
            }).ToList();
        }
        public static List<Rooms> GetAvailableRooms(DateTime fromDate, DateTime toDate, ENMVMTTransactionType transType, int transID, ENMVMTTransactionType? refTransType = null, int? refTransID = null)
        {            
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                List<int> transDTLIDs = new List<int>();
                if (transType == ENMVMTTransactionType.HTL_GroupBooking)
                {
                    transDTLIDs = dbh.GroupBookingDTLs.Where(x => x.FK_GroupBookingID == transID).Select(x => x.id).ToList();
                }
                else if (transType == ENMVMTTransactionType.HTL_GroupCheckIn)
                {
                    transDTLIDs = dbh.GroupCheckInDTLs.Where(x => x.FK_GroupCheckInID == transID).Select(x => x.id).ToList();
                }
                else
                {
                    transDTLIDs = new List<int>(){ transID };
                }

                List<int> entNotAvailableRoomIDs = GetRoomStatusByPeriod(fromDate, toDate)
                                                            .Where(x => x.FK_StatusID != (int)ENRoomStatus.Available
                                                            && !(x.FK_TransactionTypeID == (int)transType && transDTLIDs.Contains(x.FK_TransactionID ?? 0))
                                                            && !(refTransType != null && x.FK_TransactionTypeID == (int)refTransType && x.FK_TransactionID == refTransID)
                                                            )
                                                            .Select(x => x.FK_RoomID.Value)
                                                            .ToList();
            
                return dbh.Rooms.Where(x => !entNotAvailableRoomIDs.Contains(x.id)).ToList();
            }
        }
        public static void SaveRoomStatusRegister(atACCHotelEntities dbh, ENMVMTTransactionType transType, ITransactionDTL transactionDTL, int iRoomStatus = 0)
        {
            bool blnNewRec = false;
            RoomStatusRegister roomStatusRegister = GetRoomStatusRegister(dbh, transType, transactionDTL.id);
            if (roomStatusRegister == null)
            {
                roomStatusRegister = new RoomStatusRegister();
                blnNewRec = true;
            }
            switch (transType)
            {
                case ENMVMTTransactionType.HTL_Booking:
                    roomStatusRegister.StatusDate = transactionDTL.ArrivalDate;
                    roomStatusRegister.FK_StatusID = (int)ENRoomStatus.Booking;
                    roomStatusRegister.FK_BookingID = transactionDTL.id;
                    break;
                case ENMVMTTransactionType.HTL_GroupBooking:
                    roomStatusRegister.StatusDate = transactionDTL.ArrivalDate;
                    roomStatusRegister.FK_StatusID = (int)ENRoomStatus.GBooking;
                    roomStatusRegister.FK_GroupBookingDTLID = transactionDTL.id;
                    break;
                case ENMVMTTransactionType.HTL_CheckIn:
                    roomStatusRegister.StatusDate = transactionDTL.ArrivalDate;
                    roomStatusRegister.FK_StatusID = (int)ENRoomStatus.CheckIn;
                    roomStatusRegister.FK_CheckInID = transactionDTL.id;
                    break;
                case ENMVMTTransactionType.HTL_GroupCheckIn:
                    roomStatusRegister.StatusDate = transactionDTL.ArrivalDate;
                    roomStatusRegister.FK_StatusID = (int)ENRoomStatus.GCheckIn;
                    roomStatusRegister.FK_GroupCheckInDTLID = transactionDTL.id;
                    break;
                case ENMVMTTransactionType.HTL_CheckOut:
                    roomStatusRegister.StatusDate = transactionDTL.DepartureDate;
                    roomStatusRegister.FK_StatusID = (int)ENRoomStatus.Dirty;
                    roomStatusRegister.FK_CheckInID = transactionDTL.id;
                    break;
                case ENMVMTTransactionType.HTL_GroupCheckOut:
                    roomStatusRegister.StatusDate = transactionDTL.DepartureDate;
                    roomStatusRegister.FK_StatusID = (int)ENRoomStatus.Dirty;
                    roomStatusRegister.FK_GroupCheckInDTLID = transactionDTL.id;
                    break;
                case ENMVMTTransactionType.HTL_RoomOutofOrder:
                    roomStatusRegister.StatusDate = transactionDTL.ArrivalDate;
                    roomStatusRegister.FK_StatusID = (int)ENRoomStatus.OutofOrder;
                    roomStatusRegister.FK_RoomOutofOrderID = transactionDTL.id;
                    break;
                case ENMVMTTransactionType.HTL_HouseKeeping:
                    roomStatusRegister.StatusDate = transactionDTL.ArrivalDate;
                    roomStatusRegister.FK_StatusID = iRoomStatus;
                    roomStatusRegister.FK_HouseKeepingID = transactionDTL.id;
                    break;
            }
            roomStatusRegister.FK_GuestID = transactionDTL.FK_GuestID;
            roomStatusRegister.FK_RoomID = transactionDTL.FK_RoomID;
            roomStatusRegister.FK_TransactionTypeID = (int)transType;
            roomStatusRegister.FromDate = transactionDTL.ArrivalDate;
            roomStatusRegister.ToDate = transactionDTL.DepartureDate;
            roomStatusRegister.Adult = transactionDTL.Adult ?? 0;
            roomStatusRegister.Child = transactionDTL.Child ?? 0;
            roomStatusRegister.FK_PreviousStatusID = null;
            if (transactionDTL.FK_RefTransTypeID != null && transactionDTL.FK_RefTransID != null)
            {
                RoomStatusRegister refStatusRegs = GetRoomStatusRegister(dbh, (ENMVMTTransactionType) transactionDTL.FK_RefTransTypeID, (int)transactionDTL.FK_RefTransID);
                if (refStatusRegs != null)
                {
                    roomStatusRegister.FK_PreviousStatusID = refStatusRegs.id;
                }
            }

            if (blnNewRec)
            {
                dbh.RoomStatusRegisters.AddObject(roomStatusRegister);
            }
            else
            {
                dbh.ObjectStateManager.ChangeObjectState(roomStatusRegister, EntityState.Modified);
            }
        }
        public static void DeleteRoomStatusRegister(atACCHotelEntities dbh, ENMVMTTransactionType transType, ITransactionDTL transactionDTL)
        {

            RoomStatusRegister roomStatusRegister = GetRoomStatusRegister(dbh, transType, transactionDTL.id);
            if (roomStatusRegister != null)
            {
                dbh.RoomStatusRegisters.DeleteObject(roomStatusRegister);
            }

        }
        public static void LoadDefaultSettings()
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                DefaultSettings defaultSettings = dbh.DefaultSettings.SingleOrDefault();
                GlobalProperties.CheckInTime = (defaultSettings.Active ?? false) ? defaultSettings.CheckInTime : null;
                GlobalProperties.CheckOutTime = (defaultSettings.Active ?? false) ? defaultSettings.CheckOutTime : null;
                GlobalProperties.FlexibleTime = defaultSettings.FlexibleTime.Value;
            }
        }
        public static void LoadAccountSettings()
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                List<AccountSettings> accountSettings = dbh.AccountSettings.ToList();
                GlobalProperties.RentAccountID = GetAccountSettings(accountSettings, "Rent");
                GlobalProperties.ExtraServicesAccountID = GetAccountSettings(accountSettings, "ExtraServices");
                GlobalProperties.DeductionAccountID = GetAccountSettings(accountSettings, "Deduction");
                GlobalProperties.LaundryAccountID = GetAccountSettings(accountSettings, "Laundry");
                GlobalProperties.GuestAccountID = GetAccountSettings(accountSettings, "Guest");
                GlobalProperties.CashAccountID = GetAccountSettings(accountSettings, "Cash");
                GlobalProperties.CreditCardAccountID = GetAccountSettings(accountSettings, "CreditCard");
                GlobalProperties.ChequeAccountID = GetAccountSettings(accountSettings, "Cheque");
                GlobalProperties.DDAccountID = GetAccountSettings(accountSettings, "DD");
                GlobalProperties.OnlineBankingAccountID = GetAccountSettings(accountSettings, "OnlineBanking");
                GlobalProperties.EWalletAccountID = GetAccountSettings(accountSettings, "EWallet");
                GlobalProperties.DiscountAccountID = GetAccountSettings(accountSettings, "Discount");
                GlobalProperties.ExciseDutyAccountID = GetAccountSettings(accountSettings, "ExciseDuty");
                GlobalProperties.Tax1AccountID = GetAccountSettings(accountSettings, "Tax1");
                GlobalProperties.Tax2AccountID = GetAccountSettings(accountSettings, "Tax2");
                GlobalProperties.Tax3AccountID = GetAccountSettings(accountSettings, "Tax3");
                GlobalProperties.AdditionalTaxAccountID = GetAccountSettings(accountSettings, "AdditionalTax");
                GlobalProperties.VATAccountID = GetAccountSettings(accountSettings, "VAT");
                GlobalProperties.SGSTAccountID = GetAccountSettings(accountSettings, "SGST");
                GlobalProperties.CGSTAccountID = GetAccountSettings(accountSettings, "CGST");
                GlobalProperties.IGSTAccountID = GetAccountSettings(accountSettings, "IGST");
                GlobalProperties.RoundOffAccountID = 302424;
            }
        }
        public static void LoadUserSettings()
        {
            GlobalProperties.PrintPreview = GetUserSetting(ENDefaultUserSettings.PrintPreview);
            GlobalProperties.ShowPrintDialogue = GetUserSetting(ENDefaultUserSettings.ShowPrintDialogue);
            GlobalProperties.PrintWhileSavingInEnquiry = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInEnquiry);
            GlobalProperties.PrintWhileSavingInBooking = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInBooking);
            GlobalProperties.PrintWhileSavingInGroupBooking = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInGroupBooking);
            GlobalProperties.PrintWhileSavingInCheckIn = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInCheckIn);
            GlobalProperties.PrintWhileSavingInGroupCheckIn = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInGroupCheckIn);
            GlobalProperties.PrintWhileSavingInCheckOut = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInCheckOut);
            GlobalProperties.PrintWhileSavingInGroupCheckOut = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInGroupCheckOut);
            GlobalProperties.PrintWhileSavingInHouseKeeping = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInHouseKeeping);
            GlobalProperties.PrintWhileSavingInLaundry = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInLaundry);
            GlobalProperties.PrintWhileSavingInRoomService = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInRoomService);
            GlobalProperties.PrintWhileSavingInComplaintRegister = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInComplaintRegister);
            GlobalProperties.PrintWhileSavingInRoomShift = GetUserSetting(ENDefaultUserSettings.PrintWhileSavingInRoomShift);

            GlobalProperties.SendEmailWhileSavingInBooking = GetUserSetting(ENDefaultUserSettings.SendEmailWhileSavingInBooking);
            GlobalProperties.SendEmailWhileSavingInGroupBooking = GetUserSetting(ENDefaultUserSettings.SendEmailWhileSavingInGroupBooking);
            GlobalProperties.SendEmailWhileSavingInCheckIn = GetUserSetting(ENDefaultUserSettings.SendEmailWhileSavingInCheckIn);
            GlobalProperties.SendEmailWhileSavingInGroupCheckIn = GetUserSetting(ENDefaultUserSettings.SendEmailWhileSavingInGroupCheckIn);
            GlobalProperties.SendEmailWhileSavingInCheckOut = GetUserSetting(ENDefaultUserSettings.SendEmailWhileSavingInCheckOut);
            GlobalProperties.SendEmailWhileSavingInGroupCheckOut = GetUserSetting(ENDefaultUserSettings.SendEmailWhileSavingInGroupCheckOut);

            GlobalProperties.SendSMSWhileSavingInBooking = GetUserSetting(ENDefaultUserSettings.SendSMSWhileSavingInBooking);
            GlobalProperties.SendSMSWhileSavingInGroupBooking = GetUserSetting(ENDefaultUserSettings.SendSMSWhileSavingInGroupBooking);
            GlobalProperties.SendSMSWhileSavingInCheckIn = GetUserSetting(ENDefaultUserSettings.SendSMSWhileSavingInCheckIn);
            GlobalProperties.SendSMSWhileSavingInGroupCheckIn = GetUserSetting(ENDefaultUserSettings.SendSMSWhileSavingInGroupCheckIn);
            GlobalProperties.SendSMSWhileSavingInCheckOut = GetUserSetting(ENDefaultUserSettings.SendSMSWhileSavingInCheckOut);
            GlobalProperties.SendSMSWhileSavingInGroupCheckOut = GetUserSetting(ENDefaultUserSettings.SendSMSWhileSavingInGroupCheckOut);
        }
        public static bool GetUserSetting(ENDefaultUserSettings setting)
        {
            using (atACCHotelEntities dbh = atHotelContext.CreateContext())
            {
                var userset = (from us in dbh.DefaultUserSettings
                               join usm in dbh.DefaultUserSettingMappings on us.id equals usm.FK_DefaultUserSettingsID
                               where usm.FK_LoginUserID == GlobalFunctions.LoginUserID && us.id == (int)setting
                               select usm).SingleOrDefault();
                return Convert.ToBoolean(userset != null ? userset.Value.ToInt32() : 0);
            }
        }
        public static int GetAccountSettings(List<AccountSettings> accountSettings, string sSettingsName)
        {
            return accountSettings.Where(x => x.AccountFor == sSettingsName).SingleOrDefault().Value.ToInt32();
        }
        #region Account Posting
        public static VoucherHDR PostVoucher(bool newRecord, VoucherHDR entVoucherHdr, List<VoucherDTL> entVoucherDTLs, ref atACCHotelEntities db, List<AnalysisDTL> entAnalysisDTLs)
        {
            try
            {
                ValidateVoucher(entVoucherHdr, entVoucherDTLs);
                return PostToDb(newRecord, entVoucherHdr, entVoucherDTLs, ref db, entAnalysisDTLs);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void DecorateVoucherHdr(VoucherHDR entVoucherHdr, int _ContextID, string _VoucherNo, DateTime dtVoucherDate, int _TransactionCurrencyID, decimal _dcVoucherTotal, string _referenceNumber, string _TransactionType, int? iLocationID = null)
        {
            try
            {
                string sVoucherNo = "";
                entVoucherHdr.LoginUserID = GlobalFunctions.LoginUserID;
                if (iLocationID != null)
                {
                    entVoucherHdr.LocationID = iLocationID;
                }
                else
                {
                    entVoucherHdr.LocationID = GlobalFunctions.LoginLocationID;
                }

                entVoucherHdr.ContextID = _ContextID;
                if (_VoucherNo == "")
                {
                    sVoucherNo = "GL-" + _TransactionType + "-" + _referenceNumber;
                }
                else
                {
                    sVoucherNo = _VoucherNo;
                }
                entVoucherHdr.VoucherNo = sVoucherNo;
                entVoucherHdr.VoucherDate = dtVoucherDate;
                entVoucherHdr.FK_FiscalPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                entVoucherHdr.FK_TransactionCurrencyID = _TransactionCurrencyID;
                entVoucherHdr.ReferenceNumber = _referenceNumber;
                entVoucherHdr.VoucherTotal = _dcVoucherTotal;
                entVoucherHdr.TransactionType = _TransactionType;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void DecorateVoucherDtl(VoucherDTL Vdtl, int _FK_VoucherHdrID, int _AccountID, string _Narration, decimal _exRate, decimal _HomeCurrencyAmount, decimal _TransactionCurrencyAmount, string sComments, string sRemarks)
        {
            try
            {
                Vdtl.FK_VoucherHDRID = _FK_VoucherHdrID;
                Vdtl.FK_AccountID = _AccountID;
                Vdtl.Narration = _Narration;
                Vdtl.ExRate = _exRate;
                Vdtl.HomeCurrencyAmount = _HomeCurrencyAmount;
                Vdtl.TransactionCurrencyAmount = _TransactionCurrencyAmount;
                Vdtl.Comments = sComments;
                Vdtl.Remarks = sRemarks;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void AddVoucherDtl(List<VoucherDTL> entVoucherDtls, int _FK_VoucherHdrID, int _AccountID, string _Narration, decimal _exRate, decimal _Amount, string sComments, string sRemarks)
        {
            decimal _HomeCurrencyAmount = _Amount * _exRate;
            decimal _TransactionCurrencyAmount = _Amount;
            try
            {
                VoucherDTL Vdtl = new VoucherDTL();

                Vdtl.FK_VoucherHDRID = _FK_VoucherHdrID;
                Vdtl.FK_AccountID = _AccountID;
                Vdtl.Narration = _Narration;
                Vdtl.ExRate = (_exRate == 0 ? 1 : _exRate);
                Vdtl.HomeCurrencyAmount = _HomeCurrencyAmount;
                Vdtl.TransactionCurrencyAmount = _TransactionCurrencyAmount;
                Vdtl.Comments = sComments;
                Vdtl.Remarks = sRemarks;
                entVoucherDtls.Add(Vdtl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
        public static int GetNoOfDays(DateTime dtFromDate, DateTime dtToDate)
        {
            dtFromDate = dtFromDate.AddSeconds(-dtFromDate.Second);
            dtToDate = dtToDate.AddSeconds(-dtToDate.Second).AddMinutes(-GlobalProperties.FlexibleTime);            
            TimeSpan span = dtToDate.Subtract(dtFromDate.AddMinutes(-1));
            return (int)Math.Ceiling(span.TotalDays);
        }
        public static DataTable GetGuestBills(SPGetGuestBillsParam param)
        {
            SqlHelper sqlHelper = new SqlHelper
            {
                SPName = "SPGetGuestBills",
                SqlParameters = new List<SqlParameter>()
                    {
                        new SqlParameter("AccountID", param.AccountID),
                        new SqlParameter("FromDate", param.FromDate),
                        new SqlParameter("ToDate", param.ToDate),
                        new SqlParameter("BookingID", param.BookingID),
                        new SqlParameter("CheckInID", param.CheckInID),
                        new SqlParameter("CheckOutID", param.CheckOutID),
                        new SqlParameter("BranchID", GlobalFunctions.LoginLocationID),
                        new SqlParameter("ExRate", param.ExRate),
                        new SqlParameter("IsGroupTrans", param.IsGroupTrans)
                    }
            };
            return sqlHelper.ExecuteProcedure().Tables[0];
        }
        public static DateTime GetDefaultArrivalTime()
        {
            DateTime? dateTime = null;
            if (GlobalProperties.CheckInTime != null)
            {
                DateTime dt = GlobalProperties.CheckInTime.Value;               
                dateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, dt.Hour, dt.Minute, dt.Second);                
            }

            if (dateTime == null || dateTime > DateTime.Now)  // if Default arrival Time is > current time then set current time as arrival time
            {
                dateTime = DateTime.Now.AddMilliseconds(-DateTime.Now.Millisecond);                
            }
            return dateTime.Value;
        }
        public static DateTime GetDefaultDepartureTime(DateTime arrivalTime)
        {
            DateTime? dateTime = null;
            if (GlobalProperties.CheckOutTime != null)
            {
                DateTime dt = GlobalProperties.CheckOutTime.Value;
                dateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, dt.Hour, dt.Minute, dt.Second);
            }

            if (dateTime == null)  // if Default arrival Time is > current time then set current time as arrival time
            {
                dateTime = arrivalTime.AddDays(1);
            }
            return dateTime.Value;
        }
        #endregion

        #region Private Methods
        private static void ValidateVoucher(VoucherHDR entVoucherHdr, List<VoucherDTL> entVoucherDtl)
        {
            try
            {

                if (entVoucherHdr.VoucherNo.Trim() == "") { throw new Exception("Invalid Voucher No in VoucherHdr"); }
                if (entVoucherHdr.TransactionType.Trim() == "") { throw new Exception("Invalid Transaction Type in VoucherHdr"); }

                if (entVoucherDtl != null)
                {
                    foreach (VoucherDTL vdtl in entVoucherDtl)
                    {
                        if (vdtl.FK_AccountID != 0 && entVoucherHdr.id != 0)
                        {
                            if (vdtl.FK_AccountID != 0 && entVoucherHdr.id != 0)
                            {
                                CheckBudget(vdtl.FK_AccountID.toInt32(), vdtl.HomeCurrencyAmount.ToDecimal(), entVoucherHdr.id);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static void CheckBudget(int iAccountID, decimal dcmAmount, int VoucherHdrID)
        {
            try
            {
                using (atACCHotelEntities db1 = atHotelContext.CreateContext())
                {
                    decimal dcmCurrentBalance = db1.VoucherDTLs
                        .Where(x => x.FK_AccountID == iAccountID && x.FK_VoucherHDRID != VoucherHdrID)
                        .Sum(x => x.HomeCurrencyAmount)
                        .ToDecimal();
                    string sLedgerName = db1.AccountLedgers.Where(x => x.id == iAccountID).SingleOrDefault().LedgerName; ;
                    decimal dcmNetBalance = dcmCurrentBalance + dcmAmount;
                    string sFormat = "N" + GlobalFunctions.CompanyNoofDecimals;
                    decimal dcmBudgetedAmount = db1.BudgetDTLs.Where(x => x.FK_AccountID == iAccountID
                        ).Sum(x => x.AllocatedAmount).ToDecimal();
                    if (dcmBudgetedAmount == 0) { return; }
                    if (dcmNetBalance > dcmBudgetedAmount)
                    {

                        if (GlobalFunctions.strBudgetExceeded == "0")
                        {
                            return;
                        }
                        else if (GlobalFunctions.strBudgetExceeded == "1")
                        {
                            if (MessageBox.Show("Budget Exceeded for Account " + sLedgerName + " Budgeted Amount: " + GlobalFunctions.getFormattedValue(sFormat, dcmBudgetedAmount) + " Posting Amount: " + GlobalFunctions.getFormattedValue(sFormat, dcmNetBalance) + " Do You Want to Continue ?", MessageKeys.MsgApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                            {
                                throw new Exception("");
                            }
                        }
                        else
                        {
                            throw new Exception("Budget Exceeded for Account " + sLedgerName + " Budgeted Amount: " + GlobalFunctions.getFormattedValue(sFormat, dcmBudgetedAmount) + " Posting Amount: " + GlobalFunctions.getFormattedValue(sFormat, dcmNetBalance));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private static VoucherHDR PostToDb(bool newRecord, VoucherHDR entVoucherHdr, List<VoucherDTL> entVoucherDTLs, ref atACCHotelEntities db, List<AnalysisDTL> entAnalysisDTLs)
        {
            try
            {
                #region Adding or Updating VoucherHdr
                if (newRecord)
                {
                    entVoucherHdr.FK_SessionID = GlobalFunctions.LoginSessionID;
                    db.VoucherHDRs.AddObject(entVoucherHdr);
                }
                #endregion
                #region Delete Existing Voucher Dtls
                if (!newRecord)
                {
                    List<VoucherDTL> entOldVoucherDtl;
                    entOldVoucherDtl = db.VoucherDTLs.Where(x => x.FK_VoucherHDRID == entVoucherHdr.id).ToList();
                    foreach (VoucherDTL dtlold in entOldVoucherDtl)
                    {
                        db.VoucherDTLs.DeleteObject(dtlold);
                        List<VoucherAnalysisDTL> vaDtls = db.VoucherAnalysisDTLs.Where(x => x.FK_VoucherDTLID == dtlold.id).ToList();
                        if (vaDtls != null)
                        {
                            foreach (var dtls in vaDtls)
                            {
                                db.VoucherAnalysisDTLs.DeleteObject(dtls);
                            }
                        }
                    }
                }
                #endregion
                #region Adding of VoucherDtls

                foreach (VoucherDTL dtl in entVoucherDTLs)
                {
                    dtl.id = GlobalProperties.iAnalysisPostCounter;
                    dtl.FK_SessionID = GlobalFunctions.LoginSessionID;
                    dtl.FK_VoucherHDRID = entVoucherHdr.id;
                    dtl.ContextID = entVoucherHdr.ContextID;
                    db.VoucherDTLs.AddObject(dtl);
                    if (entAnalysisDTLs != null)
                    {

                        foreach (var aDtls in entAnalysisDTLs)
                        {
                            VoucherAnalysisDTL vaDTLs = new VoucherAnalysisDTL();
                            vaDTLs.LoginUserID = GlobalFunctions.LoginUserID;
                            vaDTLs.LocationID = GlobalFunctions.LoginLocationID;
                            vaDTLs.FK_FiscalPeriodID = GlobalFunctions.CurrentFiscalPeriodID;
                            vaDTLs.FK_VoucherDTLID = dtl.id;
                            vaDTLs.VoucherDate = entVoucherHdr.VoucherDate;
                            vaDTLs.FK_AnalysisTypeID = aDtls.AnalysisType;
                            vaDTLs.FK_AnalysisID = aDtls.AnalysisValue;
                            vaDTLs.Percentage = aDtls.Percentage;
                            vaDTLs.FK_AccountID = dtl.FK_AccountID;
                            vaDTLs.Narration = dtl.Narration;
                            vaDTLs.ExRate = dtl.ExRate;
                            vaDTLs.HomeCurrencyAmount = dtl.HomeCurrencyAmount * (aDtls.Percentage / 100);
                            vaDTLs.TransactionCurrencyAmount = dtl.TransactionCurrencyAmount * (aDtls.Percentage / 100);
                            vaDTLs.FK_SessionID = dtl.FK_SessionID;
                            vaDTLs.Comments = dtl.Comments;
                            vaDTLs.Remarks = dtl.Remarks;
                            db.VoucherAnalysisDTLs.AddObject(vaDTLs);

                        }

                    }
                    GlobalProperties.iAnalysisPostCounter--;
                }
                return entVoucherHdr;
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public static void DeleteVoucher(int? _VoucherID, ref atACCHotelEntities db)
        {
            if (_VoucherID == null) { return; }
            VoucherHDR entVoucherHdr = db.VoucherHDRs.Where(x => x.id == _VoucherID).SingleOrDefault();
            List<VoucherDTL> entVoucherDtls = db.VoucherDTLs.Where(x => x.FK_VoucherHDRID == _VoucherID).ToList();
            foreach (VoucherDTL vdtl in entVoucherDtls)
            {
                List<VoucherAnalysisDTL> vaDtls = db.VoucherAnalysisDTLs.Where(x => x.FK_VoucherDTLID == vdtl.id).ToList();

                if (vaDtls != null)
                {
                    foreach (var dtls in vaDtls)
                    {
                        db.VoucherAnalysisDTLs.DeleteObject(dtls);
                    }
                }
                db.DeleteObject(vdtl);
            }
            if (entVoucherHdr != null)
            {
                db.DeleteObject(entVoucherHdr);
            }

        }
        public static RoomStatusRegister GetRoomStatusRegister(atACCHotelEntities dbh, ENMVMTTransactionType transType, int transID)
        {
            return dbh.RoomStatusRegisters
                                        .Where(x =>
                                            x.FK_TransactionTypeID == (int)transType &&
                                            (
                                                (x.FK_BookingID != null && x.FK_BookingID == transID) ||
                                                (x.FK_GroupBookingDTLID != null && x.FK_GroupBookingDTLID == transID) ||
                                                (x.FK_CheckInID != null && x.FK_CheckInID == transID) ||
                                                (x.FK_GroupCheckInDTLID != null && x.FK_GroupCheckInDTLID == transID) ||
                                                (x.FK_RoomOutofOrderID != null && x.FK_RoomOutofOrderID == transID) ||
                                                (x.FK_HouseKeepingID != null && x.FK_HouseKeepingID == transID)
                                            ))
                                        .SingleOrDefault();
        }
        #endregion
    }
}
