﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACC.Common;

namespace atACC.HTL.ORM
{
    public class atHotelContext
    {
        public static atACCHotelEntities CreateContext()
        {
            try
            {
                if (GlobalFunctions.hotelEntityConnectionString == "" || GlobalFunctions.hotelEntityConnectionString == null) { throw new Exception("Connection Not Initialized!"); }
                return new atACCHotelEntities(GlobalFunctions.hotelEntityConnectionString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
