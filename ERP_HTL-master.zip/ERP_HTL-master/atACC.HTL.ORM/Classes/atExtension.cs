﻿using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
    public static class atExtension
    {
		public static void DetachAllHotelEntities(this atACCHotelEntities db)
		{

			foreach (ObjectStateEntry Entry in db.ObjectStateManager.GetObjectStateEntries(System.Data.EntityState.Added))
			{
				if (Entry.Entity != null)
				{
					db.Detach(Entry.Entity);
				}
			}
			foreach (ObjectStateEntry Entry in db.ObjectStateManager.GetObjectStateEntries(System.Data.EntityState.Modified))
			{
				if (Entry.Entity != null)
				{
					db.Detach(Entry.Entity);
				}
			}
		}
		public static void DetachAllEntities(this atACCHotelEntities db)
		{

			db.DetachAllHotelEntities();
		}
	}
}
