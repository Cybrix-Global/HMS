﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.ORM
{
	public interface ITransactionSlabDTL
	{
		System.Int32 id { get; set; }

		Nullable<global::System.Decimal> SlabDiscountPerc { get; set; }
		Nullable<global::System.Decimal> SlabDiscount { get; set; }			
		Nullable<global::System.Decimal> TaxableAmount { get; set; }
		Nullable<global::System.Decimal> CGSTPerc { get; set; }
		Nullable<global::System.Decimal> CGSTAmount { get; set; }
		Nullable<global::System.Decimal> SGSTPerc { get; set; }
		Nullable<global::System.Decimal> SGSTAmount { get; set; }
		Nullable<global::System.Decimal> IGSTPerc { get; set; }
		Nullable<global::System.Decimal> IGSTAmount { get; set; }
		Nullable<global::System.Decimal> VATPerc { get; set; }
		Nullable<global::System.Decimal> VATAmount { get; set; }
		Nullable<global::System.Decimal> ExcisePerc { get; set; }
		Nullable<global::System.Decimal> ExciseAmount { get; set; }
		Nullable<global::System.Decimal> Tax1Perc { get; set; }
		Nullable<global::System.Decimal> Tax1Amount { get; set; }
		Nullable<global::System.Decimal> Tax2Perc { get; set; }
		Nullable<global::System.Decimal> Tax2Amount { get; set; }
		Nullable<global::System.Decimal> Tax3Perc { get; set; }
		Nullable<global::System.Decimal> Tax3Amount { get; set; }
		Nullable<global::System.Decimal> AddnlTaxPerc { get; set; }
		Nullable<global::System.Decimal> AddnlTaxAmount { get; set; }
		Nullable<global::System.Decimal> InclusiveRate { get; set; }
		Nullable<global::System.Decimal> NetAmount { get; set; }
		Nullable<global::System.Decimal> Amount { get; set; }			
		Nullable<global::System.Int32> FK_TAX1SlabID { get; set; }
		Nullable<global::System.Int32> FK_TAX2SlabID { get; set; }
		Nullable<global::System.Int32> FK_TAX3SlabID { get; set; }
		Nullable<global::System.Int32> FK_AddnlTaxSlabID { get; set; }
		Nullable<global::System.Int32> FK_VATSlabID { get; set; }
		Nullable<global::System.Int32> FK_DiscountSlabID { get; set; }
		Nullable<global::System.Int32> FK_ExciseSlabID { get; set; }
		Nullable<global::System.Int32> FK_GSTSlabID { get; set; }
		Nullable<global::System.Decimal> DeductionAmount { get; set; }
		Nullable<global::System.Decimal> DeductionPerc { get; set; }
		Nullable<global::System.Decimal> TotalTax { get; set; }
		Nullable<global::System.Decimal> TotalDiscount { get; set; }
	}
	public partial class Booking : ITransactionSlabDTL 
	{
	};
	public partial class GroupBookingDTL : ITransactionSlabDTL
	{
	};
	public partial class CheckIn : ITransactionSlabDTL
	{

	};
	public partial class GroupCheckInDTL : ITransactionSlabDTL
	{
	};
	public partial class CheckInExtraServiceDTL : ITransactionSlabDTL
	{	
	};
	public partial class CheckOutExtraServiceDTL : ITransactionSlabDTL
	{	
	};
	public partial class GroupCheckInExtraServiceDTL : ITransactionSlabDTL
	{
	};
	public partial class GroupCheckOutExtraServiceDTL : ITransactionSlabDTL
	{
	};
	public partial class LaundryDTL : ITransactionSlabDTL
	{
	};
	public partial class RoomServiceDTL : ITransactionSlabDTL
	{
	};
	public partial class ExtraServiceDTLs : ITransactionSlabDTL
	{
	};
}
