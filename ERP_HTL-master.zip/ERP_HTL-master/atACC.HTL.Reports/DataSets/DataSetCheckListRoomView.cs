﻿namespace atACC.HTL.Reports.DataSets
{


    public partial class DataSetCheckListRoomView
    {
        partial class SPCheckListRoomViewDataTable
        {
        }
    }
}
