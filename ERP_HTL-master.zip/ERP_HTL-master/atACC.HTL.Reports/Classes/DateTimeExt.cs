﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.Reports
{
	public static class DateTimeExt
	{
		public static string atFormat(this DateTime obj)
		{
			try
			{
				return Convert.ToString(obj.ToString("yyyyMMdd"));
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		/// <summary>
		/// Return DateTime with current date part and 00:00:00 time part
		/// </summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public static DateTime ToBegin(this DateTime obj)
		{
			try
			{
				return new DateTime(obj.Year, obj.Month, obj.Day, 0, 0, 0, 0);

			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		/// <summary>
		/// Return DateTime with current date part and 23:59:59 time part
		/// </summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public static DateTime ToEnd(this DateTime obj)
		{
			try
			{
				return new DateTime(obj.Year, obj.Month, obj.Day, 23, 59, 59, 997);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
