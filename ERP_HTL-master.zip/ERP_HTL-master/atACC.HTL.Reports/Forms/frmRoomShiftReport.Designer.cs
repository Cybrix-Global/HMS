﻿namespace atACC.HTL.Reports
{
    partial class frmRoomShiftReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRoomShiftReport));
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.rbtShiftDate = new atACCFramework.UserControls.atRadioButton();
            this.rbtVoucherDate = new atACCFramework.UserControls.atRadioButton();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.ucReportCriteria = new atACCFramework.UserControls.ucReportCriteria();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.txtToRoom = new atACCFramework.UserControls.TextBoxExt();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.lblFromRoom = new System.Windows.Forms.Label();
            this.lblGuest = new System.Windows.Forms.Label();
            this.txtFromRoom = new atACCFramework.UserControls.TextBoxExt();
            this.lblToRoom = new atACCFramework.UserControls.atLabel();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.rbtShiftDate);
            this.pnlSearchBylist.Controls.Add(this.rbtVoucherDate);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // rbtShiftDate
            // 
            resources.ApplyResources(this.rbtShiftDate, "rbtShiftDate");
            this.rbtShiftDate.Name = "rbtShiftDate";
            this.rbtShiftDate.UseVisualStyleBackColor = true;
            // 
            // rbtVoucherDate
            // 
            resources.ApplyResources(this.rbtVoucherDate, "rbtVoucherDate");
            this.rbtVoucherDate.Checked = true;
            this.rbtVoucherDate.Name = "rbtVoucherDate";
            this.rbtVoucherDate.TabStop = true;
            this.rbtVoucherDate.UseVisualStyleBackColor = true;
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.ucReportCriteria);
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Name = "pnlMain";
            // 
            // ucReportCriteria
            // 
            this.ucReportCriteria.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.ucReportCriteria, "ucReportCriteria");
            this.ucReportCriteria.FromDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 428);
            this.ucReportCriteria.Name = "ucReportCriteria";
            this.ucReportCriteria.ToDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 430);
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.txtToRoom);
            this.grpCommon.Controls.Add(this.txtGuest);
            this.grpCommon.Controls.Add(this.lblFromRoom);
            this.grpCommon.Controls.Add(this.lblGuest);
            this.grpCommon.Controls.Add(this.txtFromRoom);
            this.grpCommon.Controls.Add(this.lblToRoom);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // txtToRoom
            // 
            resources.ApplyResources(this.txtToRoom, "txtToRoom");
            this.txtToRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtToRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtToRoom.Format = null;
            this.txtToRoom.isAllowNegative = false;
            this.txtToRoom.isAllowSpecialChar = false;
            this.txtToRoom.isNumbersOnly = false;
            this.txtToRoom.isNumeric = false;
            this.txtToRoom.isTouchable = false;
            this.txtToRoom.Name = "txtToRoom";
            this.txtToRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtGuest
            // 
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGuest.Format = null;
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGuest_KeyPress);
            // 
            // lblFromRoom
            // 
            resources.ApplyResources(this.lblFromRoom, "lblFromRoom");
            this.lblFromRoom.Name = "lblFromRoom";
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            // 
            // txtFromRoom
            // 
            resources.ApplyResources(this.txtFromRoom, "txtFromRoom");
            this.txtFromRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtFromRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFromRoom.Format = null;
            this.txtFromRoom.isAllowNegative = false;
            this.txtFromRoom.isAllowSpecialChar = false;
            this.txtFromRoom.isNumbersOnly = false;
            this.txtFromRoom.isNumeric = false;
            this.txtFromRoom.isTouchable = false;
            this.txtFromRoom.Name = "txtFromRoom";
            this.txtFromRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblToRoom
            // 
            resources.ApplyResources(this.lblToRoom, "lblToRoom");
            this.lblToRoom.Name = "lblToRoom";
            this.lblToRoom.RequiredField = false;
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmRoomShiftReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlSearchBylist);
            this.Name = "frmRoomShiftReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmRoomShiftReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmRoomShiftReport_atDesignClick);
            this.Load += new System.EventHandler(this.frmRoomShiftReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atGroupBox grpCommon;
        private System.Windows.Forms.Label lblFromRoom;
        private System.Windows.Forms.Label lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtFromRoom;
        private atACCFramework.UserControls.atLabel lblToRoom;
        private atACCFramework.UserControls.ucReportCriteria ucrDatePicker;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private atACCFramework.UserControls.TextBoxExt txtToRoom;
        private atACCFramework.UserControls.atRadioButton rbtShiftDate;
        private atACCFramework.UserControls.atRadioButton rbtVoucherDate;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.ucReportCriteria ucReportCriteria;
    }
}