﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;
using atACC.HTL.UI;


namespace atACC.HTL.Reports
{
    public partial class frmAvailabilityReport : atReportFormBase
    {
        #region Constructor
        public frmAvailabilityReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion

        #region Private Variables
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.Where(x => x.IsHall == false).ToList();
                txtRoomOrHall.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateHall()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.Where(x => x.IsHall == true).ToList();
                txtRoomOrHall.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRoomType()
        {
             try
             {
                 var RoomType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.IsHallType == false).ToList();
                 cmbType.DataSource = RoomType.ToList();
                 cmbType.DisplayMember = "Name";
                 cmbType.ValueMember = "id";
                 cmbType.SelectedIndex = -1;
             }
             catch (Exception ex)
             {
                 ExceptionManager.Publish(ex);
                 atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
             }
        }
        private void PopulateHallType()
        {
            try
            {                
                var HallType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.IsHallType == true).ToList();
                cmbType.DataSource = HallType.ToList();
                cmbType.DisplayMember = "Name";
                cmbType.ValueMember = "id";
                cmbType.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Floor
                var Floor = dbh.Floors.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbFloor.DataSource = Floor.ToList();
                cmbFloor.DisplayMember = "Name";
                cmbFloor.ValueMember = "id";
                cmbFloor.SelectedIndex = -1;
                #endregion
                #region Block
                var Block = dbh.Blocks.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbBlock.DataSource = Block.ToList();
                cmbBlock.DisplayMember = "Name";
                cmbBlock.ValueMember = "id";
                cmbBlock.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ClearFields()
        {
            try
            {
                txtRoomOrHall.Clear();
                cmbType.SelectedIndex = -1;
                cmbBlock.SelectedIndex = -1;
                cmbFloor.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void EnableOrDisableTextBox()
        {
            try
            {
                if (rbtAll.Checked == true)
                {
                    txtRoomOrHall.Enabled = false;
                    cmbType.Enabled = false;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = false;
                }
                if (rbtRoomOrHallWise.Checked == true)
                {
                    txtRoomOrHall.Enabled = true;
                    cmbType.Enabled = false;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = false;
                }
                if (rbtType.Checked == true)
                {
                    txtRoomOrHall.Enabled = false;
                    cmbType.Enabled = true;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = false;
                }
                if (radFloor.Checked == true)
                {
                    txtRoomOrHall.Enabled = false;
                    cmbType.Enabled = false;
                    cmbFloor.Enabled = true;
                    cmbBlock.Enabled = false;
                }
                if (radBlock.Checked == true)
                {
                    txtRoomOrHall.Enabled = false;
                    cmbType.Enabled = false;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();                
                tooltip.SetToolTip(txtRoomOrHall, "Enter Room Or Hall");
                tooltip.SetToolTip(cmbType, "Select Type");
                tooltip.SetToolTip(cmbFloor, "Select Floor");
                tooltip.SetToolTip(cmbBlock, "Select Block");
                tooltip.SetToolTip(rbtAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);                
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmAvailabilityReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateRoom();
                PopulateRoomType();
                PopulateCombos();
                ShowToolTip();
                dtpAsOnDate.Value = DateTime.Now.ToEnd();
                EnableOrDisableTextBox();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtRoom_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbtRoom.Checked)
                {
                    PopulateRoom();
                    PopulateRoomType();
                }
                else
                {
                    PopulateHall();
                    PopulateHallType();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errProvider.Clear();
                ClearFields();
                EnableOrDisableTextBox();                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtRoomOrHallWise_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errProvider.Clear();
                EnableOrDisableTextBox();
                ClearFields();                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtType_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errProvider.Clear();
                EnableOrDisableTextBox();
                ClearFields();                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void radFloor_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errProvider.Clear();
                EnableOrDisableTextBox();
                ClearFields();                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void radBlock_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errProvider.Clear();
                EnableOrDisableTextBox();
                ClearFields();                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtRoomOrHall_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Rooms> Sd = dbh.Rooms.ToList();
                List<Rooms> SDp = Sd.Where(x => x.Name == txtRoomOrHall.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtRoomOrHall.Tag = SDp.Select(x => x.id).Single();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private bool frmAvailabilityReport_atValidate(object source)
        {
            try
            {
                if (rbtRoomOrHallWise.Checked == true && txtRoomOrHall.Text == "")
                {
                    errProvider.SetError(txtRoomOrHall, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                if (rbtType.Checked == true && cmbType.Text.Trim() == "")
                {
                    errProvider.SetError(cmbType, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                if (radBlock.Checked == true && cmbBlock.Text == "")
                {
                    errProvider.SetError(cmbBlock, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                if (radFloor.Checked == true && cmbFloor.Text == "")
                {
                    errProvider.SetError(cmbFloor, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmAvailabilityReport_atPreviewClick(object source, UI.PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptAvailabilityReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Availability" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Availability";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                sqlParameters.Add(new SqlParameter("RoomID", txtRoomOrHall.Text != "" ? txtRoomOrHall.Tag : 0));
                sqlParameters.Add(new SqlParameter("RoomTypeID", cmbType.Text.Trim() != "" ? cmbType.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("BlockID", cmbBlock.Text.Trim() != "" ? cmbBlock.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("FloorID", cmbFloor.Text.Trim() != "" ? cmbFloor.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("IsHall", rbtHall.Checked ? 1 : 0));
                sqlParameters.Add(new SqlParameter("Asondate",dtpAsOnDate.Value));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPAvailabilityReport", sqlParameters);
                ds.Tables[0].TableName = "dsAvailabilityReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmAvailabilityReport_atDesignClick(object source, UI.DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptAvailabilityReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion

    }
}
