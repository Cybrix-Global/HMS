﻿namespace atACC.HTL.Reports
{
    partial class frmExtrasUsedReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExtrasUsedReport));
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.atPanel5 = new atACCFramework.UserControls.atPanel();
            this.rbtExtra = new atACCFramework.UserControls.atRadioButton();
            this.btnSeperator2 = new System.Windows.Forms.Button();
            this.rbtAmenity = new atACCFramework.UserControls.atRadioButton();
            this.chkAll = new atACCFramework.UserControls.atCheckBox();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.ucReportCriteria = new atACCFramework.UserControls.ucReportCriteria();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.txtRoom = new atACCFramework.UserControls.TextBoxExt();
            this.txtExtraOrAmenity = new atACCFramework.UserControls.TextBoxExt();
            this.lblExtraOrAmenity = new System.Windows.Forms.Label();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.atPanel5.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.atPanel5);
            this.pnlSearchBylist.Controls.Add(this.chkAll);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // atPanel5
            // 
            this.atPanel5.BackColor = System.Drawing.SystemColors.Window;
            this.atPanel5.Controls.Add(this.rbtExtra);
            this.atPanel5.Controls.Add(this.btnSeperator2);
            this.atPanel5.Controls.Add(this.rbtAmenity);
            resources.ApplyResources(this.atPanel5, "atPanel5");
            this.atPanel5.Name = "atPanel5";
            // 
            // rbtExtra
            // 
            resources.ApplyResources(this.rbtExtra, "rbtExtra");
            this.rbtExtra.Name = "rbtExtra";
            this.rbtExtra.UseVisualStyleBackColor = true;
            // 
            // btnSeperator2
            // 
            this.btnSeperator2.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator2, "btnSeperator2");
            this.btnSeperator2.Name = "btnSeperator2";
            this.btnSeperator2.UseVisualStyleBackColor = false;
            // 
            // rbtAmenity
            // 
            resources.ApplyResources(this.rbtAmenity, "rbtAmenity");
            this.rbtAmenity.Checked = true;
            this.rbtAmenity.Name = "rbtAmenity";
            this.rbtAmenity.TabStop = true;
            this.rbtAmenity.UseVisualStyleBackColor = true;
            // 
            // chkAll
            // 
            resources.ApplyResources(this.chkAll, "chkAll");
            this.chkAll.Name = "chkAll";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.ucReportCriteria);
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Name = "pnlMain";
            // 
            // ucReportCriteria
            // 
            this.ucReportCriteria.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.ucReportCriteria, "ucReportCriteria");
            this.ucReportCriteria.FromDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 428);
            this.ucReportCriteria.Name = "ucReportCriteria";
            this.ucReportCriteria.ToDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 430);
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.txtRoom);
            this.grpCommon.Controls.Add(this.txtExtraOrAmenity);
            this.grpCommon.Controls.Add(this.lblExtraOrAmenity);
            this.grpCommon.Controls.Add(this.txtGuest);
            this.grpCommon.Controls.Add(this.lblRoom);
            this.grpCommon.Controls.Add(this.lblGuest);
            this.grpCommon.Controls.Add(this.lblRoomType);
            this.grpCommon.Controls.Add(this.cmbRoomType);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // txtRoom
            // 
            resources.ApplyResources(this.txtRoom, "txtRoom");
            this.txtRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoom.Format = null;
            this.txtRoom.isAllowNegative = false;
            this.txtRoom.isAllowSpecialChar = false;
            this.txtRoom.isNumbersOnly = false;
            this.txtRoom.isNumeric = false;
            this.txtRoom.isTouchable = false;
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoom.TextChanged += new System.EventHandler(this.txtRoom_TextChanged);
            // 
            // txtExtraOrAmenity
            // 
            resources.ApplyResources(this.txtExtraOrAmenity, "txtExtraOrAmenity");
            this.txtExtraOrAmenity.BackColor = System.Drawing.SystemColors.Window;
            this.txtExtraOrAmenity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtExtraOrAmenity.Format = null;
            this.txtExtraOrAmenity.isAllowNegative = false;
            this.txtExtraOrAmenity.isAllowSpecialChar = false;
            this.txtExtraOrAmenity.isNumbersOnly = false;
            this.txtExtraOrAmenity.isNumeric = false;
            this.txtExtraOrAmenity.isTouchable = false;
            this.txtExtraOrAmenity.Name = "txtExtraOrAmenity";
            this.txtExtraOrAmenity.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtExtraOrAmenity.TextChanged += new System.EventHandler(this.txtExtraOrAmenity_TextChanged);
            // 
            // lblExtraOrAmenity
            // 
            resources.ApplyResources(this.lblExtraOrAmenity, "lblExtraOrAmenity");
            this.lblExtraOrAmenity.Name = "lblExtraOrAmenity";
            // 
            // txtGuest
            // 
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGuest.Format = null;
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGuest.TextChanged += new System.EventHandler(this.txtGuest_TextChanged);
            this.txtGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGuest_KeyPress);
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Name = "cmbRoomType";
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmExtrasUsedReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlSearchBylist);
            this.Name = "frmExtrasUsedReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmExtrasUsedReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmExtrasUsedReport_atDesignClick);
            this.atValidate += new atACC.HTL.UI.ValidateEventHandler(this.frmExtrasUsedReport_atValidate);
            this.Load += new System.EventHandler(this.frmExtrasUsedReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.atPanel5.ResumeLayout(false);
            this.atPanel5.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atPanel atPanel5;
        private atACCFramework.UserControls.atRadioButton rbtExtra;
        private System.Windows.Forms.Button btnSeperator2;
        private atACCFramework.UserControls.atRadioButton rbtAmenity;
        private atACCFramework.UserControls.atCheckBox chkAll;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.TextBoxExt txtExtraOrAmenity;
        private System.Windows.Forms.Label lblExtraOrAmenity;
        private atACCFramework.UserControls.ucReportCriteria ucrDatePicker;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.TextBoxExt txtRoom;
        private atACCFramework.UserControls.atGroupBox grpCommon;
        private atACCFramework.UserControls.ucReportCriteria ucReportCriteria;
    }
}