﻿namespace atACC.HTL.Reports
{
    partial class frmCloseCashReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCloseCashReport));
            this.atPanel1 = new atACCFramework.UserControls.atPanel();
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.rbtDate = new atACCFramework.UserControls.atRadioButton();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.grpAsOnDate = new atACCFramework.UserControls.atGroupBox();
            this.dtpAsOnDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblAsOn = new atACCFramework.UserControls.atLabel();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.atPanel1.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpAsOnDate.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            this.errProvider.SetError(this.pnlBottom, resources.GetString("pnlBottom.Error"));
            this.errProvider.SetIconAlignment(this.pnlBottom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlBottom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlBottom, ((int)(resources.GetObject("pnlBottom.IconPadding"))));
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.lblHead);
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // atPanel1
            // 
            resources.ApplyResources(this.atPanel1, "atPanel1");
            this.atPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.atPanel1.Controls.Add(this.pnlSearchBylist);
            this.atPanel1.Controls.Add(this.pnlMain);
            this.errProvider.SetError(this.atPanel1, resources.GetString("atPanel1.Error"));
            this.errProvider.SetIconAlignment(this.atPanel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atPanel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atPanel1, ((int)(resources.GetObject("atPanel1.IconPadding"))));
            this.atPanel1.Name = "atPanel1";
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.rbtDate);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.errProvider.SetError(this.pnlSearchBylist, resources.GetString("pnlSearchBylist.Error"));
            this.errProvider.SetIconAlignment(this.pnlSearchBylist, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlSearchBylist.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlSearchBylist, ((int)(resources.GetObject("pnlSearchBylist.IconPadding"))));
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.errProvider.SetError(this.btnSeperator0, resources.GetString("btnSeperator0.Error"));
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.errProvider.SetIconAlignment(this.btnSeperator0, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnSeperator0.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnSeperator0, ((int)(resources.GetObject("btnSeperator0.IconPadding"))));
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // rbtDate
            // 
            resources.ApplyResources(this.rbtDate, "rbtDate");
            this.rbtDate.Checked = true;
            this.errProvider.SetError(this.rbtDate, resources.GetString("rbtDate.Error"));
            this.errProvider.SetIconAlignment(this.rbtDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtDate, ((int)(resources.GetObject("rbtDate.IconPadding"))));
            this.rbtDate.Name = "rbtDate";
            this.rbtDate.TabStop = true;
            this.rbtDate.UseVisualStyleBackColor = true;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.errProvider.SetError(this.atLabel3, resources.GetString("atLabel3.Error"));
            this.errProvider.SetIconAlignment(this.atLabel3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atLabel3, ((int)(resources.GetObject("atLabel3.IconPadding"))));
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.errProvider.SetError(this.btnSeperator4, resources.GetString("btnSeperator4.Error"));
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            this.errProvider.SetIconAlignment(this.btnSeperator4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnSeperator4.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnSeperator4, ((int)(resources.GetObject("btnSeperator4.IconPadding"))));
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.grpAsOnDate);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // grpAsOnDate
            // 
            resources.ApplyResources(this.grpAsOnDate, "grpAsOnDate");
            this.grpAsOnDate.BackColor = System.Drawing.Color.Transparent;
            this.grpAsOnDate.Controls.Add(this.dtpAsOnDate);
            this.grpAsOnDate.Controls.Add(this.lblAsOn);
            this.errProvider.SetError(this.grpAsOnDate, resources.GetString("grpAsOnDate.Error"));
            this.errProvider.SetIconAlignment(this.grpAsOnDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("grpAsOnDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.grpAsOnDate, ((int)(resources.GetObject("grpAsOnDate.IconPadding"))));
            this.grpAsOnDate.Name = "grpAsOnDate";
            this.grpAsOnDate.TabStop = false;
            // 
            // dtpAsOnDate
            // 
            resources.ApplyResources(this.dtpAsOnDate, "dtpAsOnDate");
            this.dtpAsOnDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpAsOnDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpAsOnDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpAsOnDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpAsOnDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpAsOnDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpAsOnDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpAsOnDate.Checked = true;
            this.dtpAsOnDate.DisbaleDateTimeFormat = true;
            this.dtpAsOnDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpAsOnDate, resources.GetString("dtpAsOnDate.Error"));
            this.dtpAsOnDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpAsOnDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpAsOnDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpAsOnDate, ((int)(resources.GetObject("dtpAsOnDate.IconPadding"))));
            this.dtpAsOnDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpAsOnDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpAsOnDate.Name = "dtpAsOnDate";
            this.dtpAsOnDate.Value = new System.DateTime(2019, 5, 27, 12, 14, 23, 41);
            // 
            // lblAsOn
            // 
            resources.ApplyResources(this.lblAsOn, "lblAsOn");
            this.errProvider.SetError(this.lblAsOn, resources.GetString("lblAsOn.Error"));
            this.errProvider.SetIconAlignment(this.lblAsOn, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAsOn.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAsOn, ((int)(resources.GetObject("lblAsOn.IconPadding"))));
            this.lblAsOn.Name = "lblAsOn";
            this.lblAsOn.RequiredField = false;
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.errProvider.SetError(this.lblHead, resources.GetString("lblHead.Error"));
            this.errProvider.SetIconAlignment(this.lblHead, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblHead.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblHead, ((int)(resources.GetObject("lblHead.IconPadding"))));
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmCloseCashReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.atPanel1);
            this.Name = "frmCloseCashReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmCloseCashReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmCloseCashReport_atDesignClick);
            this.Load += new System.EventHandler(this.frmCloseCashReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.atPanel1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.atPanel1.ResumeLayout(false);
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpAsOnDate.ResumeLayout(false);
            this.grpAsOnDate.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel atPanel1;
        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atRadioButton rbtDate;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atGroupBox grpAsOnDate;
        private atACCFramework.UserControls.atDateTimePicker dtpAsOnDate;
        private atACCFramework.UserControls.atLabel lblAsOn;
        private atACCFramework.UserControls.atLabel lblHead;

    }
}