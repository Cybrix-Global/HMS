﻿namespace atACC.HTL.Reports
{
    partial class frmLaundryReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLaundryReport));
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.ucReportCriteria = new atACCFramework.UserControls.ucReportCriteria();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.lblService = new System.Windows.Forms.Label();
            this.txtRoom = new atACCFramework.UserControls.TextBoxExt();
            this.cmbService = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.chkAll = new atACCFramework.UserControls.atCheckBox();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.ucReportCriteria);
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Name = "pnlMain";
            // 
            // ucReportCriteria
            // 
            this.ucReportCriteria.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.ucReportCriteria, "ucReportCriteria");
            this.ucReportCriteria.FromDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 428);
            this.ucReportCriteria.Name = "ucReportCriteria";
            this.ucReportCriteria.ToDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 430);
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.txtGuest);
            this.grpCommon.Controls.Add(this.lblGuest);
            this.grpCommon.Controls.Add(this.lblService);
            this.grpCommon.Controls.Add(this.txtRoom);
            this.grpCommon.Controls.Add(this.cmbService);
            this.grpCommon.Controls.Add(this.lblRoom);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // txtGuest
            // 
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGuest.Format = null;
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGuest.TextChanged += new System.EventHandler(this.txtGuest_TextChanged);
            this.txtGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGuest_KeyPress);
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // lblService
            // 
            resources.ApplyResources(this.lblService, "lblService");
            this.lblService.Name = "lblService";
            // 
            // txtRoom
            // 
            resources.ApplyResources(this.txtRoom, "txtRoom");
            this.txtRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoom.Format = null;
            this.txtRoom.isAllowNegative = false;
            this.txtRoom.isAllowSpecialChar = false;
            this.txtRoom.isNumbersOnly = false;
            this.txtRoom.isNumeric = false;
            this.txtRoom.isTouchable = false;
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoom.TextChanged += new System.EventHandler(this.txtRoom_TextChanged);
            // 
            // cmbService
            // 
            this.cmbService.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbService.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbService.DropDownHeight = 300;
            this.cmbService.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbService, "cmbService");
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Name = "cmbService";
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.chkAll);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // chkAll
            // 
            resources.ApplyResources(this.chkAll, "chkAll");
            this.chkAll.Name = "chkAll";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmLaundryReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlSearchBylist);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmLaundryReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmLaundryReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmLaundryReport_atDesignClick);
            this.atValidate += new atACC.HTL.UI.ValidateEventHandler(this.frmLaundryReport_atValidate);
            this.atSubReportProcessing += new Microsoft.Reporting.WinForms.SubreportProcessingEventHandler(this.frmLaundryReport_atSubReportProcessing);
            this.Load += new System.EventHandler(this.frmLaundryReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.ComboBoxExt cmbService;
        private atACCFramework.UserControls.atLabel lblRoom;
        private atACCFramework.UserControls.TextBoxExt txtRoom;
        private System.Windows.Forms.Label lblService;
        private atACCFramework.UserControls.ucReportCriteria ucrDatePicker;
        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atCheckBox chkAll;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.atGroupBox grpCommon;
        private atACCFramework.UserControls.ucReportCriteria ucReportCriteria;
    }
}