﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.UI;
using atACC.HTL.Masters;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmRoomShiftReport : atReportFormBase
    {
        #region Constructor
        public frmRoomShiftReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion

        #region Private Variables
        List<Guests> e_GuestList;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        public void PopulateGuests()
        {
            try
            {
                e_GuestList = dbh.Guests
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateFromRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.ToList();
                txtFromRoom.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void PopulateToRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.ToList();
                txtToRoom.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtGuest, "Enter Guest");
                tooltip.SetToolTip(txtFromRoom, "Enter From Room");
                tooltip.SetToolTip(txtToRoom, "Enter To Room");
                tooltip.SetToolTip(rbtShiftDate, "Select This Option To View Report Based On Shift Date");
                tooltip.SetToolTip(rbtVoucherDate, "Select This Option To View Report Based On Voucher Date");                
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmRoomShiftReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateGuests();
                PopulateFromRoom();
                PopulateToRoom();
                ShowToolTip();
                ucReportCriteria.Initialise();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    txtGuest.Tag = frm.SelectedGuestID;
                    txtGuest.Text = frm.SelectedGuestName;
                    txtGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void frmRoomShiftReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptRoomShiftReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Room Shift Report" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Room Shift Report";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("IsVoucherDate", rbtVoucherDate.Checked ? 1 : 0));
                sqlParameters.Add(new SqlParameter("GuestID", txtGuest.Text != "" ? txtGuest.Tag : 0));
                sqlParameters.Add(new SqlParameter("FromRoomID", txtFromRoom.Text.Trim() != "" ? txtFromRoom.Tag : 0));
                sqlParameters.Add(new SqlParameter("ToRoomID", txtToRoom.Text.Trim() != "" ? txtFromRoom.Tag : 0));
                sqlParameters.Add(new SqlParameter("FromDate", ucReportCriteria.FromDate));
                sqlParameters.Add(new SqlParameter("ToDate", ucReportCriteria.ToDate));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPRoomShiftReport", sqlParameters);
                ds.Tables[0].TableName = "dsRoomShiftReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }

        private void frmRoomShiftReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptRoomShiftReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion
    }
}
