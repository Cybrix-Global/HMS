﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.Masters;
using atACC.HTL.UI;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmGuestDetailsReport : atReportFormBase
    {
        #region Constructor
        public frmGuestDetailsReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion
        #region Private Variables
        List<Guests> e_GuestList;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion
        #region Populate Events
        public void PopulateGuests()
        {
            try
            {
                e_GuestList = dbh.Guests
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateCity()
        {
            try
            {
                List<GuestDTLs> m_City = dbh.GuestDTLs.GroupBy(x => x.City).Select(y => y.SingleOrDefault()).ToList();
                txtCity.LoadSuggest(m_City, "City");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void PopulateState()
        {
            try
            {
                List<GuestDTLs> m_State = dbh.GuestDTLs.GroupBy(x => x.State).Select(y => y.SingleOrDefault()).ToList();
                txtState.LoadSuggest(m_State, "State");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void PopulateCountry()
        {
            try
            {
                List<GuestDTLs> m_Country = dbh.GuestDTLs.GroupBy(x => x.Country).Select(y => y.SingleOrDefault()).ToList();
                txtCountry.LoadSuggest(m_Country, "Country");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtGuest, "Enter Guest");
                tooltip.SetToolTip(txtCity, "Select City");
                tooltip.SetToolTip(txtState, "Select State");
                tooltip.SetToolTip(txtCountry, "Select Country");
                tooltip.SetToolTip(rbtAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
        #region Form Events
        private void frmGuestDetailsReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateGuests();
                PopulateCity();
                PopulateState();
                PopulateCountry();
                ShowToolTip();
                grpCommon.Enabled = false;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbtAll.Checked)
                {
                    grpCommon.Enabled = false;
                    txtGuest.Clear();
                    txtCity.Clear();
                    txtState.Clear();
                    txtCountry.Clear();
                }
                else
                {
                    grpCommon.Enabled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    txtGuest.Tag = frm.SelectedGuestID;
                    txtGuest.Text = frm.SelectedGuestName;
                    txtGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
        #region Framework Events
        private bool frmGuestDetailsReport_atValidate(object source)
        {
            try
            {
                if (rbtGuestWise.Checked == true && txtGuest.Text.Trim() == "" && txtCity.Text.Trim() == "" && txtState.Text.Trim() == ""
                    && txtCountry.Text.Trim() == "")
                {
                    errProvider.SetError(rbtGuestWise, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmGuestDetailsReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptGuestDetailsReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Guest Details Report" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Guest Details Report";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("GuestID", txtGuest.Text.Trim() != "" ? txtGuest.Tag : 0));
                sqlParameters.Add(new SqlParameter("City", txtCity.Text.Trim() != "" ? txtCity.SelectedText : ""));
                sqlParameters.Add(new SqlParameter("State", txtState.Text.Trim() != "" ? txtState.SelectedText : ""));
                sqlParameters.Add(new SqlParameter("Country", txtCountry.Text.Trim() != "" ? txtCountry.SelectedText : ""));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPGuestDetailsReport", sqlParameters);
                ds.Tables[0].TableName = "dsGuestDetailsReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmGuestDetailsReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptGuestDetailsReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion

        
    }
}
