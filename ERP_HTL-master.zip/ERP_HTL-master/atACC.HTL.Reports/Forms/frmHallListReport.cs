﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.UI;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmHallListReport : atReportFormBase
    {
        #region Constructor
        public frmHallListReport()
        {
            InitializeComponent();
            db = atHotelContext.CreateContext();
        }
        #endregion
        #region Private Variables
        atACCHotelEntities db;
        ToolTip tooltip;
        #endregion
        #region Populate Events
        private void PopulateRoom()
        {
            try
            {
                List<Rooms> m_Rooms = db.Rooms.ToList().Where(x => x.IsHall == true).ToList();
                txtCode.LoadSuggest(m_Rooms, "Code");
                txtName.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateCombos()
        {
            try
            {
                #region RoomType
                var RoomType = db.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "" && x.IsHallType == true).ToList();
                cmbRoomType.DataSource = RoomType.ToList();
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
                #endregion
                #region Floor
                var Floor = db.Floors.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbFloor.DataSource = Floor.ToList();
                cmbFloor.DisplayMember = "Name";
                cmbFloor.ValueMember = "id";
                cmbFloor.SelectedIndex = -1;
                #endregion
                #region Block
                var Block = db.Blocks.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbBlock.DataSource = Block.ToList();
                cmbBlock.DisplayMember = "Name";
                cmbBlock.ValueMember = "id";
                cmbBlock.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }




        }
        public void DisableOrEnableFields()
        {
            try
            {
                #region All
                if (rbtAll.Checked == true)
                {
                    txtCode.Enabled = false;
                    txtName.Enabled = false;
                    cmbRoomType.Enabled = false;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = false;

                    txtCode.Clear();
                    txtName.Clear();
                    cmbRoomType.SelectedIndex = -1;
                    cmbFloor.SelectedIndex = -1;
                    cmbBlock.SelectedIndex = -1;
                }
                #endregion
                #region Hall
                if (radHall.Checked == true)
                {
                    txtCode.Enabled = true;
                    txtName.Enabled = true;
                    cmbRoomType.Enabled = false;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = false;

                    cmbRoomType.SelectedIndex = -1;
                    cmbFloor.SelectedIndex = -1;
                    cmbBlock.SelectedIndex = -1;
                }
                #endregion
                #region HallType
                if (radHallType.Checked == true)
                {
                    txtCode.Enabled = false;
                    txtName.Enabled = false;
                    cmbRoomType.Enabled = true;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = false;

                    txtCode.Clear();
                    txtName.Clear();
                    cmbFloor.SelectedIndex = -1;
                    cmbBlock.SelectedIndex = -1;
                }
                #endregion
                #region Floor
                if (radFloor.Checked == true)
                {
                    txtCode.Enabled = false;
                    txtName.Enabled = false;
                    cmbRoomType.Enabled = false;
                    cmbFloor.Enabled = true;
                    cmbBlock.Enabled = false;

                    txtCode.Clear();
                    txtName.Clear();
                    cmbRoomType.SelectedIndex = -1;
                    cmbBlock.SelectedIndex = -1;
                }
                #endregion
                #region Block
                if (radBlock.Checked == true)
                {
                    txtCode.Enabled = false;
                    txtName.Enabled = false;
                    cmbRoomType.Enabled = false;
                    cmbFloor.Enabled = false;
                    cmbBlock.Enabled = true;

                    txtCode.Clear();
                    txtName.Clear();
                    cmbRoomType.SelectedIndex = -1;
                    cmbFloor.SelectedIndex = -1;
                }
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtCode, MessageKeys.MsgEnterCode);
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(cmbRoomType, "Select Hall Type");
                tooltip.SetToolTip(cmbBlock, "Select Block");
                tooltip.SetToolTip(cmbFloor, "Select Floor");
                tooltip.SetToolTip(rbtAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
                tooltip.SetToolTip(radHall, MessageKeys.MsgEnableToSearchUsingNameOrCode);
                tooltip.SetToolTip(radHallType, "Enable To Search Using Hall Type");
                tooltip.SetToolTip(radBlock, "Enable To Search Using Block");
                tooltip.SetToolTip(radFloor, "Enable To Search Using Floor");



            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
        #region Form Events
        private void frmCheckListHall_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateRoom();
                PopulateCombos();
                ShowToolTip();
                txtCode.Focus();
                rbtAll_CheckedChanged(sender, e);
                DisableOrEnableFields();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtCode_TextChanged(object sender, EventArgs e)
        {

            try
            {
                List<Rooms> Sd = db.Rooms.ToList().Where(x => x.IsHall == true).ToList();
                List<Rooms> SDp = Sd.Where(x => x.Code == txtCode.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtName.Text = ""; txtName.Tag = "";
                    txtName.Text = SDp.Select(x => x.Name).Single();
                    txtName.Tag = SDp.Select(x => x.id).Single();
                }
                else
                {
                    txtName.Text = ""; txtName.Tag = "";
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Rooms> Sd = db.Rooms.ToList().Where(x => x.IsHall == true).ToList();
                List<Rooms> SDp = Sd.Where(x => x.Name == txtName.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtCode.Text = SDp.Select(x => x.Code).Single();
                    txtName.Tag = SDp.Select(x => x.id).Single();

                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                errProvider.Clear();
                DisableOrEnableFields();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void frmCheckListHall_Activated(object sender, EventArgs e)
        {
            try
            {
                rbtAll.Checked = true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void radHall_CheckedChanged(object sender, EventArgs e)
        {
            if (radHall.Checked == true)
            { txtCode.Focus(); }
            DisableOrEnableFields();
        }
        private void radBlock_CheckedChanged(object sender, EventArgs e)
        {
            if (radBlock.Checked == true)
            { cmbBlock.Focus(); }
            DisableOrEnableFields();
        }
        private void radFloor_CheckedChanged(object sender, EventArgs e)
        {
            if (radFloor.Checked == true)
            { cmbFloor.Focus(); }
            DisableOrEnableFields();
        }
        private void radHallType_CheckedChanged(object sender, EventArgs e)
        {
            if (radHallType.Checked == true)
            { cmbRoomType.Focus(); }
            DisableOrEnableFields();
        }
        #endregion
        #region Framework Events
        private bool frmCheckListHall_atValidate(object source)
        {
            try
            {
                if (radHall.Checked == true && txtCode.Text == "" && txtName.Text == "")
                {
                    errProvider.SetError(radHall, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                if (radHallType.Checked == true && cmbRoomType.Text.Trim() == "")
                {
                    errProvider.SetError(radHallType, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                if (radBlock.Checked == true && cmbBlock.Text == "")
                {
                    errProvider.SetError(radBlock, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                if (radFloor.Checked == true && cmbFloor.Text == "")
                {
                    errProvider.SetError(radFloor, MessageKeys.MsgAtleastOneSearchCriteriaMustBeSpecified); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmCheckListHall_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptHallListReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Check List Hall" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgChecklistReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgChecklistReport + " " + MessageKeys.MsgOf + " " + "Check List Hall";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                sqlParameters.Add(new SqlParameter("HallID", txtName.Text != "" ? txtName.Tag : 0));
                sqlParameters.Add(new SqlParameter("HallTypeID", cmbRoomType.Text.Trim() != "" ? cmbRoomType.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("BlockID", cmbBlock.Text.Trim() != "" ? cmbBlock.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("FloorID", cmbFloor.Text.Trim() != "" ? cmbFloor.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("All", rbtAll.Checked ? 1 : 0));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPHallListReport", sqlParameters);
                ds.Tables[0].TableName = "dsHallListReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmCheckListHall_atHyperLinkClick(object sender, Microsoft.Reporting.WinForms.HyperlinkEventArgs e)
        {
            try
            {
                //Uri link = new Uri(e.Hyperlink);
                //if (link.Authority == "ataccplus")
                //{
                //    e.Cancel = true;
                //    char[] sep = new char[] { '=' };
                //    var param = link.Query.Split(sep);
                //    string rowid = param[1];
                //    ANIHelper aniHelper = new ANIHelper();
                //  aniHelper.DrillDownTransaction(EnContextID.HTL_, rowid.ToInt32());
                //}
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.HyperLinkClick);
                return;
            }
        }
        private void frmCheckListHall_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptHallListReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion
    }
}
