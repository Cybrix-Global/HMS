﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.UI;
using atACC.HTL.Masters;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmTaskRecordingReport : atReportFormBase
    {
        #region Constructor
        public frmTaskRecordingReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            db = atContext.CreateContext();
        }
        #endregion

        #region Private Variables
        List<Guests> e_GuestList;
        atACCHotelEntities dbh;
        atACCContextEntities db;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.ToList();
                txtRoom.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void PopulateGuests()
        {
            try
            {
                e_GuestList = dbh.Guests
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Employee
                var Employee = db.Employees.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbEmployee.DataSource = Employee.ToList();
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                #endregion

                #region RoomType
                var RoomType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).ToList();
                cmbRoomType.DataSource = RoomType.ToList();
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtRoom, "Select Room");
                tooltip.SetToolTip(cmbEmployee, "Select Employee");
                tooltip.SetToolTip(txtGuest, "Select Guest");
                tooltip.SetToolTip(cmbRoomType, "Select Guest Type");
                tooltip.SetToolTip(chkAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmTaskRecordingReport_Load(object sender, EventArgs e)
        {
            try
            {
                txtGuest.Enabled = false;
                PopulateRoom();
                PopulateGuests();
                PopulateCombos();
                ShowToolTip();
                ucReportCriteria.Initialise();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkAll.Checked == true)
                {
                    errProvider.Clear();
                    txtRoom.Enabled = false;
                    cmbEmployee.Enabled = false;
                    cmbRoomType.Enabled = false;
                    txtGuest.Enabled = false;
                }
                else if (chkAll.Checked == false)
                {
                    errProvider.Clear();
                    txtRoom.Enabled = true;
                    cmbEmployee.Enabled = true;
                    cmbRoomType.Enabled = true;
                    if (rbtRoomService.Checked)
                    {
                        txtGuest.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void rbtHouseKeeping_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbtHouseKeeping.Checked)
                {
                    txtGuest.Enabled = false;
                }
                else if (rbtRoomService.Checked)
                {
                    txtGuest.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtRoom_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Rooms> Sd = dbh.Rooms.ToList();
                List<Rooms> SDp = Sd.Where(x => x.Name == txtRoom.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtRoom.Tag = SDp.Select(x => x.id).Single();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    txtGuest.Tag = frm.SelectedGuestID;
                    txtGuest.Text = frm.SelectedGuestName;
                    txtGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private bool frmTaskRecordingReport_atValidate(object source)
        {
            try
            {
                if (chkAll.Checked == false && txtRoom.Text.Trim() == ""&& cmbEmployee.Text.Trim() == "" 
                    && txtGuest.Text.Trim() == "" && cmbRoomType.Text.Trim() == "")
                {
                    errProvider.SetError(chkAll, MessageKeys.MsgAtleastOneOptionMustBeSelected); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmTaskRecordingReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                if (rbtRoomService.Checked)
                {
                    e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptTaskRecordingReportRoomServiceHDR.rdlc";
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        string sReportCaption = "Task Recording" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                    else
                    {
                        string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Task Recording";
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                }
                else if (rbtHouseKeeping.Checked)
                {
                    e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptTaskRecordingReportHouseKeeping.rdlc";
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        string sReportCaption = "Task Recording" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                    else
                    {
                        string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Task Recording";
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                if (rbtRoomService.Checked)
                {
                    sqlParameters.Add(new SqlParameter("GuestID", txtGuest.Text.Trim() != "" ? txtGuest.Tag : 0));
                }
                sqlParameters.Add(new SqlParameter("RoomID", txtRoom.Text.Trim() != "" ? txtRoom.Tag : 0));
                sqlParameters.Add(new SqlParameter("RoomTypeID", cmbRoomType.Text.Trim() != "" ? cmbRoomType.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("EmployeeID", cmbEmployee.Text != "" ? cmbEmployee.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("FromDate", ucReportCriteria.FromDate));
                sqlParameters.Add(new SqlParameter("ToDate", ucReportCriteria.ToDate));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                if (rbtRoomService.Checked)
                {
                    ds = sqlh.ExecuteProcedure("SPTaskRecordingReportRoomServiceHDR", sqlParameters);
                    ds.Tables[0].TableName = "dsTaskRecordingReportRoomServiceHDR";
                }
                else if(rbtHouseKeeping.Checked)
                {
                    ds = sqlh.ExecuteProcedure("SPTaskRecordingReportHouseKeeping", sqlParameters);
                    ds.Tables[0].TableName = "dsTaskRecordingReportHouseKeeping";
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmTaskRecordingReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptTaskRecordingReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        private void frmTaskRecordingReport_atSubReportProcessing(object sender, SubreportProcessingEventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                if (e.DataSourceNames[0] == "dsTaskRecordingReportRoomServiceSub")
                {
                    int sHDRID = e.Parameters["HDRID"].Values[0].ToInt32();
                    sqlParameters.Add(new SqlParameter("HDRID", sHDRID));
                    ds = sqlh.ExecuteProcedure("SPTaskRecordingReportRoomServiceSub", sqlParameters);
                    ds.Tables[0].TableName = "dsTaskRecordingReportRoomServiceSub";
                    ReportDataSource rds = new ReportDataSource("dsTaskRecordingReportRoomServiceSub", ds.Tables[0]);
                    e.DataSources.Add(rds);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.SubReportProcess);
                return;
            }
        }
        #endregion   
    }
}
