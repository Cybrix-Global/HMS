﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.UI;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmOutOfOrderReport : atReportFormBase
    {
        #region Constructor
        public frmOutOfOrderReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion

        #region Private Variables
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateReason()
        {
            try
            {
                List<RoomOutofOrder> m_OutOfOrder = dbh.RoomOutofOrders.ToList();
                txtReason.LoadSuggest(m_OutOfOrder, "Reason");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void PopulateRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.ToList();
                txtRoom.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void PopulateCombos()
        {
            try
            {
                #region RoomType
                var RoomType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "" && x.IsHallType == false).ToList();
                cmbRoomType.DataSource = RoomType.ToList();
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void ClearFields()
        {
            try
            {
                if (chkAll.Checked == true)
                {
                    txtReason.Clear();
                    txtRoom.Clear();
                    cmbRoomType.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtReason, "Select Reason");
                tooltip.SetToolTip(txtRoom, "Select Room");
                tooltip.SetToolTip(cmbRoomType, "Select Room Type");
                tooltip.SetToolTip(chkAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmOutOfOrdeReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateReason();
                PopulateRoom();
                PopulateCombos();
                ShowToolTip();
                ucReportCriteria.Initialise();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ClearFields();
                if (chkAll.Checked == true)
                {
                    errProvider.Clear();
                    txtReason.Enabled = false;
                    txtRoom.Enabled = false;
                    cmbRoomType.Enabled = false;
                }
                else if (chkAll.Checked == false)
                {
                    errProvider.Clear();
                    txtReason.Enabled = true;
                    txtRoom.Enabled = true;
                    cmbRoomType.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtReason_TextChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtRoom_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Rooms> Sd = dbh.Rooms.ToList();
                List<Rooms> SDp = Sd.Where(x => x.Name == txtRoom.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtRoom.Tag = SDp.Select(x => x.id).Single();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        #endregion

        #region Framework Events
        private bool frmOutOfOrdeReport_atValidate(object source)
        {
            try
            {
                if (chkAll.Checked == false && txtReason.Text.Trim() == "" && txtRoom.Text.Trim() == ""
                    && cmbRoomType.Text.Trim() == "")
                {
                    errProvider.SetError(chkAll, MessageKeys.MsgAtleastOneOptionMustBeSelected); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmOutOfOrdeReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptOutOfOrderReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Out Of Order" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Out Of Order";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("Reason", txtReason.Text.Trim() != "" ? txtReason.Text : ""));
                sqlParameters.Add(new SqlParameter("RoomID", txtRoom.Text != "" ? txtRoom.Tag : 0));
                sqlParameters.Add(new SqlParameter("RoomTypeID", cmbRoomType.Text.Trim() != "" ? cmbRoomType.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("FromDate", ucReportCriteria.FromDate));
                sqlParameters.Add(new SqlParameter("ToDate", ucReportCriteria.ToDate));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPOutOfOrderReport", sqlParameters);
                ds.Tables[0].TableName = "dsOutOfOrderReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmOutOfOrdeReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptOutOfOrderReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion
    }
}
