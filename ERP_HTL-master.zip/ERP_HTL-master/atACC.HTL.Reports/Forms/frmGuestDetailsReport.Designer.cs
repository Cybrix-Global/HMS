﻿namespace atACC.HTL.Reports
{
    partial class frmGuestDetailsReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGuestDetailsReport));
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.rbtGuestWise = new atACCFramework.UserControls.atRadioButton();
            this.rbtAll = new atACCFramework.UserControls.atRadioButton();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.lblCountry = new atACCFramework.UserControls.atLabel();
            this.txtCountry = new atACCFramework.UserControls.TextBoxExt();
            this.txtState = new atACCFramework.UserControls.TextBoxExt();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblGuest = new System.Windows.Forms.Label();
            this.txtCity = new atACCFramework.UserControls.TextBoxExt();
            this.lblState = new atACCFramework.UserControls.atLabel();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.rbtGuestWise);
            this.pnlSearchBylist.Controls.Add(this.rbtAll);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // rbtGuestWise
            // 
            resources.ApplyResources(this.rbtGuestWise, "rbtGuestWise");
            this.rbtGuestWise.Name = "rbtGuestWise";
            this.rbtGuestWise.UseVisualStyleBackColor = true;
            // 
            // rbtAll
            // 
            resources.ApplyResources(this.rbtAll, "rbtAll");
            this.rbtAll.Checked = true;
            this.rbtAll.Name = "rbtAll";
            this.rbtAll.TabStop = true;
            this.rbtAll.UseVisualStyleBackColor = true;
            this.rbtAll.CheckedChanged += new System.EventHandler(this.rbtAll_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Name = "pnlMain";
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.lblCountry);
            this.grpCommon.Controls.Add(this.txtCountry);
            this.grpCommon.Controls.Add(this.txtState);
            this.grpCommon.Controls.Add(this.txtGuest);
            this.grpCommon.Controls.Add(this.lblCity);
            this.grpCommon.Controls.Add(this.lblGuest);
            this.grpCommon.Controls.Add(this.txtCity);
            this.grpCommon.Controls.Add(this.lblState);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // lblCountry
            // 
            resources.ApplyResources(this.lblCountry, "lblCountry");
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.RequiredField = false;
            // 
            // txtCountry
            // 
            resources.ApplyResources(this.txtCountry, "txtCountry");
            this.txtCountry.BackColor = System.Drawing.SystemColors.Window;
            this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCountry.Format = null;
            this.txtCountry.isAllowNegative = false;
            this.txtCountry.isAllowSpecialChar = false;
            this.txtCountry.isNumbersOnly = false;
            this.txtCountry.isNumeric = false;
            this.txtCountry.isTouchable = false;
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtState
            // 
            resources.ApplyResources(this.txtState, "txtState");
            this.txtState.BackColor = System.Drawing.SystemColors.Window;
            this.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtState.Format = null;
            this.txtState.isAllowNegative = false;
            this.txtState.isAllowSpecialChar = false;
            this.txtState.isNumbersOnly = false;
            this.txtState.isNumeric = false;
            this.txtState.isTouchable = false;
            this.txtState.Name = "txtState";
            this.txtState.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtGuest
            // 
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGuest.Format = null;
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGuest_KeyPress);
            // 
            // lblCity
            // 
            resources.ApplyResources(this.lblCity, "lblCity");
            this.lblCity.Name = "lblCity";
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            // 
            // txtCity
            // 
            resources.ApplyResources(this.txtCity, "txtCity");
            this.txtCity.BackColor = System.Drawing.SystemColors.Window;
            this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCity.Format = null;
            this.txtCity.isAllowNegative = false;
            this.txtCity.isAllowSpecialChar = false;
            this.txtCity.isNumbersOnly = false;
            this.txtCity.isNumeric = false;
            this.txtCity.isTouchable = false;
            this.txtCity.Name = "txtCity";
            this.txtCity.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblState
            // 
            resources.ApplyResources(this.lblState, "lblState");
            this.lblState.Name = "lblState";
            this.lblState.RequiredField = false;
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmGuestDetailsReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlSearchBylist);
            this.Name = "frmGuestDetailsReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmGuestDetailsReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmGuestDetailsReport_atDesignClick);
            this.atValidate += new atACC.HTL.UI.ValidateEventHandler(this.frmGuestDetailsReport_atValidate);
            this.Load += new System.EventHandler(this.frmGuestDetailsReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atRadioButton rbtGuestWise;
        private atACCFramework.UserControls.atRadioButton rbtAll;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atGroupBox grpCommon;
        private atACCFramework.UserControls.TextBoxExt txtState;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtCity;
        private atACCFramework.UserControls.atLabel lblState;
        private atACCFramework.UserControls.atLabel lblCountry;
        private atACCFramework.UserControls.TextBoxExt txtCountry;
        private atACCFramework.UserControls.atLabel lblHead;
    }
}