﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;

using atACC.HTL.UI;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmCloseCashReport : atReportFormBase
    {
        #region Constructor
        public frmCloseCashReport()
        {
            InitializeComponent();
        }
        #endregion

        #region Form Events
        private void frmCloseCashReport_Load(object sender, EventArgs e)
        {
            try
            {
                dtpAsOnDate.Value = DateTime.Now.ToEnd();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void frmCloseCashReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptCloseCashReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Close Cash" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Close Cash";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                sqlParameters.Add(new SqlParameter("Asondate", dtpAsOnDate.Value));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPCloseCashReport", sqlParameters);
                ds.Tables[0].TableName = "dsCloseCashReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmCloseCashReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptCloseCashReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion
    }
}
