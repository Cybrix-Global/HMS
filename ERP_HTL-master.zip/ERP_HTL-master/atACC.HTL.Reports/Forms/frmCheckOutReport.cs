﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.Masters;
using atACC.HTL.UI;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmCheckOutReport : atReportFormBase
    {
        #region Constructor
        public frmCheckOutReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion

        #region Private Variables
        List<Guests> e_GuestList;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.ToList();
                txtRoom.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateGuests()
        {
            try
            {
                e_GuestList = dbh.Guests
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateCombos()
        {
            try
            {
                #region RoomType
                var RoomType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "" && x.IsHallType == false).ToList();
                cmbRoomType.DataSource = RoomType.ToList();
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
                #endregion

                #region GuestType
                var GuestType = dbh.GuestTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).ToList();
                cmbGuestType.DataSource = GuestType.ToList();
                cmbGuestType.DisplayMember = "Name";
                cmbGuestType.ValueMember = "id";
                cmbGuestType.SelectedIndex = -1;
                #endregion

                #region Source
                var Source = dbh.Sources.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).ToList();
                cmbSource.DataSource = Source.ToList();
                cmbSource.DisplayMember = "Name";
                cmbSource.ValueMember = "id";
                cmbSource.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void ClearFields()
        {
            try
            {
                if (chkAll.Checked == true)
                {
                    txtRoom.Clear();
                    txtGuest.Clear();
                    cmbGuestType.SelectedIndex = -1;
                    cmbRoomType.SelectedIndex = -1;
                    cmbSource.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtRoom, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(cmbRoomType, "Select Room Type");
                tooltip.SetToolTip(txtGuest, "Select Guest");
                tooltip.SetToolTip(cmbGuestType, "Select Guest Type");
                tooltip.SetToolTip(cmbSource, "Select Source");
                tooltip.SetToolTip(chkAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmCheckOutReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateRoom();
                PopulateGuests();
                PopulateCombos();
                ShowToolTip();
                ucReportCriteria.Initialise();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ClearFields();
                if (chkAll.Checked == true)
                {
                    errProvider.Clear();
                    txtRoom.Enabled = false;
                    cmbRoomType.Enabled = false;
                    txtGuest.Enabled = false;
                    cmbGuestType.Enabled = false;
                    cmbSource.Enabled = false;
                }
                else if (chkAll.Checked == false)
                {
                    errProvider.Clear();
                    txtRoom.Enabled = true;
                    cmbRoomType.Enabled = true;
                    txtGuest.Enabled = true;
                    cmbGuestType.Enabled = true;
                    cmbSource.Enabled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtRoom_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Rooms> Sd = dbh.Rooms.ToList();
                List<Rooms> SDp = Sd.Where(x => x.Name == txtRoom.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtRoom.Tag = SDp.Select(x => x.id).Single();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    txtGuest.Tag = frm.SelectedGuestID;
                    txtGuest.Text = frm.SelectedGuestName;
                    txtGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private bool frmCheckOutReport_atValidate(object source)
        {
            try
            {
                if (chkAll.Checked == false && txtRoom.Text == "" && cmbRoomType.Text == "" && txtGuest.Text == "" && cmbGuestType.Text == "" &&
                    cmbSource.Text == "")
                {
                    errProvider.SetError(chkAll, MessageKeys.MsgAtleastOneOptionMustBeSelected); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmCheckOutReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptCheckOutReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Check Out" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Check Out";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                sqlParameters.Add(new SqlParameter("RoomID", txtRoom.Text != "" ? txtRoom.Tag : 0));
                sqlParameters.Add(new SqlParameter("RoomTypeID", cmbRoomType.Text.Trim() != "" ? cmbRoomType.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("GuestID", txtGuest.Text.Trim() != "" ? txtGuest.Tag : 0));
                sqlParameters.Add(new SqlParameter("GuestType", cmbGuestType.Text != "" ? cmbGuestType.SelectedValue : ""));
                sqlParameters.Add(new SqlParameter("Source", cmbSource.Text != "" ? cmbSource.SelectedValue : ""));
                sqlParameters.Add(new SqlParameter("FromDate", ucReportCriteria.FromDate));
                sqlParameters.Add(new SqlParameter("ToDate", ucReportCriteria.ToDate));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPCheckOutReport", sqlParameters);
                ds.Tables[0].TableName = "dsCheckOutReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmCheckOutReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptCheckOutReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }     
        private void frmCheckOutReport_atSubReportProcessing(object sender, SubreportProcessingEventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                if (e.DataSourceNames[0] == "dsCheckOutReportTransactionSub")
                {
                    int sHDRID = e.Parameters["CheckOutID"].Values[0].ToInt32();                    
                    sqlParameters.Add(new SqlParameter("CheckOutID", sHDRID));
                    ds = sqlh.ExecuteProcedure("SPCheckOutReportTransactionSub", sqlParameters);
                    ds.Tables[0].TableName = "dsCheckOutReportTransactionSub";
                    ReportDataSource rds = new ReportDataSource("dsCheckOutReportTransactionSub", ds.Tables[0]);
                    e.DataSources.Add(rds);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.SubReportProcess);
                return;
            }
        }
        #endregion
    }
}
