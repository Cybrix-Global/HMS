﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.UI;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmEnquiryReport : atReportFormBase
    {
        #region Constructor
        public frmEnquiryReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            db = atContext.CreateContext();
        }
        #endregion

        #region Private Variables
        atACCHotelEntities dbh;
        atACCContextEntities db;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateEnquiry()
        {
            try
            {
                List<Enquiry> m_Enquiry = dbh.Enquiries.ToList();
                txtName.LoadSuggest(m_Enquiry, "Name");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCombos()
        {
            try
            {
                #region Employee
                var Employee = db.Employees.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbEmployee.DataSource = Employee.ToList();
                cmbEmployee.DisplayMember = "Name";
                cmbEmployee.ValueMember = "id";
                cmbEmployee.SelectedIndex = -1;
                #endregion

                #region Agent
                var Agent = db.Agents.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).ToList();
                cmbAgent.DataSource = Agent.ToList();
                cmbAgent.DisplayMember = "Name";
                cmbAgent.ValueMember = "id";
                cmbAgent.SelectedIndex = -1;
                #endregion

                #region Enquiry Type
                var EnquiryType = dbh.Enquiries.GroupBy(x => x.Type).Select(y => y.FirstOrDefault()).ToList();
                cmbEnquiryType.DataSource = EnquiryType.ToList();
                cmbEnquiryType.DisplayMember = "Type";
                cmbEnquiryType.ValueMember = "id";
                cmbEnquiryType.SelectedIndex = -1;
                #endregion

                #region Mobile
                var Mobile = dbh.Enquiries.GroupBy(x => x.Mobile).Select(y => y.FirstOrDefault()).ToList();
                cmbMobile.DataSource = Mobile.ToList();
                cmbMobile.DisplayMember = "Mobile";
                cmbMobile.ValueMember = "id";
                cmbMobile.SelectedIndex = -1;
                #endregion

                #region Room Type
                var RoomType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbRoomType.DataSource = RoomType.ToList();
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ClearFields()
        {
            try
            {
                txtName.Clear();
                cmbEmployee.SelectedIndex = -1;
                cmbAgent.SelectedIndex = -1;
                cmbEnquiryType.SelectedIndex = -1;
                cmbMobile.SelectedIndex = -1;
                cmbRoomType.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtName, "Enter Enquiry");
                tooltip.SetToolTip(cmbEmployee, "Select Employee");
                tooltip.SetToolTip(cmbAgent, "Select Agent");
                tooltip.SetToolTip(cmbEnquiryType, "Select Enquiry Type");
                tooltip.SetToolTip(cmbMobile, "Select Mobile");
                tooltip.SetToolTip(cmbRoomType, "Select Room Type");
                tooltip.SetToolTip(chkAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmEnquiryReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateEnquiry();
                PopulateCombos();
                ShowToolTip();
                chkAll.Checked = true;
                ucReportCriteria.Initialise();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ClearFields();
                if (chkAll.Checked == true)
                {
                    errProvider.Clear();
                    txtName.Enabled = false;
                    cmbEmployee.Enabled = false;
                    cmbAgent.Enabled = false;
                    cmbEnquiryType.Enabled = false;
                    cmbMobile.Enabled = false;
                    cmbRoomType.Enabled = false;
                    ClearFields();
                }
                else if (chkAll.Checked == false)
                {
                    errProvider.Clear();
                    txtName.Enabled = true;
                    cmbEmployee.Enabled = true;
                    cmbAgent.Enabled = true;
                    cmbEnquiryType.Enabled = true;
                    cmbMobile.Enabled = true;
                    cmbRoomType.Enabled = true;
                    ClearFields();
                }
            }
            catch (Exception)
            {
                throw;
            }

        }
        private void txtEnquiry_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Enquiry> enq = dbh.Enquiries.ToList();
                List<Enquiry> enqs = enq.Where(x => x.Name == txtName.Text).ToList();
                if (enqs.Count > 0)
                {
                    txtName.Tag = enqs.Select(x => x.id).Single();
                }                
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private bool frmEnquiryReport_atValidate(object source)
        {
            try
            {
                if (chkAll.Checked == false && txtName.Text == "" && cmbEmployee.Text == "" && cmbAgent.Text =="" && cmbEnquiryType.Text == "" 
                    && cmbMobile.Text == "" &&cmbRoomType.Text == "")
                {
                    errProvider.SetError(chkAll, MessageKeys.MsgAtleastOneOptionMustBeSelected); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmEnquiryReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptEnquiryReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Enquiry" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Enquiry";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("EnquiryName", txtName.Text != "" ? txtName.Text.Trim() : ""));
                sqlParameters.Add(new SqlParameter("EmployeeID", cmbEmployee.Text != "" ? cmbEmployee.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("AgentID", cmbAgent.Text != "" ? cmbAgent.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("EnquiryType", cmbEnquiryType.Text != "" ? cmbEnquiryType.SelectedValue : ""));
                sqlParameters.Add(new SqlParameter("Mobile", cmbMobile.Text != "" ? cmbMobile.SelectedValue : ""));
                sqlParameters.Add(new SqlParameter("RoomTypeID", cmbRoomType.Text.Trim() != "" ? cmbRoomType.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("FromDate", ucReportCriteria.FromDate));
                sqlParameters.Add(new SqlParameter("ToDate", ucReportCriteria.ToDate));
                sqlParameters.Add(new SqlParameter("Enquiry", rbtArrival.Checked ? 1 : 0));
                sqlParameters.Add(new SqlParameter("Arrival", rbtEnquiry.Checked ? 1 : 0));
                sqlParameters.Add(new SqlParameter("Departure", rbtDeparture.Checked ? 1 : 0));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPEnquiryReport", sqlParameters);
                ds.Tables[0].TableName = "dsEnquiryReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmEnquiryReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptEnquiryReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion

    }
}
