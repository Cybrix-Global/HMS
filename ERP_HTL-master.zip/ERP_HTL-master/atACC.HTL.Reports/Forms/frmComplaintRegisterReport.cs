﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.Masters;
using atACC.HTL.UI;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmComplaintRegisterReport : atReportFormBase
    {
        #region Constructor
        public frmComplaintRegisterReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            db = atContext.CreateContext();
        }
        #endregion

        #region Private Variables
        List<Guests> e_GuestList;
        atACCHotelEntities dbh;
        atACCContextEntities db;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.ToList();
                txtRoom.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateGuests()
        {
            try
            {
                e_GuestList = dbh.Guests
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateComplaints()
        {
            try
            {
                List<ComplaintRegister> m_Complaints = dbh.ComplaintRegisters.ToList();
                txtComplaints.LoadSuggest(m_Complaints, "Complaint");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRemarks()
        {
            try
            {
                List<ComplaintRegister> m_Complaints = dbh.ComplaintRegisters.ToList();
                txtRemarks.LoadSuggest(m_Complaints, "Remarks");
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateCombos()
        {
            try
            {                

                #region Attended By
                var Attended = db.Employees.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbAttendedBy.DataSource = Attended.ToList();
                cmbAttendedBy.DisplayMember = "Name";
                cmbAttendedBy.ValueMember = "id";
                cmbAttendedBy.SelectedIndex = -1;
                #endregion

                #region Complaint Type
                var ComplaintType = dbh.ComplaintRegisters.GroupBy(x => x.Type).Select(y => y.FirstOrDefault()).ToList();
                cmbComplaintType.DataSource = ComplaintType.ToList();
                cmbComplaintType.DisplayMember = "Type";
                cmbComplaintType.ValueMember = "id";
                cmbComplaintType.SelectedIndex = -1;
                #endregion

                #region Staff Assigned
                var Staff = db.Employees.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbStaffAssigned.DataSource = Staff.ToList();
                cmbStaffAssigned.DisplayMember = "Name";
                cmbStaffAssigned.ValueMember = "id";
                cmbStaffAssigned.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        public void ClearFields()
        {
            try
            {
                if (chkAll.Checked == true)
                {
                    txtRoom.Clear();
                    txtGuest.Clear();
                    txtComplaints.Clear();
                    cmbAttendedBy.SelectedIndex = -1;
                    cmbComplaintType.SelectedIndex = -1;
                    cmbStaffAssigned.SelectedIndex = -1;
                    txtRemarks.Clear();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtRoom, "Enter Room");
                tooltip.SetToolTip(txtGuest, "Select Guest");
                tooltip.SetToolTip(txtComplaints, "Select Complaints");
                tooltip.SetToolTip(cmbAttendedBy, "Select Attended By");
                tooltip.SetToolTip(cmbComplaintType, "Select Complaint Type");
                tooltip.SetToolTip(cmbStaffAssigned, "Select Staff Assigned");
                tooltip.SetToolTip(txtRemarks, "Select Remarks");
                tooltip.SetToolTip(chkAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmComplaintRegisterReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateRoom();
                PopulateGuests();
                PopulateComplaints();
                PopulateRemarks();
                PopulateCombos();
                ShowToolTip();
                chkAll.Checked = true;
                ucReportCriteria.Initialise();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ClearFields();
                if (chkAll.Checked == true)
                {
                    errProvider.Clear();
                    txtRoom.Enabled = false;
                    txtGuest.Enabled = false;
                    txtComplaints.Enabled = false;
                    cmbAttendedBy.Enabled = false;
                    cmbComplaintType.Enabled = false;
                    cmbStaffAssigned.Enabled = false;
                    txtRemarks.Enabled = false;
                }
                else if (chkAll.Checked == false)
                {
                    errProvider.Clear();
                    txtRoom.Enabled = true;
                    txtGuest.Enabled = true;
                    txtComplaints.Enabled = true;
                    cmbAttendedBy.Enabled = true;
                    cmbComplaintType.Enabled = true;
                    cmbStaffAssigned.Enabled = true;
                    txtRemarks.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtRoom_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Rooms> Sd = dbh.Rooms.ToList();
                List<Rooms> SDp = Sd.Where(x => x.Name == txtRoom.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtRoom.Tag = SDp.Select(x => x.id).Single();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtComplaints_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<ComplaintRegister> cr = dbh.ComplaintRegisters.ToList();
                List<ComplaintRegister> crs = cr.Where(x => x.Complaint == txtComplaints.Text).ToList();
                if (crs.Count > 0)
                {
                    txtComplaints.Tag = crs.Select(x => x.id).Single();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtRemarks_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<ComplaintRegister> cr = dbh.ComplaintRegisters.ToList();
                List<ComplaintRegister> crs = cr.Where(x => x.Remarks == txtRemarks.Text).ToList();
                if (crs.Count > 0)
                {
                    txtRemarks.Tag = crs.Select(x => x.id).Single();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    txtGuest.Tag = frm.SelectedGuestID;
                    txtGuest.Text = frm.SelectedGuestName;
                    txtGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private bool frmComplaintRegisterReport_atValidate(object source)
        {
            try
            {
                if (chkAll.Checked == false && txtRoom.Text == "" && txtGuest.Text == "" && txtComplaints.Text == "" && cmbAttendedBy.Text == "" &&
                    cmbComplaintType.Text == "" && cmbStaffAssigned.Text == "" && txtRemarks.Text == "")
                {
                    errProvider.SetError(chkAll, MessageKeys.MsgAtleastOneOptionMustBeSelected); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmComplaintRegisterReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptComplaintRegisterReport.rdlc";
                if (GlobalFunctions.LanguageCulture == "ar-QA")
                {
                    string sReportCaption = "Booking" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                else
                {
                    string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Booking";
                    e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();

                sqlParameters.Add(new SqlParameter("RoomID", txtRoom.Text != "" ? txtRoom.Tag : 0));
                sqlParameters.Add(new SqlParameter("GuestID", txtGuest.Text.Trim() != "" ? txtGuest.Tag : 0));
                sqlParameters.Add(new SqlParameter("Complaint", txtComplaints.Text.Trim() != "" ? txtComplaints.Text.Trim() : ""));
                sqlParameters.Add(new SqlParameter("AttendedBy", cmbAttendedBy.Text.Trim() != "" ? cmbAttendedBy.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("Type", cmbComplaintType.Text.Trim() != "" ? cmbComplaintType.SelectedValue : ""));
                sqlParameters.Add(new SqlParameter("AssignedTo", cmbStaffAssigned.Text != "" ? cmbStaffAssigned.SelectedValue : ""));
                sqlParameters.Add(new SqlParameter("Remarks", txtRemarks.Text.Trim() != "" ? txtRemarks.Text.Trim() : ""));
                sqlParameters.Add(new SqlParameter("FromDate", ucReportCriteria.FromDate));
                sqlParameters.Add(new SqlParameter("ToDate", ucReportCriteria.ToDate));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                ds = sqlh.ExecuteProcedure("SPComplaintRegisterReport", sqlParameters);
                ds.Tables[0].TableName = "dsComplaintRegisterReport";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmComplaintRegisterReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptComplaintRegisterReport.rdlc";
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion
    }
}
