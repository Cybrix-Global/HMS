﻿namespace atACC.HTL.Reports
{
    partial class frmEnquiryReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEnquiryReport));
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.atPanel5 = new atACCFramework.UserControls.atPanel();
            this.rbtDeparture = new atACCFramework.UserControls.atRadioButton();
            this.rbtArrival = new atACCFramework.UserControls.atRadioButton();
            this.btnSeperator2 = new System.Windows.Forms.Button();
            this.rbtEnquiry = new atACCFramework.UserControls.atRadioButton();
            this.chkAll = new atACCFramework.UserControls.atCheckBox();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.cmbEmployee = new atACCFramework.UserControls.ComboBoxExt();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.cmbAgent = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.lblAgent = new atACCFramework.UserControls.atLabel();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.lblMobile = new atACCFramework.UserControls.atLabel();
            this.lblName = new System.Windows.Forms.Label();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbMobile = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEnquiryType = new atACCFramework.UserControls.atLabel();
            this.cmbEnquiryType = new atACCFramework.UserControls.ComboBoxExt();
            this.ucReportCriteria = new atACCFramework.UserControls.ucReportCriteria();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.atPanel5.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.atPanel5);
            this.pnlSearchBylist.Controls.Add(this.chkAll);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // atPanel5
            // 
            this.atPanel5.BackColor = System.Drawing.SystemColors.Window;
            this.atPanel5.Controls.Add(this.rbtDeparture);
            this.atPanel5.Controls.Add(this.rbtArrival);
            this.atPanel5.Controls.Add(this.btnSeperator2);
            this.atPanel5.Controls.Add(this.rbtEnquiry);
            resources.ApplyResources(this.atPanel5, "atPanel5");
            this.atPanel5.Name = "atPanel5";
            // 
            // rbtDeparture
            // 
            resources.ApplyResources(this.rbtDeparture, "rbtDeparture");
            this.rbtDeparture.Name = "rbtDeparture";
            this.rbtDeparture.UseVisualStyleBackColor = true;
            // 
            // rbtArrival
            // 
            resources.ApplyResources(this.rbtArrival, "rbtArrival");
            this.rbtArrival.Name = "rbtArrival";
            this.rbtArrival.UseVisualStyleBackColor = true;
            // 
            // btnSeperator2
            // 
            this.btnSeperator2.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator2, "btnSeperator2");
            this.btnSeperator2.Name = "btnSeperator2";
            this.btnSeperator2.UseVisualStyleBackColor = false;
            // 
            // rbtEnquiry
            // 
            resources.ApplyResources(this.rbtEnquiry, "rbtEnquiry");
            this.rbtEnquiry.Checked = true;
            this.rbtEnquiry.Name = "rbtEnquiry";
            this.rbtEnquiry.TabStop = true;
            this.rbtEnquiry.UseVisualStyleBackColor = true;
            // 
            // chkAll
            // 
            resources.ApplyResources(this.chkAll, "chkAll");
            this.chkAll.Name = "chkAll";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Controls.Add(this.ucReportCriteria);
            this.pnlMain.Name = "pnlMain";
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.cmbEmployee);
            this.grpCommon.Controls.Add(this.txtName);
            this.grpCommon.Controls.Add(this.cmbAgent);
            this.grpCommon.Controls.Add(this.lblRoomType);
            this.grpCommon.Controls.Add(this.lblAgent);
            this.grpCommon.Controls.Add(this.lblEmployee);
            this.grpCommon.Controls.Add(this.lblMobile);
            this.grpCommon.Controls.Add(this.lblName);
            this.grpCommon.Controls.Add(this.cmbRoomType);
            this.grpCommon.Controls.Add(this.cmbMobile);
            this.grpCommon.Controls.Add(this.lblEnquiryType);
            this.grpCommon.Controls.Add(this.cmbEnquiryType);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // cmbEmployee
            // 
            this.cmbEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployee.DropDownHeight = 300;
            this.cmbEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbEmployee, "cmbEmployee");
            this.cmbEmployee.FormattingEnabled = true;
            this.cmbEmployee.Name = "cmbEmployee";
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtName.Format = null;
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = false;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtName.TextChanged += new System.EventHandler(this.txtEnquiry_TextChanged);
            // 
            // cmbAgent
            // 
            this.cmbAgent.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAgent.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAgent.DropDownHeight = 300;
            this.cmbAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbAgent, "cmbAgent");
            this.cmbAgent.FormattingEnabled = true;
            this.cmbAgent.Name = "cmbAgent";
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // lblAgent
            // 
            resources.ApplyResources(this.lblAgent, "lblAgent");
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.RequiredField = false;
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // lblMobile
            // 
            resources.ApplyResources(this.lblMobile, "lblMobile");
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.RequiredField = false;
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.lblName.Name = "lblName";
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Name = "cmbRoomType";
            // 
            // cmbMobile
            // 
            this.cmbMobile.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbMobile.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMobile.DropDownHeight = 300;
            this.cmbMobile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbMobile, "cmbMobile");
            this.cmbMobile.FormattingEnabled = true;
            this.cmbMobile.Name = "cmbMobile";
            // 
            // lblEnquiryType
            // 
            resources.ApplyResources(this.lblEnquiryType, "lblEnquiryType");
            this.lblEnquiryType.Name = "lblEnquiryType";
            this.lblEnquiryType.RequiredField = false;
            // 
            // cmbEnquiryType
            // 
            this.cmbEnquiryType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEnquiryType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEnquiryType.DropDownHeight = 300;
            this.cmbEnquiryType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbEnquiryType, "cmbEnquiryType");
            this.cmbEnquiryType.FormattingEnabled = true;
            this.cmbEnquiryType.Name = "cmbEnquiryType";
            // 
            // ucReportCriteria
            // 
            resources.ApplyResources(this.ucReportCriteria, "ucReportCriteria");
            this.ucReportCriteria.BackColor = System.Drawing.Color.Transparent;
            this.ucReportCriteria.FromDate = new System.DateTime(2018, 12, 13, 9, 13, 3, 899);
            this.ucReportCriteria.Name = "ucReportCriteria";
            this.ucReportCriteria.ToDate = new System.DateTime(2018, 12, 13, 9, 13, 3, 899);
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmEnquiryReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlSearchBylist);
            this.Name = "frmEnquiryReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmEnquiryReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmEnquiryReport_atDesignClick);
            this.atValidate += new atACC.HTL.UI.ValidateEventHandler(this.frmEnquiryReport_atValidate);
            this.Load += new System.EventHandler(this.frmEnquiryReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.atPanel5.ResumeLayout(false);
            this.atPanel5.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atCheckBox chkAll;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblMobile;
        private atACCFramework.UserControls.ComboBoxExt cmbMobile;
        private atACCFramework.UserControls.ComboBoxExt cmbEnquiryType;
        private atACCFramework.UserControls.atLabel lblEnquiryType;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.ComboBoxExt cmbAgent;
        private atACCFramework.UserControls.atLabel lblAgent;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private System.Windows.Forms.Label lblName;
        private atACCFramework.UserControls.ucReportCriteria ucReportCriteria;
        private atACCFramework.UserControls.ComboBoxExt cmbEmployee;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.atPanel atPanel5;
        private atACCFramework.UserControls.atRadioButton rbtDeparture;
        private atACCFramework.UserControls.atRadioButton rbtArrival;
        private System.Windows.Forms.Button btnSeperator2;
        private atACCFramework.UserControls.atRadioButton rbtEnquiry;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.atGroupBox grpCommon;
    }
}