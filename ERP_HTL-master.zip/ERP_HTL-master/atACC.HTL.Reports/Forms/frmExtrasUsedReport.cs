﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACCFramework.Common;
using atACC.HTL.UI;
using atACC.HTL.Masters;
using atACCFramework.UserControls;
using atACCORM;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using atACC.HTL.ORM;

namespace atACC.HTL.Reports
{
    public partial class frmExtrasUsedReport : atReportFormBase
    {
        #region Constructor
        public frmExtrasUsedReport()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
        }
        #endregion

        #region Private Variables
        List<Guests> e_GuestList;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateExtras()
        {
            try
            {
                List<ExtraServices> m_Extras = dbh.ExtraServices.ToList();
                txtExtraOrAmenity.LoadSuggest(m_Extras, "Name");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void PopulateAmenity()
        {
            try
            {
                List<Amenities> m_Amenity = dbh.Amenities.ToList();
                txtExtraOrAmenity.LoadSuggest(m_Amenity, "Name");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void PopulateGuests()
        {
            try
            {
                e_GuestList = dbh.Guests
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRoom()
        {
            try
            {
                List<Rooms> m_Rooms = dbh.Rooms.ToList();
                txtRoom.LoadSuggest(m_Rooms, "Name");
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        public void PopulateCombos()
        {
            try
            {
                #region RoomType
                var RoomType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "" && x.IsHallType == false).ToList();
                cmbRoomType.DataSource = RoomType.ToList();
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtExtraOrAmenity, "Select Extra Or Amenity");
                tooltip.SetToolTip(txtGuest, "Select Guest");
                tooltip.SetToolTip(txtRoom, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(cmbRoomType, "Select Room Type");
                tooltip.SetToolTip(chkAll, MessageKeys.MsgEnableAllOptionToPreviewTheFullReportWithoutSorting);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void frmExtrasUsedReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateAmenity();
                PopulateGuests();
                PopulateRoom();
                PopulateCombos();
                ShowToolTip();
                ucReportCriteria.Initialise();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkAll.Checked == true)
                {
                    errProvider.Clear();
                    txtExtraOrAmenity.Enabled = false;
                    txtGuest.Enabled = false;
                    txtRoom.Enabled = false;
                    cmbRoomType.Enabled = false;
                }
                else if (chkAll.Checked == false)
                {
                    errProvider.Clear();
                    txtExtraOrAmenity.Enabled = true;
                    txtGuest.Enabled = true;
                    txtRoom.Enabled = true;
                    cmbRoomType.Enabled = true;
                }            
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtExtraOrAmenity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbtAmenity.Checked)
                {
                    List<Amenities> am = dbh.Amenities.ToList();
                    List<Amenities> ams = am.Where(x => x.Name == txtExtraOrAmenity.Text).ToList();
                    if (ams.Count > 0)
                    {
                        txtExtraOrAmenity.Tag = ams.Select(x => x.id).SingleOrDefault();
                    }
                }
                else
                {
                    List<ExtraServices> ex = dbh.ExtraServices.ToList();
                    List<ExtraServices> exs = ex.Where(x => x.Name == txtExtraOrAmenity.Text).ToList();
                    if (exs.Count > 0)
                    {
                        txtExtraOrAmenity.Tag = exs.Select(x => x.id).SingleOrDefault();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtGuest_TextChanged(object sender, EventArgs e)
        {
            //try
            //{
            //    List<Guests> gt = dbh.Guests.ToList();
            //    List<Guests> gts = gt.Where(x => x.Name == txtGuest.Text).ToList();
            //    if (gts.Count > 0)
            //    {
            //        txtGuest.Tag = gts.Select(x => x.id).SingleOrDefault();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ExceptionManager.Publish(ex);
            //}
        }
        private void txtRoom_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<Rooms> Sd = dbh.Rooms.ToList();
                List<Rooms> SDp = Sd.Where(x => x.Name == txtRoom.Text).ToList();
                if (SDp.Count > 0)
                {
                    txtRoom.Tag = SDp.Select(x => x.id).Single();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
            }
        }
        private void txtGuest_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Enter)
                {
                    return;
                }
                GuestSearch frm = new GuestSearch(e.KeyChar.ToString(), true);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    txtGuest.Tag = frm.SelectedGuestID;
                    txtGuest.Text = frm.SelectedGuestName;
                    txtGuest.SelectAll();
                    e.Handled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private bool frmExtrasUsedReport_atValidate(object source)
        {
            try
            {
                if (chkAll.Checked == false && txtRoom.Text.Trim() == "" && cmbRoomType.Text == "" && txtGuest.Text.Trim() == ""
                    && txtExtraOrAmenity.Text.Trim() == "")
                {
                    errProvider.SetError(chkAll, MessageKeys.MsgAtleastOneOptionMustBeSelected); return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private void frmExtrasUsedReport_atPreviewClick(object source, PreviewClickEventArgs e)
        {
            try
            {
                if (rbtExtra.Checked)
                {
                    e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptExtrasUsedReport.rdlc";
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        string sReportCaption = "Extras Used" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                    else
                    {
                        string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Extras Used";
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                }
                else if (rbtAmenity.Checked)
                {
                    e.ReportPath = Application.StartupPath + "\\HTL.Reports\\rptAmenitiesUsedReport.rdlc";
                    if (GlobalFunctions.LanguageCulture == "ar-QA")
                    {
                        string sReportCaption = "Amenities Used" + " " + MessageKeys.MsgOf + " " + MessageKeys.MsgReport;
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                    else
                    {
                        string sReportCaption = MessageKeys.MsgReport + " " + MessageKeys.MsgOf + " " + "Amenities Used";
                        e.reportParameters.Add(new atReportParameter("ReportCaption", sReportCaption));
                    }
                }
                DataSet ds = new DataSet();
                List<SqlParameter> sqlParameters = new List<SqlParameter>();
                sqlParameters.Add(new SqlParameter("ExtraOrAminityID", txtExtraOrAmenity.Text.Trim() != "" ? txtExtraOrAmenity.Tag : 0));
                sqlParameters.Add(new SqlParameter("GuestID", txtGuest.Text.Trim() != "" ? txtGuest.Tag : 0));
                sqlParameters.Add(new SqlParameter("RoomID", txtRoom.Text != "" ? txtRoom.Tag : 0));
                sqlParameters.Add(new SqlParameter("RoomTypeID", cmbRoomType.Text.Trim() != "" ? cmbRoomType.SelectedValue : 0));
                sqlParameters.Add(new SqlParameter("FromDate", ucReportCriteria.FromDate));
                sqlParameters.Add(new SqlParameter("ToDate", ucReportCriteria.ToDate));
                atACC.HTL.ORM.SqlHelper sqlh = new atACC.HTL.ORM.SqlHelper();
                if (rbtExtra.Checked)
                {
                    ds = sqlh.ExecuteProcedure("SPExtrasUsedReport", sqlParameters);
                    ds.Tables[0].TableName = "dsExtrasUsedReport";
                }
                else if (rbtAmenity.Checked)
                {
                    ds = sqlh.ExecuteProcedure("SPAmenitiesUsedReport", sqlParameters);
                    ds.Tables[0].TableName = "dsAmenitiesUsedReport";
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    e.DataSource = ds;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Preview);
                return;
            }
        }
        private void frmExtrasUsedReport_atDesignClick(object source, DesignClickEventArgs e)
        {
            try
            {
                if (rbtExtra.Checked)
                {
                    e.ReportPath = Application.StartupPath + "\\HTL.Masters.Reports\\rptExtrasUsedReport.rdlc";
                }
                else if (rbtAmenity.Checked)
                {
                    e.ReportPath = Application.StartupPath + "\\HTL.Masters.Reports\\rptAmenitiesUsedReport.rdlc";
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.DesignClick);
                return;
            }
        }
        #endregion
    }
}
