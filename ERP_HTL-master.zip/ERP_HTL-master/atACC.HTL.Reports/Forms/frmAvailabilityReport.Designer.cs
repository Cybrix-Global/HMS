﻿namespace atACC.HTL.Reports
{
    partial class frmAvailabilityReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAvailabilityReport));
            this.atPanel1 = new atACCFramework.UserControls.atPanel();
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.atPanel5 = new atACCFramework.UserControls.atPanel();
            this.rbtHall = new atACCFramework.UserControls.atRadioButton();
            this.btnSeperator2 = new System.Windows.Forms.Button();
            this.rbtRoom = new atACCFramework.UserControls.atRadioButton();
            this.rbtType = new atACCFramework.UserControls.atRadioButton();
            this.radFloor = new atACCFramework.UserControls.atRadioButton();
            this.radBlock = new atACCFramework.UserControls.atRadioButton();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.rbtAll = new atACCFramework.UserControls.atRadioButton();
            this.rbtRoomOrHallWise = new atACCFramework.UserControls.atRadioButton();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.grpAsOnDate = new atACCFramework.UserControls.atGroupBox();
            this.dtpAsOnDate = new atACCFramework.UserControls.atDateTimePicker();
            this.lblAsOn = new atACCFramework.UserControls.atLabel();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.cmbBlock = new atACCFramework.UserControls.ComboBoxExt();
            this.txtRoomOrHall = new atACCFramework.UserControls.TextBoxExt();
            this.lblRoomOrHall = new System.Windows.Forms.Label();
            this.lblBlock = new atACCFramework.UserControls.atLabel();
            this.lblFloor = new atACCFramework.UserControls.atLabel();
            this.cmbFloor = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblType = new atACCFramework.UserControls.atLabel();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.atPanel1.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.atPanel5.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpAsOnDate.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            this.errProvider.SetError(this.pnlBottom, resources.GetString("pnlBottom.Error"));
            this.errProvider.SetIconAlignment(this.pnlBottom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlBottom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlBottom, ((int)(resources.GetObject("pnlBottom.IconPadding"))));
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.pnlHeader2.Controls.Add(this.lblHead);
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // atPanel1
            // 
            resources.ApplyResources(this.atPanel1, "atPanel1");
            this.atPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.atPanel1.Controls.Add(this.pnlSearchBylist);
            this.atPanel1.Controls.Add(this.pnlMain);
            this.errProvider.SetError(this.atPanel1, resources.GetString("atPanel1.Error"));
            this.errProvider.SetIconAlignment(this.atPanel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atPanel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atPanel1, ((int)(resources.GetObject("atPanel1.IconPadding"))));
            this.atPanel1.Name = "atPanel1";
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.atPanel5);
            this.pnlSearchBylist.Controls.Add(this.rbtType);
            this.pnlSearchBylist.Controls.Add(this.radFloor);
            this.pnlSearchBylist.Controls.Add(this.radBlock);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.rbtAll);
            this.pnlSearchBylist.Controls.Add(this.rbtRoomOrHallWise);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.errProvider.SetError(this.pnlSearchBylist, resources.GetString("pnlSearchBylist.Error"));
            this.errProvider.SetIconAlignment(this.pnlSearchBylist, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlSearchBylist.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlSearchBylist, ((int)(resources.GetObject("pnlSearchBylist.IconPadding"))));
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // atPanel5
            // 
            resources.ApplyResources(this.atPanel5, "atPanel5");
            this.atPanel5.BackColor = System.Drawing.SystemColors.Window;
            this.atPanel5.Controls.Add(this.rbtHall);
            this.atPanel5.Controls.Add(this.btnSeperator2);
            this.atPanel5.Controls.Add(this.rbtRoom);
            this.errProvider.SetError(this.atPanel5, resources.GetString("atPanel5.Error"));
            this.errProvider.SetIconAlignment(this.atPanel5, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atPanel5.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atPanel5, ((int)(resources.GetObject("atPanel5.IconPadding"))));
            this.atPanel5.Name = "atPanel5";
            // 
            // rbtHall
            // 
            resources.ApplyResources(this.rbtHall, "rbtHall");
            this.errProvider.SetError(this.rbtHall, resources.GetString("rbtHall.Error"));
            this.errProvider.SetIconAlignment(this.rbtHall, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtHall.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtHall, ((int)(resources.GetObject("rbtHall.IconPadding"))));
            this.rbtHall.Name = "rbtHall";
            this.rbtHall.UseVisualStyleBackColor = true;
            // 
            // btnSeperator2
            // 
            resources.ApplyResources(this.btnSeperator2, "btnSeperator2");
            this.btnSeperator2.BackColor = System.Drawing.Color.LightGray;
            this.errProvider.SetError(this.btnSeperator2, resources.GetString("btnSeperator2.Error"));
            this.btnSeperator2.FlatAppearance.BorderSize = 0;
            this.errProvider.SetIconAlignment(this.btnSeperator2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnSeperator2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnSeperator2, ((int)(resources.GetObject("btnSeperator2.IconPadding"))));
            this.btnSeperator2.Name = "btnSeperator2";
            this.btnSeperator2.UseVisualStyleBackColor = false;
            // 
            // rbtRoom
            // 
            resources.ApplyResources(this.rbtRoom, "rbtRoom");
            this.rbtRoom.Checked = true;
            this.errProvider.SetError(this.rbtRoom, resources.GetString("rbtRoom.Error"));
            this.errProvider.SetIconAlignment(this.rbtRoom, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtRoom.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtRoom, ((int)(resources.GetObject("rbtRoom.IconPadding"))));
            this.rbtRoom.Name = "rbtRoom";
            this.rbtRoom.TabStop = true;
            this.rbtRoom.UseVisualStyleBackColor = true;
            this.rbtRoom.CheckedChanged += new System.EventHandler(this.rbtRoom_CheckedChanged);
            // 
            // rbtType
            // 
            resources.ApplyResources(this.rbtType, "rbtType");
            this.errProvider.SetError(this.rbtType, resources.GetString("rbtType.Error"));
            this.errProvider.SetIconAlignment(this.rbtType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtType, ((int)(resources.GetObject("rbtType.IconPadding"))));
            this.rbtType.Name = "rbtType";
            this.rbtType.UseVisualStyleBackColor = true;
            this.rbtType.CheckedChanged += new System.EventHandler(this.rbtType_CheckedChanged);
            // 
            // radFloor
            // 
            resources.ApplyResources(this.radFloor, "radFloor");
            this.errProvider.SetError(this.radFloor, resources.GetString("radFloor.Error"));
            this.errProvider.SetIconAlignment(this.radFloor, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("radFloor.IconAlignment"))));
            this.errProvider.SetIconPadding(this.radFloor, ((int)(resources.GetObject("radFloor.IconPadding"))));
            this.radFloor.Name = "radFloor";
            this.radFloor.UseVisualStyleBackColor = true;
            this.radFloor.CheckedChanged += new System.EventHandler(this.radFloor_CheckedChanged);
            // 
            // radBlock
            // 
            resources.ApplyResources(this.radBlock, "radBlock");
            this.errProvider.SetError(this.radBlock, resources.GetString("radBlock.Error"));
            this.errProvider.SetIconAlignment(this.radBlock, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("radBlock.IconAlignment"))));
            this.errProvider.SetIconPadding(this.radBlock, ((int)(resources.GetObject("radBlock.IconPadding"))));
            this.radBlock.Name = "radBlock";
            this.radBlock.UseVisualStyleBackColor = true;
            this.radBlock.CheckedChanged += new System.EventHandler(this.radBlock_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.errProvider.SetError(this.btnSeperator0, resources.GetString("btnSeperator0.Error"));
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.errProvider.SetIconAlignment(this.btnSeperator0, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnSeperator0.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnSeperator0, ((int)(resources.GetObject("btnSeperator0.IconPadding"))));
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // rbtAll
            // 
            resources.ApplyResources(this.rbtAll, "rbtAll");
            this.rbtAll.Checked = true;
            this.errProvider.SetError(this.rbtAll, resources.GetString("rbtAll.Error"));
            this.errProvider.SetIconAlignment(this.rbtAll, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtAll.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtAll, ((int)(resources.GetObject("rbtAll.IconPadding"))));
            this.rbtAll.Name = "rbtAll";
            this.rbtAll.TabStop = true;
            this.rbtAll.UseVisualStyleBackColor = true;
            this.rbtAll.CheckedChanged += new System.EventHandler(this.rbtAll_CheckedChanged);
            // 
            // rbtRoomOrHallWise
            // 
            resources.ApplyResources(this.rbtRoomOrHallWise, "rbtRoomOrHallWise");
            this.errProvider.SetError(this.rbtRoomOrHallWise, resources.GetString("rbtRoomOrHallWise.Error"));
            this.errProvider.SetIconAlignment(this.rbtRoomOrHallWise, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtRoomOrHallWise.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtRoomOrHallWise, ((int)(resources.GetObject("rbtRoomOrHallWise.IconPadding"))));
            this.rbtRoomOrHallWise.Name = "rbtRoomOrHallWise";
            this.rbtRoomOrHallWise.UseVisualStyleBackColor = true;
            this.rbtRoomOrHallWise.CheckedChanged += new System.EventHandler(this.rbtRoomOrHallWise_CheckedChanged);
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.errProvider.SetError(this.atLabel3, resources.GetString("atLabel3.Error"));
            this.errProvider.SetIconAlignment(this.atLabel3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("atLabel3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.atLabel3, ((int)(resources.GetObject("atLabel3.IconPadding"))));
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.errProvider.SetError(this.btnSeperator4, resources.GetString("btnSeperator4.Error"));
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            this.errProvider.SetIconAlignment(this.btnSeperator4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnSeperator4.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnSeperator4, ((int)(resources.GetObject("btnSeperator4.IconPadding"))));
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.grpAsOnDate);
            this.pnlMain.Controls.Add(this.grpCommon);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // grpAsOnDate
            // 
            resources.ApplyResources(this.grpAsOnDate, "grpAsOnDate");
            this.grpAsOnDate.BackColor = System.Drawing.Color.Transparent;
            this.grpAsOnDate.Controls.Add(this.dtpAsOnDate);
            this.grpAsOnDate.Controls.Add(this.lblAsOn);
            this.errProvider.SetError(this.grpAsOnDate, resources.GetString("grpAsOnDate.Error"));
            this.errProvider.SetIconAlignment(this.grpAsOnDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("grpAsOnDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.grpAsOnDate, ((int)(resources.GetObject("grpAsOnDate.IconPadding"))));
            this.grpAsOnDate.Name = "grpAsOnDate";
            this.grpAsOnDate.TabStop = false;
            // 
            // dtpAsOnDate
            // 
            resources.ApplyResources(this.dtpAsOnDate, "dtpAsOnDate");
            this.dtpAsOnDate.BackColor = System.Drawing.Color.Transparent;
            this.dtpAsOnDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpAsOnDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpAsOnDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtpAsOnDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtpAsOnDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtpAsOnDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtpAsOnDate.Checked = true;
            this.dtpAsOnDate.DisbaleDateTimeFormat = true;
            this.dtpAsOnDate.DisbaleShortDateTimeFormat = false;
            this.errProvider.SetError(this.dtpAsOnDate, resources.GetString("dtpAsOnDate.Error"));
            this.dtpAsOnDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.errProvider.SetIconAlignment(this.dtpAsOnDate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("dtpAsOnDate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.dtpAsOnDate, ((int)(resources.GetObject("dtpAsOnDate.IconPadding"))));
            this.dtpAsOnDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpAsOnDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpAsOnDate.Name = "dtpAsOnDate";
            this.dtpAsOnDate.Value = new System.DateTime(2019, 5, 27, 12, 14, 23, 41);
            // 
            // lblAsOn
            // 
            resources.ApplyResources(this.lblAsOn, "lblAsOn");
            this.errProvider.SetError(this.lblAsOn, resources.GetString("lblAsOn.Error"));
            this.errProvider.SetIconAlignment(this.lblAsOn, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAsOn.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAsOn, ((int)(resources.GetObject("lblAsOn.IconPadding"))));
            this.lblAsOn.Name = "lblAsOn";
            this.lblAsOn.RequiredField = false;
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.cmbBlock);
            this.grpCommon.Controls.Add(this.txtRoomOrHall);
            this.grpCommon.Controls.Add(this.lblRoomOrHall);
            this.grpCommon.Controls.Add(this.lblBlock);
            this.grpCommon.Controls.Add(this.lblFloor);
            this.grpCommon.Controls.Add(this.cmbFloor);
            this.grpCommon.Controls.Add(this.cmbType);
            this.grpCommon.Controls.Add(this.lblType);
            this.errProvider.SetError(this.grpCommon, resources.GetString("grpCommon.Error"));
            this.errProvider.SetIconAlignment(this.grpCommon, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("grpCommon.IconAlignment"))));
            this.errProvider.SetIconPadding(this.grpCommon, ((int)(resources.GetObject("grpCommon.IconPadding"))));
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // cmbBlock
            // 
            resources.ApplyResources(this.cmbBlock, "cmbBlock");
            this.cmbBlock.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBlock.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBlock.DropDownHeight = 300;
            this.cmbBlock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbBlock, resources.GetString("cmbBlock.Error"));
            this.cmbBlock.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbBlock, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbBlock.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbBlock, ((int)(resources.GetObject("cmbBlock.IconPadding"))));
            this.cmbBlock.Name = "cmbBlock";
            // 
            // txtRoomOrHall
            // 
            resources.ApplyResources(this.txtRoomOrHall, "txtRoomOrHall");
            this.txtRoomOrHall.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoomOrHall.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtRoomOrHall, resources.GetString("txtRoomOrHall.Error"));
            this.txtRoomOrHall.Format = null;
            this.errProvider.SetIconAlignment(this.txtRoomOrHall, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtRoomOrHall.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtRoomOrHall, ((int)(resources.GetObject("txtRoomOrHall.IconPadding"))));
            this.txtRoomOrHall.isAllowNegative = false;
            this.txtRoomOrHall.isAllowSpecialChar = false;
            this.txtRoomOrHall.isNumbersOnly = false;
            this.txtRoomOrHall.isNumeric = false;
            this.txtRoomOrHall.isTouchable = false;
            this.txtRoomOrHall.Name = "txtRoomOrHall";
            this.txtRoomOrHall.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoomOrHall.TextChanged += new System.EventHandler(this.txtRoomOrHall_TextChanged);
            // 
            // lblRoomOrHall
            // 
            resources.ApplyResources(this.lblRoomOrHall, "lblRoomOrHall");
            this.errProvider.SetError(this.lblRoomOrHall, resources.GetString("lblRoomOrHall.Error"));
            this.errProvider.SetIconAlignment(this.lblRoomOrHall, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoomOrHall.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblRoomOrHall, ((int)(resources.GetObject("lblRoomOrHall.IconPadding"))));
            this.lblRoomOrHall.Name = "lblRoomOrHall";
            // 
            // lblBlock
            // 
            resources.ApplyResources(this.lblBlock, "lblBlock");
            this.errProvider.SetError(this.lblBlock, resources.GetString("lblBlock.Error"));
            this.errProvider.SetIconAlignment(this.lblBlock, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblBlock.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblBlock, ((int)(resources.GetObject("lblBlock.IconPadding"))));
            this.lblBlock.Name = "lblBlock";
            this.lblBlock.RequiredField = false;
            // 
            // lblFloor
            // 
            resources.ApplyResources(this.lblFloor, "lblFloor");
            this.errProvider.SetError(this.lblFloor, resources.GetString("lblFloor.Error"));
            this.errProvider.SetIconAlignment(this.lblFloor, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblFloor.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblFloor, ((int)(resources.GetObject("lblFloor.IconPadding"))));
            this.lblFloor.Name = "lblFloor";
            this.lblFloor.RequiredField = false;
            // 
            // cmbFloor
            // 
            resources.ApplyResources(this.cmbFloor, "cmbFloor");
            this.cmbFloor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbFloor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbFloor.DropDownHeight = 300;
            this.cmbFloor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbFloor, resources.GetString("cmbFloor.Error"));
            this.cmbFloor.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbFloor, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbFloor.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbFloor, ((int)(resources.GetObject("cmbFloor.IconPadding"))));
            this.cmbFloor.Name = "cmbFloor";
            // 
            // cmbType
            // 
            resources.ApplyResources(this.cmbType, "cmbType");
            this.cmbType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbType.DropDownHeight = 300;
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbType, resources.GetString("cmbType.Error"));
            this.cmbType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbType, ((int)(resources.GetObject("cmbType.IconPadding"))));
            this.cmbType.Name = "cmbType";
            // 
            // lblType
            // 
            resources.ApplyResources(this.lblType, "lblType");
            this.errProvider.SetError(this.lblType, resources.GetString("lblType.Error"));
            this.errProvider.SetIconAlignment(this.lblType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblType, ((int)(resources.GetObject("lblType.IconPadding"))));
            this.lblType.Name = "lblType";
            this.lblType.RequiredField = false;
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.errProvider.SetError(this.lblHead, resources.GetString("lblHead.Error"));
            this.errProvider.SetIconAlignment(this.lblHead, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblHead.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblHead, ((int)(resources.GetObject("lblHead.IconPadding"))));
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmAvailabilityReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.atPanel1);
            this.Name = "frmAvailabilityReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmAvailabilityReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmAvailabilityReport_atDesignClick);
            this.atValidate += new atACC.HTL.UI.ValidateEventHandler(this.frmAvailabilityReport_atValidate);
            this.Load += new System.EventHandler(this.frmAvailabilityReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.atPanel1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.atPanel1.ResumeLayout(false);
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.atPanel5.ResumeLayout(false);
            this.atPanel5.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpAsOnDate.ResumeLayout(false);
            this.grpAsOnDate.PerformLayout();
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel atPanel1;
        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atRadioButton rbtType;
        private atACCFramework.UserControls.atRadioButton radFloor;
        private atACCFramework.UserControls.atRadioButton radBlock;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atRadioButton rbtAll;
        private atACCFramework.UserControls.atRadioButton rbtRoomOrHallWise;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atGroupBox grpAsOnDate;
        private atACCFramework.UserControls.atDateTimePicker dtpAsOnDate;
        private atACCFramework.UserControls.atLabel lblAsOn;
        private atACCFramework.UserControls.ComboBoxExt cmbBlock;
        private atACCFramework.UserControls.atLabel lblBlock;
        private atACCFramework.UserControls.ComboBoxExt cmbType;
        private atACCFramework.UserControls.atLabel lblType;
        private atACCFramework.UserControls.ComboBoxExt cmbFloor;
        private atACCFramework.UserControls.atLabel lblFloor;
        private atACCFramework.UserControls.TextBoxExt txtRoomOrHall;
        private System.Windows.Forms.Label lblRoomOrHall;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.atPanel atPanel5;
        private atACCFramework.UserControls.atRadioButton rbtHall;
        private System.Windows.Forms.Button btnSeperator2;
        private atACCFramework.UserControls.atRadioButton rbtRoom;
        private atACCFramework.UserControls.atGroupBox grpCommon;
    }
}