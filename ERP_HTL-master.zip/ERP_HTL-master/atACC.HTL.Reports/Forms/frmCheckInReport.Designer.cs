﻿namespace atACC.HTL.Reports
{
    partial class frmCheckInReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCheckInReport));
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.chkAll = new atACCFramework.UserControls.atCheckBox();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.ucReportCriteria = new atACCFramework.UserControls.ucReportCriteria();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.lblSource = new atACCFramework.UserControls.atLabel();
            this.txtRoom = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.cmbSource = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.cmbGuestType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoom = new System.Windows.Forms.Label();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGuestType = new atACCFramework.UserControls.atLabel();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.chkAll);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // chkAll
            // 
            resources.ApplyResources(this.chkAll, "chkAll");
            this.chkAll.Name = "chkAll";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.ucReportCriteria);
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Name = "pnlMain";
            // 
            // ucReportCriteria
            // 
            this.ucReportCriteria.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.ucReportCriteria, "ucReportCriteria");
            this.ucReportCriteria.FromDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 428);
            this.ucReportCriteria.Name = "ucReportCriteria";
            this.ucReportCriteria.ToDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 430);
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.txtGuest);
            this.grpCommon.Controls.Add(this.lblSource);
            this.grpCommon.Controls.Add(this.txtRoom);
            this.grpCommon.Controls.Add(this.lblGuest);
            this.grpCommon.Controls.Add(this.cmbSource);
            this.grpCommon.Controls.Add(this.lblRoomType);
            this.grpCommon.Controls.Add(this.cmbGuestType);
            this.grpCommon.Controls.Add(this.lblRoom);
            this.grpCommon.Controls.Add(this.cmbRoomType);
            this.grpCommon.Controls.Add(this.lblGuestType);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // txtGuest
            // 
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGuest.Format = null;
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGuest_KeyPress);
            // 
            // lblSource
            // 
            resources.ApplyResources(this.lblSource, "lblSource");
            this.lblSource.Name = "lblSource";
            this.lblSource.RequiredField = false;
            // 
            // txtRoom
            // 
            resources.ApplyResources(this.txtRoom, "txtRoom");
            this.txtRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoom.Format = null;
            this.txtRoom.isAllowNegative = false;
            this.txtRoom.isAllowSpecialChar = false;
            this.txtRoom.isNumbersOnly = false;
            this.txtRoom.isNumeric = false;
            this.txtRoom.isTouchable = false;
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoom.TextChanged += new System.EventHandler(this.txtRoom_TextChanged);
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // cmbSource
            // 
            this.cmbSource.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSource.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSource.DropDownHeight = 300;
            this.cmbSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbSource, "cmbSource");
            this.cmbSource.FormattingEnabled = true;
            this.cmbSource.Name = "cmbSource";
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // cmbGuestType
            // 
            this.cmbGuestType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuestType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuestType.DropDownHeight = 300;
            this.cmbGuestType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbGuestType, "cmbGuestType");
            this.cmbGuestType.FormattingEnabled = true;
            this.cmbGuestType.Name = "cmbGuestType";
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Name = "cmbRoomType";
            // 
            // lblGuestType
            // 
            resources.ApplyResources(this.lblGuestType, "lblGuestType");
            this.lblGuestType.Name = "lblGuestType";
            this.lblGuestType.RequiredField = false;
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmCheckInReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlSearchBylist);
            this.Name = "frmCheckInReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmCheckInReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmCheckInReport_atDesignClick);
            this.atValidate += new atACC.HTL.UI.ValidateEventHandler(this.frmCheckInReport_atValidate);
            this.Load += new System.EventHandler(this.frmCheckInReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.ComboBoxExt cmbGuestType;
        private atACCFramework.UserControls.atLabel lblGuestType;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtRoom;
        private System.Windows.Forms.Label lblRoom;
        private atACCFramework.UserControls.ucReportCriteria ucrDatePicker;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.atCheckBox chkAll;
        private atACCFramework.UserControls.atLabel lblSource;
        private atACCFramework.UserControls.ComboBoxExt cmbSource;
        private atACCFramework.UserControls.atGroupBox grpCommon;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private atACCFramework.UserControls.ucReportCriteria ucReportCriteria;
    }
}