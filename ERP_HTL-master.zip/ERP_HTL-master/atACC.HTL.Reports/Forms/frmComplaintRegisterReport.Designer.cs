﻿namespace atACC.HTL.Reports
{
    partial class frmComplaintRegisterReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmComplaintRegisterReport));
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.ucReportCriteria = new atACCFramework.UserControls.ucReportCriteria();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.txtGuest = new atACCFramework.UserControls.TextBoxExt();
            this.lblRemarks = new atACCFramework.UserControls.atLabel();
            this.txtRoom = new atACCFramework.UserControls.TextBoxExt();
            this.lblEmployee = new atACCFramework.UserControls.atLabel();
            this.atLabel4 = new atACCFramework.UserControls.atLabel();
            this.cmbAttendedBy = new atACCFramework.UserControls.ComboBoxExt();
            this.atLabel2 = new atACCFramework.UserControls.atLabel();
            this.txtComplaints = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.lblComplaints = new atACCFramework.UserControls.atLabel();
            this.cmbComplaintType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoom = new System.Windows.Forms.Label();
            this.txtRemarks = new atACCFramework.UserControls.TextBoxExt();
            this.cmbStaffAssigned = new atACCFramework.UserControls.ComboBoxExt();
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.chkAll = new atACCFramework.UserControls.atCheckBox();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.ucReportCriteria);
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Name = "pnlMain";
            // 
            // ucReportCriteria
            // 
            this.ucReportCriteria.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.ucReportCriteria, "ucReportCriteria");
            this.ucReportCriteria.FromDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 428);
            this.ucReportCriteria.Name = "ucReportCriteria";
            this.ucReportCriteria.ToDate = new System.DateTime(2019, 9, 30, 10, 13, 33, 430);
            // 
            // grpCommon
            // 
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.txtGuest);
            this.grpCommon.Controls.Add(this.lblRemarks);
            this.grpCommon.Controls.Add(this.txtRoom);
            this.grpCommon.Controls.Add(this.lblEmployee);
            this.grpCommon.Controls.Add(this.atLabel4);
            this.grpCommon.Controls.Add(this.cmbAttendedBy);
            this.grpCommon.Controls.Add(this.atLabel2);
            this.grpCommon.Controls.Add(this.txtComplaints);
            this.grpCommon.Controls.Add(this.lblGuest);
            this.grpCommon.Controls.Add(this.lblComplaints);
            this.grpCommon.Controls.Add(this.cmbComplaintType);
            this.grpCommon.Controls.Add(this.lblRoom);
            this.grpCommon.Controls.Add(this.txtRemarks);
            this.grpCommon.Controls.Add(this.cmbStaffAssigned);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // txtGuest
            // 
            resources.ApplyResources(this.txtGuest, "txtGuest");
            this.txtGuest.BackColor = System.Drawing.SystemColors.Window;
            this.txtGuest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGuest.Format = null;
            this.txtGuest.isAllowNegative = false;
            this.txtGuest.isAllowSpecialChar = false;
            this.txtGuest.isNumbersOnly = false;
            this.txtGuest.isNumeric = false;
            this.txtGuest.isTouchable = false;
            this.txtGuest.Name = "txtGuest";
            this.txtGuest.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGuest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGuest_KeyPress);
            // 
            // lblRemarks
            // 
            resources.ApplyResources(this.lblRemarks, "lblRemarks");
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.RequiredField = false;
            // 
            // txtRoom
            // 
            resources.ApplyResources(this.txtRoom, "txtRoom");
            this.txtRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoom.Format = null;
            this.txtRoom.isAllowNegative = false;
            this.txtRoom.isAllowSpecialChar = false;
            this.txtRoom.isNumbersOnly = false;
            this.txtRoom.isNumeric = false;
            this.txtRoom.isTouchable = false;
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoom.TextChanged += new System.EventHandler(this.txtRoom_TextChanged);
            // 
            // lblEmployee
            // 
            resources.ApplyResources(this.lblEmployee, "lblEmployee");
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.RequiredField = false;
            // 
            // atLabel4
            // 
            resources.ApplyResources(this.atLabel4, "atLabel4");
            this.atLabel4.Name = "atLabel4";
            this.atLabel4.RequiredField = false;
            // 
            // cmbAttendedBy
            // 
            this.cmbAttendedBy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAttendedBy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAttendedBy.DropDownHeight = 300;
            this.cmbAttendedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbAttendedBy, "cmbAttendedBy");
            this.cmbAttendedBy.FormattingEnabled = true;
            this.cmbAttendedBy.Name = "cmbAttendedBy";
            // 
            // atLabel2
            // 
            resources.ApplyResources(this.atLabel2, "atLabel2");
            this.atLabel2.Name = "atLabel2";
            this.atLabel2.RequiredField = false;
            // 
            // txtComplaints
            // 
            resources.ApplyResources(this.txtComplaints, "txtComplaints");
            this.txtComplaints.BackColor = System.Drawing.SystemColors.Window;
            this.txtComplaints.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtComplaints.Format = null;
            this.txtComplaints.isAllowNegative = false;
            this.txtComplaints.isAllowSpecialChar = false;
            this.txtComplaints.isNumbersOnly = false;
            this.txtComplaints.isNumeric = false;
            this.txtComplaints.isTouchable = false;
            this.txtComplaints.Name = "txtComplaints";
            this.txtComplaints.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtComplaints.TextChanged += new System.EventHandler(this.txtComplaints_TextChanged);
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // lblComplaints
            // 
            resources.ApplyResources(this.lblComplaints, "lblComplaints");
            this.lblComplaints.Name = "lblComplaints";
            this.lblComplaints.RequiredField = false;
            // 
            // cmbComplaintType
            // 
            this.cmbComplaintType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbComplaintType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbComplaintType.DropDownHeight = 300;
            this.cmbComplaintType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbComplaintType, "cmbComplaintType");
            this.cmbComplaintType.FormattingEnabled = true;
            this.cmbComplaintType.Name = "cmbComplaintType";
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            // 
            // txtRemarks
            // 
            resources.ApplyResources(this.txtRemarks, "txtRemarks");
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRemarks.Format = null;
            this.txtRemarks.isAllowNegative = false;
            this.txtRemarks.isAllowSpecialChar = false;
            this.txtRemarks.isNumbersOnly = false;
            this.txtRemarks.isNumeric = false;
            this.txtRemarks.isTouchable = false;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRemarks.TextChanged += new System.EventHandler(this.txtRemarks_TextChanged);
            // 
            // cmbStaffAssigned
            // 
            this.cmbStaffAssigned.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbStaffAssigned.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbStaffAssigned.DropDownHeight = 300;
            this.cmbStaffAssigned.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbStaffAssigned, "cmbStaffAssigned");
            this.cmbStaffAssigned.FormattingEnabled = true;
            this.cmbStaffAssigned.Name = "cmbStaffAssigned";
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.chkAll);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // chkAll
            // 
            resources.ApplyResources(this.chkAll, "chkAll");
            this.chkAll.Name = "chkAll";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // frmComplaintRegisterReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlSearchBylist);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmComplaintRegisterReport";
            this.atPreviewClick += new atACC.HTL.UI.PreviewClickEventHandler(this.frmComplaintRegisterReport_atPreviewClick);
            this.atDesignClick += new atACC.HTL.UI.DesignClickEventHandler(this.frmComplaintRegisterReport_atDesignClick);
            this.atValidate += new atACC.HTL.UI.ValidateEventHandler(this.frmComplaintRegisterReport_atValidate);
            this.Load += new System.EventHandler(this.frmComplaintRegisterReport_Load);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.ComboBoxExt cmbAttendedBy;
        private atACCFramework.UserControls.atLabel lblEmployee;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.TextBoxExt txtRoom;
        private System.Windows.Forms.Label lblRoom;
        private atACCFramework.UserControls.ucReportCriteria ucrDatePicker;
        private atACCFramework.UserControls.TextBoxExt txtRemarks;
        private atACCFramework.UserControls.ComboBoxExt cmbStaffAssigned;
        private atACCFramework.UserControls.ComboBoxExt cmbComplaintType;
        private atACCFramework.UserControls.TextBoxExt txtComplaints;
        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atCheckBox chkAll;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atLabel lblRemarks;
        private atACCFramework.UserControls.atLabel atLabel4;
        private atACCFramework.UserControls.atLabel atLabel2;
        private atACCFramework.UserControls.atLabel lblComplaints;
        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.atGroupBox grpCommon;
        private atACCFramework.UserControls.TextBoxExt txtGuest;
        private atACCFramework.UserControls.ucReportCriteria ucReportCriteria;
    }
}