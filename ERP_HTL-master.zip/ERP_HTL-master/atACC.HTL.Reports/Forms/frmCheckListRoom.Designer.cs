﻿namespace atACC.HTL
{
    partial class frmCheckListRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.txtRoom = new atACCFramework.UserControls.TextBoxExt();
            this.lblRoom = new System.Windows.Forms.Label();
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.chkAll = new atACCFramework.UserControls.atCheckBox();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.chkActive = new atACCFramework.UserControls.atCheckBox();
            this.lblHead = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            this.pnlBottom.Location = new System.Drawing.Point(2, 157);
            this.pnlBottom.Size = new System.Drawing.Size(638, 43);
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.cmbRoomType);
            this.pnlMain.Controls.Add(this.lblRoomType);
            this.pnlMain.Controls.Add(this.txtRoom);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.pnlMain.Location = new System.Drawing.Point(153, 38);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(486, 118);
            this.pnlMain.TabIndex = 23;
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoomType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbRoomType.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.IntegralHeight = false;
            this.cmbRoomType.Location = new System.Drawing.Point(107, 54);
            this.cmbRoomType.Name = "cmbRoomType";
            this.cmbRoomType.Size = new System.Drawing.Size(352, 26);
            this.cmbRoomType.TabIndex = 23;
            // 
            // lblRoomType
            // 
            this.lblRoomType.AutoSize = true;
            this.lblRoomType.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblRoomType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblRoomType.Location = new System.Drawing.Point(19, 58);
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            this.lblRoomType.Size = new System.Drawing.Size(82, 18);
            this.lblRoomType.TabIndex = 27;
            this.lblRoomType.Text = "Room Type :";
            // 
            // txtRoom
            // 
            this.txtRoom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoom.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.txtRoom.Format = null;
            this.txtRoom.isAllowNegative = false;
            this.txtRoom.isAllowSpecialChar = false;
            this.txtRoom.isNumbersOnly = false;
            this.txtRoom.isNumeric = false;
            this.txtRoom.isTouchable = false;
            this.txtRoom.Location = new System.Drawing.Point(107, 26);
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Size = new System.Drawing.Size(352, 18);
            this.txtRoom.TabIndex = 20;
            this.txtRoom.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoom.WaterMark = null;
            // 
            // lblRoom
            // 
            this.lblRoom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRoom.AutoSize = true;
            this.lblRoom.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblRoom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblRoom.Location = new System.Drawing.Point(51, 26);
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.Size = new System.Drawing.Size(50, 18);
            this.lblRoom.TabIndex = 21;
            this.lblRoom.Text = "Room :";
            // 
            // pnlSearchBylist
            // 
            this.pnlSearchBylist.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.chkActive);
            this.pnlSearchBylist.Controls.Add(this.chkAll);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.pnlSearchBylist.Location = new System.Drawing.Point(2, 38);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            this.pnlSearchBylist.Size = new System.Drawing.Size(150, 118);
            this.pnlSearchBylist.TabIndex = 24;
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.chkAll.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.chkAll.Location = new System.Drawing.Point(12, 38);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(41, 22);
            this.chkAll.TabIndex = 19;
            this.chkAll.Text = "All";
            this.chkAll.UseVisualStyleBackColor = true;
            // 
            // btnSeperator0
            // 
            this.btnSeperator0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator0.Location = new System.Drawing.Point(147, 4);
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.Size = new System.Drawing.Size(1, 110);
            this.btnSeperator0.TabIndex = 13;
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // atLabel3
            // 
            this.atLabel3.AutoSize = true;
            this.atLabel3.Font = new System.Drawing.Font("Open Sans", 12F);
            this.atLabel3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel3.Location = new System.Drawing.Point(7, 6);
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            this.atLabel3.Size = new System.Drawing.Size(84, 22);
            this.atLabel3.TabIndex = 0;
            this.atLabel3.Text = "Search By";
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            this.btnSeperator4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator4.Location = new System.Drawing.Point(9, 31);
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.Size = new System.Drawing.Size(129, 1);
            this.btnSeperator4.TabIndex = 12;
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // chkActive
            // 
            this.chkActive.AutoSize = true;
            this.chkActive.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.chkActive.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.chkActive.Location = new System.Drawing.Point(12, 66);
            this.chkActive.Name = "chkActive";
            this.chkActive.Size = new System.Drawing.Size(63, 22);
            this.chkActive.TabIndex = 20;
            this.chkActive.Text = "Active";
            this.chkActive.UseVisualStyleBackColor = true;
            // 
            // lblHead
            // 
            this.lblHead.AutoSize = true;
            this.lblHead.Font = new System.Drawing.Font("Open Sans", 15.75F);
            this.lblHead.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblHead.Location = new System.Drawing.Point(2, 2);
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            this.lblHead.Size = new System.Drawing.Size(162, 28);
            this.lblHead.TabIndex = 8;
            this.lblHead.Text = "Checklist Room";
            // 
            // frmCheckListRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 202);
            this.Controls.Add(this.pnlSearchBylist);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmCheckListRoom";
            this.Text = "frmCheckListRoom";
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.TextBoxExt txtRoom;
        private System.Windows.Forms.Label lblRoom;
        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atCheckBox chkAll;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atCheckBox chkActive;
        private atACCFramework.UserControls.atLabel lblHead;
    }
}