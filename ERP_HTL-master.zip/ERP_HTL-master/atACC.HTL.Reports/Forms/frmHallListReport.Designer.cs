﻿namespace atACC.HTL.Reports
{
    partial class frmHallListReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHallListReport));
            this.lblHead = new atACCFramework.UserControls.atLabel();
            this.pnlSearchBylist = new atACCFramework.UserControls.atPanel();
            this.radHallType = new atACCFramework.UserControls.atRadioButton();
            this.radFloor = new atACCFramework.UserControls.atRadioButton();
            this.radBlock = new atACCFramework.UserControls.atRadioButton();
            this.btnSeperator0 = new System.Windows.Forms.Button();
            this.rbtAll = new atACCFramework.UserControls.atRadioButton();
            this.radHall = new atACCFramework.UserControls.atRadioButton();
            this.atLabel3 = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.grpCommon = new atACCFramework.UserControls.atGroupBox();
            this.cmbBlock = new atACCFramework.UserControls.ComboBoxExt();
            this.txtCode = new atACCFramework.UserControls.TextBoxExt();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblBlock = new atACCFramework.UserControls.atLabel();
            this.lblFloor = new atACCFramework.UserControls.atLabel();
            this.lblDepartmentCode = new System.Windows.Forms.Label();
            this.cmbFloor = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblHall = new System.Windows.Forms.Label();
            this.lblHallType = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlHeader2.SuspendLayout();
            this.pnlSearchBylist.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            resources.ApplyResources(this.pnlBottom, "pnlBottom");
            // 
            // pnlHeader2
            // 
            this.pnlHeader2.Controls.Add(this.lblHead);
            // 
            // lblHead
            // 
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.RequiredField = false;
            // 
            // pnlSearchBylist
            // 
            resources.ApplyResources(this.pnlSearchBylist, "pnlSearchBylist");
            this.pnlSearchBylist.BackColor = System.Drawing.SystemColors.Window;
            this.pnlSearchBylist.Controls.Add(this.radHallType);
            this.pnlSearchBylist.Controls.Add(this.radFloor);
            this.pnlSearchBylist.Controls.Add(this.radBlock);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator0);
            this.pnlSearchBylist.Controls.Add(this.rbtAll);
            this.pnlSearchBylist.Controls.Add(this.radHall);
            this.pnlSearchBylist.Controls.Add(this.atLabel3);
            this.pnlSearchBylist.Controls.Add(this.btnSeperator4);
            this.pnlSearchBylist.Name = "pnlSearchBylist";
            // 
            // radHallType
            // 
            resources.ApplyResources(this.radHallType, "radHallType");
            this.radHallType.Name = "radHallType";
            this.radHallType.UseVisualStyleBackColor = true;
            this.radHallType.CheckedChanged += new System.EventHandler(this.radHallType_CheckedChanged);
            // 
            // radFloor
            // 
            resources.ApplyResources(this.radFloor, "radFloor");
            this.radFloor.Name = "radFloor";
            this.radFloor.UseVisualStyleBackColor = true;
            this.radFloor.CheckedChanged += new System.EventHandler(this.radFloor_CheckedChanged);
            // 
            // radBlock
            // 
            resources.ApplyResources(this.radBlock, "radBlock");
            this.radBlock.Name = "radBlock";
            this.radBlock.UseVisualStyleBackColor = true;
            this.radBlock.CheckedChanged += new System.EventHandler(this.radBlock_CheckedChanged);
            // 
            // btnSeperator0
            // 
            resources.ApplyResources(this.btnSeperator0, "btnSeperator0");
            this.btnSeperator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator0.FlatAppearance.BorderSize = 0;
            this.btnSeperator0.Name = "btnSeperator0";
            this.btnSeperator0.UseVisualStyleBackColor = false;
            // 
            // rbtAll
            // 
            resources.ApplyResources(this.rbtAll, "rbtAll");
            this.rbtAll.Checked = true;
            this.rbtAll.Name = "rbtAll";
            this.rbtAll.TabStop = true;
            this.rbtAll.UseVisualStyleBackColor = true;
            this.rbtAll.CheckedChanged += new System.EventHandler(this.rbtAll_CheckedChanged);
            // 
            // radHall
            // 
            resources.ApplyResources(this.radHall, "radHall");
            this.radHall.Name = "radHall";
            this.radHall.UseVisualStyleBackColor = true;
            this.radHall.CheckedChanged += new System.EventHandler(this.radHall_CheckedChanged);
            // 
            // atLabel3
            // 
            resources.ApplyResources(this.atLabel3, "atLabel3");
            this.atLabel3.Name = "atLabel3";
            this.atLabel3.RequiredField = false;
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSeperator4, "btnSeperator4");
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.grpCommon);
            this.pnlMain.Name = "pnlMain";
            // 
            // grpCommon
            // 
            this.grpCommon.BackColor = System.Drawing.Color.Transparent;
            this.grpCommon.Controls.Add(this.cmbBlock);
            this.grpCommon.Controls.Add(this.txtCode);
            this.grpCommon.Controls.Add(this.txtName);
            this.grpCommon.Controls.Add(this.lblBlock);
            this.grpCommon.Controls.Add(this.lblFloor);
            this.grpCommon.Controls.Add(this.lblDepartmentCode);
            this.grpCommon.Controls.Add(this.cmbFloor);
            this.grpCommon.Controls.Add(this.cmbRoomType);
            this.grpCommon.Controls.Add(this.lblHall);
            this.grpCommon.Controls.Add(this.lblHallType);
            resources.ApplyResources(this.grpCommon, "grpCommon");
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.TabStop = false;
            // 
            // cmbBlock
            // 
            resources.ApplyResources(this.cmbBlock, "cmbBlock");
            this.cmbBlock.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBlock.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBlock.DropDownHeight = 300;
            this.cmbBlock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBlock.FormattingEnabled = true;
            this.cmbBlock.Name = "cmbBlock";
            // 
            // txtCode
            // 
            resources.ApplyResources(this.txtCode, "txtCode");
            this.txtCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCode.Format = null;
            this.txtCode.isAllowNegative = false;
            this.txtCode.isAllowSpecialChar = false;
            this.txtCode.isNumbersOnly = false;
            this.txtCode.isNumeric = false;
            this.txtCode.isTouchable = false;
            this.txtCode.Name = "txtCode";
            this.txtCode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCode.TextChanged += new System.EventHandler(this.txtCode_TextChanged);
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtName.Format = null;
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = false;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblBlock
            // 
            resources.ApplyResources(this.lblBlock, "lblBlock");
            this.lblBlock.Name = "lblBlock";
            this.lblBlock.RequiredField = false;
            // 
            // lblFloor
            // 
            resources.ApplyResources(this.lblFloor, "lblFloor");
            this.lblFloor.Name = "lblFloor";
            this.lblFloor.RequiredField = false;
            // 
            // lblDepartmentCode
            // 
            resources.ApplyResources(this.lblDepartmentCode, "lblDepartmentCode");
            this.lblDepartmentCode.Name = "lblDepartmentCode";
            // 
            // cmbFloor
            // 
            resources.ApplyResources(this.cmbFloor, "cmbFloor");
            this.cmbFloor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbFloor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbFloor.DropDownHeight = 300;
            this.cmbFloor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFloor.FormattingEnabled = true;
            this.cmbFloor.Name = "cmbFloor";
            // 
            // cmbRoomType
            // 
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Name = "cmbRoomType";
            // 
            // lblHall
            // 
            resources.ApplyResources(this.lblHall, "lblHall");
            this.lblHall.Name = "lblHall";
            // 
            // lblHallType
            // 
            resources.ApplyResources(this.lblHallType, "lblHallType");
            this.lblHallType.Name = "lblHallType";
            this.lblHallType.RequiredField = false;
            // 
            // frmHallListReport
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlSearchBylist);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmHallListReport";
            this.atPreviewClick += new UI.PreviewClickEventHandler(this.frmCheckListHall_atPreviewClick);
            this.atDesignClick += new UI.DesignClickEventHandler(this.frmCheckListHall_atDesignClick);
            this.atValidate += new UI.ValidateEventHandler(this.frmCheckListHall_atValidate);
            this.atHyperLinkClick += new Microsoft.Reporting.WinForms.HyperlinkEventHandler(this.frmCheckListHall_atHyperLinkClick);
            this.Load += new System.EventHandler(this.frmCheckListHall_Load);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlSearchBylist, 0);
            this.Controls.SetChildIndex(this.pnlBottom, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlHeader2.ResumeLayout(false);
            this.pnlHeader2.PerformLayout();
            this.pnlSearchBylist.ResumeLayout(false);
            this.pnlSearchBylist.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atLabel lblHead;
        private atACCFramework.UserControls.atPanel pnlSearchBylist;
        private atACCFramework.UserControls.atRadioButton radHallType;
        private atACCFramework.UserControls.atRadioButton radFloor;
        private atACCFramework.UserControls.atRadioButton radBlock;
        private System.Windows.Forms.Button btnSeperator0;
        private atACCFramework.UserControls.atRadioButton rbtAll;
        private atACCFramework.UserControls.atRadioButton radHall;
        private atACCFramework.UserControls.atLabel atLabel3;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.ComboBoxExt cmbBlock;
        private atACCFramework.UserControls.atLabel lblBlock;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblHallType;
        private atACCFramework.UserControls.ComboBoxExt cmbFloor;
        private atACCFramework.UserControls.atLabel lblFloor;
        private atACCFramework.UserControls.TextBoxExt txtCode;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private System.Windows.Forms.Label lblDepartmentCode;
        private System.Windows.Forms.Label lblHall;
        private atACCFramework.UserControls.atGroupBox grpCommon;
    }
}