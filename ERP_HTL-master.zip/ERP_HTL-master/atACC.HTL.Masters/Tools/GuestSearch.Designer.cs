﻿namespace atACC.HTL.Masters
{
    partial class GuestSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GuestSearch));
            this.lblSearchFactors = new atACCFramework.UserControls.atLabel();
            this.btnSelectedItem = new atACCFramework.UserControls.atLabel();
            this.pcSearch = new System.Windows.Forms.PictureBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSeperator2 = new System.Windows.Forms.Button();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.txtItem = new atACCFramework.UserControls.TextBoxExt();
            this.lstItemSearch = new System.Windows.Forms.ListView();
            this.hdrid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.hdrCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.hdrName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.hdrContactPerson = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.hdrMobileNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.hdrGender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.pcSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSearchFactors
            // 
            resources.ApplyResources(this.lblSearchFactors, "lblSearchFactors");
            this.lblSearchFactors.Name = "lblSearchFactors";
            this.lblSearchFactors.RequiredField = false;
            // 
            // btnSelectedItem
            // 
            resources.ApplyResources(this.btnSelectedItem, "btnSelectedItem");
            this.btnSelectedItem.BackColor = System.Drawing.Color.Transparent;
            this.btnSelectedItem.ForeColor = System.Drawing.Color.DimGray;
            this.btnSelectedItem.Name = "btnSelectedItem";
            this.btnSelectedItem.RequiredField = false;
            // 
            // pcSearch
            // 
            resources.ApplyResources(this.pcSearch, "pcSearch");
            this.pcSearch.Name = "pcSearch";
            this.pcSearch.TabStop = false;
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.TabStop = false;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // btnSeperator2
            // 
            resources.ApplyResources(this.btnSeperator2, "btnSeperator2");
            this.btnSeperator2.BackColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSeperator2.FlatAppearance.BorderSize = 0;
            this.btnSeperator2.Name = "btnSeperator2";
            this.btnSeperator2.UseVisualStyleBackColor = false;
            // 
            // lblHeading
            // 
            resources.ApplyResources(this.lblHeading, "lblHeading");
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            // 
            // txtItem
            // 
            resources.ApplyResources(this.txtItem, "txtItem");
            this.txtItem.BackColor = System.Drawing.SystemColors.Window;
            this.txtItem.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtItem.Format = null;
            this.txtItem.isAllowNegative = false;
            this.txtItem.isAllowSpecialChar = false;
            this.txtItem.isNumbersOnly = false;
            this.txtItem.isNumeric = false;
            this.txtItem.isTouchable = false;
            this.txtItem.Name = "txtItem";
            this.txtItem.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtItem.TextChanged += new System.EventHandler(this.txtItem_TextChanged);
            this.txtItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtItem_KeyDown);
            // 
            // lstItemSearch
            // 
            resources.ApplyResources(this.lstItemSearch, "lstItemSearch");
            this.lstItemSearch.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lstItemSearch.BackColor = System.Drawing.Color.White;
            this.lstItemSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstItemSearch.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.hdrid,
            this.hdrCode,
            this.hdrName,
            this.hdrContactPerson,
            this.hdrMobileNumber,
            this.hdrGender});
            this.lstItemSearch.FullRowSelect = true;
            this.lstItemSearch.GridLines = true;
            this.lstItemSearch.HideSelection = false;
            this.lstItemSearch.Name = "lstItemSearch";
            this.lstItemSearch.ShowItemToolTips = true;
            this.lstItemSearch.UseCompatibleStateImageBehavior = false;
            this.lstItemSearch.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.lstItemSearch_ItemSelectionChanged);
            this.lstItemSearch.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstItemSearch_MouseDoubleClick);
            // 
            // hdrid
            // 
            resources.ApplyResources(this.hdrid, "hdrid");
            // 
            // hdrCode
            // 
            resources.ApplyResources(this.hdrCode, "hdrCode");
            // 
            // hdrName
            // 
            resources.ApplyResources(this.hdrName, "hdrName");
            // 
            // hdrContactPerson
            // 
            resources.ApplyResources(this.hdrContactPerson, "hdrContactPerson");
            // 
            // hdrMobileNumber
            // 
            resources.ApplyResources(this.hdrMobileNumber, "hdrMobileNumber");
            // 
            // hdrGender
            // 
            resources.ApplyResources(this.hdrGender, "hdrGender");
            // 
            // GuestSearch
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblSearchFactors);
            this.Controls.Add(this.btnSelectedItem);
            this.Controls.Add(this.pcSearch);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSeperator2);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.txtItem);
            this.Controls.Add(this.lstItemSearch);
            this.Name = "GuestSearch";
            this.Activated += new System.EventHandler(this.GuestSearch_Activated);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GuestSearch_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GuestSearch_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.pcSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atACCFramework.UserControls.atLabel lblSearchFactors;
        private atACCFramework.UserControls.atLabel btnSelectedItem;
        private System.Windows.Forms.PictureBox pcSearch;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSeperator2;
        private atACCFramework.UserControls.atLabel lblHeading;
        private atACCFramework.UserControls.TextBoxExt txtItem;
        private System.Windows.Forms.ListView lstItemSearch;
        private System.Windows.Forms.ColumnHeader hdrid;
        private System.Windows.Forms.ColumnHeader hdrCode;
        private System.Windows.Forms.ColumnHeader hdrName;
        private System.Windows.Forms.ColumnHeader hdrContactPerson;
        private System.Windows.Forms.ColumnHeader hdrMobileNumber;
        private System.Windows.Forms.ColumnHeader hdrGender;
    }
}