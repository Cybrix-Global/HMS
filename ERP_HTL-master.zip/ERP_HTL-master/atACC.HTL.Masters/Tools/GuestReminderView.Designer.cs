﻿namespace atACC.HTL.Masters
{
    partial class GuestReminderView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GuestReminderView));
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.dtReminderTime = new atACCFramework.UserControls.atDateTimePicker1();
            this.dtReminderDate = new atACCFramework.UserControls.atDateTimePicker1();
            this.atLabel2 = new atACCFramework.UserControls.atLabel();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.txtMessage = new atACCFramework.UserControls.TextBoxExt();
            this.lblGuest = new atACCFramework.UserControls.atLabel();
            this.cmbRoom = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoom = new atACCFramework.UserControls.atLabel();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.cmbGuest = new atACCFramework.UserControls.ComboBoxExt();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.radOpen = new atACCFramework.UserControls.atRadioButton();
            this.radClose = new atACCFramework.UserControls.atRadioButton();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.radClose);
            this.pnlMain.Controls.Add(this.radOpen);
            this.pnlMain.Controls.Add(this.dtReminderTime);
            this.pnlMain.Controls.Add(this.dtReminderDate);
            this.pnlMain.Controls.Add(this.atLabel2);
            this.pnlMain.Controls.Add(this.atLabel1);
            this.pnlMain.Controls.Add(this.txtMessage);
            this.pnlMain.Controls.Add(this.lblGuest);
            this.pnlMain.Controls.Add(this.cmbRoom);
            this.pnlMain.Controls.Add(this.lblRoom);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.cmbGuest);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.label1);
            this.pnlMain.Name = "pnlMain";
            // 
            // dtReminderTime
            // 
            this.dtReminderTime.DisbaleDateTimeFormat = false;
            this.dtReminderTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            resources.ApplyResources(this.dtReminderTime, "dtReminderTime");
            this.dtReminderTime.Name = "dtReminderTime";
            this.dtReminderTime.ShowUpDown = true;
            // 
            // dtReminderDate
            // 
            this.dtReminderDate.DisbaleDateTimeFormat = false;
            this.dtReminderDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            resources.ApplyResources(this.dtReminderDate, "dtReminderDate");
            this.dtReminderDate.Name = "dtReminderDate";
            this.dtReminderDate.Value = new System.DateTime(2021, 5, 20, 0, 0, 0, 0);
            // 
            // atLabel2
            // 
            resources.ApplyResources(this.atLabel2, "atLabel2");
            this.atLabel2.Name = "atLabel2";
            this.atLabel2.RequiredField = false;
            // 
            // atLabel1
            // 
            resources.ApplyResources(this.atLabel1, "atLabel1");
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            // 
            // txtMessage
            // 
            this.txtMessage.BackColor = System.Drawing.SystemColors.Window;
            this.txtMessage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMessage.Format = null;
            this.txtMessage.isAllowNegative = false;
            this.txtMessage.isAllowSpecialChar = false;
            this.txtMessage.isNumbersOnly = false;
            this.txtMessage.isNumeric = false;
            this.txtMessage.isTouchable = false;
            resources.ApplyResources(this.txtMessage, "txtMessage");
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtMessage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMessage_KeyDown);
            // 
            // lblGuest
            // 
            resources.ApplyResources(this.lblGuest, "lblGuest");
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.RequiredField = false;
            // 
            // cmbRoom
            // 
            resources.ApplyResources(this.cmbRoom, "cmbRoom");
            this.cmbRoom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoom.DropDownHeight = 300;
            this.cmbRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoom.DropDownWidth = 210;
            this.cmbRoom.FormattingEnabled = true;
            this.cmbRoom.Name = "cmbRoom";
            this.cmbRoom.SelectedValueChanged += new System.EventHandler(this.cmbRoom_SelectedValueChanged);
            // 
            // lblRoom
            // 
            resources.ApplyResources(this.lblRoom, "lblRoom");
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.RequiredField = false;
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // cmbGuest
            // 
            resources.ApplyResources(this.cmbGuest, "cmbGuest");
            this.cmbGuest.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuest.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuest.DropDownHeight = 300;
            this.cmbGuest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGuest.DropDownWidth = 210;
            this.cmbGuest.FormattingEnabled = true;
            this.cmbGuest.Name = "cmbGuest";
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // radOpen
            // 
            resources.ApplyResources(this.radOpen, "radOpen");
            this.radOpen.Checked = true;
            this.radOpen.Name = "radOpen";
            this.radOpen.UseVisualStyleBackColor = true;
            // 
            // radClose
            // 
            resources.ApplyResources(this.radClose, "radClose");
            this.radClose.Name = "radClose";
            this.radClose.UseVisualStyleBackColor = true;
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Crimson;
            this.label1.Name = "label1";
            // 
            // GuestReminderView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Name = "GuestReminderView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.GuestReminderView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.GuestReminderView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.GuestReminderView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.GuestReminderView_atNewClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.GuestReminderView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.GuestReminderView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.GuestReminderView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.GuestReminderView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.GuestReminderView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.GuestReminderView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.GuestReminderView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblGuest;
        private atACCFramework.UserControls.ComboBoxExt cmbRoom;
        private atACCFramework.UserControls.atLabel lblRoom;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.ComboBoxExt cmbGuest;
        private atACCFramework.UserControls.TextBoxExt txtMessage;
        private atACCFramework.UserControls.atLabel atLabel2;
        private atACCFramework.UserControls.atLabel atLabel1;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory4;
        private atACCFramework.UserControls.atDateTimePicker1 dtReminderDate;
        private atACCFramework.UserControls.atDateTimePicker1 dtReminderTime;
        private atACCFramework.UserControls.atRadioButton radClose;
        private atACCFramework.UserControls.atRadioButton radOpen;
        private atACCFramework.UserControls.atLabel lblStatus;
        private System.Windows.Forms.Label label1;
    }
}