﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;
using System.Data.SqlClient;

namespace atACC.HTL.Masters
{
    public partial class GuestReminderView : SearchFormBase2
    {
        #region Constructor
        public GuestReminderView()
        {
            InitializeComponent();
        }
        #endregion

        #region Private Variables
        GuestReminder entGuestReminder;
        GuestReminderPending entGuestReminderPending;
        List<GuestReminder> entGuestReminders;
        List<Rooms> entRooms;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        bool onLoad = true;
        #endregion

        #region Populate Events
        public void PopulateGuestReminder()
        {
            try
            {
                entGuestReminders = dbh.GuestReminders.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRooms()
        {
            try
            {
                entRooms = dbh.Rooms.ToList();
                cmbRoom.DataSource = entRooms;
                cmbRoom.DisplayMember = "Name";
                cmbRoom.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateGuest()
        {
            int iFlagId = 1, iRoomId = 0, iGuest = 0;
            DateTime iDate = DateTime.Now;

            SqlHelper _sql = new SqlHelper();
            iRoomId = Convert.ToInt32(cmbRoom.SelectedValue);
            _sql.SPName = "SPGetGuestInfo";
            SqlParameter paramFlag = new SqlParameter("Flag", iFlagId);
            SqlParameter paramFlag2 = new SqlParameter("RoomId", iRoomId);
            SqlParameter paramFlag3 = new SqlParameter("VoucherDate", iDate);

            _sql.SqlParameters = new List<SqlParameter>();
            _sql.SqlParameters.Add(paramFlag);
            _sql.SqlParameters.Add(paramFlag2);
            _sql.SqlParameters.Add(paramFlag3);
            DataTable dt = new DataTable();
            dt = _sql.ExecuteProcedure().Tables[0];
            cmbGuest.DataSource = dt;
            cmbGuest.DisplayMember = "Name";
            cmbGuest.ValueMember = "id";
            cmbGuest.SelectedIndex = -1;
            if (dt.Rows.Count == 1)
            {
                cmbGuest.SelectedIndex = 0;
                cmbGuest.Enabled = false;
            }
            if (dt.Rows.Count == 0)
            {
                cmbGuest.SelectedIndex = -1;
                cmbGuest.Enabled = true;
            }
        }
        #endregion

        #region Form Events
        private void txtMessage_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbRoom_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateGuest();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void GuestReminderView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                entGuestReminder = new GuestReminder();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void GuestReminderView_atAfterInitialise()
        {
            try
            {
                cmbRoom.Focus();
                PopulateGuestReminder();
                PopulateRooms();
                dtReminderDate.Value = DateTime.Now;
                radClose.Enabled = false;
                radOpen.Checked = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void GuestReminderView_atNewClick(object source)
        {
            try
            {
                entGuestReminder = new GuestReminder();
                entGuestReminders = new List<GuestReminder>();
                dbh = atHotelContext.CreateContext();
                cmbRoom.Focus();
                PopulateGuestReminder();
                radClose.Enabled = false;
                radOpen.Checked = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool GuestReminderView_atValidate(object source)
        {
            try
            {
                if (cmbRoom.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbRoom, MessageKeys.MsgRoomOrHallMustBeChosen);
                    cmbRoom.Focus();
                    return false;
                }
                if (cmbGuest.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbGuest, MessageKeys.MsgGuestMustBeChosen);
                    cmbGuest.Focus();
                    return false;
                }
                if (txtMessage.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtMessage, MessageKeys.MsgNothingToSave);
                    txtMessage.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool GuestReminderView_atSaveClick(object source, SaveClickEventArgs e)
        {
           try
            {
                if (NewRecord)
                {
                    entGuestReminder = new GuestReminder();
                    entGuestReminderPending = new GuestReminderPending();
                }
                entGuestReminder.ContextID = iContextID;
                entGuestReminder.LoginUserID = GlobalFunctions.LoginUserID;
                entGuestReminder.LocationID = GlobalFunctions.LoginLocationID;
                entGuestReminder.FK_RoomID = cmbRoom.SelectedValue.ToInt32();
                entGuestReminder.FK_GuestID = cmbGuest.SelectedValue.ToInt32();
                DateTime reminderdate = new DateTime(dtReminderDate.Value.Year, dtReminderDate.Value.Month, dtReminderDate.Value.Day, dtReminderTime.Value.Hour, dtReminderTime.Value.Minute, dtReminderTime.Value.Second);
                entGuestReminder.ReminderDate = reminderdate;
                entGuestReminder.FK_CreatedUserID = GlobalFunctions.LoginLocationID;
                entGuestReminder.Status = radOpen.Checked ? true : false;
                entGuestReminder.Message = txtMessage.Text;
                if (NewRecord)
                {
                    dbh.GuestReminders.AddObject(entGuestReminder);
                }
                else if (!NewRecord)
                {
                    dbh.ObjectStateManager.ChangeObjectState(entGuestReminder, EntityState.Modified);
                }

                if (radOpen.Checked)
                {
                    entGuestReminderPending.FK_GuestReminderID = entGuestReminder.id;
                    if (NewRecord)
                    {
                        dbh.GuestReminderPendings.AddObject(entGuestReminderPending);
                    }
                    else if (!NewRecord)
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entGuestReminderPending, EntityState.Modified);
                    }
                }
                else if (radClose.Checked && entGuestReminderPending != null)
                {
                    dbh.DeleteObject(entGuestReminderPending);
                }
                dbh.SaveChanges();
                return true;
            }
           catch (Exception ex)
           {
               ExceptionManager.Publish(ex);
               atMessageBox.Show(ex, ENOperation.Save);
               return false;
           }
        }
        private bool GuestReminderView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void GuestReminderView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vGuestReminder = entGuestReminders
                    .Select(x => new { id = x.id, Reminder_Date = x.ReminderDate.Value.ToShortDateString(), Message = x.Message }).OrderByDescending(x => x.id);
                e.SearchEntityList = vGuestReminder;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entGuestReminder = dbh.GuestReminders.Where(x => x.id == ID).SingleOrDefault();
                if (entGuestReminders != null)
                {
                    cmbRoom.SelectedValue = entGuestReminder.FK_RoomID;
                    cmbGuest.SelectedValue = entGuestReminder.FK_GuestID;
                    dtReminderDate.Value = entGuestReminder.ReminderDate.Value;
                    dtReminderTime.Value = entGuestReminder.ReminderDate.Value;
                    txtMessage.Text = entGuestReminder.Message;
                    radOpen.Checked = entGuestReminder.Status.toBool();
                }
                if (entGuestReminder.Status.toBool() == true)
                {
                    entGuestReminderPending = dbh.GuestReminderPendings.Where(x => x.FK_GuestReminderID == entGuestReminder.id).SingleOrDefault();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool GuestReminderView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vGuestReminder = new { id = 0, Reminder_Date = "", Message = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vGuestReminder).id);
                }
                else
                {
                    cmbRoom.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private void GuestReminderView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoom.Focus();
                radClose.Enabled = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool GuestReminderView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.DeleteObject(entGuestReminder);
                dbh.DeleteObject(entGuestReminderPending);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void GuestReminderView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
