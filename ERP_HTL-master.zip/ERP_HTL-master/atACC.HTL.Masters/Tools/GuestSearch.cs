﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACC.CommonExtensions;
using atACCFramework.BaseClasses;
using atACC.Common;
using System.Data.SqlClient;
using atACC.Common.Classes;
using atACC.HTL.ORM;
using atACC.HTL.Masters.Classes;
namespace atACC.HTL.Masters
{
    public partial class GuestSearch : FormBase
    {
        #region Private Variables
        List<GuestSearchClass> entCurrent;
        atACCHotelEntities dbh;
        DataTable dtSearchResult;
        SqlHelper sqlHelper;
        bool Active;
        #endregion

        #region Public Properties
        public int SelectedGuestID { get; set; }
        public string SelectedGuestCode { get; set; }
        public string SelectedGuestName { get; set; }
        public string SelectedMobileNumber { get; set; }
        #endregion

        #region Constructor
        public GuestSearch(string _CurrentGuest,bool _Active)
        {
            InitializeComponent();
            hdrCode.Width = 80;
            hdrName.Width = 250;
            hdrContactPerson.Width = 250;
            hdrMobileNumber.Width = 110;
            hdrGender.Width = 110;
            Active = _Active;
            txtItem.Text = _CurrentGuest;   
        }
        #endregion

        #region Private Methods
        private void SelectEnd()
        {
            txtItem.SelectionStart = txtItem.Text.Length;
        }
        private void SearchListView()
        {
            dtSearchResult = new DataTable();
            sqlHelper = new SqlHelper();
            sqlHelper.SqlParameters = new List<SqlParameter>();
            sqlHelper.SqlParameters.Add(new SqlParameter("SearchString", txtItem.Text));
            sqlHelper.SqlParameters.Add(new SqlParameter("BranchID", GlobalFunctions.LoginLocationID));
            sqlHelper.SqlParameters.Add(new SqlParameter("Status", Active == true ? 1 : 0));
            sqlHelper.SPName = "Sp_SearchGuest";
            dtSearchResult = sqlHelper.ExecuteProcedure().Tables[0];
            entCurrent = dtSearchResult.AsEnumerable()
                .Select(x => new GuestSearchClass
                {
                    Id = x["id"].ToString().ToInt32(),
                    Code = x["Code"].ToString(),
                    Name = x["Name"].ToString(),
                    ContactPerson = x["ContactPerson"].ToString(),
                    MobileNumber = x["Mobile"].ToString(),
                    Gender = x["Gender"].ToString(),
                }).ToList();
            BindListView();
        }
        private void BindListView()
        {
            lstItemSearch.View = View.Details;
            lstItemSearch.Items.Clear();
            foreach (GuestSearchClass gue in entCurrent)
            {
                var listViewItem = new ListViewItem(ToStringArray(gue));
                lstItemSearch.Items.Add(listViewItem);
            }
            lstItemSearch.FullRowSelect = true;
            if (lstItemSearch.Items.Count > 0)
                lstItemSearch.Items[0].Selected = true;
        }
        private string[] ToStringArray(GuestSearchClass gue)
        {
            string[] sColumns = new string[] { "Id", "Code", "Name", "ContactPerson", "MobileNumber", "Gender" };
            return gue.GetType()
                    .GetProperties()
                    .Where(x => sColumns.Contains(x.Name))
                    .Select(p =>
                    {
                        object value = p.GetValue(gue, null);
                        return value == null ? null : value.ToString();
                    })
                    .ToArray();
        }
        #endregion

        #region Form Events
        private void GuestSearch_Activated(object sender, EventArgs e)
        {
            SelectEnd();
        }
        private void txtItem_TextChanged(object sender, EventArgs e)
        {
            SearchListView();
        }
        private void txtItem_KeyDown(object sender, KeyEventArgs e)
        {
            int index;
            if (lstItemSearch.Items.Count <= 0) { return; }
            if (lstItemSearch.SelectedItems.Count <= 0) { return; }
            switch (e.KeyCode)
            {
                case Keys.Down:
                    e.Handled = true;
                    index = lstItemSearch.SelectedItems[0].Index;
                    if (index < lstItemSearch.Items.Count - 1)
                    {
                        this.lstItemSearch.Items[index].Selected = false;
                        index = index + 1;
                        this.lstItemSearch.Items[index].Selected = true;
                        lstItemSearch.EnsureVisible(index);
                    }
                    break;
                case Keys.Up:
                    e.Handled = true;
                    index = lstItemSearch.SelectedItems[0].Index;
                    if (index > 0)
                    {
                        this.lstItemSearch.Items[index].Selected = false;
                        index = index - 1;
                        this.lstItemSearch.Items[index].Selected = true;
                        lstItemSearch.EnsureVisible(index);
                    }
                    break;
                case Keys.Return:
                    SelectedGuestID = lstItemSearch.SelectedItems[0].Text.ToInt32();
                    SelectedGuestCode = lstItemSearch.SelectedItems[0].SubItems[2].Text;
                    SelectedGuestName = lstItemSearch.SelectedItems[0].SubItems[3].Text;
                    SelectedMobileNumber = lstItemSearch.SelectedItems[0].SubItems[5].Text;
                    this.DialogResult = DialogResult.OK;
                    e.Handled = true;
                    break;
            }
        }
        private void lstItemSearch_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SelectedGuestID = lstItemSearch.SelectedItems[0].Text.ToInt32();
            SelectedGuestCode = lstItemSearch.SelectedItems[0].SubItems[1].Text;
            SelectedGuestName = lstItemSearch.SelectedItems[0].SubItems[2].Text;
            SelectedMobileNumber = lstItemSearch.SelectedItems[0].SubItems[5].Text;
            this.DialogResult = DialogResult.OK;
        }
        private void GuestSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.DialogResult = DialogResult.Cancel;
            }
        }
        private void GuestSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\'')
            {
                e.Handled = true;
            }
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        private void lstItemSearch_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.Item.Selected)
            {
                int ListViewPosition = lstItemSearch.Location.Y;
                int itemposition = e.Item.Position.Y;
                btnSelectedItem.Location = new Point(btnSelectedItem.Location.X, itemposition + ListViewPosition);
            }
            else if (!e.Item.Selected)
            {

            }
        }
        #endregion
    }
}
