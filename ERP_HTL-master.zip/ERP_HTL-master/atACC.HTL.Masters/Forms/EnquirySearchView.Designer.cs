﻿namespace atACC.HTL.Masters.Forms
{
    partial class EnquirySearchView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EnquirySearchView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlCommon = new atACCFramework.UserControls.atPanel();
            this.pcSearch = new System.Windows.Forms.PictureBox();
            this.lblTo = new atACCFramework.UserControls.atLabel();
            this.lblFrom = new atACCFramework.UserControls.atLabel();
            this.dtToDate = new atACCFramework.UserControls.atDateTimePicker();
            this.dtFromDate = new atACCFramework.UserControls.atDateTimePicker();
            this.txtSearch = new atACCFramework.UserControls.TextBoxExt();
            this.dgVouchers = new atACCFramework.UserControls.atGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblHeading = new atACCFramework.UserControls.atLabel();
            this.bindEnquiry = new System.Windows.Forms.BindingSource(this.components);
            this.col_Vno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Employee = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.pnlCommon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgVouchers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindEnquiry)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCommon
            // 
            resources.ApplyResources(this.pnlCommon, "pnlCommon");
            this.pnlCommon.BackColor = System.Drawing.SystemColors.Window;
            this.pnlCommon.Controls.Add(this.pcSearch);
            this.pnlCommon.Controls.Add(this.lblTo);
            this.pnlCommon.Controls.Add(this.lblFrom);
            this.pnlCommon.Controls.Add(this.dtToDate);
            this.pnlCommon.Controls.Add(this.dtFromDate);
            this.pnlCommon.Controls.Add(this.txtSearch);
            this.pnlCommon.Controls.Add(this.dgVouchers);
            this.pnlCommon.Name = "pnlCommon";
            // 
            // pcSearch
            // 
            resources.ApplyResources(this.pcSearch, "pcSearch");
            this.pcSearch.Name = "pcSearch";
            this.pcSearch.TabStop = false;
            // 
            // lblTo
            // 
            resources.ApplyResources(this.lblTo, "lblTo");
            this.lblTo.Name = "lblTo";
            this.lblTo.RequiredField = false;
            // 
            // lblFrom
            // 
            resources.ApplyResources(this.lblFrom, "lblFrom");
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.RequiredField = false;
            // 
            // dtToDate
            // 
            resources.ApplyResources(this.dtToDate, "dtToDate");
            this.dtToDate.BackColor = System.Drawing.Color.Transparent;
            this.dtToDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtToDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtToDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtToDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtToDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtToDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtToDate.Checked = true;
            this.dtToDate.DisbaleDateTimeFormat = false;
            this.dtToDate.DisbaleShortDateTimeFormat = false;
            this.dtToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtToDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtToDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtToDate.Name = "dtToDate";
            this.dtToDate.Value = new System.DateTime(2021, 6, 1, 16, 3, 14, 323);
            this.dtToDate.ValueChanged += new System.EventHandler(this.dtToDate_ValueChanged);
            // 
            // dtFromDate
            // 
            resources.ApplyResources(this.dtFromDate, "dtFromDate");
            this.dtFromDate.BackColor = System.Drawing.Color.Transparent;
            this.dtFromDate.CalendarFont = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFromDate.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this.dtFromDate.CalendarMonthBackground = System.Drawing.SystemColors.Window;
            this.dtFromDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtFromDate.CalendarTitleForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtFromDate.CalendarTrailingForeColor = System.Drawing.SystemColors.GrayText;
            this.dtFromDate.Checked = true;
            this.dtFromDate.DisbaleDateTimeFormat = false;
            this.dtFromDate.DisbaleShortDateTimeFormat = false;
            this.dtFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtFromDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtFromDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtFromDate.Name = "dtFromDate";
            this.dtFromDate.Value = new System.DateTime(2021, 6, 1, 16, 3, 14, 323);
            this.dtFromDate.ValueChanged += new System.EventHandler(this.dtFromDate_ValueChanged);
            // 
            // txtSearch
            // 
            resources.ApplyResources(this.txtSearch, "txtSearch");
            this.txtSearch.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSearch.Format = null;
            this.txtSearch.isAllowNegative = false;
            this.txtSearch.isAllowSpecialChar = false;
            this.txtSearch.isNumbersOnly = false;
            this.txtSearch.isNumeric = false;
            this.txtSearch.isTouchable = false;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtSearch.TextChanged += new System.EventHandler(this.txtFilterHDR_TextChanged);
            // 
            // dgVouchers
            // 
            resources.ApplyResources(this.dgVouchers, "dgVouchers");
            this.dgVouchers.AllowUserToAddRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgVouchers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgVouchers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgVouchers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgVouchers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgVouchers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_Vno,
            this.col_Name,
            this.col_Employee});
            this.dgVouchers.EnableHeadersVisualStyles = false;
            this.dgVouchers.EnterKeyNavigation = false;
            this.dgVouchers.LastKey = System.Windows.Forms.Keys.None;
            this.dgVouchers.Name = "dgVouchers";
            this.dgVouchers.ReadOnly = true;
            this.dgVouchers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgVouchers.sGridID = null;
            this.dgVouchers.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dgVouchers_MouseDoubleClick);
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Crimson;
            this.btnClose.ForeColor = System.Drawing.Color.DarkGray;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // lblHeading
            // 
            resources.ApplyResources(this.lblHeading, "lblHeading");
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.RequiredField = false;
            // 
            // col_Vno
            // 
            this.col_Vno.DataPropertyName = "VoucherNo";
            this.col_Vno.FillWeight = 80F;
            resources.ApplyResources(this.col_Vno, "col_Vno");
            this.col_Vno.Name = "col_Vno";
            this.col_Vno.ReadOnly = true;
            // 
            // col_Name
            // 
            this.col_Name.DataPropertyName = "Name";
            this.col_Name.FillWeight = 200F;
            resources.ApplyResources(this.col_Name, "col_Name");
            this.col_Name.Name = "col_Name";
            this.col_Name.ReadOnly = true;
            // 
            // col_Employee
            // 
            this.col_Employee.DataPropertyName = "FK_EmployeeID";
            this.col_Employee.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.col_Employee.FillWeight = 110F;
            this.col_Employee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.col_Employee, "col_Employee");
            this.col_Employee.Name = "col_Employee";
            this.col_Employee.ReadOnly = true;
            this.col_Employee.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_Employee.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // EnquirySearchView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlCommon);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblHeading);
            this.Name = "EnquirySearchView";
            this.pnlCommon.ResumeLayout(false);
            this.pnlCommon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgVouchers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindEnquiry)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlCommon;
        private atACCFramework.UserControls.TextBoxExt txtSearch;
        private atACCFramework.UserControls.atGridView dgVouchers;
        private System.Windows.Forms.Button btnClose;
        private atACCFramework.UserControls.atLabel lblHeading;
        private System.Windows.Forms.BindingSource bindEnquiry;
        private atACCFramework.UserControls.atLabel lblTo;
        private atACCFramework.UserControls.atLabel lblFrom;
        private atACCFramework.UserControls.atDateTimePicker dtToDate;
        private atACCFramework.UserControls.atDateTimePicker dtFromDate;
        private System.Windows.Forms.PictureBox pcSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Vno;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Name;
        private System.Windows.Forms.DataGridViewComboBoxColumn col_Employee;

    }
}