﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class FloorsView : SearchFormBase2
    {
        #region Constructor
        public FloorsView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_FloorsView;
        }
        #endregion

        #region Private Variables
        Floors m_Floor;
        List<Floors> m_Floors;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        bool onLoad = true;
        #endregion

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Floors, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateFloorsView()
        {
            try
            {
                m_Floors = dbh.Floors.ToList();
                rbtActive.Checked = true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtCode, MessageKeys.MsgEnterCode);
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(txtDescription, MessageKeys.MsgEnterDescription);

            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    Floors floor = dbh.Floors.Where(x => x.Code == txtCode.Text.Trim())
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (floor != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(floor.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtActive_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtInactive_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void FloorsView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                m_Floor = new Floors();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void FloorsView_atAfterInitialise()
        {
            try
            {
                txtCode.Focus();
                GetSeqNo();
                PopulateFloorsView();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void FloorsView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_Floor = new Floors();
                txtCode.Focus();
                GetSeqNo();
                PopulateFloorsView();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool FloorsView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == "")
                {
                    errProvider.SetError(txtCode, MessageKeys.MsgCodeMustBeEntered);
                    txtCode.Focus();
                    return false;
                }
                if (txtName.Text.Trim() == "")
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool FloorsView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    m_Floor = new Floors();
                }
                m_Floor.ContextID = iContextID;
                m_Floor.LoginUserID = GlobalFunctions.LoginUserID;
                m_Floor.LocationID = GlobalFunctions.LoginLocationID;
                m_Floor.Code = txtCode.Text;
                m_Floor.Name = txtName.Text;
                m_Floor.Description = txtDescription.Text;
                m_Floor.Active = rbtActive.Checked ? true : false;                
                if (NewRecord)
                {                    
                    dbh.Floors.AddObject(m_Floor);
                }
                else if (!NewRecord)
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_Floor, EntityState.Modified);
                }
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_FloorsCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return FloorsView_atSaveClick(source, e);
                    }
                    else if (updEx.InnerException.Message.Contains("UC_FloorsName"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgFloor + " (" + txtName.Text + ") "
                            + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                        txtName.Focus();
                        return false;
                    }
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool FloorsView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void FloorsView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vFloors = m_Floors.Select(x => new { id = x.id, Code = x.Code, Name = x.Name }).OrderByDescending(x => x.id);
                e.SearchEntityList = vFloors;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_Floor = dbh.Floors.Where(x => x.id == ID).SingleOrDefault();
                if (m_Floors != null)
                {
                    txtCode.Text = m_Floor.Code;
                    txtName.Text = m_Floor.Name;
                    txtDescription.Text = m_Floor.Description;
                    rbtActive.Checked = m_Floor.Active == true ? true : false;
                    rbtInactive.Checked = m_Floor.Active == true ? false : true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool FloorsView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vFloors = new { id = 0, Code = "", Name = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vFloors).id);
                }
                else 
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool FloorsView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                onLoad = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void FloorsView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool FloorsView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.DeleteObject(m_Floor);
                dbh.SaveChanges();
                PopulateFloorsView();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void FloorsView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
