﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;
namespace atACC.HTL.Masters
{
    public partial class SourceView : SearchFormBase2
    {
        #region Constructor
        public SourceView()
        {
            InitializeComponent();
        }
        #endregion

        #region Public Properties
        public int CurrentID { get; set; }
        #endregion

        #region Private Variable
        Source m_Source;
        List<Source> m_SourceList;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateSource()
        {
            try
            {

                m_SourceList = dbh.Sources.ToList();                
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            try
            {
                m_Source = new Source();
                m_SourceList = new List<Source>();
                txtName.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtName_Validated(object sender, EventArgs e)
        {
            try
            {
                Source SD = dbh.Sources.Where(x => x.Name == txtName.Text.Trim())
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .SingleOrDefault();
                if (SD != null && txtName.IsTextChanged())
                {
                    ReLoadData(SD.id);
                    onPopulate();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void SourceView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                m_Source = new Source();
                SettingsButton.Visible = ShareButton.Visible = false;
                PrintButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void SourceView_atAfterInitialise()
        {
            try
            {
                txtName.Focus();
                ShowToolTip();
                PopulateSource();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void SourceView_atNewClick(object source)
        {
            try
            {
                m_Source = new Source();
                dbh = atHotelContext.CreateContext();
                txtName.Focus();
                FnClearAll();
                ShowToolTip();
                PopulateSource();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool SourceView_atValidate(object source)
        {
            try
            {
                if (txtName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool SourceView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    m_Source = new Source();
                }
                m_Source.ContextID = iContextID;
                m_Source.LocationID = GlobalFunctions.LoginLocationID;
                m_Source.LoginUserID = GlobalFunctions.LoginUserID;
                m_Source.Name = txtName.Text.ToString();
                if (NewRecord)
                {
                    dbh.Sources.AddObject(m_Source);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_Source, EntityState.Modified);
                }
                dbh.SaveChanges();
                CurrentID = m_Source.id;
                this.DialogResult = DialogResult.OK;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException.Message.Contains("UC_SourceName"))
                {
                    atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgSource + " (" + txtName.Text + ") "
                        + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                    txtName.Focus();
                    return false;
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool SourceView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void SourceView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = m_SourceList.Select(x => new { x.id, Name = x.Name }).OrderByDescending(x => x.id);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_Source = dbh.Sources.Where(x => x.id == id).SingleOrDefault();
                if (m_Source != null)
                {
                    txtName.Text = m_Source.Name.ToString();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool SourceView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vLoan = new { id = 0, Name = string.Empty };
                    ReLoadData(e.GetSelectedEntity().Cast(vLoan).id);
                }
                else
                {
                    txtName.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool SourceView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void SourceView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool SourceView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {

                dbh.Sources.DeleteObject(m_Source);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void SourceView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
