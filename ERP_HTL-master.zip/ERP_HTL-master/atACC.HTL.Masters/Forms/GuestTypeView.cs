﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class GuestTypeView : SearchFormBase2
    {
        #region Constructor
        public GuestTypeView()
        {
            InitializeComponent();
        }
        #endregion

        #region Public Properties
        public int CurrentID { get; set; }
        #endregion

        #region Private Variable
        GuestType m_GuestType;
        List<GuestType> m_GuestTypeList;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        #endregion

        #region Populate Events
        private void PopulateGuestType()
        {
            try
            {
                m_GuestTypeList = dbh.GuestTypes.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            try
            {
                m_GuestType = new GuestType();
                m_GuestTypeList = new List<GuestType>();
                txtName.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtName_Validated(object sender, EventArgs e)
        {
            try
            {
                GuestType SD = dbh.GuestTypes.Where(x => x.Name == txtName.Text.Trim())
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .SingleOrDefault();
                if (SD != null && txtName.IsTextChanged())
                {
                    ReLoadData(SD.id);
                    onPopulate();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void GuestTypeView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                m_GuestType = new GuestType();
                SettingsButton.Visible = ShareButton.Visible = false;
                PrintButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void GuestTypeView_atAfterInitialise()
        {
            try
            {
                txtName.Focus();
                ShowToolTip();
                PopulateGuestType();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void GuestTypeView_atNewClick(object source)
        {
            try
            {
                m_GuestType = new GuestType();
                dbh = atHotelContext.CreateContext();
                txtName.Focus();
                FnClearAll();
                ShowToolTip();
                PopulateGuestType();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool GuestTypeView_atValidate(object source)
        {
            try
            {
                if (txtName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool GuestTypeView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    m_GuestType = new GuestType();
                }
                m_GuestType.ContextID = iContextID;
                m_GuestType.LocationID = GlobalFunctions.LoginLocationID;
                m_GuestType.LoginUserID = GlobalFunctions.LoginUserID;
                m_GuestType.Name = txtName.Text.ToString();
                if (NewRecord)
                {
                    dbh.GuestTypes.AddObject(m_GuestType);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_GuestType, EntityState.Modified);
                }
                dbh.SaveChanges();
                CurrentID = m_GuestType.id;
                this.DialogResult = DialogResult.OK;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException.Message.Contains("UC_GuestTypeName"))
                {
                    atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgGuestType + " (" + txtName.Text + ") "
                        + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                    txtName.Focus();
                    return false;
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool GuestTypeView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void GuestTypeView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = m_GuestTypeList.Select(x => new { x.id, Name = x.Name }).OrderByDescending(x => x.id);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_GuestType = dbh.GuestTypes.Where(x => x.id == id).SingleOrDefault();
                if (m_GuestType != null)
                {
                    txtName.Text = m_GuestType.Name.ToString();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool GuestTypeView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vLoan = new { id = 0, Name = string.Empty };
                    ReLoadData(e.GetSelectedEntity().Cast(vLoan).id);
                }
                else 
                {
                    txtName.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool GuestTypeView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void GuestTypeView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool GuestTypeView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.GuestTypes.DeleteObject(m_GuestType);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void GuestTypeView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
