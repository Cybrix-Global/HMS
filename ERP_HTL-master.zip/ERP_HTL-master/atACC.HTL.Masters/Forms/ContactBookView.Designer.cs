﻿namespace atACC.HTL.Masters
{
    partial class ContactBookView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ContactBookView));
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblContry = new atACCFramework.UserControls.atLabel();
            this.txtEmail = new atACCFramework.UserControls.TextBoxExt();
            this.txtState = new atACCFramework.UserControls.TextBoxExt();
            this.txtAdd3 = new atACCFramework.UserControls.TextBoxExt();
            this.lblCity = new atACCFramework.UserControls.atLabel();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.CmbCountry = new atACCFramework.UserControls.ComboBoxExt();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.txtPostalcode = new atACCFramework.UserControls.TextBoxExt();
            this.lblState = new atACCFramework.UserControls.atLabel();
            this.lblContactPerson = new atACCFramework.UserControls.atLabel();
            this.lblMobileNumber = new atACCFramework.UserControls.atLabel();
            this.txtAdd2 = new atACCFramework.UserControls.TextBoxExt();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.txtContactPerson = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddress3 = new atACCFramework.UserControls.atLabel();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.lblAddress2 = new atACCFramework.UserControls.atLabel();
            this.lblPostalCode = new atACCFramework.UserControls.atLabel();
            this.txtCity = new atACCFramework.UserControls.TextBoxExt();
            this.lblEmail = new atACCFramework.UserControls.atLabel();
            this.lblCategory = new atACCFramework.UserControls.atLabel();
            this.cmbCategory = new atACCFramework.UserControls.ComboBoxExt();
            this.txtReferenceName = new atACCFramework.UserControls.TextBoxExt();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblName = new atACCFramework.UserControls.atLabel();
            this.lblAccount = new atACCFramework.UserControls.atLabel();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.errProvider.SetError(this.panel1, resources.GetString("panel1.Error"));
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.panel1, ((int)(resources.GetObject("panel1.IconPadding"))));
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // pnlOptionalBar
            // 
            resources.ApplyResources(this.pnlOptionalBar, "pnlOptionalBar");
            this.pnlOptionalBar.AllowMultiSelect = false;
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.errProvider.SetError(this.pnlOptionalBar, resources.GetString("pnlOptionalBar.Error"));
            this.errProvider.SetIconAlignment(this.pnlOptionalBar, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlOptionalBar.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlOptionalBar, ((int)(resources.GetObject("pnlOptionalBar.IconPadding"))));
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblContry);
            this.pnlMain.Controls.Add(this.txtEmail);
            this.pnlMain.Controls.Add(this.txtState);
            this.pnlMain.Controls.Add(this.txtAdd3);
            this.pnlMain.Controls.Add(this.lblCity);
            this.pnlMain.Controls.Add(this.txtTelephone);
            this.pnlMain.Controls.Add(this.CmbCountry);
            this.pnlMain.Controls.Add(this.lblTelephone);
            this.pnlMain.Controls.Add(this.txtAdd1);
            this.pnlMain.Controls.Add(this.txtPostalcode);
            this.pnlMain.Controls.Add(this.lblState);
            this.pnlMain.Controls.Add(this.lblContactPerson);
            this.pnlMain.Controls.Add(this.lblMobileNumber);
            this.pnlMain.Controls.Add(this.txtAdd2);
            this.pnlMain.Controls.Add(this.txtMobile);
            this.pnlMain.Controls.Add(this.txtContactPerson);
            this.pnlMain.Controls.Add(this.lblAddress3);
            this.pnlMain.Controls.Add(this.lblAddress1);
            this.pnlMain.Controls.Add(this.lblAddress2);
            this.pnlMain.Controls.Add(this.lblPostalCode);
            this.pnlMain.Controls.Add(this.txtCity);
            this.pnlMain.Controls.Add(this.lblEmail);
            this.pnlMain.Controls.Add(this.lblCategory);
            this.pnlMain.Controls.Add(this.cmbCategory);
            this.pnlMain.Controls.Add(this.txtReferenceName);
            this.pnlMain.Controls.Add(this.txtName);
            this.pnlMain.Controls.Add(this.lblName);
            this.pnlMain.Controls.Add(this.lblAccount);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // lblContry
            // 
            resources.ApplyResources(this.lblContry, "lblContry");
            this.errProvider.SetError(this.lblContry, resources.GetString("lblContry.Error"));
            this.errProvider.SetIconAlignment(this.lblContry, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblContry.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblContry, ((int)(resources.GetObject("lblContry.IconPadding"))));
            this.lblContry.Name = "lblContry";
            this.lblContry.RequiredField = false;
            // 
            // txtEmail
            // 
            resources.ApplyResources(this.txtEmail, "txtEmail");
            this.txtEmail.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtEmail, resources.GetString("txtEmail.Error"));
            this.txtEmail.Format = null;
            this.errProvider.SetIconAlignment(this.txtEmail, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtEmail.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtEmail, ((int)(resources.GetObject("txtEmail.IconPadding"))));
            this.txtEmail.isAllowNegative = false;
            this.txtEmail.isAllowSpecialChar = false;
            this.txtEmail.isNumbersOnly = false;
            this.txtEmail.isNumeric = false;
            this.txtEmail.isTouchable = false;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtEmail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEmail_KeyDown);
            // 
            // txtState
            // 
            resources.ApplyResources(this.txtState, "txtState");
            this.txtState.BackColor = System.Drawing.SystemColors.Window;
            this.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtState, resources.GetString("txtState.Error"));
            this.txtState.Format = null;
            this.errProvider.SetIconAlignment(this.txtState, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtState.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtState, ((int)(resources.GetObject("txtState.IconPadding"))));
            this.txtState.isAllowNegative = false;
            this.txtState.isAllowSpecialChar = false;
            this.txtState.isNumbersOnly = false;
            this.txtState.isNumeric = false;
            this.txtState.isTouchable = false;
            this.txtState.Name = "txtState";
            this.txtState.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtAdd3
            // 
            resources.ApplyResources(this.txtAdd3, "txtAdd3");
            this.txtAdd3.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtAdd3, resources.GetString("txtAdd3.Error"));
            this.txtAdd3.Format = null;
            this.errProvider.SetIconAlignment(this.txtAdd3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAdd3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtAdd3, ((int)(resources.GetObject("txtAdd3.IconPadding"))));
            this.txtAdd3.isAllowNegative = false;
            this.txtAdd3.isAllowSpecialChar = false;
            this.txtAdd3.isNumbersOnly = false;
            this.txtAdd3.isNumeric = false;
            this.txtAdd3.isTouchable = false;
            this.txtAdd3.Name = "txtAdd3";
            this.txtAdd3.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblCity
            // 
            resources.ApplyResources(this.lblCity, "lblCity");
            this.errProvider.SetError(this.lblCity, resources.GetString("lblCity.Error"));
            this.errProvider.SetIconAlignment(this.lblCity, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCity.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCity, ((int)(resources.GetObject("lblCity.IconPadding"))));
            this.lblCity.Name = "lblCity";
            this.lblCity.RequiredField = false;
            // 
            // txtTelephone
            // 
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtTelephone, resources.GetString("txtTelephone.Error"));
            this.txtTelephone.Format = null;
            this.errProvider.SetIconAlignment(this.txtTelephone, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtTelephone.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtTelephone, ((int)(resources.GetObject("txtTelephone.IconPadding"))));
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = false;
            this.txtTelephone.isNumeric = true;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // CmbCountry
            // 
            resources.ApplyResources(this.CmbCountry, "CmbCountry");
            this.CmbCountry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CmbCountry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCountry.DropDownHeight = 300;
            this.CmbCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.CmbCountry, resources.GetString("CmbCountry.Error"));
            this.CmbCountry.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.CmbCountry, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("CmbCountry.IconAlignment"))));
            this.errProvider.SetIconPadding(this.CmbCountry, ((int)(resources.GetObject("CmbCountry.IconPadding"))));
            this.CmbCountry.Name = "CmbCountry";
            // 
            // lblTelephone
            // 
            resources.ApplyResources(this.lblTelephone, "lblTelephone");
            this.errProvider.SetError(this.lblTelephone, resources.GetString("lblTelephone.Error"));
            this.errProvider.SetIconAlignment(this.lblTelephone, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTelephone.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTelephone, ((int)(resources.GetObject("lblTelephone.IconPadding"))));
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            // 
            // txtAdd1
            // 
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtAdd1, resources.GetString("txtAdd1.Error"));
            this.txtAdd1.Format = null;
            this.errProvider.SetIconAlignment(this.txtAdd1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAdd1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtAdd1, ((int)(resources.GetObject("txtAdd1.IconPadding"))));
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtPostalcode
            // 
            resources.ApplyResources(this.txtPostalcode, "txtPostalcode");
            this.txtPostalcode.BackColor = System.Drawing.SystemColors.Window;
            this.txtPostalcode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtPostalcode, resources.GetString("txtPostalcode.Error"));
            this.txtPostalcode.Format = null;
            this.errProvider.SetIconAlignment(this.txtPostalcode, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtPostalcode.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtPostalcode, ((int)(resources.GetObject("txtPostalcode.IconPadding"))));
            this.txtPostalcode.isAllowNegative = false;
            this.txtPostalcode.isAllowSpecialChar = true;
            this.txtPostalcode.isNumbersOnly = false;
            this.txtPostalcode.isNumeric = true;
            this.txtPostalcode.isTouchable = false;
            this.txtPostalcode.Name = "txtPostalcode";
            this.txtPostalcode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblState
            // 
            resources.ApplyResources(this.lblState, "lblState");
            this.errProvider.SetError(this.lblState, resources.GetString("lblState.Error"));
            this.errProvider.SetIconAlignment(this.lblState, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblState.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblState, ((int)(resources.GetObject("lblState.IconPadding"))));
            this.lblState.Name = "lblState";
            this.lblState.RequiredField = false;
            // 
            // lblContactPerson
            // 
            resources.ApplyResources(this.lblContactPerson, "lblContactPerson");
            this.errProvider.SetError(this.lblContactPerson, resources.GetString("lblContactPerson.Error"));
            this.errProvider.SetIconAlignment(this.lblContactPerson, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblContactPerson.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblContactPerson, ((int)(resources.GetObject("lblContactPerson.IconPadding"))));
            this.lblContactPerson.Name = "lblContactPerson";
            this.lblContactPerson.RequiredField = false;
            // 
            // lblMobileNumber
            // 
            resources.ApplyResources(this.lblMobileNumber, "lblMobileNumber");
            this.errProvider.SetError(this.lblMobileNumber, resources.GetString("lblMobileNumber.Error"));
            this.errProvider.SetIconAlignment(this.lblMobileNumber, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMobileNumber.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMobileNumber, ((int)(resources.GetObject("lblMobileNumber.IconPadding"))));
            this.lblMobileNumber.Name = "lblMobileNumber";
            this.lblMobileNumber.RequiredField = false;
            // 
            // txtAdd2
            // 
            resources.ApplyResources(this.txtAdd2, "txtAdd2");
            this.txtAdd2.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtAdd2, resources.GetString("txtAdd2.Error"));
            this.txtAdd2.Format = null;
            this.errProvider.SetIconAlignment(this.txtAdd2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAdd2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtAdd2, ((int)(resources.GetObject("txtAdd2.IconPadding"))));
            this.txtAdd2.isAllowNegative = false;
            this.txtAdd2.isAllowSpecialChar = false;
            this.txtAdd2.isNumbersOnly = false;
            this.txtAdd2.isNumeric = false;
            this.txtAdd2.isTouchable = false;
            this.txtAdd2.Name = "txtAdd2";
            this.txtAdd2.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtMobile
            // 
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtMobile, resources.GetString("txtMobile.Error"));
            this.txtMobile.Format = null;
            this.errProvider.SetIconAlignment(this.txtMobile, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtMobile.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtMobile, ((int)(resources.GetObject("txtMobile.IconPadding"))));
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = false;
            this.txtMobile.isNumeric = true;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtContactPerson
            // 
            resources.ApplyResources(this.txtContactPerson, "txtContactPerson");
            this.txtContactPerson.BackColor = System.Drawing.SystemColors.Window;
            this.txtContactPerson.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtContactPerson, resources.GetString("txtContactPerson.Error"));
            this.txtContactPerson.Format = null;
            this.errProvider.SetIconAlignment(this.txtContactPerson, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtContactPerson.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtContactPerson, ((int)(resources.GetObject("txtContactPerson.IconPadding"))));
            this.txtContactPerson.isAllowNegative = false;
            this.txtContactPerson.isAllowSpecialChar = false;
            this.txtContactPerson.isNumbersOnly = false;
            this.txtContactPerson.isNumeric = false;
            this.txtContactPerson.isTouchable = false;
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddress3
            // 
            resources.ApplyResources(this.lblAddress3, "lblAddress3");
            this.errProvider.SetError(this.lblAddress3, resources.GetString("lblAddress3.Error"));
            this.errProvider.SetIconAlignment(this.lblAddress3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddress3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAddress3, ((int)(resources.GetObject("lblAddress3.IconPadding"))));
            this.lblAddress3.Name = "lblAddress3";
            this.lblAddress3.RequiredField = false;
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.errProvider.SetError(this.lblAddress1, resources.GetString("lblAddress1.Error"));
            this.errProvider.SetIconAlignment(this.lblAddress1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddress1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAddress1, ((int)(resources.GetObject("lblAddress1.IconPadding"))));
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // lblAddress2
            // 
            resources.ApplyResources(this.lblAddress2, "lblAddress2");
            this.errProvider.SetError(this.lblAddress2, resources.GetString("lblAddress2.Error"));
            this.errProvider.SetIconAlignment(this.lblAddress2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddress2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAddress2, ((int)(resources.GetObject("lblAddress2.IconPadding"))));
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.RequiredField = false;
            // 
            // lblPostalCode
            // 
            resources.ApplyResources(this.lblPostalCode, "lblPostalCode");
            this.errProvider.SetError(this.lblPostalCode, resources.GetString("lblPostalCode.Error"));
            this.errProvider.SetIconAlignment(this.lblPostalCode, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblPostalCode.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblPostalCode, ((int)(resources.GetObject("lblPostalCode.IconPadding"))));
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.RequiredField = false;
            // 
            // txtCity
            // 
            resources.ApplyResources(this.txtCity, "txtCity");
            this.txtCity.BackColor = System.Drawing.SystemColors.Window;
            this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtCity, resources.GetString("txtCity.Error"));
            this.txtCity.Format = null;
            this.errProvider.SetIconAlignment(this.txtCity, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtCity.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtCity, ((int)(resources.GetObject("txtCity.IconPadding"))));
            this.txtCity.isAllowNegative = false;
            this.txtCity.isAllowSpecialChar = false;
            this.txtCity.isNumbersOnly = false;
            this.txtCity.isNumeric = false;
            this.txtCity.isTouchable = false;
            this.txtCity.Name = "txtCity";
            this.txtCity.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblEmail
            // 
            resources.ApplyResources(this.lblEmail, "lblEmail");
            this.errProvider.SetError(this.lblEmail, resources.GetString("lblEmail.Error"));
            this.errProvider.SetIconAlignment(this.lblEmail, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblEmail.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblEmail, ((int)(resources.GetObject("lblEmail.IconPadding"))));
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.RequiredField = false;
            // 
            // lblCategory
            // 
            resources.ApplyResources(this.lblCategory, "lblCategory");
            this.errProvider.SetError(this.lblCategory, resources.GetString("lblCategory.Error"));
            this.errProvider.SetIconAlignment(this.lblCategory, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCategory.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCategory, ((int)(resources.GetObject("lblCategory.IconPadding"))));
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.RequiredField = false;
            // 
            // cmbCategory
            // 
            resources.ApplyResources(this.cmbCategory, "cmbCategory");
            this.cmbCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCategory.DropDownHeight = 300;
            this.errProvider.SetError(this.cmbCategory, resources.GetString("cmbCategory.Error"));
            this.cmbCategory.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbCategory, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbCategory.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbCategory, ((int)(resources.GetObject("cmbCategory.IconPadding"))));
            this.cmbCategory.Name = "cmbCategory";
            // 
            // txtReferenceName
            // 
            resources.ApplyResources(this.txtReferenceName, "txtReferenceName");
            this.txtReferenceName.BackColor = System.Drawing.SystemColors.Window;
            this.txtReferenceName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtReferenceName, resources.GetString("txtReferenceName.Error"));
            this.txtReferenceName.Format = null;
            this.errProvider.SetIconAlignment(this.txtReferenceName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtReferenceName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtReferenceName, ((int)(resources.GetObject("txtReferenceName.IconPadding"))));
            this.txtReferenceName.isAllowNegative = false;
            this.txtReferenceName.isAllowSpecialChar = false;
            this.txtReferenceName.isNumbersOnly = false;
            this.txtReferenceName.isNumeric = false;
            this.txtReferenceName.isTouchable = false;
            this.txtReferenceName.Name = "txtReferenceName";
            this.txtReferenceName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtName, resources.GetString("txtName.Error"));
            this.txtName.Format = null;
            this.errProvider.SetIconAlignment(this.txtName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtName, ((int)(resources.GetObject("txtName.IconPadding"))));
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = false;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.errProvider.SetError(this.lblName, resources.GetString("lblName.Error"));
            this.errProvider.SetIconAlignment(this.lblName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblName, ((int)(resources.GetObject("lblName.IconPadding"))));
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // lblAccount
            // 
            resources.ApplyResources(this.lblAccount, "lblAccount");
            this.errProvider.SetError(this.lblAccount, resources.GetString("lblAccount.Error"));
            this.errProvider.SetIconAlignment(this.lblAccount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAccount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAccount, ((int)(resources.GetObject("lblAccount.IconPadding"))));
            this.lblAccount.Name = "lblAccount";
            this.lblAccount.RequiredField = false;
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.errProvider.SetError(this.lblMandatory2, resources.GetString("lblMandatory2.Error"));
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory2, ((int)(resources.GetObject("lblMandatory2.IconPadding"))));
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // ContactBookView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlOptionalBar);
            this.Name = "ContactBookView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.ContactBookView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.ContactBookView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.ContactBookView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.ContactBookView_atNewClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.ContactBookView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.ContactBookView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.ContactBookView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.ContactBookView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.ContactBookView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.ContactBookView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.ContactBookView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atLabel lblCategory;
        private atACCFramework.UserControls.ComboBoxExt cmbCategory;
        private atACCFramework.UserControls.TextBoxExt txtReferenceName;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private atACCFramework.UserControls.atLabel lblName;
        private atACCFramework.UserControls.atLabel lblAccount;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atLabel lblContry;
        private atACCFramework.UserControls.TextBoxExt txtEmail;
        private atACCFramework.UserControls.TextBoxExt txtState;
        private atACCFramework.UserControls.TextBoxExt txtAdd3;
        private atACCFramework.UserControls.atLabel lblCity;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.ComboBoxExt CmbCountry;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.TextBoxExt txtPostalcode;
        private atACCFramework.UserControls.atLabel lblState;
        private atACCFramework.UserControls.atLabel lblContactPerson;
        private atACCFramework.UserControls.atLabel lblMobileNumber;
        private atACCFramework.UserControls.TextBoxExt txtAdd2;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.TextBoxExt txtContactPerson;
        private atACCFramework.UserControls.atLabel lblAddress3;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.atLabel lblAddress2;
        private atACCFramework.UserControls.atLabel lblPostalCode;
        private atACCFramework.UserControls.TextBoxExt txtCity;
        private atACCFramework.UserControls.atLabel lblEmail;
    }
}