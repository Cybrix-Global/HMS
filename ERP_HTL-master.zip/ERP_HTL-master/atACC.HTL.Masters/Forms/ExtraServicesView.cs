﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class ExtraServicesView : SearchFormBase2
    {
        #region Constructor
        public ExtraServicesView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_ExtraServicesView;
        }
        #endregion

        #region Private Variable
        ExtraServices entExtraService;
        List<ExtraServices> entExtraServices;
        List<ExtraServiceSlabs> entExtraServicesSlabs;
        ExtraServiceSlabs entExtraServiceDiscount;
        ExtraServiceSlabs entExtraServiceExDuty;
        ExtraServiceSlabs entExtraServiceTax1;
        ExtraServiceSlabs entExtraServiceTax2;
        ExtraServiceSlabs entExtraServiceTax3;
        ExtraServiceSlabs entExtraServiceAddlTax;
        ExtraServiceSlabs entExtraServiceVAT;
        ExtraServiceSlabs entExtraServiceGST;
        atACCHotelEntities dbh;
        CommonLibClasses objLib = new CommonLibClasses();
        ANIHelper aniHelper;
        string m_NumberFormat;
        ToolTip tooltip;
        bool onLoad = true;
        #endregion

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_ExtraServices, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateExtras()
        {
            try
            {
                entExtraServices = dbh.ExtraServices.Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID))).OrderBy(x => x.Name).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateSlabs()
        {
            try
            {
                #region Discount
                List<Slab> entDiscountSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.Discount).OrderBy(x => x.Name).ToList();
                Slab entDiscountSlab;
                entDiscountSlab = new Slab();
                entDiscountSlab.id = 0;
                entDiscountSlab.Name = MessageKeys.MsgNone;
                entDiscountSlabs.Insert(0, entDiscountSlab);
                objLib.fnFillCombo(ref cmbDiscount, entDiscountSlabs, "Name", "id");
                cmbDiscount.SelectedIndex = -1;
                #endregion

                #region ExciseDuty
                List<Slab> entExciseDutySlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.ExciseDuty).OrderBy(x => x.Name).ToList();
                Slab entExciseDutySlab;
                entExciseDutySlab = new Slab();
                entExciseDutySlab.id = 0;
                entExciseDutySlab.Name = MessageKeys.MsgNone;
                entExciseDutySlabs.Insert(0, entExciseDutySlab);
                objLib.fnFillCombo(ref cmbExciseDuty, entExciseDutySlabs, "Name", "id");
                cmbExciseDuty.SelectedIndex = -1;
                #endregion

                #region Tax1
                List<Slab> entTax1Slabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX1).OrderBy(x => x.Name).ToList();
                Slab entTax1Slab;
                entTax1Slab = new Slab();
                entTax1Slab.id = 0;
                entTax1Slab.Name = MessageKeys.MsgNone;
                entTax1Slabs.Insert(0, entTax1Slab);
                objLib.fnFillCombo(ref cmbTax1, entTax1Slabs, "Name", "id");
                cmbTax1.SelectedIndex = -1;
                #endregion

                #region Tax2
                List<Slab> entTax2Slabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX2).OrderBy(x => x.Name).ToList();
                Slab entTax2Slab;
                entTax2Slab = new Slab();
                entTax2Slab.id = 0;
                entTax2Slab.Name = MessageKeys.MsgNone;
                entTax2Slabs.Insert(0, entTax2Slab);
                objLib.fnFillCombo(ref cmbTax2, entTax2Slabs, "Name", "id");
                cmbTax2.SelectedIndex = -1;
                #endregion

                #region Tax3
                List<Slab> entTax3Slabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX3).OrderBy(x => x.Name).ToList();
                Slab entTax3Slab;
                entTax3Slab = new Slab();
                entTax3Slab.id = 0;
                entTax3Slab.Name = MessageKeys.MsgNone;
                entTax3Slabs.Insert(0, entTax3Slab);
                objLib.fnFillCombo(ref cmbTax3, entTax3Slabs, "Name", "id");
                cmbTax3.SelectedIndex = -1;
                #endregion

                #region Additional Tax
                List<Slab> entAdditionalTaxSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.AdditionalTax).OrderBy(x => x.Name).ToList();
                Slab entAdditionalTaxSlab;
                entAdditionalTaxSlab = new Slab();
                entAdditionalTaxSlab.id = 0;
                entAdditionalTaxSlab.Name = MessageKeys.MsgNone;
                entAdditionalTaxSlabs.Insert(0, entAdditionalTaxSlab);
                objLib.fnFillCombo(ref cmbAddlTax, entAdditionalTaxSlabs, "Name", "id");
                cmbAddlTax.SelectedIndex = -1;
                #endregion

                #region VAT
                List<Slab> entVATSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.VAT).OrderBy(x => x.Name).ToList();
                Slab entVATSlab;
                entVATSlab = new Slab();
                entVATSlab.id = 0;
                entVATSlab.Name = MessageKeys.MsgNone;
                entVATSlabs.Insert(0, entVATSlab);
                objLib.fnFillCombo(ref cmbVAT, entVATSlabs, "Name", "id");
                cmbVAT.SelectedIndex = -1;
                #endregion

                #region GST
                List<Slab> entGSTSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.GST).OrderBy(x => x.Name).ToList();
                Slab entGSTSlab;
                entGSTSlab = new Slab();
                entGSTSlab.id = 0;
                entGSTSlab.Name = MessageKeys.MsgNone;
                entGSTSlabs.Insert(0, entGSTSlab);
                objLib.fnFillCombo(ref cmbGST, entGSTSlabs, "Name", "id");
                cmbGST.SelectedIndex = -1;
                #endregion
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateType()
        {
            var items = new[] {
                      new { Text = MessageKeys.MsgDefault, Value = "0" },
                      new { Text = MessageKeys.MsgLaundry, Value = "1" },
                      new { Text = MessageKeys.MsgRoomService, Value = "2" },
            };
            cmbType.DisplayMember = "Text";
            cmbType.ValueMember = "Value";
            cmbType.DataSource = items;
        }
        private void EnableSlabsComboBasedonSetting()
        {
            try
            {
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableSlabDiscount))
                {
                    lblDiscount.Enabled = false;
                    cmbDiscount.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableExciseDuty))
                {
                    lblExciseDuty.Enabled = false;
                    cmbExciseDuty.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableTAX1))
                {
                    lblTax1.Enabled = false;
                    cmbTax1.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableTAX2))
                {
                    lblTax2.Enabled = false;
                    cmbTax2.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableTAX3))
                {
                    lblTax3.Enabled = false;
                    cmbTax3.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableAddnlTax))
                {
                    lblAdditionalTax.Enabled = false;
                    cmbAddlTax.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableVAT))
                {
                    lblVAT.Enabled = false;
                    cmbVAT.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableGST))
                {
                    lblGST.Enabled = false;
                    cmbGST.Enabled = false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SetSlabsCaption()
        {
            try
            {
                if (GlobalFunctions.LanguageCulture == "en-US")
                {
                    lblDiscount.Text = GlobalFunctions.strSlabDiscountName;
                    lblExciseDuty.Text = GlobalFunctions.strSlabExciseDutyName;
                    lblTax1.Text = GlobalFunctions.strSlabTAX1Name;
                    lblTax2.Text = GlobalFunctions.strSlabTAX2Name;
                    lblTax3.Text = GlobalFunctions.strSlabTAX3Name;
                    lblAdditionalTax.Text = GlobalFunctions.strSlabAdditionalTaxName;
                    lblVAT.Text = GlobalFunctions.strSlabVATName;
                    lblGST.Text = GlobalFunctions.strSlabGSTName;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                m_NumberFormat = "N" + GlobalFunctions.CompanyNoofDecimals;
                txtDefaultRate.Format = m_NumberFormat;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ClearEntities()
        {
            entExtraService = null;
            entExtraServiceDiscount = null;
            entExtraServiceExDuty = null;
            entExtraServiceTax1 = null;
            entExtraServiceTax2 = null;
            entExtraServiceTax3 = null;
            entExtraServiceAddlTax = null;
            entExtraServiceVAT = null;
            entExtraServiceGST = null;
        }
        #endregion

        #region Form Events
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    ExtraServices exservice = dbh.ExtraServices.Where(x => x.Code == txtCode.Text.Trim())
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (exservice != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(exservice.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbDiscount_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbExciseDuty.Enabled && !cmbTax1.Enabled && !cmbTax2.Enabled
                    && !cmbTax3.Enabled && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbExciseDuty_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbTax1.Enabled && !cmbTax2.Enabled
                            && !cmbTax3.Enabled && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        private void cmbTax1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbTax2.Enabled && !cmbTax3.Enabled 
                            && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbTax2_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbTax3.Enabled && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbTax3_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbAddlTax_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbVAT_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbGST_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region Framework Events
        private void ExtraServicesView_atInitialise()
        {
            try
            {
                objLib = new CommonLibClasses();
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                entExtraService = new ExtraServices();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void ExtraServicesView_atAfterInitialise()
        {
            try
            {
                PopulateExtras();
                PopulateSlabs();
                EnableSlabsComboBasedonSetting();
                PopulateType();
                SetSlabsCaption();
                LoadSettings();
                GetSeqNo();
                rbtActive.Checked = true;
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void ExtraServicesView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                ClearEntities();
                PopulateExtras();
                PopulateSlabs();
                PopulateType();
                EnableSlabsComboBasedonSetting();
                GetSeqNo();
                rbtActive.Checked = true;
                txtCode.Focus();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool ExtraServicesView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == "")
                {
                    errProvider.SetError(txtCode, MessageKeys.MsgCodeMustBeEntered);
                    txtCode.Focus();
                    return false;
                }
                if (txtName.Text.Trim() == "")
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool ExtraServicesView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    entExtraService = new ExtraServices();
                }
                entExtraService.ContextID = iContextID;
                entExtraService.LoginUserID = GlobalFunctions.LoginUserID;
                entExtraService.LocationID = GlobalFunctions.LoginLocationID;
                entExtraService.Code = txtCode.Text;
                entExtraService.Name = txtName.Text;
                entExtraService.Rate = txtDefaultRate.Value;
                entExtraService.Type = cmbType.SelectedValue.ToInt32();
                entExtraService.Active = rbtActive.Checked ? true : false;
                if (NewRecord)
                {
                    dbh.ExtraServices.AddObject(entExtraService);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(entExtraService, EntityState.Modified);
                }

                bool NewObject;

                #region Discount Slabs
                if (cmbDiscount.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceDiscount == null)
                    {
                        entExtraServiceDiscount = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceDiscount.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceDiscount.FK_SlabTypeID = (int)ENMVMTSlabType.Discount;
                    entExtraServiceDiscount.FK_SlabID = cmbDiscount.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceDiscount);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceDiscount, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceDiscount != null && entExtraServiceDiscount.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceDiscount);
                    }
                }
                #endregion

                #region Excise Duty Slabs
                if (cmbExciseDuty.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceExDuty == null)
                    {
                        entExtraServiceExDuty = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceExDuty.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceExDuty.FK_SlabTypeID = (int)ENMVMTSlabType.ExciseDuty;
                    entExtraServiceExDuty.FK_SlabID = cmbExciseDuty.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceExDuty);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceExDuty, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceExDuty != null && entExtraServiceExDuty.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceExDuty);
                    }
                }
                #endregion

                #region Tax 1 Slabs
                if (cmbTax1.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceTax1 == null)
                    {
                        entExtraServiceTax1 = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceTax1.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceTax1.FK_SlabTypeID = (int)ENMVMTSlabType.TAX1;
                    entExtraServiceTax1.FK_SlabID = cmbTax1.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceTax1);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceTax1, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceTax1 != null && entExtraServiceTax1.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceTax1);
                    }
                }
                #endregion

                #region Tax 2 Slabs
                if (cmbTax2.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceTax2 == null)
                    {
                        entExtraServiceTax2 = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceTax2.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceTax2.FK_SlabTypeID = (int)ENMVMTSlabType.TAX2;
                    entExtraServiceTax2.FK_SlabID = cmbTax2.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceTax2);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceTax2, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceTax2 != null && entExtraServiceTax2.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceTax2);
                    }
                }
                #endregion

                #region Tax 3 Slabs
                if (cmbTax3.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceTax3 == null)
                    {
                        entExtraServiceTax3 = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceTax3.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceTax3.FK_SlabTypeID = (int)ENMVMTSlabType.TAX3;
                    entExtraServiceTax3.FK_SlabID = cmbTax3.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceTax3);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceTax3, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceTax3 != null && entExtraServiceTax3.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceTax3);
                    }
                }
                #endregion

                #region Additional Tax Slabs
                if (cmbAddlTax.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceAddlTax == null)
                    {
                        entExtraServiceAddlTax = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceAddlTax.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceAddlTax.FK_SlabTypeID = (int)ENMVMTSlabType.AdditionalTax;
                    entExtraServiceAddlTax.FK_SlabID = cmbAddlTax.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceAddlTax);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceAddlTax, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceAddlTax != null && entExtraServiceAddlTax.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceAddlTax);
                    }
                }
                #endregion

                #region VAT Slabs
                if (cmbVAT.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceVAT == null)
                    {
                        entExtraServiceVAT = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceVAT.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceVAT.FK_SlabTypeID = (int)ENMVMTSlabType.VAT;
                    entExtraServiceVAT.FK_SlabID = cmbVAT.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceVAT);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceVAT, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceVAT != null && entExtraServiceVAT.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceVAT);
                    }
                }
                #endregion

                #region GST Slabs
                if (cmbGST.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entExtraServiceGST == null)
                    {
                        entExtraServiceGST = new ExtraServiceSlabs();
                        NewObject = true;
                    }
                    entExtraServiceGST.FK_ExtraServiceID = entExtraService.id;
                    entExtraServiceGST.FK_SlabTypeID = (int)ENMVMTSlabType.GST;
                    entExtraServiceGST.FK_SlabID = cmbGST.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.ExtraServiceSlabs.AddObject(entExtraServiceGST);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entExtraServiceGST, EntityState.Modified);
                    }
                }
                else
                {
                    if (entExtraServiceGST != null && entExtraServiceGST.id != 0)
                    {
                        dbh.ExtraServiceSlabs.DeleteObject(entExtraServiceGST);
                    }
                }
                #endregion

                dbh.SaveChanges();
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_ExtraServicesCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return ExtraServicesView_atSaveClick(source, e);
                    }
                    else if (updEx.InnerException.Message.Contains("UC_ExtraServicesName"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgExtraService + " (" + txtName.Text + ") "
                            + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                        txtName.Focus();
                        return false;
                    }
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool ExtraServicesView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void ExtraServicesView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vExtras= entExtraServices.Select(x => new { id = x.id, Code = x.Code, Name = x.Name }).OrderByDescending(x => x.id);
                e.SearchEntityList = vExtras;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entExtraService = dbh.ExtraServices.Where(x => x.id == ID).SingleOrDefault();
                if (entExtraService != null)
                {
                    txtCode.Text = entExtraService.Code;
                    txtName.Text = entExtraService.Name;
                    txtDefaultRate.Value = entExtraService.Rate.ToDecimal();
                    PopulateType();
                    if (entExtraService.Type != null)
                    {
                        if (entExtraService.Type == 0)
                        {
                            cmbType.Text = MessageKeys.MsgDefault;
                        }
                        if (entExtraService.Type == 1)
                        {
                            cmbType.Text = MessageKeys.MsgLaundry;
                        }
                        if (entExtraService.Type == 2)
                        {
                            cmbType.Text = MessageKeys.MsgRoomService;
                        }
                    }
                    if (entExtraService.Active == true)
                    {
                        rbtActive.Checked = true;
                    }
                    else { rbtInactive.Checked = true; }

                    List<ExtraServiceSlabs> entExtraServiceSlabs = dbh.ExtraServiceSlabs.Where(x => x.FK_ExtraServiceID == entExtraService.id).ToList();
                    if (entExtraServiceSlabs.Count > 0)
                    {
                        entExtraServiceDiscount = entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.Discount).SingleOrDefault();
                        if (entExtraServiceDiscount != null)
                        {
                            cmbDiscount.SelectedValue = entExtraServiceDiscount.FK_SlabID.toInt32();
                        }

                        entExtraServiceExDuty= entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.ExciseDuty).SingleOrDefault();
                        if (entExtraServiceExDuty != null)
                        {
                            cmbExciseDuty.SelectedValue = entExtraServiceExDuty.FK_SlabID.toInt32();
                        }

                        entExtraServiceTax1 = entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.TAX1).SingleOrDefault();
                        if (entExtraServiceTax1 != null)
                        {
                            cmbTax1.SelectedValue = entExtraServiceTax1.FK_SlabID.toInt32();
                        }

                        entExtraServiceTax2 = entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.TAX2).SingleOrDefault();
                        if (entExtraServiceTax2 != null)
                        {
                            cmbTax2.SelectedValue = entExtraServiceTax2.FK_SlabID.toInt32();
                        }

                        entExtraServiceTax3 = entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.TAX3).SingleOrDefault();
                        if (entExtraServiceTax3 != null)
                        {
                            cmbTax3.SelectedValue = entExtraServiceTax3.FK_SlabID.toInt32();
                        }

                        entExtraServiceAddlTax = entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.AdditionalTax).SingleOrDefault();
                        if (entExtraServiceAddlTax != null)
                        {
                            cmbAddlTax.SelectedValue = entExtraServiceAddlTax.FK_SlabID.toInt32();
                        }

                        entExtraServiceVAT = entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.VAT).SingleOrDefault();
                        if (entExtraServiceVAT != null)
                        {
                            cmbVAT.SelectedValue = entExtraServiceVAT.FK_SlabID.toInt32();
                        }

                        entExtraServiceGST = entExtraServiceSlabs.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.GST).SingleOrDefault();
                        if (entExtraServiceGST != null)
                        {
                            cmbGST.SelectedValue = entExtraServiceGST.FK_SlabID.toInt32();
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool ExtraServicesView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vExtraService = new { id = 0, Code = "", Name = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vExtraService).id);
                }
                else 
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool ExtraServicesView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtCode.Focus();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void ExtraServicesView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                EnableSlabsComboBasedonSetting();
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool ExtraServicesView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                if (entExtraServiceDiscount != null) { dbh.DeleteObject(entExtraServiceDiscount); }
                if (entExtraServiceExDuty != null) { dbh.DeleteObject(entExtraServiceExDuty); }
                if (entExtraServiceTax1 != null) { dbh.DeleteObject(entExtraServiceTax1); }
                if (entExtraServiceTax2 != null) { dbh.DeleteObject(entExtraServiceTax2); }
                if (entExtraServiceTax3 != null) { dbh.DeleteObject(entExtraServiceTax3); }
                if (entExtraServiceAddlTax != null) { dbh.DeleteObject(entExtraServiceAddlTax); }
                if (entExtraServiceVAT != null) { dbh.DeleteObject(entExtraServiceVAT); }
                if (entExtraServiceGST != null) { dbh.DeleteObject(entExtraServiceGST); }
                if (entExtraService != null) { dbh.DeleteObject(entExtraService); }
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void ExtraServicesView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
