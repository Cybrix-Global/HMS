﻿namespace atACC.HTL.Masters
{
    partial class HallTypesView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HallTypesView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.TabRateType = new atACCFramework.UserControls.atTabControl();
            this.tabAmenity = new System.Windows.Forms.TabPage();
            this.btnSepearator0 = new System.Windows.Forms.Button();
            this.lblAmenity = new atACCFramework.UserControls.atLabel();
            this.dgAmenity = new atACCFramework.UserControls.atGridView();
            this.Col_SlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Amenity = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.tabSlabs = new System.Windows.Forms.TabPage();
            this.btnSepearator1 = new System.Windows.Forms.Button();
            this.lblSlabs = new atACCFramework.UserControls.atLabel();
            this.lblExciseDuty = new atACCFramework.UserControls.atLabel();
            this.cmbTax3 = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbAddlTax = new atACCFramework.UserControls.ComboBoxExt();
            this.lblAdditionalTax = new atACCFramework.UserControls.atLabel();
            this.cmbTax2 = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbTax1 = new atACCFramework.UserControls.ComboBoxExt();
            this.lblTax3 = new atACCFramework.UserControls.atLabel();
            this.lblDiscount = new atACCFramework.UserControls.atLabel();
            this.cmbExciseDuty = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGST = new atACCFramework.UserControls.atLabel();
            this.cmbDiscount = new atACCFramework.UserControls.ComboBoxExt();
            this.lblVAT = new atACCFramework.UserControls.atLabel();
            this.lblTax2 = new atACCFramework.UserControls.atLabel();
            this.lblTax1 = new atACCFramework.UserControls.atLabel();
            this.cmbGST = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbVAT = new atACCFramework.UserControls.ComboBoxExt();
            this.pnlTabContain = new atACCFramework.UserControls.atPanel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.btnColor = new System.Windows.Forms.Button();
            this.lblColor = new atACCFramework.UserControls.atLabel();
            this.lblAddlPersonRate = new atACCFramework.UserControls.atLabel();
            this.txtAddlPersonRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddlBedRate = new atACCFramework.UserControls.atLabel();
            this.txtAddlBedRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblDefaultRate = new atACCFramework.UserControls.atLabel();
            this.txtDefaultRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblExtraBeds = new atACCFramework.UserControls.atLabel();
            this.txtExtraBeds = new atACCFramework.UserControls.TextBoxExt();
            this.lblChild = new atACCFramework.UserControls.atLabel();
            this.lblAdult = new atACCFramework.UserControls.atLabel();
            this.txtChild = new atACCFramework.UserControls.TextBoxExt();
            this.txtAdult = new atACCFramework.UserControls.TextBoxExt();
            this.lblDescription = new atACCFramework.UserControls.atLabel();
            this.txtDescription = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.txtCode = new atACCFramework.UserControls.TextBoxExt();
            this.rbtActive = new atACCFramework.UserControls.atRadioButton();
            this.lblCode = new atACCFramework.UserControls.atLabel();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblName = new atACCFramework.UserControls.atLabel();
            this.rbtInactive = new atACCFramework.UserControls.atRadioButton();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            this.btnSelected = new atACCFramework.UserControls.atGradientPanel();
            this.atImageframe = new atACCFramework.UserControls.atImageFrame();
            this.btnSlabs = new System.Windows.Forms.Button();
            this.btnAmenities = new System.Windows.Forms.Button();
            this.bindAmenity = new System.Windows.Forms.BindingSource(this.components);
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.TabRateType.SuspendLayout();
            this.tabAmenity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgAmenity)).BeginInit();
            this.tabSlabs.SuspendLayout();
            this.pnlTabContain.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlOptionalBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindAmenity)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            // 
            // TabRateType
            // 
            resources.ApplyResources(this.TabRateType, "TabRateType");
            this.TabRateType.Controls.Add(this.tabAmenity);
            this.TabRateType.Controls.Add(this.tabSlabs);
            this.TabRateType.Name = "TabRateType";
            this.TabRateType.SelectedIndex = 0;
            // 
            // tabAmenity
            // 
            this.tabAmenity.BackColor = System.Drawing.SystemColors.Window;
            this.tabAmenity.Controls.Add(this.btnSepearator0);
            this.tabAmenity.Controls.Add(this.lblAmenity);
            this.tabAmenity.Controls.Add(this.dgAmenity);
            resources.ApplyResources(this.tabAmenity, "tabAmenity");
            this.tabAmenity.Name = "tabAmenity";
            // 
            // btnSepearator0
            // 
            this.btnSepearator0.BackColor = System.Drawing.Color.LightGray;
            this.btnSepearator0.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSepearator0.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSepearator0, "btnSepearator0");
            this.btnSepearator0.Name = "btnSepearator0";
            this.btnSepearator0.UseVisualStyleBackColor = false;
            // 
            // lblAmenity
            // 
            resources.ApplyResources(this.lblAmenity, "lblAmenity");
            this.lblAmenity.Name = "lblAmenity";
            this.lblAmenity.RequiredField = false;
            // 
            // dgAmenity
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgAmenity.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAmenity.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            resources.ApplyResources(this.dgAmenity, "dgAmenity");
            this.dgAmenity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgAmenity.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_SlNo,
            this.Col_Amenity});
            this.dgAmenity.EnableHeadersVisualStyles = false;
            this.dgAmenity.EnterKeyNavigation = false;
            this.dgAmenity.LastKey = System.Windows.Forms.Keys.None;
            this.dgAmenity.Name = "dgAmenity";
            this.dgAmenity.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgAmenity.sGridID = null;
            this.dgAmenity.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgAmenity_RowsAdded);
            this.dgAmenity.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgAmenity_RowsRemoved);
            // 
            // Col_SlNo
            // 
            resources.ApplyResources(this.Col_SlNo, "Col_SlNo");
            this.Col_SlNo.Name = "Col_SlNo";
            this.Col_SlNo.ReadOnly = true;
            // 
            // Col_Amenity
            // 
            this.Col_Amenity.DataPropertyName = "FK_AmenityID";
            this.Col_Amenity.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.Col_Amenity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.Col_Amenity, "Col_Amenity");
            this.Col_Amenity.Name = "Col_Amenity";
            // 
            // tabSlabs
            // 
            this.tabSlabs.BackColor = System.Drawing.SystemColors.Window;
            this.tabSlabs.Controls.Add(this.btnSepearator1);
            this.tabSlabs.Controls.Add(this.lblSlabs);
            this.tabSlabs.Controls.Add(this.lblExciseDuty);
            this.tabSlabs.Controls.Add(this.cmbTax3);
            this.tabSlabs.Controls.Add(this.cmbAddlTax);
            this.tabSlabs.Controls.Add(this.lblAdditionalTax);
            this.tabSlabs.Controls.Add(this.cmbTax2);
            this.tabSlabs.Controls.Add(this.cmbTax1);
            this.tabSlabs.Controls.Add(this.lblTax3);
            this.tabSlabs.Controls.Add(this.lblDiscount);
            this.tabSlabs.Controls.Add(this.cmbExciseDuty);
            this.tabSlabs.Controls.Add(this.lblGST);
            this.tabSlabs.Controls.Add(this.cmbDiscount);
            this.tabSlabs.Controls.Add(this.lblVAT);
            this.tabSlabs.Controls.Add(this.lblTax2);
            this.tabSlabs.Controls.Add(this.lblTax1);
            this.tabSlabs.Controls.Add(this.cmbGST);
            this.tabSlabs.Controls.Add(this.cmbVAT);
            resources.ApplyResources(this.tabSlabs, "tabSlabs");
            this.tabSlabs.Name = "tabSlabs";
            // 
            // btnSepearator1
            // 
            this.btnSepearator1.BackColor = System.Drawing.Color.LightGray;
            this.btnSepearator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSepearator1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnSepearator1, "btnSepearator1");
            this.btnSepearator1.Name = "btnSepearator1";
            this.btnSepearator1.UseVisualStyleBackColor = false;
            // 
            // lblSlabs
            // 
            resources.ApplyResources(this.lblSlabs, "lblSlabs");
            this.lblSlabs.Name = "lblSlabs";
            this.lblSlabs.RequiredField = false;
            // 
            // lblExciseDuty
            // 
            resources.ApplyResources(this.lblExciseDuty, "lblExciseDuty");
            this.lblExciseDuty.Name = "lblExciseDuty";
            this.lblExciseDuty.RequiredField = false;
            // 
            // cmbTax3
            // 
            resources.ApplyResources(this.cmbTax3, "cmbTax3");
            this.cmbTax3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax3.DropDownHeight = 300;
            this.cmbTax3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTax3.FormattingEnabled = true;
            this.cmbTax3.Name = "cmbTax3";
            this.cmbTax3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTax3_KeyDown);
            // 
            // cmbAddlTax
            // 
            resources.ApplyResources(this.cmbAddlTax, "cmbAddlTax");
            this.cmbAddlTax.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAddlTax.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAddlTax.DropDownHeight = 300;
            this.cmbAddlTax.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddlTax.FormattingEnabled = true;
            this.cmbAddlTax.Name = "cmbAddlTax";
            this.cmbAddlTax.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbAddlTax_KeyDown);
            // 
            // lblAdditionalTax
            // 
            resources.ApplyResources(this.lblAdditionalTax, "lblAdditionalTax");
            this.lblAdditionalTax.Name = "lblAdditionalTax";
            this.lblAdditionalTax.RequiredField = false;
            // 
            // cmbTax2
            // 
            resources.ApplyResources(this.cmbTax2, "cmbTax2");
            this.cmbTax2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax2.DropDownHeight = 300;
            this.cmbTax2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTax2.FormattingEnabled = true;
            this.cmbTax2.Name = "cmbTax2";
            this.cmbTax2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTax2_KeyDown);
            // 
            // cmbTax1
            // 
            resources.ApplyResources(this.cmbTax1, "cmbTax1");
            this.cmbTax1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax1.DropDownHeight = 300;
            this.cmbTax1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTax1.FormattingEnabled = true;
            this.cmbTax1.Name = "cmbTax1";
            this.cmbTax1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTax1_KeyDown);
            // 
            // lblTax3
            // 
            resources.ApplyResources(this.lblTax3, "lblTax3");
            this.lblTax3.Name = "lblTax3";
            this.lblTax3.RequiredField = false;
            // 
            // lblDiscount
            // 
            resources.ApplyResources(this.lblDiscount, "lblDiscount");
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.RequiredField = false;
            // 
            // cmbExciseDuty
            // 
            resources.ApplyResources(this.cmbExciseDuty, "cmbExciseDuty");
            this.cmbExciseDuty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbExciseDuty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbExciseDuty.DropDownHeight = 300;
            this.cmbExciseDuty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbExciseDuty.FormattingEnabled = true;
            this.cmbExciseDuty.Name = "cmbExciseDuty";
            this.cmbExciseDuty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbExciseDuty_KeyDown);
            // 
            // lblGST
            // 
            resources.ApplyResources(this.lblGST, "lblGST");
            this.lblGST.Name = "lblGST";
            this.lblGST.RequiredField = false;
            // 
            // cmbDiscount
            // 
            resources.ApplyResources(this.cmbDiscount, "cmbDiscount");
            this.cmbDiscount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbDiscount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDiscount.BackColor = System.Drawing.SystemColors.Window;
            this.cmbDiscount.DropDownHeight = 300;
            this.cmbDiscount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDiscount.FormattingEnabled = true;
            this.cmbDiscount.Name = "cmbDiscount";
            this.cmbDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbDiscount_KeyDown);
            // 
            // lblVAT
            // 
            resources.ApplyResources(this.lblVAT, "lblVAT");
            this.lblVAT.Name = "lblVAT";
            this.lblVAT.RequiredField = false;
            // 
            // lblTax2
            // 
            resources.ApplyResources(this.lblTax2, "lblTax2");
            this.lblTax2.Name = "lblTax2";
            this.lblTax2.RequiredField = false;
            // 
            // lblTax1
            // 
            resources.ApplyResources(this.lblTax1, "lblTax1");
            this.lblTax1.Name = "lblTax1";
            this.lblTax1.RequiredField = false;
            // 
            // cmbGST
            // 
            resources.ApplyResources(this.cmbGST, "cmbGST");
            this.cmbGST.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGST.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGST.DropDownHeight = 300;
            this.cmbGST.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGST.FormattingEnabled = true;
            this.cmbGST.Name = "cmbGST";
            this.cmbGST.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbGST_KeyDown);
            // 
            // cmbVAT
            // 
            resources.ApplyResources(this.cmbVAT, "cmbVAT");
            this.cmbVAT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbVAT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVAT.DropDownHeight = 300;
            this.cmbVAT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVAT.FormattingEnabled = true;
            this.cmbVAT.Name = "cmbVAT";
            this.cmbVAT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbVAT_KeyDown);
            // 
            // pnlTabContain
            // 
            resources.ApplyResources(this.pnlTabContain, "pnlTabContain");
            this.pnlTabContain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlTabContain.Controls.Add(this.TabRateType);
            this.pnlTabContain.Name = "pnlTabContain";
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.btnColor);
            this.pnlMain.Controls.Add(this.lblColor);
            this.pnlMain.Controls.Add(this.lblAddlPersonRate);
            this.pnlMain.Controls.Add(this.txtAddlPersonRate);
            this.pnlMain.Controls.Add(this.lblAddlBedRate);
            this.pnlMain.Controls.Add(this.txtAddlBedRate);
            this.pnlMain.Controls.Add(this.lblDefaultRate);
            this.pnlMain.Controls.Add(this.txtDefaultRate);
            this.pnlMain.Controls.Add(this.lblExtraBeds);
            this.pnlMain.Controls.Add(this.txtExtraBeds);
            this.pnlMain.Controls.Add(this.lblChild);
            this.pnlMain.Controls.Add(this.lblAdult);
            this.pnlMain.Controls.Add(this.txtChild);
            this.pnlMain.Controls.Add(this.txtAdult);
            this.pnlMain.Controls.Add(this.lblDescription);
            this.pnlMain.Controls.Add(this.txtDescription);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.txtCode);
            this.pnlMain.Controls.Add(this.rbtActive);
            this.pnlMain.Controls.Add(this.lblCode);
            this.pnlMain.Controls.Add(this.txtName);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblName);
            this.pnlMain.Controls.Add(this.rbtInactive);
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Name = "pnlMain";
            // 
            // btnColor
            // 
            this.btnColor.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.btnColor, "btnColor");
            this.btnColor.ForeColor = System.Drawing.Color.White;
            this.btnColor.Name = "btnColor";
            this.btnColor.TabStop = false;
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // lblColor
            // 
            resources.ApplyResources(this.lblColor, "lblColor");
            this.lblColor.Name = "lblColor";
            this.lblColor.RequiredField = false;
            // 
            // lblAddlPersonRate
            // 
            resources.ApplyResources(this.lblAddlPersonRate, "lblAddlPersonRate");
            this.lblAddlPersonRate.Name = "lblAddlPersonRate";
            this.lblAddlPersonRate.RequiredField = false;
            // 
            // txtAddlPersonRate
            // 
            resources.ApplyResources(this.txtAddlPersonRate, "txtAddlPersonRate");
            this.txtAddlPersonRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddlPersonRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddlPersonRate.Format = null;
            this.txtAddlPersonRate.isAllowNegative = false;
            this.txtAddlPersonRate.isAllowSpecialChar = false;
            this.txtAddlPersonRate.isNumbersOnly = false;
            this.txtAddlPersonRate.isNumeric = true;
            this.txtAddlPersonRate.isTouchable = true;
            this.txtAddlPersonRate.Name = "txtAddlPersonRate";
            this.txtAddlPersonRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddlBedRate
            // 
            resources.ApplyResources(this.lblAddlBedRate, "lblAddlBedRate");
            this.lblAddlBedRate.Name = "lblAddlBedRate";
            this.lblAddlBedRate.RequiredField = false;
            // 
            // txtAddlBedRate
            // 
            resources.ApplyResources(this.txtAddlBedRate, "txtAddlBedRate");
            this.txtAddlBedRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddlBedRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddlBedRate.Format = null;
            this.txtAddlBedRate.isAllowNegative = false;
            this.txtAddlBedRate.isAllowSpecialChar = false;
            this.txtAddlBedRate.isNumbersOnly = false;
            this.txtAddlBedRate.isNumeric = true;
            this.txtAddlBedRate.isTouchable = true;
            this.txtAddlBedRate.Name = "txtAddlBedRate";
            this.txtAddlBedRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblDefaultRate
            // 
            resources.ApplyResources(this.lblDefaultRate, "lblDefaultRate");
            this.lblDefaultRate.Name = "lblDefaultRate";
            this.lblDefaultRate.RequiredField = false;
            // 
            // txtDefaultRate
            // 
            resources.ApplyResources(this.txtDefaultRate, "txtDefaultRate");
            this.txtDefaultRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtDefaultRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDefaultRate.Format = null;
            this.txtDefaultRate.isAllowNegative = false;
            this.txtDefaultRate.isAllowSpecialChar = false;
            this.txtDefaultRate.isNumbersOnly = false;
            this.txtDefaultRate.isNumeric = true;
            this.txtDefaultRate.isTouchable = true;
            this.txtDefaultRate.Name = "txtDefaultRate";
            this.txtDefaultRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblExtraBeds
            // 
            resources.ApplyResources(this.lblExtraBeds, "lblExtraBeds");
            this.lblExtraBeds.Name = "lblExtraBeds";
            this.lblExtraBeds.RequiredField = false;
            // 
            // txtExtraBeds
            // 
            resources.ApplyResources(this.txtExtraBeds, "txtExtraBeds");
            this.txtExtraBeds.BackColor = System.Drawing.SystemColors.Window;
            this.txtExtraBeds.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtExtraBeds.Format = null;
            this.txtExtraBeds.isAllowNegative = false;
            this.txtExtraBeds.isAllowSpecialChar = false;
            this.txtExtraBeds.isNumbersOnly = true;
            this.txtExtraBeds.isNumeric = true;
            this.txtExtraBeds.isTouchable = true;
            this.txtExtraBeds.Name = "txtExtraBeds";
            this.txtExtraBeds.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblChild
            // 
            resources.ApplyResources(this.lblChild, "lblChild");
            this.lblChild.Name = "lblChild";
            this.lblChild.RequiredField = false;
            // 
            // lblAdult
            // 
            resources.ApplyResources(this.lblAdult, "lblAdult");
            this.lblAdult.Name = "lblAdult";
            this.lblAdult.RequiredField = false;
            // 
            // txtChild
            // 
            resources.ApplyResources(this.txtChild, "txtChild");
            this.txtChild.BackColor = System.Drawing.SystemColors.Window;
            this.txtChild.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtChild.Format = null;
            this.txtChild.isAllowNegative = false;
            this.txtChild.isAllowSpecialChar = false;
            this.txtChild.isNumbersOnly = true;
            this.txtChild.isNumeric = true;
            this.txtChild.isTouchable = true;
            this.txtChild.Name = "txtChild";
            this.txtChild.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtAdult
            // 
            resources.ApplyResources(this.txtAdult, "txtAdult");
            this.txtAdult.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdult.Format = null;
            this.txtAdult.isAllowNegative = false;
            this.txtAdult.isAllowSpecialChar = false;
            this.txtAdult.isNumbersOnly = true;
            this.txtAdult.isNumeric = true;
            this.txtAdult.isTouchable = true;
            this.txtAdult.Name = "txtAdult";
            this.txtAdult.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblDescription
            // 
            resources.ApplyResources(this.lblDescription, "lblDescription");
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.RequiredField = false;
            // 
            // txtDescription
            // 
            resources.ApplyResources(this.txtDescription, "txtDescription");
            this.txtDescription.BackColor = System.Drawing.SystemColors.Window;
            this.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDescription.Format = null;
            this.txtDescription.isAllowNegative = false;
            this.txtDescription.isAllowSpecialChar = false;
            this.txtDescription.isNumbersOnly = false;
            this.txtDescription.isNumeric = false;
            this.txtDescription.isTouchable = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // txtCode
            // 
            resources.ApplyResources(this.txtCode, "txtCode");
            this.txtCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCode.Format = null;
            this.txtCode.isAllowNegative = false;
            this.txtCode.isAllowSpecialChar = false;
            this.txtCode.isNumbersOnly = false;
            this.txtCode.isNumeric = false;
            this.txtCode.isTouchable = true;
            this.txtCode.Name = "txtCode";
            this.txtCode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCode.Validated += new System.EventHandler(this.txtCode_Validated);
            // 
            // rbtActive
            // 
            resources.ApplyResources(this.rbtActive, "rbtActive");
            this.rbtActive.Checked = true;
            this.rbtActive.Name = "rbtActive";
            this.rbtActive.TabStop = true;
            this.rbtActive.UseVisualStyleBackColor = true;
            // 
            // lblCode
            // 
            resources.ApplyResources(this.lblCode, "lblCode");
            this.lblCode.Name = "lblCode";
            this.lblCode.RequiredField = false;
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtName.Format = null;
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = true;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // rbtInactive
            // 
            resources.ApplyResources(this.rbtInactive, "rbtInactive");
            this.rbtInactive.Name = "rbtInactive";
            this.rbtInactive.UseVisualStyleBackColor = true;
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // pnlOptionalBar
            // 
            this.pnlOptionalBar.AllowMultiSelect = false;
            resources.ApplyResources(this.pnlOptionalBar, "pnlOptionalBar");
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.pnlOptionalBar.Controls.Add(this.btnSelected);
            this.pnlOptionalBar.Controls.Add(this.atImageframe);
            this.pnlOptionalBar.Controls.Add(this.btnSlabs);
            this.pnlOptionalBar.Controls.Add(this.btnAmenities);
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // btnSelected
            // 
            this.btnSelected.AllowMultiSelect = false;
            this.btnSelected.Angle = 110F;
            this.btnSelected.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSelected.BottomColor = System.Drawing.Color.MediumSpringGreen;
            resources.ApplyResources(this.btnSelected, "btnSelected");
            this.btnSelected.Name = "btnSelected";
            this.btnSelected.Selected = false;
            this.btnSelected.TextAdjestmentHeight = 0;
            this.btnSelected.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSelected.TopColor = System.Drawing.Color.DodgerBlue;
            // 
            // atImageframe
            // 
            this.atImageframe.AllowDrop = true;
            this.atImageframe.BackColor = System.Drawing.Color.Transparent;
            this.atImageframe.CurrentImage = null;
            resources.ApplyResources(this.atImageframe, "atImageframe");
            this.atImageframe.ForeColor = System.Drawing.Color.Transparent;
            this.atImageframe.ImageData = null;
            this.atImageframe.Name = "atImageframe";
            // 
            // btnSlabs
            // 
            this.btnSlabs.BackColor = System.Drawing.Color.Transparent;
            this.btnSlabs.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSlabs.FlatAppearance.BorderSize = 0;
            this.btnSlabs.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnSlabs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnSlabs, "btnSlabs");
            this.btnSlabs.ForeColor = System.Drawing.SystemColors.Window;
            this.btnSlabs.Name = "btnSlabs";
            this.btnSlabs.UseVisualStyleBackColor = false;
            this.btnSlabs.Click += new System.EventHandler(this.btnSlabs_Click);
            // 
            // btnAmenities
            // 
            this.btnAmenities.BackColor = System.Drawing.Color.White;
            this.btnAmenities.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAmenities.FlatAppearance.BorderSize = 0;
            this.btnAmenities.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnAmenities.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnAmenities, "btnAmenities");
            this.btnAmenities.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnAmenities.Name = "btnAmenities";
            this.btnAmenities.UseVisualStyleBackColor = false;
            this.btnAmenities.Click += new System.EventHandler(this.btnAmenities_Click);
            // 
            // HallTypesView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlOptionalBar);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlTabContain);
            this.Name = "HallTypesView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.HallTypesView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.HallTypesView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.HallTypesView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.HallTypesView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.HallTypesView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.HallTypesView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.HallTypesView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.HallTypesView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.HallTypesView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.HallTypesView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.HallTypesView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.HallTypesView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlTabContain, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.TabRateType.ResumeLayout(false);
            this.tabAmenity.ResumeLayout(false);
            this.tabAmenity.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgAmenity)).EndInit();
            this.tabSlabs.ResumeLayout(false);
            this.tabSlabs.PerformLayout();
            this.pnlTabContain.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlOptionalBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bindAmenity)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atTabControl TabRateType;
        private System.Windows.Forms.TabPage tabAmenity;
        private System.Windows.Forms.Button btnSepearator0;
        private atACCFramework.UserControls.atLabel lblAmenity;
        private atACCFramework.UserControls.atGridView dgAmenity;
        private System.Windows.Forms.TabPage tabSlabs;
        private System.Windows.Forms.Button btnSepearator1;
        private atACCFramework.UserControls.atLabel lblSlabs;
        private atACCFramework.UserControls.atLabel lblExciseDuty;
        private atACCFramework.UserControls.ComboBoxExt cmbTax3;
        private atACCFramework.UserControls.ComboBoxExt cmbAddlTax;
        private atACCFramework.UserControls.atLabel lblAdditionalTax;
        private atACCFramework.UserControls.ComboBoxExt cmbTax2;
        private atACCFramework.UserControls.ComboBoxExt cmbTax1;
        private atACCFramework.UserControls.atLabel lblTax3;
        private atACCFramework.UserControls.atLabel lblDiscount;
        private atACCFramework.UserControls.ComboBoxExt cmbExciseDuty;
        private atACCFramework.UserControls.atLabel lblGST;
        private atACCFramework.UserControls.ComboBoxExt cmbDiscount;
        private atACCFramework.UserControls.atLabel lblVAT;
        private atACCFramework.UserControls.atLabel lblTax2;
        private atACCFramework.UserControls.atLabel lblTax1;
        private atACCFramework.UserControls.ComboBoxExt cmbGST;
        private atACCFramework.UserControls.ComboBoxExt cmbVAT;
        private atACCFramework.UserControls.atPanel pnlTabContain;
        private atACCFramework.UserControls.atPanel pnlMain;
        private System.Windows.Forms.Button btnColor;
        private atACCFramework.UserControls.atLabel lblColor;
        private atACCFramework.UserControls.atLabel lblAddlPersonRate;
        private atACCFramework.UserControls.TextBoxExt txtAddlPersonRate;
        private atACCFramework.UserControls.atLabel lblAddlBedRate;
        private atACCFramework.UserControls.TextBoxExt txtAddlBedRate;
        private atACCFramework.UserControls.atLabel lblDefaultRate;
        private atACCFramework.UserControls.TextBoxExt txtDefaultRate;
        private atACCFramework.UserControls.atLabel lblExtraBeds;
        private atACCFramework.UserControls.TextBoxExt txtExtraBeds;
        private atACCFramework.UserControls.atLabel lblChild;
        private atACCFramework.UserControls.atLabel lblAdult;
        private atACCFramework.UserControls.TextBoxExt txtChild;
        private atACCFramework.UserControls.TextBoxExt txtAdult;
        private atACCFramework.UserControls.atLabel lblDescription;
        private atACCFramework.UserControls.TextBoxExt txtDescription;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.atRadioButton rbtInactive;
        private atACCFramework.UserControls.atLabel lblStatus;
        private atACCFramework.UserControls.TextBoxExt txtCode;
        private atACCFramework.UserControls.atRadioButton rbtActive;
        private atACCFramework.UserControls.atLabel lblCode;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atLabel lblName;
        private System.Windows.Forms.Label lblMandatory4;
        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private atACCFramework.UserControls.atGradientPanel btnSelected;
        private atACCFramework.UserControls.atImageFrame atImageframe;
        private System.Windows.Forms.Button btnSlabs;
        private System.Windows.Forms.Button btnAmenities;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_SlNo;
        private System.Windows.Forms.DataGridViewComboBoxColumn Col_Amenity;
        private System.Windows.Forms.BindingSource bindAmenity;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}