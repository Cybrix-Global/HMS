﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.ORM;
namespace atACC.HTL.Masters.Forms
{
    public partial class EnquirySearchView : FormBase
    {
        #region Private Variables
        atACCHotelEntities dbh;
        Enquiry entEnquiry;
        List<Enquiry> entEnquirys;
        #endregion

        #region Constructor
        public EnquirySearchView(atACCHotelEntities _dbh)
        {
            InitializeComponent();
            dbh = _dbh;
            dtFromDate.Value = DateTime.Now.ToBegin();
            dtToDate.Value = DateTime.Now.ToEnd();
            PopulateEmployee();
            PopulateVouchers();
            BindGrid();
        }
        #endregion

        #region Public Properties
        public Enquiry SelectedEnquiry { get; set; }
        #endregion

        #region Populate Events
        private void PopulateEmployee()
        {
            col_Employee.DataSource = dbh.Employees.OrderBy(x => x.Name).ToList();
            col_Employee.DisplayMember = "Name";
            col_Employee.ValueMember = "id";
        }
        private void PopulateVouchers()
        {
            atACCHotelEntities dbh = atHotelContext.CreateContext();
            entEnquirys = dbh.Enquiries.Where(x => (x.Name.Contains(txtSearch.Text) || x.VoucherNo.Contains(txtSearch.Text)) 
                && (x.VoucherDate >= dtFromDate.Value && x.VoucherDate <= dtToDate.Value)
                &&(x.Cancelled ?? false) == false && (x.Sanctioned ?? true) == true).ToList();
        }
        private void BindGrid()
        {
            dgVouchers.AutoGenerateColumns = false;
            dgVouchers.DataSource = null;
            bindEnquiry.DataSource = null;
            bindEnquiry.DataSource = entEnquirys;
            dgVouchers.DataSource = bindEnquiry;
            dgVouchers.CurrentCell = null;
        }
        #endregion

        #region Form Events
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.White;
        }
        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.ForeColor = Color.DarkGray;
        }
        private void dgVouchers_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (dgVouchers.CurrentRow != null)
            {
                Enquiry enquiry = (Enquiry)dgVouchers.CurrentRow.DataBoundItem;
                if (enquiry != null)
                {
                    SelectedEnquiry = enquiry;
                    this.DialogResult = DialogResult.OK;
                }
            }
        }
        private void txtFilterHDR_TextChanged(object sender, EventArgs e)
        {
            PopulateVouchers();
            BindGrid();
        }
        private void dtFromDate_ValueChanged(object sender, EventArgs e)
        {
            PopulateVouchers();
            BindGrid();
        }
        private void dtToDate_ValueChanged(object sender, EventArgs e)
        {
            PopulateVouchers();
            BindGrid();
        }
        #endregion
    }
}
