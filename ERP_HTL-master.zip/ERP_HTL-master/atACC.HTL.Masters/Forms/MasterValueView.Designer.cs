﻿namespace atACC.HTL.Masters
{
    partial class MasterValueView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MasterValueView));
            this.cmbMasterType = new atACCFramework.UserControls.ComboBoxExt();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblMasterType = new atACCFramework.UserControls.atLabel();
            this.lblName = new atACCFramework.UserControls.atLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            // 
            // cmbMasterType
            // 
            resources.ApplyResources(this.cmbMasterType, "cmbMasterType");
            this.cmbMasterType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbMasterType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMasterType.DropDownHeight = 300;
            this.cmbMasterType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMasterType.FormattingEnabled = true;
            this.cmbMasterType.Name = "cmbMasterType";
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtName.Format = null;
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = false;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtName_KeyDown);
            // 
            // lblMasterType
            // 
            resources.ApplyResources(this.lblMasterType, "lblMasterType");
            this.lblMasterType.Name = "lblMasterType";
            this.lblMasterType.RequiredField = false;
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // MasterValueView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cmbMasterType);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblMasterType);
            this.Controls.Add(this.lblName);
            this.Name = "MasterValueView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.MasterValueView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.MasterValueView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.MasterValueView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.MasterValueView_atNewClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.MasterValueView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.MasterValueView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.MasterValueView_atAfterSave);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.MasterValueView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.MasterValueView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.MasterValueView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.lblName, 0);
            this.Controls.SetChildIndex(this.lblMasterType, 0);
            this.Controls.SetChildIndex(this.txtName, 0);
            this.Controls.SetChildIndex(this.cmbMasterType, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atACCFramework.UserControls.ComboBoxExt cmbMasterType;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private atACCFramework.UserControls.atLabel lblMasterType;
        private atACCFramework.UserControls.atLabel lblName;
    }
}