﻿namespace atACC.HTL.Masters
{
    partial class RoomView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RoomView));
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.txtDisplayOrder = new atACCFramework.UserControls.TextBoxExt();
            this.lblDisplayOrder = new atACCFramework.UserControls.atLabel();
            this.txtUserField3 = new atACCFramework.UserControls.TextBoxExt();
            this.txtUserField2 = new atACCFramework.UserControls.TextBoxExt();
            this.txtUserField1 = new atACCFramework.UserControls.TextBoxExt();
            this.lblUserFiled1 = new atACCFramework.UserControls.atLabel();
            this.txtUserField4 = new atACCFramework.UserControls.TextBoxExt();
            this.lblUserFiled4 = new atACCFramework.UserControls.atLabel();
            this.lblUserFiled2 = new atACCFramework.UserControls.atLabel();
            this.lblUserFiled3 = new atACCFramework.UserControls.atLabel();
            this.radInactive = new atACCFramework.UserControls.atRadioButton();
            this.radActive = new atACCFramework.UserControls.atRadioButton();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.txtKeyNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblKeyNo = new atACCFramework.UserControls.atLabel();
            this.txtPhone = new atACCFramework.UserControls.TextBoxExt();
            this.lblPhoneNo = new atACCFramework.UserControls.atLabel();
            this.cmbBlock = new atACCFramework.UserControls.ComboBoxExt();
            this.lblBlock = new atACCFramework.UserControls.atLabel();
            this.cmbFloor = new atACCFramework.UserControls.ComboBoxExt();
            this.txtDescription = new atACCFramework.UserControls.TextBoxExt();
            this.lblDescription = new atACCFramework.UserControls.atLabel();
            this.lblFloor = new atACCFramework.UserControls.atLabel();
            this.txtCode = new atACCFramework.UserControls.TextBoxExt();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblCode = new atACCFramework.UserControls.atLabel();
            this.lblName = new atACCFramework.UserControls.atLabel();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.txtDisplayOrder);
            this.pnlMain.Controls.Add(this.lblDisplayOrder);
            this.pnlMain.Controls.Add(this.txtUserField3);
            this.pnlMain.Controls.Add(this.txtUserField2);
            this.pnlMain.Controls.Add(this.txtUserField1);
            this.pnlMain.Controls.Add(this.lblUserFiled1);
            this.pnlMain.Controls.Add(this.txtUserField4);
            this.pnlMain.Controls.Add(this.lblUserFiled4);
            this.pnlMain.Controls.Add(this.lblUserFiled2);
            this.pnlMain.Controls.Add(this.lblUserFiled3);
            this.pnlMain.Controls.Add(this.radInactive);
            this.pnlMain.Controls.Add(this.radActive);
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.txtKeyNo);
            this.pnlMain.Controls.Add(this.lblKeyNo);
            this.pnlMain.Controls.Add(this.txtPhone);
            this.pnlMain.Controls.Add(this.lblPhoneNo);
            this.pnlMain.Controls.Add(this.cmbBlock);
            this.pnlMain.Controls.Add(this.lblBlock);
            this.pnlMain.Controls.Add(this.cmbFloor);
            this.pnlMain.Controls.Add(this.txtDescription);
            this.pnlMain.Controls.Add(this.lblDescription);
            this.pnlMain.Controls.Add(this.lblFloor);
            this.pnlMain.Controls.Add(this.txtCode);
            this.pnlMain.Controls.Add(this.txtName);
            this.pnlMain.Controls.Add(this.lblCode);
            this.pnlMain.Controls.Add(this.lblName);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblMandatory5);
            this.pnlMain.Controls.Add(this.cmbRoomType);
            this.pnlMain.Controls.Add(this.lblRoomType);
            this.pnlMain.Name = "pnlMain";
            // 
            // txtDisplayOrder
            // 
            resources.ApplyResources(this.txtDisplayOrder, "txtDisplayOrder");
            this.txtDisplayOrder.BackColor = System.Drawing.SystemColors.Window;
            this.txtDisplayOrder.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDisplayOrder.Format = null;
            this.errProvider.SetIconAlignment(this.txtDisplayOrder, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtDisplayOrder.IconAlignment"))));
            this.txtDisplayOrder.isAllowNegative = false;
            this.txtDisplayOrder.isAllowSpecialChar = false;
            this.txtDisplayOrder.isNumbersOnly = false;
            this.txtDisplayOrder.isNumeric = true;
            this.txtDisplayOrder.isTouchable = true;
            this.txtDisplayOrder.Name = "txtDisplayOrder";
            this.txtDisplayOrder.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtDisplayOrder.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDisplayOrder_KeyDown);
            // 
            // lblDisplayOrder
            // 
            resources.ApplyResources(this.lblDisplayOrder, "lblDisplayOrder");
            this.errProvider.SetIconAlignment(this.lblDisplayOrder, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDisplayOrder.IconAlignment"))));
            this.lblDisplayOrder.Name = "lblDisplayOrder";
            this.lblDisplayOrder.RequiredField = false;
            // 
            // txtUserField3
            // 
            resources.ApplyResources(this.txtUserField3, "txtUserField3");
            this.txtUserField3.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserField3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUserField3.Format = null;
            this.errProvider.SetIconAlignment(this.txtUserField3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtUserField3.IconAlignment"))));
            this.txtUserField3.isAllowNegative = false;
            this.txtUserField3.isAllowSpecialChar = false;
            this.txtUserField3.isNumbersOnly = false;
            this.txtUserField3.isNumeric = false;
            this.txtUserField3.isTouchable = true;
            this.txtUserField3.Name = "txtUserField3";
            this.txtUserField3.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtUserField2
            // 
            resources.ApplyResources(this.txtUserField2, "txtUserField2");
            this.txtUserField2.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserField2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUserField2.Format = null;
            this.errProvider.SetIconAlignment(this.txtUserField2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtUserField2.IconAlignment"))));
            this.txtUserField2.isAllowNegative = false;
            this.txtUserField2.isAllowSpecialChar = false;
            this.txtUserField2.isNumbersOnly = false;
            this.txtUserField2.isNumeric = false;
            this.txtUserField2.isTouchable = true;
            this.txtUserField2.Name = "txtUserField2";
            this.txtUserField2.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtUserField1
            // 
            resources.ApplyResources(this.txtUserField1, "txtUserField1");
            this.txtUserField1.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserField1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUserField1.Format = null;
            this.errProvider.SetIconAlignment(this.txtUserField1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtUserField1.IconAlignment"))));
            this.txtUserField1.isAllowNegative = false;
            this.txtUserField1.isAllowSpecialChar = false;
            this.txtUserField1.isNumbersOnly = false;
            this.txtUserField1.isNumeric = false;
            this.txtUserField1.isTouchable = true;
            this.txtUserField1.Name = "txtUserField1";
            this.txtUserField1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblUserFiled1
            // 
            resources.ApplyResources(this.lblUserFiled1, "lblUserFiled1");
            this.errProvider.SetIconAlignment(this.lblUserFiled1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblUserFiled1.IconAlignment"))));
            this.lblUserFiled1.Name = "lblUserFiled1";
            this.lblUserFiled1.RequiredField = false;
            // 
            // txtUserField4
            // 
            resources.ApplyResources(this.txtUserField4, "txtUserField4");
            this.txtUserField4.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserField4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUserField4.Format = null;
            this.errProvider.SetIconAlignment(this.txtUserField4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtUserField4.IconAlignment"))));
            this.txtUserField4.isAllowNegative = false;
            this.txtUserField4.isAllowSpecialChar = false;
            this.txtUserField4.isNumbersOnly = false;
            this.txtUserField4.isNumeric = false;
            this.txtUserField4.isTouchable = true;
            this.txtUserField4.Name = "txtUserField4";
            this.txtUserField4.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblUserFiled4
            // 
            resources.ApplyResources(this.lblUserFiled4, "lblUserFiled4");
            this.errProvider.SetIconAlignment(this.lblUserFiled4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblUserFiled4.IconAlignment"))));
            this.lblUserFiled4.Name = "lblUserFiled4";
            this.lblUserFiled4.RequiredField = false;
            // 
            // lblUserFiled2
            // 
            resources.ApplyResources(this.lblUserFiled2, "lblUserFiled2");
            this.errProvider.SetIconAlignment(this.lblUserFiled2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblUserFiled2.IconAlignment"))));
            this.lblUserFiled2.Name = "lblUserFiled2";
            this.lblUserFiled2.RequiredField = false;
            // 
            // lblUserFiled3
            // 
            resources.ApplyResources(this.lblUserFiled3, "lblUserFiled3");
            this.errProvider.SetIconAlignment(this.lblUserFiled3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblUserFiled3.IconAlignment"))));
            this.lblUserFiled3.Name = "lblUserFiled3";
            this.lblUserFiled3.RequiredField = false;
            // 
            // radInactive
            // 
            resources.ApplyResources(this.radInactive, "radInactive");
            this.radInactive.Name = "radInactive";
            this.radInactive.UseVisualStyleBackColor = true;
            // 
            // radActive
            // 
            resources.ApplyResources(this.radActive, "radActive");
            this.radActive.Checked = true;
            this.radActive.Name = "radActive";
            this.radActive.TabStop = true;
            this.radActive.UseVisualStyleBackColor = true;
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            // 
            // txtKeyNo
            // 
            this.txtKeyNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtKeyNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtKeyNo, "txtKeyNo");
            this.txtKeyNo.Format = null;
            this.txtKeyNo.isAllowNegative = false;
            this.txtKeyNo.isAllowSpecialChar = false;
            this.txtKeyNo.isNumbersOnly = false;
            this.txtKeyNo.isNumeric = false;
            this.txtKeyNo.isTouchable = true;
            this.txtKeyNo.Name = "txtKeyNo";
            this.txtKeyNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblKeyNo
            // 
            resources.ApplyResources(this.lblKeyNo, "lblKeyNo");
            this.lblKeyNo.Name = "lblKeyNo";
            this.lblKeyNo.RequiredField = false;
            // 
            // txtPhone
            // 
            this.txtPhone.BackColor = System.Drawing.SystemColors.Window;
            this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtPhone, "txtPhone");
            this.txtPhone.Format = null;
            this.txtPhone.isAllowNegative = false;
            this.txtPhone.isAllowSpecialChar = false;
            this.txtPhone.isNumbersOnly = false;
            this.txtPhone.isNumeric = true;
            this.txtPhone.isTouchable = true;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblPhoneNo
            // 
            resources.ApplyResources(this.lblPhoneNo, "lblPhoneNo");
            this.lblPhoneNo.Name = "lblPhoneNo";
            this.lblPhoneNo.RequiredField = false;
            // 
            // cmbBlock
            // 
            this.cmbBlock.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBlock.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBlock.DropDownHeight = 300;
            this.cmbBlock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbBlock, "cmbBlock");
            this.cmbBlock.FormattingEnabled = true;
            this.cmbBlock.Name = "cmbBlock";
            // 
            // lblBlock
            // 
            resources.ApplyResources(this.lblBlock, "lblBlock");
            this.lblBlock.Name = "lblBlock";
            this.lblBlock.RequiredField = false;
            // 
            // cmbFloor
            // 
            this.cmbFloor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbFloor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbFloor.DropDownHeight = 300;
            this.cmbFloor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbFloor, "cmbFloor");
            this.cmbFloor.FormattingEnabled = true;
            this.cmbFloor.Name = "cmbFloor";
            // 
            // txtDescription
            // 
            this.txtDescription.BackColor = System.Drawing.SystemColors.Window;
            this.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtDescription, "txtDescription");
            this.txtDescription.Format = null;
            this.txtDescription.isAllowNegative = false;
            this.txtDescription.isAllowSpecialChar = false;
            this.txtDescription.isNumbersOnly = false;
            this.txtDescription.isNumeric = false;
            this.txtDescription.isTouchable = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblDescription
            // 
            resources.ApplyResources(this.lblDescription, "lblDescription");
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.RequiredField = false;
            // 
            // lblFloor
            // 
            resources.ApplyResources(this.lblFloor, "lblFloor");
            this.lblFloor.Name = "lblFloor";
            this.lblFloor.RequiredField = false;
            // 
            // txtCode
            // 
            this.txtCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtCode, "txtCode");
            this.txtCode.Format = null;
            this.txtCode.isAllowNegative = false;
            this.txtCode.isAllowSpecialChar = false;
            this.txtCode.isNumbersOnly = false;
            this.txtCode.isNumeric = false;
            this.txtCode.isTouchable = true;
            this.txtCode.Name = "txtCode";
            this.txtCode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCode.Validated += new System.EventHandler(this.txtCode_Validated);
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.Format = null;
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = true;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblCode
            // 
            resources.ApplyResources(this.lblCode, "lblCode");
            this.lblCode.Name = "lblCode";
            this.lblCode.RequiredField = false;
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblMandatory5
            // 
            resources.ApplyResources(this.lblMandatory5, "lblMandatory5");
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory5.Name = "lblMandatory5";
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Name = "cmbRoomType";
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // pnlOptionalBar
            // 
            this.pnlOptionalBar.AllowMultiSelect = false;
            resources.ApplyResources(this.pnlOptionalBar, "pnlOptionalBar");
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // RoomView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlOptionalBar);
            this.Name = "RoomView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.FrmRoomView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.FrmRoomView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.FrmRoomView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.FrmRoomView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.RoomView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.FrmRoomView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.FrmRoomView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.FrmRoomView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.FrmRoomView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.FrmRoomView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.FrmRoomView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.FrmRoomView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.TextBoxExt txtCode;
        private atACCFramework.UserControls.atLabel lblCode;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private atACCFramework.UserControls.atLabel lblName;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.TextBoxExt txtUserField3;
        private atACCFramework.UserControls.TextBoxExt txtUserField2;
        private atACCFramework.UserControls.TextBoxExt txtUserField1;
        private atACCFramework.UserControls.atLabel lblUserFiled1;
        private atACCFramework.UserControls.TextBoxExt txtUserField4;
        private atACCFramework.UserControls.atLabel lblUserFiled4;
        private atACCFramework.UserControls.atLabel lblUserFiled2;
        private atACCFramework.UserControls.atLabel lblUserFiled3;
        private atACCFramework.UserControls.atRadioButton radInactive;
        private atACCFramework.UserControls.atRadioButton radActive;
        private atACCFramework.UserControls.atLabel lblStatus;
        private atACCFramework.UserControls.TextBoxExt txtKeyNo;
        private atACCFramework.UserControls.atLabel lblKeyNo;
        private atACCFramework.UserControls.TextBoxExt txtPhone;
        private atACCFramework.UserControls.atLabel lblPhoneNo;
        private atACCFramework.UserControls.ComboBoxExt cmbBlock;
        private atACCFramework.UserControls.atLabel lblBlock;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.ComboBoxExt cmbFloor;
        private atACCFramework.UserControls.TextBoxExt txtDescription;
        private atACCFramework.UserControls.atLabel lblDescription;
        private atACCFramework.UserControls.atLabel lblFloor;
        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private atACCFramework.UserControls.TextBoxExt txtDisplayOrder;
        private atACCFramework.UserControls.atLabel lblDisplayOrder;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory3;
        private System.Windows.Forms.Label lblMandatory4;
        private System.Windows.Forms.Label lblMandatory5;
    }
}