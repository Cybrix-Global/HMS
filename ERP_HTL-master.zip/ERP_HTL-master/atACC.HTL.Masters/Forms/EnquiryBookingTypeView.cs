﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class EnquiryBookingTypeView : SearchFormBase2
    {
        #region Constructor
        public EnquiryBookingTypeView()
        {
            InitializeComponent();
        }
        #endregion

        #region Public Properties
        public int CurrentID { get; set; }
        #endregion

        #region Private Variable
        EnquiryBookingType m_EnquiryBookingType;
        List<EnquiryBookingType> m_EnquiryBookingTypeList;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        ToolTip tooltip;        
        #endregion

        #region Populate Events
        private void PopulateEnquiryBookingType()
        {
            try
            {
                m_EnquiryBookingTypeList = dbh.EnquiryBookingTypes.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();                
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            try
            {
                m_EnquiryBookingType = new EnquiryBookingType();
                m_EnquiryBookingTypeList = new List<EnquiryBookingType>();
                txtName.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtName_Validated(object sender, EventArgs e)
        {
            try
            {                
                EnquiryBookingType SD = dbh.EnquiryBookingTypes.Where(x => x.Name == txtName.Text.Trim())
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .SingleOrDefault();
                if (SD != null && txtName.IsTextChanged())
                {
                    ReLoadData(SD.id);
                    onPopulate();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void EnquiryBookingType_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                m_EnquiryBookingType = new EnquiryBookingType();
                SettingsButton.Visible = ShareButton.Visible = false;
                PrintButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void EnquiryBookingType_atAfterInitialise()
        {
            try
            {
                txtName.Focus();
                ShowToolTip();
                PopulateEnquiryBookingType();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void EnquiryBookingType_atNewClick(object source)
        {
            try
            {
                m_EnquiryBookingType = new EnquiryBookingType();
                dbh = atHotelContext.CreateContext();
                txtName.Focus();
                FnClearAll();
                ShowToolTip();
                PopulateEnquiryBookingType();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool EnquiryBookingType_atValidate(object source)
        {
            try
            {                
                if (txtName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool EnquiryBookingType_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    m_EnquiryBookingType = new EnquiryBookingType();
                }           
                m_EnquiryBookingType.ContextID = iContextID;
                m_EnquiryBookingType.LocationID = GlobalFunctions.LoginLocationID;
                m_EnquiryBookingType.LoginUserID = GlobalFunctions.LoginUserID;
                m_EnquiryBookingType.Name = txtName.Text.ToString();                
                if (NewRecord)
                {
                    dbh.EnquiryBookingTypes.AddObject(m_EnquiryBookingType);                    
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_EnquiryBookingType, EntityState.Modified);
                }                
                dbh.SaveChanges();
                CurrentID = m_EnquiryBookingType.id;
                this.DialogResult = DialogResult.OK;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException.Message.Contains("UC_EnquiryBookingTypeName"))
                {
                    atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgEnquiryBookingType + " (" + txtName.Text + ") "
                        + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                    txtName.Focus();
                    return false;
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool EnquiryBookingType_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void EnquiryBookingType_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = m_EnquiryBookingTypeList.Select(x => new { x.id, Name = x.Name }).OrderByDescending(x => x.id);                
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_EnquiryBookingType = dbh.EnquiryBookingTypes.Where(x => x.id == id).SingleOrDefault();
                if (m_EnquiryBookingType != null)
                {
                    txtName.Text = m_EnquiryBookingType.Name.ToString();
                }                
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool EnquiryBookingType_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vLoan = new { id = 0, Name = string.Empty };
                    ReLoadData(e.GetSelectedEntity().Cast(vLoan).id);
                }
                else
                {
                    txtName.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool EnquiryBookingType_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void EnquiryBookingTypeView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool EnquiryBookingType_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.EnquiryBookingTypes.DeleteObject(m_EnquiryBookingType);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void EnquiryBookingType_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
