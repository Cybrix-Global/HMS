﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class ContactBookView : SearchFormBase2
    {
        #region Constructor
        public ContactBookView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_ContactBookView;
        }
        #endregion

        #region Private Variables
        ContactBook entContactBook;
        List<ContactBook> entContactBooks;
        List<CurrencyClass> entCurrencys;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        ToolTip tooltip;
        string m_NumberFormat;
        #endregion

        #region Populate Events
        private void PopulateContactBooks()
        {
            try
            {
                entContactBooks = dbh.ContactBooks.OrderBy(x => x.Name).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCountry()
        {
            try
            {
                CmbCountry.DisplayMember = "Description";
                CmbCountry.ValueMember = "id";
                CmbCountry.DataSource = dbh.CurrencyHDRs.OrderBy(x => x.Description).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateCategory()
        {
            try
            {
                var Category = dbh.ContactBooks.GroupBy(x => x.Category).Select(y => y.FirstOrDefault()).Where(x => x.Category != "").OrderBy(x => x.Category).ToList();
                cmbCategory.DataSource = Category;
                cmbCategory.DisplayMember = "Category";
                cmbCategory.ValueMember = "id";
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(txtReferenceName, MessageKeys.MsgEnterReferenceName);
                tooltip.SetToolTip(cmbCategory, MessageKeys.MsgCategory);
                tooltip.SetToolTip(txtContactPerson, MessageKeys.MsgEnterContactPerson);
                tooltip.SetToolTip(txtAdd1, MessageKeys.MsgEnterAddress1);
                tooltip.SetToolTip(txtAdd2, MessageKeys.MsgEnterAddress2);
                tooltip.SetToolTip(txtAdd3, MessageKeys.MsgEnterAddress3);
                tooltip.SetToolTip(txtCity, MessageKeys.MsgEnterCity);
                tooltip.SetToolTip(txtState, MessageKeys.MsgEnterState);
                tooltip.SetToolTip(CmbCountry, MessageKeys.MsgChooseCountry);
                tooltip.SetToolTip(txtPostalcode, MessageKeys.MsgEnterPostalCode);
                tooltip.SetToolTip(txtTelephone, MessageKeys.MsgEnterTelephoneNumber);
                tooltip.SetToolTip(txtMobile, MessageKeys.MsgEnterMobileNumber);
                tooltip.SetToolTip(txtEmail, MessageKeys.MsgEnterEmailAddress);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void ContactBookView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                entContactBook = new ContactBook();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void ContactBookView_atAfterInitialise()
        {
            try
            {
                txtName.Focus();
                PopulateContactBooks();
                PopulateCategory();
                PopulateCountry();
                ShowToolTip();
                CmbCountry.SelectedValue = GlobalFunctions.CompanyCurrencyID;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void ContactBookView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entContactBook = new ContactBook();
                PopulateContactBooks();
                PopulateCategory();
                PopulateCountry();
                CmbCountry.SelectedValue = GlobalFunctions.CompanyCurrencyID;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool ContactBookView_atValidate(object source)
        {
            try
            {
                
                if (txtName.Text.Trim() == "") { errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered); txtName.Focus(); return false; }
                if (!GlobalFunctions.IsValidPincode(txtPostalcode.Text))
                {
                    errProvider.SetError(txtPostalcode, MessageKeys.MsgInvalidPincode);
                    txtPostalcode.Focus();
                    return false;
                }
                if (!GlobalFunctions.IsValidMobileNo(txtMobile.Text))
                {
                    errProvider.SetError(txtMobile, MessageKeys.MsgInvalidMobileNumber);
                    txtMobile.Focus();
                    return false;
                }
                if (!GlobalFunctions.IsValidEmailId(txtEmail.Text))
                {
                    errProvider.SetError(txtEmail, MessageKeys.MsgInvalidEmailAddress);
                    txtEmail.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool ContactBookView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    entContactBook = new ContactBook();
                }
                entContactBook.Name = txtName.Text;
                entContactBook.ReferenceName = txtReferenceName.Text;
                entContactBook.Category = cmbCategory.Text;
                entContactBook.ContactPerson = txtContactPerson.Text;
                entContactBook.Address1 = txtAdd1.Text;
                entContactBook.Address2 = txtAdd2.Text;
                entContactBook.Address3 = txtAdd3.Text;
                entContactBook.City = txtCity.Text;
                entContactBook.State = txtState.Text;
                entContactBook.FK_Country = CmbCountry.SelectedValue.ToInt32();
                entContactBook.PinCode = txtPostalcode.Text;
                entContactBook.PhoneNumber = txtTelephone.Text;
                entContactBook.MobileNumber = txtMobile.Text;
                entContactBook.Email = txtEmail.Text;
                if (NewRecord)
                {
                    dbh.ContactBooks.AddObject(entContactBook);
                }
                else if (!NewRecord)
                {
                    dbh.ObjectStateManager.ChangeObjectState(entContactBook, EntityState.Modified);
                }
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool ContactBookView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void ContactBookView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = entContactBooks.Select(x => new { id = x.id, Name = x.Name, Category = x.Category }).OrderByDescending(x => x.id);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {

                dbh = atHotelContext.CreateContext();
                entContactBook = dbh.ContactBooks.Where(x => x.id == ID).SingleOrDefault();
                if (entContactBook != null)
                {
                    txtName.Text = entContactBook.Name;
                    txtReferenceName.Text = entContactBook.ReferenceName;
                    cmbCategory.Text = entContactBook.Category;
                    txtContactPerson.Text = entContactBook.ContactPerson;
                    txtAdd1.Text = entContactBook.Address1;
                    txtAdd2.Text = entContactBook.Address2;
                    txtAdd3.Text = entContactBook.Address3;
                    txtCity.Text = entContactBook.City;
                    txtState.Text = entContactBook.State;
                    CmbCountry.SelectedValue = entContactBook.FK_Country;
                    txtPostalcode.Text = entContactBook.PinCode;
                    txtTelephone.Text = entContactBook.PhoneNumber;
                    txtMobile.Text = entContactBook.MobileNumber;
                    txtEmail.Text = entContactBook.Email;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool ContactBookView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vContactBook = new { id = 0, Name = string.Empty, Category = string.Empty };
                    ReLoadData(e.GetSelectedEntity().Cast(vContactBook).id);
                }
                else
                {
                    txtName.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private void ContactBookView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool ContactBookView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.DeleteObject(entContactBook);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void ContactBookView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
