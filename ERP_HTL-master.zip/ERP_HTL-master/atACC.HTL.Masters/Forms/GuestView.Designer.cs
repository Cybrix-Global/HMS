﻿namespace atACC.HTL.Masters
{
    partial class GuestView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GuestView));
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            this.btnSelected = new atACCFramework.UserControls.atGradientPanel();
            this.atImageframe = new atACCFramework.UserControls.atImageFrame();
            this.btnOtherDetails = new System.Windows.Forms.Button();
            this.btnContactDetails = new System.Windows.Forms.Button();
            this.lblCurrency = new atACCFramework.UserControls.atLabel();
            this.lblAccount = new atACCFramework.UserControls.atLabel();
            this.lblName = new atACCFramework.UserControls.atLabel();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblMandatory3 = new System.Windows.Forms.Label();
            this.lblExRate = new atACCFramework.UserControls.atLabel();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblCode = new atACCFramework.UserControls.atLabel();
            this.CmbCurrency = new atACCFramework.UserControls.ComboBoxExt();
            this.txtExRate = new atACCFramework.UserControls.TextBoxExt();
            this.txtAccount = new atACCFramework.UserControls.TextBoxExt();
            this.rbtActive = new atACCFramework.UserControls.atRadioButton();
            this.txtCode = new atACCFramework.UserControls.TextBoxExt();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.rbtInactive = new atACCFramework.UserControls.atRadioButton();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.chkEnquiry = new atACCFramework.UserControls.atCheckBox();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.cmbGender = new atACCFramework.UserControls.ComboBoxExt();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblMandatory6 = new System.Windows.Forms.Label();
            this.pnlTabContain = new atACCFramework.UserControls.atPanel();
            this.tabGuest = new atACCFramework.UserControls.atTabControl();
            this.tabContactDetails = new System.Windows.Forms.TabPage();
            this.pnlContactDetails = new atACCFramework.UserControls.atPanel();
            this.lblContry = new atACCFramework.UserControls.atLabel();
            this.txtEmail = new atACCFramework.UserControls.TextBoxExt();
            this.txtState = new atACCFramework.UserControls.TextBoxExt();
            this.txtAdd3 = new atACCFramework.UserControls.TextBoxExt();
            this.lblCity = new atACCFramework.UserControls.atLabel();
            this.txtTelephone = new atACCFramework.UserControls.TextBoxExt();
            this.CmbCountry = new atACCFramework.UserControls.ComboBoxExt();
            this.lblTelephone = new atACCFramework.UserControls.atLabel();
            this.txtAdd1 = new atACCFramework.UserControls.TextBoxExt();
            this.txtPostalcode = new atACCFramework.UserControls.TextBoxExt();
            this.lblState = new atACCFramework.UserControls.atLabel();
            this.lblContactPerson = new atACCFramework.UserControls.atLabel();
            this.lblMobileNumber = new atACCFramework.UserControls.atLabel();
            this.txtAdd2 = new atACCFramework.UserControls.TextBoxExt();
            this.txtMobile = new atACCFramework.UserControls.TextBoxExt();
            this.txtContactPerson = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddress3 = new atACCFramework.UserControls.atLabel();
            this.lblAddress1 = new atACCFramework.UserControls.atLabel();
            this.lblAddress2 = new atACCFramework.UserControls.atLabel();
            this.lblPostalCode = new atACCFramework.UserControls.atLabel();
            this.txtCity = new atACCFramework.UserControls.TextBoxExt();
            this.lblEmail = new atACCFramework.UserControls.atLabel();
            this.tabOtherDetails = new System.Windows.Forms.TabPage();
            this.pnlOtherDetails = new atACCFramework.UserControls.atPanel();
            this.btnNewProofType = new atACCFramework.UserControls.atButton();
            this.CmbCreditCardType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblCreditCardType = new atACCFramework.UserControls.atLabel();
            this.txtDiscPerc = new atACCFramework.UserControls.TextBoxExt();
            this.lblDiscInPerc = new atACCFramework.UserControls.atLabel();
            this.cmbProofType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblProofType = new atACCFramework.UserControls.atLabel();
            this.txtCreditCardNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblBankName = new atACCFramework.UserControls.atLabel();
            this.txtBankName = new atACCFramework.UserControls.TextBoxExt();
            this.txtProofNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblAccountName = new atACCFramework.UserControls.atLabel();
            this.lblCreditCardNo = new atACCFramework.UserControls.atLabel();
            this.txtSWIFTCode = new atACCFramework.UserControls.TextBoxExt();
            this.lblSWIFTCode = new atACCFramework.UserControls.atLabel();
            this.txtBankNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblVehicleNo = new atACCFramework.UserControls.atLabel();
            this.lblPreferences = new atACCFramework.UserControls.atLabel();
            this.txtPreferences = new atACCFramework.UserControls.TextBoxExt();
            this.txtVehicleNo = new atACCFramework.UserControls.TextBoxExt();
            this.lblProofNo = new atACCFramework.UserControls.atLabel();
            this.btnEnquiry = new atACCFramework.UserControls.atButton();
            this.lblMandatory7 = new System.Windows.Forms.Label();
            this.lblMandatory8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlOptionalBar.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlTabContain.SuspendLayout();
            this.tabGuest.SuspendLayout();
            this.tabContactDetails.SuspendLayout();
            this.pnlContactDetails.SuspendLayout();
            this.tabOtherDetails.SuspendLayout();
            this.pnlOtherDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnEnquiry);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.SetChildIndex(this.btnEnquiry, 0);
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            // 
            // pnlOptionalBar
            // 
            this.pnlOptionalBar.AllowMultiSelect = false;
            resources.ApplyResources(this.pnlOptionalBar, "pnlOptionalBar");
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.pnlOptionalBar.Controls.Add(this.btnSelected);
            this.pnlOptionalBar.Controls.Add(this.atImageframe);
            this.pnlOptionalBar.Controls.Add(this.btnOtherDetails);
            this.pnlOptionalBar.Controls.Add(this.btnContactDetails);
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // btnSelected
            // 
            this.btnSelected.AllowMultiSelect = false;
            this.btnSelected.Angle = 110F;
            this.btnSelected.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSelected.BottomColor = System.Drawing.Color.MediumSpringGreen;
            resources.ApplyResources(this.btnSelected, "btnSelected");
            this.btnSelected.Name = "btnSelected";
            this.btnSelected.Selected = false;
            this.btnSelected.TextAdjestmentHeight = 0;
            this.btnSelected.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSelected.TopColor = System.Drawing.Color.DodgerBlue;
            // 
            // atImageframe
            // 
            this.atImageframe.AllowDrop = true;
            this.atImageframe.BackColor = System.Drawing.Color.Transparent;
            this.atImageframe.CurrentImage = null;
            resources.ApplyResources(this.atImageframe, "atImageframe");
            this.atImageframe.ForeColor = System.Drawing.Color.Transparent;
            this.atImageframe.ImageData = null;
            this.atImageframe.Name = "atImageframe";
            // 
            // btnOtherDetails
            // 
            this.btnOtherDetails.BackColor = System.Drawing.Color.Transparent;
            this.btnOtherDetails.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnOtherDetails.FlatAppearance.BorderSize = 0;
            this.btnOtherDetails.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnOtherDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnOtherDetails, "btnOtherDetails");
            this.btnOtherDetails.ForeColor = System.Drawing.SystemColors.Window;
            this.btnOtherDetails.Name = "btnOtherDetails";
            this.btnOtherDetails.UseVisualStyleBackColor = false;
            this.btnOtherDetails.Click += new System.EventHandler(this.btnOtherDetails_Click);
            // 
            // btnContactDetails
            // 
            this.btnContactDetails.BackColor = System.Drawing.Color.White;
            this.btnContactDetails.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnContactDetails.FlatAppearance.BorderSize = 0;
            this.btnContactDetails.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnContactDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnContactDetails, "btnContactDetails");
            this.btnContactDetails.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnContactDetails.Name = "btnContactDetails";
            this.btnContactDetails.UseVisualStyleBackColor = false;
            this.btnContactDetails.Click += new System.EventHandler(this.btnContactDetails_Click);
            // 
            // lblCurrency
            // 
            resources.ApplyResources(this.lblCurrency, "lblCurrency");
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.RequiredField = false;
            // 
            // lblAccount
            // 
            resources.ApplyResources(this.lblAccount, "lblAccount");
            this.lblAccount.Name = "lblAccount";
            this.lblAccount.RequiredField = false;
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblMandatory3
            // 
            resources.ApplyResources(this.lblMandatory3, "lblMandatory3");
            this.lblMandatory3.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory3.Name = "lblMandatory3";
            // 
            // lblExRate
            // 
            resources.ApplyResources(this.lblExRate, "lblExRate");
            this.lblExRate.Name = "lblExRate";
            this.lblExRate.RequiredField = false;
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtName.Format = null;
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = false;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblCode
            // 
            resources.ApplyResources(this.lblCode, "lblCode");
            this.lblCode.Name = "lblCode";
            this.lblCode.RequiredField = false;
            // 
            // CmbCurrency
            // 
            resources.ApplyResources(this.CmbCurrency, "CmbCurrency");
            this.CmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCurrency.DropDownHeight = 300;
            this.CmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCurrency.FormattingEnabled = true;
            this.CmbCurrency.Name = "CmbCurrency";
            this.CmbCurrency.SelectedIndexChanged += new System.EventHandler(this.CmbCurrency_SelectedIndexChanged);
            this.CmbCurrency.SelectedValueChanged += new System.EventHandler(this.CmbCurrency_SelectedValueChanged);
            // 
            // txtExRate
            // 
            resources.ApplyResources(this.txtExRate, "txtExRate");
            this.txtExRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtExRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtExRate.Format = null;
            this.txtExRate.isAllowNegative = false;
            this.txtExRate.isAllowSpecialChar = false;
            this.txtExRate.isNumbersOnly = false;
            this.txtExRate.isNumeric = true;
            this.txtExRate.isTouchable = false;
            this.txtExRate.Name = "txtExRate";
            this.txtExRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtAccount
            // 
            resources.ApplyResources(this.txtAccount, "txtAccount");
            this.txtAccount.BackColor = System.Drawing.SystemColors.Window;
            this.txtAccount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAccount.Format = null;
            this.txtAccount.isAllowNegative = false;
            this.txtAccount.isAllowSpecialChar = false;
            this.txtAccount.isNumbersOnly = false;
            this.txtAccount.isNumeric = false;
            this.txtAccount.isTouchable = false;
            this.txtAccount.Name = "txtAccount";
            this.txtAccount.ReadOnly = true;
            this.txtAccount.TabStop = false;
            this.txtAccount.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // rbtActive
            // 
            resources.ApplyResources(this.rbtActive, "rbtActive");
            this.rbtActive.Checked = true;
            this.rbtActive.Name = "rbtActive";
            this.rbtActive.TabStop = true;
            this.rbtActive.UseVisualStyleBackColor = true;
            this.rbtActive.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rbtActive_KeyDown);
            // 
            // txtCode
            // 
            resources.ApplyResources(this.txtCode, "txtCode");
            this.txtCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCode.Format = null;
            this.txtCode.isAllowNegative = false;
            this.txtCode.isAllowSpecialChar = false;
            this.txtCode.isNumbersOnly = false;
            this.txtCode.isNumeric = false;
            this.txtCode.isTouchable = false;
            this.txtCode.Name = "txtCode";
            this.txtCode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCode.Validated += new System.EventHandler(this.txtCode_Validated);
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            // 
            // rbtInactive
            // 
            resources.ApplyResources(this.rbtInactive, "rbtInactive");
            this.rbtInactive.Name = "rbtInactive";
            this.rbtInactive.UseVisualStyleBackColor = true;
            this.rbtInactive.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rbtInactive_KeyDown);
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory5
            // 
            resources.ApplyResources(this.lblMandatory5, "lblMandatory5");
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory5.Name = "lblMandatory5";
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.chkEnquiry);
            this.pnlMain.Controls.Add(this.atLabel1);
            this.pnlMain.Controls.Add(this.lblMandatory5);
            this.pnlMain.Controls.Add(this.cmbGender);
            this.pnlMain.Controls.Add(this.rbtInactive);
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.txtCode);
            this.pnlMain.Controls.Add(this.rbtActive);
            this.pnlMain.Controls.Add(this.txtAccount);
            this.pnlMain.Controls.Add(this.txtExRate);
            this.pnlMain.Controls.Add(this.CmbCurrency);
            this.pnlMain.Controls.Add(this.lblCode);
            this.pnlMain.Controls.Add(this.txtName);
            this.pnlMain.Controls.Add(this.lblExRate);
            this.pnlMain.Controls.Add(this.lblName);
            this.pnlMain.Controls.Add(this.lblAccount);
            this.pnlMain.Controls.Add(this.lblCurrency);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblMandatory3);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblMandatory6);
            this.pnlMain.Name = "pnlMain";
            // 
            // chkEnquiry
            // 
            resources.ApplyResources(this.chkEnquiry, "chkEnquiry");
            this.chkEnquiry.Name = "chkEnquiry";
            this.chkEnquiry.UseVisualStyleBackColor = true;
            this.chkEnquiry.CheckedChanged += new System.EventHandler(this.chkEnquiry_CheckedChanged);
            // 
            // atLabel1
            // 
            resources.ApplyResources(this.atLabel1, "atLabel1");
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            // 
            // cmbGender
            // 
            resources.ApplyResources(this.cmbGender, "cmbGender");
            this.cmbGender.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGender.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGender.DropDownHeight = 300;
            this.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Name = "cmbGender";
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblMandatory6
            // 
            resources.ApplyResources(this.lblMandatory6, "lblMandatory6");
            this.lblMandatory6.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory6.Name = "lblMandatory6";
            // 
            // pnlTabContain
            // 
            resources.ApplyResources(this.pnlTabContain, "pnlTabContain");
            this.pnlTabContain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlTabContain.Controls.Add(this.tabGuest);
            this.pnlTabContain.Name = "pnlTabContain";
            // 
            // tabGuest
            // 
            resources.ApplyResources(this.tabGuest, "tabGuest");
            this.tabGuest.Controls.Add(this.tabContactDetails);
            this.tabGuest.Controls.Add(this.tabOtherDetails);
            this.tabGuest.Name = "tabGuest";
            this.tabGuest.SelectedIndex = 0;
            this.tabGuest.TabStop = false;
            // 
            // tabContactDetails
            // 
            this.tabContactDetails.BackColor = System.Drawing.SystemColors.Window;
            this.tabContactDetails.Controls.Add(this.pnlContactDetails);
            resources.ApplyResources(this.tabContactDetails, "tabContactDetails");
            this.tabContactDetails.Name = "tabContactDetails";
            // 
            // pnlContactDetails
            // 
            this.pnlContactDetails.BackColor = System.Drawing.SystemColors.Window;
            this.pnlContactDetails.Controls.Add(this.lblContry);
            this.pnlContactDetails.Controls.Add(this.txtEmail);
            this.pnlContactDetails.Controls.Add(this.txtState);
            this.pnlContactDetails.Controls.Add(this.txtAdd3);
            this.pnlContactDetails.Controls.Add(this.lblCity);
            this.pnlContactDetails.Controls.Add(this.txtTelephone);
            this.pnlContactDetails.Controls.Add(this.CmbCountry);
            this.pnlContactDetails.Controls.Add(this.lblTelephone);
            this.pnlContactDetails.Controls.Add(this.txtAdd1);
            this.pnlContactDetails.Controls.Add(this.txtPostalcode);
            this.pnlContactDetails.Controls.Add(this.lblState);
            this.pnlContactDetails.Controls.Add(this.lblContactPerson);
            this.pnlContactDetails.Controls.Add(this.lblMobileNumber);
            this.pnlContactDetails.Controls.Add(this.txtAdd2);
            this.pnlContactDetails.Controls.Add(this.txtMobile);
            this.pnlContactDetails.Controls.Add(this.txtContactPerson);
            this.pnlContactDetails.Controls.Add(this.lblAddress3);
            this.pnlContactDetails.Controls.Add(this.lblAddress1);
            this.pnlContactDetails.Controls.Add(this.lblAddress2);
            this.pnlContactDetails.Controls.Add(this.lblPostalCode);
            this.pnlContactDetails.Controls.Add(this.txtCity);
            this.pnlContactDetails.Controls.Add(this.lblEmail);
            resources.ApplyResources(this.pnlContactDetails, "pnlContactDetails");
            this.pnlContactDetails.Name = "pnlContactDetails";
            // 
            // lblContry
            // 
            resources.ApplyResources(this.lblContry, "lblContry");
            this.lblContry.Name = "lblContry";
            this.lblContry.RequiredField = false;
            // 
            // txtEmail
            // 
            resources.ApplyResources(this.txtEmail, "txtEmail");
            this.txtEmail.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Format = null;
            this.txtEmail.isAllowNegative = false;
            this.txtEmail.isAllowSpecialChar = false;
            this.txtEmail.isNumbersOnly = false;
            this.txtEmail.isNumeric = false;
            this.txtEmail.isTouchable = false;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtEmail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEmail_KeyDown);
            // 
            // txtState
            // 
            resources.ApplyResources(this.txtState, "txtState");
            this.txtState.BackColor = System.Drawing.SystemColors.Window;
            this.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtState.Format = null;
            this.txtState.isAllowNegative = false;
            this.txtState.isAllowSpecialChar = false;
            this.txtState.isNumbersOnly = false;
            this.txtState.isNumeric = false;
            this.txtState.isTouchable = false;
            this.txtState.Name = "txtState";
            this.txtState.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtAdd3
            // 
            resources.ApplyResources(this.txtAdd3, "txtAdd3");
            this.txtAdd3.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdd3.Format = null;
            this.txtAdd3.isAllowNegative = false;
            this.txtAdd3.isAllowSpecialChar = false;
            this.txtAdd3.isNumbersOnly = false;
            this.txtAdd3.isNumeric = false;
            this.txtAdd3.isTouchable = false;
            this.txtAdd3.Name = "txtAdd3";
            this.txtAdd3.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblCity
            // 
            resources.ApplyResources(this.lblCity, "lblCity");
            this.lblCity.Name = "lblCity";
            this.lblCity.RequiredField = false;
            // 
            // txtTelephone
            // 
            resources.ApplyResources(this.txtTelephone, "txtTelephone");
            this.txtTelephone.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelephone.Format = null;
            this.txtTelephone.isAllowNegative = false;
            this.txtTelephone.isAllowSpecialChar = true;
            this.txtTelephone.isNumbersOnly = true;
            this.txtTelephone.isNumeric = false;
            this.txtTelephone.isTouchable = false;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // CmbCountry
            // 
            resources.ApplyResources(this.CmbCountry, "CmbCountry");
            this.CmbCountry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CmbCountry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCountry.DropDownHeight = 300;
            this.CmbCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCountry.FormattingEnabled = true;
            this.CmbCountry.Name = "CmbCountry";
            // 
            // lblTelephone
            // 
            resources.ApplyResources(this.lblTelephone, "lblTelephone");
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.RequiredField = false;
            // 
            // txtAdd1
            // 
            resources.ApplyResources(this.txtAdd1, "txtAdd1");
            this.txtAdd1.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdd1.Format = null;
            this.txtAdd1.isAllowNegative = false;
            this.txtAdd1.isAllowSpecialChar = false;
            this.txtAdd1.isNumbersOnly = false;
            this.txtAdd1.isNumeric = false;
            this.txtAdd1.isTouchable = false;
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtPostalcode
            // 
            resources.ApplyResources(this.txtPostalcode, "txtPostalcode");
            this.txtPostalcode.BackColor = System.Drawing.SystemColors.Window;
            this.txtPostalcode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPostalcode.Format = null;
            this.txtPostalcode.isAllowNegative = false;
            this.txtPostalcode.isAllowSpecialChar = true;
            this.txtPostalcode.isNumbersOnly = true;
            this.txtPostalcode.isNumeric = false;
            this.txtPostalcode.isTouchable = false;
            this.txtPostalcode.Name = "txtPostalcode";
            this.txtPostalcode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblState
            // 
            resources.ApplyResources(this.lblState, "lblState");
            this.lblState.Name = "lblState";
            this.lblState.RequiredField = false;
            // 
            // lblContactPerson
            // 
            resources.ApplyResources(this.lblContactPerson, "lblContactPerson");
            this.lblContactPerson.Name = "lblContactPerson";
            this.lblContactPerson.RequiredField = false;
            // 
            // lblMobileNumber
            // 
            resources.ApplyResources(this.lblMobileNumber, "lblMobileNumber");
            this.lblMobileNumber.Name = "lblMobileNumber";
            this.lblMobileNumber.RequiredField = false;
            // 
            // txtAdd2
            // 
            resources.ApplyResources(this.txtAdd2, "txtAdd2");
            this.txtAdd2.BackColor = System.Drawing.SystemColors.Window;
            this.txtAdd2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdd2.Format = null;
            this.txtAdd2.isAllowNegative = false;
            this.txtAdd2.isAllowSpecialChar = false;
            this.txtAdd2.isNumbersOnly = false;
            this.txtAdd2.isNumeric = false;
            this.txtAdd2.isTouchable = false;
            this.txtAdd2.Name = "txtAdd2";
            this.txtAdd2.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtMobile
            // 
            resources.ApplyResources(this.txtMobile, "txtMobile");
            this.txtMobile.BackColor = System.Drawing.SystemColors.Window;
            this.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMobile.Format = null;
            this.txtMobile.isAllowNegative = false;
            this.txtMobile.isAllowSpecialChar = true;
            this.txtMobile.isNumbersOnly = true;
            this.txtMobile.isNumeric = false;
            this.txtMobile.isTouchable = false;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtContactPerson
            // 
            resources.ApplyResources(this.txtContactPerson, "txtContactPerson");
            this.txtContactPerson.BackColor = System.Drawing.SystemColors.Window;
            this.txtContactPerson.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContactPerson.Format = null;
            this.txtContactPerson.isAllowNegative = false;
            this.txtContactPerson.isAllowSpecialChar = false;
            this.txtContactPerson.isNumbersOnly = false;
            this.txtContactPerson.isNumeric = false;
            this.txtContactPerson.isTouchable = false;
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAddress3
            // 
            resources.ApplyResources(this.lblAddress3, "lblAddress3");
            this.lblAddress3.Name = "lblAddress3";
            this.lblAddress3.RequiredField = false;
            // 
            // lblAddress1
            // 
            resources.ApplyResources(this.lblAddress1, "lblAddress1");
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.RequiredField = false;
            // 
            // lblAddress2
            // 
            resources.ApplyResources(this.lblAddress2, "lblAddress2");
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.RequiredField = false;
            // 
            // lblPostalCode
            // 
            resources.ApplyResources(this.lblPostalCode, "lblPostalCode");
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.RequiredField = false;
            // 
            // txtCity
            // 
            resources.ApplyResources(this.txtCity, "txtCity");
            this.txtCity.BackColor = System.Drawing.SystemColors.Window;
            this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCity.Format = null;
            this.txtCity.isAllowNegative = false;
            this.txtCity.isAllowSpecialChar = false;
            this.txtCity.isNumbersOnly = false;
            this.txtCity.isNumeric = false;
            this.txtCity.isTouchable = false;
            this.txtCity.Name = "txtCity";
            this.txtCity.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblEmail
            // 
            resources.ApplyResources(this.lblEmail, "lblEmail");
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.RequiredField = false;
            // 
            // tabOtherDetails
            // 
            this.tabOtherDetails.BackColor = System.Drawing.SystemColors.Window;
            this.tabOtherDetails.Controls.Add(this.pnlOtherDetails);
            resources.ApplyResources(this.tabOtherDetails, "tabOtherDetails");
            this.tabOtherDetails.Name = "tabOtherDetails";
            // 
            // pnlOtherDetails
            // 
            this.pnlOtherDetails.BackColor = System.Drawing.SystemColors.Window;
            this.pnlOtherDetails.Controls.Add(this.lblMandatory8);
            this.pnlOtherDetails.Controls.Add(this.btnNewProofType);
            this.pnlOtherDetails.Controls.Add(this.CmbCreditCardType);
            this.pnlOtherDetails.Controls.Add(this.lblCreditCardType);
            this.pnlOtherDetails.Controls.Add(this.txtDiscPerc);
            this.pnlOtherDetails.Controls.Add(this.lblDiscInPerc);
            this.pnlOtherDetails.Controls.Add(this.cmbProofType);
            this.pnlOtherDetails.Controls.Add(this.lblProofType);
            this.pnlOtherDetails.Controls.Add(this.txtCreditCardNo);
            this.pnlOtherDetails.Controls.Add(this.lblBankName);
            this.pnlOtherDetails.Controls.Add(this.txtBankName);
            this.pnlOtherDetails.Controls.Add(this.txtProofNo);
            this.pnlOtherDetails.Controls.Add(this.lblAccountName);
            this.pnlOtherDetails.Controls.Add(this.lblCreditCardNo);
            this.pnlOtherDetails.Controls.Add(this.txtSWIFTCode);
            this.pnlOtherDetails.Controls.Add(this.lblSWIFTCode);
            this.pnlOtherDetails.Controls.Add(this.txtBankNo);
            this.pnlOtherDetails.Controls.Add(this.lblVehicleNo);
            this.pnlOtherDetails.Controls.Add(this.lblPreferences);
            this.pnlOtherDetails.Controls.Add(this.txtPreferences);
            this.pnlOtherDetails.Controls.Add(this.txtVehicleNo);
            this.pnlOtherDetails.Controls.Add(this.lblProofNo);
            this.pnlOtherDetails.Controls.Add(this.lblMandatory7);
            resources.ApplyResources(this.pnlOtherDetails, "pnlOtherDetails");
            this.pnlOtherDetails.Name = "pnlOtherDetails";
            // 
            // btnNewProofType
            // 
            this.btnNewProofType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnNewProofType.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnNewProofType, "btnNewProofType");
            this.btnNewProofType.ForeColor = System.Drawing.Color.White;
            this.btnNewProofType.Name = "btnNewProofType";
            this.btnNewProofType.TabStop = false;
            this.btnNewProofType.Tag = "";
            this.btnNewProofType.UseVisualStyleBackColor = false;
            this.btnNewProofType.Click += new System.EventHandler(this.btnNewProofType_Click);
            // 
            // CmbCreditCardType
            // 
            this.CmbCreditCardType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CmbCreditCardType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCreditCardType.DropDownHeight = 300;
            this.CmbCreditCardType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.CmbCreditCardType, "CmbCreditCardType");
            this.CmbCreditCardType.FormattingEnabled = true;
            this.CmbCreditCardType.Name = "CmbCreditCardType";
            // 
            // lblCreditCardType
            // 
            resources.ApplyResources(this.lblCreditCardType, "lblCreditCardType");
            this.lblCreditCardType.Name = "lblCreditCardType";
            this.lblCreditCardType.RequiredField = false;
            // 
            // txtDiscPerc
            // 
            resources.ApplyResources(this.txtDiscPerc, "txtDiscPerc");
            this.txtDiscPerc.BackColor = System.Drawing.SystemColors.Window;
            this.txtDiscPerc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiscPerc.Format = null;
            this.txtDiscPerc.isAllowNegative = false;
            this.txtDiscPerc.isAllowSpecialChar = false;
            this.txtDiscPerc.isNumbersOnly = false;
            this.txtDiscPerc.isNumeric = true;
            this.txtDiscPerc.isTouchable = false;
            this.txtDiscPerc.Name = "txtDiscPerc";
            this.txtDiscPerc.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblDiscInPerc
            // 
            resources.ApplyResources(this.lblDiscInPerc, "lblDiscInPerc");
            this.lblDiscInPerc.Name = "lblDiscInPerc";
            this.lblDiscInPerc.RequiredField = false;
            // 
            // cmbProofType
            // 
            this.cmbProofType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbProofType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProofType.DropDownHeight = 300;
            this.cmbProofType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbProofType, "cmbProofType");
            this.cmbProofType.FormattingEnabled = true;
            this.cmbProofType.Name = "cmbProofType";
            this.cmbProofType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbProofType_KeyDown);
            // 
            // lblProofType
            // 
            resources.ApplyResources(this.lblProofType, "lblProofType");
            this.lblProofType.Name = "lblProofType";
            this.lblProofType.RequiredField = false;
            // 
            // txtCreditCardNo
            // 
            resources.ApplyResources(this.txtCreditCardNo, "txtCreditCardNo");
            this.txtCreditCardNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtCreditCardNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCreditCardNo.Format = null;
            this.txtCreditCardNo.isAllowNegative = false;
            this.txtCreditCardNo.isAllowSpecialChar = false;
            this.txtCreditCardNo.isNumbersOnly = true;
            this.txtCreditCardNo.isNumeric = false;
            this.txtCreditCardNo.isTouchable = false;
            this.txtCreditCardNo.Name = "txtCreditCardNo";
            this.txtCreditCardNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblBankName
            // 
            resources.ApplyResources(this.lblBankName, "lblBankName");
            this.lblBankName.Name = "lblBankName";
            this.lblBankName.RequiredField = false;
            // 
            // txtBankName
            // 
            resources.ApplyResources(this.txtBankName, "txtBankName");
            this.txtBankName.BackColor = System.Drawing.SystemColors.Window;
            this.txtBankName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBankName.Format = null;
            this.txtBankName.isAllowNegative = false;
            this.txtBankName.isAllowSpecialChar = false;
            this.txtBankName.isNumbersOnly = false;
            this.txtBankName.isNumeric = false;
            this.txtBankName.isTouchable = false;
            this.txtBankName.Name = "txtBankName";
            this.txtBankName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtProofNo
            // 
            resources.ApplyResources(this.txtProofNo, "txtProofNo");
            this.txtProofNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtProofNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProofNo.Format = null;
            this.txtProofNo.isAllowNegative = false;
            this.txtProofNo.isAllowSpecialChar = false;
            this.txtProofNo.isNumbersOnly = false;
            this.txtProofNo.isNumeric = false;
            this.txtProofNo.isTouchable = false;
            this.txtProofNo.Name = "txtProofNo";
            this.txtProofNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblAccountName
            // 
            resources.ApplyResources(this.lblAccountName, "lblAccountName");
            this.lblAccountName.Name = "lblAccountName";
            this.lblAccountName.RequiredField = false;
            // 
            // lblCreditCardNo
            // 
            resources.ApplyResources(this.lblCreditCardNo, "lblCreditCardNo");
            this.lblCreditCardNo.Name = "lblCreditCardNo";
            this.lblCreditCardNo.RequiredField = false;
            // 
            // txtSWIFTCode
            // 
            resources.ApplyResources(this.txtSWIFTCode, "txtSWIFTCode");
            this.txtSWIFTCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtSWIFTCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSWIFTCode.Format = null;
            this.txtSWIFTCode.isAllowNegative = false;
            this.txtSWIFTCode.isAllowSpecialChar = false;
            this.txtSWIFTCode.isNumbersOnly = false;
            this.txtSWIFTCode.isNumeric = false;
            this.txtSWIFTCode.isTouchable = false;
            this.txtSWIFTCode.Name = "txtSWIFTCode";
            this.txtSWIFTCode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblSWIFTCode
            // 
            resources.ApplyResources(this.lblSWIFTCode, "lblSWIFTCode");
            this.lblSWIFTCode.Name = "lblSWIFTCode";
            this.lblSWIFTCode.RequiredField = false;
            // 
            // txtBankNo
            // 
            resources.ApplyResources(this.txtBankNo, "txtBankNo");
            this.txtBankNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtBankNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBankNo.Format = null;
            this.txtBankNo.isAllowNegative = false;
            this.txtBankNo.isAllowSpecialChar = false;
            this.txtBankNo.isNumbersOnly = false;
            this.txtBankNo.isNumeric = false;
            this.txtBankNo.isTouchable = false;
            this.txtBankNo.Name = "txtBankNo";
            this.txtBankNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblVehicleNo
            // 
            resources.ApplyResources(this.lblVehicleNo, "lblVehicleNo");
            this.lblVehicleNo.Name = "lblVehicleNo";
            this.lblVehicleNo.RequiredField = false;
            // 
            // lblPreferences
            // 
            resources.ApplyResources(this.lblPreferences, "lblPreferences");
            this.lblPreferences.Name = "lblPreferences";
            this.lblPreferences.RequiredField = false;
            // 
            // txtPreferences
            // 
            resources.ApplyResources(this.txtPreferences, "txtPreferences");
            this.txtPreferences.BackColor = System.Drawing.SystemColors.Window;
            this.txtPreferences.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPreferences.Format = null;
            this.txtPreferences.isAllowNegative = false;
            this.txtPreferences.isAllowSpecialChar = false;
            this.txtPreferences.isNumbersOnly = false;
            this.txtPreferences.isNumeric = false;
            this.txtPreferences.isTouchable = false;
            this.txtPreferences.Name = "txtPreferences";
            this.txtPreferences.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtPreferences.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPreferences_KeyDown);
            // 
            // txtVehicleNo
            // 
            resources.ApplyResources(this.txtVehicleNo, "txtVehicleNo");
            this.txtVehicleNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtVehicleNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVehicleNo.Format = null;
            this.txtVehicleNo.isAllowNegative = false;
            this.txtVehicleNo.isAllowSpecialChar = false;
            this.txtVehicleNo.isNumbersOnly = false;
            this.txtVehicleNo.isNumeric = false;
            this.txtVehicleNo.isTouchable = false;
            this.txtVehicleNo.Name = "txtVehicleNo";
            this.txtVehicleNo.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblProofNo
            // 
            resources.ApplyResources(this.lblProofNo, "lblProofNo");
            this.lblProofNo.Name = "lblProofNo";
            this.lblProofNo.RequiredField = false;
            // 
            // btnEnquiry
            // 
            this.btnEnquiry.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnEnquiry.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnEnquiry, "btnEnquiry");
            this.btnEnquiry.ForeColor = System.Drawing.Color.White;
            this.btnEnquiry.Name = "btnEnquiry";
            this.btnEnquiry.UseVisualStyleBackColor = false;
            this.btnEnquiry.Click += new System.EventHandler(this.btnEnquiry_Click);
            // 
            // lblMandatory7
            // 
            resources.ApplyResources(this.lblMandatory7, "lblMandatory7");
            this.lblMandatory7.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory7.Name = "lblMandatory7";
            // 
            // lblMandatory8
            // 
            resources.ApplyResources(this.lblMandatory8, "lblMandatory8");
            this.lblMandatory8.ForeColor = System.Drawing.Color.Crimson;
            this.lblMandatory8.Name = "lblMandatory8";
            // 
            // GuestView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlTabContain);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlOptionalBar);
            this.Name = "GuestView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.GuestView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.GuestView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.GuestView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.GuestView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.GuestView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.GuestView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.GuestView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.GuestView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.GuestView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.GuestView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.GuestView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.GuestView_atBeforeSearch);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlTabContain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.pnlOptionalBar.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlTabContain.ResumeLayout(false);
            this.tabGuest.ResumeLayout(false);
            this.tabContactDetails.ResumeLayout(false);
            this.pnlContactDetails.ResumeLayout(false);
            this.pnlContactDetails.PerformLayout();
            this.tabOtherDetails.ResumeLayout(false);
            this.pnlOtherDetails.ResumeLayout(false);
            this.pnlOtherDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private atACCFramework.UserControls.atGradientPanel btnSelected;
        private atACCFramework.UserControls.atImageFrame atImageframe;
        private System.Windows.Forms.Button btnOtherDetails;
        private System.Windows.Forms.Button btnContactDetails;
        private atACCFramework.UserControls.atLabel lblCurrency;
        private atACCFramework.UserControls.atLabel lblAccount;
        private atACCFramework.UserControls.atLabel lblName;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory3;
        private atACCFramework.UserControls.atLabel lblExRate;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private atACCFramework.UserControls.atLabel lblCode;
        private atACCFramework.UserControls.ComboBoxExt CmbCurrency;
        private atACCFramework.UserControls.TextBoxExt txtExRate;
        private atACCFramework.UserControls.TextBoxExt txtAccount;
        private atACCFramework.UserControls.atRadioButton rbtActive;
        private atACCFramework.UserControls.TextBoxExt txtCode;
        private atACCFramework.UserControls.atLabel lblStatus;
        private atACCFramework.UserControls.atRadioButton rbtInactive;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory5;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atPanel pnlTabContain;
        private atACCFramework.UserControls.atTabControl tabGuest;
        private System.Windows.Forms.TabPage tabContactDetails;
        private atACCFramework.UserControls.atPanel pnlContactDetails;
        private atACCFramework.UserControls.atLabel lblContry;
        private atACCFramework.UserControls.TextBoxExt txtEmail;
        private atACCFramework.UserControls.TextBoxExt txtState;
        private atACCFramework.UserControls.TextBoxExt txtAdd3;
        private atACCFramework.UserControls.atLabel lblCity;
        private atACCFramework.UserControls.TextBoxExt txtTelephone;
        private atACCFramework.UserControls.ComboBoxExt CmbCountry;
        private atACCFramework.UserControls.atLabel lblTelephone;
        private atACCFramework.UserControls.TextBoxExt txtAdd1;
        private atACCFramework.UserControls.TextBoxExt txtPostalcode;
        private atACCFramework.UserControls.atLabel lblState;
        private atACCFramework.UserControls.atLabel lblContactPerson;
        private atACCFramework.UserControls.atLabel lblMobileNumber;
        private atACCFramework.UserControls.TextBoxExt txtAdd2;
        private atACCFramework.UserControls.TextBoxExt txtMobile;
        private atACCFramework.UserControls.TextBoxExt txtContactPerson;
        private atACCFramework.UserControls.atLabel lblAddress3;
        private atACCFramework.UserControls.atLabel lblAddress1;
        private atACCFramework.UserControls.atLabel lblAddress2;
        private atACCFramework.UserControls.atLabel lblPostalCode;
        private atACCFramework.UserControls.TextBoxExt txtCity;
        private atACCFramework.UserControls.atLabel lblEmail;
        private System.Windows.Forms.TabPage tabOtherDetails;
        private atACCFramework.UserControls.atPanel pnlOtherDetails;
        private atACCFramework.UserControls.TextBoxExt txtCreditCardNo;
        private atACCFramework.UserControls.atLabel lblBankName;
        private atACCFramework.UserControls.TextBoxExt txtBankName;
        private atACCFramework.UserControls.atLabel lblAccountName;
        private atACCFramework.UserControls.atLabel lblCreditCardNo;
        private atACCFramework.UserControls.TextBoxExt txtSWIFTCode;
        private atACCFramework.UserControls.atLabel lblSWIFTCode;
        private atACCFramework.UserControls.TextBoxExt txtBankNo;
        private atACCFramework.UserControls.atLabel lblVehicleNo;
        private atACCFramework.UserControls.atLabel lblPreferences;
        private atACCFramework.UserControls.TextBoxExt txtPreferences;
        private atACCFramework.UserControls.TextBoxExt txtVehicleNo;
        private atACCFramework.UserControls.ComboBoxExt cmbProofType;
        private atACCFramework.UserControls.atLabel lblProofType;
        private atACCFramework.UserControls.TextBoxExt txtProofNo;
        private atACCFramework.UserControls.atLabel lblProofNo;
        private atACCFramework.UserControls.TextBoxExt txtDiscPerc;
        private atACCFramework.UserControls.atLabel lblDiscInPerc;
        private atACCFramework.UserControls.ComboBoxExt CmbCreditCardType;
        private atACCFramework.UserControls.atLabel lblCreditCardType;
        private atACCFramework.UserControls.atLabel atLabel1;
        private atACCFramework.UserControls.ComboBoxExt cmbGender;
        private System.Windows.Forms.Label lblMandatory6;
        private System.Windows.Forms.Label lblMandatory4;
        private atACCFramework.UserControls.atButton btnNewProofType;
        private atACCFramework.UserControls.atButton btnEnquiry;
        private atACCFramework.UserControls.atCheckBox chkEnquiry;
        private System.Windows.Forms.Label lblMandatory8;
        private System.Windows.Forms.Label lblMandatory7;
    }
}