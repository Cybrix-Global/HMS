﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class MasterValueView : SearchFormBase2
    {
        #region Constructor
        public MasterValueView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            iContextID = 36;
        }
        public MasterValueView(int _MasterType)
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            iContextID = 36;
            MasterType = _MasterType;
            txtName.Focus();
        }
        #endregion

        #region Public Properties
        public int CurrentID { get; set; }
        #endregion

        #region Private Variables
        MasterValue m_MasterValue;
        List<MasterValue> m_MasterValues;
        List<MasterType> m_MasterTypes;
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        ANIHelper aniHelper;
        ToolTip tooltip;
        int MasterType;
        #endregion

        #region Populate Events
        private void PopulateMasterValue()
        {
            try
            {
                if (MasterType != null && MasterType != 0)
                {
                    m_MasterValues = dbh.MasterValues.Where(x=>x.FK_MasterTypeID == MasterType).ToList();
                }
                else
                {
                    m_MasterValues = dbh.MasterValues.ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateMasterTypes()
        {
            m_MasterTypes = dbh.MasterTypes.ToList();
            objLib.fnFillCombo(ref cmbMasterType, m_MasterTypes, "Description", "id");
            if (MasterType != null && MasterType != 0)
            {
                cmbMasterType.SelectedValue = MasterType;
                cmbMasterType.Enabled = false;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            try
            {
                m_MasterValue = new MasterValue();
                m_MasterValues = new List<MasterValue>();
                txtName.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void MasterValueView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                objLib = new CommonLibClasses();
                m_MasterValue = new MasterValue();
                SettingsButton.Visible = ShareButton.Visible = false;
                PrintButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
                DeleteButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void MasterValueView_atAfterInitialise()
        {
            try
            {
                txtName.Focus();
                ShowToolTip();
                PopulateMasterValue();
                PopulateMasterTypes();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void MasterValueView_atNewClick(object source)
        {
            try
            {
                m_MasterValue = new MasterValue();
                dbh = atHotelContext.CreateContext();
                txtName.Focus();
                FnClearAll();
                ShowToolTip();
                PopulateMasterValue();
                PopulateMasterTypes();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool MasterValueView_atValidate(object source)
        {
            try
            {
                if (txtName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool MasterValueView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    m_MasterValue = new MasterValue();
                }
                m_MasterValue.ContextID = iContextID;
                m_MasterValue.LocationID = GlobalFunctions.LoginLocationID;
                m_MasterValue.LoginUserID = GlobalFunctions.LoginUserID;
                m_MasterValue.isUserDefined = true;
                m_MasterValue.Name = txtName.Text;
                m_MasterValue.Description = txtName.Text;
                m_MasterValue.FK_MasterTypeID = cmbMasterType.SelectedValue.ToInt32();
                if (NewRecord)
                {
                    dbh.MasterValues.AddObject(m_MasterValue);
                }
                if (!NewRecord)
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_MasterValue, EntityState.Modified);
                }
                dbh.SaveChanges();
                CurrentID = m_MasterValue.id;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool MasterValueView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void MasterValueView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var mValue = m_MasterValues.Select(x => new { id = x.id, Name = x.Name }).OrderByDescending(x => x.id);
                e.SearchEntityList = mValue;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_MasterValue = dbh.MasterValues.Where(x => x.id == ID).SingleOrDefault();
                if (m_MasterValue != null)
                {
                    txtName.Text = m_MasterValue.Description;
                    cmbMasterType.SelectedValue = m_MasterValue.FK_MasterTypeID.ToString().ToInt32();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool MasterValueView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
             try
             {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var mValue = new { id = 0, Name = "" };
                    ReLoadData(e.GetSelectedEntity().Cast(mValue).id);
                }
                else 
                {
                    txtName.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private void MasterValueView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtName.Focus();
                cmbMasterType.Enabled = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool MasterValueView_atDelete(object source, DeleteClickEventArgs e)
        {
            return default(bool);
        }
        #endregion
    }
}
