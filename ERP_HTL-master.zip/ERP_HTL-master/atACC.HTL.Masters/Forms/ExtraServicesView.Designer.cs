﻿namespace atACC.HTL.Masters
{
    partial class ExtraServicesView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExtraServicesView));
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblMandatory5 = new System.Windows.Forms.Label();
            this.lblType = new atACCFramework.UserControls.atLabel();
            this.cmbType = new atACCFramework.UserControls.ComboBoxExt();
            this.btnSepearator1 = new System.Windows.Forms.Button();
            this.lblSlabs = new atACCFramework.UserControls.atLabel();
            this.lblExciseDuty = new atACCFramework.UserControls.atLabel();
            this.cmbTax3 = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbAddlTax = new atACCFramework.UserControls.ComboBoxExt();
            this.lblAdditionalTax = new atACCFramework.UserControls.atLabel();
            this.cmbTax2 = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbTax1 = new atACCFramework.UserControls.ComboBoxExt();
            this.lblTax3 = new atACCFramework.UserControls.atLabel();
            this.lblDiscount = new atACCFramework.UserControls.atLabel();
            this.cmbExciseDuty = new atACCFramework.UserControls.ComboBoxExt();
            this.lblGST = new atACCFramework.UserControls.atLabel();
            this.cmbDiscount = new atACCFramework.UserControls.ComboBoxExt();
            this.lblVAT = new atACCFramework.UserControls.atLabel();
            this.lblTax2 = new atACCFramework.UserControls.atLabel();
            this.lblTax1 = new atACCFramework.UserControls.atLabel();
            this.cmbGST = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbVAT = new atACCFramework.UserControls.ComboBoxExt();
            this.rbtInactive = new atACCFramework.UserControls.atRadioButton();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.rbtActive = new atACCFramework.UserControls.atRadioButton();
            this.lblMandatory4 = new System.Windows.Forms.Label();
            this.lblDefaultRate = new atACCFramework.UserControls.atLabel();
            this.txtDefaultRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.txtCode = new atACCFramework.UserControls.TextBoxExt();
            this.lblCode = new atACCFramework.UserControls.atLabel();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            this.lblName = new atACCFramework.UserControls.atLabel();
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.errProvider.SetError(this.panel1, resources.GetString("panel1.Error"));
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.panel1, ((int)(resources.GetObject("panel1.IconPadding"))));
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblMandatory5);
            this.pnlMain.Controls.Add(this.lblType);
            this.pnlMain.Controls.Add(this.cmbType);
            this.pnlMain.Controls.Add(this.btnSepearator1);
            this.pnlMain.Controls.Add(this.lblSlabs);
            this.pnlMain.Controls.Add(this.lblExciseDuty);
            this.pnlMain.Controls.Add(this.cmbTax3);
            this.pnlMain.Controls.Add(this.cmbAddlTax);
            this.pnlMain.Controls.Add(this.lblAdditionalTax);
            this.pnlMain.Controls.Add(this.cmbTax2);
            this.pnlMain.Controls.Add(this.cmbTax1);
            this.pnlMain.Controls.Add(this.lblTax3);
            this.pnlMain.Controls.Add(this.lblDiscount);
            this.pnlMain.Controls.Add(this.cmbExciseDuty);
            this.pnlMain.Controls.Add(this.lblGST);
            this.pnlMain.Controls.Add(this.cmbDiscount);
            this.pnlMain.Controls.Add(this.lblVAT);
            this.pnlMain.Controls.Add(this.lblTax2);
            this.pnlMain.Controls.Add(this.lblTax1);
            this.pnlMain.Controls.Add(this.cmbGST);
            this.pnlMain.Controls.Add(this.cmbVAT);
            this.pnlMain.Controls.Add(this.rbtInactive);
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.rbtActive);
            this.pnlMain.Controls.Add(this.lblMandatory4);
            this.pnlMain.Controls.Add(this.lblDefaultRate);
            this.pnlMain.Controls.Add(this.txtDefaultRate);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.txtCode);
            this.pnlMain.Controls.Add(this.lblCode);
            this.pnlMain.Controls.Add(this.txtName);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.pnlMain.Controls.Add(this.lblName);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // lblMandatory5
            // 
            resources.ApplyResources(this.lblMandatory5, "lblMandatory5");
            this.errProvider.SetError(this.lblMandatory5, resources.GetString("lblMandatory5.Error"));
            this.lblMandatory5.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory5, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory5.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory5, ((int)(resources.GetObject("lblMandatory5.IconPadding"))));
            this.lblMandatory5.Name = "lblMandatory5";
            // 
            // lblType
            // 
            resources.ApplyResources(this.lblType, "lblType");
            this.errProvider.SetError(this.lblType, resources.GetString("lblType.Error"));
            this.errProvider.SetIconAlignment(this.lblType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblType, ((int)(resources.GetObject("lblType.IconPadding"))));
            this.lblType.Name = "lblType";
            this.lblType.RequiredField = false;
            // 
            // cmbType
            // 
            resources.ApplyResources(this.cmbType, "cmbType");
            this.cmbType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbType.BackColor = System.Drawing.SystemColors.Window;
            this.cmbType.DropDownHeight = 300;
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbType, resources.GetString("cmbType.Error"));
            this.cmbType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbType.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbType, ((int)(resources.GetObject("cmbType.IconPadding"))));
            this.cmbType.Name = "cmbType";
            // 
            // btnSepearator1
            // 
            resources.ApplyResources(this.btnSepearator1, "btnSepearator1");
            this.btnSepearator1.BackColor = System.Drawing.Color.LightGray;
            this.errProvider.SetError(this.btnSepearator1, resources.GetString("btnSepearator1.Error"));
            this.btnSepearator1.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSepearator1.FlatAppearance.BorderSize = 0;
            this.errProvider.SetIconAlignment(this.btnSepearator1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("btnSepearator1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.btnSepearator1, ((int)(resources.GetObject("btnSepearator1.IconPadding"))));
            this.btnSepearator1.Name = "btnSepearator1";
            this.btnSepearator1.UseVisualStyleBackColor = false;
            // 
            // lblSlabs
            // 
            resources.ApplyResources(this.lblSlabs, "lblSlabs");
            this.errProvider.SetError(this.lblSlabs, resources.GetString("lblSlabs.Error"));
            this.errProvider.SetIconAlignment(this.lblSlabs, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblSlabs.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblSlabs, ((int)(resources.GetObject("lblSlabs.IconPadding"))));
            this.lblSlabs.Name = "lblSlabs";
            this.lblSlabs.RequiredField = false;
            // 
            // lblExciseDuty
            // 
            resources.ApplyResources(this.lblExciseDuty, "lblExciseDuty");
            this.errProvider.SetError(this.lblExciseDuty, resources.GetString("lblExciseDuty.Error"));
            this.errProvider.SetIconAlignment(this.lblExciseDuty, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblExciseDuty.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblExciseDuty, ((int)(resources.GetObject("lblExciseDuty.IconPadding"))));
            this.lblExciseDuty.Name = "lblExciseDuty";
            this.lblExciseDuty.RequiredField = false;
            // 
            // cmbTax3
            // 
            resources.ApplyResources(this.cmbTax3, "cmbTax3");
            this.cmbTax3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax3.DropDownHeight = 300;
            this.cmbTax3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbTax3, resources.GetString("cmbTax3.Error"));
            this.cmbTax3.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbTax3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbTax3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbTax3, ((int)(resources.GetObject("cmbTax3.IconPadding"))));
            this.cmbTax3.Name = "cmbTax3";
            this.cmbTax3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTax3_KeyDown);
            // 
            // cmbAddlTax
            // 
            resources.ApplyResources(this.cmbAddlTax, "cmbAddlTax");
            this.cmbAddlTax.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAddlTax.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAddlTax.DropDownHeight = 300;
            this.cmbAddlTax.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbAddlTax, resources.GetString("cmbAddlTax.Error"));
            this.cmbAddlTax.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbAddlTax, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbAddlTax.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbAddlTax, ((int)(resources.GetObject("cmbAddlTax.IconPadding"))));
            this.cmbAddlTax.Name = "cmbAddlTax";
            this.cmbAddlTax.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbAddlTax_KeyDown);
            // 
            // lblAdditionalTax
            // 
            resources.ApplyResources(this.lblAdditionalTax, "lblAdditionalTax");
            this.errProvider.SetError(this.lblAdditionalTax, resources.GetString("lblAdditionalTax.Error"));
            this.errProvider.SetIconAlignment(this.lblAdditionalTax, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAdditionalTax.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblAdditionalTax, ((int)(resources.GetObject("lblAdditionalTax.IconPadding"))));
            this.lblAdditionalTax.Name = "lblAdditionalTax";
            this.lblAdditionalTax.RequiredField = false;
            // 
            // cmbTax2
            // 
            resources.ApplyResources(this.cmbTax2, "cmbTax2");
            this.cmbTax2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax2.DropDownHeight = 300;
            this.cmbTax2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbTax2, resources.GetString("cmbTax2.Error"));
            this.cmbTax2.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbTax2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbTax2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbTax2, ((int)(resources.GetObject("cmbTax2.IconPadding"))));
            this.cmbTax2.Name = "cmbTax2";
            this.cmbTax2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTax2_KeyDown);
            // 
            // cmbTax1
            // 
            resources.ApplyResources(this.cmbTax1, "cmbTax1");
            this.cmbTax1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax1.DropDownHeight = 300;
            this.cmbTax1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbTax1, resources.GetString("cmbTax1.Error"));
            this.cmbTax1.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbTax1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbTax1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbTax1, ((int)(resources.GetObject("cmbTax1.IconPadding"))));
            this.cmbTax1.Name = "cmbTax1";
            this.cmbTax1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTax1_KeyDown);
            // 
            // lblTax3
            // 
            resources.ApplyResources(this.lblTax3, "lblTax3");
            this.errProvider.SetError(this.lblTax3, resources.GetString("lblTax3.Error"));
            this.errProvider.SetIconAlignment(this.lblTax3, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTax3.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTax3, ((int)(resources.GetObject("lblTax3.IconPadding"))));
            this.lblTax3.Name = "lblTax3";
            this.lblTax3.RequiredField = false;
            // 
            // lblDiscount
            // 
            resources.ApplyResources(this.lblDiscount, "lblDiscount");
            this.errProvider.SetError(this.lblDiscount, resources.GetString("lblDiscount.Error"));
            this.errProvider.SetIconAlignment(this.lblDiscount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDiscount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblDiscount, ((int)(resources.GetObject("lblDiscount.IconPadding"))));
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.RequiredField = false;
            // 
            // cmbExciseDuty
            // 
            resources.ApplyResources(this.cmbExciseDuty, "cmbExciseDuty");
            this.cmbExciseDuty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbExciseDuty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbExciseDuty.DropDownHeight = 300;
            this.cmbExciseDuty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbExciseDuty, resources.GetString("cmbExciseDuty.Error"));
            this.cmbExciseDuty.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbExciseDuty, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbExciseDuty.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbExciseDuty, ((int)(resources.GetObject("cmbExciseDuty.IconPadding"))));
            this.cmbExciseDuty.Name = "cmbExciseDuty";
            this.cmbExciseDuty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbExciseDuty_KeyDown);
            // 
            // lblGST
            // 
            resources.ApplyResources(this.lblGST, "lblGST");
            this.errProvider.SetError(this.lblGST, resources.GetString("lblGST.Error"));
            this.errProvider.SetIconAlignment(this.lblGST, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblGST.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblGST, ((int)(resources.GetObject("lblGST.IconPadding"))));
            this.lblGST.Name = "lblGST";
            this.lblGST.RequiredField = false;
            // 
            // cmbDiscount
            // 
            resources.ApplyResources(this.cmbDiscount, "cmbDiscount");
            this.cmbDiscount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbDiscount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDiscount.BackColor = System.Drawing.SystemColors.Window;
            this.cmbDiscount.DropDownHeight = 300;
            this.cmbDiscount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbDiscount, resources.GetString("cmbDiscount.Error"));
            this.cmbDiscount.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbDiscount, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbDiscount.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbDiscount, ((int)(resources.GetObject("cmbDiscount.IconPadding"))));
            this.cmbDiscount.Name = "cmbDiscount";
            this.cmbDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbDiscount_KeyDown);
            // 
            // lblVAT
            // 
            resources.ApplyResources(this.lblVAT, "lblVAT");
            this.errProvider.SetError(this.lblVAT, resources.GetString("lblVAT.Error"));
            this.errProvider.SetIconAlignment(this.lblVAT, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblVAT.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblVAT, ((int)(resources.GetObject("lblVAT.IconPadding"))));
            this.lblVAT.Name = "lblVAT";
            this.lblVAT.RequiredField = false;
            // 
            // lblTax2
            // 
            resources.ApplyResources(this.lblTax2, "lblTax2");
            this.errProvider.SetError(this.lblTax2, resources.GetString("lblTax2.Error"));
            this.errProvider.SetIconAlignment(this.lblTax2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTax2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTax2, ((int)(resources.GetObject("lblTax2.IconPadding"))));
            this.lblTax2.Name = "lblTax2";
            this.lblTax2.RequiredField = false;
            // 
            // lblTax1
            // 
            resources.ApplyResources(this.lblTax1, "lblTax1");
            this.errProvider.SetError(this.lblTax1, resources.GetString("lblTax1.Error"));
            this.errProvider.SetIconAlignment(this.lblTax1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblTax1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblTax1, ((int)(resources.GetObject("lblTax1.IconPadding"))));
            this.lblTax1.Name = "lblTax1";
            this.lblTax1.RequiredField = false;
            // 
            // cmbGST
            // 
            resources.ApplyResources(this.cmbGST, "cmbGST");
            this.cmbGST.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGST.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGST.DropDownHeight = 300;
            this.cmbGST.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbGST, resources.GetString("cmbGST.Error"));
            this.cmbGST.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbGST, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbGST.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbGST, ((int)(resources.GetObject("cmbGST.IconPadding"))));
            this.cmbGST.Name = "cmbGST";
            this.cmbGST.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbGST_KeyDown);
            // 
            // cmbVAT
            // 
            resources.ApplyResources(this.cmbVAT, "cmbVAT");
            this.cmbVAT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbVAT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVAT.DropDownHeight = 300;
            this.cmbVAT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.errProvider.SetError(this.cmbVAT, resources.GetString("cmbVAT.Error"));
            this.cmbVAT.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbVAT, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbVAT.IconAlignment"))));
            this.errProvider.SetIconPadding(this.cmbVAT, ((int)(resources.GetObject("cmbVAT.IconPadding"))));
            this.cmbVAT.Name = "cmbVAT";
            this.cmbVAT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbVAT_KeyDown);
            // 
            // rbtInactive
            // 
            resources.ApplyResources(this.rbtInactive, "rbtInactive");
            this.errProvider.SetError(this.rbtInactive, resources.GetString("rbtInactive.Error"));
            this.errProvider.SetIconAlignment(this.rbtInactive, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtInactive.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtInactive, ((int)(resources.GetObject("rbtInactive.IconPadding"))));
            this.rbtInactive.Name = "rbtInactive";
            this.rbtInactive.UseVisualStyleBackColor = true;
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.errProvider.SetError(this.lblStatus, resources.GetString("lblStatus.Error"));
            this.errProvider.SetIconAlignment(this.lblStatus, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblStatus.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblStatus, ((int)(resources.GetObject("lblStatus.IconPadding"))));
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            // 
            // rbtActive
            // 
            resources.ApplyResources(this.rbtActive, "rbtActive");
            this.rbtActive.Checked = true;
            this.errProvider.SetError(this.rbtActive, resources.GetString("rbtActive.Error"));
            this.errProvider.SetIconAlignment(this.rbtActive, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtActive.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtActive, ((int)(resources.GetObject("rbtActive.IconPadding"))));
            this.rbtActive.Name = "rbtActive";
            this.rbtActive.TabStop = true;
            this.rbtActive.UseVisualStyleBackColor = true;
            // 
            // lblMandatory4
            // 
            resources.ApplyResources(this.lblMandatory4, "lblMandatory4");
            this.errProvider.SetError(this.lblMandatory4, resources.GetString("lblMandatory4.Error"));
            this.lblMandatory4.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory4, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory4.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory4, ((int)(resources.GetObject("lblMandatory4.IconPadding"))));
            this.lblMandatory4.Name = "lblMandatory4";
            // 
            // lblDefaultRate
            // 
            resources.ApplyResources(this.lblDefaultRate, "lblDefaultRate");
            this.errProvider.SetError(this.lblDefaultRate, resources.GetString("lblDefaultRate.Error"));
            this.errProvider.SetIconAlignment(this.lblDefaultRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDefaultRate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblDefaultRate, ((int)(resources.GetObject("lblDefaultRate.IconPadding"))));
            this.lblDefaultRate.Name = "lblDefaultRate";
            this.lblDefaultRate.RequiredField = false;
            // 
            // txtDefaultRate
            // 
            resources.ApplyResources(this.txtDefaultRate, "txtDefaultRate");
            this.txtDefaultRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtDefaultRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtDefaultRate, resources.GetString("txtDefaultRate.Error"));
            this.txtDefaultRate.Format = null;
            this.errProvider.SetIconAlignment(this.txtDefaultRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtDefaultRate.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtDefaultRate, ((int)(resources.GetObject("txtDefaultRate.IconPadding"))));
            this.txtDefaultRate.isAllowNegative = false;
            this.txtDefaultRate.isAllowSpecialChar = false;
            this.txtDefaultRate.isNumbersOnly = false;
            this.txtDefaultRate.isNumeric = true;
            this.txtDefaultRate.isTouchable = true;
            this.txtDefaultRate.Name = "txtDefaultRate";
            this.txtDefaultRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.errProvider.SetError(this.lblMandatory1, resources.GetString("lblMandatory1.Error"));
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory1, ((int)(resources.GetObject("lblMandatory1.IconPadding"))));
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // txtCode
            // 
            resources.ApplyResources(this.txtCode, "txtCode");
            this.txtCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtCode, resources.GetString("txtCode.Error"));
            this.txtCode.Format = null;
            this.errProvider.SetIconAlignment(this.txtCode, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtCode.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtCode, ((int)(resources.GetObject("txtCode.IconPadding"))));
            this.txtCode.isAllowNegative = false;
            this.txtCode.isAllowSpecialChar = false;
            this.txtCode.isNumbersOnly = false;
            this.txtCode.isNumeric = false;
            this.txtCode.isTouchable = true;
            this.txtCode.Name = "txtCode";
            this.txtCode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCode.Validated += new System.EventHandler(this.txtCode_Validated);
            // 
            // lblCode
            // 
            resources.ApplyResources(this.lblCode, "lblCode");
            this.errProvider.SetError(this.lblCode, resources.GetString("lblCode.Error"));
            this.errProvider.SetIconAlignment(this.lblCode, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCode.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCode, ((int)(resources.GetObject("lblCode.IconPadding"))));
            this.lblCode.Name = "lblCode";
            this.lblCode.RequiredField = false;
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtName, resources.GetString("txtName.Error"));
            this.txtName.Format = null;
            this.errProvider.SetIconAlignment(this.txtName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtName, ((int)(resources.GetObject("txtName.IconPadding"))));
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = true;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.errProvider.SetError(this.lblMandatory2, resources.GetString("lblMandatory2.Error"));
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory2, ((int)(resources.GetObject("lblMandatory2.IconPadding"))));
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.errProvider.SetError(this.lblName, resources.GetString("lblName.Error"));
            this.errProvider.SetIconAlignment(this.lblName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblName, ((int)(resources.GetObject("lblName.IconPadding"))));
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // pnlOptionalBar
            // 
            resources.ApplyResources(this.pnlOptionalBar, "pnlOptionalBar");
            this.pnlOptionalBar.AllowMultiSelect = false;
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.errProvider.SetError(this.pnlOptionalBar, resources.GetString("pnlOptionalBar.Error"));
            this.errProvider.SetIconAlignment(this.pnlOptionalBar, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlOptionalBar.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlOptionalBar, ((int)(resources.GetObject("pnlOptionalBar.IconPadding"))));
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // ExtraServicesView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlOptionalBar);
            this.Name = "ExtraServicesView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.ExtraServicesView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.ExtraServicesView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.ExtraServicesView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.ExtraServicesView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.ExtraServicesView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.ExtraServicesView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.ExtraServicesView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.ExtraServicesView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.ExtraServicesView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.ExtraServicesView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.ExtraServicesView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.ExtraServicesView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atPanel pnlMain;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.TextBoxExt txtCode;
        private atACCFramework.UserControls.atLabel lblCode;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atLabel lblName;
        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private atACCFramework.UserControls.atLabel lblDefaultRate;
        private atACCFramework.UserControls.TextBoxExt txtDefaultRate;
        private atACCFramework.UserControls.atRadioButton rbtInactive;
        private atACCFramework.UserControls.atLabel lblStatus;
        private atACCFramework.UserControls.atRadioButton rbtActive;
        private System.Windows.Forms.Label lblMandatory4;
        private System.Windows.Forms.Button btnSepearator1;
        private atACCFramework.UserControls.atLabel lblSlabs;
        private atACCFramework.UserControls.atLabel lblExciseDuty;
        private atACCFramework.UserControls.ComboBoxExt cmbTax3;
        private atACCFramework.UserControls.ComboBoxExt cmbAddlTax;
        private atACCFramework.UserControls.atLabel lblAdditionalTax;
        private atACCFramework.UserControls.ComboBoxExt cmbTax2;
        private atACCFramework.UserControls.ComboBoxExt cmbTax1;
        private atACCFramework.UserControls.atLabel lblTax3;
        private atACCFramework.UserControls.atLabel lblDiscount;
        private atACCFramework.UserControls.ComboBoxExt cmbExciseDuty;
        private atACCFramework.UserControls.atLabel lblGST;
        private atACCFramework.UserControls.ComboBoxExt cmbDiscount;
        private atACCFramework.UserControls.atLabel lblVAT;
        private atACCFramework.UserControls.atLabel lblTax2;
        private atACCFramework.UserControls.atLabel lblTax1;
        private atACCFramework.UserControls.ComboBoxExt cmbGST;
        private atACCFramework.UserControls.ComboBoxExt cmbVAT;
        private atACCFramework.UserControls.ComboBoxExt cmbType;
        private atACCFramework.UserControls.atLabel lblType;
        private System.Windows.Forms.Label lblMandatory5;
    }
}