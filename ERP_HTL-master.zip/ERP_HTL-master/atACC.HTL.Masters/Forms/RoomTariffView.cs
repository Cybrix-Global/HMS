﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class RoomTariffView : SearchFormBase2
    {
        #region Constructor
        public RoomTariffView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_RoomTariffView;
        }
        #endregion

        #region Private Variable
        RoomTariffs entRoomTariff;
        List<RoomTariffs> entRoomTariffs;
        List<RoomTypes> entRoomTypes;
        List<RateTypes> entRateTypes;
        atACCHotelEntities dbh;
        ANIHelper aniHelper;
        CommonLibClasses objLib = new CommonLibClasses();
        string m_NumberFormat;
        ToolTip tooltip;
        bool onLoad = true;
        #endregion

        #region Populate Events
        private void PopulateRateTariff()
        {
            try
            {
                entRoomTariffs = dbh.RoomTariffs.Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID))).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRateType()
        {
            try
            {
                entRateTypes = dbh.RateTypes.Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID))).OrderBy(x => x.Name).ToList();
                objLib.fnFillCombo(ref cmbRateType, entRateTypes, "Name", "id");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRoomType()
        {
            try
            {
                entRoomTypes = dbh.RoomTypes.Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID))).OrderBy(x => x.Name).ToList();
                objLib.fnFillCombo(ref cmbRoomType, entRoomTypes, "Name", "id");
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                m_NumberFormat = "N" + GlobalFunctions.CompanyNoofDecimals;
                txtDefaultRate.Format = m_NumberFormat;
                txtAddlBedRate.Format = m_NumberFormat;
                txtAddlPersonRate.Format = m_NumberFormat;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void cmbRoomType_SelectedValueChanged(object sender, EventArgs e)
        {

        }
        private void txtAddlPersonRate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                SaveClick();
            }
        }
        #endregion

        #region Framework Events
        private void RoomTariffView_atInitialise()
        {
            try
            {
                objLib = new CommonLibClasses();
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                entRoomTariff = new RoomTariffs();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void RoomTariffView_atAfterInitialise()
        {
            try
            {
                PopulateRateTariff();
                PopulateRoomType();
                PopulateRateType();
                LoadSettings();
                cmbRoomType.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void RoomTariffView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entRoomTariff = new RoomTariffs();
                PopulateRateTariff();
                PopulateRoomType();
                PopulateRateType();
                cmbRoomType.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool RoomTariffView_atValidate(object source)
        {
            try
            {
                if (cmbRoomType.Text == string.Empty)
                {
                    errProvider.SetError(cmbRoomType, MessageKeys.MsgRoomTypeMustBeChosen);
                    cmbRoomType.Focus();
                    return false;
                }
                if (cmbRateType.Text == string.Empty)
                {
                    errProvider.SetError(cmbRateType, MessageKeys.MsgRateTypeMustBeChosen);
                    cmbRateType.Focus();
                    return false;
                }
                if (cmbRoomType.Text != string.Empty && cmbRateType.Text != string.Empty)
                {
                    int iRoomType = cmbRoomType.SelectedValue.ToInt32();
                    int iRateType = cmbRateType.SelectedValue.ToInt32();
                    if (dbh.RoomTariffs.Where(x => x.FK_RoomTypeID == iRoomType && x.FK_RateTypeID == iRateType && x.id != entRoomTariff.id).Any())
                    {
                        atMessageBox.Show(MessageKeys.MsgRecordAlreadyExists);
                        return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool RoomTariffView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    entRoomTariff = new RoomTariffs();
                }
                entRoomTariff.ContextID = iContextID;
                entRoomTariff.LocationID = GlobalFunctions.LoginLocationID;
                entRoomTariff.LoginUserID = GlobalFunctions.LoginUserID;
                entRoomTariff.FK_RoomTypeID = cmbRoomType.SelectedValue.ToInt32();
                entRoomTariff.FK_RateTypeID = cmbRateType.SelectedValue.ToInt32();
                entRoomTariff.BaseRate = txtDefaultRate.Value;
                entRoomTariff.ExtraBedRate = txtAddlBedRate.Value;
                entRoomTariff.AdditionalPersonRate = txtAddlPersonRate.Value;
                if (NewRecord)
                {
                    dbh.RoomTariffs.AddObject(entRoomTariff);
                }
                else if (!NewRecord)
                {
                    dbh.ObjectStateManager.ChangeObjectState(entRoomTariff, EntityState.Modified);
                }
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool RoomTariffView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void RoomTariffView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vRoomTariffs = entRoomTariffs.Select(x => new { id = x.id, RoomType = x.TB_HTL_RoomTypes.Name, RateType = x.TB_HTL_RateTypes.Name }).OrderByDescending(x => x.id);
                e.SearchEntityList = vRoomTariffs;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entRoomTariff = dbh.RoomTariffs.Where(x => x.id == ID).SingleOrDefault();
                if (entRoomTariff != null)
                {
                    cmbRoomType.SelectedValue = entRoomTariff.FK_RoomTypeID;
                    cmbRateType.SelectedValue = entRoomTariff.FK_RateTypeID;
                    txtDefaultRate.Value = entRoomTariff.BaseRate.ToDecimal();
                    txtAddlBedRate.Value = entRoomTariff.ExtraBedRate.ToDecimal();
                    txtAddlPersonRate.Value = entRoomTariff.AdditionalPersonRate.ToDecimal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool RoomTariffView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vRoomTariffs = new { id = 0, RoomType = "", RateType = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vRoomTariffs).id);
                }
                else
                {
                    cmbRoomType.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool RoomTariffView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoomType.Focus();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void RoomTariffView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                cmbRoomType.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool RoomTariffView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.DeleteObject(entRoomTariff);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void RoomTariffView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
