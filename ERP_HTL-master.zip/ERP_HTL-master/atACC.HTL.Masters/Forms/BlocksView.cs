﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class BlocksView : SearchFormBase2
    {
        #region Constructor
        public BlocksView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_BlocksView;
        }
        #endregion

        #region Private Variables
        Blocks m_Block;
        List<Blocks> m_Blocks;        
        ANIHelper aniHelper;        
        atACCHotelEntities dbh;
        ToolTip tooltip;
        bool onLoad = true;
        #endregion

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Blocks, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateBlocksView()
        {
            try
            {
                m_Blocks = dbh.Blocks.ToList();
                rbtActive.Checked = true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtCode, MessageKeys.MsgEnterCode);
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(txtDescription, MessageKeys.MsgEnterDescription);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    Blocks block = dbh.Blocks.Where(x => x.Code == txtCode.Text.Trim())
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (block != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(block.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtActive_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                SaveClick();
            }
        }
        private void rbtInactive_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                SaveClick();
            }
        }
        #endregion

        #region Framework Events
        private void BlocksView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                m_Block = new Blocks();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void BlocksView_atAfterInitialise()
        {
            try
            {
                txtCode.Focus();
                GetSeqNo();
                ShowToolTip();
                PopulateBlocksView();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void BlocksView_atNewClick(object source)
        {
            try
            {
                m_Block = new Blocks();
                m_Blocks = new List<Blocks>();
                dbh = atHotelContext.CreateContext();
                txtCode.Focus();
                GetSeqNo();
                PopulateBlocksView();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool BlocksView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == "")
                {
                    errProvider.SetError(txtCode, MessageKeys.MsgCodeMustBeEntered);
                    txtCode.Focus();
                    return false;
                }
                if (txtName.Text.Trim() == "")
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool BlocksView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    m_Block = new Blocks();
                }
                m_Block.ContextID = iContextID;
                m_Block.LoginUserID = GlobalFunctions.LoginUserID;
                m_Block.LocationID = GlobalFunctions.LoginLocationID;
                m_Block.Code = txtCode.Text;
                m_Block.Name = txtName.Text;
                m_Block.Description = txtDescription.Text;
                m_Block.Active = rbtActive.Checked ? true : false;                
                if (NewRecord)
                {
                    dbh.Blocks.AddObject(m_Block);
                }
                else if (!NewRecord)
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_Block, EntityState.Modified);
                }
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_BlocksCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return BlocksView_atSaveClick(source, e);
                    }
                    else if (updEx.InnerException.Message.Contains("UC_BlocksName"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgBlock + " (" + txtName.Text + ") "
                            + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                        txtName.Focus();
                        return false;
                    }
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool BlocksView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void BlocksView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vBlocks = m_Blocks.Select(x => new { id = x.id, Code = x.Code, Name = x.Name }).OrderByDescending(x => x.id);
                e.SearchEntityList = vBlocks;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_Block = dbh.Blocks.Where(x => x.id == ID).SingleOrDefault();
                if (m_Blocks != null)
                {
                    txtCode.Text = m_Block.Code;
                    txtName.Text = m_Block.Name;
                    txtDescription.Text = m_Block.Description;
                    rbtActive.Checked = m_Block.Active == true ? true : false;
                    rbtInactive.Checked = m_Block.Active == true ? false : true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool BlocksView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vBlocks = new { id = 0, Code = "", Name = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vBlocks).id);
                }
                else
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool BlocksView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                onLoad = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void BlocksView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool BlocksView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.DeleteObject(m_Block);
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void BlocksView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
