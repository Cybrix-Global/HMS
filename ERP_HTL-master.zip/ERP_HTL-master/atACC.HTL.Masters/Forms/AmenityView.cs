﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class AmenityView : SearchFormBase2
    {
        #region Constructor
        public AmenityView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_AmenityView;
        }
        #endregion

        #region Private Variable
        Amenities m_AmenitiesView;
        List<Amenities> m_AmenitiesViewList;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        bool onLoad = true;
        #endregion

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Amenities, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateAmenity()
        {
            try
            {
                m_AmenitiesViewList = dbh.Amenities.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtCode, MessageKeys.MsgEnterCode);
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(txtDescription, MessageKeys.MsgEnterDescription);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            m_AmenitiesView = new Amenities();
            m_AmenitiesViewList = new List<Amenities>();
            txtCode.Focus();
        }
        #endregion

        #region Form Events
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    Amenities SD = dbh.Amenities.Where(x => x.Code == txtCode.Text.Trim())
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (SD != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(SD.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        } 
        private void txtDescription_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework Events
        private void AmenityView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                m_AmenitiesView = new Amenities();
                SettingsButton.Visible = ShareButton.Visible = false;
                PrintButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void AmenityView_atAfterInitialise()
        {
            try
            {
                txtCode.Focus();
                ShowToolTip();
                PopulateAmenity();
                GetSeqNo();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void AmenityView_atNewClick(object source)
        {
            try
            {
                m_AmenitiesView = new Amenities();
                dbh = atHotelContext.CreateContext();
                txtCode.Focus();
                FnClearAll();
                ShowToolTip();
                PopulateAmenity();
                GetSeqNo();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool AmenityView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtCode, MessageKeys.MsgCode);
                    txtCode.Focus();
                    return false;
                }
                if (txtName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtName, MessageKeys.MsgName);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool AmenityView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    m_AmenitiesView = new Amenities();
                }
                m_AmenitiesView.ContextID = iContextID;
                m_AmenitiesView.LocationID = GlobalFunctions.LoginLocationID;
                m_AmenitiesView.LoginUserID = GlobalFunctions.LoginUserID;
                m_AmenitiesView.Code = txtCode.Text.ToString();
                m_AmenitiesView.Name = txtName.Text.ToString();
                m_AmenitiesView.Description = txtDescription.Text.ToString();
                if (NewRecord)
                {
                    dbh.Amenities.AddObject(m_AmenitiesView);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_AmenitiesView, EntityState.Modified);
                }
                dbh.SaveChanges();
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_AmenitiesCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return AmenityView_atSaveClick(source, e);
                    }
                }
                if (updEx.InnerException.Message.Contains("UC_AmenitiesName"))
                {
                    atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgAmenity + " (" + txtName.Text + ") "
                        + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                    txtName.Focus();
                    return false;
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool AmenityView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void AmenityView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = m_AmenitiesViewList.Select(x => new { x.id, Name = x.Name }).OrderByDescending(x => x.id);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_AmenitiesView = dbh.Amenities.Where(x => x.id == id).SingleOrDefault();
                if (m_AmenitiesView != null)
                {
                    txtCode.Text = m_AmenitiesView.Code.ToString();
                    txtName.Text = m_AmenitiesView.Name.ToString();
                    txtDescription.Text = m_AmenitiesView.Description.ToString();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool AmenityView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vLoan = new { id = 0, Name = string.Empty };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vLoan).id);
                }
                else
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool AmenityView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
               onLoad = true;
               txtCode.Focus();
               return true;
            }
            catch (Exception ex)
            {
               ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
               return false;
            }
        }
        private void AmenityView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool AmenityView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.Amenities.DeleteObject(m_AmenitiesView);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void AmenityView_atAfterDelete(object source)
        {
            try
            {
                NewClick(); 
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
