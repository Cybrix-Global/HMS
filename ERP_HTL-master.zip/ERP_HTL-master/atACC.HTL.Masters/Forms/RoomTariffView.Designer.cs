﻿namespace atACC.HTL.Masters
{
    partial class RoomTariffView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RoomTariffView));
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.lblAddlPersonRate = new atACCFramework.UserControls.atLabel();
            this.txtAddlPersonRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblAddlBedRate = new atACCFramework.UserControls.atLabel();
            this.txtAddlBedRate = new atACCFramework.UserControls.TextBoxExt();
            this.lblDefaultRate = new atACCFramework.UserControls.atLabel();
            this.txtDefaultRate = new atACCFramework.UserControls.TextBoxExt();
            this.cmbRateType = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbRoomType = new atACCFramework.UserControls.ComboBoxExt();
            this.lblRoomType = new atACCFramework.UserControls.atLabel();
            this.lblRateType = new atACCFramework.UserControls.atLabel();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            resources.ApplyResources(this.panel1, "panel1");
            // 
            // pnlHeader2
            // 
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            // 
            // pnlOptionalBar
            // 
            this.pnlOptionalBar.AllowMultiSelect = false;
            resources.ApplyResources(this.pnlOptionalBar, "pnlOptionalBar");
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.errProvider.SetIconAlignment(this.pnlOptionalBar, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlOptionalBar.IconAlignment"))));
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.lblAddlPersonRate);
            this.pnlMain.Controls.Add(this.txtAddlPersonRate);
            this.pnlMain.Controls.Add(this.lblAddlBedRate);
            this.pnlMain.Controls.Add(this.txtAddlBedRate);
            this.pnlMain.Controls.Add(this.lblDefaultRate);
            this.pnlMain.Controls.Add(this.txtDefaultRate);
            this.pnlMain.Controls.Add(this.cmbRateType);
            this.pnlMain.Controls.Add(this.cmbRoomType);
            this.pnlMain.Controls.Add(this.lblRoomType);
            this.pnlMain.Controls.Add(this.lblRateType);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // lblAddlPersonRate
            // 
            resources.ApplyResources(this.lblAddlPersonRate, "lblAddlPersonRate");
            this.errProvider.SetIconAlignment(this.lblAddlPersonRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddlPersonRate.IconAlignment"))));
            this.lblAddlPersonRate.Name = "lblAddlPersonRate";
            this.lblAddlPersonRate.RequiredField = false;
            // 
            // txtAddlPersonRate
            // 
            resources.ApplyResources(this.txtAddlPersonRate, "txtAddlPersonRate");
            this.txtAddlPersonRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddlPersonRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddlPersonRate.Format = null;
            this.errProvider.SetIconAlignment(this.txtAddlPersonRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAddlPersonRate.IconAlignment"))));
            this.txtAddlPersonRate.isAllowNegative = false;
            this.txtAddlPersonRate.isAllowSpecialChar = false;
            this.txtAddlPersonRate.isNumbersOnly = false;
            this.txtAddlPersonRate.isNumeric = true;
            this.txtAddlPersonRate.isTouchable = true;
            this.txtAddlPersonRate.Name = "txtAddlPersonRate";
            this.txtAddlPersonRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtAddlPersonRate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAddlPersonRate_KeyDown);
            // 
            // lblAddlBedRate
            // 
            resources.ApplyResources(this.lblAddlBedRate, "lblAddlBedRate");
            this.errProvider.SetIconAlignment(this.lblAddlBedRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblAddlBedRate.IconAlignment"))));
            this.lblAddlBedRate.Name = "lblAddlBedRate";
            this.lblAddlBedRate.RequiredField = false;
            // 
            // txtAddlBedRate
            // 
            resources.ApplyResources(this.txtAddlBedRate, "txtAddlBedRate");
            this.txtAddlBedRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddlBedRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddlBedRate.Format = null;
            this.errProvider.SetIconAlignment(this.txtAddlBedRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtAddlBedRate.IconAlignment"))));
            this.txtAddlBedRate.isAllowNegative = false;
            this.txtAddlBedRate.isAllowSpecialChar = false;
            this.txtAddlBedRate.isNumbersOnly = false;
            this.txtAddlBedRate.isNumeric = true;
            this.txtAddlBedRate.isTouchable = true;
            this.txtAddlBedRate.Name = "txtAddlBedRate";
            this.txtAddlBedRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblDefaultRate
            // 
            resources.ApplyResources(this.lblDefaultRate, "lblDefaultRate");
            this.errProvider.SetIconAlignment(this.lblDefaultRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDefaultRate.IconAlignment"))));
            this.lblDefaultRate.Name = "lblDefaultRate";
            this.lblDefaultRate.RequiredField = false;
            // 
            // txtDefaultRate
            // 
            resources.ApplyResources(this.txtDefaultRate, "txtDefaultRate");
            this.txtDefaultRate.BackColor = System.Drawing.SystemColors.Window;
            this.txtDefaultRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDefaultRate.Format = null;
            this.errProvider.SetIconAlignment(this.txtDefaultRate, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtDefaultRate.IconAlignment"))));
            this.txtDefaultRate.isAllowNegative = false;
            this.txtDefaultRate.isAllowSpecialChar = false;
            this.txtDefaultRate.isNumbersOnly = false;
            this.txtDefaultRate.isNumeric = true;
            this.txtDefaultRate.isTouchable = true;
            this.txtDefaultRate.Name = "txtDefaultRate";
            this.txtDefaultRate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // cmbRateType
            // 
            this.cmbRateType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRateType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRateType.DropDownHeight = 300;
            this.cmbRateType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRateType, "cmbRateType");
            this.cmbRateType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRateType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRateType.IconAlignment"))));
            this.cmbRateType.Name = "cmbRateType";
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRoomType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRoomType.DropDownHeight = 300;
            this.cmbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbRoomType, "cmbRoomType");
            this.cmbRoomType.FormattingEnabled = true;
            this.errProvider.SetIconAlignment(this.cmbRoomType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("cmbRoomType.IconAlignment"))));
            this.cmbRoomType.Name = "cmbRoomType";
            this.cmbRoomType.SelectedValueChanged += new System.EventHandler(this.cmbRoomType_SelectedValueChanged);
            // 
            // lblRoomType
            // 
            resources.ApplyResources(this.lblRoomType, "lblRoomType");
            this.errProvider.SetIconAlignment(this.lblRoomType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRoomType.IconAlignment"))));
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.RequiredField = false;
            // 
            // lblRateType
            // 
            resources.ApplyResources(this.lblRateType, "lblRateType");
            this.errProvider.SetIconAlignment(this.lblRateType, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblRateType.IconAlignment"))));
            this.lblRateType.Name = "lblRateType";
            this.lblRateType.RequiredField = false;
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory1.IconAlignment"))));
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory2.IconAlignment"))));
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // RoomTariffView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlOptionalBar);
            this.Name = "RoomTariffView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.RoomTariffView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.RoomTariffView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.RoomTariffView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.RoomTariffView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.RoomTariffView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.RoomTariffView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.RoomTariffView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.RoomTariffView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.RoomTariffView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.RoomTariffView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.RoomTariffView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.RoomTariffView_atBeforeSearch);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private atACCFramework.UserControls.atPanel pnlMain;
        private System.Windows.Forms.Label lblMandatory2;
        private System.Windows.Forms.Label lblMandatory1;
        private atACCFramework.UserControls.atLabel lblRoomType;
        private atACCFramework.UserControls.atLabel lblRateType;
        private atACCFramework.UserControls.ComboBoxExt cmbRateType;
        private atACCFramework.UserControls.ComboBoxExt cmbRoomType;
        private atACCFramework.UserControls.atLabel lblAddlPersonRate;
        private atACCFramework.UserControls.TextBoxExt txtAddlPersonRate;
        private atACCFramework.UserControls.atLabel lblAddlBedRate;
        private atACCFramework.UserControls.TextBoxExt txtAddlBedRate;
        private atACCFramework.UserControls.atLabel lblDefaultRate;
        private atACCFramework.UserControls.TextBoxExt txtDefaultRate;
    }
}