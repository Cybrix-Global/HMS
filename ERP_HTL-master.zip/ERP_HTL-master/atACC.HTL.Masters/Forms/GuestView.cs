﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.ORM;
using atACC.HTL.Masters.Forms;
namespace atACC.HTL.Masters
{
    public partial class GuestView : SearchFormBase2
    {
        #region Constructor
        public GuestView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            iContextID = (int)EnContextID.HTL_GuestView;
        }
        public GuestView(bool _blnFromOtherForm)
        {
            FromOtherForm = _blnFromOtherForm;
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            iContextID = (int)EnContextID.HTL_GuestView;
        }
        #endregion Constructor

        #region Public Properties
        public int CurrentID { get; set; }
        #endregion

        #region Private Variable
        Guests e_Guest;
        List<Guests> e_GuestList;
        GuestDTLs  e_GuestDTLs;
        List<CurrencyClass> entCurrencys;
        AccountLedger e_Ledger;
        int IsettingsId = 0;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        ToolTip tooltip;
        string m_NumberFormat;
        int GuestUnder;
        bool onLoad = true;
        bool fromEnquiry = false;
        #endregion

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Guests, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateGuests()
        {
            try
            {
                e_GuestList = dbh.Guests
                    .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateCombos()
        {
            try
            {
                entCurrencys = (List<CurrencyClass>)dbh.CurrencyHDRs.ToList().Select(x => new CurrencyClass { Id = x.id, CurrencyName = x.Description + "(" + x.Code + ")" }).OrderBy(x => x.CurrencyName).ToList();
                CmbCurrency.DisplayMember = "CurrencyName";
                CmbCurrency.ValueMember = "Id";
                CmbCurrency.DataSource = entCurrencys;
                IsettingsId = 1;

                CmbCountry.DisplayMember = "Description";
                CmbCountry.ValueMember = "id";
                CmbCountry.DataSource = dbh.CurrencyHDRs.OrderBy(x => x.Description).ToList();

                cmbGender.DataSource = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.Gender).OrderBy(x => x.id).ToList();
                cmbGender.DisplayMember = "Description";
                cmbGender.ValueMember = "id";

                List<MasterValue> entCreditCradTypes = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.CardTypes).OrderBy(x => x.Name).ToList();
                MasterValue entCreditCradType = new MasterValue();
                entCreditCradType.id = 0;
                entCreditCradType.Description = MessageKeys.MsgNone;
                entCreditCradTypes.Insert(0, entCreditCradType);
                CmbCreditCardType.DataSource = entCreditCradTypes;
                CmbCreditCardType.DisplayMember = "Description";
                CmbCreditCardType.ValueMember = "id";

                if (!GlobalFunctions.GetANISettings((int)ENANISettings.MultiCurrency))
                {
                    CmbCurrency.Visible = false;
                    txtExRate.Visible = false;
                    lblCurrency.Visible = lblExRate.Visible = lblMandatory4.Visible = false;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }
        private void PopulateProofTypes()
        {
            try
            {
                cmbProofType.DataSource = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.ProofTypes).OrderBy(x => x.Name).ToList();
                cmbProofType.DisplayMember = "Description";
                cmbProofType.ValueMember = "id";
                cmbProofType.SelectedIndex = -1;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SelectCompanyCurrencyExRate()
        {
            try
            {
                if (CmbCurrency.SelectedValue.ToString2().ToInt32() == GlobalFunctions.CompanyCurrencyID)
                {
                    txtExRate.Enabled = false;
                    return;
                }
                else
                {
                    txtExRate.Enabled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtCode, MessageKeys.MsgEnterCode);
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(CmbCurrency, MessageKeys.MsgChooseCurrency);
                tooltip.SetToolTip(txtExRate, MessageKeys.MsgEnterExchangeRate);
                tooltip.SetToolTip(rbtActive, MessageKeys.MsgSetStatusAsActive);
                tooltip.SetToolTip(rbtInactive, MessageKeys.MsgSetStatusAsInactive);
                tooltip.SetToolTip(cmbGender, MessageKeys.MsgChooseGender);
                tooltip.SetToolTip(txtContactPerson, MessageKeys.MsgEnterContactPerson);
                tooltip.SetToolTip(txtAdd1, MessageKeys.MsgEnterAddress1);
                tooltip.SetToolTip(txtAdd2, MessageKeys.MsgEnterAddress2);
                tooltip.SetToolTip(txtAdd3, MessageKeys.MsgEnterAddress3);
                tooltip.SetToolTip(txtCity, MessageKeys.MsgEnterCity);
                tooltip.SetToolTip(txtState, MessageKeys.MsgEnterState);
                tooltip.SetToolTip(CmbCountry, MessageKeys.MsgChooseCountry);
                tooltip.SetToolTip(txtPostalcode, MessageKeys.MsgEnterPostalCode);
                tooltip.SetToolTip(txtTelephone, MessageKeys.MsgEnterTelephoneNumber);
                tooltip.SetToolTip(txtMobile, MessageKeys.MsgEnterMobileNumber);
                tooltip.SetToolTip(txtEmail, MessageKeys.MsgEnterEmailAddress);
                tooltip.SetToolTip(cmbProofType, MessageKeys.MsgChooseProofType);
                tooltip.SetToolTip(txtProofNo, MessageKeys.MsgEnterProofNumber);
                tooltip.SetToolTip(txtDiscPerc, MessageKeys.MsgEnterDiscountPercentage);
                tooltip.SetToolTip(txtBankName, MessageKeys.MsgEnterBankName);
                tooltip.SetToolTip(txtAccount, MessageKeys.MsgEnterAccountNumber);
                tooltip.SetToolTip(txtSWIFTCode, MessageKeys.MsgEnterSWIFTCode);
                tooltip.SetToolTip(CmbCreditCardType, MessageKeys.MsgChooseCreditCardType);
                tooltip.SetToolTip(txtCreditCardNo, MessageKeys.MsgEnterCardNumber);
                tooltip.SetToolTip(txtVehicleNo, MessageKeys.MsgEnterVehicleNumber);
                tooltip.SetToolTip(txtPreferences, MessageKeys.MsgEnterPreferences);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                m_NumberFormat = "N" + GlobalFunctions.CompanyNoofDecimals;
                txtExRate.Format = m_NumberFormat;
                txtDiscPerc.Format = m_NumberFormat;
               
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void UpdateExchangeRate(atACCHotelEntities db, int iContextID, int iDestinationCurrencyID, decimal dcExRate)
        {
            int iCompCurrID = GlobalFunctions.CompanyCurrencyID;
            bool isNewExrate = false;
            CurrencyDTL currencyDtl = db.CurrencyDTLs.Where(x => x.FK_CurrencyHdrID == iCompCurrID
                                        && x.FK_DestinationCountryID == iDestinationCurrencyID).SingleOrDefault();
            if (currencyDtl == null)
            {
                isNewExrate = true;
                currencyDtl = new CurrencyDTL();
            }
            currencyDtl.ContextID = iContextID;
            currencyDtl.LocationID = GlobalFunctions.LoginLocationID;
            currencyDtl.LoginUserID = GlobalFunctions.LoginUserID;
            currencyDtl.FK_CurrencyHdrID = iCompCurrID;
            currencyDtl.FK_DestinationCountryID = iDestinationCurrencyID;
            currencyDtl.ExRate = dcExRate;
            if (isNewExrate)
            {
                db.CurrencyDTLs.AddObject(currencyDtl);
            }
            else
            {
                db.ObjectStateManager.ChangeObjectState(currencyDtl, EntityState.Modified);
            }
        }
        public AccountLedger CreateAccount(ref atACCHotelEntities db, int contextID, string AccountName, int ParentID, int CurrencyID, int Status,AccountLedger ledger)
        {

            ledger.LedgerCode = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.AccountLedger, 0, 0, "");
            ledger.LedgerName = AccountName;
            ledger.LedgerName2 = "";
            ledger.FK_AccountGroupID = ParentID;
            ledger.FK_CurrencyHDRID = CurrencyID;
            ledger.ContextID = contextID;
            ledger.LoginUserID = GlobalFunctions.LoginUserID;
            ledger.LocationID = GlobalFunctions.LoginLocationID;
            ledger.Status = Status;

            int iloginCurrency = db.Companies.Single().CurrencyHDR.id;
            var vexrates = from hdr in db.CurrencyHDRs
                           join dtl in db.CurrencyDTLs on hdr.id equals dtl.FK_CurrencyHdrID
                           where hdr.id == iloginCurrency && dtl.FK_DestinationCountryID == CurrencyID
                           select new { ExRate = dtl.ExRate };
            if (vexrates.ToList().Count > 0)
            {
                ledger.ExRate = vexrates.Single().ExRate;
            }
            else
            {
                ledger.ExRate = 1;
            }
            if(NewRecord)
                db.AccountLedgers.AddObject(ledger);
            else
                db.ObjectStateManager.ChangeObjectState(ledger, EntityState.Modified);
            return ledger;
        }
        #endregion

        #region Form Events
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    Guests Guest = dbh.Guests.Where(x => x.Code == txtCode.Text.Trim())
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (Guest != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(Guest.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtAccount.Text = txtName.Text;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void chkEnquiry_CheckedChanged(object sender, EventArgs e)
        {
            btnEnquiry.Visible = chkEnquiry.Checked ? true : false;
        }
        private void SelectButtonContactDetails()
        {
            try
            {
                tabGuest.SelectedTab = tabContactDetails;
                btnContactDetails.BackColor = Color.White;
                btnContactDetails.ForeColor = Color.FromArgb(61, 77, 125);
                btnOtherDetails.BackColor = Color.Transparent;
                btnOtherDetails.ForeColor = Color.White;
                btnSelected.Top = btnContactDetails.Top;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SelectButtonOtherDetails()
        {
            try
            {
                tabGuest.SelectedTab = tabOtherDetails;
                btnOtherDetails.BackColor = Color.White;
                btnOtherDetails.ForeColor = Color.FromArgb(61, 77, 125);
                btnContactDetails.BackColor = Color.Transparent;
                btnContactDetails.ForeColor =  Color.White;
                btnSelected.Top = btnOtherDetails.Top;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnOtherDetails_Click(object sender, EventArgs e)
        {
            try
            {
                SelectButtonOtherDetails();
                cmbProofType.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnContactDetails_Click(object sender, EventArgs e)
        {
            try
            {
                SelectButtonContactDetails();
                txtContactPerson.Focus();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnNewProofType_Click(object sender, EventArgs e)
        {
            try
            {
                int MasterType = (int)ENMasterTypeT4.ProofTypes;
                MasterValueView mvView = new MasterValueView(MasterType);
                mvView.Text = MessageKeys.MsgProofTypes;
                mvView.ShowDialog();
                PopulateProofTypes();
                cmbProofType.SelectedValue = mvView.CurrentID;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (CmbCurrency.SelectedValue != null)
                {
                    int iCurrencyID = CmbCurrency.SelectedValue.ToString2().ToInt32();
                    CurrencyClass entCurrency = entCurrencys.Where(x => x.Id == iCurrencyID).SingleOrDefault();
                    Company company = dbh.Companies.Single();
                    int _sourcecurrencyId = company.FK_Currency.toInt32();
                    int _destinationCurrencyID = entCurrency.Id;
                    txtExRate.Value = aniHelper.getExchangeRate(_sourcecurrencyId, _destinationCurrencyID).ToDecimal();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CmbCurrency_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                SelectCompanyCurrencyExRate();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void rbtActive_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                SelectButtonContactDetails();
                e.Handled = true;
                txtContactPerson.Focus();
            }
        }
        private void rbtInactive_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                SelectButtonContactDetails();
                e.Handled = true;
                txtContactPerson.Focus();
            }
        }
        private void cmbProofType_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == true && e.KeyCode == Keys.Enter)
            {
                SelectButtonContactDetails();
                e.Handled = true;
                txtEmail.Focus();
            }
        }
        private void txtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                SelectButtonOtherDetails();
                e.Handled = true;
                cmbProofType.Focus();
            }
        }
        private void txtPreferences_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                SaveClick();
            }
        }
        private void btnEnquiry_Click(object sender, EventArgs e)
        {
            //fromEnquiry = true;
            EnquirySearchView enquirysearch = new EnquirySearchView(dbh);
            if (enquirysearch.ShowDialog() == DialogResult.OK)
            {
                if (enquirysearch.SelectedEnquiry != null)
                {
                    Enquiry e_Enquiry = dbh.Enquiries.Where(x => x.id == enquirysearch.SelectedEnquiry.id).SingleOrDefault();
                    if (e_Enquiry != null)
                    {
                        txtName.Text = e_Enquiry.Name;
                        txtAccount.Text = e_Enquiry.Name;
                        txtContactPerson.Text = e_Enquiry.Name;
                        txtCity.Text = e_Enquiry.City;
                        txtTelephone.Text = e_Enquiry.Telephone;
                        txtMobile.Text = e_Enquiry.Mobile;
                        txtEmail.Text = e_Enquiry.Email;
                    }
                }
            }
        }
        #endregion 

        #region Framework Events
        private void GuestView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                e_Guest = new Guests();
                e_Ledger = new AccountLedger();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void GuestView_atAfterInitialise()
        {
            try
            {
                txtCode.Focus();
                rbtActive.Checked = true;
                GetSeqNo();
                LoadSettings();
                ShowToolTip();
                PopulateGuests();
                PopulateCombos();
                PopulateProofTypes();
                CmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;
                CmbCountry.SelectedValue = GlobalFunctions.CompanyCurrencyID;
                if (FromOtherForm)
                {
                    EditButton.Visible = SearchButton.Visible = DeleteButton.Visible = false;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void GuestView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                e_Guest = new Guests();
                SelectButtonContactDetails();
                GetSeqNo();
                PopulateGuests();
                PopulateCombos();
                PopulateProofTypes();
                CmbCurrency.SelectedValue = GlobalFunctions.CompanyCurrencyID;
                CmbCountry.SelectedValue = GlobalFunctions.CompanyCurrencyID;
                rbtActive.Checked = true;
                txtCode.Focus();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool GuestView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == "") { errProvider.SetError(txtCode, MessageKeys.MsgCodeMustBeEntered); txtCode.Focus(); return false; }
                if (txtName.Text.Trim() == "") { errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered); txtName.Focus(); return false; }
                if (CmbCurrency.Text.Trim() == "") { errProvider.SetError(CmbCurrency, MessageKeys.MsgChooseCurrency); CmbCurrency.Focus(); return false; }
                if (txtExRate.Text.Trim() == "") { errProvider.SetError(txtExRate, MessageKeys.MsgEnterExchangeRate); txtExRate.Focus(); return false; }
                if (!GlobalFunctions.IsValidPincode(txtPostalcode.Text))
                {
                    errProvider.SetError(txtPostalcode, MessageKeys.MsgInvalidPincode);
                    tabGuest.SelectedTab = tabContactDetails;
                    txtPostalcode.Focus();
                    return false;
                }
                if (!GlobalFunctions.IsValidMobileNo(txtMobile.Text))
                {
                    errProvider.SetError(txtMobile, MessageKeys.MsgInvalidMobileNumber);
                    tabGuest.SelectedTab = tabContactDetails;
                    txtMobile.Focus();
                    return false;
                }
                if (!GlobalFunctions.IsValidEmailId(txtEmail.Text))
                {
                    errProvider.SetError(txtEmail, MessageKeys.MsgInvalidEmailAddress);
                    tabGuest.SelectedTab = tabContactDetails;
                    txtEmail.Focus();
                    return false;
                }
                if (cmbProofType.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbProofType, MessageKeys.MsgProofTypeMustBeChosen);
                    tabGuest.SelectedTab = tabOtherDetails;
                    cmbProofType.Focus();
                    return false;
                }
                if(txtProofNo.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtProofNo, MessageKeys.MsgProofNumberMustBeEntered);
                    tabGuest.SelectedTab = tabOtherDetails;
                    txtProofNo.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool GuestView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    e_Guest = new Guests();
                    e_GuestDTLs = new GuestDTLs();
                    e_Ledger = new AccountLedger();
                }
                GuestUnder = dbh.AccountSettings.Where(x => x.AccountFor == "Guest").SingleOrDefault().Value.toInt32();
                int CurrencyID = CmbCurrency.SelectedValue.ToString().ToInt32();
                e_Ledger = CreateAccount(ref dbh, iContextID, txtAccount.Text, GuestUnder, CurrencyID, rbtActive.Checked ? 1 : 0, e_Ledger);//**Create Account From Guest*//

                #region Guest Details 
                e_Guest.ContextID = iContextID;
                e_Guest.LocationID = GlobalFunctions.LoginLocationID;
                e_Guest.LoginUserID = GlobalFunctions.LoginUserID;
                e_Guest.Code = txtCode.Text;
                e_Guest.Name = txtName.Text;
                e_Guest.FK_AccountID =  e_Ledger.id;
                e_Guest.FK_CurrencyHDRID = CmbCurrency.SelectedValue.ToString2().ToInt32();
                e_Guest.CreatedDate = System.DateTime.Now;
                if (txtExRate.Text.ToDecimal() == 0)
                {
                    txtExRate.Text = "1";
                }
                else
                {
                    e_Guest.ExRate = txtExRate.Text.ToDecimal();
                }
                if (rbtActive.Checked == true)
                    e_Guest.Active = true;
                else
                    e_Guest.Active = false;
                if (NewRecord)
                {
                    dbh.Guests.AddObject(e_Guest);
                }
                else
                {  
                    e_Guest.ModifiedDate=System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(e_Guest, EntityState.Modified);
                }
                #endregion

                #region Guest DTLs 
                e_GuestDTLs.ContextID = iContextID;
                e_GuestDTLs.LocationID = GlobalFunctions.LoginLocationID;
                e_GuestDTLs.LoginUserID = GlobalFunctions.LoginUserID;
                e_GuestDTLs.FK_GuestID = e_Guest.id;
                e_GuestDTLs.FK_Gender = Convert.ToInt32(cmbGender.SelectedValue);
                e_GuestDTLs.ContactPerson = txtContactPerson.Text;
                e_GuestDTLs.Address1 = txtAdd1.Text;
                e_GuestDTLs.Address2 = txtAdd2.Text;
                e_GuestDTLs.Address3 = txtAdd3.Text;
                e_GuestDTLs.City = txtCity.Text;
                e_GuestDTLs.State = txtState.Text;
                e_GuestDTLs.Country = CmbCountry.Text;
                e_GuestDTLs.PostalCode = txtPostalcode.Text;
                e_GuestDTLs.Telephone = txtTelephone.Text;
                e_GuestDTLs.Mobile = txtMobile.Text;
                e_GuestDTLs.Email = txtEmail.Text;
                if (cmbProofType.Text != null && cmbProofType.SelectedValue.ToInt32() != 0)
                {
                    e_GuestDTLs.FK_ProofType = cmbProofType.SelectedValue.ToInt32();
                }
                else { e_GuestDTLs.FK_ProofType = null; }
                   
                e_GuestDTLs.ProofNo = txtProofNo.Text;
                e_GuestDTLs.DiscountPerc = Convert.ToDecimal(txtDiscPerc.Value);
                e_GuestDTLs.BankName = txtBankName.Text;
                e_GuestDTLs.BankNo = txtBankNo.Text;
                e_GuestDTLs.BankSWIFTCode = txtSWIFTCode.Text;
                if (CmbCreditCardType.Text != null && CmbCreditCardType.SelectedValue.ToInt32() != 0)
                {
                    e_GuestDTLs.FK_CreditCardType = CmbCreditCardType.SelectedValue.ToInt32();
                }
                else { e_GuestDTLs.FK_CreditCardType = null; }
                e_GuestDTLs.CreditCardNo = txtCreditCardNo.Text;
                e_GuestDTLs.VehicleNo = txtVehicleNo.Text;
                e_GuestDTLs.Preferences = txtPreferences.Text;
                e_GuestDTLs.Image = atImageframe.ImageData;
                if (NewRecord)
                {
                    dbh.GuestDTLs.AddObject(e_GuestDTLs);
                }
                else if (!NewRecord)
                {
                    e_GuestDTLs.ModifiedDate = System.DateTime.Now;
                    dbh.ObjectStateManager.ChangeObjectState(e_GuestDTLs, EntityState.Modified);
                }
                
                #endregion

                UpdateExchangeRate(dbh, iContextID, CmbCurrency.SelectedValue.ToString2().ToInt32(), txtExRate.Text.ToDecimal());
                dbh.SaveChanges();
                if (FromOtherForm)
                {
                    this.DialogResult = DialogResult.OK;
                    CurrentID = e_Guest.id;
                }
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_GuestsCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return GuestView_atSaveClick(source, e);
                    }
                    else if (updEx.InnerException.Message.Contains("UC_LedgerCode"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgLedger + " (" + txtCode.Text + ") "
                            + MessageKeys.MsgWithSameCodeAlreadyExistsPleaseEnterDifferentCode);
                        txtCode.Focus();
                        return false;
                    }
                    else if (updEx.InnerException.Message.Contains("UC_LedgerName"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgLedger + " (" + txtAccount.Text + ") "
                            + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                        txtName.Focus();
                        return false;
                    }
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                dbh.DetachAllHotelEntities();
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool GuestView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void GuestView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vGuest = e_GuestList.Select(x => new { id = x.id, Code = x.Code, GuestName = x.Name }).OrderByDescending(x => x.id); //**Specify the Fields for Searching Option**//
                e.SearchEntityList = vGuest;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                e_Guest = dbh.Guests.Where(x => x.id == ID).SingleOrDefault();
                if (e_Guest != null)
                {
                    #region Main Details
                    txtCode.Text = e_Guest.Code;
                    txtName.Text = e_Guest.Name;
                    e_Ledger = dbh.AccountLedgers.ToList().Where(x => x.id == e_Guest.FK_AccountID).First();
                    txtAccount.Text = e_Ledger.LedgerName;
                    CmbCurrency.SelectedValue = e_Guest.FK_CurrencyHDRID;
                    txtExRate.Value = e_Guest.ExRate.Value;
                    rbtActive.Checked = e_Guest.Active == true ? true : false;
                    rbtInactive.Checked = e_Guest.Active == true ? false : true;
                    e_GuestDTLs = dbh.GuestDTLs.Where(x => x.FK_GuestID == e_Guest.id).SingleOrDefault();
                    #endregion

                    #region Contact Details Part
                    cmbGender.SelectedValue = e_GuestDTLs.FK_Gender;
                    txtContactPerson.Text = e_GuestDTLs.ContactPerson;
                    txtAdd1.Text = e_GuestDTLs.Address1;
                    txtAdd2.Text = e_GuestDTLs.Address2;
                    txtAdd3.Text = e_GuestDTLs.Address3;
                    txtCity.Text = e_GuestDTLs.City;
                    txtState.Text = e_GuestDTLs.State;
                    CmbCountry.Text = e_GuestDTLs.Country;
                    txtPostalcode.Text = e_GuestDTLs.PostalCode;
                    txtTelephone.Text = e_GuestDTLs.Telephone;
                    txtMobile.Text = e_GuestDTLs.Mobile;
                    txtEmail.Text = e_GuestDTLs.Email;
                    #endregion

                    #region Other Details
                    if (e_GuestDTLs.FK_ProofType != null)
                    {
                        cmbProofType.SelectedValue = e_GuestDTLs.FK_ProofType;
                    }
                    txtProofNo.Text = e_GuestDTLs.ProofNo;
                    txtDiscPerc.Value = e_GuestDTLs.DiscountPerc.Value;
                    txtBankName.Text = e_GuestDTLs.BankName;
                    txtBankNo.Text = e_GuestDTLs.BankNo;
                    txtSWIFTCode.Text = e_GuestDTLs.BankSWIFTCode;
                    if (e_GuestDTLs.FK_CreditCardType != null)
                    {

                        CmbCreditCardType.SelectedValue = e_GuestDTLs.FK_CreditCardType;
                    }
                    else
                    {
                        CmbCreditCardType.SelectedValue = 0;
                    }
                    txtCreditCardNo.Text = e_GuestDTLs.CreditCardNo;
                    txtVehicleNo.Text = e_GuestDTLs.VehicleNo;
                    atImageframe.ImageData = e_GuestDTLs.Image;
                    txtPreferences.Text = e_GuestDTLs.Preferences;
                    tabGuest.SelectedTab = tabContactDetails;
                    #endregion
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool GuestView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vGuest = new { id = 0, Code = "", GuestName = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vGuest).id);
                }
                else 
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);

                return false;
            }
        }
        private bool GuestView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                onLoad = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void GuestView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                SelectCompanyCurrencyExRate();
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool GuestView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
              
                dbh.DeleteObject(e_Ledger);       
                dbh.DeleteObject(e_GuestDTLs);    
                dbh.DeleteObject(e_Guest);      
                dbh.SaveChanges();
                if (GlobalFunctions.blnMobileIntegration) { GlobalFunctions.AddToFireBase("REPORT"); }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void GuestView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
