﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseForms;
using atACC.Common;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using atACC.HTL.ORM;
using atACC.HTL.Masters;
namespace atACC.HTL.Masters
{
    public partial class RoomView : SearchFormBase2
    {
        #region Constructor
        public RoomView()
        {
            InitializeComponent();
            dbh = atHotelContext.CreateContext();
            iContextID = (int)EnContextID.HTL_RoomView;
        }
        #endregion

        #region Private Varibales
        Rooms m_RoomView;
        List<Rooms> m_RoomViewList;
        atACCHotelEntities dbh;
        ToolTip tooltip;
        bool onLoad = true;
        List<MasterValue> entRoomUserFields;
        #endregion Private Varibales

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                 txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_Rooms, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PopulateRoom()
        {
            try
            {
                m_RoomViewList = dbh.Rooms.GroupBy(x => x.id).Select(y => y.FirstOrDefault()).Where(x => x.IsHall == false).ToList();
            }
            catch (Exception)
            {
                throw;

            }
        }
        public void PopulateCombos()
        {
            try
            {
                #region RoomType
                var RoomType = dbh.RoomTypes.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "" && x.IsHallType == false).ToList();
                cmbRoomType.DataSource = RoomType.ToList();
                cmbRoomType.DisplayMember = "Name";
                cmbRoomType.ValueMember = "id";
                cmbRoomType.SelectedIndex = -1;
                #endregion
                #region Floor
                var Floor = dbh.Floors.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbFloor.DataSource = Floor.ToList();
                cmbFloor.DisplayMember = "Name";
                cmbFloor.ValueMember = "id";
                cmbFloor.SelectedIndex = -1;
                #endregion
                #region Block
                var Block = dbh.Blocks.GroupBy(x => x.Name).Select(y => y.FirstOrDefault()).Where(x => x.Name != "").ToList();
                cmbBlock.DataSource = Block.ToList();
                cmbBlock.DisplayMember = "Name";
                cmbBlock.ValueMember = "id";
                cmbBlock.SelectedIndex = -1;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtCode,MessageKeys.MsgEnterCode);
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
                tooltip.SetToolTip(txtDescription, MessageKeys.MsgEnterDescription);
                tooltip.SetToolTip(cmbRoomType,MessageKeys.MsgChooseRoomType);
                tooltip.SetToolTip(cmbFloor,MessageKeys.MsgChooseFloor);
                tooltip.SetToolTip(cmbBlock, MessageKeys.MsgChooseBlock);
                tooltip.SetToolTip(txtPhone, MessageKeys.MsgEnterPhoneExtension);
                tooltip.SetToolTip(txtKeyNo, MessageKeys.MsgEnterKeyNumber);
                tooltip.SetToolTip(txtUserField1, MessageKeys.MsgUserField1);
                tooltip.SetToolTip(txtUserField2, MessageKeys.MsgUserField2);
                tooltip.SetToolTip(txtUserField3, MessageKeys.MsgUserField3);
                tooltip.SetToolTip(txtUserField4, MessageKeys.MsgUserField4);
                tooltip.SetToolTip(txtDisplayOrder, MessageKeys.MsgEnterDisplayOrder);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void FnClearAll()
        {
            m_RoomView = new Rooms();
            m_RoomViewList = new List<Rooms>();
            radActive.Checked = true;
            txtCode.Focus();
        }
        private void SetUserFieldCaption()
        {
            entRoomUserFields = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.RoomUserFields).ToList();
            if (GlobalFunctions.LanguageCulture != "ar-QA")
            {
                lblUserFiled1.Text = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField1).SingleOrDefault().Description + " :";
                lblUserFiled2.Text = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField2).SingleOrDefault().Description + " :";
                lblUserFiled3.Text = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField3).SingleOrDefault().Description + " :";
                lblUserFiled4.Text = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField4).SingleOrDefault().Description + " :";
            }
        }
        #endregion Populate Event

        #region Form Event
        private void txtDisplayOrder_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    Rooms SD = dbh.Rooms.Where(x => x.Code == txtCode.Text.Trim())
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (SD != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(SD.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Framework events
        private void FrmRoomView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_RoomView = new Rooms();
                SettingsButton.Visible = ShareButton.Visible = false;
                PrintButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }
        private void FrmRoomView_atAfterInitialise()
        {
            try
            {
                txtCode.Focus();
                radActive.Checked = true;
                ShowToolTip();
                PopulateCombos();
                PopulateRoom();
                SetUserFieldCaption();
                GetSeqNo();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void FrmRoomView_atNewClick(object source)
        {
            try
            {
                m_RoomView = new Rooms();
                dbh = atHotelContext.CreateContext();
                txtCode.Focus();
                FnClearAll();
                PopulateCombos();
                ShowToolTip();
                PopulateRoom();
                GetSeqNo();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
                return;
            }
        }
        private bool FrmRoomView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtCode, MessageKeys.MsgCodeMustBeEntered);
                    txtCode.Focus();
                    return false;
                }
                if (txtName.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                if (cmbRoomType.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbRoomType, MessageKeys.MsgRoomTypeMustBeChosen);
                    cmbRoomType.Focus();
                    return false;
                }
                if (cmbFloor.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbFloor,MessageKeys.MsgFloorMustBeChosen);
                    cmbFloor.Focus();
                    return false;
                }
                if (cmbBlock.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbBlock,MessageKeys.MsgBlockMustBeChosen);
                    cmbBlock.Focus();
                    return false;
                }
                if(txtKeyNo.Text != string.Empty)
                {
                    if(dbh.Rooms.Any(x=> x.KeyNo == txtKeyNo.Text && x.id != m_RoomView.id))
                    {
                        errProvider.SetError(txtKeyNo, "Key No already exists.");
                        txtKeyNo.Focus();
                        return false;
                    }
                }
                if (txtPhone.Text != string.Empty)
                {
                    if (dbh.Rooms.Any(x => x.PhoneNo == txtPhone.Text && x.id != m_RoomView.id))
                    {
                        errProvider.SetError(txtPhone, "Phone No already exists.");
                        txtPhone.Focus();
                        return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredWhileValidating);
                return false;
            }
        }
        private bool FrmRoomView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    m_RoomView = new Rooms();
                }
                m_RoomView.ContextID = iContextID;
                m_RoomView.LocationID = GlobalFunctions.LoginLocationID;
                m_RoomView.LoginUserID = GlobalFunctions.LoginUserID;
                m_RoomView.Code=txtCode.Text.ToString();
                m_RoomView.Name = txtName.Text.ToString();
                m_RoomView.FK_RoomTypeID = cmbRoomType.SelectedValue.ToInt32();
                m_RoomView.FK_BlockID = cmbBlock.SelectedValue.ToInt32();
                m_RoomView.FK_FloorID = cmbFloor.SelectedValue.ToInt32();
                m_RoomView.Description = txtDescription.Text.ToString();
                m_RoomView.PhoneNo = txtPhone.Text.ToString();
                m_RoomView.KeyNo = txtKeyNo.Text.ToString();
                if (radActive.Checked == true)
                {
                    m_RoomView.Actice = true;
                }
                else
                {
                    m_RoomView.Actice =false;
                }
                m_RoomView.UserField1 = txtUserField1.Text.ToString();
                m_RoomView.UserField2 = txtUserField2.Text.ToString();
                m_RoomView.UserField3= txtUserField3.Text.ToString();
                m_RoomView.UserField4 = txtUserField4.Text.ToString();
                m_RoomView.DisplayOrder = txtDisplayOrder.Text.ToInt32();
                m_RoomView.IsHall = false;
                if (NewRecord)
                {
                    dbh.Rooms.AddObject(m_RoomView);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_RoomView, EntityState.Modified);
                }
                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_RoomsCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return FrmRoomView_atSaveClick(source, e);
                    }
                    else if (updEx.InnerException.Message.Contains("UC_RoomsName"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgRoom + " (" + txtName.Text + ") "
                            + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                        txtName.Focus();
                        return false;
                    }
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool FrmRoomView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                PopulateRoom();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSave);
                return false;
            }
        }
        private void FrmRoomView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                e.SearchEntityList = m_RoomViewList.Select(x => new { x.id, Name = x.Name}).OrderByDescending(x => x.id);

            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredBeforeSearching);
            }
        }
        public override void ReLoadData(int id)
        {
            try
            {
                PopulateCombos();
                dbh = atHotelContext.CreateContext();
                m_RoomView = dbh.Rooms.Where(x => x.id == id).SingleOrDefault();
                if (m_RoomView != null)
                {
                    txtCode.Text = m_RoomView.Code.ToString();
                    txtName.Text = m_RoomView.Name.ToString();
                    txtDescription.Text = m_RoomView.Description.ToString();
                    cmbRoomType.SelectedValue = m_RoomView.FK_RoomTypeID;
                    cmbBlock.SelectedValue = m_RoomView.FK_BlockID;
                    cmbFloor.SelectedValue = m_RoomView.FK_FloorID;
                    if (m_RoomView.Actice.toBool() == true)
                    {radActive.Checked = true;}
                    else { radInactive.Checked = true; }
                    txtPhone.Text = m_RoomView.PhoneNo.ToString();
                    txtKeyNo.Text = m_RoomView.KeyNo.ToString();
                    txtUserField1.Text = m_RoomView.UserField1.ToString();
                    txtUserField2.Text = m_RoomView.UserField2.ToString();
                    txtUserField3.Text = m_RoomView.UserField3.ToString();
                    txtUserField4.Text = m_RoomView.UserField4.ToString();
                    txtDisplayOrder.Text = m_RoomView.DisplayOrder.ToString();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                throw;
            }
        }
        private bool FrmRoomView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vLoan = new { id = 0, Name = string.Empty };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vLoan).id);
                }
                else 
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredAfterSearching);
                return false;
            }
        }
        private bool RoomView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                onLoad = true;
                txtCode.Focus();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void FrmRoomView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool FrmRoomView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.Rooms.DeleteObject(m_RoomView);
                dbh.SaveChanges();
                PopulateCombos();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void FrmRoomView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
                PopulateRoom();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
            }
        }
        #endregion Framework events
    }
}