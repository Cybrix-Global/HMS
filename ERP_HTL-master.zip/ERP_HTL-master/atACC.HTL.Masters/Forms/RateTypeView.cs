﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class RateTypeView : SearchFormBase2
    {
        #region Constructor
        public RateTypeView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_RateTypeView;
        }
        #endregion

        #region Private Variable
        RateTypes entRateType;
        List<RateTypes> entRateTypes;
        atACCHotelEntities dbh;
        ANIHelper aniHelper;
        string m_NumberFormat;
        ToolTip tooltip;
        bool onLoad = true;
        #endregion

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_RateTypes, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateRateType()
        {
            try
            {
                entRateTypes = dbh.RateTypes.Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID))).OrderBy(x => x.Name).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ShowToolTip()
        {
            try
            {
                tooltip = new ToolTip();
                tooltip.SetToolTip(txtCode, MessageKeys.MsgEnterCode);
                tooltip.SetToolTip(txtName, MessageKeys.MsgEnterName);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Form Events
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    RateTypes ratetype = dbh.RateTypes.Where(x => x.Code == txtCode.Text.Trim())
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (ratetype != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(ratetype.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == false && e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                SaveClick();
            }
        }
        #endregion

        #region Framework Events
        private void RateTypeView_atInitialise()
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                entRateType = new RateTypes();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void RateTypeView_atAfterInitialise()
        {
            try
            {
                txtCode.Focus();
                GetSeqNo();
                PopulateRateType();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void RateTypeView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entRateType = new RateTypes();
                txtCode.Focus();
                GetSeqNo();
                PopulateRateType();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool RateTypeView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == "") 
                { 
                    errProvider.SetError(txtCode, MessageKeys.MsgCodeMustBeEntered); 
                    txtCode.Focus(); 
                    return false; 
                }
                if (txtName.Text.Trim() == "") 
                { 
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered); 
                    txtName.Focus(); 
                    return false; 
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool RateTypeView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    entRateType = new RateTypes();
                }
                entRateType.ContextID = iContextID;
                entRateType.LocationID = GlobalFunctions.LoginLocationID;
                entRateType.LoginUserID = GlobalFunctions.LoginUserID;
                entRateType.Code = txtCode.Text;
                entRateType.Name = txtName.Text;
                if (NewRecord)
                {
                    dbh.RateTypes.AddObject(entRateType);
                }
                else if (!NewRecord)
                {
                    dbh.ObjectStateManager.ChangeObjectState(entRateType, EntityState.Modified);
                }
                dbh.SaveChanges();
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_RateTypesCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return RateTypeView_atSaveClick(source, e);
                    }
                    else if (updEx.InnerException.Message.Contains("UC_RateTypeName"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgRateType + " (" + txtName.Text + ") "
                            + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                        txtName.Focus();
                        return false;
                    }
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool RateTypeView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void RateTypeView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vRateTypes = entRateTypes.Select(x => new { id = x.id, Code = x.Code, Name = x.Name }).OrderByDescending(x => x.id);
                e.SearchEntityList = vRateTypes;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                entRateType = dbh.RateTypes.Where(x => x.id == ID).SingleOrDefault();
                if (entRateTypes != null)
                {
                    txtCode.Text = entRateType.Code;
                    txtName.Text = entRateType.Name;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool RateTypeView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vRateTypes = new { id = 0, Code = "", Name = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vRateTypes).id);
                }
                else
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool RateTypeView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                onLoad = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void RateTypeView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool RateTypeView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.DeleteObject(entRateType);
                dbh.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void RateTypeView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
