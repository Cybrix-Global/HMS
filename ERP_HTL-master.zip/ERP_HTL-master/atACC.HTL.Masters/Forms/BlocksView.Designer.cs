﻿namespace atACC.HTL.Masters
{
    partial class BlocksView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BlocksView));
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.txtCode = new atACCFramework.UserControls.TextBoxExt();
            this.lblDescription = new atACCFramework.UserControls.atLabel();
            this.rbtInactive = new atACCFramework.UserControls.atRadioButton();
            this.rbtActive = new atACCFramework.UserControls.atRadioButton();
            this.lblStatus = new atACCFramework.UserControls.atLabel();
            this.txtDescription = new atACCFramework.UserControls.TextBoxExt();
            this.txtName = new atACCFramework.UserControls.TextBoxExt();
            this.lblCode = new atACCFramework.UserControls.atLabel();
            this.lblName = new atACCFramework.UserControls.atLabel();
            this.lblMandatory1 = new System.Windows.Forms.Label();
            this.lblMandatory2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            resources.ApplyResources(this.errProvider, "errProvider");
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.errProvider.SetError(this.panel1, resources.GetString("panel1.Error"));
            this.errProvider.SetIconAlignment(this.panel1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("panel1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.panel1, ((int)(resources.GetObject("panel1.IconPadding"))));
            // 
            // pnlHeader2
            // 
            resources.ApplyResources(this.pnlHeader2, "pnlHeader2");
            this.errProvider.SetError(this.pnlHeader2, resources.GetString("pnlHeader2.Error"));
            this.errProvider.SetIconAlignment(this.pnlHeader2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlHeader2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlHeader2, ((int)(resources.GetObject("pnlHeader2.IconPadding"))));
            // 
            // pnlOptionalBar
            // 
            resources.ApplyResources(this.pnlOptionalBar, "pnlOptionalBar");
            this.pnlOptionalBar.AllowMultiSelect = false;
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.errProvider.SetError(this.pnlOptionalBar, resources.GetString("pnlOptionalBar.Error"));
            this.errProvider.SetIconAlignment(this.pnlOptionalBar, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlOptionalBar.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlOptionalBar, ((int)(resources.GetObject("pnlOptionalBar.IconPadding"))));
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // pnlMain
            // 
            resources.ApplyResources(this.pnlMain, "pnlMain");
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.txtCode);
            this.pnlMain.Controls.Add(this.lblDescription);
            this.pnlMain.Controls.Add(this.rbtInactive);
            this.pnlMain.Controls.Add(this.rbtActive);
            this.pnlMain.Controls.Add(this.lblStatus);
            this.pnlMain.Controls.Add(this.txtDescription);
            this.pnlMain.Controls.Add(this.txtName);
            this.pnlMain.Controls.Add(this.lblCode);
            this.pnlMain.Controls.Add(this.lblName);
            this.pnlMain.Controls.Add(this.lblMandatory1);
            this.pnlMain.Controls.Add(this.lblMandatory2);
            this.errProvider.SetError(this.pnlMain, resources.GetString("pnlMain.Error"));
            this.errProvider.SetIconAlignment(this.pnlMain, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("pnlMain.IconAlignment"))));
            this.errProvider.SetIconPadding(this.pnlMain, ((int)(resources.GetObject("pnlMain.IconPadding"))));
            this.pnlMain.Name = "pnlMain";
            // 
            // txtCode
            // 
            resources.ApplyResources(this.txtCode, "txtCode");
            this.txtCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtCode, resources.GetString("txtCode.Error"));
            this.txtCode.Format = null;
            this.errProvider.SetIconAlignment(this.txtCode, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtCode.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtCode, ((int)(resources.GetObject("txtCode.IconPadding"))));
            this.txtCode.isAllowNegative = false;
            this.txtCode.isAllowSpecialChar = false;
            this.txtCode.isNumbersOnly = false;
            this.txtCode.isNumeric = false;
            this.txtCode.isTouchable = false;
            this.txtCode.Name = "txtCode";
            this.txtCode.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCode.Validated += new System.EventHandler(this.txtCode_Validated);
            // 
            // lblDescription
            // 
            resources.ApplyResources(this.lblDescription, "lblDescription");
            this.errProvider.SetError(this.lblDescription, resources.GetString("lblDescription.Error"));
            this.errProvider.SetIconAlignment(this.lblDescription, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblDescription.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblDescription, ((int)(resources.GetObject("lblDescription.IconPadding"))));
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.RequiredField = false;
            // 
            // rbtInactive
            // 
            resources.ApplyResources(this.rbtInactive, "rbtInactive");
            this.errProvider.SetError(this.rbtInactive, resources.GetString("rbtInactive.Error"));
            this.errProvider.SetIconAlignment(this.rbtInactive, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtInactive.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtInactive, ((int)(resources.GetObject("rbtInactive.IconPadding"))));
            this.rbtInactive.Name = "rbtInactive";
            this.rbtInactive.UseVisualStyleBackColor = true;
            this.rbtInactive.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rbtInactive_KeyDown);
            // 
            // rbtActive
            // 
            resources.ApplyResources(this.rbtActive, "rbtActive");
            this.rbtActive.Checked = true;
            this.errProvider.SetError(this.rbtActive, resources.GetString("rbtActive.Error"));
            this.errProvider.SetIconAlignment(this.rbtActive, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("rbtActive.IconAlignment"))));
            this.errProvider.SetIconPadding(this.rbtActive, ((int)(resources.GetObject("rbtActive.IconPadding"))));
            this.rbtActive.Name = "rbtActive";
            this.rbtActive.TabStop = true;
            this.rbtActive.UseVisualStyleBackColor = true;
            this.rbtActive.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rbtActive_KeyDown);
            // 
            // lblStatus
            // 
            resources.ApplyResources(this.lblStatus, "lblStatus");
            this.errProvider.SetError(this.lblStatus, resources.GetString("lblStatus.Error"));
            this.errProvider.SetIconAlignment(this.lblStatus, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblStatus.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblStatus, ((int)(resources.GetObject("lblStatus.IconPadding"))));
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.RequiredField = false;
            // 
            // txtDescription
            // 
            resources.ApplyResources(this.txtDescription, "txtDescription");
            this.txtDescription.BackColor = System.Drawing.SystemColors.Window;
            this.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtDescription, resources.GetString("txtDescription.Error"));
            this.txtDescription.Format = null;
            this.errProvider.SetIconAlignment(this.txtDescription, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtDescription.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtDescription, ((int)(resources.GetObject("txtDescription.IconPadding"))));
            this.txtDescription.isAllowNegative = false;
            this.txtDescription.isAllowSpecialChar = false;
            this.txtDescription.isNumbersOnly = false;
            this.txtDescription.isNumeric = false;
            this.txtDescription.isTouchable = false;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errProvider.SetError(this.txtName, resources.GetString("txtName.Error"));
            this.txtName.Format = null;
            this.errProvider.SetIconAlignment(this.txtName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("txtName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.txtName, ((int)(resources.GetObject("txtName.IconPadding"))));
            this.txtName.isAllowNegative = false;
            this.txtName.isAllowSpecialChar = false;
            this.txtName.isNumbersOnly = false;
            this.txtName.isNumeric = false;
            this.txtName.isTouchable = false;
            this.txtName.Name = "txtName";
            this.txtName.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // lblCode
            // 
            resources.ApplyResources(this.lblCode, "lblCode");
            this.errProvider.SetError(this.lblCode, resources.GetString("lblCode.Error"));
            this.errProvider.SetIconAlignment(this.lblCode, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblCode.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblCode, ((int)(resources.GetObject("lblCode.IconPadding"))));
            this.lblCode.Name = "lblCode";
            this.lblCode.RequiredField = false;
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.errProvider.SetError(this.lblName, resources.GetString("lblName.Error"));
            this.errProvider.SetIconAlignment(this.lblName, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblName.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblName, ((int)(resources.GetObject("lblName.IconPadding"))));
            this.lblName.Name = "lblName";
            this.lblName.RequiredField = false;
            // 
            // lblMandatory1
            // 
            resources.ApplyResources(this.lblMandatory1, "lblMandatory1");
            this.errProvider.SetError(this.lblMandatory1, resources.GetString("lblMandatory1.Error"));
            this.lblMandatory1.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory1.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory1, ((int)(resources.GetObject("lblMandatory1.IconPadding"))));
            this.lblMandatory1.Name = "lblMandatory1";
            // 
            // lblMandatory2
            // 
            resources.ApplyResources(this.lblMandatory2, "lblMandatory2");
            this.errProvider.SetError(this.lblMandatory2, resources.GetString("lblMandatory2.Error"));
            this.lblMandatory2.ForeColor = System.Drawing.Color.Crimson;
            this.errProvider.SetIconAlignment(this.lblMandatory2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("lblMandatory2.IconAlignment"))));
            this.errProvider.SetIconPadding(this.lblMandatory2, ((int)(resources.GetObject("lblMandatory2.IconPadding"))));
            this.lblMandatory2.Name = "lblMandatory2";
            // 
            // BlocksView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlOptionalBar);
            this.Name = "BlocksView";
            this.atSaveClick += new atACCFramework.BaseClasses.SaveClickEventHandler(this.BlocksView_atSaveClick);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.BlocksView_atInitialise);
            this.atAfterInitialise += new atACCFramework.BaseClasses.AfterInitialiseEventHandler(this.BlocksView_atAfterInitialise);
            this.atNewClick += new atACCFramework.BaseClasses.NewClickEventHandler(this.BlocksView_atNewClick);
            this.atEditClick += new atACCFramework.BaseClasses.EditClickEventHandler(this.BlocksView_atEditClick);
            this.atAfterEditClick += new atACCFramework.BaseClasses.AfterEditClickEventHandler(this.BlocksView_atAfterEditClick);
            this.atDelete += new atACCFramework.BaseClasses.DeleteClickEventHandler(this.BlocksView_atDelete);
            this.atAfterSave += new atACCFramework.BaseClasses.AfterSaveClickEventHandler(this.BlocksView_atAfterSave);
            this.atAfterDelete += new atACCFramework.BaseClasses.AfterDeleteEventHandler(this.BlocksView_atAfterDelete);
            this.atValidate += new atACCFramework.BaseClasses.ValidateEventHandler(this.BlocksView_atValidate);
            this.atAfterSearch += new atACCFramework.BaseClasses.AfterSearchEventHandler(this.BlocksView_atAfterSearch);
            this.atBeforeSearch += new atACCFramework.BaseClasses.BeforeSearchEventHandler(this.BlocksView_atBeforeSearch);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.TextBoxExt txtCode;
        private atACCFramework.UserControls.atLabel lblDescription;
        private atACCFramework.UserControls.atRadioButton rbtInactive;
        private atACCFramework.UserControls.atRadioButton rbtActive;
        private atACCFramework.UserControls.atLabel lblStatus;
        private atACCFramework.UserControls.TextBoxExt txtDescription;
        private atACCFramework.UserControls.TextBoxExt txtName;
        private System.Windows.Forms.Label lblMandatory1;
        private System.Windows.Forms.Label lblMandatory2;
        private atACCFramework.UserControls.atLabel lblCode;
        private atACCFramework.UserControls.atLabel lblName;
    }
}