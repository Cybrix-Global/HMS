﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;

namespace atACC.HTL.Masters
{
    public partial class HallTypesView : SearchFormBase2
    {
        #region Constructor
        public HallTypesView()
        {
            InitializeComponent();
            iContextID = (int)EnContextID.HTL_HallTypesView;
        }
        #endregion

        #region Private Variable
        RoomTypes m_RoomType;
        List<RoomTypes> m_RoomTypes;
        List<RoomTypeSlabs> entRoomTypesSlabs;
        List<RoomTypeAmenities> entRoomTypesAmenities;
        RoomTypeAmenities entRoomTypesAmenity;
        RoomTypeSlabs entRoomTypeDiscount;
        RoomTypeSlabs entRoomTypeExDuty;
        RoomTypeSlabs entRoomTypeTax1;
        RoomTypeSlabs entRoomTypeTax2;
        RoomTypeSlabs entRoomTypeTax3;
        RoomTypeSlabs entRoomTypeAddlTax;
        RoomTypeSlabs entRoomTypeVAT;
        RoomTypeSlabs entRoomTypeGST;
        List<RoomTypeAmenities> entRoomTypeAmenities;
        List<RoomTypeAmenities> entOldRoomTypeAmenities;
        string m_NumberFormat;
        ANIHelper aniHelper;
        atACCHotelEntities dbh;
        CommonLibClasses objLib = new CommonLibClasses();
        ToolTip tooltip;
        bool onLoad = true;
        #endregion

        #region Populate Events
        private void GetSeqNo()
        {
            try
            {
                txtCode.Text = GlobalFunctions.getSequenceNo((int)ENMVMTTransactionType.HTL_HallTypes, 0, 0, txtCode.Text);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateHallType()
        {
            try
            {
                m_RoomTypes = dbh.RoomTypes.Where(x => x.IsHallType == true).ToList();
                rbtActive.Checked = true;
                btnColor.BackColor = default(Color);
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateAmenities()
        {
            try
            {
                List<Amenities> entAmenities = dbh.Amenities.ToList();
                Amenities entAmenity;
                entAmenity = new Amenities();
                Col_Amenity.DisplayMember = "Name";
                Col_Amenity.ValueMember = "id";
                Col_Amenity.DataSource = entAmenities;
                BindAmenityGrid();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void BindAmenityGrid()
        {
            try
            {
                dgAmenity.AutoGenerateColumns = false;
                dgAmenity.DataSource = null;
                bindAmenity.DataSource = null;
                bindAmenity.DataSource = entRoomTypeAmenities;
                dgAmenity.DataSource = bindAmenity;
                LoadFullSerialNoCombos();
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void PopulateSlabs()
        {
            try
            {
                #region Discount
                List<Slab> entDiscountSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.Discount).OrderBy(x => x.Name).ToList();
                Slab entDiscountSlab;
                entDiscountSlab = new Slab();
                entDiscountSlab.id = 0;
                entDiscountSlab.Name = MessageKeys.MsgNone;
                entDiscountSlabs.Insert(0, entDiscountSlab);
                objLib.fnFillCombo(ref cmbDiscount, entDiscountSlabs, "Name", "id");
                cmbDiscount.SelectedIndex = -1;
                #endregion

                #region ExciseDuty
                List<Slab> entExciseDutySlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.ExciseDuty).OrderBy(x => x.Name).ToList();
                Slab entExciseDutySlab;
                entExciseDutySlab = new Slab();
                entExciseDutySlab.id = 0;
                entExciseDutySlab.Name = MessageKeys.MsgNone;
                entExciseDutySlabs.Insert(0, entExciseDutySlab);
                objLib.fnFillCombo(ref cmbExciseDuty, entExciseDutySlabs, "Name", "id");
                cmbExciseDuty.SelectedIndex = -1;
                #endregion

                #region Tax1
                List<Slab> entTax1Slabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX1).OrderBy(x => x.Name).ToList();
                Slab entTax1Slab;
                entTax1Slab = new Slab();
                entTax1Slab.id = 0;
                entTax1Slab.Name = MessageKeys.MsgNone;
                entTax1Slabs.Insert(0, entTax1Slab);
                objLib.fnFillCombo(ref cmbTax1, entTax1Slabs, "Name", "id");
                cmbTax1.SelectedIndex = -1;
                #endregion

                #region Tax2
                List<Slab> entTax2Slabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX2).OrderBy(x => x.Name).ToList();
                Slab entTax2Slab;
                entTax2Slab = new Slab();
                entTax2Slab.id = 0;
                entTax2Slab.Name = MessageKeys.MsgNone;
                entTax2Slabs.Insert(0, entTax2Slab);
                objLib.fnFillCombo(ref cmbTax2, entTax2Slabs, "Name", "id");
                cmbTax2.SelectedIndex = -1;
                #endregion

                #region Tax3
                List<Slab> entTax3Slabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.TAX3).OrderBy(x => x.Name).ToList();
                Slab entTax3Slab;
                entTax3Slab = new Slab();
                entTax3Slab.id = 0;
                entTax3Slab.Name = MessageKeys.MsgNone;
                entTax3Slabs.Insert(0, entTax3Slab);
                objLib.fnFillCombo(ref cmbTax3, entTax3Slabs, "Name", "id");
                cmbTax3.SelectedIndex = -1;
                #endregion

                #region Additional Tax
                List<Slab> entAdditionalTaxSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.AdditionalTax).OrderBy(x => x.Name).ToList();
                Slab entAdditionalTaxSlab;
                entAdditionalTaxSlab = new Slab();
                entAdditionalTaxSlab.id = 0;
                entAdditionalTaxSlab.Name = MessageKeys.MsgNone;
                entAdditionalTaxSlabs.Insert(0, entAdditionalTaxSlab);
                objLib.fnFillCombo(ref cmbAddlTax, entAdditionalTaxSlabs, "Name", "id");
                cmbAddlTax.SelectedIndex = -1;
                #endregion

                #region VAT
                List<Slab> entVATSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.VAT).OrderBy(x => x.Name).ToList();
                Slab entVATSlab;
                entVATSlab = new Slab();
                entVATSlab.id = 0;
                entVATSlab.Name = MessageKeys.MsgNone;
                entVATSlabs.Insert(0, entVATSlab);
                objLib.fnFillCombo(ref cmbVAT, entVATSlabs, "Name", "id");
                cmbVAT.SelectedIndex = -1;
                #endregion

                #region GST
                List<Slab> entGSTSlabs = dbh.Slabs.Where(x => x.FK_MasterValueSlabType == (int)ENMVMTSlabType.GST).OrderBy(x => x.Name).ToList();
                Slab entGSTSlab;
                entGSTSlab = new Slab();
                entGSTSlab.id = 0;
                entGSTSlab.Name = MessageKeys.MsgNone;
                entGSTSlabs.Insert(0, entGSTSlab);
                objLib.fnFillCombo(ref cmbGST, entGSTSlabs, "Name", "id");
                cmbGST.SelectedIndex = -1;
                #endregion
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void EnableSlabsComboBasedonSetting()
        {
            try
            {
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableSlabDiscount))
                {
                    lblDiscount.Enabled = false;
                    cmbDiscount.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableExciseDuty))
                {
                    lblExciseDuty.Enabled = false;
                    cmbExciseDuty.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableTAX1))
                {
                    lblTax1.Enabled = false;
                    cmbTax1.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableTAX2))
                {
                    lblTax2.Enabled = false;
                    cmbTax2.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableTAX3))
                {
                    lblTax3.Enabled = false;
                    cmbTax3.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableAddnlTax))
                {
                    lblAdditionalTax.Enabled = false;
                    cmbAddlTax.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableVAT))
                {
                    lblVAT.Enabled = false;
                    cmbVAT.Enabled = false;
                }
                if (!GlobalFunctions.GetANISettings((int)ENANISettings.EnableGST))
                {
                    lblGST.Enabled = false;
                    cmbGST.Enabled = false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SetSlabsCaption()
        {
            try
            {
                if (GlobalFunctions.LanguageCulture == "en-US")
                {
                    lblDiscount.Text = GlobalFunctions.strSlabDiscountName;
                    lblExciseDuty.Text = GlobalFunctions.strSlabExciseDutyName;
                    lblTax1.Text = GlobalFunctions.strSlabTAX1Name;
                    lblTax2.Text = GlobalFunctions.strSlabTAX2Name;
                    lblTax3.Text = GlobalFunctions.strSlabTAX3Name;
                    lblAdditionalTax.Text = GlobalFunctions.strSlabAdditionalTaxName;
                    lblVAT.Text = GlobalFunctions.strSlabVATName;
                    lblGST.Text = GlobalFunctions.strSlabGSTName;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SelectButtonAmenity()
        {
            try
            {
                btnAmenities.BackColor = Color.White;
                btnAmenities.ForeColor = Color.FromArgb(61, 77, 125);
                btnSlabs.BackColor = Color.Transparent;
                btnSlabs.ForeColor = Color.White;
                btnSelected.Top = btnAmenities.Top;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SelectButtonSlabs()
        {
            try
            {
                btnSlabs.BackColor = Color.White;
                btnSlabs.ForeColor = Color.FromArgb(61, 77, 125);
                btnAmenities.BackColor = Color.Transparent;
                btnAmenities.ForeColor = Color.White;
                btnSelected.Top = btnSlabs.Top;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void CheckVisibility()
        {
            try
            {
                lblDiscount.Visible = cmbDiscount.Visible = GlobalFunctions.blnSlabDiscount;
                lblExciseDuty.Visible = cmbExciseDuty.Visible = GlobalFunctions.blnExiseDuty;
                lblTax1.Visible = cmbTax1.Visible = GlobalFunctions.blnTax1;
                lblTax2.Visible = cmbTax2.Visible = GlobalFunctions.blnTax2;
                lblTax3.Visible = cmbTax3.Visible = GlobalFunctions.blnTax3;
                lblAdditionalTax.Visible = cmbAddlTax.Visible = GlobalFunctions.blnAddnlTax;
                lblVAT.Visible = cmbVAT.Visible = GlobalFunctions.blnVAT;
                lblGST.Visible = cmbGST.Visible = GlobalFunctions.blnGST;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void LoadSettings()
        {
            try
            {
                m_NumberFormat = "N" + GlobalFunctions.CompanyNoofDecimals;
                txtDefaultRate.Format = m_NumberFormat;
                txtAddlBedRate.Format = m_NumberFormat;
                txtAddlPersonRate.Format = m_NumberFormat;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void ClearEntities()
        {
            m_RoomType = null;
            entRoomTypesAmenity = null;
            entRoomTypeDiscount = null;
            entRoomTypeExDuty = null;
            entRoomTypeTax1 = null;
            entRoomTypeTax2 = null;
            entRoomTypeTax3 = null;
            entRoomTypeAddlTax = null;
            entRoomTypeVAT = null;
            entRoomTypeGST = null;
            entRoomTypesSlabs = new List<RoomTypeSlabs>();
            entRoomTypesAmenities = new List<RoomTypeAmenities>();
            entRoomTypeAmenities = new List<RoomTypeAmenities>();
            entOldRoomTypeAmenities = new List<RoomTypeAmenities>();
        }
        private void LoadFullSerialNoCombos()
        {
            int i = 1;
            foreach (DataGridViewRow row in dgAmenity.Rows)
            {
                //SlNos
                row.Cells[Col_SlNo.Name].Value = i;
                i = i + 1;
            }
        }
        private void LoadCurrentSerialNo()
        {
            if (dgAmenity.CurrentRow == null) { return; }
            dgAmenity.CurrentRow.Cells[Col_SlNo.Name].Value = dgAmenity.CurrentRow.Cells[Col_SlNo.Name].RowIndex + 1;

        }
        #endregion

        #region Form Events
        private void txtCode_Validated(object sender, EventArgs e)
        {
            try
            {
                if (onLoad == true && txtCode.IsTextChanged())
                {
                    RoomTypes m_RoomType = dbh.RoomTypes.Where(x => x.Code == txtCode.Text.Trim() && x.IsHallType == true)
                        .Where(x => (GlobalFunctions.blnFilterBranchInMasters == false || GlobalFunctions.entCurrentLocations.Contains((int)x.LocationID)))
                        .SingleOrDefault();
                    if (m_RoomType != null && txtCode.IsTextChanged())
                    {
                        ReLoadData(m_RoomType.id);
                        onPopulate();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void btnAmenities_Click(object sender, EventArgs e)
        {
            TabRateType.SelectedTab = tabAmenity;
            SelectButtonAmenity();
            dgAmenity.Focus();
        }
        private void btnSlabs_Click(object sender, EventArgs e)
        {
            TabRateType.SelectedTab = tabSlabs;
            SelectButtonSlabs();
        }
        private void btnColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                btnColor.BackColor = colorDialog1.Color;
            }
        }
        private void cmbDiscount_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbExciseDuty.Enabled && !cmbTax1.Enabled && !cmbTax2.Enabled
                    && !cmbTax3.Enabled && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void cmbExciseDuty_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbTax1.Enabled && !cmbTax2.Enabled
                            && !cmbTax3.Enabled && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbTax1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbTax2.Enabled && !cmbTax3.Enabled
                            && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbTax2_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbTax3.Enabled && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbTax3_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbAddlTax.Enabled && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbAddlTax_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbVAT.Enabled && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbVAT_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return && !cmbGST.Enabled)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void cmbGST_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Shift == false && e.KeyCode == Keys.Return)
                {
                    e.Handled = true;
                    SaveClick();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region Grid Events
        private void dgAmenity_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (e.RowIndex == -1) { return; }
            LoadCurrentSerialNo();
        }
        private void dgAmenity_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            LoadFullSerialNoCombos();
        }
        #endregion

        #region Framwework Events
        private void HallTypesView_atInitialise()
        {
            try
            {
                objLib = new CommonLibClasses();
                dbh = atHotelContext.CreateContext();
                aniHelper = new ANIHelper();
                m_RoomType = new RoomTypes();
                entRoomTypeAmenities = new List<RoomTypeAmenities>();
                PrintButton.Visible = false;
                ShareButton.Visible = false;
                MaximizeButton.Visible = false;
                MinimizeButton.Visible = false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Initialise);
            }
        }
        private void HallTypesView_atAfterInitialise()
        {
            try
            {
                GetSeqNo();
                PopulateHallType();
                PopulateAmenities();
                PopulateSlabs();
                EnableSlabsComboBasedonSetting();
                SetSlabsCaption();
                LoadSettings();
                ClearEntities();
                txtCode.Focus();
                BindAmenityGrid();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterInitialise);
            }
        }
        private void HallTypesView_atNewClick(object source)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_RoomType = new RoomTypes();
                entRoomTypeAmenities = new List<RoomTypeAmenities>();
                PopulateHallType();
                PopulateAmenities();
                PopulateSlabs();
                EnableSlabsComboBasedonSetting();
                SelectButtonAmenity();
                TabRateType.SelectedTab = tabAmenity;
                GetSeqNo();
                ClearEntities();
                BindAmenityGrid();
                txtCode.Focus();
                onLoad = true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.New);
            }
        }
        private bool HallTypesView_atValidate(object source)
        {
            try
            {
                if (txtCode.Text.Trim() == "")
                {
                    errProvider.SetError(txtCode, MessageKeys.MsgCodeMustBeEntered);
                    txtCode.Focus();
                    return false;
                }
                if (txtName.Text.Trim() == "")
                {
                    errProvider.SetError(txtName, MessageKeys.MsgNameMustBeEntered);
                    txtName.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Validate);
                return false;
            }
        }
        private bool HallTypesView_atSaveClick(object source, SaveClickEventArgs e)
        {
            try
            {
                if (NewRecord)
                {
                    GetSeqNo();
                    m_RoomType = new RoomTypes();
                }
                m_RoomType.ContextID = iContextID;
                m_RoomType.LoginUserID = GlobalFunctions.LoginUserID;
                m_RoomType.LocationID = GlobalFunctions.LoginLocationID;
                m_RoomType.Code = txtCode.Text;
                m_RoomType.Name = txtName.Text;
                m_RoomType.Description = txtDescription.Text;
                m_RoomType.AdultOccupancy = txtAdult.Value.ToInt32();
                m_RoomType.ChildOccupancy = txtChild.Value.ToInt32();
                m_RoomType.MaxExtraBeds = txtExtraBeds.Value.ToInt32();
                m_RoomType.Color = btnColor.BackColor.ToArgb();
                m_RoomType.BaseRate = txtDefaultRate.Value;
                m_RoomType.ExtraBedRate = txtAddlBedRate.Value;
                m_RoomType.AdditionalPersonRate = txtAddlPersonRate.Value;
                m_RoomType.Active = rbtActive.Checked ? true : false;
                m_RoomType.IsHallType = true;                
                if (NewRecord)
                {
                    dbh.RoomTypes.AddObject(m_RoomType);
                }
                else
                {
                    dbh.ObjectStateManager.ChangeObjectState(m_RoomType, EntityState.Modified);
                }

                #region Amenity
                var a1 = entOldRoomTypeAmenities.Select(x => new { id = x.id });
                var a2 = entRoomTypeAmenities.Select(y => new { id = y.id });
                var deletedItems = a1.Except(a2);
                foreach (var deletedItem in deletedItems)
                {
                    RoomTypeAmenities delItem = entOldRoomTypeAmenities.Where(x => x.id == deletedItem.id).First();
                    dbh.RoomTypeAmenities.DeleteObject(delItem);
                    entRoomTypeAmenities.Remove(delItem);
                }
                foreach (RoomTypeAmenities item in entRoomTypeAmenities)
                {
                    if (item.FK_AmenityID != null)
                    {
                        if (dbh.RoomTypeAmenities.Where(x => x.id == item.id).ToList().Count == 0)
                        {
                            item.FK_RoomTypeID = m_RoomType.id;
                            dbh.RoomTypeAmenities.AddObject(item);
                        }
                        else
                        {
                            dbh.ObjectStateManager.ChangeObjectState(item, System.Data.EntityState.Modified);
                        }
                    }
                }
                #endregion

                bool NewObject;

                #region Discount Slabs
                if (cmbDiscount.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeDiscount == null)
                    {
                        entRoomTypeDiscount = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeDiscount.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeDiscount.FK_SlabTypeID = (int)ENMVMTSlabType.Discount;
                    entRoomTypeDiscount.FK_SlabID = cmbDiscount.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeDiscount);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeDiscount, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeDiscount != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeDiscount);
                    }
                }
                #endregion

                #region Excise Duty Slabs
                if (cmbExciseDuty.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeExDuty == null)
                    {
                        entRoomTypeExDuty = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeExDuty.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeExDuty.FK_SlabTypeID = (int)ENMVMTSlabType.ExciseDuty;
                    entRoomTypeExDuty.FK_SlabID = cmbExciseDuty.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeExDuty);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeExDuty, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeExDuty != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeExDuty);
                    }
                }
                #endregion

                #region Tax 1 Slabs
                if (cmbTax1.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeTax1 == null)
                    {
                        entRoomTypeTax1 = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeTax1.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeTax1.FK_SlabTypeID = (int)ENMVMTSlabType.TAX1;
                    entRoomTypeTax1.FK_SlabID = cmbTax1.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeTax1);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeTax1, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeTax1 != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeTax1);
                    }
                }
                #endregion

                #region Tax 2 Slabs
                if (cmbTax2.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeTax2 == null)
                    {
                        entRoomTypeTax2 = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeTax2.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeTax2.FK_SlabTypeID = (int)ENMVMTSlabType.TAX2;
                    entRoomTypeTax2.FK_SlabID = cmbTax2.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeTax2);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeTax2, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeTax2 != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeTax2);
                    }
                }
                #endregion

                #region Tax 3 Slabs
                if (cmbTax3.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeTax3 == null)
                    {
                        entRoomTypeTax3 = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeTax3.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeTax3.FK_SlabTypeID = (int)ENMVMTSlabType.TAX3;
                    entRoomTypeTax3.FK_SlabID = cmbTax3.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeTax3);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeTax3, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeTax3 != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeTax3);
                    }
                }
                #endregion

                #region Additional Tax Slabs
                if (cmbAddlTax.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeAddlTax == null)
                    {
                        entRoomTypeAddlTax = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeAddlTax.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeAddlTax.FK_SlabTypeID = (int)ENMVMTSlabType.AdditionalTax;
                    entRoomTypeAddlTax.FK_SlabID = cmbAddlTax.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeAddlTax);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeAddlTax, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeAddlTax != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeAddlTax);
                    }
                }
                #endregion

                #region VAT Slabs
                if (cmbVAT.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeVAT == null)
                    {
                        entRoomTypeVAT = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeVAT.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeVAT.FK_SlabTypeID = (int)ENMVMTSlabType.VAT;
                    entRoomTypeVAT.FK_SlabID = cmbVAT.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeVAT);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeVAT, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeVAT != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeVAT);
                    }
                }
                #endregion

                #region GST Slabs
                if (cmbGST.SelectedValue.ToString2().ToInt32() != 0)
                {
                    NewObject = NewRecord;
                    if (entRoomTypeGST == null)
                    {
                        entRoomTypeGST = new RoomTypeSlabs();
                        NewObject = true;
                    }
                    entRoomTypeGST.FK_RoomTypeID = m_RoomType.id;
                    entRoomTypeGST.FK_SlabTypeID = (int)ENMVMTSlabType.GST;
                    entRoomTypeGST.FK_SlabID = cmbGST.SelectedValue.ToInt32();
                    if (NewObject)
                    {
                        dbh.RoomTypeSlabs.AddObject(entRoomTypeGST);
                    }
                    else
                    {
                        dbh.ObjectStateManager.ChangeObjectState(entRoomTypeGST, EntityState.Modified);
                    }
                }
                else
                {
                    if (entRoomTypeGST != null)
                    {
                        dbh.RoomTypeSlabs.DeleteObject(entRoomTypeGST);
                    }
                }
                #endregion

                dbh.SaveChanges();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (UpdateException updEx)
            {
                dbh.DetachAllHotelEntities();
                if (updEx.InnerException != null)
                {
                    if (updEx.InnerException.Message.Contains("UC_RoomTypesCode"))
                    {
                        if (FirstSaveClick == true && atMessageBox.Show(MessageKeys.MsgCodeAlreadyExistsDoYouWantToFollowTheSeriesBasedOnPreviousSequence, MessageBoxButtons.YesNo) == DialogResult.No)
                        {
                            txtCode.Focus();
                            return false;
                        }
                        FirstSaveClick = false;
                        return HallTypesView_atSaveClick(source, e);
                    }
                    else if (updEx.InnerException.Message.Contains("UC_RoomTypesName"))
                    {
                        atMessageBox.Show(MessageKeys.MsgAnother + MessageKeys.MsgHallType + " (" + txtName.Text + ") "
                            + MessageKeys.MsgWithSameNameAlreadyExistsPleaseEnterDifferentName);
                        txtName.Focus();
                        return false;
                    }
                }
                ExceptionManager.Publish(updEx);
                atMessageBox.Show(updEx, ENOperation.Save);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Save);
                return false;
            }
        }
        private bool HallTypesView_atAfterSave(object source)
        {
            try
            {
                NewClick();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSave);
                return false;
            }
        }
        private void HallTypesView_atBeforeSearch(object source, BeforeSearchEventArgs e)
        {
            try
            {
                var vRoomType = m_RoomTypes.Where(x => x.IsHallType == true).Select(x => new { id = x.id, Code = x.Code, Name = x.Name }).OrderByDescending(x => x.id);
                e.SearchEntityList = vRoomType;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.BeforeSearch);
                return;
            }
        }
        public override void ReLoadData(int ID)
        {
            try
            {
                dbh = atHotelContext.CreateContext();
                m_RoomType = dbh.RoomTypes.Where(x => x.id == ID).SingleOrDefault();
                if (m_RoomType != null)
                {
                    txtCode.Text = m_RoomType.Code;
                    txtName.Text = m_RoomType.Name;
                    txtDescription.Text = m_RoomType.Description;
                    txtAdult.Value = m_RoomType.AdultOccupancy.ToInt32();
                    txtChild.Value = m_RoomType.ChildOccupancy.ToInt32();
                    txtExtraBeds.Value = m_RoomType.MaxExtraBeds.ToInt32();
                    int iColor = m_RoomType.Color.ToInt32();
                    Color myColor = Color.FromArgb(iColor);
                    btnColor.BackColor = myColor;         

                    txtDefaultRate.Value = m_RoomType.BaseRate.ToDecimal();
                    txtAddlBedRate.Value = m_RoomType.ExtraBedRate.ToDecimal();
                    txtAddlPersonRate.Value = m_RoomType.AdditionalPersonRate.ToDecimal();
                    if (m_RoomType.Active == true)
                    {
                        rbtActive.Checked = true;
                    }
                    else
                    {
                        rbtInactive.Checked = true;
                    }

                    #region Slabs
                    List<RoomTypeSlabs> entDisc = dbh.RoomTypeSlabs.Where(x => x.FK_RoomTypeID == m_RoomType.id).ToList();
                    if (entDisc.Count > 0)
                    {
                        entRoomTypeDiscount = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.Discount).SingleOrDefault();
                        if (entRoomTypeDiscount != null)
                        {
                            cmbDiscount.SelectedValue = entRoomTypeDiscount.FK_SlabID.toInt32();
                        }
                        entRoomTypeExDuty = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.ExciseDuty).SingleOrDefault();
                        if (entRoomTypeExDuty != null)
                        {
                            cmbExciseDuty.SelectedValue = entRoomTypeExDuty.FK_SlabID.toInt32();
                        }

                        entRoomTypeTax1 = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.TAX1).SingleOrDefault();
                        if (entRoomTypeTax1 != null)
                        {
                            cmbTax1.SelectedValue = entRoomTypeTax1.FK_SlabID.toInt32();
                        }

                        entRoomTypeTax2 = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.TAX2).SingleOrDefault();
                        if (entRoomTypeTax2 != null)
                        {
                            cmbTax2.SelectedValue = entRoomTypeTax2.FK_SlabID.toInt32();
                        }

                        entRoomTypeTax3 = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.TAX3).SingleOrDefault();
                        if (entRoomTypeTax3 != null)
                        {
                            cmbTax3.SelectedValue = entRoomTypeTax3.FK_SlabID.toInt32();
                        }

                        entRoomTypeAddlTax = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.AdditionalTax).SingleOrDefault();
                        if (entRoomTypeAddlTax != null)
                        {
                            cmbAddlTax.SelectedValue = entRoomTypeAddlTax.FK_SlabID.toInt32();
                        }

                        entRoomTypeVAT = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.VAT).SingleOrDefault();
                        if (entRoomTypeVAT != null)
                        {
                            cmbVAT.SelectedValue = entRoomTypeVAT.FK_SlabID.toInt32();
                        }

                        entRoomTypeGST = entDisc.Where(x => x.FK_SlabTypeID == (int)ENMVMTSlabType.GST).SingleOrDefault();
                        if (entRoomTypeGST != null)
                        {
                            cmbGST.SelectedValue = entRoomTypeGST.FK_SlabID.toInt32();
                        }
                    }
                    #endregion
                    
                    #region Amenities
                    entRoomTypeAmenities = dbh.RoomTypeAmenities.Where(x => x.FK_RoomTypeID == m_RoomType.id).ToList();
                    if (entRoomTypeAmenities == null)
                    {
                        entRoomTypeAmenities = new List<RoomTypeAmenities>();
                    }
                    entOldRoomTypeAmenities = new List<RoomTypeAmenities>(entRoomTypeAmenities);
                    BindAmenityGrid();
                    #endregion
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool HallTypesView_atAfterSearch(object source, AfterSearchEventArgs e)
        {
            try
            {
                if (e.GetSelectedEntity() != null)
                {
                    NewClick();
                    var vRoomTypes = new { id = 0, Code = "", Name = "" };
                    onLoad = false;
                    ReLoadData(e.GetSelectedEntity().Cast(vRoomTypes).id);
                }
                else 
                {
                    txtCode.Focus();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterSearch);
                return false;
            }
        }
        private bool HallTypesView_atEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                onLoad = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Edit);
                return false;
            }
        }
        private void HallTypesView_atAfterEditClick(object source, EditClickEventArgs e)
        {
            try
            {
                EnableSlabsComboBasedonSetting();
                txtCode.Focus();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterEdit);
            }
        }
        private bool HallTypesView_atDelete(object source, DeleteClickEventArgs e)
        {
            try
            {
                dbh.DeleteObject(m_RoomType);
                dbh.SaveChanges();
                PopulateHallType();
                PopulateAmenities();
                PopulateSlabs();
                GlobalProperties.RefreshDashboard = true;
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.Delete);
                return false;
            }
        }
        private void HallTypesView_atAfterDelete(object source)
        {
            try
            {
                NewClick();
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.AfterDelete);
                return;
            }
        }
        #endregion
    }
}
