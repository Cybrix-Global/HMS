﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using atACC.HTL.ORM;
using System.Data.SqlClient;
using System.Data;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;

namespace atACC.HTL.Masters
{
    public class GetAccounts
    {
        public List<AccountLedger> GetAccountLedgers(int iGrpID)
        {
            atACCHotelEntities dbh = atHotelContext.CreateContext();
            SqlHelper sqlh = new SqlHelper();
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("GroupID", iGrpID));
            DataSet ds = sqlh.ExecuteProcedure("sp_GetLedgers", sqlParameters);
            List<AccountLedger> entAccountLedgers = dbh.AccountLedgers.ToList();
            List<DataRow> drows = ds.Tables[0].AsEnumerable().ToList();
            List<AccountLedger> entFilteredProducts = (from prd in entAccountLedgers
                                                       join row in drows on prd.id equals row["id"].ToString().ToInt32()
                                                       select prd).OrderBy(x => x.LedgerName).ToList();
            return entFilteredProducts;
        }
        public List<AccountGroup> GetAccountGroups(int iGrpID)
        {
            atACCHotelEntities dbh = atHotelContext.CreateContext();
            SqlHelper sqlh = new SqlHelper();
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("GroupID", iGrpID));
            DataSet ds = sqlh.ExecuteProcedure("sp_GetGroups", sqlParameters);
            List<AccountGroup> entAccountGroup = dbh.AccountGroups.ToList();
            List<DataRow> drows = ds.Tables[0].AsEnumerable().ToList();
            List<AccountGroup> entFilteredGroup = (from grp in entAccountGroup
                                                   join row in drows on grp.id equals row["id"].ToString().ToInt32()
                                                   select grp).ToList();

            if (GlobalFunctions.blnArabicAccountNameAndGroupName)
            {
                foreach (AccountGroup al in entFilteredGroup)
                {
                    if (al.GroupName2 != null && al.GroupName2 != "")
                    {
                        al.GroupName = al.GroupName2;
                    }
                }
            }
            return entFilteredGroup;
        }
    }
}
