﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.Masters.Classes
{
    class GuestSearchClass
    {
        int _id;
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        string _Code;
        public string Code
        {
            get { return _Code; }
            set { _Code = value; }
        }

        string _Name;
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        string _ContactPerson;
        public string ContactPerson
        {
            get { return _ContactPerson; }
            set { _ContactPerson = value; }
        }

        string _MobileNumber;
        public string MobileNumber
        {
            get { return _MobileNumber; }
            set { _MobileNumber = value; }
        }

        string _Gender;
        public string Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }
    }
}
