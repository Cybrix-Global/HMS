﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atACC.HTL.Masters.Classes
{
    public class atListBoxItem
    {
        public string Text { get; set; }
        public int Value { get; set; }
        public override string ToString()
        {
            return this.Text;
        }
    }
}
