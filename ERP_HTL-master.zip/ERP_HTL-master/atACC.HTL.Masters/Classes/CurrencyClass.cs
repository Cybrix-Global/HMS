﻿namespace atACC.HTL.Masters
{
    public class CurrencyClass
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _CurrencyName;

        public string CurrencyName
        {
            get { return _CurrencyName; }
            set { _CurrencyName = value; }
        }
    }
}