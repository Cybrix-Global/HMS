﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using atACCFramework.BaseClasses;
using atACCFramework.Common;
using atACCFramework.UserControls;
using System.Data.Entity;
using atACC.Common;
using atACC.CommonMessages;
using atACC.CommonExtensions;
using System.Data.Objects;
using System.Diagnostics;
using atACC.HTL.ORM;
using System.Data.SqlClient;
using atACC.HTL.Masters;
using atACC.HTL.Masters.Classes;

namespace atACC.HTL.Masters
{
    public partial class SettingsView : DialogBase
    {
        #region Constructor
        public SettingsView()
        {
            InitializeComponent();
        }
        #endregion

        #region Private Variables
        List<AccountLedger> entCommonAccounts;
        List<AccountLedger> entDiscSlabAccounts;
        List<AccountLedger> entSlabsAccounts;
        List<AccountLedger> entCashAccounts;
        List<AccountLedger> entBankAccounts;
        List<AccountGroup> entGuestAccountsUnder;
        atACCHotelEntities dbh;
        CommonLibClasses objLib;
        GetAccounts getAccc;
        List<AccountSettings> entAccountSettings;
        AccountSettings entRentAccount;
        AccountSettings entExtrasAccount;
        AccountSettings entDeductionAccount;
        AccountSettings entLaundryAccount;
        AccountSettings entGuestAccount;
        AccountSettings entCashAccount;
        AccountSettings entCreditCardAccount;
        AccountSettings entChequeAccount;
        AccountSettings entDDAccount;
        AccountSettings entOnlineBankingAccount;
        AccountSettings entEWalletAccount;
        AccountSettings entDiscountAccount;
        AccountSettings entExciseDutyAccount;
        AccountSettings entTax1Account;
        AccountSettings entTax2Account;
        AccountSettings entTax3Account;
        AccountSettings entAddlTaxAccount;
        AccountSettings entVATAccount;
        AccountSettings entSGSTAccount;
        AccountSettings entCGSTAccount;
        AccountSettings entIGSTAccount;
        DefaultSettings entDefaultSettings;
        List<DefaultUserSetting> entDefaultUserSettings;
        DefaultUserSettingMapping entDefaultUserSettingMapping;
        List<DefaultUserSettingMapping> entDefaultUserSettingMappings;
        MessageTemplate entEmailMessageTemplate;
        MessageTemplate entSMSMessageTemplate;
        MessageTemplate entWhatsAppMessageTemplate;
        List<RoomStatusColorSetting> entStatusColorSettings;
        RoomStatusColorSetting entAvailableColor;
        RoomStatusColorSetting entBookingColor;
        RoomStatusColorSetting entGroupBookingColor;
        RoomStatusColorSetting entCheckInColor;
        RoomStatusColorSetting entGroupCheckInColor;
        RoomStatusColorSetting entDirtyColor;
        RoomStatusColorSetting entCleanColor;
        RoomStatusColorSetting entOutOfOrderColor;
        List<MasterValue> entRoomUserFields;
        List<MasterValue> entHallUserFields;
        MasterValue entRoomUserField1;
        MasterValue entRoomUserField2;
        MasterValue entRoomUserField3;
        MasterValue entRoomUserField4;
        MasterValue entHallUserField1;
        MasterValue entHallUserField2;
        MasterValue entHallUserField3;
        MasterValue entHallUserField4;
        #endregion

        #region Populate Events
        private void PopulateCombos()
        {
            entCommonAccounts = getAccc.GetAccountLedgers(50);
            objLib.fnFillCombo(ref cmbRentAccount, entCommonAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbExtras, entCommonAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbDeduction, entCommonAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbLaundry, entCommonAccounts, "LedgerName", "id");

            entGuestAccountsUnder = getAccc.GetAccountGroups(25);
            objLib.fnFillCombo(ref cmbGuests, entGuestAccountsUnder, "GroupName", "id");

            entCashAccounts = getAccc.GetAccountLedgers(27);
            objLib.fnFillCombo(ref cmbCash, entCashAccounts, "LedgerName", "id");

            entBankAccounts = getAccc.GetAccountLedgers(26);
            objLib.fnFillCombo(ref cmbCreditCard, entBankAccounts, "LedgerName", "id"); cmbCreditCard.SelectedIndex = -1;
            objLib.fnFillCombo(ref cmbCheque, entBankAccounts, "LedgerName", "id"); cmbCheque.SelectedIndex = -1;
            objLib.fnFillCombo(ref cmbDD, entBankAccounts, "LedgerName", "id"); cmbDD.SelectedIndex = -1;
            objLib.fnFillCombo(ref cmbOnlineBanking, entBankAccounts, "LedgerName", "id"); cmbOnlineBanking.SelectedIndex = -1;
            objLib.fnFillCombo(ref cmbEWallet, entBankAccounts, "LedgerName", "id"); cmbEWallet.SelectedIndex = -1;

            entDiscSlabAccounts = getAccc.GetAccountLedgers(62);
            objLib.fnFillCombo(ref cmbDiscountSlab, entDiscSlabAccounts, "LedgerName", "id");

            entSlabsAccounts = getAccc.GetAccountLedgers(95);
            objLib.fnFillCombo(ref cmbExciseDuty, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbTax1, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbTax2, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbTax3, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbAddlTax, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbVAT, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbSGST, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbCGST, entSlabsAccounts, "LedgerName", "id");
            objLib.fnFillCombo(ref cmbIGST, entSlabsAccounts, "LedgerName", "id");
        }
        private void PopulateDefaultUserSettings(int iUserID)
        {
            entDefaultUserSettings = dbh.DefaultUserSettings.OrderBy(x => x.DisplayPosition).ToList();
            lstLoginSettings.Items.Clear();
            entDefaultUserSettingMappings = dbh.DefaultUserSettingMappings.Where(x => x.FK_LoginUserID == iUserID).ToList();
            foreach (DefaultUserSetting loginSetting in entDefaultUserSettings)
            {
                atListBoxItem itm = new atListBoxItem();
                itm.Text = loginSetting.SettingsName;
                itm.Value = loginSetting.id;
                if (entDefaultUserSettingMappings.Where(x => x.FK_DefaultUserSettingsID == loginSetting.id).ToList().Count > 0)
                {
                    lstLoginSettings.Items.Add(itm, true);
                }
                else
                {
                    lstLoginSettings.Items.Add(itm, false);
                }
            }
        }
        private void EnablePropertyBasedOnSettings()
        {
            try
            {
                lblDiscount.Enabled = cmbDiscountSlab.Enabled = GlobalFunctions.blnSlabDiscount;
                lblExciseDuty.Enabled = cmbExciseDuty.Enabled = GlobalFunctions.blnExiseDuty;
                lblTax1.Enabled = cmbTax1.Enabled = GlobalFunctions.blnTax1;
                lblTax2.Enabled = cmbTax2.Enabled = GlobalFunctions.blnTax2;
                lblTax3.Enabled = cmbTax3.Enabled = GlobalFunctions.blnTax3;
                lblAdditionalTax.Enabled = cmbAddlTax.Enabled = GlobalFunctions.blnAddnlTax;
                lblVAT.Enabled = cmbVAT.Enabled = GlobalFunctions.blnVAT;
                lblCGST.Enabled = lblSGST.Enabled = lblIGST.Enabled = cmbCGST.Enabled = cmbSGST.Enabled = cmbIGST.Enabled = GlobalFunctions.blnGST;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SelectTabButtonAccounts()
        {
            TabSettings.SelectedTab = tabAccounts;
            btnAccounts.BackColor = Color.White; 
            btnAccounts.ForeColor = Color.FromArgb(61, 77, 125);
            btnDefault.BackColor = btnEmailTemp.BackColor = btnSMSTemp.BackColor = btnWhatsAppTemp.BackColor = Color.Transparent;
            btnDefault.ForeColor = btnEmailTemp.ForeColor = btnSMSTemp.ForeColor = btnWhatsAppTemp.ForeColor = Color.White;
            btnSelected.Top = btnAccounts.Top;
        }
        private void SelectTabButtonDefault()
        {
            TabSettings.SelectedTab = tabDefault;
            btnDefault.BackColor = Color.White;
            btnDefault.ForeColor = Color.FromArgb(61, 77, 125);
            btnAccounts.BackColor = btnEmailTemp.BackColor = btnSMSTemp.BackColor = btnWhatsAppTemp.BackColor = Color.Transparent;
            btnAccounts.ForeColor = btnEmailTemp.ForeColor = btnSMSTemp.ForeColor = btnWhatsAppTemp.ForeColor = Color.White;
            btnSelected.Top = btnDefault.Top;
        }
        private void SelectButtonEmailTemp()
        {
            TabSettings.SelectedTab = tabEmailTemplate;
            btnEmailTemp.BackColor = Color.White;
            btnEmailTemp.ForeColor = Color.FromArgb(61, 77, 125);
            btnAccounts.BackColor = btnDefault.BackColor = btnSMSTemp.BackColor = btnWhatsAppTemp.BackColor = Color.Transparent;
            btnAccounts.ForeColor = btnDefault.ForeColor = btnSMSTemp.ForeColor = btnWhatsAppTemp.ForeColor = Color.White;
            btnSelected.Top = btnEmailTemp.Top;
        }
        private void SelectButtonSMSTemp()
        {
            TabSettings.SelectedTab = tabSMS;
            btnSMSTemp.BackColor = Color.White;
            btnSMSTemp.ForeColor = Color.FromArgb(61, 77, 125);
            btnAccounts.BackColor = btnDefault.BackColor = btnEmailTemp.BackColor = btnWhatsAppTemp.BackColor = Color.Transparent;
            btnAccounts.ForeColor = btnDefault.ForeColor = btnEmailTemp.ForeColor = btnWhatsAppTemp.ForeColor = Color.White;
            btnSelected.Top = btnSMSTemp.Top;
        }
        private void SelectButtonWhatsAppTemp()
        {
            TabSettings.SelectedTab = tabWhatsApp;
            btnWhatsAppTemp.BackColor = Color.White;
            btnWhatsAppTemp.ForeColor = Color.FromArgb(61, 77, 125);
            btnAccounts.BackColor = btnDefault.BackColor = btnEmailTemp.BackColor = btnSMSTemp.BackColor = Color.Transparent;
            btnAccounts.ForeColor = btnDefault.ForeColor = btnEmailTemp.ForeColor = btnSMSTemp.ForeColor = Color.White;
            btnSelected.Top = btnWhatsAppTemp.Top;
        }
        private void ReloadData()
        {
            #region AccountSettings
            entAccountSettings = dbh.AccountSettings.ToList();
            entRentAccount = entAccountSettings.Where(x => x.AccountFor == "Rent").SingleOrDefault();
            entExtrasAccount = entAccountSettings.Where(x => x.AccountFor == "ExtraServices").SingleOrDefault();
            entDeductionAccount = entAccountSettings.Where(x => x.AccountFor == "Deduction").SingleOrDefault();
            entLaundryAccount = entAccountSettings.Where(x => x.AccountFor == "Laundry").SingleOrDefault();
            entGuestAccount = entAccountSettings.Where(x => x.AccountFor == "Guest").SingleOrDefault();
            entCashAccount = entAccountSettings.Where(x => x.AccountFor == "Cash").SingleOrDefault();
            entCreditCardAccount = entAccountSettings.Where(x => x.AccountFor == "CreditCard").SingleOrDefault();
            entChequeAccount = entAccountSettings.Where(x => x.AccountFor == "Cheque").SingleOrDefault();
            entDDAccount = entAccountSettings.Where(x => x.AccountFor == "DD").SingleOrDefault();
            entOnlineBankingAccount = entAccountSettings.Where(x => x.AccountFor == "OnlineBanking").SingleOrDefault();
            entEWalletAccount = entAccountSettings.Where(x => x.AccountFor == "EWallet").SingleOrDefault();
            entDiscountAccount = entAccountSettings.Where(x => x.AccountFor == "Discount").SingleOrDefault();
            entExciseDutyAccount = entAccountSettings.Where(x => x.AccountFor == "ExciseDuty").SingleOrDefault();
            entTax1Account = entAccountSettings.Where(x => x.AccountFor == "Tax1").SingleOrDefault();
            entTax2Account = entAccountSettings.Where(x => x.AccountFor == "Tax2").SingleOrDefault();
            entTax3Account = entAccountSettings.Where(x => x.AccountFor == "Tax3").SingleOrDefault();
            entAddlTaxAccount = entAccountSettings.Where(x => x.AccountFor == "AdditionalTax").SingleOrDefault();
            entVATAccount = entAccountSettings.Where(x => x.AccountFor == "VAT").SingleOrDefault();
            entSGSTAccount = entAccountSettings.Where(x => x.AccountFor == "SGST").SingleOrDefault();
            entCGSTAccount = entAccountSettings.Where(x => x.AccountFor == "CGST").SingleOrDefault();
            entIGSTAccount = entAccountSettings.Where(x => x.AccountFor == "IGST").SingleOrDefault();

            cmbRentAccount.SelectedValue = entRentAccount.Value == null ? -1 : entRentAccount.Value;
            cmbExtras.SelectedValue = entExtrasAccount.Value == null ? -1 : entExtrasAccount.Value;
            cmbDeduction.SelectedValue = entDeductionAccount.Value == null ? -1 : entDeductionAccount.Value;
            cmbLaundry.SelectedValue = entLaundryAccount.Value == null ? -1 : entLaundryAccount.Value;
            cmbGuests.SelectedValue = entGuestAccount.Value == null ? -1 : entGuestAccount.Value;
            cmbCash.SelectedValue = entCashAccount.Value == null ? -1 : entCashAccount.Value;
            cmbCreditCard.SelectedValue = entCreditCardAccount.Value == null ? -1 : entCreditCardAccount.Value;
            cmbCheque.SelectedValue = entChequeAccount.Value == null ? -1 : entChequeAccount.Value;
            cmbDD.SelectedValue = entDDAccount.Value == null ? -1 : entDDAccount.Value;
            cmbOnlineBanking.SelectedValue = entOnlineBankingAccount.Value == null ? -1 : entOnlineBankingAccount.Value;
            cmbEWallet.SelectedValue = entEWalletAccount.Value == null ? -1 : entEWalletAccount.Value;
            cmbDiscountSlab.SelectedValue = entDiscountAccount.Value == null ? -1 : entDiscountAccount.Value;
            cmbExciseDuty.SelectedValue = entExciseDutyAccount.Value == null ? -1 : entExciseDutyAccount.Value;
            cmbTax1.SelectedValue = entTax1Account.Value == null ? -1 : entTax1Account.Value;
            cmbTax2.SelectedValue = entTax2Account.Value == null ? -1 : entTax2Account.Value;
            cmbTax3.SelectedValue = entTax3Account.Value == null ? -1 : entTax3Account.Value;
            cmbAddlTax.SelectedValue = entAddlTaxAccount.Value == null ? -1 : entAddlTaxAccount.Value;
            cmbVAT.SelectedValue = entVATAccount.Value == null ? -1 : entVATAccount.Value;
            cmbSGST.SelectedValue = entSGSTAccount.Value == null ? -1 : entSGSTAccount.Value;
            cmbCGST.SelectedValue = entCGSTAccount.Value == null ? -1 : entCGSTAccount.Value;
            cmbIGST.SelectedValue = entIGSTAccount.Value == null ? -1 : entIGSTAccount.Value;
            #endregion

            #region Default Settings
            entDefaultSettings = dbh.DefaultSettings.Where(x=>x.id == 1).SingleOrDefault();
            dtpCheckInTime.Value = entDefaultSettings.CheckInTime.Value;
            dtpCheckOutTime.Value = entDefaultSettings.CheckOutTime.Value;
            txtFlexibleTime.Value = entDefaultSettings.FlexibleTime.Value;
            if (entDefaultSettings.Active == true)
            {
                chkActive.Checked = true;
            }
            else
            {
                chkActive.Checked = false;
            }
            #endregion

            #region Userfields
            entRoomUserFields = dbh.MasterValues.Where(x=>x.FK_MasterTypeID == (int)ENMasterTypeT4.RoomUserFields).ToList();
            entHallUserFields = dbh.MasterValues.Where(x => x.FK_MasterTypeID == (int)ENMasterTypeT4.HallUserFields).ToList();
            entRoomUserField1 = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField1).SingleOrDefault();
            entRoomUserField2  = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField2).SingleOrDefault();
            entRoomUserField3 = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField3).SingleOrDefault();
            entRoomUserField4  = entRoomUserFields.Where(x => x.id == (int)ENMVRoomUserFields.UserField4).SingleOrDefault();
            entHallUserField1 = entHallUserFields.Where(x => x.id == (int)ENMVHallUserFields.UserField1).SingleOrDefault();
            entHallUserField2 = entHallUserFields.Where(x => x.id == (int)ENMVHallUserFields.UserField2).SingleOrDefault();
            entHallUserField3 = entHallUserFields.Where(x => x.id == (int)ENMVHallUserFields.UserField3).SingleOrDefault();
            entHallUserField4 = entHallUserFields.Where(x => x.id == (int)ENMVHallUserFields.UserField4).SingleOrDefault();
            txtRoomUserField1.Text = entRoomUserField1.Description;
            txtRoomUserField2.Text = entRoomUserField2.Description;
            txtRoomUserField3.Text = entRoomUserField3.Description;
            txtRoomUserField4.Text = entRoomUserField4.Description;
            txtHallUserField1.Text = entHallUserField1.Description;
            txtHallUserField2.Text = entHallUserField2.Description;
            txtHallUserField3.Text = entHallUserField3.Description;
            txtHallUserField4.Text = entHallUserField4.Description;
            #endregion

            #region Status Color
            entStatusColorSettings = dbh.RoomStatusColorSettings.ToList();

            #region Available
            entAvailableColor = entStatusColorSettings.Where(x => x.id == 1).SingleOrDefault();
            int iAvailableColor = entAvailableColor.Color.ToInt32();
            Color AvailableColor = Color.FromArgb(iAvailableColor);
            btnColorAvailable.BackColor = AvailableColor;
            #endregion

            #region Booking
            entBookingColor = entStatusColorSettings.Where(x => x.id == 2).SingleOrDefault();
            int iBookingColor = entBookingColor.Color.ToInt32();
            Color BookingColor = Color.FromArgb(iBookingColor);
            btnColorBooking.BackColor = BookingColor;
            #endregion

            #region GroupBooking
            entGroupBookingColor = entStatusColorSettings.Where(x => x.id == 3).SingleOrDefault();
            int iGroupBookingColor = entGroupBookingColor.Color.ToInt32();
            Color GroupBookingColor = Color.FromArgb(iGroupBookingColor);
            btnColorGrpBooking.BackColor = GroupBookingColor;
            #endregion

            #region CheckIn
            entCheckInColor = entStatusColorSettings.Where(x => x.id == 4).SingleOrDefault();
            int iCheckInColor = entCheckInColor.Color.ToInt32();
            Color CheckInColor = Color.FromArgb(iCheckInColor);
            btnColorCheckIn.BackColor = CheckInColor;
            #endregion

            #region Group Check In
            entGroupCheckInColor = entStatusColorSettings.Where(x => x.id == 5).SingleOrDefault();
            int iGroupCheckInColor = entGroupCheckInColor.Color.ToInt32();
            Color GroupCheckInColor = Color.FromArgb(iGroupCheckInColor);
            btnColorGrpCheckIn.BackColor = GroupCheckInColor;
            #endregion

            #region Dirty
            entDirtyColor = entStatusColorSettings.Where(x => x.id == 6).SingleOrDefault();
            int iDirtyColor = entDirtyColor.Color.ToInt32();
            Color DirtyColor = Color.FromArgb(iDirtyColor);
            btnColorDirty.BackColor = DirtyColor;
            #endregion

            #region Clean
            entCleanColor = entStatusColorSettings.Where(x => x.id == 7).SingleOrDefault();
            int iCleanColor = entCleanColor.Color.ToInt32();
            Color CleanColor = Color.FromArgb(iCleanColor);
            btnColorClean.BackColor = CleanColor;
            #endregion

            #region OutOfOrder
            entOutOfOrderColor = entStatusColorSettings.Where(x => x.id == 8).SingleOrDefault();
            int iOutOfOrderColor = entOutOfOrderColor.Color.ToInt32();
            Color OutOfOrderColor = Color.FromArgb(iOutOfOrderColor);
            btnColorOutofOrder.BackColor = OutOfOrderColor;
            #endregion

            #endregion

            #region Email Template
            entEmailMessageTemplate = dbh.MessageTemplates.Where(x => x.Type == "Email").SingleOrDefault();
            txtEmailBooking.Text = entEmailMessageTemplate.Booking;
            txtEmailCheckIn.Text = entEmailMessageTemplate.CheckIn;
            txtEmailCheckOut.Text = entEmailMessageTemplate.CheckOut;
            txtEmailGrpCheckIn.Text = entEmailMessageTemplate.GroupCheckIn;
            txtEmailGrpCheckOut.Text = entEmailMessageTemplate.GroupCheckOut;
            #endregion

            #region SMS Template
            entSMSMessageTemplate = dbh.MessageTemplates.Where(x => x.Type == "SMS").SingleOrDefault();
            txtSMSBooking.Text = entSMSMessageTemplate.Booking;
            txtSMSCheckIn.Text = entSMSMessageTemplate.CheckIn;
            txtSMSCheckOut.Text = entSMSMessageTemplate.CheckOut;
            txtSMSGrpCheckIn.Text = entSMSMessageTemplate.GroupCheckIn;
            txtSMSGrpCheckOut.Text = entSMSMessageTemplate.GroupCheckOut;
            #endregion

            #region WhatsApp Template
            entWhatsAppMessageTemplate = dbh.MessageTemplates.Where(x => x.Type == "WhatsApp").SingleOrDefault();
            txtWhtsappBooking.Text = entWhatsAppMessageTemplate.Booking;
            txtWhtsappCheckIn.Text = entWhatsAppMessageTemplate.CheckIn;
            txtWhtsappCheckOut.Text = entWhatsAppMessageTemplate.CheckOut;
            txtWhtsappGrpCheckIn.Text = entWhatsAppMessageTemplate.GroupCheckIn;
            txtWhtsappGrpCheckOut.Text = entWhatsAppMessageTemplate.GroupCheckOut;
            #endregion
        }
        #endregion

        #region Form Events
        private void SettingsView_Load(object sender, EventArgs e)
        {
            
        }
        private void btnAccounts_Click(object sender, EventArgs e)
        {
            SelectTabButtonAccounts();
            cmbRentAccount.Focus();
        }
        private void btnDefault_Click(object sender, EventArgs e)
        {
            SelectTabButtonDefault();
            dtpCheckInTime.Focus();
        }
        private void btnEmailTemp_Click(object sender, EventArgs e)
        {
            SelectButtonEmailTemp();
            txtEmailBooking.Focus();
        }
        private void btnSMSTemp_Click(object sender, EventArgs e)
        {
            SelectButtonSMSTemp();
            txtSMSBooking.Focus();
        }
        private void btnWhatsAppTemp_Click(object sender, EventArgs e)
        {
            SelectButtonWhatsAppTemp();
            txtWhtsappBooking.Focus();
        }
        #endregion

        #region Color Choose
        private void btnColorAvailable_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorAvailable.BackColor = clrStatusColor.Color;
            }
        }
        private void btnColorBooking_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorBooking.BackColor = clrStatusColor.Color;
            }
        }
        private void btnColorGrpBooking_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorGrpBooking.BackColor = clrStatusColor.Color;
            }
        }
        private void btnColorCheckIn_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorCheckIn.BackColor = clrStatusColor.Color;
            }
        }
        private void btnColorCheckOut_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorGrpCheckIn.BackColor = clrStatusColor.Color;
            }
        }
        private void btnColorDirty_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorDirty.BackColor = clrStatusColor.Color;
            }
        }
        private void btnColorClean_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorClean.BackColor = clrStatusColor.Color;
            }
        }
        private void btnColorOutofOrder_Click(object sender, EventArgs e)
        {
            if (clrStatusColor.ShowDialog() == DialogResult.OK)
            {
                btnColorOutofOrder.BackColor = clrStatusColor.Color;
            }
        }
        #endregion

        #region Framework Events
        private void SettingsView_atInitialise()
        {
            try
            {
                objLib = new CommonLibClasses();
                dbh = atHotelContext.CreateContext();
                getAccc = new GetAccounts();
                PopulateCombos();
                SelectTabButtonAccounts();
                EnablePropertyBasedOnSettings();
                ReloadData();
                PopulateDefaultUserSettings(GlobalFunctions.LoginUserID);
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccuredWhileIntialising);
            }
        }
        private bool SettingsView_atValidate(object source)
        {
            try
            {
                if (cmbCreditCard.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbCreditCard, MessageKeys.MsgBankAccount + " " + MessageKeys.MsgMustbeSelected);
                    cmbCreditCard.Focus();
                    return false;
                }
                if (cmbCheque.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbCheque, MessageKeys.MsgBankAccount + " " + MessageKeys.MsgMustbeSelected);
                    cmbCheque.Focus();
                    return false;
                }
                if (cmbDD.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbDD, MessageKeys.MsgBankAccount + " " + MessageKeys.MsgMustbeSelected);
                    cmbDD.Focus();
                    return false;
                }
                if (cmbOnlineBanking.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbOnlineBanking, MessageKeys.MsgBankAccount + " " + MessageKeys.MsgMustbeSelected);
                    cmbOnlineBanking.Focus();
                    return false;
                }
                if (cmbEWallet.Text.Trim() == string.Empty)
                {
                    errProvider.SetError(cmbEWallet, MessageKeys.MsgBankAccount + " " + MessageKeys.MsgMustbeSelected);
                    cmbEWallet.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(MessageKeys.MsgExceptionOccurredWhileValidating);
                return false;
            }
        }
        private bool SettingsView_atOkClick(object source, OKClickEventArgs e)
        {
            try
            {
                #region Account Settings
                entRentAccount.Value = cmbRentAccount.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entRentAccount, EntityState.Modified);

                entExtrasAccount.Value = cmbExtras.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entExtrasAccount, EntityState.Modified);

                entDeductionAccount.Value = cmbDeduction.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entDeductionAccount, EntityState.Modified);

                entLaundryAccount.Value = cmbLaundry.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entLaundryAccount, EntityState.Modified);

                entGuestAccount.Value = cmbGuests.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entLaundryAccount, EntityState.Modified);

                entCashAccount.Value = cmbCash.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entCashAccount, EntityState.Modified);

                entCreditCardAccount.Value = cmbCreditCard.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entCreditCardAccount, EntityState.Modified);

                entChequeAccount.Value = cmbCheque.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entChequeAccount, EntityState.Modified);

                entDDAccount.Value = cmbDD.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entDDAccount, EntityState.Modified);

                entOnlineBankingAccount.Value = cmbOnlineBanking.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entOnlineBankingAccount, EntityState.Modified);

                entEWalletAccount.Value = cmbEWallet.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entEWalletAccount, EntityState.Modified);

                entDiscountAccount.Value = cmbDiscountSlab.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entDiscountAccount, EntityState.Modified);

                entExciseDutyAccount.Value = cmbExciseDuty.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entExciseDutyAccount, EntityState.Modified);

                entTax1Account.Value = cmbTax1.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entTax1Account, EntityState.Modified);

                entTax2Account.Value = cmbTax2.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entTax2Account, EntityState.Modified);

                entTax3Account.Value = cmbTax3.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entTax3Account, EntityState.Modified);

                entAddlTaxAccount.Value = cmbAddlTax.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entAddlTaxAccount, EntityState.Modified);

                entVATAccount.Value = cmbVAT.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entVATAccount, EntityState.Modified);

                entSGSTAccount.Value = cmbSGST.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entSGSTAccount, EntityState.Modified);

                entCGSTAccount.Value = cmbCGST.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entCGSTAccount, EntityState.Modified);

                entIGSTAccount.Value = cmbIGST.SelectedValue.ToInt32();
                dbh.ObjectStateManager.ChangeObjectState(entIGSTAccount, EntityState.Modified);
                #endregion

                #region Default Settings
                entDefaultSettings.CheckInTime = dtpCheckInTime.Value;
                entDefaultSettings.CheckOutTime = dtpCheckOutTime.Value;
                entDefaultSettings.FlexibleTime = txtFlexibleTime.Text.ToInt32();
                entDefaultSettings.Active = chkActive.Checked ? true : false;
                dbh.ObjectStateManager.ChangeObjectState(entDefaultSettings, EntityState.Modified);
                #endregion

                #region Room Or Hall Userfields
                entRoomUserField1.Description = txtRoomUserField1.Text;
                dbh.ObjectStateManager.ChangeObjectState(entRoomUserField1, EntityState.Modified);

                entRoomUserField2.Description = txtRoomUserField2.Text;
                dbh.ObjectStateManager.ChangeObjectState(entRoomUserField2, EntityState.Modified);

                entRoomUserField3.Description = txtRoomUserField3.Text;
                dbh.ObjectStateManager.ChangeObjectState(entRoomUserField3, EntityState.Modified);

                entRoomUserField4.Description = txtRoomUserField4.Text;
                dbh.ObjectStateManager.ChangeObjectState(entRoomUserField4, EntityState.Modified);

                entHallUserField1.Description = txtHallUserField1.Text;
                dbh.ObjectStateManager.ChangeObjectState(entHallUserField1, EntityState.Modified);

                entHallUserField2.Description = txtHallUserField2.Text;
                dbh.ObjectStateManager.ChangeObjectState(entHallUserField2, EntityState.Modified);

                entHallUserField3.Description = txtHallUserField3.Text;
                dbh.ObjectStateManager.ChangeObjectState(entHallUserField3, EntityState.Modified);

                entHallUserField4.Description = txtHallUserField4.Text;
                dbh.ObjectStateManager.ChangeObjectState(entHallUserField4, EntityState.Modified);
                #endregion

                #region Saving & Delete New Default User Login Settings Mapp
                int iSelectedUser = GlobalFunctions.LoginUserID;

                #region Delete
                foreach (DefaultUserSettingMapping mapp in entDefaultUserSettingMappings)
                {
                    dbh.DefaultUserSettingMappings.DeleteObject(mapp);
                }
                #endregion

                #region Save
                for (int i = 0; i < lstLoginSettings.Items.Count; i++)
                {
                    if (lstLoginSettings.GetItemChecked(i))
                    {
                        atListBoxItem itm = (atListBoxItem)lstLoginSettings.Items[i];
                        DefaultUserSettingMapping NewMapp = new DefaultUserSettingMapping();
                        NewMapp.FK_LoginUserID = GlobalFunctions.LoginUserID;
                        NewMapp.FK_DefaultUserSettingsID = itm.Value;
                        NewMapp.Value = 1;
                        dbh.DefaultUserSettingMappings.AddObject(NewMapp);
                    }
                }
                #endregion
                #endregion

                #region Email Template
                entEmailMessageTemplate.Booking = txtEmailBooking.Text;
                entEmailMessageTemplate.CheckIn = txtEmailCheckIn.Text;
                entEmailMessageTemplate.CheckOut = txtEmailCheckOut.Text;
                entEmailMessageTemplate.GroupCheckIn = txtEmailGrpCheckIn.Text;
                entEmailMessageTemplate.GroupCheckOut = txtEmailGrpCheckOut.Text;
                dbh.ObjectStateManager.ChangeObjectState(entEmailMessageTemplate, EntityState.Modified);
                #endregion

                #region SMS Template
                entSMSMessageTemplate.Booking = txtSMSBooking.Text;
                entSMSMessageTemplate.CheckIn = txtSMSCheckIn.Text;
                entSMSMessageTemplate.CheckOut = txtSMSCheckOut.Text;
                entSMSMessageTemplate.GroupCheckIn = txtSMSGrpCheckIn.Text;
                entSMSMessageTemplate.GroupCheckOut = txtSMSGrpCheckOut.Text;
                dbh.ObjectStateManager.ChangeObjectState(entSMSMessageTemplate, EntityState.Modified);
                #endregion

                #region WhatsApp Template
                entWhatsAppMessageTemplate.Booking = txtWhtsappBooking.Text;
                entWhatsAppMessageTemplate.CheckIn = txtWhtsappCheckIn.Text;
                entWhatsAppMessageTemplate.CheckOut = txtWhtsappCheckOut.Text;
                entWhatsAppMessageTemplate.GroupCheckIn = txtWhtsappGrpCheckIn.Text;
                entWhatsAppMessageTemplate.GroupCheckOut = txtWhtsappGrpCheckOut.Text;
                dbh.ObjectStateManager.ChangeObjectState(entWhatsAppMessageTemplate, EntityState.Modified);
                #endregion

                #region StatusColorSettings
                entAvailableColor.Color = btnColorAvailable.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entAvailableColor, EntityState.Modified);

                entBookingColor.Color = btnColorBooking.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entBookingColor, EntityState.Modified);

                entGroupBookingColor.Color = btnColorGrpBooking.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entGroupBookingColor, EntityState.Modified);

                entCheckInColor.Color = btnColorCheckIn.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entCheckInColor, EntityState.Modified);

                entGroupCheckInColor.Color = btnColorGrpCheckIn.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entGroupCheckInColor, EntityState.Modified);

                entDirtyColor.Color = btnColorDirty.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entDirtyColor, EntityState.Modified);

                entCleanColor.Color = btnColorClean.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entCleanColor, EntityState.Modified);

                entOutOfOrderColor.Color = btnColorOutofOrder.BackColor.ToArgb();
                dbh.ObjectStateManager.ChangeObjectState(entOutOfOrderColor, EntityState.Modified);
                #endregion

                dbh.SaveChanges();

                GlobalProperties.RefreshDashboard = true;
                GlobalMethods.LoadAccountSettings();
                GlobalMethods.LoadUserSettings();

                return true;
            }
            catch (Exception ex)
            {
                ExceptionManager.Publish(ex);
                atMessageBox.Show(ex, ENOperation.OK);
                return false;
            }
        }
        private void SettingsView_atCancelClick(object source, CancelClickEventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
