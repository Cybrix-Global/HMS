﻿namespace atACC.HTL.Masters
{
    partial class SettingsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlOptionalBar = new atACCFramework.UserControls.atGradientPanel();
            this.btnSeperator1 = new System.Windows.Forms.Button();
            this.lblGlobal = new atACCFramework.UserControls.atLabel();
            this.btnSelected = new atACCFramework.UserControls.atGradientPanel();
            this.btnDefault = new System.Windows.Forms.Button();
            this.btnAccounts = new System.Windows.Forms.Button();
            this.btnWhatsAppTemp = new System.Windows.Forms.Button();
            this.btnSMSTemp = new System.Windows.Forms.Button();
            this.btnEmailTemp = new System.Windows.Forms.Button();
            this.pnlAccounts = new atACCFramework.UserControls.atPanel();
            this.lblIGST = new atACCFramework.UserControls.atLabel();
            this.lblCGST = new atACCFramework.UserControls.atLabel();
            this.cmbIGST = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbCGST = new atACCFramework.UserControls.ComboBoxExt();
            this.lblEWallet = new atACCFramework.UserControls.atLabel();
            this.lblOnlineBanking = new atACCFramework.UserControls.atLabel();
            this.lblDD = new atACCFramework.UserControls.atLabel();
            this.lblCheque = new atACCFramework.UserControls.atLabel();
            this.lblCreditCard = new atACCFramework.UserControls.atLabel();
            this.lblCash = new atACCFramework.UserControls.atLabel();
            this.cmbEWallet = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbOnlineBanking = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbCreditCard = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbDD = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbCheque = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbCash = new atACCFramework.UserControls.ComboBoxExt();
            this.btnSeperator5 = new System.Windows.Forms.Button();
            this.lblPayment = new atACCFramework.UserControls.atLabel();
            this.lblExciseDuty = new atACCFramework.UserControls.atLabel();
            this.lblAdditionalTax = new atACCFramework.UserControls.atLabel();
            this.lblTax3 = new atACCFramework.UserControls.atLabel();
            this.lblDiscount = new atACCFramework.UserControls.atLabel();
            this.lblSGST = new atACCFramework.UserControls.atLabel();
            this.lblVAT = new atACCFramework.UserControls.atLabel();
            this.lblTax2 = new atACCFramework.UserControls.atLabel();
            this.lblTax1 = new atACCFramework.UserControls.atLabel();
            this.cmbSGST = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbVAT = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbAddlTax = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbTax3 = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbTax2 = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbTax1 = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbExciseDuty = new atACCFramework.UserControls.ComboBoxExt();
            this.btnSeperator3 = new System.Windows.Forms.Button();
            this.lblCommon = new atACCFramework.UserControls.atLabel();
            this.btnSeperator4 = new System.Windows.Forms.Button();
            this.cmbDiscountSlab = new atACCFramework.UserControls.ComboBoxExt();
            this.lblSlabs = new atACCFramework.UserControls.atLabel();
            this.lblGuests = new atACCFramework.UserControls.atLabel();
            this.lblLaundry = new atACCFramework.UserControls.atLabel();
            this.lblDeduction = new atACCFramework.UserControls.atLabel();
            this.lblExtras = new atACCFramework.UserControls.atLabel();
            this.lblRent = new atACCFramework.UserControls.atLabel();
            this.cmbGuests = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbLaundry = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbDeduction = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbExtras = new atACCFramework.UserControls.ComboBoxExt();
            this.cmbRentAccount = new atACCFramework.UserControls.ComboBoxExt();
            this.pnlMain = new atACCFramework.UserControls.atPanel();
            this.TabSettings = new atACCFramework.UserControls.atTabControl();
            this.tabAccounts = new System.Windows.Forms.TabPage();
            this.tabDefault = new System.Windows.Forms.TabPage();
            this.grpRoomOraHallUserfields = new atACCFramework.UserControls.atGroupBox();
            this.lblHallCap = new atACCFramework.UserControls.atLabel();
            this.lblRoomCap = new atACCFramework.UserControls.atLabel();
            this.lblUserFiled1 = new atACCFramework.UserControls.atLabel();
            this.lblUserFiled4 = new atACCFramework.UserControls.atLabel();
            this.lblUserFiled2 = new atACCFramework.UserControls.atLabel();
            this.lblUserFiled3 = new atACCFramework.UserControls.atLabel();
            this.txtRoomUserField4 = new atACCFramework.UserControls.TextBoxExt();
            this.txtRoomUserField3 = new atACCFramework.UserControls.TextBoxExt();
            this.txtRoomUserField2 = new atACCFramework.UserControls.TextBoxExt();
            this.txtRoomUserField1 = new atACCFramework.UserControls.TextBoxExt();
            this.txtHallUserField4 = new atACCFramework.UserControls.TextBoxExt();
            this.txtHallUserField3 = new atACCFramework.UserControls.TextBoxExt();
            this.txtHallUserField2 = new atACCFramework.UserControls.TextBoxExt();
            this.txtHallUserField1 = new atACCFramework.UserControls.TextBoxExt();
            this.grpStatusColor = new atACCFramework.UserControls.atGroupBox();
            this.lblOutofOrder = new atACCFramework.UserControls.atLabel();
            this.lblClean = new atACCFramework.UserControls.atLabel();
            this.lblDirty = new atACCFramework.UserControls.atLabel();
            this.btnColorOutofOrder = new System.Windows.Forms.Button();
            this.btnColorClean = new System.Windows.Forms.Button();
            this.btnColorDirty = new System.Windows.Forms.Button();
            this.lblGrpCheckIn = new atACCFramework.UserControls.atLabel();
            this.lblCheckIn = new atACCFramework.UserControls.atLabel();
            this.lblGrpBooking = new atACCFramework.UserControls.atLabel();
            this.btnColorGrpCheckIn = new System.Windows.Forms.Button();
            this.btnColorCheckIn = new System.Windows.Forms.Button();
            this.btnColorGrpBooking = new System.Windows.Forms.Button();
            this.lblBooking = new atACCFramework.UserControls.atLabel();
            this.btnColorBooking = new System.Windows.Forms.Button();
            this.lblAvailable = new atACCFramework.UserControls.atLabel();
            this.btnColorAvailable = new System.Windows.Forms.Button();
            this.grpUserWise = new atACCFramework.UserControls.atGroupBox();
            this.lstLoginSettings = new System.Windows.Forms.CheckedListBox();
            this.grpOperational = new atACCFramework.UserControls.atGroupBox();
            this.txtFlexibleTime = new atACCFramework.UserControls.TextBoxExt();
            this.lblCheckInTime = new atACCFramework.UserControls.atLabel();
            this.dtpCheckOutTime = new atACCFramework.UserControls.atDateTimePicker1();
            this.lblCheckOutTime = new atACCFramework.UserControls.atLabel();
            this.dtpCheckInTime = new atACCFramework.UserControls.atDateTimePicker1();
            this.lblFlexibleTime = new atACCFramework.UserControls.atLabel();
            this.tabEmailTemplate = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.lblMailUseKeys = new atACCFramework.UserControls.atLabel();
            this.txtMailUseKeys = new System.Windows.Forms.RichTextBox();
            this.btnSeperator9 = new System.Windows.Forms.Button();
            this.lblEmailGrpCheckIn = new atACCFramework.UserControls.atLabel();
            this.btnSeperator10 = new System.Windows.Forms.Button();
            this.lblEmailGrpCheckOut = new atACCFramework.UserControls.atLabel();
            this.txtEmailGrpCheckOut = new atACCFramework.UserControls.TextBoxNormal();
            this.btnSeperator8 = new System.Windows.Forms.Button();
            this.lblEmailCheckOut = new atACCFramework.UserControls.atLabel();
            this.txtEmailCheckOut = new atACCFramework.UserControls.TextBoxNormal();
            this.txtEmailGrpCheckIn = new atACCFramework.UserControls.TextBoxNormal();
            this.txtEmailCheckIn = new atACCFramework.UserControls.TextBoxNormal();
            this.btnSeperator7 = new System.Windows.Forms.Button();
            this.lblEmailCheckIn = new atACCFramework.UserControls.atLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.lblEmailBooking = new atACCFramework.UserControls.atLabel();
            this.txtEmailBooking = new atACCFramework.UserControls.TextBoxNormal();
            this.tabSMS = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.lblSMSUseKeys = new atACCFramework.UserControls.atLabel();
            this.txtSMSUseKeys = new System.Windows.Forms.RichTextBox();
            this.btnSeperator14 = new System.Windows.Forms.Button();
            this.lblSMSGrpCheckIn = new atACCFramework.UserControls.atLabel();
            this.btnSeperator15 = new System.Windows.Forms.Button();
            this.lblSMSGrpCheckOut = new atACCFramework.UserControls.atLabel();
            this.txtSMSGrpCheckOut = new atACCFramework.UserControls.TextBoxNormal();
            this.btnSeperator13 = new System.Windows.Forms.Button();
            this.lblSMSCheckOut = new atACCFramework.UserControls.atLabel();
            this.txtSMSCheckOut = new atACCFramework.UserControls.TextBoxNormal();
            this.txtSMSGrpCheckIn = new atACCFramework.UserControls.TextBoxNormal();
            this.txtSMSCheckIn = new atACCFramework.UserControls.TextBoxNormal();
            this.btnSeperator12 = new System.Windows.Forms.Button();
            this.lblSMSCheckIn = new atACCFramework.UserControls.atLabel();
            this.btnSeperator11 = new System.Windows.Forms.Button();
            this.lblSMSBooking = new atACCFramework.UserControls.atLabel();
            this.txtSMSBooking = new atACCFramework.UserControls.TextBoxNormal();
            this.tabWhatsApp = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.atLabel1 = new atACCFramework.UserControls.atLabel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnSepeartor19 = new System.Windows.Forms.Button();
            this.lblWhtsappGrpCheckIn = new atACCFramework.UserControls.atLabel();
            this.btnSepeartor20 = new System.Windows.Forms.Button();
            this.lblWhtsappGrpCheckOut = new atACCFramework.UserControls.atLabel();
            this.txtWhtsappGrpCheckOut = new atACCFramework.UserControls.TextBoxNormal();
            this.btnSepeartor18 = new System.Windows.Forms.Button();
            this.lblWhtsappCheckOut = new atACCFramework.UserControls.atLabel();
            this.txtWhtsappCheckOut = new atACCFramework.UserControls.TextBoxNormal();
            this.txtWhtsappGrpCheckIn = new atACCFramework.UserControls.TextBoxNormal();
            this.txtWhtsappCheckIn = new atACCFramework.UserControls.TextBoxNormal();
            this.btnSepeartor17 = new System.Windows.Forms.Button();
            this.lblWhtsappCheckIn = new atACCFramework.UserControls.atLabel();
            this.btnSepeartor16 = new System.Windows.Forms.Button();
            this.lblWhtsappBooking = new atACCFramework.UserControls.atLabel();
            this.txtWhtsappBooking = new atACCFramework.UserControls.TextBoxNormal();
            this.clrStatusColor = new System.Windows.Forms.ColorDialog();
            this.chkActive = new atACCFramework.UserControls.atCheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.pnlOptionalBar.SuspendLayout();
            this.pnlAccounts.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.TabSettings.SuspendLayout();
            this.tabAccounts.SuspendLayout();
            this.tabDefault.SuspendLayout();
            this.grpRoomOraHallUserfields.SuspendLayout();
            this.grpStatusColor.SuspendLayout();
            this.grpUserWise.SuspendLayout();
            this.grpOperational.SuspendLayout();
            this.tabEmailTemplate.SuspendLayout();
            this.tabSMS.SuspendLayout();
            this.tabWhatsApp.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlOptionalBar
            // 
            this.pnlOptionalBar.AllowMultiSelect = false;
            this.pnlOptionalBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlOptionalBar.Angle = 120F;
            this.pnlOptionalBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.pnlOptionalBar.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(67)))), ((int)(((byte)(108)))));
            this.pnlOptionalBar.Controls.Add(this.btnSeperator1);
            this.pnlOptionalBar.Controls.Add(this.lblGlobal);
            this.pnlOptionalBar.Controls.Add(this.btnSelected);
            this.pnlOptionalBar.Controls.Add(this.btnDefault);
            this.pnlOptionalBar.Controls.Add(this.btnAccounts);
            this.pnlOptionalBar.Controls.Add(this.btnWhatsAppTemp);
            this.pnlOptionalBar.Controls.Add(this.btnSMSTemp);
            this.pnlOptionalBar.Controls.Add(this.btnEmailTemp);
            this.pnlOptionalBar.Font = new System.Drawing.Font("Open Sans", 8.25F);
            this.pnlOptionalBar.Location = new System.Drawing.Point(4, 40);
            this.pnlOptionalBar.Name = "pnlOptionalBar";
            this.pnlOptionalBar.Selected = false;
            this.pnlOptionalBar.Size = new System.Drawing.Size(150, 484);
            this.pnlOptionalBar.TabIndex = 8;
            this.pnlOptionalBar.TextAdjestmentHeight = 0;
            this.pnlOptionalBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOptionalBar.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            // 
            // btnSeperator1
            // 
            this.btnSeperator1.BackColor = System.Drawing.Color.DimGray;
            this.btnSeperator1.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator1.FlatAppearance.BorderSize = 0;
            this.btnSeperator1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator1.Location = new System.Drawing.Point(0, 37);
            this.btnSeperator1.Name = "btnSeperator1";
            this.btnSeperator1.Size = new System.Drawing.Size(134, 1);
            this.btnSeperator1.TabIndex = 139;
            this.btnSeperator1.UseVisualStyleBackColor = false;
            // 
            // lblGlobal
            // 
            this.lblGlobal.AutoSize = true;
            this.lblGlobal.BackColor = System.Drawing.Color.Transparent;
            this.lblGlobal.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblGlobal.ForeColor = System.Drawing.Color.Black;
            this.lblGlobal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblGlobal.Location = new System.Drawing.Point(3, 12);
            this.lblGlobal.Name = "lblGlobal";
            this.lblGlobal.RequiredField = false;
            this.lblGlobal.Size = new System.Drawing.Size(62, 22);
            this.lblGlobal.TabIndex = 7;
            this.lblGlobal.Text = "Global";
            // 
            // btnSelected
            // 
            this.btnSelected.AllowMultiSelect = false;
            this.btnSelected.Angle = 110F;
            this.btnSelected.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSelected.BottomColor = System.Drawing.Color.MediumSpringGreen;
            this.btnSelected.Location = new System.Drawing.Point(0, 51);
            this.btnSelected.Name = "btnSelected";
            this.btnSelected.Selected = false;
            this.btnSelected.Size = new System.Drawing.Size(6, 30);
            this.btnSelected.TabIndex = 6;
            this.btnSelected.TextAdjestmentHeight = 0;
            this.btnSelected.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSelected.TopColor = System.Drawing.Color.DodgerBlue;
            // 
            // btnDefault
            // 
            this.btnDefault.BackColor = System.Drawing.Color.Transparent;
            this.btnDefault.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDefault.FlatAppearance.BorderSize = 0;
            this.btnDefault.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnDefault.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDefault.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDefault.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnDefault.ForeColor = System.Drawing.SystemColors.Window;
            this.btnDefault.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDefault.Location = new System.Drawing.Point(1, 86);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(149, 30);
            this.btnDefault.TabIndex = 1;
            this.btnDefault.Text = "   Default";
            this.btnDefault.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDefault.UseVisualStyleBackColor = false;
            this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
            // 
            // btnAccounts
            // 
            this.btnAccounts.BackColor = System.Drawing.Color.White;
            this.btnAccounts.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAccounts.FlatAppearance.BorderSize = 0;
            this.btnAccounts.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnAccounts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAccounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccounts.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnAccounts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(77)))), ((int)(((byte)(125)))));
            this.btnAccounts.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnAccounts.Location = new System.Drawing.Point(1, 51);
            this.btnAccounts.Name = "btnAccounts";
            this.btnAccounts.Size = new System.Drawing.Size(149, 30);
            this.btnAccounts.TabIndex = 146;
            this.btnAccounts.Text = "   Accounts";
            this.btnAccounts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAccounts.UseVisualStyleBackColor = false;
            this.btnAccounts.Click += new System.EventHandler(this.btnAccounts_Click);
            // 
            // btnWhatsAppTemp
            // 
            this.btnWhatsAppTemp.BackColor = System.Drawing.Color.Transparent;
            this.btnWhatsAppTemp.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnWhatsAppTemp.FlatAppearance.BorderSize = 0;
            this.btnWhatsAppTemp.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnWhatsAppTemp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWhatsAppTemp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWhatsAppTemp.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnWhatsAppTemp.ForeColor = System.Drawing.SystemColors.Window;
            this.btnWhatsAppTemp.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnWhatsAppTemp.Location = new System.Drawing.Point(1, 191);
            this.btnWhatsAppTemp.Name = "btnWhatsAppTemp";
            this.btnWhatsAppTemp.Size = new System.Drawing.Size(150, 30);
            this.btnWhatsAppTemp.TabIndex = 149;
            this.btnWhatsAppTemp.Text = "   WhatsApp Template";
            this.btnWhatsAppTemp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWhatsAppTemp.UseVisualStyleBackColor = false;
            this.btnWhatsAppTemp.Visible = false;
            this.btnWhatsAppTemp.Click += new System.EventHandler(this.btnWhatsAppTemp_Click);
            // 
            // btnSMSTemp
            // 
            this.btnSMSTemp.BackColor = System.Drawing.Color.Transparent;
            this.btnSMSTemp.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSMSTemp.FlatAppearance.BorderSize = 0;
            this.btnSMSTemp.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnSMSTemp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSMSTemp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSMSTemp.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSMSTemp.ForeColor = System.Drawing.SystemColors.Window;
            this.btnSMSTemp.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSMSTemp.Location = new System.Drawing.Point(1, 156);
            this.btnSMSTemp.Name = "btnSMSTemp";
            this.btnSMSTemp.Size = new System.Drawing.Size(149, 30);
            this.btnSMSTemp.TabIndex = 148;
            this.btnSMSTemp.Text = "   SMS Template";
            this.btnSMSTemp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSMSTemp.UseVisualStyleBackColor = false;
            this.btnSMSTemp.Click += new System.EventHandler(this.btnSMSTemp_Click);
            // 
            // btnEmailTemp
            // 
            this.btnEmailTemp.BackColor = System.Drawing.Color.Transparent;
            this.btnEmailTemp.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnEmailTemp.FlatAppearance.BorderSize = 0;
            this.btnEmailTemp.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnEmailTemp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnEmailTemp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmailTemp.Font = new System.Drawing.Font("Open Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnEmailTemp.ForeColor = System.Drawing.SystemColors.Window;
            this.btnEmailTemp.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnEmailTemp.Location = new System.Drawing.Point(1, 121);
            this.btnEmailTemp.Name = "btnEmailTemp";
            this.btnEmailTemp.Size = new System.Drawing.Size(149, 30);
            this.btnEmailTemp.TabIndex = 147;
            this.btnEmailTemp.Text = "   Email Template";
            this.btnEmailTemp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmailTemp.UseVisualStyleBackColor = false;
            this.btnEmailTemp.Click += new System.EventHandler(this.btnEmailTemp_Click);
            // 
            // pnlAccounts
            // 
            this.pnlAccounts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlAccounts.BackColor = System.Drawing.SystemColors.Window;
            this.pnlAccounts.Controls.Add(this.lblIGST);
            this.pnlAccounts.Controls.Add(this.lblCGST);
            this.pnlAccounts.Controls.Add(this.cmbIGST);
            this.pnlAccounts.Controls.Add(this.cmbCGST);
            this.pnlAccounts.Controls.Add(this.lblEWallet);
            this.pnlAccounts.Controls.Add(this.lblOnlineBanking);
            this.pnlAccounts.Controls.Add(this.lblDD);
            this.pnlAccounts.Controls.Add(this.lblCheque);
            this.pnlAccounts.Controls.Add(this.lblCreditCard);
            this.pnlAccounts.Controls.Add(this.lblCash);
            this.pnlAccounts.Controls.Add(this.cmbEWallet);
            this.pnlAccounts.Controls.Add(this.cmbOnlineBanking);
            this.pnlAccounts.Controls.Add(this.cmbCreditCard);
            this.pnlAccounts.Controls.Add(this.cmbDD);
            this.pnlAccounts.Controls.Add(this.cmbCheque);
            this.pnlAccounts.Controls.Add(this.cmbCash);
            this.pnlAccounts.Controls.Add(this.btnSeperator5);
            this.pnlAccounts.Controls.Add(this.lblPayment);
            this.pnlAccounts.Controls.Add(this.lblExciseDuty);
            this.pnlAccounts.Controls.Add(this.lblAdditionalTax);
            this.pnlAccounts.Controls.Add(this.lblTax3);
            this.pnlAccounts.Controls.Add(this.lblDiscount);
            this.pnlAccounts.Controls.Add(this.lblSGST);
            this.pnlAccounts.Controls.Add(this.lblVAT);
            this.pnlAccounts.Controls.Add(this.lblTax2);
            this.pnlAccounts.Controls.Add(this.lblTax1);
            this.pnlAccounts.Controls.Add(this.cmbSGST);
            this.pnlAccounts.Controls.Add(this.cmbVAT);
            this.pnlAccounts.Controls.Add(this.cmbAddlTax);
            this.pnlAccounts.Controls.Add(this.cmbTax3);
            this.pnlAccounts.Controls.Add(this.cmbTax2);
            this.pnlAccounts.Controls.Add(this.cmbTax1);
            this.pnlAccounts.Controls.Add(this.cmbExciseDuty);
            this.pnlAccounts.Controls.Add(this.btnSeperator3);
            this.pnlAccounts.Controls.Add(this.lblCommon);
            this.pnlAccounts.Controls.Add(this.btnSeperator4);
            this.pnlAccounts.Controls.Add(this.cmbDiscountSlab);
            this.pnlAccounts.Controls.Add(this.lblSlabs);
            this.pnlAccounts.Controls.Add(this.lblGuests);
            this.pnlAccounts.Controls.Add(this.lblLaundry);
            this.pnlAccounts.Controls.Add(this.lblDeduction);
            this.pnlAccounts.Controls.Add(this.lblExtras);
            this.pnlAccounts.Controls.Add(this.lblRent);
            this.pnlAccounts.Controls.Add(this.cmbGuests);
            this.pnlAccounts.Controls.Add(this.cmbLaundry);
            this.pnlAccounts.Controls.Add(this.cmbDeduction);
            this.pnlAccounts.Controls.Add(this.cmbExtras);
            this.pnlAccounts.Controls.Add(this.cmbRentAccount);
            this.pnlAccounts.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlAccounts.Location = new System.Drawing.Point(0, 0);
            this.pnlAccounts.Name = "pnlAccounts";
            this.pnlAccounts.Size = new System.Drawing.Size(844, 483);
            this.pnlAccounts.TabIndex = 0;
            // 
            // lblIGST
            // 
            this.lblIGST.AutoSize = true;
            this.lblIGST.Enabled = false;
            this.lblIGST.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblIGST.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblIGST.Location = new System.Drawing.Point(487, 328);
            this.lblIGST.Name = "lblIGST";
            this.lblIGST.RequiredField = false;
            this.lblIGST.Size = new System.Drawing.Size(41, 18);
            this.lblIGST.TabIndex = 185;
            this.lblIGST.Text = "IGST :";
            this.lblIGST.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblCGST
            // 
            this.lblCGST.AutoSize = true;
            this.lblCGST.Enabled = false;
            this.lblCGST.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblCGST.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCGST.Location = new System.Drawing.Point(488, 298);
            this.lblCGST.Name = "lblCGST";
            this.lblCGST.RequiredField = false;
            this.lblCGST.Size = new System.Drawing.Size(45, 18);
            this.lblCGST.TabIndex = 184;
            this.lblCGST.Text = "CGST :";
            this.lblCGST.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbIGST
            // 
            this.cmbIGST.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbIGST.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbIGST.DropDownHeight = 300;
            this.cmbIGST.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIGST.Enabled = false;
            this.cmbIGST.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbIGST.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbIGST.FormattingEnabled = true;
            this.cmbIGST.IntegralHeight = false;
            this.cmbIGST.Location = new System.Drawing.Point(538, 325);
            this.cmbIGST.Name = "cmbIGST";
            this.cmbIGST.Size = new System.Drawing.Size(300, 26);
            this.cmbIGST.TabIndex = 20;
            // 
            // cmbCGST
            // 
            this.cmbCGST.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCGST.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCGST.DropDownHeight = 300;
            this.cmbCGST.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCGST.Enabled = false;
            this.cmbCGST.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCGST.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbCGST.FormattingEnabled = true;
            this.cmbCGST.IntegralHeight = false;
            this.cmbCGST.Location = new System.Drawing.Point(538, 295);
            this.cmbCGST.Name = "cmbCGST";
            this.cmbCGST.Size = new System.Drawing.Size(300, 26);
            this.cmbCGST.TabIndex = 19;
            // 
            // lblEWallet
            // 
            this.lblEWallet.AutoSize = true;
            this.lblEWallet.Location = new System.Drawing.Point(58, 397);
            this.lblEWallet.Name = "lblEWallet";
            this.lblEWallet.RequiredField = false;
            this.lblEWallet.Size = new System.Drawing.Size(58, 18);
            this.lblEWallet.TabIndex = 181;
            this.lblEWallet.Text = "EWallet :";
            // 
            // lblOnlineBanking
            // 
            this.lblOnlineBanking.AutoSize = true;
            this.lblOnlineBanking.Location = new System.Drawing.Point(12, 367);
            this.lblOnlineBanking.Name = "lblOnlineBanking";
            this.lblOnlineBanking.RequiredField = false;
            this.lblOnlineBanking.Size = new System.Drawing.Size(104, 18);
            this.lblOnlineBanking.TabIndex = 180;
            this.lblOnlineBanking.Text = "Online Banking :";
            // 
            // lblDD
            // 
            this.lblDD.AutoSize = true;
            this.lblDD.Location = new System.Drawing.Point(84, 340);
            this.lblDD.Name = "lblDD";
            this.lblDD.RequiredField = false;
            this.lblDD.Size = new System.Drawing.Size(32, 18);
            this.lblDD.TabIndex = 179;
            this.lblDD.Text = "DD :";
            // 
            // lblCheque
            // 
            this.lblCheque.AutoSize = true;
            this.lblCheque.Location = new System.Drawing.Point(56, 310);
            this.lblCheque.Name = "lblCheque";
            this.lblCheque.RequiredField = false;
            this.lblCheque.Size = new System.Drawing.Size(60, 18);
            this.lblCheque.TabIndex = 178;
            this.lblCheque.Text = "Cheque :";
            // 
            // lblCreditCard
            // 
            this.lblCreditCard.AutoSize = true;
            this.lblCreditCard.Location = new System.Drawing.Point(35, 280);
            this.lblCreditCard.Name = "lblCreditCard";
            this.lblCreditCard.RequiredField = false;
            this.lblCreditCard.Size = new System.Drawing.Size(81, 18);
            this.lblCreditCard.TabIndex = 177;
            this.lblCreditCard.Text = "Credit Card :";
            // 
            // lblCash
            // 
            this.lblCash.AutoSize = true;
            this.lblCash.Location = new System.Drawing.Point(73, 250);
            this.lblCash.Name = "lblCash";
            this.lblCash.RequiredField = false;
            this.lblCash.Size = new System.Drawing.Size(43, 18);
            this.lblCash.TabIndex = 176;
            this.lblCash.Text = "Cash :";
            // 
            // cmbEWallet
            // 
            this.cmbEWallet.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEWallet.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEWallet.DropDownHeight = 300;
            this.cmbEWallet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEWallet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbEWallet.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbEWallet.FormattingEnabled = true;
            this.cmbEWallet.IntegralHeight = false;
            this.cmbEWallet.Location = new System.Drawing.Point(122, 394);
            this.cmbEWallet.Name = "cmbEWallet";
            this.cmbEWallet.Size = new System.Drawing.Size(300, 26);
            this.cmbEWallet.TabIndex = 10;
            // 
            // cmbOnlineBanking
            // 
            this.cmbOnlineBanking.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbOnlineBanking.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbOnlineBanking.DropDownHeight = 300;
            this.cmbOnlineBanking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOnlineBanking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbOnlineBanking.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbOnlineBanking.FormattingEnabled = true;
            this.cmbOnlineBanking.IntegralHeight = false;
            this.cmbOnlineBanking.Location = new System.Drawing.Point(122, 364);
            this.cmbOnlineBanking.Name = "cmbOnlineBanking";
            this.cmbOnlineBanking.Size = new System.Drawing.Size(300, 26);
            this.cmbOnlineBanking.TabIndex = 9;
            // 
            // cmbCreditCard
            // 
            this.cmbCreditCard.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCreditCard.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCreditCard.DropDownHeight = 300;
            this.cmbCreditCard.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCreditCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCreditCard.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbCreditCard.FormattingEnabled = true;
            this.cmbCreditCard.IntegralHeight = false;
            this.cmbCreditCard.Location = new System.Drawing.Point(122, 277);
            this.cmbCreditCard.Name = "cmbCreditCard";
            this.cmbCreditCard.Size = new System.Drawing.Size(300, 26);
            this.cmbCreditCard.TabIndex = 6;
            // 
            // cmbDD
            // 
            this.cmbDD.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbDD.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDD.DropDownHeight = 300;
            this.cmbDD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDD.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbDD.FormattingEnabled = true;
            this.cmbDD.IntegralHeight = false;
            this.cmbDD.Location = new System.Drawing.Point(122, 337);
            this.cmbDD.Name = "cmbDD";
            this.cmbDD.Size = new System.Drawing.Size(300, 26);
            this.cmbDD.TabIndex = 8;
            // 
            // cmbCheque
            // 
            this.cmbCheque.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCheque.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCheque.DropDownHeight = 300;
            this.cmbCheque.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCheque.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCheque.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbCheque.FormattingEnabled = true;
            this.cmbCheque.IntegralHeight = false;
            this.cmbCheque.Location = new System.Drawing.Point(122, 307);
            this.cmbCheque.Name = "cmbCheque";
            this.cmbCheque.Size = new System.Drawing.Size(300, 26);
            this.cmbCheque.TabIndex = 7;
            // 
            // cmbCash
            // 
            this.cmbCash.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCash.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCash.DropDownHeight = 300;
            this.cmbCash.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCash.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCash.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbCash.FormattingEnabled = true;
            this.cmbCash.IntegralHeight = false;
            this.cmbCash.Location = new System.Drawing.Point(122, 247);
            this.cmbCash.Name = "cmbCash";
            this.cmbCash.Size = new System.Drawing.Size(300, 26);
            this.cmbCash.TabIndex = 5;
            // 
            // btnSeperator5
            // 
            this.btnSeperator5.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator5.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator5.FlatAppearance.BorderSize = 0;
            this.btnSeperator5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator5.Location = new System.Drawing.Point(17, 238);
            this.btnSeperator5.Name = "btnSeperator5";
            this.btnSeperator5.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator5.TabIndex = 169;
            this.btnSeperator5.UseVisualStyleBackColor = false;
            // 
            // lblPayment
            // 
            this.lblPayment.AutoSize = true;
            this.lblPayment.BackColor = System.Drawing.Color.Transparent;
            this.lblPayment.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblPayment.ForeColor = System.Drawing.Color.Black;
            this.lblPayment.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblPayment.Location = new System.Drawing.Point(20, 213);
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.RequiredField = false;
            this.lblPayment.Size = new System.Drawing.Size(82, 22);
            this.lblPayment.TabIndex = 168;
            this.lblPayment.Text = "Payment";
            // 
            // lblExciseDuty
            // 
            this.lblExciseDuty.AutoSize = true;
            this.lblExciseDuty.Enabled = false;
            this.lblExciseDuty.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblExciseDuty.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblExciseDuty.Location = new System.Drawing.Point(450, 88);
            this.lblExciseDuty.Name = "lblExciseDuty";
            this.lblExciseDuty.RequiredField = false;
            this.lblExciseDuty.Size = new System.Drawing.Size(82, 18);
            this.lblExciseDuty.TabIndex = 164;
            this.lblExciseDuty.Text = "Excise Duty :";
            this.lblExciseDuty.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAdditionalTax
            // 
            this.lblAdditionalTax.AutoSize = true;
            this.lblAdditionalTax.Enabled = false;
            this.lblAdditionalTax.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblAdditionalTax.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblAdditionalTax.Location = new System.Drawing.Point(433, 208);
            this.lblAdditionalTax.Name = "lblAdditionalTax";
            this.lblAdditionalTax.RequiredField = false;
            this.lblAdditionalTax.Size = new System.Drawing.Size(99, 18);
            this.lblAdditionalTax.TabIndex = 167;
            this.lblAdditionalTax.Text = "Additional Tax :";
            this.lblAdditionalTax.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTax3
            // 
            this.lblTax3.AutoSize = true;
            this.lblTax3.Enabled = false;
            this.lblTax3.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblTax3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTax3.Location = new System.Drawing.Point(487, 178);
            this.lblTax3.Name = "lblTax3";
            this.lblTax3.RequiredField = false;
            this.lblTax3.Size = new System.Drawing.Size(45, 18);
            this.lblTax3.TabIndex = 166;
            this.lblTax3.Text = "Tax 3 :";
            this.lblTax3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblDiscount
            // 
            this.lblDiscount.AutoSize = true;
            this.lblDiscount.Enabled = false;
            this.lblDiscount.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblDiscount.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDiscount.Location = new System.Drawing.Point(465, 58);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.RequiredField = false;
            this.lblDiscount.Size = new System.Drawing.Size(67, 18);
            this.lblDiscount.TabIndex = 162;
            this.lblDiscount.Text = "Discount :";
            this.lblDiscount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSGST
            // 
            this.lblSGST.AutoSize = true;
            this.lblSGST.Enabled = false;
            this.lblSGST.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblSGST.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSGST.Location = new System.Drawing.Point(488, 268);
            this.lblSGST.Name = "lblSGST";
            this.lblSGST.RequiredField = false;
            this.lblSGST.Size = new System.Drawing.Size(44, 18);
            this.lblSGST.TabIndex = 161;
            this.lblSGST.Text = "SGST :";
            this.lblSGST.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblVAT
            // 
            this.lblVAT.AutoSize = true;
            this.lblVAT.Enabled = false;
            this.lblVAT.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblVAT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblVAT.Location = new System.Drawing.Point(495, 239);
            this.lblVAT.Name = "lblVAT";
            this.lblVAT.RequiredField = false;
            this.lblVAT.Size = new System.Drawing.Size(37, 18);
            this.lblVAT.TabIndex = 160;
            this.lblVAT.Text = "VAT :";
            this.lblVAT.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTax2
            // 
            this.lblTax2.AutoSize = true;
            this.lblTax2.Enabled = false;
            this.lblTax2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblTax2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTax2.Location = new System.Drawing.Point(487, 148);
            this.lblTax2.Name = "lblTax2";
            this.lblTax2.RequiredField = false;
            this.lblTax2.Size = new System.Drawing.Size(45, 18);
            this.lblTax2.TabIndex = 165;
            this.lblTax2.Text = "Tax 2 :";
            this.lblTax2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTax1
            // 
            this.lblTax1.AutoSize = true;
            this.lblTax1.Enabled = false;
            this.lblTax1.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lblTax1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTax1.Location = new System.Drawing.Point(487, 118);
            this.lblTax1.Name = "lblTax1";
            this.lblTax1.RequiredField = false;
            this.lblTax1.Size = new System.Drawing.Size(45, 18);
            this.lblTax1.TabIndex = 163;
            this.lblTax1.Text = "Tax 1 :";
            this.lblTax1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbSGST
            // 
            this.cmbSGST.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSGST.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSGST.DropDownHeight = 300;
            this.cmbSGST.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSGST.Enabled = false;
            this.cmbSGST.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSGST.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbSGST.FormattingEnabled = true;
            this.cmbSGST.IntegralHeight = false;
            this.cmbSGST.Location = new System.Drawing.Point(538, 265);
            this.cmbSGST.Name = "cmbSGST";
            this.cmbSGST.Size = new System.Drawing.Size(300, 26);
            this.cmbSGST.TabIndex = 18;
            // 
            // cmbVAT
            // 
            this.cmbVAT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbVAT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVAT.DropDownHeight = 300;
            this.cmbVAT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVAT.Enabled = false;
            this.cmbVAT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbVAT.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbVAT.FormattingEnabled = true;
            this.cmbVAT.IntegralHeight = false;
            this.cmbVAT.Location = new System.Drawing.Point(538, 235);
            this.cmbVAT.Name = "cmbVAT";
            this.cmbVAT.Size = new System.Drawing.Size(300, 26);
            this.cmbVAT.TabIndex = 17;
            // 
            // cmbAddlTax
            // 
            this.cmbAddlTax.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAddlTax.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAddlTax.DropDownHeight = 300;
            this.cmbAddlTax.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddlTax.Enabled = false;
            this.cmbAddlTax.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbAddlTax.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbAddlTax.FormattingEnabled = true;
            this.cmbAddlTax.IntegralHeight = false;
            this.cmbAddlTax.Location = new System.Drawing.Point(538, 205);
            this.cmbAddlTax.Name = "cmbAddlTax";
            this.cmbAddlTax.Size = new System.Drawing.Size(300, 26);
            this.cmbAddlTax.TabIndex = 16;
            // 
            // cmbTax3
            // 
            this.cmbTax3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax3.DropDownHeight = 300;
            this.cmbTax3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTax3.Enabled = false;
            this.cmbTax3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTax3.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbTax3.FormattingEnabled = true;
            this.cmbTax3.IntegralHeight = false;
            this.cmbTax3.Location = new System.Drawing.Point(538, 175);
            this.cmbTax3.Name = "cmbTax3";
            this.cmbTax3.Size = new System.Drawing.Size(300, 26);
            this.cmbTax3.TabIndex = 15;
            // 
            // cmbTax2
            // 
            this.cmbTax2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax2.DropDownHeight = 300;
            this.cmbTax2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTax2.Enabled = false;
            this.cmbTax2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTax2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbTax2.FormattingEnabled = true;
            this.cmbTax2.IntegralHeight = false;
            this.cmbTax2.Location = new System.Drawing.Point(538, 145);
            this.cmbTax2.Name = "cmbTax2";
            this.cmbTax2.Size = new System.Drawing.Size(300, 26);
            this.cmbTax2.TabIndex = 14;
            // 
            // cmbTax1
            // 
            this.cmbTax1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTax1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTax1.DropDownHeight = 300;
            this.cmbTax1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTax1.Enabled = false;
            this.cmbTax1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTax1.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbTax1.FormattingEnabled = true;
            this.cmbTax1.IntegralHeight = false;
            this.cmbTax1.Location = new System.Drawing.Point(538, 115);
            this.cmbTax1.Name = "cmbTax1";
            this.cmbTax1.Size = new System.Drawing.Size(300, 26);
            this.cmbTax1.TabIndex = 13;
            // 
            // cmbExciseDuty
            // 
            this.cmbExciseDuty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbExciseDuty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbExciseDuty.DropDownHeight = 300;
            this.cmbExciseDuty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbExciseDuty.Enabled = false;
            this.cmbExciseDuty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbExciseDuty.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbExciseDuty.FormattingEnabled = true;
            this.cmbExciseDuty.IntegralHeight = false;
            this.cmbExciseDuty.Location = new System.Drawing.Point(538, 85);
            this.cmbExciseDuty.Name = "cmbExciseDuty";
            this.cmbExciseDuty.Size = new System.Drawing.Size(300, 26);
            this.cmbExciseDuty.TabIndex = 12;
            // 
            // btnSeperator3
            // 
            this.btnSeperator3.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator3.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator3.FlatAppearance.BorderSize = 0;
            this.btnSeperator3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator3.Location = new System.Drawing.Point(4, 37);
            this.btnSeperator3.Name = "btnSeperator3";
            this.btnSeperator3.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator3.TabIndex = 151;
            this.btnSeperator3.UseVisualStyleBackColor = false;
            // 
            // lblCommon
            // 
            this.lblCommon.AutoSize = true;
            this.lblCommon.BackColor = System.Drawing.Color.Transparent;
            this.lblCommon.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblCommon.ForeColor = System.Drawing.Color.Black;
            this.lblCommon.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCommon.Location = new System.Drawing.Point(7, 12);
            this.lblCommon.Name = "lblCommon";
            this.lblCommon.RequiredField = false;
            this.lblCommon.Size = new System.Drawing.Size(83, 22);
            this.lblCommon.TabIndex = 150;
            this.lblCommon.Text = "Common";
            // 
            // btnSeperator4
            // 
            this.btnSeperator4.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator4.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator4.FlatAppearance.BorderSize = 0;
            this.btnSeperator4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator4.Location = new System.Drawing.Point(438, 41);
            this.btnSeperator4.Name = "btnSeperator4";
            this.btnSeperator4.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator4.TabIndex = 149;
            this.btnSeperator4.UseVisualStyleBackColor = false;
            // 
            // cmbDiscountSlab
            // 
            this.cmbDiscountSlab.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbDiscountSlab.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDiscountSlab.DropDownHeight = 300;
            this.cmbDiscountSlab.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDiscountSlab.Enabled = false;
            this.cmbDiscountSlab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDiscountSlab.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbDiscountSlab.FormattingEnabled = true;
            this.cmbDiscountSlab.IntegralHeight = false;
            this.cmbDiscountSlab.Location = new System.Drawing.Point(538, 55);
            this.cmbDiscountSlab.Name = "cmbDiscountSlab";
            this.cmbDiscountSlab.Size = new System.Drawing.Size(300, 26);
            this.cmbDiscountSlab.TabIndex = 11;
            // 
            // lblSlabs
            // 
            this.lblSlabs.AutoSize = true;
            this.lblSlabs.BackColor = System.Drawing.Color.Transparent;
            this.lblSlabs.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblSlabs.ForeColor = System.Drawing.Color.Black;
            this.lblSlabs.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSlabs.Location = new System.Drawing.Point(441, 16);
            this.lblSlabs.Name = "lblSlabs";
            this.lblSlabs.RequiredField = false;
            this.lblSlabs.Size = new System.Drawing.Size(52, 22);
            this.lblSlabs.TabIndex = 148;
            this.lblSlabs.Text = "Slabs";
            // 
            // lblGuests
            // 
            this.lblGuests.AutoSize = true;
            this.lblGuests.Location = new System.Drawing.Point(67, 169);
            this.lblGuests.Name = "lblGuests";
            this.lblGuests.RequiredField = false;
            this.lblGuests.Size = new System.Drawing.Size(49, 18);
            this.lblGuests.TabIndex = 20;
            this.lblGuests.Text = "Guest :";
            // 
            // lblLaundry
            // 
            this.lblLaundry.AutoSize = true;
            this.lblLaundry.Location = new System.Drawing.Point(52, 139);
            this.lblLaundry.Name = "lblLaundry";
            this.lblLaundry.RequiredField = false;
            this.lblLaundry.Size = new System.Drawing.Size(64, 18);
            this.lblLaundry.TabIndex = 19;
            this.lblLaundry.Text = "Laundry :";
            // 
            // lblDeduction
            // 
            this.lblDeduction.AutoSize = true;
            this.lblDeduction.Location = new System.Drawing.Point(40, 109);
            this.lblDeduction.Name = "lblDeduction";
            this.lblDeduction.RequiredField = false;
            this.lblDeduction.Size = new System.Drawing.Size(76, 18);
            this.lblDeduction.TabIndex = 18;
            this.lblDeduction.Text = "Deduction :";
            // 
            // lblExtras
            // 
            this.lblExtras.AutoSize = true;
            this.lblExtras.Location = new System.Drawing.Point(20, 79);
            this.lblExtras.Name = "lblExtras";
            this.lblExtras.RequiredField = false;
            this.lblExtras.Size = new System.Drawing.Size(96, 18);
            this.lblExtras.TabIndex = 17;
            this.lblExtras.Text = "Extra Services :";
            // 
            // lblRent
            // 
            this.lblRent.AutoSize = true;
            this.lblRent.Location = new System.Drawing.Point(74, 49);
            this.lblRent.Name = "lblRent";
            this.lblRent.RequiredField = false;
            this.lblRent.Size = new System.Drawing.Size(42, 18);
            this.lblRent.TabIndex = 16;
            this.lblRent.Text = "Rent :";
            // 
            // cmbGuests
            // 
            this.cmbGuests.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGuests.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGuests.DropDownHeight = 300;
            this.cmbGuests.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGuests.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbGuests.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbGuests.FormattingEnabled = true;
            this.cmbGuests.IntegralHeight = false;
            this.cmbGuests.Location = new System.Drawing.Point(122, 166);
            this.cmbGuests.Name = "cmbGuests";
            this.cmbGuests.Size = new System.Drawing.Size(300, 26);
            this.cmbGuests.TabIndex = 4;
            // 
            // cmbLaundry
            // 
            this.cmbLaundry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbLaundry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLaundry.DropDownHeight = 300;
            this.cmbLaundry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLaundry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbLaundry.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbLaundry.FormattingEnabled = true;
            this.cmbLaundry.IntegralHeight = false;
            this.cmbLaundry.Location = new System.Drawing.Point(122, 136);
            this.cmbLaundry.Name = "cmbLaundry";
            this.cmbLaundry.Size = new System.Drawing.Size(300, 26);
            this.cmbLaundry.TabIndex = 3;
            // 
            // cmbDeduction
            // 
            this.cmbDeduction.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbDeduction.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDeduction.DropDownHeight = 300;
            this.cmbDeduction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDeduction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDeduction.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbDeduction.FormattingEnabled = true;
            this.cmbDeduction.IntegralHeight = false;
            this.cmbDeduction.Location = new System.Drawing.Point(122, 106);
            this.cmbDeduction.Name = "cmbDeduction";
            this.cmbDeduction.Size = new System.Drawing.Size(300, 26);
            this.cmbDeduction.TabIndex = 2;
            // 
            // cmbExtras
            // 
            this.cmbExtras.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbExtras.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbExtras.DropDownHeight = 300;
            this.cmbExtras.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbExtras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbExtras.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbExtras.FormattingEnabled = true;
            this.cmbExtras.IntegralHeight = false;
            this.cmbExtras.Location = new System.Drawing.Point(122, 76);
            this.cmbExtras.Name = "cmbExtras";
            this.cmbExtras.Size = new System.Drawing.Size(300, 26);
            this.cmbExtras.TabIndex = 1;
            // 
            // cmbRentAccount
            // 
            this.cmbRentAccount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRentAccount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRentAccount.DropDownHeight = 300;
            this.cmbRentAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRentAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbRentAccount.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.cmbRentAccount.FormattingEnabled = true;
            this.cmbRentAccount.IntegralHeight = false;
            this.cmbRentAccount.Location = new System.Drawing.Point(122, 46);
            this.cmbRentAccount.Name = "cmbRentAccount";
            this.cmbRentAccount.Size = new System.Drawing.Size(300, 26);
            this.cmbRentAccount.TabIndex = 0;
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.BackColor = System.Drawing.SystemColors.Window;
            this.pnlMain.Controls.Add(this.TabSettings);
            this.pnlMain.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(153, 40);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(844, 484);
            this.pnlMain.TabIndex = 0;
            // 
            // TabSettings
            // 
            this.TabSettings.Controls.Add(this.tabAccounts);
            this.TabSettings.Controls.Add(this.tabDefault);
            this.TabSettings.Controls.Add(this.tabEmailTemplate);
            this.TabSettings.Controls.Add(this.tabSMS);
            this.TabSettings.Controls.Add(this.tabWhatsApp);
            this.TabSettings.Location = new System.Drawing.Point(-4, -27);
            this.TabSettings.Name = "TabSettings";
            this.TabSettings.SelectedIndex = 0;
            this.TabSettings.Size = new System.Drawing.Size(852, 514);
            this.TabSettings.TabIndex = 0;
            // 
            // tabAccounts
            // 
            this.tabAccounts.BackColor = System.Drawing.SystemColors.Window;
            this.tabAccounts.Controls.Add(this.pnlAccounts);
            this.tabAccounts.Location = new System.Drawing.Point(4, 27);
            this.tabAccounts.Name = "tabAccounts";
            this.tabAccounts.Padding = new System.Windows.Forms.Padding(3);
            this.tabAccounts.Size = new System.Drawing.Size(844, 483);
            this.tabAccounts.TabIndex = 0;
            this.tabAccounts.Text = "Accounts";
            // 
            // tabDefault
            // 
            this.tabDefault.BackColor = System.Drawing.SystemColors.Window;
            this.tabDefault.Controls.Add(this.grpRoomOraHallUserfields);
            this.tabDefault.Controls.Add(this.grpStatusColor);
            this.tabDefault.Controls.Add(this.grpUserWise);
            this.tabDefault.Controls.Add(this.grpOperational);
            this.tabDefault.Location = new System.Drawing.Point(4, 27);
            this.tabDefault.Name = "tabDefault";
            this.tabDefault.Padding = new System.Windows.Forms.Padding(3);
            this.tabDefault.Size = new System.Drawing.Size(844, 483);
            this.tabDefault.TabIndex = 1;
            this.tabDefault.Text = "Default";
            // 
            // grpRoomOraHallUserfields
            // 
            this.grpRoomOraHallUserfields.BackColor = System.Drawing.Color.Transparent;
            this.grpRoomOraHallUserfields.Controls.Add(this.lblHallCap);
            this.grpRoomOraHallUserfields.Controls.Add(this.lblRoomCap);
            this.grpRoomOraHallUserfields.Controls.Add(this.lblUserFiled1);
            this.grpRoomOraHallUserfields.Controls.Add(this.lblUserFiled4);
            this.grpRoomOraHallUserfields.Controls.Add(this.lblUserFiled2);
            this.grpRoomOraHallUserfields.Controls.Add(this.lblUserFiled3);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtRoomUserField4);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtRoomUserField3);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtRoomUserField2);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtRoomUserField1);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtHallUserField4);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtHallUserField3);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtHallUserField2);
            this.grpRoomOraHallUserfields.Controls.Add(this.txtHallUserField1);
            this.grpRoomOraHallUserfields.Location = new System.Drawing.Point(364, 2);
            this.grpRoomOraHallUserfields.Name = "grpRoomOraHallUserfields";
            this.grpRoomOraHallUserfields.Size = new System.Drawing.Size(474, 151);
            this.grpRoomOraHallUserfields.TabIndex = 10;
            this.grpRoomOraHallUserfields.TabStop = false;
            this.grpRoomOraHallUserfields.Text = "Room / Hall UserFields";
            // 
            // lblHallCap
            // 
            this.lblHallCap.AutoSize = true;
            this.lblHallCap.Location = new System.Drawing.Point(359, 13);
            this.lblHallCap.Name = "lblHallCap";
            this.lblHallCap.RequiredField = false;
            this.lblHallCap.Size = new System.Drawing.Size(31, 18);
            this.lblHallCap.TabIndex = 191;
            this.lblHallCap.Text = "Hall";
            // 
            // lblRoomCap
            // 
            this.lblRoomCap.AutoSize = true;
            this.lblRoomCap.Location = new System.Drawing.Point(174, 14);
            this.lblRoomCap.Name = "lblRoomCap";
            this.lblRoomCap.RequiredField = false;
            this.lblRoomCap.Size = new System.Drawing.Size(44, 18);
            this.lblRoomCap.TabIndex = 190;
            this.lblRoomCap.Text = "Room";
            // 
            // lblUserFiled1
            // 
            this.lblUserFiled1.AutoSize = true;
            this.lblUserFiled1.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.errProvider.SetIconAlignment(this.lblUserFiled1, System.Windows.Forms.ErrorIconAlignment.TopLeft);
            this.lblUserFiled1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblUserFiled1.Location = new System.Drawing.Point(40, 44);
            this.lblUserFiled1.Name = "lblUserFiled1";
            this.lblUserFiled1.RequiredField = false;
            this.lblUserFiled1.Size = new System.Drawing.Size(82, 18);
            this.lblUserFiled1.TabIndex = 186;
            this.lblUserFiled1.Text = "User Field 1 :";
            this.lblUserFiled1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblUserFiled4
            // 
            this.lblUserFiled4.AutoSize = true;
            this.lblUserFiled4.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.errProvider.SetIconAlignment(this.lblUserFiled4, System.Windows.Forms.ErrorIconAlignment.TopLeft);
            this.lblUserFiled4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblUserFiled4.Location = new System.Drawing.Point(40, 125);
            this.lblUserFiled4.Name = "lblUserFiled4";
            this.lblUserFiled4.RequiredField = false;
            this.lblUserFiled4.Size = new System.Drawing.Size(82, 18);
            this.lblUserFiled4.TabIndex = 189;
            this.lblUserFiled4.Text = "User Field 4 :";
            this.lblUserFiled4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblUserFiled2
            // 
            this.lblUserFiled2.AutoSize = true;
            this.lblUserFiled2.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.errProvider.SetIconAlignment(this.lblUserFiled2, System.Windows.Forms.ErrorIconAlignment.TopLeft);
            this.lblUserFiled2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblUserFiled2.Location = new System.Drawing.Point(40, 71);
            this.lblUserFiled2.Name = "lblUserFiled2";
            this.lblUserFiled2.RequiredField = false;
            this.lblUserFiled2.Size = new System.Drawing.Size(82, 18);
            this.lblUserFiled2.TabIndex = 187;
            this.lblUserFiled2.Text = "User Field 2 :";
            this.lblUserFiled2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblUserFiled3
            // 
            this.lblUserFiled3.AutoSize = true;
            this.lblUserFiled3.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.errProvider.SetIconAlignment(this.lblUserFiled3, System.Windows.Forms.ErrorIconAlignment.TopLeft);
            this.lblUserFiled3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblUserFiled3.Location = new System.Drawing.Point(40, 98);
            this.lblUserFiled3.Name = "lblUserFiled3";
            this.lblUserFiled3.RequiredField = false;
            this.lblUserFiled3.Size = new System.Drawing.Size(82, 18);
            this.lblUserFiled3.TabIndex = 188;
            this.lblUserFiled3.Text = "User Field 3 :";
            this.lblUserFiled3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtRoomUserField4
            // 
            this.txtRoomUserField4.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoomUserField4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoomUserField4.Format = null;
            this.txtRoomUserField4.isAllowNegative = false;
            this.txtRoomUserField4.isAllowSpecialChar = false;
            this.txtRoomUserField4.isNumbersOnly = false;
            this.txtRoomUserField4.isNumeric = false;
            this.txtRoomUserField4.isTouchable = false;
            this.txtRoomUserField4.Location = new System.Drawing.Point(128, 125);
            this.txtRoomUserField4.Name = "txtRoomUserField4";
            this.txtRoomUserField4.Size = new System.Drawing.Size(150, 18);
            this.txtRoomUserField4.TabIndex = 7;
            this.txtRoomUserField4.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoomUserField4.WaterMark = null;
            // 
            // txtRoomUserField3
            // 
            this.txtRoomUserField3.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoomUserField3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoomUserField3.Format = null;
            this.txtRoomUserField3.isAllowNegative = false;
            this.txtRoomUserField3.isAllowSpecialChar = false;
            this.txtRoomUserField3.isNumbersOnly = false;
            this.txtRoomUserField3.isNumeric = false;
            this.txtRoomUserField3.isTouchable = false;
            this.txtRoomUserField3.Location = new System.Drawing.Point(128, 98);
            this.txtRoomUserField3.Name = "txtRoomUserField3";
            this.txtRoomUserField3.Size = new System.Drawing.Size(150, 18);
            this.txtRoomUserField3.TabIndex = 6;
            this.txtRoomUserField3.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoomUserField3.WaterMark = null;
            // 
            // txtRoomUserField2
            // 
            this.txtRoomUserField2.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoomUserField2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoomUserField2.Format = null;
            this.txtRoomUserField2.isAllowNegative = false;
            this.txtRoomUserField2.isAllowSpecialChar = false;
            this.txtRoomUserField2.isNumbersOnly = false;
            this.txtRoomUserField2.isNumeric = false;
            this.txtRoomUserField2.isTouchable = false;
            this.txtRoomUserField2.Location = new System.Drawing.Point(128, 71);
            this.txtRoomUserField2.Name = "txtRoomUserField2";
            this.txtRoomUserField2.Size = new System.Drawing.Size(150, 18);
            this.txtRoomUserField2.TabIndex = 5;
            this.txtRoomUserField2.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoomUserField2.WaterMark = null;
            // 
            // txtRoomUserField1
            // 
            this.txtRoomUserField1.BackColor = System.Drawing.SystemColors.Window;
            this.txtRoomUserField1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRoomUserField1.Format = null;
            this.txtRoomUserField1.isAllowNegative = false;
            this.txtRoomUserField1.isAllowSpecialChar = false;
            this.txtRoomUserField1.isNumbersOnly = false;
            this.txtRoomUserField1.isNumeric = false;
            this.txtRoomUserField1.isTouchable = false;
            this.txtRoomUserField1.Location = new System.Drawing.Point(128, 44);
            this.txtRoomUserField1.Name = "txtRoomUserField1";
            this.txtRoomUserField1.Size = new System.Drawing.Size(150, 18);
            this.txtRoomUserField1.TabIndex = 4;
            this.txtRoomUserField1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtRoomUserField1.WaterMark = null;
            // 
            // txtHallUserField4
            // 
            this.txtHallUserField4.BackColor = System.Drawing.SystemColors.Window;
            this.txtHallUserField4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHallUserField4.Format = null;
            this.txtHallUserField4.isAllowNegative = false;
            this.txtHallUserField4.isAllowSpecialChar = false;
            this.txtHallUserField4.isNumbersOnly = false;
            this.txtHallUserField4.isNumeric = false;
            this.txtHallUserField4.isTouchable = false;
            this.txtHallUserField4.Location = new System.Drawing.Point(305, 125);
            this.txtHallUserField4.Name = "txtHallUserField4";
            this.txtHallUserField4.Size = new System.Drawing.Size(150, 18);
            this.txtHallUserField4.TabIndex = 3;
            this.txtHallUserField4.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtHallUserField4.WaterMark = null;
            // 
            // txtHallUserField3
            // 
            this.txtHallUserField3.BackColor = System.Drawing.SystemColors.Window;
            this.txtHallUserField3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHallUserField3.Format = null;
            this.txtHallUserField3.isAllowNegative = false;
            this.txtHallUserField3.isAllowSpecialChar = false;
            this.txtHallUserField3.isNumbersOnly = false;
            this.txtHallUserField3.isNumeric = false;
            this.txtHallUserField3.isTouchable = false;
            this.txtHallUserField3.Location = new System.Drawing.Point(305, 98);
            this.txtHallUserField3.Name = "txtHallUserField3";
            this.txtHallUserField3.Size = new System.Drawing.Size(150, 18);
            this.txtHallUserField3.TabIndex = 2;
            this.txtHallUserField3.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtHallUserField3.WaterMark = null;
            // 
            // txtHallUserField2
            // 
            this.txtHallUserField2.BackColor = System.Drawing.SystemColors.Window;
            this.txtHallUserField2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHallUserField2.Format = null;
            this.txtHallUserField2.isAllowNegative = false;
            this.txtHallUserField2.isAllowSpecialChar = false;
            this.txtHallUserField2.isNumbersOnly = false;
            this.txtHallUserField2.isNumeric = false;
            this.txtHallUserField2.isTouchable = false;
            this.txtHallUserField2.Location = new System.Drawing.Point(305, 71);
            this.txtHallUserField2.Name = "txtHallUserField2";
            this.txtHallUserField2.Size = new System.Drawing.Size(150, 18);
            this.txtHallUserField2.TabIndex = 1;
            this.txtHallUserField2.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtHallUserField2.WaterMark = null;
            // 
            // txtHallUserField1
            // 
            this.txtHallUserField1.BackColor = System.Drawing.SystemColors.Window;
            this.txtHallUserField1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHallUserField1.Format = null;
            this.txtHallUserField1.isAllowNegative = false;
            this.txtHallUserField1.isAllowSpecialChar = false;
            this.txtHallUserField1.isNumbersOnly = false;
            this.txtHallUserField1.isNumeric = false;
            this.txtHallUserField1.isTouchable = false;
            this.txtHallUserField1.Location = new System.Drawing.Point(305, 44);
            this.txtHallUserField1.Name = "txtHallUserField1";
            this.txtHallUserField1.Size = new System.Drawing.Size(150, 18);
            this.txtHallUserField1.TabIndex = 0;
            this.txtHallUserField1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtHallUserField1.WaterMark = null;
            // 
            // grpStatusColor
            // 
            this.grpStatusColor.BackColor = System.Drawing.Color.Transparent;
            this.grpStatusColor.Controls.Add(this.lblOutofOrder);
            this.grpStatusColor.Controls.Add(this.lblClean);
            this.grpStatusColor.Controls.Add(this.lblDirty);
            this.grpStatusColor.Controls.Add(this.btnColorOutofOrder);
            this.grpStatusColor.Controls.Add(this.btnColorClean);
            this.grpStatusColor.Controls.Add(this.btnColorDirty);
            this.grpStatusColor.Controls.Add(this.lblGrpCheckIn);
            this.grpStatusColor.Controls.Add(this.lblCheckIn);
            this.grpStatusColor.Controls.Add(this.lblGrpBooking);
            this.grpStatusColor.Controls.Add(this.btnColorGrpCheckIn);
            this.grpStatusColor.Controls.Add(this.btnColorCheckIn);
            this.grpStatusColor.Controls.Add(this.btnColorGrpBooking);
            this.grpStatusColor.Controls.Add(this.lblBooking);
            this.grpStatusColor.Controls.Add(this.btnColorBooking);
            this.grpStatusColor.Controls.Add(this.lblAvailable);
            this.grpStatusColor.Controls.Add(this.btnColorAvailable);
            this.grpStatusColor.Location = new System.Drawing.Point(7, 154);
            this.grpStatusColor.Name = "grpStatusColor";
            this.grpStatusColor.Size = new System.Drawing.Size(351, 329);
            this.grpStatusColor.TabIndex = 9;
            this.grpStatusColor.TabStop = false;
            this.grpStatusColor.Text = "Status Color";
            // 
            // lblOutofOrder
            // 
            this.lblOutofOrder.AutoSize = true;
            this.lblOutofOrder.Location = new System.Drawing.Point(28, 239);
            this.lblOutofOrder.Name = "lblOutofOrder";
            this.lblOutofOrder.RequiredField = false;
            this.lblOutofOrder.Size = new System.Drawing.Size(88, 18);
            this.lblOutofOrder.TabIndex = 26;
            this.lblOutofOrder.Text = "Out of order :";
            // 
            // lblClean
            // 
            this.lblClean.AutoSize = true;
            this.lblClean.Location = new System.Drawing.Point(69, 210);
            this.lblClean.Name = "lblClean";
            this.lblClean.RequiredField = false;
            this.lblClean.Size = new System.Drawing.Size(47, 18);
            this.lblClean.TabIndex = 25;
            this.lblClean.Text = "Clean :";
            // 
            // lblDirty
            // 
            this.lblDirty.AutoSize = true;
            this.lblDirty.Location = new System.Drawing.Point(73, 181);
            this.lblDirty.Name = "lblDirty";
            this.lblDirty.RequiredField = false;
            this.lblDirty.Size = new System.Drawing.Size(43, 18);
            this.lblDirty.TabIndex = 24;
            this.lblDirty.Text = "Dirty :";
            // 
            // btnColorOutofOrder
            // 
            this.btnColorOutofOrder.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorOutofOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorOutofOrder.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorOutofOrder.Location = new System.Drawing.Point(122, 237);
            this.btnColorOutofOrder.Name = "btnColorOutofOrder";
            this.btnColorOutofOrder.Size = new System.Drawing.Size(197, 23);
            this.btnColorOutofOrder.TabIndex = 23;
            this.btnColorOutofOrder.TabStop = false;
            this.btnColorOutofOrder.UseVisualStyleBackColor = true;
            this.btnColorOutofOrder.Click += new System.EventHandler(this.btnColorOutofOrder_Click);
            // 
            // btnColorClean
            // 
            this.btnColorClean.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorClean.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorClean.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorClean.Location = new System.Drawing.Point(122, 208);
            this.btnColorClean.Name = "btnColorClean";
            this.btnColorClean.Size = new System.Drawing.Size(197, 23);
            this.btnColorClean.TabIndex = 22;
            this.btnColorClean.TabStop = false;
            this.btnColorClean.UseVisualStyleBackColor = true;
            this.btnColorClean.Click += new System.EventHandler(this.btnColorClean_Click);
            // 
            // btnColorDirty
            // 
            this.btnColorDirty.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorDirty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorDirty.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorDirty.Location = new System.Drawing.Point(122, 179);
            this.btnColorDirty.Name = "btnColorDirty";
            this.btnColorDirty.Size = new System.Drawing.Size(197, 23);
            this.btnColorDirty.TabIndex = 21;
            this.btnColorDirty.TabStop = false;
            this.btnColorDirty.UseVisualStyleBackColor = true;
            this.btnColorDirty.Click += new System.EventHandler(this.btnColorDirty_Click);
            // 
            // lblGrpCheckIn
            // 
            this.lblGrpCheckIn.AutoSize = true;
            this.lblGrpCheckIn.Location = new System.Drawing.Point(10, 152);
            this.lblGrpCheckIn.Name = "lblGrpCheckIn";
            this.lblGrpCheckIn.RequiredField = false;
            this.lblGrpCheckIn.Size = new System.Drawing.Size(106, 18);
            this.lblGrpCheckIn.TabIndex = 16;
            this.lblGrpCheckIn.Text = "Group Check In :";
            // 
            // lblCheckIn
            // 
            this.lblCheckIn.AutoSize = true;
            this.lblCheckIn.Location = new System.Drawing.Point(51, 123);
            this.lblCheckIn.Name = "lblCheckIn";
            this.lblCheckIn.RequiredField = false;
            this.lblCheckIn.Size = new System.Drawing.Size(65, 18);
            this.lblCheckIn.TabIndex = 15;
            this.lblCheckIn.Text = "Check In :";
            // 
            // lblGrpBooking
            // 
            this.lblGrpBooking.AutoSize = true;
            this.lblGrpBooking.Location = new System.Drawing.Point(12, 94);
            this.lblGrpBooking.Name = "lblGrpBooking";
            this.lblGrpBooking.RequiredField = false;
            this.lblGrpBooking.Size = new System.Drawing.Size(104, 18);
            this.lblGrpBooking.TabIndex = 14;
            this.lblGrpBooking.Text = "Group Booking :";
            // 
            // btnColorGrpCheckIn
            // 
            this.btnColorGrpCheckIn.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorGrpCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorGrpCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorGrpCheckIn.Location = new System.Drawing.Point(122, 150);
            this.btnColorGrpCheckIn.Name = "btnColorGrpCheckIn";
            this.btnColorGrpCheckIn.Size = new System.Drawing.Size(197, 23);
            this.btnColorGrpCheckIn.TabIndex = 13;
            this.btnColorGrpCheckIn.TabStop = false;
            this.btnColorGrpCheckIn.UseVisualStyleBackColor = true;
            this.btnColorGrpCheckIn.Click += new System.EventHandler(this.btnColorCheckOut_Click);
            // 
            // btnColorCheckIn
            // 
            this.btnColorCheckIn.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorCheckIn.Location = new System.Drawing.Point(122, 121);
            this.btnColorCheckIn.Name = "btnColorCheckIn";
            this.btnColorCheckIn.Size = new System.Drawing.Size(197, 23);
            this.btnColorCheckIn.TabIndex = 12;
            this.btnColorCheckIn.TabStop = false;
            this.btnColorCheckIn.UseVisualStyleBackColor = true;
            this.btnColorCheckIn.Click += new System.EventHandler(this.btnColorCheckIn_Click);
            // 
            // btnColorGrpBooking
            // 
            this.btnColorGrpBooking.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorGrpBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorGrpBooking.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorGrpBooking.Location = new System.Drawing.Point(122, 92);
            this.btnColorGrpBooking.Name = "btnColorGrpBooking";
            this.btnColorGrpBooking.Size = new System.Drawing.Size(197, 23);
            this.btnColorGrpBooking.TabIndex = 11;
            this.btnColorGrpBooking.TabStop = false;
            this.btnColorGrpBooking.UseVisualStyleBackColor = true;
            this.btnColorGrpBooking.Click += new System.EventHandler(this.btnColorGrpBooking_Click);
            // 
            // lblBooking
            // 
            this.lblBooking.AutoSize = true;
            this.lblBooking.Location = new System.Drawing.Point(53, 65);
            this.lblBooking.Name = "lblBooking";
            this.lblBooking.RequiredField = false;
            this.lblBooking.Size = new System.Drawing.Size(63, 18);
            this.lblBooking.TabIndex = 10;
            this.lblBooking.Text = "Booking :";
            // 
            // btnColorBooking
            // 
            this.btnColorBooking.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorBooking.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorBooking.Location = new System.Drawing.Point(122, 63);
            this.btnColorBooking.Name = "btnColorBooking";
            this.btnColorBooking.Size = new System.Drawing.Size(197, 23);
            this.btnColorBooking.TabIndex = 9;
            this.btnColorBooking.TabStop = false;
            this.btnColorBooking.UseVisualStyleBackColor = true;
            this.btnColorBooking.Click += new System.EventHandler(this.btnColorBooking_Click);
            // 
            // lblAvailable
            // 
            this.lblAvailable.AutoSize = true;
            this.lblAvailable.Location = new System.Drawing.Point(49, 36);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.RequiredField = false;
            this.lblAvailable.Size = new System.Drawing.Size(67, 18);
            this.lblAvailable.TabIndex = 8;
            this.lblAvailable.Text = "Available :";
            // 
            // btnColorAvailable
            // 
            this.btnColorAvailable.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnColorAvailable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorAvailable.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnColorAvailable.Location = new System.Drawing.Point(122, 34);
            this.btnColorAvailable.Name = "btnColorAvailable";
            this.btnColorAvailable.Size = new System.Drawing.Size(197, 23);
            this.btnColorAvailable.TabIndex = 7;
            this.btnColorAvailable.TabStop = false;
            this.btnColorAvailable.UseVisualStyleBackColor = true;
            this.btnColorAvailable.Click += new System.EventHandler(this.btnColorAvailable_Click);
            // 
            // grpUserWise
            // 
            this.grpUserWise.BackColor = System.Drawing.Color.Transparent;
            this.grpUserWise.Controls.Add(this.lstLoginSettings);
            this.grpUserWise.Location = new System.Drawing.Point(364, 153);
            this.grpUserWise.Name = "grpUserWise";
            this.grpUserWise.Size = new System.Drawing.Size(472, 330);
            this.grpUserWise.TabIndex = 8;
            this.grpUserWise.TabStop = false;
            this.grpUserWise.Text = "User wise";
            // 
            // lstLoginSettings
            // 
            this.lstLoginSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstLoginSettings.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstLoginSettings.Font = new System.Drawing.Font("Open Sans", 9.75F);
            this.lstLoginSettings.FormattingEnabled = true;
            this.lstLoginSettings.Location = new System.Drawing.Point(10, 22);
            this.lstLoginSettings.Name = "lstLoginSettings";
            this.lstLoginSettings.Size = new System.Drawing.Size(456, 300);
            this.lstLoginSettings.TabIndex = 11;
            // 
            // grpOperational
            // 
            this.grpOperational.BackColor = System.Drawing.Color.Transparent;
            this.grpOperational.Controls.Add(this.chkActive);
            this.grpOperational.Controls.Add(this.txtFlexibleTime);
            this.grpOperational.Controls.Add(this.lblCheckInTime);
            this.grpOperational.Controls.Add(this.dtpCheckOutTime);
            this.grpOperational.Controls.Add(this.lblCheckOutTime);
            this.grpOperational.Controls.Add(this.dtpCheckInTime);
            this.grpOperational.Controls.Add(this.lblFlexibleTime);
            this.grpOperational.Location = new System.Drawing.Point(7, 3);
            this.grpOperational.Name = "grpOperational";
            this.grpOperational.Size = new System.Drawing.Size(351, 150);
            this.grpOperational.TabIndex = 7;
            this.grpOperational.TabStop = false;
            this.grpOperational.Text = "Global";
            // 
            // txtFlexibleTime
            // 
            this.txtFlexibleTime.BackColor = System.Drawing.SystemColors.Window;
            this.txtFlexibleTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFlexibleTime.Format = null;
            this.txtFlexibleTime.isAllowNegative = false;
            this.txtFlexibleTime.isAllowSpecialChar = false;
            this.txtFlexibleTime.isNumbersOnly = true;
            this.txtFlexibleTime.isNumeric = false;
            this.txtFlexibleTime.isTouchable = false;
            this.txtFlexibleTime.Location = new System.Drawing.Point(149, 124);
            this.txtFlexibleTime.Name = "txtFlexibleTime";
            this.txtFlexibleTime.Size = new System.Drawing.Size(170, 18);
            this.txtFlexibleTime.TabIndex = 2;
            this.txtFlexibleTime.Text = "0";
            this.txtFlexibleTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFlexibleTime.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtFlexibleTime.WaterMark = null;
            // 
            // lblCheckInTime
            // 
            this.lblCheckInTime.AutoSize = true;
            this.lblCheckInTime.Location = new System.Drawing.Point(44, 33);
            this.lblCheckInTime.Name = "lblCheckInTime";
            this.lblCheckInTime.RequiredField = false;
            this.lblCheckInTime.Size = new System.Drawing.Size(99, 18);
            this.lblCheckInTime.TabIndex = 2;
            this.lblCheckInTime.Text = "Check in Time : ";
            // 
            // dtpCheckOutTime
            // 
            this.dtpCheckOutTime.DisbaleDateTimeFormat = false;
            this.dtpCheckOutTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpCheckOutTime.Location = new System.Drawing.Point(149, 59);
            this.dtpCheckOutTime.Name = "dtpCheckOutTime";
            this.dtpCheckOutTime.ShowUpDown = true;
            this.dtpCheckOutTime.Size = new System.Drawing.Size(170, 25);
            this.dtpCheckOutTime.TabIndex = 1;
            // 
            // lblCheckOutTime
            // 
            this.lblCheckOutTime.AutoSize = true;
            this.lblCheckOutTime.Location = new System.Drawing.Point(32, 66);
            this.lblCheckOutTime.Name = "lblCheckOutTime";
            this.lblCheckOutTime.RequiredField = false;
            this.lblCheckOutTime.Size = new System.Drawing.Size(111, 18);
            this.lblCheckOutTime.TabIndex = 3;
            this.lblCheckOutTime.Text = "Check Out Time : ";
            // 
            // dtpCheckInTime
            // 
            this.dtpCheckInTime.DisbaleDateTimeFormat = false;
            this.dtpCheckInTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpCheckInTime.Location = new System.Drawing.Point(149, 28);
            this.dtpCheckInTime.Name = "dtpCheckInTime";
            this.dtpCheckInTime.ShowUpDown = true;
            this.dtpCheckInTime.Size = new System.Drawing.Size(170, 25);
            this.dtpCheckInTime.TabIndex = 0;
            // 
            // lblFlexibleTime
            // 
            this.lblFlexibleTime.AutoSize = true;
            this.lblFlexibleTime.Location = new System.Drawing.Point(18, 124);
            this.lblFlexibleTime.Name = "lblFlexibleTime";
            this.lblFlexibleTime.RequiredField = false;
            this.lblFlexibleTime.Size = new System.Drawing.Size(125, 18);
            this.lblFlexibleTime.TabIndex = 5;
            this.lblFlexibleTime.Text = "Flexible Time (Min) :";
            // 
            // tabEmailTemplate
            // 
            this.tabEmailTemplate.BackColor = System.Drawing.SystemColors.Window;
            this.tabEmailTemplate.Controls.Add(this.button2);
            this.tabEmailTemplate.Controls.Add(this.lblMailUseKeys);
            this.tabEmailTemplate.Controls.Add(this.txtMailUseKeys);
            this.tabEmailTemplate.Controls.Add(this.btnSeperator9);
            this.tabEmailTemplate.Controls.Add(this.lblEmailGrpCheckIn);
            this.tabEmailTemplate.Controls.Add(this.btnSeperator10);
            this.tabEmailTemplate.Controls.Add(this.lblEmailGrpCheckOut);
            this.tabEmailTemplate.Controls.Add(this.txtEmailGrpCheckOut);
            this.tabEmailTemplate.Controls.Add(this.btnSeperator8);
            this.tabEmailTemplate.Controls.Add(this.lblEmailCheckOut);
            this.tabEmailTemplate.Controls.Add(this.txtEmailCheckOut);
            this.tabEmailTemplate.Controls.Add(this.txtEmailGrpCheckIn);
            this.tabEmailTemplate.Controls.Add(this.txtEmailCheckIn);
            this.tabEmailTemplate.Controls.Add(this.btnSeperator7);
            this.tabEmailTemplate.Controls.Add(this.lblEmailCheckIn);
            this.tabEmailTemplate.Controls.Add(this.button1);
            this.tabEmailTemplate.Controls.Add(this.lblEmailBooking);
            this.tabEmailTemplate.Controls.Add(this.txtEmailBooking);
            this.tabEmailTemplate.Location = new System.Drawing.Point(4, 27);
            this.tabEmailTemplate.Name = "tabEmailTemplate";
            this.tabEmailTemplate.Size = new System.Drawing.Size(844, 483);
            this.tabEmailTemplate.TabIndex = 2;
            this.tabEmailTemplate.Text = "Template";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkGray;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(437, 37);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 1);
            this.button2.TabIndex = 173;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // lblMailUseKeys
            // 
            this.lblMailUseKeys.AutoSize = true;
            this.lblMailUseKeys.BackColor = System.Drawing.Color.Transparent;
            this.lblMailUseKeys.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblMailUseKeys.ForeColor = System.Drawing.Color.Black;
            this.lblMailUseKeys.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblMailUseKeys.Location = new System.Drawing.Point(440, 12);
            this.lblMailUseKeys.Name = "lblMailUseKeys";
            this.lblMailUseKeys.RequiredField = false;
            this.lblMailUseKeys.Size = new System.Drawing.Size(80, 22);
            this.lblMailUseKeys.TabIndex = 172;
            this.lblMailUseKeys.Text = "Use Keys";
            // 
            // txtMailUseKeys
            // 
            this.txtMailUseKeys.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMailUseKeys.Location = new System.Drawing.Point(436, 44);
            this.txtMailUseKeys.Name = "txtMailUseKeys";
            this.txtMailUseKeys.ReadOnly = true;
            this.txtMailUseKeys.Size = new System.Drawing.Size(399, 115);
            this.txtMailUseKeys.TabIndex = 171;
            this.txtMailUseKeys.Text = "@VoucherNo@\n@VoucherDate@\n@GuestName@\n@RoomType@\n@Room@\n@ArrivalDate@\n@DepartureD" +
    "ate@\n@NoofDays@\n@Advance@\n@Payment@\n@GrandTotal@";
            // 
            // btnSeperator9
            // 
            this.btnSeperator9.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator9.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator9.FlatAppearance.BorderSize = 0;
            this.btnSeperator9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator9.Location = new System.Drawing.Point(4, 353);
            this.btnSeperator9.Name = "btnSeperator9";
            this.btnSeperator9.Size = new System.Drawing.Size(150, 1);
            this.btnSeperator9.TabIndex = 169;
            this.btnSeperator9.UseVisualStyleBackColor = false;
            // 
            // lblEmailGrpCheckIn
            // 
            this.lblEmailGrpCheckIn.AutoSize = true;
            this.lblEmailGrpCheckIn.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailGrpCheckIn.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblEmailGrpCheckIn.ForeColor = System.Drawing.Color.Black;
            this.lblEmailGrpCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmailGrpCheckIn.Location = new System.Drawing.Point(7, 328);
            this.lblEmailGrpCheckIn.Name = "lblEmailGrpCheckIn";
            this.lblEmailGrpCheckIn.RequiredField = false;
            this.lblEmailGrpCheckIn.Size = new System.Drawing.Size(132, 22);
            this.lblEmailGrpCheckIn.TabIndex = 168;
            this.lblEmailGrpCheckIn.Text = "Group Check In";
            // 
            // btnSeperator10
            // 
            this.btnSeperator10.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator10.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator10.FlatAppearance.BorderSize = 0;
            this.btnSeperator10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator10.Location = new System.Drawing.Point(436, 353);
            this.btnSeperator10.Name = "btnSeperator10";
            this.btnSeperator10.Size = new System.Drawing.Size(150, 1);
            this.btnSeperator10.TabIndex = 167;
            this.btnSeperator10.UseVisualStyleBackColor = false;
            // 
            // lblEmailGrpCheckOut
            // 
            this.lblEmailGrpCheckOut.AutoSize = true;
            this.lblEmailGrpCheckOut.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailGrpCheckOut.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblEmailGrpCheckOut.ForeColor = System.Drawing.Color.Black;
            this.lblEmailGrpCheckOut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmailGrpCheckOut.Location = new System.Drawing.Point(436, 328);
            this.lblEmailGrpCheckOut.Name = "lblEmailGrpCheckOut";
            this.lblEmailGrpCheckOut.RequiredField = false;
            this.lblEmailGrpCheckOut.Size = new System.Drawing.Size(147, 22);
            this.lblEmailGrpCheckOut.TabIndex = 166;
            this.lblEmailGrpCheckOut.Text = "Group Check Out";
            // 
            // txtEmailGrpCheckOut
            // 
            this.txtEmailGrpCheckOut.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmailGrpCheckOut.Format = null;
            this.txtEmailGrpCheckOut.isAllowNegative = false;
            this.txtEmailGrpCheckOut.isAllowSpecialChar = false;
            this.txtEmailGrpCheckOut.isNumeric = false;
            this.txtEmailGrpCheckOut.isTouchable = false;
            this.txtEmailGrpCheckOut.Location = new System.Drawing.Point(435, 360);
            this.txtEmailGrpCheckOut.Multiline = true;
            this.txtEmailGrpCheckOut.Name = "txtEmailGrpCheckOut";
            this.txtEmailGrpCheckOut.Size = new System.Drawing.Size(400, 115);
            this.txtEmailGrpCheckOut.TabIndex = 4;
            this.txtEmailGrpCheckOut.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator8
            // 
            this.btnSeperator8.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator8.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator8.FlatAppearance.BorderSize = 0;
            this.btnSeperator8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator8.Location = new System.Drawing.Point(436, 194);
            this.btnSeperator8.Name = "btnSeperator8";
            this.btnSeperator8.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator8.TabIndex = 164;
            this.btnSeperator8.UseVisualStyleBackColor = false;
            // 
            // lblEmailCheckOut
            // 
            this.lblEmailCheckOut.AutoSize = true;
            this.lblEmailCheckOut.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailCheckOut.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblEmailCheckOut.ForeColor = System.Drawing.Color.Black;
            this.lblEmailCheckOut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmailCheckOut.Location = new System.Drawing.Point(436, 169);
            this.lblEmailCheckOut.Name = "lblEmailCheckOut";
            this.lblEmailCheckOut.RequiredField = false;
            this.lblEmailCheckOut.Size = new System.Drawing.Size(93, 22);
            this.lblEmailCheckOut.TabIndex = 163;
            this.lblEmailCheckOut.Text = "Check Out";
            // 
            // txtEmailCheckOut
            // 
            this.txtEmailCheckOut.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmailCheckOut.Format = null;
            this.txtEmailCheckOut.isAllowNegative = false;
            this.txtEmailCheckOut.isAllowSpecialChar = false;
            this.txtEmailCheckOut.isNumeric = false;
            this.txtEmailCheckOut.isTouchable = false;
            this.txtEmailCheckOut.Location = new System.Drawing.Point(435, 201);
            this.txtEmailCheckOut.Multiline = true;
            this.txtEmailCheckOut.Name = "txtEmailCheckOut";
            this.txtEmailCheckOut.Size = new System.Drawing.Size(400, 115);
            this.txtEmailCheckOut.TabIndex = 2;
            this.txtEmailCheckOut.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtEmailGrpCheckIn
            // 
            this.txtEmailGrpCheckIn.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmailGrpCheckIn.Format = null;
            this.txtEmailGrpCheckIn.isAllowNegative = false;
            this.txtEmailGrpCheckIn.isAllowSpecialChar = false;
            this.txtEmailGrpCheckIn.isNumeric = false;
            this.txtEmailGrpCheckIn.isTouchable = false;
            this.txtEmailGrpCheckIn.Location = new System.Drawing.Point(11, 360);
            this.txtEmailGrpCheckIn.Multiline = true;
            this.txtEmailGrpCheckIn.Name = "txtEmailGrpCheckIn";
            this.txtEmailGrpCheckIn.Size = new System.Drawing.Size(400, 115);
            this.txtEmailGrpCheckIn.TabIndex = 3;
            this.txtEmailGrpCheckIn.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtEmailCheckIn
            // 
            this.txtEmailCheckIn.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmailCheckIn.Format = null;
            this.txtEmailCheckIn.isAllowNegative = false;
            this.txtEmailCheckIn.isAllowSpecialChar = false;
            this.txtEmailCheckIn.isNumeric = false;
            this.txtEmailCheckIn.isTouchable = false;
            this.txtEmailCheckIn.Location = new System.Drawing.Point(11, 201);
            this.txtEmailCheckIn.Multiline = true;
            this.txtEmailCheckIn.Name = "txtEmailCheckIn";
            this.txtEmailCheckIn.Size = new System.Drawing.Size(400, 115);
            this.txtEmailCheckIn.TabIndex = 1;
            this.txtEmailCheckIn.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator7
            // 
            this.btnSeperator7.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator7.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator7.FlatAppearance.BorderSize = 0;
            this.btnSeperator7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator7.Location = new System.Drawing.Point(4, 194);
            this.btnSeperator7.Name = "btnSeperator7";
            this.btnSeperator7.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator7.TabIndex = 159;
            this.btnSeperator7.UseVisualStyleBackColor = false;
            // 
            // lblEmailCheckIn
            // 
            this.lblEmailCheckIn.AutoSize = true;
            this.lblEmailCheckIn.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailCheckIn.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblEmailCheckIn.ForeColor = System.Drawing.Color.Black;
            this.lblEmailCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmailCheckIn.Location = new System.Drawing.Point(7, 169);
            this.lblEmailCheckIn.Name = "lblEmailCheckIn";
            this.lblEmailCheckIn.RequiredField = false;
            this.lblEmailCheckIn.Size = new System.Drawing.Size(78, 22);
            this.lblEmailCheckIn.TabIndex = 158;
            this.lblEmailCheckIn.Text = "Check In";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(4, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 1);
            this.button1.TabIndex = 153;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // lblEmailBooking
            // 
            this.lblEmailBooking.AutoSize = true;
            this.lblEmailBooking.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailBooking.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblEmailBooking.ForeColor = System.Drawing.Color.Black;
            this.lblEmailBooking.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmailBooking.Location = new System.Drawing.Point(7, 12);
            this.lblEmailBooking.Name = "lblEmailBooking";
            this.lblEmailBooking.RequiredField = false;
            this.lblEmailBooking.Size = new System.Drawing.Size(76, 22);
            this.lblEmailBooking.TabIndex = 152;
            this.lblEmailBooking.Text = "Booking";
            // 
            // txtEmailBooking
            // 
            this.txtEmailBooking.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmailBooking.Format = null;
            this.txtEmailBooking.isAllowNegative = false;
            this.txtEmailBooking.isAllowSpecialChar = false;
            this.txtEmailBooking.isNumeric = false;
            this.txtEmailBooking.isTouchable = false;
            this.txtEmailBooking.Location = new System.Drawing.Point(11, 44);
            this.txtEmailBooking.Multiline = true;
            this.txtEmailBooking.Name = "txtEmailBooking";
            this.txtEmailBooking.Size = new System.Drawing.Size(400, 115);
            this.txtEmailBooking.TabIndex = 0;
            this.txtEmailBooking.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // tabSMS
            // 
            this.tabSMS.BackColor = System.Drawing.SystemColors.Window;
            this.tabSMS.Controls.Add(this.button3);
            this.tabSMS.Controls.Add(this.lblSMSUseKeys);
            this.tabSMS.Controls.Add(this.txtSMSUseKeys);
            this.tabSMS.Controls.Add(this.btnSeperator14);
            this.tabSMS.Controls.Add(this.lblSMSGrpCheckIn);
            this.tabSMS.Controls.Add(this.btnSeperator15);
            this.tabSMS.Controls.Add(this.lblSMSGrpCheckOut);
            this.tabSMS.Controls.Add(this.txtSMSGrpCheckOut);
            this.tabSMS.Controls.Add(this.btnSeperator13);
            this.tabSMS.Controls.Add(this.lblSMSCheckOut);
            this.tabSMS.Controls.Add(this.txtSMSCheckOut);
            this.tabSMS.Controls.Add(this.txtSMSGrpCheckIn);
            this.tabSMS.Controls.Add(this.txtSMSCheckIn);
            this.tabSMS.Controls.Add(this.btnSeperator12);
            this.tabSMS.Controls.Add(this.lblSMSCheckIn);
            this.tabSMS.Controls.Add(this.btnSeperator11);
            this.tabSMS.Controls.Add(this.lblSMSBooking);
            this.tabSMS.Controls.Add(this.txtSMSBooking);
            this.tabSMS.Location = new System.Drawing.Point(4, 27);
            this.tabSMS.Name = "tabSMS";
            this.tabSMS.Size = new System.Drawing.Size(844, 483);
            this.tabSMS.TabIndex = 3;
            this.tabSMS.Text = "SMS";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkGray;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(437, 37);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 1);
            this.button3.TabIndex = 187;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // lblSMSUseKeys
            // 
            this.lblSMSUseKeys.AutoSize = true;
            this.lblSMSUseKeys.BackColor = System.Drawing.Color.Transparent;
            this.lblSMSUseKeys.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblSMSUseKeys.ForeColor = System.Drawing.Color.Black;
            this.lblSMSUseKeys.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSMSUseKeys.Location = new System.Drawing.Point(440, 12);
            this.lblSMSUseKeys.Name = "lblSMSUseKeys";
            this.lblSMSUseKeys.RequiredField = false;
            this.lblSMSUseKeys.Size = new System.Drawing.Size(80, 22);
            this.lblSMSUseKeys.TabIndex = 186;
            this.lblSMSUseKeys.Text = "Use Keys";
            // 
            // txtSMSUseKeys
            // 
            this.txtSMSUseKeys.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSMSUseKeys.Location = new System.Drawing.Point(436, 44);
            this.txtSMSUseKeys.Name = "txtSMSUseKeys";
            this.txtSMSUseKeys.ReadOnly = true;
            this.txtSMSUseKeys.Size = new System.Drawing.Size(399, 115);
            this.txtSMSUseKeys.TabIndex = 185;
            this.txtSMSUseKeys.Text = "@VoucherNo@\n@VoucherDate@\n@GuestName@\n@RoomType@\n@Room@\n@ArrivalDate@\n@DepartureD" +
    "ate@\n@NoofDays@\n@Advance@\n@Payment@\n@GrandTotal@";
            // 
            // btnSeperator14
            // 
            this.btnSeperator14.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator14.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator14.FlatAppearance.BorderSize = 0;
            this.btnSeperator14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator14.Location = new System.Drawing.Point(4, 355);
            this.btnSeperator14.Name = "btnSeperator14";
            this.btnSeperator14.Size = new System.Drawing.Size(150, 1);
            this.btnSeperator14.TabIndex = 184;
            this.btnSeperator14.UseVisualStyleBackColor = false;
            // 
            // lblSMSGrpCheckIn
            // 
            this.lblSMSGrpCheckIn.AutoSize = true;
            this.lblSMSGrpCheckIn.BackColor = System.Drawing.Color.Transparent;
            this.lblSMSGrpCheckIn.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblSMSGrpCheckIn.ForeColor = System.Drawing.Color.Black;
            this.lblSMSGrpCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSMSGrpCheckIn.Location = new System.Drawing.Point(7, 330);
            this.lblSMSGrpCheckIn.Name = "lblSMSGrpCheckIn";
            this.lblSMSGrpCheckIn.RequiredField = false;
            this.lblSMSGrpCheckIn.Size = new System.Drawing.Size(132, 22);
            this.lblSMSGrpCheckIn.TabIndex = 183;
            this.lblSMSGrpCheckIn.Text = "Group Check In";
            // 
            // btnSeperator15
            // 
            this.btnSeperator15.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator15.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator15.FlatAppearance.BorderSize = 0;
            this.btnSeperator15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator15.Location = new System.Drawing.Point(436, 355);
            this.btnSeperator15.Name = "btnSeperator15";
            this.btnSeperator15.Size = new System.Drawing.Size(150, 1);
            this.btnSeperator15.TabIndex = 182;
            this.btnSeperator15.UseVisualStyleBackColor = false;
            // 
            // lblSMSGrpCheckOut
            // 
            this.lblSMSGrpCheckOut.AutoSize = true;
            this.lblSMSGrpCheckOut.BackColor = System.Drawing.Color.Transparent;
            this.lblSMSGrpCheckOut.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblSMSGrpCheckOut.ForeColor = System.Drawing.Color.Black;
            this.lblSMSGrpCheckOut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSMSGrpCheckOut.Location = new System.Drawing.Point(436, 330);
            this.lblSMSGrpCheckOut.Name = "lblSMSGrpCheckOut";
            this.lblSMSGrpCheckOut.RequiredField = false;
            this.lblSMSGrpCheckOut.Size = new System.Drawing.Size(147, 22);
            this.lblSMSGrpCheckOut.TabIndex = 181;
            this.lblSMSGrpCheckOut.Text = "Group Check Out";
            // 
            // txtSMSGrpCheckOut
            // 
            this.txtSMSGrpCheckOut.BackColor = System.Drawing.SystemColors.Window;
            this.txtSMSGrpCheckOut.Format = null;
            this.txtSMSGrpCheckOut.isAllowNegative = false;
            this.txtSMSGrpCheckOut.isAllowSpecialChar = false;
            this.txtSMSGrpCheckOut.isNumeric = false;
            this.txtSMSGrpCheckOut.isTouchable = false;
            this.txtSMSGrpCheckOut.Location = new System.Drawing.Point(435, 362);
            this.txtSMSGrpCheckOut.Multiline = true;
            this.txtSMSGrpCheckOut.Name = "txtSMSGrpCheckOut";
            this.txtSMSGrpCheckOut.Size = new System.Drawing.Size(400, 115);
            this.txtSMSGrpCheckOut.TabIndex = 4;
            this.txtSMSGrpCheckOut.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator13
            // 
            this.btnSeperator13.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator13.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator13.FlatAppearance.BorderSize = 0;
            this.btnSeperator13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator13.Location = new System.Drawing.Point(436, 193);
            this.btnSeperator13.Name = "btnSeperator13";
            this.btnSeperator13.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator13.TabIndex = 179;
            this.btnSeperator13.UseVisualStyleBackColor = false;
            // 
            // lblSMSCheckOut
            // 
            this.lblSMSCheckOut.AutoSize = true;
            this.lblSMSCheckOut.BackColor = System.Drawing.Color.Transparent;
            this.lblSMSCheckOut.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblSMSCheckOut.ForeColor = System.Drawing.Color.Black;
            this.lblSMSCheckOut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSMSCheckOut.Location = new System.Drawing.Point(436, 168);
            this.lblSMSCheckOut.Name = "lblSMSCheckOut";
            this.lblSMSCheckOut.RequiredField = false;
            this.lblSMSCheckOut.Size = new System.Drawing.Size(93, 22);
            this.lblSMSCheckOut.TabIndex = 178;
            this.lblSMSCheckOut.Text = "Check Out";
            // 
            // txtSMSCheckOut
            // 
            this.txtSMSCheckOut.BackColor = System.Drawing.SystemColors.Window;
            this.txtSMSCheckOut.Format = null;
            this.txtSMSCheckOut.isAllowNegative = false;
            this.txtSMSCheckOut.isAllowSpecialChar = false;
            this.txtSMSCheckOut.isNumeric = false;
            this.txtSMSCheckOut.isTouchable = false;
            this.txtSMSCheckOut.Location = new System.Drawing.Point(435, 200);
            this.txtSMSCheckOut.Multiline = true;
            this.txtSMSCheckOut.Name = "txtSMSCheckOut";
            this.txtSMSCheckOut.Size = new System.Drawing.Size(400, 115);
            this.txtSMSCheckOut.TabIndex = 2;
            this.txtSMSCheckOut.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtSMSGrpCheckIn
            // 
            this.txtSMSGrpCheckIn.BackColor = System.Drawing.SystemColors.Window;
            this.txtSMSGrpCheckIn.Format = null;
            this.txtSMSGrpCheckIn.isAllowNegative = false;
            this.txtSMSGrpCheckIn.isAllowSpecialChar = false;
            this.txtSMSGrpCheckIn.isNumeric = false;
            this.txtSMSGrpCheckIn.isTouchable = false;
            this.txtSMSGrpCheckIn.Location = new System.Drawing.Point(11, 362);
            this.txtSMSGrpCheckIn.Multiline = true;
            this.txtSMSGrpCheckIn.Name = "txtSMSGrpCheckIn";
            this.txtSMSGrpCheckIn.Size = new System.Drawing.Size(400, 115);
            this.txtSMSGrpCheckIn.TabIndex = 3;
            this.txtSMSGrpCheckIn.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtSMSCheckIn
            // 
            this.txtSMSCheckIn.BackColor = System.Drawing.SystemColors.Window;
            this.txtSMSCheckIn.Format = null;
            this.txtSMSCheckIn.isAllowNegative = false;
            this.txtSMSCheckIn.isAllowSpecialChar = false;
            this.txtSMSCheckIn.isNumeric = false;
            this.txtSMSCheckIn.isTouchable = false;
            this.txtSMSCheckIn.Location = new System.Drawing.Point(11, 200);
            this.txtSMSCheckIn.Multiline = true;
            this.txtSMSCheckIn.Name = "txtSMSCheckIn";
            this.txtSMSCheckIn.Size = new System.Drawing.Size(400, 115);
            this.txtSMSCheckIn.TabIndex = 1;
            this.txtSMSCheckIn.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSeperator12
            // 
            this.btnSeperator12.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator12.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator12.FlatAppearance.BorderSize = 0;
            this.btnSeperator12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator12.Location = new System.Drawing.Point(4, 193);
            this.btnSeperator12.Name = "btnSeperator12";
            this.btnSeperator12.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator12.TabIndex = 174;
            this.btnSeperator12.UseVisualStyleBackColor = false;
            // 
            // lblSMSCheckIn
            // 
            this.lblSMSCheckIn.AutoSize = true;
            this.lblSMSCheckIn.BackColor = System.Drawing.Color.Transparent;
            this.lblSMSCheckIn.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblSMSCheckIn.ForeColor = System.Drawing.Color.Black;
            this.lblSMSCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSMSCheckIn.Location = new System.Drawing.Point(7, 168);
            this.lblSMSCheckIn.Name = "lblSMSCheckIn";
            this.lblSMSCheckIn.RequiredField = false;
            this.lblSMSCheckIn.Size = new System.Drawing.Size(78, 22);
            this.lblSMSCheckIn.TabIndex = 173;
            this.lblSMSCheckIn.Text = "Check In";
            // 
            // btnSeperator11
            // 
            this.btnSeperator11.BackColor = System.Drawing.Color.DarkGray;
            this.btnSeperator11.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSeperator11.FlatAppearance.BorderSize = 0;
            this.btnSeperator11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeperator11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSeperator11.Location = new System.Drawing.Point(4, 36);
            this.btnSeperator11.Name = "btnSeperator11";
            this.btnSeperator11.Size = new System.Drawing.Size(100, 1);
            this.btnSeperator11.TabIndex = 171;
            this.btnSeperator11.UseVisualStyleBackColor = false;
            // 
            // lblSMSBooking
            // 
            this.lblSMSBooking.AutoSize = true;
            this.lblSMSBooking.BackColor = System.Drawing.Color.Transparent;
            this.lblSMSBooking.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblSMSBooking.ForeColor = System.Drawing.Color.Black;
            this.lblSMSBooking.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSMSBooking.Location = new System.Drawing.Point(7, 11);
            this.lblSMSBooking.Name = "lblSMSBooking";
            this.lblSMSBooking.RequiredField = false;
            this.lblSMSBooking.Size = new System.Drawing.Size(76, 22);
            this.lblSMSBooking.TabIndex = 170;
            this.lblSMSBooking.Text = "Booking";
            // 
            // txtSMSBooking
            // 
            this.txtSMSBooking.BackColor = System.Drawing.SystemColors.Window;
            this.txtSMSBooking.Format = null;
            this.txtSMSBooking.isAllowNegative = false;
            this.txtSMSBooking.isAllowSpecialChar = false;
            this.txtSMSBooking.isNumeric = false;
            this.txtSMSBooking.isTouchable = false;
            this.txtSMSBooking.Location = new System.Drawing.Point(11, 43);
            this.txtSMSBooking.Multiline = true;
            this.txtSMSBooking.Name = "txtSMSBooking";
            this.txtSMSBooking.Size = new System.Drawing.Size(400, 115);
            this.txtSMSBooking.TabIndex = 0;
            this.txtSMSBooking.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // tabWhatsApp
            // 
            this.tabWhatsApp.BackColor = System.Drawing.SystemColors.Window;
            this.tabWhatsApp.Controls.Add(this.button4);
            this.tabWhatsApp.Controls.Add(this.atLabel1);
            this.tabWhatsApp.Controls.Add(this.richTextBox1);
            this.tabWhatsApp.Controls.Add(this.btnSepeartor19);
            this.tabWhatsApp.Controls.Add(this.lblWhtsappGrpCheckIn);
            this.tabWhatsApp.Controls.Add(this.btnSepeartor20);
            this.tabWhatsApp.Controls.Add(this.lblWhtsappGrpCheckOut);
            this.tabWhatsApp.Controls.Add(this.txtWhtsappGrpCheckOut);
            this.tabWhatsApp.Controls.Add(this.btnSepeartor18);
            this.tabWhatsApp.Controls.Add(this.lblWhtsappCheckOut);
            this.tabWhatsApp.Controls.Add(this.txtWhtsappCheckOut);
            this.tabWhatsApp.Controls.Add(this.txtWhtsappGrpCheckIn);
            this.tabWhatsApp.Controls.Add(this.txtWhtsappCheckIn);
            this.tabWhatsApp.Controls.Add(this.btnSepeartor17);
            this.tabWhatsApp.Controls.Add(this.lblWhtsappCheckIn);
            this.tabWhatsApp.Controls.Add(this.btnSepeartor16);
            this.tabWhatsApp.Controls.Add(this.lblWhtsappBooking);
            this.tabWhatsApp.Controls.Add(this.txtWhtsappBooking);
            this.tabWhatsApp.Location = new System.Drawing.Point(4, 27);
            this.tabWhatsApp.Name = "tabWhatsApp";
            this.tabWhatsApp.Size = new System.Drawing.Size(844, 483);
            this.tabWhatsApp.TabIndex = 4;
            this.tabWhatsApp.Text = "WhatsApp";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkGray;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button4.Location = new System.Drawing.Point(437, 36);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 1);
            this.button4.TabIndex = 202;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // atLabel1
            // 
            this.atLabel1.AutoSize = true;
            this.atLabel1.BackColor = System.Drawing.Color.Transparent;
            this.atLabel1.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.atLabel1.ForeColor = System.Drawing.Color.Black;
            this.atLabel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atLabel1.Location = new System.Drawing.Point(440, 11);
            this.atLabel1.Name = "atLabel1";
            this.atLabel1.RequiredField = false;
            this.atLabel1.Size = new System.Drawing.Size(80, 22);
            this.atLabel1.TabIndex = 201;
            this.atLabel1.Text = "Use Keys";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Location = new System.Drawing.Point(436, 43);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(399, 115);
            this.richTextBox1.TabIndex = 200;
            this.richTextBox1.Text = "@VoucherNo@\n@VoucherDate@\n@GuestName@\n@RoomType@\n@Room@\n@ArrivalDate@\n@DepartureD" +
    "ate@\n@NoofDays@\n@Advance@\n@Payment@\n@GrandTotal@";
            // 
            // btnSepeartor19
            // 
            this.btnSepeartor19.BackColor = System.Drawing.Color.DarkGray;
            this.btnSepeartor19.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSepeartor19.FlatAppearance.BorderSize = 0;
            this.btnSepeartor19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSepeartor19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSepeartor19.Location = new System.Drawing.Point(5, 355);
            this.btnSepeartor19.Name = "btnSepeartor19";
            this.btnSepeartor19.Size = new System.Drawing.Size(150, 1);
            this.btnSepeartor19.TabIndex = 199;
            this.btnSepeartor19.UseVisualStyleBackColor = false;
            // 
            // lblWhtsappGrpCheckIn
            // 
            this.lblWhtsappGrpCheckIn.AutoSize = true;
            this.lblWhtsappGrpCheckIn.BackColor = System.Drawing.Color.Transparent;
            this.lblWhtsappGrpCheckIn.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblWhtsappGrpCheckIn.ForeColor = System.Drawing.Color.Black;
            this.lblWhtsappGrpCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblWhtsappGrpCheckIn.Location = new System.Drawing.Point(8, 330);
            this.lblWhtsappGrpCheckIn.Name = "lblWhtsappGrpCheckIn";
            this.lblWhtsappGrpCheckIn.RequiredField = false;
            this.lblWhtsappGrpCheckIn.Size = new System.Drawing.Size(132, 22);
            this.lblWhtsappGrpCheckIn.TabIndex = 198;
            this.lblWhtsappGrpCheckIn.Text = "Group Check In";
            // 
            // btnSepeartor20
            // 
            this.btnSepeartor20.BackColor = System.Drawing.Color.DarkGray;
            this.btnSepeartor20.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSepeartor20.FlatAppearance.BorderSize = 0;
            this.btnSepeartor20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSepeartor20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSepeartor20.Location = new System.Drawing.Point(437, 355);
            this.btnSepeartor20.Name = "btnSepeartor20";
            this.btnSepeartor20.Size = new System.Drawing.Size(150, 1);
            this.btnSepeartor20.TabIndex = 197;
            this.btnSepeartor20.UseVisualStyleBackColor = false;
            // 
            // lblWhtsappGrpCheckOut
            // 
            this.lblWhtsappGrpCheckOut.AutoSize = true;
            this.lblWhtsappGrpCheckOut.BackColor = System.Drawing.Color.Transparent;
            this.lblWhtsappGrpCheckOut.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblWhtsappGrpCheckOut.ForeColor = System.Drawing.Color.Black;
            this.lblWhtsappGrpCheckOut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblWhtsappGrpCheckOut.Location = new System.Drawing.Point(437, 330);
            this.lblWhtsappGrpCheckOut.Name = "lblWhtsappGrpCheckOut";
            this.lblWhtsappGrpCheckOut.RequiredField = false;
            this.lblWhtsappGrpCheckOut.Size = new System.Drawing.Size(147, 22);
            this.lblWhtsappGrpCheckOut.TabIndex = 196;
            this.lblWhtsappGrpCheckOut.Text = "Group Check Out";
            // 
            // txtWhtsappGrpCheckOut
            // 
            this.txtWhtsappGrpCheckOut.BackColor = System.Drawing.SystemColors.Window;
            this.txtWhtsappGrpCheckOut.Format = null;
            this.txtWhtsappGrpCheckOut.isAllowNegative = false;
            this.txtWhtsappGrpCheckOut.isAllowSpecialChar = false;
            this.txtWhtsappGrpCheckOut.isNumeric = false;
            this.txtWhtsappGrpCheckOut.isTouchable = false;
            this.txtWhtsappGrpCheckOut.Location = new System.Drawing.Point(436, 362);
            this.txtWhtsappGrpCheckOut.Multiline = true;
            this.txtWhtsappGrpCheckOut.Name = "txtWhtsappGrpCheckOut";
            this.txtWhtsappGrpCheckOut.Size = new System.Drawing.Size(400, 115);
            this.txtWhtsappGrpCheckOut.TabIndex = 4;
            this.txtWhtsappGrpCheckOut.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSepeartor18
            // 
            this.btnSepeartor18.BackColor = System.Drawing.Color.DarkGray;
            this.btnSepeartor18.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSepeartor18.FlatAppearance.BorderSize = 0;
            this.btnSepeartor18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSepeartor18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSepeartor18.Location = new System.Drawing.Point(437, 193);
            this.btnSepeartor18.Name = "btnSepeartor18";
            this.btnSepeartor18.Size = new System.Drawing.Size(100, 1);
            this.btnSepeartor18.TabIndex = 194;
            this.btnSepeartor18.UseVisualStyleBackColor = false;
            // 
            // lblWhtsappCheckOut
            // 
            this.lblWhtsappCheckOut.AutoSize = true;
            this.lblWhtsappCheckOut.BackColor = System.Drawing.Color.Transparent;
            this.lblWhtsappCheckOut.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblWhtsappCheckOut.ForeColor = System.Drawing.Color.Black;
            this.lblWhtsappCheckOut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblWhtsappCheckOut.Location = new System.Drawing.Point(437, 168);
            this.lblWhtsappCheckOut.Name = "lblWhtsappCheckOut";
            this.lblWhtsappCheckOut.RequiredField = false;
            this.lblWhtsappCheckOut.Size = new System.Drawing.Size(93, 22);
            this.lblWhtsappCheckOut.TabIndex = 193;
            this.lblWhtsappCheckOut.Text = "Check Out";
            // 
            // txtWhtsappCheckOut
            // 
            this.txtWhtsappCheckOut.BackColor = System.Drawing.SystemColors.Window;
            this.txtWhtsappCheckOut.Format = null;
            this.txtWhtsappCheckOut.isAllowNegative = false;
            this.txtWhtsappCheckOut.isAllowSpecialChar = false;
            this.txtWhtsappCheckOut.isNumeric = false;
            this.txtWhtsappCheckOut.isTouchable = false;
            this.txtWhtsappCheckOut.Location = new System.Drawing.Point(436, 200);
            this.txtWhtsappCheckOut.Multiline = true;
            this.txtWhtsappCheckOut.Name = "txtWhtsappCheckOut";
            this.txtWhtsappCheckOut.Size = new System.Drawing.Size(400, 115);
            this.txtWhtsappCheckOut.TabIndex = 2;
            this.txtWhtsappCheckOut.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtWhtsappGrpCheckIn
            // 
            this.txtWhtsappGrpCheckIn.BackColor = System.Drawing.SystemColors.Window;
            this.txtWhtsappGrpCheckIn.Format = null;
            this.txtWhtsappGrpCheckIn.isAllowNegative = false;
            this.txtWhtsappGrpCheckIn.isAllowSpecialChar = false;
            this.txtWhtsappGrpCheckIn.isNumeric = false;
            this.txtWhtsappGrpCheckIn.isTouchable = false;
            this.txtWhtsappGrpCheckIn.Location = new System.Drawing.Point(12, 362);
            this.txtWhtsappGrpCheckIn.Multiline = true;
            this.txtWhtsappGrpCheckIn.Name = "txtWhtsappGrpCheckIn";
            this.txtWhtsappGrpCheckIn.Size = new System.Drawing.Size(400, 115);
            this.txtWhtsappGrpCheckIn.TabIndex = 3;
            this.txtWhtsappGrpCheckIn.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // txtWhtsappCheckIn
            // 
            this.txtWhtsappCheckIn.BackColor = System.Drawing.SystemColors.Window;
            this.txtWhtsappCheckIn.Format = null;
            this.txtWhtsappCheckIn.isAllowNegative = false;
            this.txtWhtsappCheckIn.isAllowSpecialChar = false;
            this.txtWhtsappCheckIn.isNumeric = false;
            this.txtWhtsappCheckIn.isTouchable = false;
            this.txtWhtsappCheckIn.Location = new System.Drawing.Point(12, 200);
            this.txtWhtsappCheckIn.Multiline = true;
            this.txtWhtsappCheckIn.Name = "txtWhtsappCheckIn";
            this.txtWhtsappCheckIn.Size = new System.Drawing.Size(400, 115);
            this.txtWhtsappCheckIn.TabIndex = 1;
            this.txtWhtsappCheckIn.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // btnSepeartor17
            // 
            this.btnSepeartor17.BackColor = System.Drawing.Color.DarkGray;
            this.btnSepeartor17.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSepeartor17.FlatAppearance.BorderSize = 0;
            this.btnSepeartor17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSepeartor17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSepeartor17.Location = new System.Drawing.Point(5, 193);
            this.btnSepeartor17.Name = "btnSepeartor17";
            this.btnSepeartor17.Size = new System.Drawing.Size(100, 1);
            this.btnSepeartor17.TabIndex = 189;
            this.btnSepeartor17.UseVisualStyleBackColor = false;
            // 
            // lblWhtsappCheckIn
            // 
            this.lblWhtsappCheckIn.AutoSize = true;
            this.lblWhtsappCheckIn.BackColor = System.Drawing.Color.Transparent;
            this.lblWhtsappCheckIn.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblWhtsappCheckIn.ForeColor = System.Drawing.Color.Black;
            this.lblWhtsappCheckIn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblWhtsappCheckIn.Location = new System.Drawing.Point(8, 168);
            this.lblWhtsappCheckIn.Name = "lblWhtsappCheckIn";
            this.lblWhtsappCheckIn.RequiredField = false;
            this.lblWhtsappCheckIn.Size = new System.Drawing.Size(78, 22);
            this.lblWhtsappCheckIn.TabIndex = 188;
            this.lblWhtsappCheckIn.Text = "Check In";
            // 
            // btnSepeartor16
            // 
            this.btnSepeartor16.BackColor = System.Drawing.Color.DarkGray;
            this.btnSepeartor16.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSepeartor16.FlatAppearance.BorderSize = 0;
            this.btnSepeartor16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSepeartor16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSepeartor16.Location = new System.Drawing.Point(5, 36);
            this.btnSepeartor16.Name = "btnSepeartor16";
            this.btnSepeartor16.Size = new System.Drawing.Size(100, 1);
            this.btnSepeartor16.TabIndex = 186;
            this.btnSepeartor16.UseVisualStyleBackColor = false;
            // 
            // lblWhtsappBooking
            // 
            this.lblWhtsappBooking.AutoSize = true;
            this.lblWhtsappBooking.BackColor = System.Drawing.Color.Transparent;
            this.lblWhtsappBooking.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblWhtsappBooking.ForeColor = System.Drawing.Color.Black;
            this.lblWhtsappBooking.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblWhtsappBooking.Location = new System.Drawing.Point(8, 11);
            this.lblWhtsappBooking.Name = "lblWhtsappBooking";
            this.lblWhtsappBooking.RequiredField = false;
            this.lblWhtsappBooking.Size = new System.Drawing.Size(76, 22);
            this.lblWhtsappBooking.TabIndex = 185;
            this.lblWhtsappBooking.Text = "Booking";
            // 
            // txtWhtsappBooking
            // 
            this.txtWhtsappBooking.BackColor = System.Drawing.SystemColors.Window;
            this.txtWhtsappBooking.Format = null;
            this.txtWhtsappBooking.isAllowNegative = false;
            this.txtWhtsappBooking.isAllowSpecialChar = false;
            this.txtWhtsappBooking.isNumeric = false;
            this.txtWhtsappBooking.isTouchable = false;
            this.txtWhtsappBooking.Location = new System.Drawing.Point(12, 43);
            this.txtWhtsappBooking.Multiline = true;
            this.txtWhtsappBooking.Name = "txtWhtsappBooking";
            this.txtWhtsappBooking.Size = new System.Drawing.Size(400, 115);
            this.txtWhtsappBooking.TabIndex = 0;
            this.txtWhtsappBooking.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // chkActive
            // 
            this.chkActive.AutoSize = true;
            this.chkActive.Location = new System.Drawing.Point(149, 90);
            this.chkActive.Name = "chkActive";
            this.chkActive.Size = new System.Drawing.Size(139, 22);
            this.chkActive.TabIndex = 6;
            this.chkActive.Text = "Apply Default Time";
            this.chkActive.UseVisualStyleBackColor = true;
            // 
            // SettingsView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 570);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlOptionalBar);
            this.Name = "SettingsView";
            this.NewRecord = true;
            this.Text = "Settings";
            this.atOkClick += new atACCFramework.BaseClasses.OKClickEventHandler(this.SettingsView_atOkClick);
            this.atCancelClick += new atACCFramework.BaseClasses.CancelClickEventHandler(this.SettingsView_atCancelClick);
            this.atValidate += new atACCFramework.BaseClasses.ValidateOKClickHandler(this.SettingsView_atValidate);
            this.atInitialise += new atACCFramework.BaseClasses.InitialiseEventHandler(this.SettingsView_atInitialise);
            this.Load += new System.EventHandler(this.SettingsView_Load);
            this.Controls.SetChildIndex(this.pnlOptionalBar, 0);
            this.Controls.SetChildIndex(this.pnlMain, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.pnlOptionalBar.ResumeLayout(false);
            this.pnlOptionalBar.PerformLayout();
            this.pnlAccounts.ResumeLayout(false);
            this.pnlAccounts.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.TabSettings.ResumeLayout(false);
            this.tabAccounts.ResumeLayout(false);
            this.tabDefault.ResumeLayout(false);
            this.grpRoomOraHallUserfields.ResumeLayout(false);
            this.grpRoomOraHallUserfields.PerformLayout();
            this.grpStatusColor.ResumeLayout(false);
            this.grpStatusColor.PerformLayout();
            this.grpUserWise.ResumeLayout(false);
            this.grpOperational.ResumeLayout(false);
            this.grpOperational.PerformLayout();
            this.tabEmailTemplate.ResumeLayout(false);
            this.tabEmailTemplate.PerformLayout();
            this.tabSMS.ResumeLayout(false);
            this.tabSMS.PerformLayout();
            this.tabWhatsApp.ResumeLayout(false);
            this.tabWhatsApp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private atACCFramework.UserControls.atGradientPanel pnlOptionalBar;
        private System.Windows.Forms.Button btnSeperator1;
        private atACCFramework.UserControls.atLabel lblGlobal;
        private atACCFramework.UserControls.atGradientPanel btnSelected;
        private System.Windows.Forms.Button btnDefault;
        private System.Windows.Forms.Button btnAccounts;
        private atACCFramework.UserControls.atPanel pnlAccounts;
        private atACCFramework.UserControls.atLabel lblExtras;
        private atACCFramework.UserControls.atLabel lblRent;
        private atACCFramework.UserControls.ComboBoxExt cmbGuests;
        private atACCFramework.UserControls.ComboBoxExt cmbLaundry;
        private atACCFramework.UserControls.ComboBoxExt cmbDeduction;
        private atACCFramework.UserControls.ComboBoxExt cmbExtras;
        private atACCFramework.UserControls.ComboBoxExt cmbRentAccount;
        private atACCFramework.UserControls.atLabel lblGuests;
        private atACCFramework.UserControls.atLabel lblLaundry;
        private atACCFramework.UserControls.atLabel lblDeduction;
        private System.Windows.Forms.Button btnSeperator3;
        private atACCFramework.UserControls.atLabel lblCommon;
        private System.Windows.Forms.Button btnSeperator4;
        private atACCFramework.UserControls.ComboBoxExt cmbDiscountSlab;
        private atACCFramework.UserControls.atLabel lblSlabs;
        private atACCFramework.UserControls.ComboBoxExt cmbSGST;
        private atACCFramework.UserControls.ComboBoxExt cmbVAT;
        private atACCFramework.UserControls.ComboBoxExt cmbAddlTax;
        private atACCFramework.UserControls.ComboBoxExt cmbTax3;
        private atACCFramework.UserControls.ComboBoxExt cmbTax2;
        private atACCFramework.UserControls.ComboBoxExt cmbTax1;
        private atACCFramework.UserControls.ComboBoxExt cmbExciseDuty;
        private System.Windows.Forms.Button btnSeperator5;
        private atACCFramework.UserControls.atLabel lblPayment;
        private atACCFramework.UserControls.atLabel lblExciseDuty;
        private atACCFramework.UserControls.atLabel lblAdditionalTax;
        private atACCFramework.UserControls.atLabel lblTax3;
        private atACCFramework.UserControls.atLabel lblDiscount;
        private atACCFramework.UserControls.atLabel lblSGST;
        private atACCFramework.UserControls.atLabel lblVAT;
        private atACCFramework.UserControls.atLabel lblTax2;
        private atACCFramework.UserControls.atLabel lblTax1;
        private atACCFramework.UserControls.ComboBoxExt cmbEWallet;
        private atACCFramework.UserControls.ComboBoxExt cmbOnlineBanking;
        private atACCFramework.UserControls.ComboBoxExt cmbCreditCard;
        private atACCFramework.UserControls.ComboBoxExt cmbDD;
        private atACCFramework.UserControls.ComboBoxExt cmbCheque;
        private atACCFramework.UserControls.ComboBoxExt cmbCash;
        private atACCFramework.UserControls.atLabel lblEWallet;
        private atACCFramework.UserControls.atLabel lblOnlineBanking;
        private atACCFramework.UserControls.atLabel lblDD;
        private atACCFramework.UserControls.atLabel lblCheque;
        private atACCFramework.UserControls.atLabel lblCreditCard;
        private atACCFramework.UserControls.atLabel lblCash;
        private atACCFramework.UserControls.atPanel pnlMain;
        private atACCFramework.UserControls.atTabControl TabSettings;
        private System.Windows.Forms.TabPage tabAccounts;
        private System.Windows.Forms.TabPage tabDefault;
        private atACCFramework.UserControls.atLabel lblCheckOutTime;
        private atACCFramework.UserControls.atLabel lblCheckInTime;
        private atACCFramework.UserControls.atLabel lblFlexibleTime;
        private atACCFramework.UserControls.TextBoxExt txtFlexibleTime;
        private atACCFramework.UserControls.ComboBoxExt cmbIGST;
        private atACCFramework.UserControls.ComboBoxExt cmbCGST;
        private atACCFramework.UserControls.atLabel lblIGST;
        private atACCFramework.UserControls.atLabel lblCGST;
        private atACCFramework.UserControls.atDateTimePicker1 dtpCheckOutTime;
        private atACCFramework.UserControls.atDateTimePicker1 dtpCheckInTime;
        private atACCFramework.UserControls.atGroupBox grpUserWise;
        private System.Windows.Forms.CheckedListBox lstLoginSettings;
        private atACCFramework.UserControls.atGroupBox grpOperational;
        private System.Windows.Forms.Button btnEmailTemp;
        private System.Windows.Forms.TabPage tabEmailTemplate;
        private atACCFramework.UserControls.TextBoxNormal txtEmailBooking;
        private System.Windows.Forms.Button button1;
        private atACCFramework.UserControls.atLabel lblEmailBooking;
        private System.Windows.Forms.Button btnSeperator9;
        private atACCFramework.UserControls.atLabel lblEmailGrpCheckIn;
        private System.Windows.Forms.Button btnSeperator10;
        private atACCFramework.UserControls.atLabel lblEmailGrpCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtEmailGrpCheckOut;
        private System.Windows.Forms.Button btnSeperator8;
        private atACCFramework.UserControls.atLabel lblEmailCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtEmailCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtEmailGrpCheckIn;
        private atACCFramework.UserControls.TextBoxNormal txtEmailCheckIn;
        private System.Windows.Forms.Button btnSeperator7;
        private atACCFramework.UserControls.atLabel lblEmailCheckIn;
        private System.Windows.Forms.Button btnWhatsAppTemp;
        private System.Windows.Forms.Button btnSMSTemp;
        private System.Windows.Forms.TabPage tabSMS;
        private System.Windows.Forms.TabPage tabWhatsApp;
        private System.Windows.Forms.Button btnSeperator14;
        private atACCFramework.UserControls.atLabel lblSMSGrpCheckIn;
        private System.Windows.Forms.Button btnSeperator15;
        private atACCFramework.UserControls.atLabel lblSMSGrpCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtSMSGrpCheckOut;
        private System.Windows.Forms.Button btnSeperator13;
        private atACCFramework.UserControls.atLabel lblSMSCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtSMSCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtSMSGrpCheckIn;
        private atACCFramework.UserControls.TextBoxNormal txtSMSCheckIn;
        private System.Windows.Forms.Button btnSeperator12;
        private atACCFramework.UserControls.atLabel lblSMSCheckIn;
        private System.Windows.Forms.Button btnSeperator11;
        private atACCFramework.UserControls.atLabel lblSMSBooking;
        private atACCFramework.UserControls.TextBoxNormal txtSMSBooking;
        private System.Windows.Forms.Button btnSepeartor19;
        private atACCFramework.UserControls.atLabel lblWhtsappGrpCheckIn;
        private System.Windows.Forms.Button btnSepeartor20;
        private atACCFramework.UserControls.atLabel lblWhtsappGrpCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtWhtsappGrpCheckOut;
        private System.Windows.Forms.Button btnSepeartor18;
        private atACCFramework.UserControls.atLabel lblWhtsappCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtWhtsappCheckOut;
        private atACCFramework.UserControls.TextBoxNormal txtWhtsappGrpCheckIn;
        private atACCFramework.UserControls.TextBoxNormal txtWhtsappCheckIn;
        private System.Windows.Forms.Button btnSepeartor17;
        private atACCFramework.UserControls.atLabel lblWhtsappCheckIn;
        private System.Windows.Forms.Button btnSepeartor16;
        private atACCFramework.UserControls.atLabel lblWhtsappBooking;
        private atACCFramework.UserControls.TextBoxNormal txtWhtsappBooking;
        private atACCFramework.UserControls.atGroupBox grpStatusColor;
        private System.Windows.Forms.Button btnColorOutofOrder;
        private System.Windows.Forms.Button btnColorClean;
        private System.Windows.Forms.Button btnColorDirty;
        private atACCFramework.UserControls.atLabel lblGrpCheckIn;
        private atACCFramework.UserControls.atLabel lblCheckIn;
        private atACCFramework.UserControls.atLabel lblGrpBooking;
        private System.Windows.Forms.Button btnColorGrpCheckIn;
        private System.Windows.Forms.Button btnColorCheckIn;
        private System.Windows.Forms.Button btnColorGrpBooking;
        private atACCFramework.UserControls.atLabel lblBooking;
        private System.Windows.Forms.Button btnColorBooking;
        private atACCFramework.UserControls.atLabel lblAvailable;
        private System.Windows.Forms.Button btnColorAvailable;
        private atACCFramework.UserControls.atLabel lblOutofOrder;
        private atACCFramework.UserControls.atLabel lblClean;
        private atACCFramework.UserControls.atLabel lblDirty;
        private System.Windows.Forms.ColorDialog clrStatusColor;
        private atACCFramework.UserControls.atGroupBox grpRoomOraHallUserfields;
        private atACCFramework.UserControls.TextBoxExt txtRoomUserField4;
        private atACCFramework.UserControls.TextBoxExt txtRoomUserField3;
        private atACCFramework.UserControls.TextBoxExt txtRoomUserField2;
        private atACCFramework.UserControls.TextBoxExt txtRoomUserField1;
        private atACCFramework.UserControls.TextBoxExt txtHallUserField4;
        private atACCFramework.UserControls.TextBoxExt txtHallUserField3;
        private atACCFramework.UserControls.TextBoxExt txtHallUserField2;
        private atACCFramework.UserControls.TextBoxExt txtHallUserField1;
        private atACCFramework.UserControls.atLabel lblHallCap;
        private atACCFramework.UserControls.atLabel lblRoomCap;
        private atACCFramework.UserControls.atLabel lblUserFiled1;
        private atACCFramework.UserControls.atLabel lblUserFiled4;
        private atACCFramework.UserControls.atLabel lblUserFiled2;
        private atACCFramework.UserControls.atLabel lblUserFiled3;
        private System.Windows.Forms.RichTextBox txtMailUseKeys;
        private System.Windows.Forms.Button button2;
        private atACCFramework.UserControls.atLabel lblMailUseKeys;
        private System.Windows.Forms.Button button3;
        private atACCFramework.UserControls.atLabel lblSMSUseKeys;
        private System.Windows.Forms.RichTextBox txtSMSUseKeys;
        private System.Windows.Forms.Button button4;
        private atACCFramework.UserControls.atLabel atLabel1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private atACCFramework.UserControls.atCheckBox chkActive;
    }
}